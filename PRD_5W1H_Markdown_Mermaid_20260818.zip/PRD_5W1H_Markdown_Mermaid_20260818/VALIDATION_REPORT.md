# Validation Report

- 検証日: **2026-08-18（JST）**
- 対象: `README.md`、PRDテンプレート、記入サンプル、調査資料
- 結果: **構造・Markdown・表・5W1H・ID範囲の検査はPASS**

## 1. ファイル別結果

| File | Lines | Bytes | Mermaid blocks | Numbered sections | YAML front matter | Markdown parse |
|---|---:|---:|---:|---:|---|---|
| `README.md` | 90 | 5,139 | 1 | 0 | N/A | PASS (350 tokens) |
| `01_PRD_Template_5W1H.md` | 1,196 | 51,717 | 15 | 16 | PASS | PASS (7,050 tokens) |
| `02_PRD_Sample_Inventory_5W1H.md` | 1,446 | 100,204 | 18 | 16 | PASS | PASS (11,254 tokens) |
| `SOURCES.md` | 168 | 11,069 | 0 | 0 | N/A | PASS (630 tokens) |

## 2. 実施した検査

| Check | 内容 | Result |
|---|---|---|
| UTF-8読込 | 全ファイルをUTF-8として読込可能 | **PASS** |
| YAML front matter | テンプレートとサンプルをPyYAMLで構文解析 | **PASS** |
| 章構造 | テンプレートとサンプルにトップレベル1〜16章が重複・欠落なく存在 | **PASS** |
| 5W1H | 各1〜16章の直下にWho／What／When／Where／Why／Howの説明が存在 | **PASS** |
| Code fence | Markdown code fenceの開始・終了が対応 | **PASS** |
| Mermaid block | 各blockが標準Diagram宣言（flowchart／sequenceDiagram／stateDiagram-v2／gantt）から開始 | **PASS** |
| Markdown table | HeaderとData rowの列数が全表で一致 | **PASS** |
| Markdown parser | CommonMark + table extensionで全ファイルを解析 | **PASS** |
| Sample ID範囲 | OBJ、KPI、GRD、US、FR、NFR、AC、Risk等の主要定義数を確認 | **PASS** |
| Sampleの未確定表現 | 実装前に判定するRelease checklist以外の空Checkboxなし。TBRはOwner・期限付き | **PASS** |
| Source provenance | 公式・一次資料のTitle、URL、版・状態を調査日に確認しSOURCES.mdへ記録 | **PASS** |

## 3. サンプル定義数

| 種別 | 件数 |
|---|---:|
| Objectives | 9 |
| KPI | 4 |
| Guardrails | 4 |
| User stories | 8 |
| Functional requirements | 14 |
| Non-functional requirements | 21 |
| Acceptance criteria | 18 |
| Risks | 8 |
| Assumptions | 5 |
| TBR | 5 |
| Milestones | 10 |
| Future opportunities | 6 |

## 4. Mermaid検証範囲

- Code fence、Diagram種別、開始・終了、Markdown内の配置を構造検査した。
- GitHub Docsが案内する`mermaid` language identifierのFenced block形式を使用している。
- 実際のRendering engineのVersionはGitHub、GitLab、Confluence、VS Code extension等で異なるため、公開先のPreviewで最終表示を確認する。
- Mermaid図は補助表現であり、要件、閾値、権限、受入条件、承認条件は本文・表にも記載している。

## 5. 既知の制約

1. サンプルの数値、日程、Architecture候補、Persona、Evidenceは架空であり、実案件の事実を示さない。
2. ISO規格本文の全内容ではなく、公式公開概要と実務参照点を利用している。規制・契約適合性は組織の法務・Security・Quality責任者が判定する。
3. Link先は調査日現在の公式Pageである。外部Pageの将来の移転・更新は制御できない。
4. Markdownは表示先によってTable、Task list、MermaidのRendering差がある。正本Platformを決め、Release前にPreviewする。

# End of Validation Report
