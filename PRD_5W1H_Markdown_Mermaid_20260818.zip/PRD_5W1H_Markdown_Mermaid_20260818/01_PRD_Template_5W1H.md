---
title: "[プロダクト／機能名] Product Requirements Document"
version: "0.1.0"
status: "Draft"
owner: "[Product Manager / Product Owner]"
last_updated: "YYYY-MM-DD"
target_release: "YYYY-MM-DD または未定"
confidentiality: "[Public / Internal / Confidential]"
---

# [プロダクト／機能名] Product Requirements Document（PRD）

> **この文書の目的**  
> [誰の、どの問題を、なぜ今解くのか]、[何を提供するのか]、[どの状態を成功とするのか]を、実装・検証・リリース・効果測定まで追跡可能な形で合意する。
>
> **文書境界**  
> PRDは主として `Why / Who / What / 成功条件` を定義する。API詳細、データモデル、アルゴリズム、クラス設計、具体的なインフラ構築手順などの `How exactly` は、承認済みPRDを入力としてProduct Spec、Technical Spec、UX Spec、ADRへ記載する。

- 調査・レビュー基準日: [YYYY-MM-DD]
- PRDオーナー: [氏名・役割]
- 意思決定者: [氏名・役割]
- 対象読者: [経営／事業／PM／Design／Engineering／QA／Security／Legal／Operations／Support など]
- 関連イニシアチブ／OKR: [リンクまたはID]
- 詳細仕様の格納先: [リンク]

---

## 0. 記入規則と品質基準

### 0.1 要件記述ルール

1. 1つの要求文には原則として1つの振る舞いまたは品質条件だけを書く。
2. 主語、対象、条件、期待結果、例外を明示する。
3. 「高速」「簡単」「十分」「適切」「柔軟」「堅牢」など、測定不能な表現を単独で使わない。
4. 可能な限り、閾値、時間窓、対象母集団、測定方法、データソースを記載する。
5. 要件には一意なIDを付け、目的・ストーリー・受入基準・テスト・実装・リリース・KPIへ追跡できるようにする。
6. 実装方法を不必要に固定しない。技術制約が必要な場合は、理由と意思決定権者を記載する。
7. 未確定値は `TBR` とし、責任者、解消期限、解消方法、暫定値を明記する。
8. 成果指標と受入基準を混同しない。
   - **成果指標**: リリース後に価値・行動・事業成果が生じたかを測る。
   - **受入基準**: リリース前に要求どおり動くかを検証する。

### 0.2 ID体系

| 種別 | 形式 | 例 |
|---|---|---|
| 目的 | `OBJ-xxx` | `OBJ-001` |
| 成果指標／ガードレール | `KPI-xxx` / `GRD-xxx` | `KPI-001` |
| ユーザーストーリー | `US-xxx` | `US-001` |
| 機能要件 | `FR-xxx` | `FR-001` |
| 非機能要件 | `NFR-<分類>-xxx` | `NFR-PERF-001` |
| 受入基準 | `AC-xxx` | `AC-001` |
| テスト | `TC-xxx` | `TC-E2E-001` |
| リスク | `RISK-xxx` | `RISK-001` |
| 前提 | `ASM-xxx` | `ASM-001` |
| 未解決事項 | `OQ-xxx` / `TBR-xxx` | `OQ-001` |
| 意思決定 | `DEC-xxx` | `DEC-001` |

### 0.3 5W1H全体対応表

| 章 | 主に答える5W1H | 章で確定すること |
|---|---|---|
| 1. ドキュメント情報 | Who / When / Where / How | 誰が、いつ、どこで、どの版を管理・承認するか |
| 2. 製品概要 | Why / Who / What / When / Where / How | なぜ今、誰の何を、どの利用状況で、どんな方向性で解くか |
| 3. 目標と成果指標 | Why / What / When / How / Who | 何をいつまでに、誰が、どう測って成功とするか |
| 4. ターゲットユーザー | Who / When / Where / Why / How / What | 誰が、いつどこで、なぜ、どのように利用するか |
| 5. スコープ | What / When / Where / Why / Who / How | 今回何をどこまで含め、なぜ、誰が優先順位を決めるか |
| 6. ユースケース | Who / What / When / Where / Why / How | 利用者がどの状況で何をどう行い、どの価値を得るか |
| 7. 機能要件 | What / How / Who / When / Where / Why | システムが何を、どの条件・結果で提供するか |
| 8. 非機能要件 | How / What / When / Where / Who / Why | どの品質水準を、どの環境・条件で満たすか |
| 9. UI / UX | How / Who / What / When / Where / Why | 誰がどの画面・導線で、安全かつ理解可能に操作するか |
| 10. 技術概要 | Where / How / What / Who / Why / When | システム境界、主要連携、技術制約、詳細仕様の責任分界 |
| 11. QA戦略 | How / What / Who / When / Where / Why | 何を誰がどこでどう検証し、いつ合格とするか |
| 12. スケジュール | When / Who / What / How / Why / Where | 誰が何をいつまでに完了し、どのゲートで判断するか |
| 13. リスクと課題 | What / Why / When / Where / Who / How | 何がなぜ起こり得て、誰がどう監視・対処するか |
| 14. 承認フロー | Who / What / When / Where / How / Why | 誰が何をいつどの方法で承認し、なぜ権限を持つか |
| 15. 今後の拡張 | What / Why / When / Who / How / Where | 将来何を、どの条件で、誰が再評価するか |
| 16. 参考資料 | What / Where / Who / When / Why / How | 根拠資料をどこに置き、誰がどの版をどう参照するか |

---

# 1. ドキュメント情報（基本情報）

> **5W1H**: `Who` 作成・レビュー・承認者 / `What` 文書・変更内容 / `When` 作成・更新・承認日 / `Where` 正本の保管場所 / `Why` 最新仕様と責任を明確化 / `How` 版管理・変更管理・通知方法

## 1.1 基本メタデータ

| 項目 | 記入内容 |
|---|---|
| 文書タイトル | [名称] |
| 文書ID | [PRD-XXXX] |
| バージョン | [0.1.0] |
| ステータス | [Draft / In Review / Approved / Implementing / Released / Superseded] |
| オーナー | [氏名・役割] |
| 最終意思決定者 | [氏名・役割] |
| 作成日 | [YYYY-MM-DD] |
| 最終更新日 | [YYYY-MM-DD] |
| 承認日 | [YYYY-MM-DD / 未承認] |
| 対象リリース | [Release / Quarter / Date] |
| 機密区分 | [区分] |
| 正本URL | [Git / Docs / Wiki URL] |
| 関連Epic／Project | [ID・URL] |
| Product Spec | [URL / 未作成] |
| UX Spec | [URL / 未作成] |
| Architecture / ADR | [URL / 未作成] |
| Test Plan / RTM | [URL / 未作成] |

## 1.2 改訂履歴

| 版 | 日付 | 作成者 | 変更概要 | 影響する要件ID | レビュー／承認 |
|---|---|---|---|---|---|
| 0.1.0 | YYYY-MM-DD | [氏名] | 初版 | - | Draft |
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## 1.3 文書ステータス遷移

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> InReview: レビュー開始
    InReview --> Draft: 修正要求
    InReview --> Approved: 承認
    Approved --> Implementing: 開発開始
    Implementing --> Approved: 要件変更なし
    Implementing --> InReview: 重大な要件変更
    Approved --> Released: リリース完了
    Released --> Superseded: 後継版で置換
```

## 1.4 意思決定ログ

| ID | 日付 | 決定事項 | 選択肢 | 決定理由 | 決定者 | 影響範囲 | 再検討条件 |
|---|---|---|---|---|---|---|---|
| DEC-001 | [ ] | [ ] | [ ] | [ ] | [ ] | [要件ID] | [ ] |

---

# 2. 製品概要（Purpose / Background）

> **5W1H**: `Who` 対象ユーザー・影響者 / `What` 解決する問題と提供価値 / `When` 問題が生じる時・今取り組む理由 / `Where` 利用場所・チャネル・業務工程 / `Why` 顧客・事業・戦略上の必要性 / `How` 解決仮説と大まかなアプローチ

## 2.1 エグゼクティブサマリー

[3〜7文で、対象ユーザー、問題、現状影響、提案する能力、成功条件、対象リリースを記載する。機能一覧ではなく、意思決定に必要な要点を書く。]

## 2.2 問題定義

| 項目 | 記入内容 |
|---|---|
| 対象ユーザー | [誰が困っているか] |
| 現在の状況 | [現行フロー・代替手段・回避策] |
| 解決すべき問題 | [観察可能な問題を1〜3件] |
| 発生条件 | [いつ・どこで・どの頻度で] |
| ユーザーへの影響 | [時間、失敗、心理負荷、リスクなど] |
| 事業への影響 | [売上、コスト、継続率、リスクなど] |
| 根拠 | [調査、ログ、インタビュー、問い合わせ、規制など] |
| 問題を放置した場合 | [機会損失・リスク] |

## 2.3 根拠と信頼度

| Evidence ID | 根拠 | 種別 | 対象数／期間 | 示唆 | 限界・バイアス | 信頼度 |
|---|---|---|---|---|---|---|
| EVD-001 | [ ] | [定量 / 定性 / 規制 / 市場] | [ ] | [ ] | [ ] | [High / Medium / Low] |

## 2.4 Why Now（なぜ今か）

- [ユーザー環境・市場・技術・法規・契約・経営方針などの時間要因]
- [今着手しない場合の損失]
- [期限が恣意的でない根拠]

## 2.5 ビジョンと価値提案

**価値提案**  
[対象ユーザー] に対して、[プロダクト／能力] は [主要な価値] を提供する。[既存手段] と異なり、[差別化要因] により [望ましい成果] を実現する。

## 2.6 戦略との整合

| 戦略／OKR | 本PRDの寄与 | 寄与の測定方法 | オーナー |
|---|---|---|---|
| [ ] | [ ] | [ ] | [ ] |

## 2.7 解決仮説

> **仮説**: [対象ユーザー] に [能力／体験] を提供すれば、[行動変化] が起き、[成果指標] が [目標値] まで改善する。なぜなら [根拠・メカニズム] だからである。

| 仮説ID | 仮説 | 検証方法 | 成功条件 | 失敗時の判断 |
|---|---|---|---|---|
| HYP-001 | [ ] | [Prototype / Experiment / Pilot / Analytics] | [ ] | [Pivot / Stop / Re-scope] |

## 2.8 システム／業務コンテキスト

```mermaid
flowchart LR
    U1["Primary User"] --> P["Product / Capability"]
    U2["Secondary User"] --> P
    P --> S1["External System A"]
    P --> S2["External System B"]
    P --> O["Operations / Support"]
    P --> A["Analytics / Audit"]
```

## 2.9 制約・原則・非目標

| 種別 | 内容 | 理由 | 変更権限者 |
|---|---|---|---|
| 制約 | [予算、期日、法令、契約、既存基盤など] | [ ] | [ ] |
| 設計原則 | [例: Human-in-the-loop、Privacy by Design] | [ ] | [ ] |
| 非目標 | [今回解かない問題] | [ ] | [ ] |

## 2.10 用語集

| 用語 | 定義 | 非該当・注意点 |
|---|---|---|
| [ ] | [ ] | [ ] |

---

# 3. 目標と成果指標（Objectives / Success Metrics）

> **5W1H**: `Who` 指標オーナー・対象ユーザー / `What` 達成する成果と指標 / `When` 評価期限・観測窓 / `Where` 対象チャネル・セグメント / `Why` 事業・顧客価値との関係 / `How` 定義・計測・判定・意思決定方法

## 3.1 目的

| Objective ID | 目的 | 対象ユーザー／事業 | 戦略との関連 | 優先度 | オーナー |
|---|---|---|---|---|---|
| OBJ-001 | [成果を動詞で記載] | [ ] | [ ] | [Must / Should] | [ ] |

## 3.2 成果指標

| Metric ID | 指標名 | 種別 | 正式定義／式 | ベースライン | 目標 | 観測窓・期限 | 対象母集団 | データソース | オーナー | 判定後の行動 |
|---|---|---|---|---:|---:|---|---|---|---|---|
| KPI-001 | [ ] | [Primary / Leading / Lagging] | [分子・分母・除外条件] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| GRD-001 | [ ] | Guardrail | [悪化させてはいけない指標] | [ ] | [上限／下限] | [ ] | [ ] | [ ] | [ ] | [ ] |

### 指標記述チェック

- [ ] 機能を出したことではなく、ユーザーまたは事業の成果を測っている。
- [ ] ベースラインと目標値が同じ定義・母集団・時間窓で比較可能である。
- [ ] 平均だけでなく、必要に応じて中央値、分位点、失敗率、セグメント差を確認する。
- [ ] 指標悪化を防ぐガードレールを定義している。
- [ ] 計測不能・データ欠損時の扱いが決まっている。

## 3.3 計測イベント／データ要件

| Event ID | イベント名 | 発火条件 | 必須属性 | 禁止属性 | 保持期間 | KPIとの関係 | データ品質チェック |
|---|---|---|---|---|---|---|---|
| EVT-001 | [ ] | [ ] | [ ] | [PIIなど] | [ ] | [KPI-001] | [重複・欠損・遅延] |

## 3.4 成果の因果仮説

```mermaid
flowchart LR
    A["Product Capability"] --> B["User Behavior Change"]
    B --> C["User Outcome"]
    C --> D["Business Outcome"]
    A --> G["Guardrail Metrics"]
```

## 3.5 成功・保留・失敗の判定

| 判定 | 条件 | 意思決定 |
|---|---|---|
| Success | [Primary KPI達成かつGuardrail維持] | [拡大・標準化] |
| Inconclusive | [データ不足、信頼区間、観測期間不足] | [観測継続・追加検証] |
| Failure | [KPI未達またはGuardrail違反] | [停止・縮小・仮説変更] |

---

# 4. ターゲットユーザーとペルソナ

> **5W1H**: `Who` 利用者・購入者・管理者・影響者 / `What` JTBD・ニーズ・能力・制約 / `When` 利用契機・頻度 / `Where` 端末・場所・業務環境 / `Why` 利用理由・代替行動 / `How` 現行フロー・期待する操作・支援方法

## 4.1 ユーザー区分

| User ID | 区分 | 役割 | 主なJTBD | 利用頻度 | 利用場所／端末 | 権限 | 対象／非対象 | 根拠 |
|---|---|---|---|---|---|---|---|---|
| USER-001 | Primary | [ ] | [When..., I want..., so I can...] | [ ] | [ ] | [ ] | [ ] | [ ] |

## 4.2 ペルソナ

### Persona: [名称]

| 観点 | 内容 |
|---|---|
| 背景・責務 | [ ] |
| 目標 | [ ] |
| 現在の行動 | [ ] |
| 痛点 | [ ] |
| 利用トリガー | [ ] |
| 成功の定義 | [ ] |
| スキル／リテラシー | [ ] |
| アクセシビリティ上のニーズ | [ ] |
| 信頼・プライバシー上の懸念 | [ ] |
| 対象外条件 | [ ] |
| 根拠 | [実データ・調査] |

## 4.3 Jobs-to-be-Done

> **When** [状況]、**I want to** [進歩／タスク]、**so I can** [望む成果]。

| JTBD ID | 状況 | 望む進歩 | 現在の代替手段 | 障壁 | 成功条件 | 関連US |
|---|---|---|---|---|---|---|
| JTBD-001 | [ ] | [ ] | [ ] | [ ] | [ ] | [US-001] |

## 4.4 現状と将来のユーザージャーニー

```mermaid
flowchart LR
    A["Trigger"] --> B["Current Workaround"]
    B --> C["Pain / Delay / Risk"]
    C --> D["Use Product"]
    D --> E["Complete Task"]
    E --> F["Desired Outcome"]
```

## 4.5 調査上の不足

| OQ ID | 未確認事項 | 重要度 | 検証方法 | オーナー | 期限 | 解消しない場合の扱い |
|---|---|---|---|---|---|---|
| OQ-001 | [ ] | [High / Medium / Low] | [ ] | [ ] | [ ] | [ ] |

---

# 5. 製品スコープと機能一覧（Scope & Features）

> **5W1H**: `Who` スコープ決定者・対象ユーザー / `What` In・Out・Later / `When` 今回・次回・将来 / `Where` 対象チャネル・地域・組織・環境 / `Why` 優先順位とトレードオフ / `How` 分割、段階提供、変更管理

## 5.1 対象リリースの定義

| 項目 | 内容 |
|---|---|
| リリース名／ID | [ ] |
| リリース目的 | [達成する最小の成果] |
| 対象ユーザー | [ ] |
| 対象地域／チャネル／環境 | [ ] |
| 目標日 | [ ] |
| リリース方式 | [Pilot / Beta / GA / Feature Flag / Phased Rollout] |
| 成功判定 | [KPI / Gate] |

## 5.2 In Scope

| Scope ID | 能力／機能 | 対象ユーザー | 価値／関連目的 | 優先度 | 対象リリース | 関連US・FR | 備考 |
|---|---|---|---|---|---|---|---|
| SCP-001 | [ ] | [ ] | [OBJ-001] | [Must / Should / Could] | [ ] | [US-001 / FR-001] | [ ] |

## 5.3 Out of Scope

| Scope ID | 対象外項目 | 対象外の理由 | 誤解しやすい境界 | 再検討条件 | 想定時期 |
|---|---|---|---|---|---|
| OOS-001 | [ ] | [価値、費用、リスク、依存関係] | [ ] | [ ] | [ ] |

## 5.4 優先順位とトレードオフ

| 優先するもの | 劣後を許容するもの | 判断理由 | 承認者 |
|---|---|---|---|
| [例: データ正確性] | [例: 高度な可視化] | [ ] | [ ] |

### 優先順位規則

- **Must**: ないと目的未達、法令・契約違反、重大リスク、またはリリース不能。
- **Should**: 価値は高いが、一時的な代替策がある。
- **Could**: 余力があれば実施。なくても主要成果を損なわない。
- **Won't this time**: 明示的に今回対象外。将来を約束する表現ではない。

## 5.5 段階提供

```mermaid
flowchart LR
    R0["Prototype / Discovery"] --> R1["Pilot: Minimum Outcome"]
    R1 --> R2["Beta: Broader Coverage"]
    R2 --> R3["GA: Operational Scale"]
    R3 --> R4["Optimization"]
```

| Slice | 目的 | 含むScope ID | 対象ユーザー | Entry条件 | Exit条件 |
|---|---|---|---|---|---|
| R1 | [ ] | [ ] | [ ] | [ ] | [ ] |

## 5.6 スコープ変更規則

- Mustの追加・削除、Primary KPI、法規・安全・セキュリティ水準、対象ユーザー、リリース方式の変更は、PRD再レビュー対象とする。
- 誤記修正や要件を変えない表現改善は、軽微変更として履歴のみ残す。
- 変更要求には、価値、工数、リスク、日程、既存要件への影響を添付する。

---

# 6. ユースケース / ユーザーストーリー

> **5W1H**: `Who` アクター / `What` 目的・操作・結果 / `When` トリガー・事前条件 / `Where` チャネル・画面・業務工程 / `Why` 得たい価値 / `How` 基本フロー・代替フロー・例外・受入基準

## 6.1 ユーザーストーリー一覧

| US ID | ユーザーストーリー | JTBD | 優先度 | 前提条件 | 主要AC | 関連FR | 状態 |
|---|---|---|---|---|---|---|---|
| US-001 | [As a `<user>`, I want `<goal>`, so that `<benefit>`.] | [JTBD-001] | [Must] | [ ] | [AC-001] | [FR-001] | [Draft] |

> ユーザーストーリーは、短いカードだけで完結させず、会話による明確化と、確認可能な受入基準を組み合わせる。

## 6.2 ユースケース詳細

### UC-[XXX]: [ユースケース名]

| 項目 | 内容 |
|---|---|
| 主アクター | [ ] |
| 副アクター／外部システム | [ ] |
| 目的 | [ ] |
| トリガー | [ ] |
| 事前条件 | [ ] |
| 事後条件 | [ ] |
| 頻度・規模 | [ ] |
| 関連US／FR | [ ] |

**基本フロー**

1. [ ]
2. [ ]
3. [ ]

**代替フロー**

- A1. [ ]

**例外・失敗フロー**

- E1. [権限不足、競合、入力不正、外部障害など]

**乱用・誤操作シナリオ**

- [大量操作、重複送信、誤削除、権限逸脱など]

## 6.3 ユーザーフロー

```mermaid
flowchart TD
    A["Trigger"] --> B["Open Product"]
    B --> C{"Authorized?"}
    C -->|No| D["Explain and Recover"]
    C -->|Yes| E["Perform Task"]
    E --> F{"Valid Input?"}
    F -->|No| G["Show Actionable Error"]
    G --> E
    F -->|Yes| H["Persist / Execute"]
    H --> I["Confirm Result"]
    I --> J["Measure Event"]
```

## 6.4 受入基準（Given / When / Then）

| AC ID | 関連US／FR | Given | When | Then | 例外／境界値 | 検証方法 | 自動化 |
|---|---|---|---|---|---|---|---|
| AC-001 | US-001 / FR-001 | [前提] | [操作] | [観察可能な結果] | [ ] | [Test / Inspection / Analysis / Demonstration] | [Yes / No] |

```gherkin
Feature: [能力名]

  Scenario: [正常系シナリオ]
    Given [前提条件]
    When [アクション]
    Then [観察可能な結果]

  Scenario: [境界／例外シナリオ]
    Given [前提条件]
    When [アクション]
    Then [安全で理解可能な失敗結果]
```

## 6.5 シーケンス概要

> 実装方式ではなく、アクターとシステム境界間で観察できる振る舞いを示す。API名や内部コンポーネントを固定する必要がある場合は、10章またはProduct Specへリンクする。

```mermaid
sequenceDiagram
    actor User
    participant UI as Product UI
    participant Core as Product Service
    participant Ext as External Dependency
    User->>UI: Request action
    UI->>Core: Submit validated intent
    Core->>Ext: Optional dependency call
    alt Success
        Ext-->>Core: Success
        Core-->>UI: Confirmed result
        UI-->>User: Success feedback
    else Recoverable failure
        Ext-->>Core: Error / timeout
        Core-->>UI: Safe failure + recovery option
        UI-->>User: Actionable guidance
    end
```

---

# 7. 機能要件（Functional Requirements）

> **5W1H**: `Who` 利用者・権限・担当者 / `What` 必須の振る舞い / `When` 発火条件・時間順序 / `Where` チャネル・境界・対象データ / `Why` 根拠・上位目的 / `How` 入力、処理結果、エラー、検証方法。ただし不必要な実装固定は避ける

## 7.1 機能要件一覧

| FR ID | 要求文 | 対象ユーザー | 条件／トリガー | 期待結果 | 理由・根拠 | 優先度 | 関連OBJ／US | AC | 依存関係 | 状態 |
|---|---|---|---|---|---|---|---|---|---|---|
| FR-001 | システムは、[条件]において[対象]が[観察可能な結果]を得られるようにする。 | [ ] | [ ] | [ ] | [EVD/HYP] | [Must] | [OBJ-001 / US-001] | [AC-001] | [ ] | [Draft] |

## 7.2 要件詳細テンプレート

### FR-[XXX]: [短い名称]

| 属性 | 内容 |
|---|---|
| 要求文 | システムは、[条件]において、[主体]に対し、[振る舞い／結果]を提供しなければならない。 |
| ユーザー価値 | [ ] |
| 根拠／出典 | [EVD-xxx / 法令 / 契約 / 上位要件] |
| 対象ユーザー／権限 | [ ] |
| 入力 | [意味、単位、範囲。UI部品ではなく情報として記載] |
| 処理上のビジネスルール | [ ] |
| 出力／事後条件 | [観察可能な結果] |
| エラー／回復 | [失敗時に何を保持し、利用者がどう回復できるか] |
| 境界値／例外 | [0、最大、空、重複、競合、タイムアウトなど] |
| データ・監査 | [作成・更新・閲覧記録、保持、機微性] |
| 計測イベント | [EVT-xxx] |
| 依存関係 | [外部システム、他チーム、別要件] |
| 受入基準 | [AC-xxx] |
| 検証方法 | [Test / Analysis / Inspection / Demonstration] |
| Product Specリンク | [ ] |
| オーナー | [ ] |
| 状態 | [Draft / Approved / Implemented / Verified / Deprecated] |

## 7.3 権限マトリクス

| 操作／データ | Role A | Role B | Role C | 条件・例外 | 監査要件 |
|---|---:|---:|---:|---|---|
| [閲覧] | Allow | Allow | Deny | [ ] | [ ] |
| [更新] | Allow | Deny | Deny | [ ] | [ ] |

## 7.4 ビジネスルール

| Rule ID | ルール | 適用条件 | 優先順位／競合時 | 根拠 | 関連FR／AC |
|---|---|---|---|---|---|
| BR-001 | [ ] | [ ] | [ ] | [ ] | [ ] |

## 7.5 状態遷移

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> Submitted: submit
    Submitted --> Approved: approve
    Submitted --> Rejected: reject
    Rejected --> Draft: revise
    Approved --> Archived: archive
    Archived --> [*]
```

## 7.6 要件品質セルフチェック

- [ ] 一意のIDがある。
- [ ] 1要求1意図である。
- [ ] 主語、条件、結果が明確である。
- [ ] 実装方法ではなく必要な能力・結果を記載している。
- [ ] 曖昧語、無限定な「など」、`and/or`、二重否定を避けている。
- [ ] 根拠と上位目的へ追跡できる。
- [ ] 受入基準と検証方法がある。
- [ ] 境界値、失敗、競合、権限、監査を検討した。
- [ ] 他要件と矛盾しない。
- [ ] 技術的・運用的に実現可能である。

---

# 8. 非機能要件（Non-Functional Requirements）

> **5W1H**: `Who` 品質の受益者・責任者 / `What` 必須の品質特性・閾値 / `When` 平常、ピーク、障害、保守、災害時 / `Where` 本番、端末、地域、ネットワーク、外部境界 / `Why` 顧客価値・法令・リスク / `How` 測定、監視、検証、復旧、例外承認

## 8.1 品質特性の選定

> 以下はISO/IEC 25010:2023の9特性を漏れ確認の軸として使う。すべてを同じ深さで要求するのではなく、プロダクトのリスクと価値に応じて優先度と測定方法を定める。

| 品質特性 | この製品での重要性 | 具体的な品質目標 | 関連NFR | オーナー |
|---|---|---|---|---|
| 機能適合性 | [High/Med/Low] | [完全性、正確性、適切性] | [ ] | [ ] |
| 性能効率性 | [ ] | [応答時間、スループット、容量、資源効率] | [ ] | [ ] |
| 互換性 | [ ] | [共存性、相互運用性] | [ ] | [ ] |
| インタラクション能力 | [ ] | [学習容易性、操作性、誤操作防止、アクセシビリティ] | [ ] | [ ] |
| 信頼性 | [ ] | [可用性、無故障性、耐障害性、回復性] | [ ] | [ ] |
| セキュリティ | [ ] | [機密性、完全性、真正性、責任追跡、耐攻撃性] | [ ] | [ ] |
| 保守性 | [ ] | [モジュール性、解析性、修正性、試験性] | [ ] | [ ] |
| 柔軟性 | [ ] | [適応性、拡張性、導入・置換性、スケーラビリティ] | [ ] | [ ] |
| 安全性 | [ ] | [危害・損失の回避、フェイルセーフ] | [ ] | [ ] |

## 8.2 非機能要件一覧

| NFR ID | 分類 | 要求・SLI | 目標／SLO | 条件・対象範囲 | 測定方法 | 観測窓 | 例外 | オーナー | AC／TC |
|---|---|---|---|---|---|---|---|---|---|
| NFR-PERF-001 | Performance | [例: 操作完了時間のp95] | [閾値] | [負荷・データ量・地域] | [Tool / Query] | [ ] | [ ] | [ ] | [ ] |
| NFR-REL-001 | Reliability | [可用性] | [99.x%] | [除外条件] | [ ] | [月次] | [ ] | [ ] | [ ] |
| NFR-SEC-001 | Security | [認証・認可・暗号・監査] | [基準] | [ ] | [Security Test] | [Release] | [ ] | [ ] | [ ] |
| NFR-UX-001 | Interaction | [アクセシビリティ／操作性] | [WCAG 2.2 AA等] | [対象画面] | [自動＋手動] | [Release] | [ ] | [ ] | [ ] |

## 8.3 性能・容量

| シナリオ | SLI | 目標 | 負荷条件 | データ条件 | 測定地点 | 失敗時の縮退 |
|---|---|---|---|---|---|---|
| [通常閲覧] | [p50/p95/p99] | [ ] | [同時数、RPS] | [件数] | [Client/API] | [ ] |

## 8.4 信頼性・可用性・復旧

| 項目 | 要求 | 測定・検証 | オーナー |
|---|---|---|---|
| 可用性 | [SLO、計画停止の扱い] | [ ] | [ ] |
| RTO | [ ] | [演習] | [ ] |
| RPO | [ ] | [復元試験] | [ ] |
| バックアップ | [頻度、暗号化、保持、復元確認] | [ ] | [ ] |
| 障害時動作 | [Fail-open / Fail-closed / Read-only / Queue] | [ ] | [ ] |
| データ整合性 | [重複、順序、競合、冪等性] | [ ] | [ ] |

## 8.5 セキュリティ

| 領域 | 要求 | 参照基準 | 検証 | 例外承認 |
|---|---|---|---|---|
| 認証 | [ ] | [OWASP ASVS等] | [ ] | [ ] |
| 認可 | [最小権限、テナント分離] | [ ] | [ ] | [ ] |
| データ保護 | [転送時・保存時、鍵管理] | [ ] | [ ] | [ ] |
| 入力・出力 | [検証、エンコード、ファイル処理] | [ ] | [ ] | [ ] |
| 監査 | [対象イベント、改ざん耐性、保持] | [ ] | [ ] | [ ] |
| 脆弱性管理 | [SCA/SAST/DAST、修正SLA] | [NIST SSDF等] | [ ] | [ ] |
| インシデント | [検知、連絡、封じ込め、証跡] | [ ] | [演習] | [ ] |

## 8.6 プライバシー・データガバナンス

| Data ID | データ要素 | 分類 | 収集目的 | 法的根拠／同意 | 最小化 | 保持・削除 | アクセス主体 | 越境／第三者 | 監査 |
|---|---|---|---|---|---|---|---|---|---|
| DATA-001 | [ ] | [Public/Internal/Confidential/PII] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

- [ ] 目的外利用を禁止し、収集しない属性を明示した。
- [ ] データ主体の開示・訂正・削除・同意撤回が必要か確認した。
- [ ] 分析イベントへ機微情報を直接送信しない。
- [ ] テストデータと本番データの境界を定義した。

## 8.7 アクセシビリティ・国際化

| 項目 | 要求 | 対象 | 検証方法 |
|---|---|---|---|
| WCAG | [例: WCAG 2.2 Level AA] | [Web画面] | [自動＋キーボード＋スクリーンリーダー] |
| キーボード | [全主要操作] | [ ] | [手動] |
| フォーカス | [可視・遮蔽されない] | [ ] | [手動] |
| 色・コントラスト | [ ] | [ ] | [自動＋手動] |
| エラー | [テキストで原因と回復方法] | [ ] | [E2E/UAT] |
| 言語・日時・通貨 | [locale、timezone、format] | [ ] | [ ] |

## 8.8 観測可能性・運用性

| 種別 | 必須項目 | SLO／保持 | アラート条件 | 利用者 |
|---|---|---|---|---|
| Logs | [相関ID、監査、機微情報除外] | [ ] | [ ] | [Ops/Sec] |
| Metrics | [SLI、業務イベント] | [ ] | [ ] | [Product/Ops] |
| Traces | [主要経路] | [ ] | [ ] | [Engineering] |
| Runbook | [障害、復旧、ロールバック] | [最新版] | - | [Ops/Support] |

## 8.9 安全性・高影響判断（該当時）

| Hazard ID | 危害／損失 | 原因 | 影響 | 安全要件 | 検知 | フェイルセーフ | 残余リスク承認 |
|---|---|---|---|---|---|---|---|
| HAZ-001 | [ ] | [ ] | [ ] | [NFR-SAFE-001] | [ ] | [ ] | [ ] |

---

# 9. UIデザイン / モックアップ

> **5W1H**: `Who` 利用者・支援者 / `What` 画面・情報・操作 / `When` タスク中の各状態 / `Where` 端末・画面・環境 / `Why` 理解・効率・信頼・誤操作防止 / `How` 情報設計、導線、フィードバック、アクセシビリティ

## 9.1 UX原則

1. [例: 主要タスクを最短経路で完了できる]
2. [例: システム状態と処理結果を常に理解できる]
3. [例: 破壊的操作は予防・確認・復旧を備える]
4. [例: 色だけに依存せず、キーボードと支援技術で操作できる]

## 9.2 画面一覧

| Screen ID | 画面／状態 | 対象ユーザー | 主要目的 | 主操作 | 必須状態 | 関連US／FR | Design URL |
|---|---|---|---|---|---|---|---|
| SCR-001 | [ ] | [ ] | [ ] | [ ] | [Loading / Empty / Error / Success / Disabled] | [ ] | [ ] |

## 9.3 情報アーキテクチャ

```mermaid
flowchart TD
    HOME["Home / Dashboard"] --> A["Primary Area A"]
    HOME --> B["Primary Area B"]
    A --> A1["List"]
    A1 --> A2["Detail"]
    A2 --> A3["Create / Edit"]
    HOME --> HELP["Help / Support"]
```

## 9.4 主要画面の仕様

### SCR-[XXX]: [画面名]

| 観点 | 内容 |
|---|---|
| 目的 | [ ] |
| 対象ユーザー | [ ] |
| 進入条件 | [ ] |
| 表示情報 | [優先順位、単位、鮮度] |
| 主操作 | [ ] |
| 権限差 | [ ] |
| Loading | [ ] |
| Empty | [ ] |
| Error | [原因、影響、回復手段] |
| Success | [ ] |
| 確認／取消／Undo | [ ] |
| キーボード／Focus | [ ] |
| 読み上げ／ラベル | [ ] |
| レスポンシブ | [最小幅、主要端末] |
| Analytics | [EVT-xxx] |

## 9.5 コンテンツ・マイクロコピー

| Message ID | 場面 | メッセージ | 禁止表現／注意 | ローカライズ |
|---|---|---|---|---|
| MSG-001 | [Error] | [何が起き、何が保持され、次に何をすべきか] | [責任転嫁・内部コードのみ] | [Yes/No] |

## 9.6 プロトタイプ／モックアップ

- Low-fidelity: [URL]
- High-fidelity: [URL]
- Prototype: [URL]
- Design System: [URL]
- UX Research / Usability Test: [URL]

> Mermaid図だけを唯一のUI仕様としない。画面状態、アクセシビリティ、文言、権限差、失敗時挙動は表またはUX Specに記録する。

---

# 10. 技術スタック / アーキテクチャ概要

> **5W1H**: `Who` 技術・運用・セキュリティ責任者 / `What` システム境界、主要能力、データ、外部連携 / `When` 実行時・同期・非同期・障害時 / `Where` クライアント、クラウド、地域、信頼境界 / `Why` 制約・品質・既存資産との整合 / `How` 高位構成と責任分界。詳細実装はProduct Spec・ADRへ委譲

## 10.1 PRDに記載する技術情報の範囲

**記載する**

- システムの内外、信頼境界、主要アクター、外部依存関係
- 契約・法規・既存基盤など、選択肢を制約する事項
- 主要データ区分、データ所在、同期／非同期などプロダクト挙動に影響する事項
- 必須の相互運用性、移行・互換性、運用責任

**詳細仕様へ委譲する**

- APIエンドポイント、スキーマ、クラス、関数、テーブルDDL
- 具体的なクラウドリソース、ネットワーク設定、IaC手順
- アルゴリズム、内部状態機械、キャッシュ・キューの実装詳細
- コンポーネント別テストコード、デプロイ手順

## 10.2 システムコンテキスト

```mermaid
flowchart LR
    U["Users"] --> C["Client / Channel"]
    C --> P["Product Boundary"]
    P --> IDP["Identity Provider"]
    P --> D[("Product Data")]
    P --> E["External System"]
    P --> N["Notification / Messaging"]
    P --> O["Observability / Audit"]
    OPS["Operations / Support"] --> O
```

## 10.3 システム境界と責任分界

| Component / System | In / External | 責務 | オーナー | 入出力 | 可用性依存 | データ分類 | 契約／SLA |
|---|---|---|---|---|---|---|---|
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## 10.4 技術制約

| Constraint ID | 制約 | 種別 | 根拠 | 影響 | 例外権限 | ADR |
|---|---|---|---|---|---|---|
| CON-001 | [ ] | [契約 / 法規 / 既存基盤 / スキル / 費用] | [ ] | [ ] | [ ] | [ ] |

## 10.5 主要インターフェース

| IF ID | 相手 | 目的 | 方向 | データ | 頻度／規模 | 失敗時挙動 | セキュリティ | オーナー | Spec |
|---|---|---|---|---|---|---|---|---|---|
| IF-001 | [ ] | [ ] | [Inbound / Outbound / Both] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## 10.6 データフローと信頼境界

```mermaid
flowchart LR
    subgraph Public["Untrusted / Public"]
        U["User Device"]
    end
    subgraph Trusted["Trusted Product Boundary"]
        APP["Application"]
        DB[("Primary Data")]
        AUDIT[("Audit Store")]
    end
    subgraph ThirdParty["Third-party Boundary"]
        EXT["External Service"]
    end
    U -->|"Authenticated request"| APP
    APP --> DB
    APP --> AUDIT
    APP -->|"Minimized data"| EXT
```

## 10.7 参照仕様

- Product Spec: [URL]
- API / Interface Spec: [URL]
- Data Model / Data Contract: [URL]
- Threat Model: [URL]
- Privacy Impact Assessment: [URL]
- Architecture Decision Records: [URL]
- Runbook / SRE Spec: [URL]

---

# 11. テスト計画 / QA戦略

> **5W1H**: `Who` 開発、QA、Security、Design、業務受入者 / `What` 要件、品質、互換性、失敗・回復 / `When` PR、CI、統合、リリース前、リリース後 / `Where` ローカル、CI、ステージング、本番カナリア / `Why` 品質・安全・契約・顧客信頼 / `How` 自動・手動テスト、分析、検査、実証、RTM、リリースゲート

## 11.1 品質戦略

[リスクベースのテスト方針、品質責任、シフトレフト／本番検証、テスト自動化の境界を記載する。]

## 11.2 テストレベルと責任

| Test ID / Level | 対象 | 主な目的 | 実施者 | 環境 | 自動化 | Entry条件 | Exit条件 | 証跡 |
|---|---|---|---|---|---|---|---|---|
| Unit | [Business rule] | [ ] | Engineering | CI | [ ] | [ ] | [ ] | [ ] |
| Contract | [Interface] | [ ] | Engineering | CI | [ ] | [ ] | [ ] | [ ] |
| Integration | [Systems] | [ ] | Eng / QA | Staging | [ ] | [ ] | [ ] | [ ] |
| E2E | [User journey] | [ ] | QA | Staging | [ ] | [ ] | [ ] | [ ] |
| Performance | [NFR] | [ ] | Eng / SRE | Perf env | [ ] | [ ] | [ ] | [ ] |
| Security | [ASVS / Threat] | [ ] | Security | CI / Staging | [ ] | [ ] | [ ] | [ ] |
| Accessibility | [WCAG] | [ ] | Design / QA | Staging | Mixed | [ ] | [ ] | [ ] |
| UAT | [Business outcomes] | [ ] | Business users | Pilot | Manual | [ ] | [ ] | [ ] |
| Production verification | [SLI / smoke] | [ ] | SRE / Product | Canary | [ ] | [ ] | [ ] | [ ] |

## 11.3 要求トレーサビリティマトリクス（RTM）

| Objective | User Story | Requirement | Acceptance Criteria | Test Case | Code / PR | Defect | Release | KPI |
|---|---|---|---|---|---|---|---|---|
| OBJ-001 | US-001 | FR-001 | AC-001 | TC-E2E-001 | [ ] | [ ] | [ ] | KPI-001 |

```mermaid
flowchart LR
    OBJ["Objective"] --> US["User Story"]
    US --> REQ["FR / NFR"]
    REQ --> AC["Acceptance Criteria"]
    AC --> TC["Test Case"]
    TC --> CODE["Code / PR"]
    CODE --> REL["Release"]
    REL --> KPI["Outcome Metric"]
    BUG["Defect"] --> REQ
    BUG --> TC
```

## 11.4 テストデータ

| Data Set | 目的 | 生成方法 | PII使用 | マスキング | リセット | オーナー |
|---|---|---|---|---|---|---|
| [ ] | [ ] | [Synthetic / Masked / Fixture] | [No preferred] | [ ] | [ ] | [ ] |

## 11.5 欠陥重大度

| Severity | 定義 | 例 | リリース可否 | 修正目標 |
|---|---|---|---|---|
| Sev-1 | 安全、重大な情報漏えい、全体停止、不可逆データ損失 | [ ] | 不可 | 即時 |
| Sev-2 | 主要経路が利用不能、広範な誤結果、代替策なし | [ ] | 原則不可 | [ ] |
| Sev-3 | 一部機能不良、回避策あり | [ ] | 条件付き | [ ] |
| Sev-4 | 軽微な表示・文言 | [ ] | 可 | [ ] |

## 11.6 リリース品質ゲート

- [ ] Must要件の受入基準がすべてPass。
- [ ] CriticalなNFRが目標値を満たす。
- [ ] 未検証要件、テスト未紐付け要件が0件、または例外承認済み。
- [ ] Sev-1 / Sev-2が0件。
- [ ] セキュリティ・プライバシー・アクセシビリティの必須レビュー完了。
- [ ] 監視、アラート、Runbook、バックアップ、ロールバックを検証済み。
- [ ] AnalyticsイベントとKPI集計を検証済み。
- [ ] UATおよび最終承認完了。

---

# 12. スケジュール / マイルストーン

> **5W1H**: `Who` オーナー・参加チーム / `What` 成果物・ゲート / `When` 開始、完了、期限 / `Where` 実施環境・対象市場 / `Why` 順序・期限の根拠 / `How` 依存関係、段階提供、判断条件

## 12.1 マイルストーン

| Milestone ID | マイルストーン | 成果物 | オーナー | 開始 | 目標日 | Entry条件 | 完了条件 | 依存関係 | 状態 |
|---|---|---|---|---|---|---|---|---|---|
| MS-001 | Problem validation | [Evidence / Brief] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| MS-002 | PRD approval | [Approved PRD] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| MS-003 | Product Spec ready | [Spec / Design / ADR] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| MS-004 | Pilot | [Pilot release] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| MS-005 | GA decision | [Decision record] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## 12.2 高位ロードマップ

```mermaid
gantt
    title Product Delivery Milestones
    dateFormat  YYYY-MM-DD
    axisFormat  %Y-%m-%d
    section Discovery
    Evidence and problem validation :d1, 2026-01-01, 14d
    PRD review                    :d2, after d1, 10d
    section Specification
    UX and Product Spec           :s1, after d2, 15d
    section Delivery
    Build and verification        :b1, after s1, 30d
    Pilot                         :p1, after b1, 14d
    GA decision                   :milestone, g1, after p1, 0d
```

> 上記日付はひな形。実際の計画へ置換する。タスク単位の詳細はProject Planまたはバックログで管理し、PRDには意思決定に必要なマイルストーンと完了条件だけを残す。

## 12.3 クリティカル依存関係

| Dependency ID | 依存先 | 必要な成果 | 必要日 | オーナー | 状態 | 遅延時の影響 | 代替案 |
|---|---|---|---|---|---|---|---|
| DEP-001 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## 12.4 日程の信頼度

| 項目 | 内容 |
|---|---|
| 見積もり方法 | [類似実績 / Bottom-up / Range] |
| 信頼区間 | [例: P50 / P80] |
| 最大の不確実性 | [ ] |
| バッファ方針 | [ ] |
| 再見積もり条件 | [ ] |

---

# 13. リスクと課題（Risks & Issues）/ 想定される障壁

> **5W1H**: `Who` リスクオーナー・影響者 / `What` リスク、課題、前提、依存、未解決事項 / `When` 発生時期・監視頻度 / `Where` 技術、業務、組織、外部連携 / `Why` 発生原因・前提 / `How` 回避、低減、移転、受容、コンティンジェンシー

## 13.1 リスク登録簿

| Risk ID | リスク事象 | 原因 | 影響 | 確率(1-5) | 影響度(1-5) | Score | 兆候 | 対応方針 | 予防策 | 発生時対応 | オーナー | 期限 | 残余リスク |
|---|---|---|---|---:|---:|---:|---|---|---|---|---|---|---|
| RISK-001 | [もしXならYが起きる] | [ ] | [ ] | [ ] | [ ] | [P×I] | [ ] | [Avoid/Reduce/Transfer/Accept] | [ ] | [ ] | [ ] | [ ] | [ ] |

## 13.2 前提条件

| Assumption ID | 前提 | 根拠 | 信頼度 | 検証方法 | オーナー | 期限 | 誤りだった場合の影響 |
|---|---|---|---|---|---|---|---|
| ASM-001 | [ ] | [ ] | [High/Med/Low] | [ ] | [ ] | [ ] | [ ] |

## 13.3 課題・障害

| Issue ID | 現在発生している課題 | 影響 | 暫定対応 | 恒久対応 | オーナー | 期限 | 状態 |
|---|---|---|---|---|---|---|---|
| ISSUE-001 | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## 13.4 未解決事項／TBR

| ID | 未解決事項／暫定値 | 暫定判断 | 解消方法 | 意思決定者 | オーナー | 期限 | ブロック対象 | 状態 |
|---|---|---|---|---|---|---|---|---|
| TBR-001 | [ ] | [ ] | [調査／実験／法務確認] | [ ] | [ ] | [ ] | [要件／マイルストーン] | [Open] |

## 13.5 リスクヒートマップの読み方

```mermaid
flowchart LR
    A["Identify"] --> B["Assess Probability and Impact"]
    B --> C{"Above Tolerance?"}
    C -->|Yes| D["Mitigate / Avoid / Transfer"]
    C -->|No| E["Accept and Monitor"]
    D --> F["Assign Owner and Trigger"]
    E --> F
    F --> G["Review on Cadence"]
```

---

# 14. 承認フロー / ステークホルダー

> **5W1H**: `Who` Responsible・Accountable・Consulted・Informed / `What` 承認対象・権限範囲 / `When` レビュー・ゲート・変更時 / `Where` 会議・リポジトリ・電子承認 / `Why` 責任・統制・手戻り防止 / `How` レビュー、異議処理、承認証跡、変更管理

## 14.1 ステークホルダー一覧

| Stakeholder | 役割 | 関心・成功条件 | 意思決定権 | 必要情報 | 参加タイミング | 連絡方法 |
|---|---|---|---|---|---|---|
| [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## 14.2 RACI

| 成果物／判断 | Product | Business | Design | Engineering | QA | Security | Legal/Privacy | Operations | Executive |
|---|---|---|---|---|---|---|---|---|---|
| Problem / Outcome | A/R | C | C | C | I | I | I | I | C |
| PRD | A/R | C | C | C | C | C | C | C | I |
| Product Spec | C | I | R | A/R | C | C | I | C | I |
| Release Gate | A | C | C | R | R | R | C | R | I |
| GA decision | R | C | C | C | C | C | C | C | A |

> `R`: Responsible、`A`: Accountable、`C`: Consulted、`I`: Informed。組織実態に合わせて置換する。

## 14.3 承認マトリクス

| Gate | 承認対象 | 必須レビュー | 承認者 | 完了条件 | 証跡 | 期限 |
|---|---|---|---|---|---|---|
| G1 | PRD | Product / Eng / Design / QA / Business | [ ] | [ ] | [PR / e-sign] | [ ] |
| G2 | Security & Privacy | Security / Privacy | [ ] | [ ] | [ ] | [ ] |
| G3 | Release | Product / QA / Ops | [ ] | [ ] | [ ] | [ ] |
| G4 | GA | Business / Product | [ ] | [KPI初期・運用準備] | [DEC-xxx] | [ ] |

## 14.4 レビューと異議処理

1. レビューコメントは、`Blocking / Major / Minor / Question` に分類する。
2. Blockingは、要件ID、根拠、影響、代案を添える。
3. 合意できない場合は、最終意思決定者が選択肢と理由を `DEC-xxx` に記録する。
4. 承認後の重大変更は、影響分析と再承認を必要とする。

## 14.5 署名／承認記録

| 役割 | 氏名 | 判断 | 日付 | 条件・コメント | 証跡URL |
|---|---|---|---|---|---|
| Product | [ ] | [Approve / Reject / Conditional] | [ ] | [ ] | [ ] |
| Engineering | [ ] | [ ] | [ ] | [ ] | [ ] |
| QA | [ ] | [ ] | [ ] | [ ] | [ ] |
| Business | [ ] | [ ] | [ ] | [ ] | [ ] |

---

# 15. 今後の拡張（Future Enhancements）

> **5W1H**: `Who` 将来の対象ユーザー・評価者 / `What` 機会・能力候補 / `When` 再評価時期・トリガー / `Where` 対象市場・チャネル・システム / `Why` 潜在価値・戦略 / `How` 検証方法・昇格条件。ただしリリース約束にはしない

## 15.1 Opportunity Backlog

| Opportunity ID | 将来機会 | 対象ユーザー | 想定価値 | 根拠 | 現時点で対象外の理由 | 再評価トリガー | 検証方法 | 想定依存 |
|---|---|---|---|---|---|---|---|---|
| FUT-001 | [ ] | [ ] | [ ] | [ ] | [ ] | [KPI / 顧客数 / 規制 / 技術] | [ ] | [ ] |

## 15.2 将来像

```mermaid
flowchart LR
    NOW["Current Release"] --> N1["Validated Next Opportunity"]
    N1 --> N2["Scale / Integration"]
    N2 --> N3["Optimization / Intelligence"]
    N3 --> V["Long-term Product Vision"]
```

## 15.3 設計上の先行配慮

| 将来可能性 | 現行設計で守る境界 | 今は実装しないもの | 過剰設計を防ぐ条件 |
|---|---|---|---|
| [ ] | [API境界、データ所有など] | [ ] | [需要確認前は実装しない] |

> Future Enhancementsはコミットメントではない。価値、根拠、機会費用を改めて評価し、必要なら新しいProduct Brief／PRDを作成する。

---

# 16. 参考資料 / 添付文書

> **5W1H**: `Who` 作成者・所有者・利用者 / `What` 根拠・関連仕様・規格 / `When` 取得日・対象期間・版 / `Where` 正本URL・保管場所 / `Why` 意思決定と要件の根拠 / `How` 引用、版固定、アクセス権、更新確認

## 16.1 Evidence Catalog

| Ref ID | 資料名 | 種別 | 所有者／発行元 | 日付／版 | URL／保管場所 | 使用箇所 | 信頼度 | 制約 |
|---|---|---|---|---|---|---|---|---|
| REF-001 | [ ] | [Research / Log / Standard / Contract / Design] | [ ] | [ ] | [ ] | [EVD/FR/NFR] | [ ] | [機密・ライセンス] |

## 16.2 関連成果物

- Product Brief: [URL]
- User Research: [URL]
- Market / Competitive Analysis: [URL]
- UX / Prototype: [URL]
- Product Spec: [URL]
- Technical Spec / ADR: [URL]
- Data Contract / API Spec: [URL]
- Threat Model / Security Review: [URL]
- Privacy Review / DPIA: [URL]
- Test Plan / RTM / Test Report: [URL]
- Runbook / Support Guide: [URL]
- Release Notes / Post-launch Review: [URL]

## 16.3 公式資料・標準の参照候補

- ISO/IEC/IEEE 29148:2018 — Requirements engineering
- ISO/IEC 25010:2023 — Product quality model
- W3C WCAG 2.2 — Web accessibility
- OWASP ASVS 5.0.0 — Web application security verification
- NIST SP 800-218 — Secure Software Development Framework
- NIST Privacy Framework — Privacy risk management

---

# Appendix A. PRD Ready Checklist

## A.1 Problem / Outcome

- [ ] 対象ユーザーと問題が、解決策から独立して説明されている。
- [ ] 問題の根拠と限界が記録されている。
- [ ] Why Nowと戦略上の関係が明確である。
- [ ] Primary KPI、ベースライン、目標、観測窓、データソース、オーナーがある。
- [ ] ガードレールと失敗時判断がある。

## A.2 Scope / Requirements

- [ ] In Scope、Out of Scope、優先順位、対象リリースが合意されている。
- [ ] 各Must要件が目的・ユーザーストーリーへ追跡できる。
- [ ] 各Must要件に検証可能な受入基準がある。
- [ ] 重大な境界値、失敗、権限、競合、監査を定義した。
- [ ] 非機能要件に測定可能な閾値と条件がある。
- [ ] UIのLoading、Empty、Error、Success、Disabled状態を検討した。

## A.3 Delivery / Governance

- [ ] 依存関係、リスク、前提、未解決事項にオーナーと期限がある。
- [ ] Product Specへ委譲する詳細と責任者が明確である。
- [ ] QA戦略、RTM、リリースゲートが定義されている。
- [ ] ロールアウト、ロールバック、監視、サポートが定義されている。
- [ ] 必要なBusiness、Engineering、Design、QA、Security、Privacy、Operations承認がある。

---

# Appendix B. Requirement Validation Checklist

| 観点 | 確認質問 | 結果 |
|---|---|---|
| 必要性 | この要求を除くと、どの目的・リスク・契約が満たせないか | [ ] |
| 正確性 | ステークホルダーの実際の必要性を正しく表しているか | [ ] |
| 明確性 | 一通りに解釈でき、曖昧語がないか | [ ] |
| 原子性 | 1つの要求文に1つの意図だけがあるか | [ ] |
| 完全性 | 条件、対象、結果、単位、境界、例外が揃っているか | [ ] |
| 一貫性 | 他要件・用語・規格と矛盾しないか | [ ] |
| 実現可能性 | 技術、費用、日程、運用の観点で実現可能か | [ ] |
| 設計独立性 | 必要以上に実装方式を固定していないか | [ ] |
| 検証可能性 | テスト、分析、検査、実証のいずれかで判定できるか | [ ] |
| 追跡可能性 | 上位目的と下位AC・テストへ双方向に追跡できるか | [ ] |
| 保守性 | 一意ID、状態、履歴、オーナー、版があるか | [ ] |

---

# Appendix C. Release / Rollout Plan

## C.1 ロールアウト

| Stage | 対象 | 割合／規模 | Entry条件 | 観測時間 | 成功条件 | 停止条件 | 責任者 |
|---|---|---:|---|---|---|---|---|
| Internal | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| Pilot | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| Canary | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| GA | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

## C.2 ロールバック

| 項目 | 内容 |
|---|---|
| トリガー | [Error rate、データ不整合、Security、KPI Guardrailなど] |
| 決定者 | [ ] |
| 方法 | [Feature flag / Previous version / Read-only / Data restore] |
| データ互換性 | [Forward / Backward / Migration reversal] |
| 目標時間 | [ ] |
| 顧客通知 | [ ] |
| 検証 | [演習日・結果] |

## C.3 リリース後レビュー

| 時点 | 確認内容 | 意思決定 |
|---|---|---|
| T+1日 | 健全性、重大障害、データ品質 | 継続／停止 |
| T+7日 | 利用、問い合わせ、ガードレール | 拡大／修正 |
| T+30日 | Leading KPI、セグメント差 | 改善／再設計 |
| 観測窓終了 | Primary KPI、ROI、残余リスク | Scale／Iterate／Stop |

---

# Appendix D. 5W1H最終確認

| 観点 | 最終確認質問 | 主な参照章 |
|---|---|---|
| Who | 利用者、購入者、承認者、実装者、運用者、リスクオーナーが明確か | 1, 4, 14 |
| What | 問題、成果、スコープ、要求、品質条件、対象外が明確か | 2, 3, 5, 7, 8 |
| When | 利用契機、期限、観測窓、障害時、再評価時期が明確か | 3, 6, 8, 12, 15 |
| Where | 利用場所、端末、チャネル、地域、システム・信頼境界が明確か | 2, 4, 9, 10 |
| Why | 根拠、ユーザー価値、戦略、優先順位、要件理由が明確か | 2, 3, 5, 7 |
| How | 操作フロー、受入、計測、検証、展開、運用、変更方法が明確か | 6, 9, 11, 13, 14 |

---

# Appendix E. 参考にした公式資料

詳細は同梱の `SOURCES.md` を参照する。

