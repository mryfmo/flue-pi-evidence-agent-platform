---
title: "StockLens（仮称）小規模小売店向けリアルタイム在庫管理Webアプリ PRD"
version: "1.0.0-sample"
status: "Approved Sample"
owner: "Product Manager（サンプル）"
last_updated: "2026-08-18"
target_release: "2027-01-20"
confidentiality: "Sample / Public"
---

# StockLens（仮称）小規模小売店向けリアルタイム在庫管理Webアプリ PRD

> **重要**  
> これはPRDの書き方を示す架空のサンプルである。組織名、ユーザー数、ベースライン、目標値、日程、技術選定、リスク評価はすべて説明用の仮定であり、実在調査の結果ではない。実案件では、ユーザー調査、ログ、契約、法令、技術検証に置き換える。

- 作成基準日: 2026-08-18（JST）
- 文書ID: `PRD-STOCKLENS-001`
- PRDオーナー: Product Manager（サンプル）
- 最終意思決定者: Head of Product（サンプル）
- 対象読者: Business、Product、Design、Engineering、QA、Security、Operations、Support
- 関連目的: 小規模店舗の在庫管理工数と在庫差異を削減する
- Product Spec: `docs/product-spec/stocklens-v1.md`（サンプル参照先）

---

## 0. このサンプルで採用する境界

- PRDでは、ユーザーの問題、成果、スコープ、要求、品質水準、受入・リリース条件を確定する。
- APIパス、テーブルDDL、クラウドリソース、内部アルゴリズムはProduct Spec／Technical Specで決める。
- 元の例にある「React / Node.js / PostgreSQL / AWS」は、10章で**候補技術と制約の要約**として扱い、PRDだけで実装を固定しない。
- 成果指標はリリース後の価値を測り、受入基準はリリース前の完成判定に使う。

## 0.1 主要ID

| 種別 | 使用範囲 |
|---|---|
| 目的 | `OBJ-001`〜`OBJ-003` |
| KPI / Guardrail | `KPI-001`〜`KPI-004`, `GRD-001`〜`GRD-004` |
| ユーザーストーリー | `US-001`〜`US-008` |
| 機能要件 | `FR-001`〜`FR-014` |
| 非機能要件 | `NFR-*` |
| 受入基準 | `AC-001`〜`AC-018` |
| リスク | `RISK-001`〜`RISK-008` |

---

# 1. ドキュメント情報（基本情報）

> **5W1H**: `Who` Product Managerが管理し、Head of Productが最終承認 / `What` StockLens v1の要求 / `When` 2026-08-18確定、2027-01-20目標 / `Where` Gitリポジトリを正本 / `Why` 版・責任・変更影響を一意にする / `How` Pull Requestと要件IDで変更管理

## 1.1 基本メタデータ

| 項目 | 内容 |
|---|---|
| 文書タイトル | StockLens 小規模小売店向けリアルタイム在庫管理Webアプリ PRD |
| 文書ID | PRD-STOCKLENS-001 |
| バージョン | 1.0.0-sample |
| ステータス | Approved Sample |
| オーナー | Product Manager（サンプル） |
| 最終意思決定者 | Head of Product（サンプル） |
| 作成日 | 2026-08-18 |
| 最終更新日 | 2026-08-18 |
| 目標リリース | 2027-01-20 |
| リリース形態 | 5店舗Pilot → 20店舗Beta → GA |
| 正本 | `docs/prd/stocklens-v1.md` |
| 関連Epic | `EPIC-STOCKLENS-V1` |
| Product Spec | `docs/product-spec/stocklens-v1.md` |
| UX Spec | `docs/ux/stocklens-v1.fig` |
| RTM | `qa/rtm/stocklens-v1.csv` |

## 1.2 改訂履歴

| 版 | 日付 | 作成者 | 変更概要 | 影響ID | 状態 |
|---|---|---|---|---|---|
| 0.1.0 | 2026-08-18 | Product | 問題・成果・初期スコープ | 全体 | Draft |
| 0.8.0 | 2026-08-18 | Cross-functional team | NFR、受入基準、Rolloutを追加 | FR/NFR/AC | In Review |
| 1.0.0-sample | 2026-08-18 | Product | サンプルとして承認 | 全体 | Approved Sample |

## 1.3 変更管理

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> InReview: Product review request
    InReview --> Draft: Blocking comment
    InReview --> Approved: Cross-functional approval
    Approved --> Implementing: Product Spec ready
    Implementing --> InReview: KPI / Must / NFR変更
    Implementing --> Released: Release gate pass
    Released --> Superseded: v2 approved
```

## 1.4 意思決定ログ

| ID | 日付 | 決定 | 理由 | 影響 | 再検討条件 |
|---|---|---|---|---|---|
| DEC-001 | 2026-08-18 | v1ではPOS連携を対象外とする | 外部製品差が大きく、CSVで価値仮説を先に検証できるため | OOS-001 | PilotでCSV作業が週30分超の店舗が50%以上 |
| DEC-002 | 2026-08-18 | 在庫更新には理由コードと監査ログを必須とする | 誤更新の原因追跡と復旧に必要 | FR-006, FR-007 | なし |
| DEC-003 | 2026-08-18 | 詳細アーキテクチャはProduct Specで確定する | PRDと実装責務を分離するため | 10章 | 制約変更時 |

---

# 2. 製品概要（Purpose / Background）

> **5W1H**: `Who` 1〜10店舗を運営する小規模小売店の店長・在庫担当 / `What` 店舗別SKU在庫の把握・更新・差異追跡 / `When` 入荷、販売後調整、棚卸し、発注判断時 / `Where` 店舗PC・タブレット・スマートフォンのWeb / `Why` 表計算・紙・口頭連絡による遅延と差異を減らす / `How` 単一の在庫台帳、即時反映、しきい値通知、監査証跡で支援

## 2.1 エグゼクティブサマリー

小規模小売店では、店舗ごとに紙、表計算、口頭連絡を併用して在庫を管理しているという仮説を置く。その結果、在庫数の確認、転記、差異調査に時間がかかり、欠品・過剰在庫・誤発注につながる。StockLens v1は、店舗別・SKU別の在庫をWebから確認・更新し、低在庫を可視化し、すべての変更を監査可能にする。v1の成功は、Pilot店舗で週次在庫管理工数を50%削減し、在庫差異率を3%以下にしながら、重大なデータ損失・権限逸脱を0件に保つことで判定する。

## 2.2 問題定義

| 項目 | サンプル仮定 |
|---|---|
| 対象ユーザー | 1〜10店舗、5〜50名規模の小売事業者。専任IT管理者なし |
| 現状 | 店舗別Excel、紙の入荷票、チャット、口頭で在庫を更新 |
| 問題1 | 最新在庫がどのファイル・店舗にあるか分からず、確認に時間がかかる |
| 問題2 | 複数人更新や転記ミスにより、帳簿在庫と実在庫がずれる |
| 問題3 | 低在庫の発見が遅れ、発注判断が属人化する |
| 発生時 | 入荷時、破損・返品時、閉店後集計、発注前、棚卸し時 |
| ユーザー影響 | 確認・再入力・差異調査、欠品対応、心理的負担 |
| 事業影響 | 販売機会損失、余剰在庫、作業コスト、説明責任の不足 |
| 放置時 | 店舗数・SKU数の増加に伴い、手作業と差異が拡大する可能性 |

## 2.3 根拠と信頼度

> 以下は実データではなく、実案件で収集すべき証拠の記入例である。

| Evidence ID | 仮の根拠 | 種別 | 対象 | 示唆 | 限界 | 信頼度 |
|---|---|---|---|---|---|---|
| EVD-001 | 店長インタビュー | 定性 | 5店舗 | 最新ファイル確認と差異調査が主な負担 | 標本が小さい | Medium |
| EVD-002 | 2週間の作業日誌 | 定量 | 3店舗 | 在庫管理に中央値10時間／週 | 自己申告 | Medium |
| EVD-003 | 棚卸し差異サンプル | 定量 | 2か月 | SKU行の8%に差異 | 商品構成が限定的 | Low |
| EVD-004 | サポート問い合わせ分類 | 定性 | 30件 | CSV、権限、更新履歴が重要 | 新規製品の直接証拠ではない | Low |

## 2.4 Why Now

- Pilot協力店舗を2026年12月に確保できるという仮定がある。
- 年末・年度末の棚卸し前に、基本的な在庫台帳と監査性を検証できる。
- POS連携やAI需要予測へ進む前に、基礎データの正確性と運用定着を確認する必要がある。

## 2.5 価値提案

1〜10店舗を運営する小売店の店長・在庫担当に対して、StockLensは店舗別在庫を一つの台帳で確認・更新・追跡できるWebアプリを提供する。分散した表計算や口頭連絡と異なり、変更理由、更新者、時刻を保持し、低在庫を即時に可視化することで、確認工数と差異調査を減らす。

## 2.6 戦略との整合

| 戦略 | 寄与 | 測定 | オーナー |
|---|---|---|---|
| 小規模事業者の業務デジタル化 | 手作業の在庫台帳を共同利用可能にする | KPI-001, KPI-002 | Product |
| 継続利用可能なSaaS基盤 | 複数店舗・複数権限・監査をv1から確立 | KPI-003, GRD-002 | Product / Engineering |
| 信頼できる業務データ | 差異と変更履歴を可視化 | KPI-002, FR-007 | Product / QA |

## 2.7 解決仮説

| 仮説ID | 仮説 | 検証 | 成功条件 | 失敗時判断 |
|---|---|---|---|---|
| HYP-001 | 一つの在庫台帳と即時更新を提供すれば、確認・転記時間が減る | 5店舗Pilot、作業日誌 | KPI-001達成 | 導線・対象作業を再設計 |
| HYP-002 | 理由付き更新と監査履歴を提供すれば、差異原因の特定が速くなる | 差異調査時間計測 | KPI-002および補助指標達成 | 更新粒度・理由分類を見直す |
| HYP-003 | 低在庫一覧を提供すれば、発注前の見落としが減る | 利用ログ＋店舗ヒアリング | 対象店舗の70%以上が週1回以上利用 | 通知頻度・閾値設定を見直す |

## 2.8 コンテキスト

```mermaid
flowchart LR
    Owner["店長 / オーナー"] --> Web["StockLens Web / PWA"]
    Staff["在庫担当"] --> Web
    Web --> CSV["既存CSV / 表計算"]
    Web --> Mail["メール通知"]
    Web --> Audit["監査・操作履歴"]
    Support["サポート担当"] --> Audit
    Web -. v1対象外 .-> POS["POSシステム"]
```

## 2.9 制約・非目標

| 種別 | 内容 | 理由 |
|---|---|---|
| 制約 | 専任IT担当なしでも初期設定・運用可能 | 対象ユーザー条件 |
| 制約 | 店舗の一般的なPC、タブレット、スマートフォンの現行ブラウザで利用 | 導入障壁を抑える |
| 原則 | 変更は追跡可能、破壊的操作は復旧可能 | 業務データの信頼性 |
| 非目標 | v1で売上取引を記録する | POSの責務と重なる |
| 非目標 | v1で需要予測・自動発注を行う | 基礎データの品質未検証 |
| 非目標 | v1で会計・多通貨を扱う | 主要問題と無関係 |

## 2.10 用語集

| 用語 | 定義 |
|---|---|
| SKU | 在庫を区別する最小の商品単位 |
| 帳簿在庫 | StockLensに記録された数量 |
| 実在庫 | 現物確認による数量 |
| 在庫差異率 | 差異があったSKU行数 ÷ 棚卸し対象SKU行数 |
| 在庫調整 | 入荷・販売以外の理由で帳簿在庫を増減する操作 |
| 低在庫 | 店舗・SKUごとの閾値以下になった状態 |

---

# 3. 目標と成果指標（Objectives / Success Metrics）

> **5W1H**: `Who` Pilot店舗とProduct Analytics owner / `What` 工数、差異、利用定着、品質 / `When` Pilot開始後30・60・90日 / `Where` 5店舗のWeb利用 / `Why` 作業削減と在庫信頼性を成果とする / `How` 作業日誌、棚卸し記録、イベント、監視で測定

## 3.1 目的

| ID | 目的 | 優先度 | オーナー |
|---|---|---|---|
| OBJ-001 | 店長・在庫担当の週次在庫管理工数を削減する | Must | Product |
| OBJ-002 | 帳簿在庫と実在庫の差異を削減し、原因追跡を容易にする | Must | Product / Operations |
| OBJ-003 | 小規模店舗で継続利用できる操作性・信頼性・安全性を実現する | Must | Product / Engineering |

## 3.2 KPIとガードレール

> 数値はサンプル仮定。実案件ではPilot前に測定定義を凍結する。

| ID | 指標 | 種別 | 定義 | Baseline | Target | 観測窓 | Source | Owner | 判定後 |
|---|---|---|---|---:|---:|---|---|---|---|
| KPI-001 | 週次在庫管理工数 | Primary | 対象店舗の在庫確認・更新・集計・差異調査の合計時間の店舗中央値 | 10時間/週 | 5時間/週以下 | Pilot 90日 | 作業日誌 | Product | 達成なら拡大 |
| KPI-002 | 在庫差異率 | Primary | 差異SKU行数 ÷ 棚卸しSKU行数 | 8% | 3%以下 | Pilot 90日 | 棚卸し結果 | Product / Ops | 未達なら運用・UI再設計 |
| KPI-003 | Weekly Active Store率 | Leading | 週に1回以上、閲覧以外の有効操作をした店舗 ÷ 有効化店舗 | 0% | 70%以上 | 4週連続 | Analytics | Product | 低ければ定着施策 |
| KPI-004 | 差異原因特定時間 | Supporting | 差異発見から原因または未解決判断までの中央値 | 120分 | 30分以下 | Pilot 60日 | Issue log | Operations | 監査・理由分類を改善 |
| GRD-001 | 誤更新による不可逆データ損失 | Safety | 復元不能な在庫履歴消失件数 | 0 | 0 | 常時 | Incident log | Engineering | 1件でRollout停止 |
| GRD-002 | 権限逸脱 | Security | 無許可店舗・データへのアクセス確認件数 | 0 | 0 | 常時 | Security/Audit | Security | 1件でRollout停止 |
| GRD-003 | サポート負荷 | Guardrail | 有効店舗あたり問い合わせ件数／週 | 未計測 | 0.5以下 | Pilot 4週 | Support | Support | 超過ならUX改善 |
| GRD-004 | 重大操作失敗率 | Reliability | 在庫更新要求のうち保存不能・不明状態となった割合 | 未計測 | 0.5%未満 | 週次 | Metrics | Engineering | 超過なら拡大停止 |

## 3.3 指標の因果関係

```mermaid
flowchart LR
    CAP1["単一在庫台帳"] --> BEH1["最新在庫を直接確認"]
    CAP2["理由付き即時更新"] --> BEH2["転記・口頭連絡を削減"]
    CAP3["監査履歴"] --> BEH3["差異原因を検索"]
    BEH1 --> OUT1["在庫管理工数削減"]
    BEH2 --> OUT1
    BEH3 --> OUT2["差異率・調査時間削減"]
    OUT1 --> BUS["小規模店舗での継続利用"]
    OUT2 --> BUS
    CAP1 --> GRD["Security / Reliability Guardrails"]
```

## 3.4 計測イベント

| Event ID | 名称 | 発火条件 | 属性 | 禁止属性 | KPI |
|---|---|---|---|---|---|
| EVT-001 | inventory_viewed | 店舗在庫一覧の有効表示 | tenant_id_hash, store_id_hash, item_count, duration_ms | 商品名、メール | KPI-003 |
| EVT-002 | inventory_adjusted | 更新が確定 | hashed IDs, delta_bucket, reason_code, result | 自由入力メモ本文 | KPI-003, GRD-004 |
| EVT-003 | low_stock_opened | 低在庫一覧表示 | hashed store, count | 商品名 | KPI-003 |
| EVT-004 | csv_import_completed | CSV取込完了 | rows, success_rows, error_rows, duration | ファイル内容 | KPI-001, GRD-003 |

## 3.5 フェーズ別の判定基準

### Pilot／Beta／GAの初期Rollout判断

90日を必要とするOutcome KPIが確定する前にGA判断を行うため、初期RolloutはSafety、Reliability、利用可能性、Support負荷のLeading indicatorで判定する。これを最終的なProduct successとはみなさない。

| Gate | 条件 | 行動 |
|---|---|---|
| Pilot → Beta | GRD-001/002=0、Sev-1/2=0、5店舗中4店舗以上がMust journey完了、更新成功率99.5%以上、Support 1件/店舗/週以下 | 20店舗Betaへ拡大 |
| Beta → GA | 上記Guardrail維持、重大回帰0、Operational readiness承認、既知RiskのOwner・期限あり | 段階GAを開始 |
| Hold | Guardrailは維持するが、利用・Support・品質のいずれかが閾値未達 | Cohort拡大を止め、改善後に再判定 |
| Stop | GRD-001/002違反、Sev-1/2、復旧不能、権限逸脱 | Rollout停止、Rollback／Incident response |

### 90日Outcome判断

| 判定 | 条件 | 行動 |
|---|---|---|
| Success | KPI-001とKPI-002達成、KPI-003達成、全Guardrail維持 | Scale投資と次期Opportunityを承認 |
| Partial | Primary KPIの一方達成、Guardrail維持 | 4週間の改善実験または対象Segment見直し |
| Inconclusive | Data欠損20%以上、棚卸し母数不足、Baseline不成立 | 計測修正後に観測延長。成功とは判定しない |
| Failure | Primary KPI双方未達、または安全・Security上の許容不能Risk | 拡大停止、仮説・Scope・Solutionを再評価 |

---

# 4. ターゲットユーザーとペルソナ

> **5W1H**: `Who` 店長、在庫担当、閲覧のみのスタッフ、サポート / `What` 在庫確認・更新・差異調査 / `When` 入荷・破損・発注・棚卸し / `Where` 店舗バックヤード、売場、事務所 / `Why` 最新状態の共有と誤りの説明 / `How` PC・タブレット・スマートフォンから役割別に操作

## 4.1 ユーザー区分

| User ID | 区分 | 役割 | JTBD | 頻度 | 場所／端末 | 権限 | 対象 |
|---|---|---|---|---|---|---|---|
| USER-001 | Primary | 店長／オーナー | 全店舗の在庫と低在庫を短時間で把握し、差異の原因を確認する | 毎日〜週数回 | 事務所PC、スマホ | 全店舗管理 | 対象 |
| USER-002 | Primary | 在庫担当 | 入荷・破損・返品後に数量を正確に更新する | 1日複数回 | バックヤードのタブレット | 担当店舗更新 | 対象 |
| USER-003 | Secondary | 売場スタッフ | 在庫を閲覧し、顧客対応に使う | 必要時 | スマホ | 担当店舗閲覧 | 対象 |
| USER-004 | Internal | サポート担当 | 利用者の操作履歴を確認し、問題解決を支援する | 問い合わせ時 | 管理PC | 承認済み支援閲覧 | 条件付き |
| USER-005 | Excluded v1 | 会計担当 | 売上・原価・会計仕訳を管理する | 月次 | PC | - | 対象外 |

## 4.2 ペルソナA: 35歳の小売店オーナー「佐藤さん」（架空）

| 観点 | 内容 |
|---|---|
| 背景 | 3店舗、従業員18名。専任IT担当なし |
| 目標 | 閉店後に各店舗へ電話せず、欠品候補と差異を15分以内に確認したい |
| 現状 | 店舗別Excelとチャット写真を集約 |
| 痛点 | ファイル版の混乱、数値の根拠不明、差異調査に時間 |
| トリガー | 発注前、店舗間移動、棚卸し後 |
| 成功 | どの店舗の誰がいつ更新したか分かり、必要なSKUだけ確認できる |
| リテラシー | 基本的なWeb・表計算操作。複雑な設定は避けたい |
| アクセシビリティ | 小さい文字や色だけの警告を避ける |
| 信頼上の懸念 | データ消失、他店舗・他社への漏えい |

## 4.3 ペルソナB: 42歳の在庫担当「高橋さん」（架空）

| 観点 | 内容 |
|---|---|
| 背景 | 1店舗の入荷・棚卸し担当。PCよりタブレットを多用 |
| 目標 | 入荷直後に複数商品の数量を誤りなく更新したい |
| 現状 | 紙の入荷票からExcelへ後入力 |
| 痛点 | 二重入力、入力ミス、保存済みか不明 |
| トリガー | 入荷、破損、返品、棚卸し調整 |
| 成功 | 入力エラーの場所と直し方が分かり、保存結果を確認できる |
| リテラシー | 定型操作には慣れるが、複雑なメニューは苦手 |
| アクセシビリティ | タッチ操作、十分なターゲットサイズ、キーボード操作 |

## 4.4 Jobs-to-be-Done

| ID | When | I want to | So I can | 代替手段 | 成功条件 |
|---|---|---|---|---|---|
| JTBD-001 | 発注前 | 店舗別の最新在庫と低在庫を一覧で確認したい | 欠品と過剰発注を避けられる | 各店舗へ確認 | 15分以内に候補確認 |
| JTBD-002 | 入荷・破損・返品時 | 数量と理由をその場で更新したい | 後入力と転記ミスをなくせる | 紙メモ→Excel | 保存確認と履歴が残る |
| JTBD-003 | 棚卸し差異を見つけた時 | 誰がいつ何を変更したか調べたい | 原因を説明し、必要なら修正できる | チャット検索 | 30分以内に原因特定 |
| JTBD-004 | 初回導入時 | 既存CSVを安全に取り込みたい | 手入力せず開始できる | 手作業コピー | エラー行だけ修正可能 |

## 4.5 ユーザージャーニー

```mermaid
flowchart LR
    A["発注・入荷・棚卸しが発生"] --> B["StockLensで店舗を選択"]
    B --> C["在庫一覧・低在庫を確認"]
    C --> D{"更新が必要?"}
    D -->|No| E["判断・業務を継続"]
    D -->|Yes| F["数量と理由を入力"]
    F --> G["検証・保存"]
    G --> H["結果・更新者・時刻を確認"]
    H --> I["必要時に監査履歴を検索"]
```

## 4.6 未確認事項

| ID | 未確認 | 重要度 | 検証 | Owner | Due | 未解消時 |
|---|---|---|---|---|---|---|
| OQ-001 | 店舗内Wi-Fiが不安定な場合の頻度 | High | Pilot現地計測 | Product / Eng | 2026-09-10 | v1は明示的な再送・未保存表示を必須、完全オフラインは対象外 |
| OQ-002 | バーコード入力の必要度 | Medium | 5店舗観察 | Design | 2026-09-15 | v1は検索・CSVを優先 |
| OQ-003 | 自由入力の調整理由が必要か | Medium | タスク分析 | Product | 2026-09-05 | 理由コード＋任意メモで開始 |

---

# 5. 製品スコープと機能一覧（Scope & Features）

> **5W1H**: `Who` Pilot店舗の店長・在庫担当を優先 / `What` 在庫台帳、更新、低在庫、CSV、監査 / `When` v1 Pilot・Beta・GAで段階提供 / `Where` Web/PWAと管理画面 / `Why` 最小の成果検証に集中 / `How` MoSCoWとFeature Flagで範囲を統制

## 5.1 対象リリース

| 項目 | 内容 |
|---|---|
| リリースID | StockLens v1 |
| 最小成果 | 5店舗で在庫確認・更新・差異追跡を一つのWeb台帳へ移す |
| 対象 | 1〜10店舗の小規模小売事業者 |
| チャネル | レスポンシブWeb。ホーム画面追加可能なPWAを許容 |
| 地域・言語 | 日本国内、日本語、JST |
| Pilot開始 | 2026-12-07 |
| Beta開始 | 2027-01-06 |
| GA目標 | 2027-01-20 |
| 展開方式 | Tenant単位Feature Flag |

## 5.2 In Scope

| ID | 能力 | ユーザー | 価値 | 優先度 | Release | 関連 |
|---|---|---|---|---|---|---|
| SCP-001 | 認証と店舗・役割別アクセス | 全員 | 他店舗・他社データを分離 | Must | Pilot | US-001, FR-001〜003 |
| SCP-002 | 店舗別・SKU別在庫一覧と検索 | 店長・担当・閲覧者 | 最新在庫を短時間で確認 | Must | Pilot | US-002, FR-004 |
| SCP-003 | 理由付き在庫調整 | 店長・担当 | その場で正確に更新 | Must | Pilot | US-003, FR-005〜006 |
| SCP-004 | 変更監査履歴 | 店長・Support | 差異原因を追跡 | Must | Pilot | US-004, FR-007 |
| SCP-005 | 低在庫閾値と一覧 | 店長・担当 | 発注候補の見落とし削減 | Must | Pilot | US-005, FR-008〜009 |
| SCP-006 | CSV初期取込・エラー確認 | 店長 | 導入時の手入力削減 | Must | Pilot | US-006, FR-010 |
| SCP-007 | CSV出力 | 店長 | バックアップ・外部分析 | Should | Beta | US-007, FR-011 |
| SCP-008 | サマリーダッシュボード | 店長 | 全店舗の状況把握 | Should | Beta | US-008, FR-012 |
| SCP-009 | 操作・品質計測 | Product/Ops | KPIと障害の測定 | Must | Pilot | FR-013〜014 |

## 5.3 Out of Scope

| ID | 対象外 | 理由 | 境界 | 再評価条件 |
|---|---|---|---|---|
| OOS-001 | POSとのリアルタイム連携 | 製品ごとの契約・仕様差が大きい | v1はCSVによる初期取込・出力のみ | CSV作業がKPI阻害要因になる |
| OOS-002 | 売上・会計処理 | 在庫台帳の問題に集中 | 金額・税・仕訳は扱わない | 別PRDで検討 |
| OOS-003 | AI需要予測・自動発注 | データ品質と運用定着が未検証 | 低在庫の可視化まで | 6か月分の信頼できる履歴 |
| OOS-004 | 完全オフライン同期 | 競合・復旧の複雑性が高い | 一時通信断は再送・未保存表示で対応 | Pilotで通信断が主要障害になる |
| OOS-005 | 多通貨・多言語 | 日本国内Pilotに不要 | 日本語・数量中心 | 海外展開決定 |
| OOS-006 | 商品画像認識による自動棚卸し | v1仮説と離れる | 画像アップロードもしない | 別のDiscovery |

## 5.4 トレードオフ

| 優先 | 劣後許容 | 理由 |
|---|---|---|
| 在庫数量の正確性・監査性 | 高度なグラフ | 業務の信頼が先 |
| 明確な保存結果・回復 | 操作ステップの極端な削減 | 誤更新を防ぐため |
| テナント・店舗分離 | 柔軟な共有設定 | 権限事故を避けるため |
| CSVエラーの部分修正 | 任意形式の自動推測 | 誤取込を防ぐため |

## 5.5 段階提供

```mermaid
flowchart LR
    P0["Prototype<br/>5 users"] --> P1["Pilot<br/>5 stores"]
    P1 --> P2["Beta<br/>20 stores"]
    P2 --> P3["GA<br/>Eligible tenants"]
    P3 --> P4["Outcome Review<br/>90 days"]
```

| Stage | 含む範囲 | Entry | Exit |
|---|---|---|---|
| Prototype | SCR-001〜005の主要導線 | 問題仮説合意 | 5名中4名が支援なしで更新完了 |
| Pilot | Must機能 | Release Gate Pass | 4週、Sev-1/2なし、GRD維持 |
| Beta | Should機能＋改善 | Pilot Exit | 20店舗で運用・Support準備 |
| GA | 対象顧客へ提供 | Beta Exit、承認 | 稼働・監視・契約・サポート完了 |

---

# 6. ユースケース / ユーザーストーリー

> **5W1H**: `Who` 店長・在庫担当・閲覧者 / `What` 認証、確認、調整、履歴、低在庫、CSV / `When` 業務イベント発生時 / `Where` 店舗Web/PWA / `Why` 最新在庫と説明可能性 / `How` 権限確認、入力検証、保存確認、エラー回復

## 6.1 ユーザーストーリー

| US ID | ストーリー | Priority | AC | FR |
|---|---|---|---|---|
| US-001 | 店舗スタッフとして、自分に許可された店舗だけへ安全にアクセスしたい。なぜなら他店舗・他社の情報を誤って閲覧・更新したくないから。 | Must | AC-001〜003 | FR-001〜003 |
| US-002 | 店長として、複数店舗のSKU在庫を検索・絞込したい。なぜなら発注前に欠品候補を短時間で把握したいから。 | Must | AC-004〜005 | FR-004 |
| US-003 | 在庫担当として、数量と調整理由をその場で更新したい。なぜなら紙からの後入力と転記ミスを減らしたいから。 | Must | AC-006〜009 | FR-005〜006 |
| US-004 | 店長として、数量変更の履歴を確認したい。なぜなら差異の原因と責任範囲を説明したいから。 | Must | AC-010〜011 | FR-007 |
| US-005 | 店長として、低在庫SKUを店舗別に確認したい。なぜなら発注候補の見落としを減らしたいから。 | Must | AC-012〜013 | FR-008〜009 |
| US-006 | 店長として、既存CSVを検証付きで取り込みたい。なぜなら初期データを手入力したくないから。 | Must | AC-014〜016 | FR-010 |
| US-007 | 店長として、在庫一覧をCSV出力したい。なぜなら外部保管・分析へ利用したいから。 | Should | AC-017 | FR-011 |
| US-008 | 店長として、全店舗の総SKU、低在庫、最近の更新を一画面で見たい。なぜなら確認開始点を統一したいから。 | Should | AC-018 | FR-012 |

## 6.2 UC-001: 在庫数量を調整する

| 項目 | 内容 |
|---|---|
| 主アクター | USER-002 在庫担当 |
| 目的 | 対象店舗・SKUの帳簿在庫を理由付きで変更する |
| トリガー | 入荷、破損、返品、棚卸し差異、手動訂正 |
| 事前条件 | 認証済み、対象店舗の更新権限あり、SKUが有効 |
| 事後条件 | 新数量が保存され、更新者・時刻・旧値・新値・理由が監査履歴へ記録 |
| 頻度 | 1店舗あたり1日10〜200回を想定（サンプル） |

**基本フロー**

1. 在庫担当が店舗とSKUを選択する。
2. 現在数量、最終更新時刻、更新者を確認する。
3. 新数量または増減値と理由コードを入力する。
4. システムが権限、数値範囲、競合、必須項目を検証する。
5. システムが数量と監査履歴を不可分に保存する。
6. UIが保存後数量、時刻、理由を表示する。

**代替・例外**

- A1: 連続入力では保存成功後、次SKUへ移動できる。
- E1: 数量が許容範囲外なら保存せず、項目単位で理由と修正方法を表示する。
- E2: 他ユーザーが先に更新した場合、上書きせず最新値と差分を表示する。
- E3: 通信断・タイムアウト時は「保存済み」と表示せず、再試行または状態確認を選べる。
- E4: 権限を失った場合、更新を拒否し、入力内容を安全な範囲で保持する。

## 6.3 在庫更新フロー

```mermaid
flowchart TD
    A["ログイン"] --> B["許可店舗を選択"]
    B --> C["SKUを検索"]
    C --> D["現在数量・更新時刻を確認"]
    D --> E["新数量 / 増減値と理由を入力"]
    E --> F{"入力・権限・競合を検証"}
    F -->|入力不正| G["項目別エラーと修正方法"]
    G --> E
    F -->|更新競合| H["最新値と差分を提示"]
    H --> D
    F -->|OK| I["数量と監査履歴を保存"]
    I --> J["保存後数量・時刻を表示"]
```

## 6.4 観察可能なシーケンス

```mermaid
sequenceDiagram
    actor Staff as 在庫担当
    participant UI as StockLens UI
    participant Core as 在庫管理サービス
    participant Store as 在庫データ
    participant Audit as 監査履歴
    Staff->>UI: 数量・理由を入力して保存
    UI->>Core: 認証済み更新意図を送信
    Core->>Store: 現在値と更新版を確認
    alt 他の更新と競合
        Store-->>Core: 最新値が異なる
        Core-->>UI: 競合・最新値・再確認要求
        UI-->>Staff: 上書きせず差分を表示
    else 検証成功
        Core->>Store: 新数量を保存
        Core->>Audit: 旧値・新値・理由・主体を記録
        Core-->>UI: 保存結果
        UI-->>Staff: 新数量と更新時刻を表示
    end
```

## 6.5 受入基準

| AC | 関連 | Given | When | Then | Verification |
|---|---|---|---|---|---|
| AC-001 | US-001/FR-001 | 有効な招待済みユーザー | 正しい認証を完了 | 許可されたTenantへログインできる | E2E |
| AC-002 | US-001/FR-002 | 店舗Aのみ許可されたユーザー | 店舗BのURLまたはIDへ直接アクセス | データを返さず、権限エラーを記録する | Security/E2E |
| AC-003 | US-001/FR-003 | 閲覧権限ユーザー | 更新操作を試行 | 更新されず、必要権限を説明する | E2E |
| AC-004 | US-002/FR-004 | 2店舗・1,000 SKUのデータ | 店舗、SKU、商品名で絞込 | 条件に合う行だけを表示し、条件を保持する | E2E |
| AC-005 | US-002/FR-004 | 検索結果0件 | 検索 | Empty状態と条件解除方法を表示する | E2E/A11y |
| AC-006 | US-003/FR-005 | 更新権限と有効SKU | 0以上の許容数量・理由を保存 | 数量が1回だけ更新され、成功結果を表示する | Integration/E2E |
| AC-007 | US-003/FR-005 | 現在数量10 | -11となる更新を試行 | 保存せず、負数不可と修正方法を表示する | Unit/E2E |
| AC-008 | US-003/FR-005 | 2ユーザーが同じ版を表示 | 一方の保存後、もう一方が保存 | 後者を上書きせず競合を通知する | Integration |
| AC-009 | US-003/FR-006 | 同一更新要求 | タイムアウト後に再送 | 二重反映せず、確定結果を返す | Integration |
| AC-010 | US-004/FR-007 | 更新履歴あり | 店長が履歴を開く | 旧値、新値、差分、理由、更新者、時刻を表示する | E2E |
| AC-011 | US-004/FR-007 | 他Tenantの履歴ID | 直接アクセス | 存在を推測できる情報を返さず拒否する | Security |
| AC-012 | US-005/FR-008 | 数量が閾値以下 | 低在庫一覧を開く | 対象SKUを店舗別に表示する | Unit/E2E |
| AC-013 | US-005/FR-009 | 店長権限 | 店舗・SKUの閾値を変更 | 次回判定から新閾値を使用し履歴を残す | E2E |
| AC-014 | US-006/FR-010 | 正しいCSV | Preview後に確定 | 行数・新規・更新・エラーを表示し、確定分を反映する | Integration/E2E |
| AC-015 | US-006/FR-010 | 一部不正CSV | Preview | エラー行・列・理由を表示し、確定前は一切反映しない | Integration |
| AC-016 | US-006/FR-010 | 同一SKU重複CSV | Preview | 重複規則に従って拒否し、修正例を表示する | Unit/E2E |
| AC-017 | US-007/FR-011 | 店長権限 | CSV出力 | 表示条件、生成時刻、文字コード仕様に従うファイルを取得する | E2E |
| AC-018 | US-008/FR-012 | 複数店舗データ | Dashboardを開く | 総SKU、低在庫、直近更新が権限範囲で表示される | E2E |

---

# 7. 機能要件（Functional Requirements）

> **5W1H**: `Who` 役割別ユーザー / `What` 14件の必須・推奨能力 / `When` 認証・業務イベント・エラー時 / `Where` Tenant・店舗境界内 / `Why` OBJとUSへ追跡 / `How` 観察可能な入力・結果・回復・監査として定義

## 7.1 機能要件一覧

| FR | 要求文 | Priority | Related | AC | Owner |
|---|---|---|---|---|---|
| FR-001 | システムは、招待され有効なユーザーを認証し、所属Tenantへアクセスさせなければならない。 | Must | OBJ-003, US-001 | AC-001 | Eng/Sec |
| FR-002 | システムは、ユーザーが許可されたTenantおよび店舗のデータだけを閲覧できるようにしなければならない。 | Must | OBJ-003, US-001 | AC-002, AC-011 | Eng/Sec |
| FR-003 | システムは、Owner、Manager、Staff、Viewerの役割に応じて操作を制御しなければならない。 | Must | OBJ-003, US-001 | AC-003 | Product/Eng |
| FR-004 | システムは、許可店舗の在庫を店舗、SKU、商品名、在庫状態で検索・絞込・並べ替えできるようにしなければならない。 | Must | OBJ-001, US-002 | AC-004, AC-005 | Product |
| FR-005 | システムは、更新権限者がSKUの在庫数量を0以上の許容範囲で調整できるようにし、理由コードを必須としなければならない。 | Must | OBJ-001/002, US-003 | AC-006〜008 | Product/Eng |
| FR-006 | システムは、再送または通信不明状態において同一の在庫調整を二重反映してはならない。 | Must | OBJ-002/003, US-003 | AC-009 | Eng |
| FR-007 | システムは、在庫変更についてTenant、店舗、SKU、旧値、新値、差分、理由、主体、時刻、相関IDを監査履歴へ記録し、許可された利用者が参照できるようにしなければならない。 | Must | OBJ-002, US-004 | AC-010, AC-011 | Product/Sec |
| FR-008 | システムは、現在数量が有効な閾値以下のSKUを低在庫として判定し、店舗別に一覧表示しなければならない。 | Must | OBJ-001, US-005 | AC-012 | Product |
| FR-009 | システムは、Manager以上が店舗・SKUごとの低在庫閾値を設定・変更できるようにし、変更履歴を記録しなければならない。 | Must | OBJ-001, US-005 | AC-013 | Product |
| FR-010 | システムは、指定テンプレートのCSVをPreview、検証、確定の順で取り込み、確定前に変更を反映してはならない。 | Must | OBJ-001/002, US-006 | AC-014〜016 | Product/Eng |
| FR-011 | システムは、Manager以上が権限範囲の在庫一覧をCSVとして出力できるようにしなければならない。 | Should | OBJ-001, US-007 | AC-017 | Product |
| FR-012 | システムは、店長に対し、権限範囲の店舗数、SKU数、低在庫数、直近更新を要約表示しなければならない。 | Should | OBJ-001, US-008 | AC-018 | Product |
| FR-013 | システムは、KPI計測に必要な最小イベントを、機微な商品名・自由入力本文・メールアドレスを含めず記録しなければならない。 | Must | OBJ-003 | Data AC | Product/Data |
| FR-014 | システムは、重大な操作失敗、権限拒否、CSV失敗、監査記録失敗を観測可能な形で記録し、運用者が検知できるようにしなければならない。 | Must | OBJ-003 | Ops AC | Eng/Ops |

## 7.2 FR-005 詳細: 在庫調整

| 属性 | 内容 |
|---|---|
| 要求文 | 更新権限者は、許可店舗・有効SKUの数量を0以上9,999,999以下の整数へ調整できる。理由コードは必須とする。上限はTBR-001としてPilot前に確認する。 |
| 入力 | 店舗、SKU、現在版、新数量または増減値、理由コード、任意メモ100文字以内 |
| 理由コード | 入荷、販売後訂正、破損、返品、棚卸し、店舗間移動、その他 |
| 出力 | 保存後数量、差分、理由、更新時刻、更新者表示名 |
| 権限 | Manager / Staff。Viewerは禁止 |
| 検証 | 数値、範囲、SKU状態、権限、Tenant、更新競合、重複要求 |
| 失敗 | 変更しない。入力不正、競合、権限、通信不明を区別し、回復手段を提示 |
| 監査 | FR-007の項目を同一の業務確定単位で記録 |
| Related | US-003, AC-006〜009, NFR-REL-003, NFR-SEC-002 |

## 7.3 権限マトリクス

| 操作 | Owner | Manager | Staff | Viewer | Support |
|---|---:|---:|---:|---:|---:|
| Tenant設定 | Allow | Deny | Deny | Deny | Deny |
| 店舗・ユーザー管理 | Allow | Allow | Deny | Deny | Deny |
| 在庫閲覧 | Allow | Allow | Allow | Allow | 承認済み支援時のみ |
| 在庫更新 | Allow | Allow | Allow | Deny | Deny |
| 閾値変更 | Allow | Allow | Deny | Deny | Deny |
| 監査履歴閲覧 | Allow | Allow | 自分の店舗のみ | Deny | 承認済み支援時のみ |
| CSV取込・出力 | Allow | Allow | Deny | Deny | Deny |

## 7.4 ビジネスルール

| Rule | 内容 | 関連 |
|---|---|---|
| BR-001 | 帳簿在庫は負数を許容しない | FR-005 |
| BR-002 | 1回の調整で数量と監査記録の一方だけが確定してはならない | FR-005/007 |
| BR-003 | 低在庫は `current_quantity <= threshold` で判定する | FR-008 |
| BR-004 | 無効化SKUは閲覧可能だが、新規調整不可とする | FR-004/005 |
| BR-005 | CSV確定は全行成功または有効行のみ確定の方式をProduct Specで決めるが、Preview結果と実確定結果は一致しなければならない | FR-010 |
| BR-006 | Tenant IDはクライアント入力を信頼せず、認証・認可文脈から決定する | FR-002 |

## 7.5 在庫状態

```mermaid
stateDiagram-v2
    [*] --> Normal
    Normal --> LowStock: quantity <= threshold
    LowStock --> OutOfStock: quantity == 0
    OutOfStock --> LowStock: 0 < quantity <= threshold
    LowStock --> Normal: quantity > threshold
    Normal --> Inactive: SKU disabled
    LowStock --> Inactive: SKU disabled
    OutOfStock --> Inactive: SKU disabled
    Inactive --> Normal: SKU re-enabled and quantity > threshold
```

---

# 8. 非機能要件（Non-Functional Requirements）

> **5W1H**: `Who` 店舗ユーザー、運用、Security、Support / `What` 性能、信頼性、セキュリティ、操作性、保守・柔軟性、安全 / `When` 通常・ピーク・障害・復旧 / `Where` 日本国内のWeb、クラウド境界 / `Why` 業務データの信頼と定着 / `How` SLI/SLO、テスト、監視、監査、復旧演習

## 8.1 品質優先度

| ISO/IEC 25010:2023観点 | Priority | StockLensでの意味 |
|---|---|---|
| 機能適合性 | High | 数量・権限・履歴が正しい |
| 性能効率性 | High | 店舗業務中に待たせず、1,000〜50,000 SKUでも主要操作が成立 |
| 互換性 | Medium | 現行WebブラウザとCSVで既存業務に接続 |
| インタラクション能力 | High | 非ITユーザーが状態・エラー・保存結果を理解できる |
| 信頼性 | High | 二重更新・不明状態・データ損失を防ぐ |
| セキュリティ | High | Tenant・店舗分離、最小権限、監査 |
| 保守性 | Medium | 変更が要件・テストへ追跡できる |
| 柔軟性 | Medium | 店舗・SKU増加と段階導入に対応 |
| 安全性 | High | 不可逆な在庫損失・大量誤更新を防ぐ |

## 8.2 NFR一覧

| NFR ID | 分類 | 要求／SLO | 条件 | 検証 |
|---|---|---|---|---|
| NFR-PERF-001 | Performance | 在庫一覧初期表示のサーバー応答p95を800ms以下、利用者が操作可能になるまでのp95を2.0秒以下 | 1 Tenant 50,000 SKU、同時200ユーザー、通常ネットワーク | Load + RUM |
| NFR-PERF-002 | Performance | 在庫更新の確定応答p95を1.0秒以下、p99を2.5秒以下 | 外部通知を待たず、正常負荷 | Load test |
| NFR-CAP-001 | Capacity | 1 Tenantあたり10店舗、50,000 SKU、1日50,000調整、監査履歴3年を扱える | Pilot想定の10倍まで試験 | Performance/Storage analysis |
| NFR-REL-001 | Availability | 月間可用性99.9%以上。事前通知済み計画停止は月2時間以内で別計上 | GA、本番 | Monitoring |
| NFR-REL-002 | Recovery | RPO 15分以下、RTO 4時間以下 | 地域内障害・操作ミスによる復元 | Restore drill |
| NFR-REL-003 | Integrity | 同一調整要求を複数回受信しても在庫差分を1回だけ適用する | Retry/timeout | Integration test |
| NFR-REL-004 | Consistency | 在庫数量更新と監査履歴は同一の業務確定単位で成功または失敗する | 通常・障害注入 | Integration/Chaos |
| NFR-SEC-001 | Authentication | OIDC準拠の認証を用い、Owner/ManagerにはMFAを必須とする | Pilot/GA | Security test |
| NFR-SEC-002 | Authorization | すべてのデータ操作でTenant・店舗・役割をサーバー側で検証する | API/UI全経路 | ASVS-based test |
| NFR-SEC-003 | Data protection | 通信はTLS 1.2以上、保存データとバックアップは管理された鍵で暗号化する | 本番・Backup | Inspection/Test |
| NFR-SEC-004 | Audit | 認証、権限拒否、在庫変更、CSV、設定変更、Supportアクセスを監査し、原則1年オンライン・3年アーカイブ保持する | 本番 | Audit test |
| NFR-SEC-005 | Vulnerability | Critical既知脆弱性0件、Highは例外承認なしでRelease不可 | Release gate | SAST/SCA/DAST/Pentest |
| NFR-PRIV-001 | Privacy | Analyticsへ商品名、自由入力メモ、メールアドレス、氏名を送信しない | 全イベント | Schema test |
| NFR-UX-001 | Accessibility | 主要ユーザーフローはWCAG 2.2 Level AAを目標とし、キーボードのみで完了可能 | Login、一覧、更新、履歴、CSV | Automated + manual + screen reader |
| NFR-UX-002 | Responsive | 360 CSS px以上の幅で主要閲覧・更新を横スクロールなしで完了可能 | Smartphone portrait | Visual/E2E |
| NFR-UX-003 | Error recovery | エラーは原因、保存状態、保持された入力、次の行動をテキストで示す | 全主要操作 | Content/UAT |
| NFR-COMP-001 | Compatibility | GA時点のChrome、Edge、Safariの現行安定版と1世代前をサポートする | Desktop/mobile | Browser matrix |
| NFR-MAINT-001 | Maintainability | Must要件は要件IDから自動テスト・PR・Releaseへ追跡できる | CI/CD | RTM audit |
| NFR-FLEX-001 | Flexibility | Tenant単位Feature FlagでPilot/Beta/GAを制御し、全体再デプロイなしに無効化できる | Production | Release rehearsal |
| NFR-SAFE-001 | Safety | 100件超の一括変更はPreview、件数・影響・確認を必要とし、取消可能な履歴を残す | CSV/一括操作 | E2E/UAT |
| NFR-OBS-001 | Observability | 在庫更新失敗率、p95、権限拒否急増、監査失敗、CSV失敗をDashboard・Alertで確認可能 | Production | Ops test |

## 8.3 性能シナリオ

| Scenario | SLI | Target | Load/Data | Degradation |
|---|---|---|---|---|
| 店舗在庫一覧 | Time to interactive p95 | <= 2.0s | 50,000 SKU、200 concurrent | ページング・条件保持 |
| SKU検索 | Server p95 | <= 500ms | 部分一致、50,000 SKU | 入力停止後に検索、結果件数表示 |
| 在庫更新 | Confirm p95 | <= 1.0s | 50 updates/sec burst | Queueせず失敗を明示、再試行可能 |
| 監査履歴 | Server p95 | <= 1.5s | 3年、1,000万行相当の検証データ | 期間上限・ページング |
| CSV Preview | 10,000行 | <= 60s | UTF-8、規定列 | 非同期進捗・取消 |

## 8.4 信頼性・復旧

| 項目 | 要求 |
|---|---|
| Backup | 暗号化された増分バックアップを15分間隔、日次スナップショットを35日保持 |
| Restore | 四半期ごとに復元演習し、RPO/RTOと監査履歴整合を確認 |
| Partial failure | 監査記録に失敗した更新は確定させない |
| Unknown state | UIはタイムアウトを成功扱いせず、照会により確定状態を確認できる |
| Rollback | Feature Flagで新UI・機能をTenant単位停止。データ変更は互換性を保つ |

## 8.5 セキュリティ・プライバシー

| 領域 | 要求 |
|---|---|
| Threats | Tenant混同、IDOR、権限昇格、CSV式注入、悪性ファイル、Credential stuffing、監査改ざんを分析 |
| CSV | 規定拡張子・MIME・サイズ・列・文字コードを検証し、出力では表計算式として解釈される先頭文字を安全化 |
| Session | 失効、再認証、端末共有時のLogoutを定義。詳細はSecurity Spec |
| Support access | チケット、承認、期限、理由を伴う一時アクセスのみ。全操作監査 |
| Data minimization | 氏名・メール以外の個人情報を在庫データへ収集しない。自由入力へ個人情報を記載しない旨を表示 |
| Retention | ユーザーアカウントは契約中、退職時無効化。監査は契約・法務確認後に最終決定 |

## 8.6 アクセシビリティ

- すべての主要操作をキーボードで実施できる。
- Focusは可視で、Sticky headerやDialogに隠れない。
- 低在庫は色だけでなく、テキスト、アイコン、状態名で示す。
- 入力エラーは項目へ関連付け、Summaryから移動可能にする。
- Drag操作は必須にしない。
- 認証で記憶・パズルだけに依存しない。
- Mermaid図は補助情報とし、同内容を本文・表でも提供する。

## 8.7 運用・監視

| Signal | Alert | Initial response |
|---|---|---|
| Update failure rate | 5分で2%超 | 新規Rollout停止、依存・DB・Release確認 |
| p95 update latency | 10分で2秒超 | 負荷・DB・Lock確認 |
| Authorization deny anomaly | Tenant基準の5倍 | Security確認、攻撃・設定ミス切り分け |
| Audit write failure | 1件以上 | 書込系を安全側へ制限、原因調査 |
| CSV error spike | 1時間で50%超 | Template/Release確認、案内更新 |

---

# 9. UIデザイン / モックアップ

> **5W1H**: `Who` 店長・在庫担当・閲覧者 / `What` Dashboard、一覧、調整、履歴、CSV / `When` 通常・Loading・Empty・Error・Conflict / `Where` 360px以上のWeb / `Why` 保存状態と次の行動を明確化 / `How` 一貫した情報設計、状態表示、キーボード、確認・回復

## 9.1 UX原則

1. **最新性が分かる**: 数量だけでなく最終更新時刻・更新者・同期状態を示す。
2. **保存結果を曖昧にしない**: 成功、失敗、処理中、状態不明を別表示にする。
3. **誤更新を予防し回復できる**: 理由、差分、Preview、競合検知、履歴を備える。
4. **主要操作を店舗業務中でも短くする**: 店舗・検索条件を保持し、連続更新を支援する。
5. **色だけに依存しない**: 状態名、アイコン、テキストを併用する。

## 9.2 画面一覧

| Screen | 名称 | User | 目的 | 必須状態 | Related |
|---|---|---|---|---|---|
| SCR-001 | Login / MFA | 全員 | 安全な認証 | Loading, Error, Locked, Recovery | FR-001 |
| SCR-002 | Dashboard | 店長 | 全店舗の状況把握 | Loading, Empty, Partial data, Error | FR-012 |
| SCR-003 | 在庫一覧 | 全員 | 検索・絞込・状態確認 | Loading, Empty, Error, Stale | FR-004/008 |
| SCR-004 | 在庫調整Dialog | Manager/Staff | 数量・理由の更新 | Invalid, Conflict, Submitting, Unknown, Success | FR-005/006 |
| SCR-005 | 監査履歴 | Manager | 差異調査 | Loading, Empty, Error | FR-007 |
| SCR-006 | 低在庫一覧・閾値 | Manager/Staff | 発注候補確認 | Empty, Error | FR-008/009 |
| SCR-007 | CSV Import | Manager | Preview・修正・確定 | Uploading, Validating, Errors, Ready, Importing, Complete | FR-010 |
| SCR-008 | CSV Export | Manager | 条件付き出力 | Generating, Ready, Error | FR-011 |
| SCR-009 | User / Store settings | Owner/Manager | 権限・店舗管理 | Loading, Error, Confirm | FR-002/003 |

## 9.3 情報アーキテクチャ

```mermaid
flowchart TD
    LOGIN["Login / MFA"] --> DASH["Dashboard"]
    DASH --> INV["在庫一覧"]
    DASH --> LOW["低在庫"]
    DASH --> HIST["最近の更新"]
    INV --> ADJ["在庫調整"]
    INV --> ITEMH["SKU監査履歴"]
    LOW --> ADJ
    DASH --> CSV["CSV Import / Export"]
    DASH --> SET["店舗・ユーザー・閾値設定"]
    DASH --> HELP["Help / Support"]
```

## 9.4 SCR-004 在庫調整Dialog

| 観点 | 仕様 |
|---|---|
| 表示 | 店舗、SKU、商品名、現在数量、最終更新時刻、更新者 |
| 入力 | 「新数量」または「増減」をモード選択、理由コード、任意メモ |
| 確認 | 保存前に旧値→新値、差分、理由を表示 |
| Loading | ボタンを多重実行できない。処理中テキストを表示 |
| Invalid | 項目直下にエラー、先頭にSummary。入力を保持 |
| Conflict | 最新値・自身の入力・差分を表示し、再適用または取消を選択 |
| Unknown | 成功と表示せず、「状態を確認」操作を提供 |
| Success | 新数量、更新時刻、監査履歴へのリンクを表示 |
| Keyboard | Dialog内Focus trap、Escapeは未保存確認後に閉じる |
| Mobile | 360pxで主要情報・操作が1列。数値キーボードを利用可能 |

## 9.5 主要画面フロー

```mermaid
flowchart LR
    D["Dashboard"] --> I["在庫一覧"]
    I --> F["検索 / 絞込"]
    F --> A["在庫調整"]
    A --> V{"Valid?"}
    V -->|No| ER["エラー修正"]
    ER --> A
    V -->|Conflict| CF["最新値を比較"]
    CF --> A
    V -->|Yes| S["保存結果"]
    S --> H["監査履歴"]
```

## 9.6 マイクロコピー例

| 場面 | 悪い例 | 採用例 |
|---|---|---|
| 更新失敗 | エラーが発生しました | 在庫数は保存されていません。通信を確認し、「状態を確認」または「再試行」を選んでください。 |
| 競合 | 更新できません | 14:32に別のユーザーが数量を12から9へ変更しました。最新値を確認してから再入力してください。 |
| CSV | 取込失敗 | 248行目の「数量」が整数ではありません。確定前のため、在庫データは変更されていません。 |
| 権限 | Forbidden | この店舗の在庫を更新する権限がありません。閲覧は継続できます。店長へ権限を確認してください。 |

---

# 10. 技術スタック / アーキテクチャ概要

> **5W1H**: `Who` Product・Engineering・Security・Operationsが責任分界を合意 / `What` Web/PWA、認証、在庫サービス、監査、データ、外部連携 / `When` 通常更新、CSV処理、障害・再送・復旧時 / `Where` 利用者端末、日本国内クラウドリージョン、外部IdP・通知境界 / `Why` 在庫整合性、Tenant分離、運用可能性を満たす / `How` 高位構成と制約をPRDで固定し、API・DDL・クラウド詳細はProduct Spec／ADRへ委譲

## 10.1 PRDで確定する事項と委譲する事項

| 区分 | このPRDで確定 | Product Spec／Technical Specで確定 |
|---|---|---|
| Product boundary | Web/PWA、在庫台帳、監査、CSV、Dashboardを製品責務とする | コンポーネント分割、モジュール境界 |
| Data integrity | 在庫更新と監査記録を同一の業務確定単位で扱う | トランザクション方式、ロック、イベント方式 |
| Identity / Access | OIDC、Tenant・店舗・役割のサーバー側検証、Manager以上のMFA | IdP製品、Token詳細、Claim mapping |
| Availability / Recovery | 99.9%、RPO 15分、RTO 4時間 | Multi-AZ構成、Backup実装、復旧Runbook |
| Technology | Web標準、TypeScript中心、関係データベース、日本リージョンを候補方針とする | Framework、クラウドサービス、IaC、バージョン |
| Interfaces | IdP、メール、Analytics、Observability、CSV入出力の責務 | APIパス、Schema、Retry、Timeout、契約テスト |
| Security / Privacy | 暗号化、最小権限、監査、Analytics最小化 | Key管理、Network policy、Secret管理、詳細Threat model |

## 10.2 高位アーキテクチャ

```mermaid
flowchart LR
    subgraph Device["User Device / Untrusted"]
        B["Browser / Installable PWA"]
    end

    subgraph Product["StockLens Product Boundary"]
        EDGE["Web Entry / API Boundary"]
        APP["Inventory Application"]
        JOB["CSV / Notification Worker"]
        DB[("Relational Inventory DB")]
        OBJ[("Temporary CSV Object Store")]
        AUD[("Audit and Operational Logs")]
        FLAG["Tenant Feature Flags"]
    end

    subgraph External["External / Separate Trust Boundary"]
        IDP["OIDC Identity Provider"]
        MAIL["Email Provider"]
        OBS["Observability Platform"]
        ANA["Product Analytics"]
    end

    B -->|"TLS + authenticated request"| EDGE
    EDGE --> APP
    APP --> DB
    APP --> AUD
    APP --> FLAG
    APP --> JOB
    JOB --> OBJ
    JOB --> DB
    B --> IDP
    APP -->|"Minimum notification data"| MAIL
    APP --> OBS
    JOB --> OBS
    APP -->|"Pseudonymous events only"| ANA
```

## 10.3 コンポーネントと責任分界

| Component / System | 区分 | 責務 | オーナー | 主な入出力 | データ分類 | 障害時のProduct挙動 |
|---|---|---|---|---|---|---|
| Browser / PWA | Client | 表示、入力、状態提示、再認証 | Frontend | HTTPS request/response | 業務・認証情報 | 未保存入力を保持し、確定状態を推測しない |
| Web Entry / API Boundary | Product | TLS終端、Rate limit、Request routing | Platform | Authenticated request | 全区分 | 過負荷時は明示的な一時エラーを返す |
| Inventory Application | Product | 在庫・権限・閾値・監査の業務規則 | Backend | Commands / Queries | 業務データ | 在庫更新と監査を原子的に失敗させる |
| CSV / Notification Worker | Product | 非同期CSV検証・確定、通知 | Backend / Ops | Job / Result | 業務データ | 再実行可能にし、二重反映を防ぐ |
| Relational Inventory DB | Product | Tenant、店舗、SKU、在庫、履歴の正本 | Platform / Data | Transactional data | Confidential | 書込停止またはRead-onlyへ縮退 |
| Temporary CSV Object Store | Product | Upload後の一時保管 | Platform | CSV object | Confidential | 処理を停止し、再Uploadを案内 |
| OIDC Identity Provider | External | 認証、MFA、Account lifecycle | Security / IT | Token / Claims | Identity | 新規Login不可。既存Session方針はSpecで定義 |
| Email Provider | External | 招待・低在庫通知の配送 | Operations | Minimal message | Contact | 在庫操作は継続し、通知をRetry |
| Observability | External | Metrics、Logs、Traces、Alert | SRE | Telemetry | Operational | ローカルbuffer／代替AlertをSpecで定義 |
| Product Analytics | External | KPI用イベント集計 | Product Data | Pseudonymous event | Internal | 業務処理を止めず、欠損を可視化 |

## 10.4 候補技術と制約

> 候補はサンプルであり、採用決定ではない。最終決定は性能・運用・セキュリティ検証とADR承認後とする。

| ID | 候補／制約 | Status | 根拠・目的 | 影響 | 確定先 |
|---|---|---|---|---|---|
| CON-001 | React + TypeScriptによるResponsive Web/PWA | Candidate | 1コードベースでPC・Tablet・Smartphoneを扱う | Native固有機能はv1対象外 | ADR-001 |
| CON-002 | Node.js + TypeScript系Application runtime | Candidate | Frontendとの型・言語整合とチーム技能を仮定 | Runtime性能を負荷試験で確認 | ADR-002 |
| CON-003 | PostgreSQL互換の関係DB | Candidate | 在庫更新・監査・一意性・参照整合性が必要 | Schema設計とPartition方針が必要 | ADR-003 |
| CON-004 | AWS等の日本国内リージョン | Candidate constraint | 対象顧客のデータ所在期待を単純化 | DR範囲と費用に影響 | ADR-004 |
| CON-005 | OIDC準拠IdP | Product constraint | 認証を独自実装しない | Claim・Provisioning連携が必要 | SEC-SPEC-001 |
| CON-006 | CSVはUTF-8、RFC 4180互換のTemplateを正本 | Product constraint | 表計算との相互運用を明確化 | Excel互換性試験が必要 | DATA-SPEC-001 |
| CON-007 | Tenant分離は全Query／Commandで強制 | Security constraint | GRD-002を守る | Test・Code reviewの主要Gate | THREAT-001 |
| CON-008 | 在庫・監査正本の破壊的物理削除を通常UIから提供しない | Integrity constraint | 説明責任と復旧性 | Retention・匿名化を別途設計 | DATA-SPEC-002 |

## 10.5 主要インターフェース

| IF ID | 相手 | 目的 | 方向 | データ | 頻度／規模 | 失敗時挙動 | Security / Privacy | Owner |
|---|---|---|---|---|---|---|---|---|
| IF-001 | OIDC IdP | Login、MFA、Session確立 | Both | Subject、Tenant/Roleに必要なClaim | Login時 | Loginを失敗として明示。Local passwordへFallbackしない | Token検証、最小Claim | Security |
| IF-002 | Email Provider | 招待、低在庫Digest | Outbound | 宛先、Tenant表示名、件数、Deep link | 日次・少量 | Queue Retry。業務処理は継続 | 商品名を既定で本文に含めない | Operations |
| IF-003 | CSV Upload / Download | 初期移行、一括更新、出力 | Both | SKU、店舗、数量、閾値、Version | 最大50,000行／Fileの仮定 | Preview前は無反映。確定失敗時は全体結果を明示 | Virus scan、Size limit、期限付きURL | Engineering |
| IF-004 | Observability | SLI、Alert、Incident調査 | Outbound | Metrics、Structured log、Trace、Correlation ID | Continuous | Telemetry欠損を別Alert。業務処理とのCouplingを避ける | Secret、Token、自由入力を除外 | SRE |
| IF-005 | Product Analytics | KPI-003、操作Funnel | Outbound | Hash化Tenant/Store ID、Event、Duration、Result | Event-driven | Retry可能。欠損率を記録 | 商品名、氏名、メール、メモを禁止 | Product Data |

## 10.6 在庫更新の信頼境界と確定フロー

```mermaid
sequenceDiagram
    actor User as Store User
    participant UI as Web/PWA
    participant API as Inventory API
    participant Auth as Authorization
    participant DB as Inventory DB
    participant Audit as Audit Record

    User->>UI: 数量・理由を入力
    UI->>API: 調整Command + idempotency key + expected version
    API->>Auth: Tenant / Store / Roleを検証
    Auth-->>API: Allowed
    API->>DB: Transaction開始・Version確認
    alt Version conflict
        DB-->>API: Conflict + current version
        API-->>UI: 409 + 最新値 + 再入力案内
    else Valid
        API->>DB: 在庫を1回だけ更新
        API->>Audit: 同一Transactionで履歴を記録
        DB-->>API: Commit + new version
        API-->>UI: 確定数量・時刻・correlation ID
    end
```

## 10.7 データ分類・保持の概要

| Data | 例 | Classification | 正本 | 保持 | Analytics送信 | 主なAccess |
|---|---|---|---|---|---|---|
| Identity | 氏名、メール、Role、所属 | Confidential / Personal | IdP + User profile | 契約終了後の方針をPrivacy Specで確定 | No | 本人、Tenant admin、限定Support |
| Inventory master | SKU、商品名、店舗、閾値 | Confidential business | Inventory DB | 契約期間 + Export期間 | 商品名はNo、Hash IDのみ | 権限店舗ユーザー |
| Inventory balance | 現在数量、Version | Confidential business | Inventory DB | 契約期間 + Export期間 | Bucketのみ可 | 権限店舗ユーザー |
| Adjustment audit | 旧値、新値、理由、主体、時刻 | Restricted business | Audit store | 1年Online + 3年Archiveの暫定値 | No | Manager、Security、限定Support |
| CSV file | 一括取込元・出力 | Confidential business | Temporary object store | Uploadは処理完了後7日以内削除 | No | Upload者、Manager、Worker |
| Telemetry | Latency、Result、Correlation | Internal | Observability | 90日の暫定値 | N/A | Engineering / SRE |

## 10.8 参照仕様

- Product Spec: `docs/product-spec/stocklens-v1.md`
- API / Interface Spec: `docs/api/stocklens-openapi.yaml`
- Data Model / CSV Contract: `docs/data/stocklens-data-contract.md`
- Architecture Decision Records: `docs/adr/ADR-001..`
- Threat Model: `security/threat-model-stocklens-v1.md`
- Privacy Review: `privacy/stocklens-v1-review.md`
- Runbook / Disaster Recovery: `ops/runbooks/stocklens-v1/`

---

# 11. テスト計画 / QA戦略

> **5W1H**: `Who` Engineering・QA・Security・Design・Pilot店業務受入者 / `What` 在庫整合性、Tenant分離、主要Journey、NFR、計測 / `When` PR、CI、統合、Release Candidate、Pilot、GA後 / `Where` Local、CI、Staging、Performance環境、Pilot、本番Canary / `Why` 誤在庫・情報漏えい・復旧不能をRelease前に防ぐ / `How` Risk-based test、要件トレーサビリティ、障害注入、UAT、品質Gate

## 11.1 品質戦略

最優先の品質リスクは、(1) 誤った在庫数量、(2) 他Tenant／店舗への権限逸脱、(3) Retry・競合による二重更新、(4) CSVの部分反映、(5) 監査欠落、(6) 操作結果が不明なUIである。テスト件数やコードカバレッジだけを完成条件にせず、Must要件ごとに検証可能な受入基準と証跡を保持する。

```mermaid
flowchart LR
    R["Requirement / Risk"] --> AC["Acceptance Criteria"]
    AC --> AUTO["Automated Test"]
    AC --> MAN["Manual / UAT"]
    AUTO --> EVD["Evidence"]
    MAN --> EVD
    EVD --> GATE{"Release Gate"}
    GATE -->|Pass| CAN["Canary / Pilot"]
    GATE -->|Fail| FIX["Fix or approved exception"]
    CAN --> KPI["Production SLI / KPI"]
```

## 11.2 テストレベルと責任

| Test level | 主な対象 | 実施者 | 環境 | 自動化 | Entry条件 | Exit条件 | 証跡 |
|---|---|---|---|---|---|---|---|
| Unit / Property | 数量境界、理由、閾値、Role、CSV field | Engineering | CI | High | Requirement・business rule確定 | Must ruleの正常・境界・異常Pass | Test report |
| Contract | OIDC Claim、CSV Contract、Email、Analytics schema | Engineering / Security | CI | High | Interface contract version固定 | Consumer/Provider contract Pass | Contract report |
| Integration | DB transaction、Idempotency、Optimistic concurrency、Audit | Engineering / QA | Ephemeral env | High | Migration適用、fixture準備 | AC-006〜016相当のIntegration Pass | CI artifact |
| E2E | Login→検索→更新→履歴、CSV、権限 | QA / Engineering | Staging | Medium/High | RC deploy、Test data reset | Must journey 100% Pass | Video / screenshot / result |
| Performance | 50,000 SKU、200同時、更新・検索・CSV | Performance owner | Isolated perf env | High | Build固定、監視有効 | NFR-PERF/CAP達成 | Load report |
| Resilience / Recovery | DB failover、Retry、Backup restore、Telemetry欠損 | SRE / Engineering | Staging / DR env | Mixed | Runbook Draft、Backup取得 | RPO/RTO、Integrity要件達成 | Drill report |
| Security | Tenant isolation、RBAC、Session、SAST/SCA/DAST、ASVS観点 | Security / Engineering | CI / Staging | Mixed | Threat model更新 | Critical/High Gate達成 | Security report |
| Privacy | Analytics schema、Log redaction、CSV retention、Support access | Privacy / QA | CI / Staging | Mixed | Data inventory確定 | 禁止Data 0、レビュー承認 | Privacy checklist |
| Accessibility | Keyboard、Focus、Name/Role/Value、Contrast、Screen reader | Design / QA | Staging | Mixed | UI feature complete | 主要JourneyがNFR-UX-001達成 | Audit report |
| Browser / Responsive | Chrome、Edge、Safari、360px以上 | QA | Device / Browser lab | Mixed | Supported matrix確定 | Blocker 0 | Matrix result |
| UAT | 日常更新、棚卸し差異、低在庫、CSV | Pilot店舗 | Pilot | Manual | Training、Data import、Support ready | 5店舗中4店舗以上がMust journey承認、Blocker 0 | Signed UAT |
| Production verification | Smoke、SLI、Alert、Event、Audit | SRE / Product | Canary / Pilot | High | Rollout開始 | 監視窓でTrigger未超過 | Deployment evidence |

## 11.3 要求トレーサビリティマトリクス（抜粋）

| Objective | User Story | Requirement | Acceptance Criteria | Test Case | Evidence | Release | KPI / Guardrail |
|---|---|---|---|---|---|---|---|
| OBJ-003 | US-001 | FR-001 / NFR-SEC-001 | AC-001 | TC-E2E-AUTH-001 | CI + UAT | v1 | GRD-002 |
| OBJ-003 | US-001 | FR-002 / NFR-SEC-002 | AC-002, AC-011 | TC-SEC-TENANT-001..020 | Security report | v1 | GRD-002 |
| OBJ-001 | US-002 | FR-004 / NFR-PERF-001 | AC-004, AC-005 | TC-E2E-SEARCH-001 / TC-PERF-001 | E2E + Load | v1 | KPI-001 |
| OBJ-001/002 | US-003 | FR-005 / NFR-REL-004 | AC-006〜008 | TC-INT-ADJ-001..015 | Integration report | v1 | KPI-001/002 |
| OBJ-002/003 | US-003 | FR-006 / NFR-REL-003 | AC-009 | TC-INT-IDEMP-001..008 | Fault injection report | v1 | GRD-001/004 |
| OBJ-002 | US-004 | FR-007 / NFR-SEC-004 | AC-010, AC-011 | TC-E2E-AUDIT-001 / TC-SEC-007 | Audit report | v1 | KPI-004 |
| OBJ-001/002 | US-006 | FR-010 / NFR-SAFE-001 | AC-014〜016 | TC-CSV-001..030 | CSV report | v1 | GRD-001/003 |
| OBJ-003 | N/A | FR-013 / NFR-PRIV-001 | DATA-AC-001 | TC-DATA-SCHEMA-001 | Schema gate | v1 | KPI-003 |
| OBJ-003 | N/A | FR-014 / NFR-OBS-001 | OPS-AC-001 | TC-OPS-ALERT-001 | Alert drill | v1 | GRD-004 |

## 11.4 追加の受入基準

| ID | 対象 | Given | When | Then | 検証 |
|---|---|---|---|---|---|
| DATA-AC-001 | FR-013 | 全Analytics event schema | CIでSchema検査 | 商品名、氏名、メール、自由入力本文のFieldが0件 | Automated schema gate |
| OPS-AC-001 | FR-014 | Stagingで更新失敗を注入 | Alert条件を満たす | 5分以内にOn-call向けAlertとRunbook linkが生成 | Alert drill |
| REL-AC-001 | NFR-REL-002 | 検証用Backup | 復旧訓練 | 15分以内のRPO、4時間以内のRTOで整合性CheckをPass | Restore drill |
| A11Y-AC-001 | NFR-UX-001 | Keyboardのみ | Login→検索→在庫更新→履歴を実施 | Focusが失われず、全操作とError recoveryを完了 | Manual + screen reader |
| PERF-AC-001 | NFR-PERF-002 | 通常想定負荷 | 30分継続試験 | 更新p95≤1.0秒、p99≤2.5秒、Error<0.5% | Load test |

## 11.5 テストデータ

| Data set | 目的 | 規模 | 生成方法 | PII | リセット | Owner |
|---|---|---:|---|---|---|---|
| TD-001 Small deterministic | Unit・E2E | 2 Tenant、5店舗、1,000 SKU | Version管理Fixture | No | Test毎 | QA |
| TD-002 Boundary | 0、最大数量、Unicode、長い商品名、CSV異常 | 300 Case | Generator | No | Test毎 | Engineering |
| TD-003 Tenant isolation | Cross-tenant ID・Role組合せ | 20 Tenant、全Role | Synthetic | No | Suite毎 | Security |
| TD-004 Performance | Capacity・Concurrency | 10 Tenant、500,000 SKU | Seed generator | No | Run毎 | Performance owner |
| TD-005 Pilot import rehearsal | 実CSV互換性 | 5店舗分 | 顧客Dataを契約・Mask方針に従い別管理 | 原則No。必要時は承認 | Rehearsal後削除 | Data / Privacy |

## 11.6 欠陥重大度

| Severity | StockLensでの定義 | 例 | Release可否 | 目標対応 |
|---|---|---|---|---|
| Sev-1 | 情報漏えい、Tenant逸脱、不可逆Data損失、広範な誤在庫 | 他Tenant閲覧、二重更新で復元不能 | 不可、Rollout停止 | 即時Incident対応 |
| Sev-2 | 主要Journey不能、誤結果、監査欠落、代替策なし | 在庫更新不能、CSV部分反映 | 原則不可 | RC前修正・再検証 |
| Sev-3 | 一部機能不良、限定影響、回避策あり | 特定Filter、非主要Browserの表示不良 | 条件付き | Owner・期限・例外承認 |
| Sev-4 | 軽微な文言・視覚上の問題 | 誤字、非主要Spacing | 可 | Backlog化 |

## 11.7 Release品質Gate

- [ ] `Must`のFR/NFRに要件ID、受入基準、Test、証跡が100%紐付く。
- [ ] Must受入基準がすべてPassし、未実施・Blockedが0件。
- [ ] Sev-1／Sev-2が0件。Sev-3はProduct・QA・Ownerによる例外承認済み。
- [ ] NFR-PERF、REL、SEC、PRIV、UX、OBSのRelease対象値を満たす。
- [ ] Tenant isolation testが全Role・全主要APIでPassする。
- [ ] Backup restore、Read-only縮退、Feature Flag停止、Rollback rehearsalが完了する。
- [ ] Dashboard・Alert・Runbook・Support escalationが本番相当で検証済み。
- [ ] KPIイベントのSchema、発火、欠損率、Dashboard計算が検証済み。
- [ ] Pilot UATの必須Journeyが5店舗中4店舗以上で承認される。
- [ ] Security、Privacy、Accessibility、Operationsの必須Reviewを完了する。

---

# 12. スケジュール / マイルストーン

> **5W1H**: `Who` Product・Design・Engineering・QA・Security・Operations・Pilot店舗 / `What` PRD、Spec、Build、品質Gate、Pilot、Beta、GA、成果判定 / `When` 2026-08-18から2027-04-20 / `Where` 開発・Staging・5店舗Pilot・20店舗Beta / `Why` 基礎データ品質と運用を段階検証してから拡大 / `How` Milestone完了条件、依存関係、Feature Flag、明示的なGo/No-Goで進行

## 12.1 マイルストーン

| ID | マイルストーン | Owner | 開始 | 目標日 | 主要成果物 | 完了条件 | 状態 |
|---|---|---|---|---|---|---|---|
| MS-001 | Problem validation | Product Research | 2026-08-03 | 2026-08-14 | Evidence summary、Problem statement | 仮説・限界・Baseline計測計画をReview | Complete sample |
| MS-002 | PRD approval | Product | 2026-08-17 | 2026-08-18 | Approved PRD | Cross-functional blocking comment 0 | Complete sample |
| MS-003 | UX / Product Spec ready | Design / Engineering | 2026-08-19 | 2026-09-18 | Prototype、API/Data Spec、ADR、Threat model | Must要件を実装単位へ追跡、TBRのBlocker解消 | Planned |
| MS-004 | Feature complete | Engineering | 2026-09-21 | 2026-10-30 | Integrated RC0 | FR-001〜014実装、CI Gate Pass | Planned |
| MS-005 | Hardening / UAT ready | QA / SRE | 2026-11-02 | 2026-11-27 | RC1、Test report、Runbook、Training | Release品質GateのPilot項目Pass | Planned |
| MS-006 | Pilot readiness decision | Product / QA / Ops | 2026-11-30 | 2026-12-04 | GO/NO-GO `DEC-010` | 5店舗Data rehearsal、Support、Rollback準備 | Planned |
| MS-007 | 5-store Pilot | Product / Pilot stores | 2026-12-07 | 2027-01-05 | Pilot telemetry、UAT、Incident log | GRD-001/002維持、主要操作成功率・Support負荷を評価 | Planned |
| MS-008 | 20-store Beta | Product / Operations | 2027-01-06 | 2027-01-19 | Beta release | Pilot拡大Gate Pass、重大Incident 0 | Planned |
| MS-009 | GA readiness / Release | Head of Product | 2027-01-20 | 2027-01-20 | GA decision `DEC-020` | Release Gate Pass、Rollout計画承認 | Planned |
| MS-010 | 90-day outcome review | Product Analytics | 2027-01-21 | 2027-04-20 | KPI review、Next decision | KPI-001〜004とGuardrailの判定可能Data | Planned |

## 12.2 高位ロードマップ

```mermaid
gantt
    title StockLens v1 Sample Roadmap
    dateFormat  YYYY-MM-DD
    axisFormat  %Y-%m-%d

    section Discovery and Decision
    Problem validation              :done, d1, 2026-08-03, 2026-08-14
    PRD approval                    :milestone, m1, 2026-08-18, 0d

    section Product and Technical Specification
    UX prototype and usability      :s1, 2026-08-19, 2026-09-11
    Product Spec and ADR             :s2, 2026-08-24, 2026-09-18

    section Build and Verification
    Foundation auth tenant audit     :b1, 2026-09-21, 2026-10-09
    Inventory search and adjustment  :b2, 2026-09-28, 2026-10-23
    CSV dashboard observability      :b3, 2026-10-05, 2026-10-30
    Hardening security performance   :v1, 2026-11-02, 2026-11-27
    Pilot readiness                  :milestone, m2, 2026-12-04, 0d

    section Controlled Rollout
    Five store Pilot                 :p1, 2026-12-07, 2027-01-05
    Twenty store Beta                :p2, 2027-01-06, 2027-01-19
    GA                               :milestone, m3, 2027-01-20, 0d
    Outcome observation              :o1, 2027-01-21, 2027-04-20
```

## 12.3 クリティカル依存関係

| ID | 依存先 | 必要成果 | 必要日 | Owner | 状態 | 遅延影響 | 代替案 |
|---|---|---|---|---|---|---|---|
| DEP-001 | Pilot店舗 | SKU・店舗・RoleのSample CSV、業務責任者 | 2026-09-30 | Product Ops | Planned | CSV・権限UAT遅延 | Synthetic Dataで先行、Pilot日程再判定 |
| DEP-002 | Identity / IT | OIDC Test tenant、MFA、Claim contract | 2026-09-18 | Security | Planned | Login・RBAC実装Block | Mock IdPで開発、Pilot前に本番相当必須 |
| DEP-003 | Security / Privacy | Threat model、Data inventory、Retention判断 | 2026-10-16 | Security / Privacy | Planned | Release Gate未完了 | Feature縮小、Data保持を保守的に短縮 |
| DEP-004 | Operations | Alert routing、Runbook、On-call、Status communication | 2026-11-20 | SRE / Support | Planned | Pilot不可 | Pilot規模・時間帯を縮小 |
| DEP-005 | Browser / Device | Pilot店舗の端末・OS・Browser matrix | 2026-10-02 | QA | Planned | Compatibility漏れ | Managed loaner deviceを用意 |
| DEP-006 | Analytics | Event schema、Dashboard、Data quality check | 2026-11-13 | Product Data | Planned | Outcome判定不能 | 作業日誌・Auditから補完、GA拡大を保留 |

## 12.4 日程の信頼度

| 項目 | Sample判断 |
|---|---|
| 見積もり方法 | Must要件をCapability単位に分解し、類似Web業務アプリの仮想実績とBottom-upを併用 |
| P50 | 2027-01-20 GA |
| P80 | 2027-02-10 GA |
| 最大の不確実性 | Pilot CSV品質、Tenant/Roleの例外、CSV一括処理、店舗端末差 |
| Buffer | Hardening 4週、Pilot拡大前に明示Gate、Should要件を切離し可能にする |
| 再見積もり条件 | Must追加、NFR変更、外部IdP契約変更、Sev-1/2、Pilot Data準備2週超遅延 |

---

# 13. リスクと課題（Risks & Issues）/ 想定される障壁

> **5W1H**: `Who` 各Risk ownerと影響店舗 / `What` Data品質、競合、採用、権限、損失、Network、Support、Scope / `When` Spec・移行・Pilot・GA時 / `Where` CSV、在庫更新、Tenant境界、店舗Network、運用体制 / `Why` 不完全Data、同時操作、技能差、外部依存 / `How` Trigger監視、予防、縮退、Rollback、Owner付き対応

## 13.1 リスク登録簿

| ID | リスク事象 | P | I | Score | 兆候／Trigger | 予防・低減 | 発生時対応 | Owner | 残余 |
|---|---|---:|---:|---:|---|---|---|---|---|
| RISK-001 | 店舗CSVの列・文字コード・重複・数量品質が低く、移行が遅延または誤反映する | 4 | 4 | 16 | Preview error行>5%、手修正>60分/店舗 | Template、Preflight validator、Sample rehearsal、確定前Preview | 取込停止、店舗別修正Guide、Manual staged import | Product Ops / Eng | Medium |
| RISK-002 | 複数人の同時更新やRetryで数量が上書き・二重反映される | 3 | 5 | 15 | Conflict率急増、同一Correlationの重複 | Version check、Idempotency key、Transaction、Fault test | Write停止、Auditから影響特定、補正・再発防止 | Engineering | Low/Med |
| RISK-003 | IT技能差や現行習慣により利用が定着せず、KPIを測定できない | 4 | 4 | 16 | WA Store<50%、Support>1件/店/週 | 30分Onboarding、店舗Champion、既存作業に沿う導線 | Pilot延長、対象Journey縮小、UX改善 | Product / Customer Success | Medium |
| RISK-004 | Tenant・店舗・Roleの検証漏れにより無許可DataへAccessできる | 2 | 5 | 10 | 権限拒否異常、Security test fail | Server-side policy、deny-by-default、Cross-tenant suite、Review | Rollout停止、Session revoke、Incident response | Security / Engineering | Low |
| RISK-005 | 在庫更新・監査・Backup不備により復元不能なData損失が起きる | 2 | 5 | 10 | Audit gap、Restore drill fail、DB error | Atomic commit、Backup、Restore drill、Soft-delete、Read-only mode | Write停止、Backup復旧、影響通知、Root cause | SRE / Engineering | Low |
| RISK-006 | 店舗Networkが不安定で、更新結果が不明になり再操作が増える | 4 | 3 | 12 | Timeout>1%、Unknown state問い合わせ | Idempotency、明示状態確認、軽量UI、Retry設計 | Read-only表示、状態照会、Offline queueは将来検討 | Engineering / Design | Medium |
| RISK-007 | CSV・権限・Onboarding問い合わせが想定以上でSupportが逼迫する | 3 | 3 | 9 | GRD-003超過、応答遅延 | In-product help、Error copy、Admin guide、Support playbook | Cohort拡大停止、Office hour、FAQ優先修正 | Support / Product | Medium |
| RISK-008 | POS、会計、AI予測などの要求がv1へ混入し、品質・日程を圧迫する | 4 | 3 | 12 | Must追加、Spec再作業>10%、日程P80超過 | In/Out合意、Change control、Opportunity backlog | Scope freeze、Should延期、GA再見積もり | Product | Low/Med |

## 13.2 前提条件

| ID | 前提 | 根拠 | 信頼度 | 検証 | Owner | 期限 | 誤りの場合 |
|---|---|---|---|---|---|---|---|
| ASM-001 | 5店舗が2026-12-07からPilot参加可能 | 口頭合意というSample仮定 | Medium | 参加確認書と担当者確定 | Product Ops | 2026-09-30 | Pilot日程・母数を再計画 |
| ASM-002 | 各店舗がSKU・店舗・数量をCSVで提供できる | 現行Excel利用という仮定 | Medium | 早期Sample import | Product Ops | 2026-09-30 | Manual onboarding／Scope縮小 |
| ASM-003 | 主要端末で現行Browserまたは1世代前を利用できる | 一般的環境という仮定 | Low | Device survey | QA | 2026-10-02 | Support matrix・端末支援を変更 |
| ASM-004 | 理由コード10種類以内でPilot業務の80%以上を表現できる | Interview仮説 | Low | Card sorting + Pilot log | Product / Design | 2026-09-11 | 理由分類と自由記述方針を再設計 |
| ASM-005 | 低在庫は店舗・SKU単位の固定閾値で初期価値を提供できる | v1単純化 | Medium | Usability test / Pilot | Product | 2027-01-05 | 店舗別Rule拡張を優先化 |

## 13.3 現在の課題・障害

| ID | 課題 | 影響 | 暫定対応 | 恒久対応 | Owner | 期限 | 状態 |
|---|---|---|---|---|---|---|---|
| ISSUE-001 | Pilot店舗の端末・Browser情報が未収集 | Compatibility test matrixが未確定 | Chrome/Edge/Safari標準Matrixで先行 | Device survey完了後にMatrix凍結 | QA | 2026-10-02 | Open |
| ISSUE-002 | 実CSVの列名・文字コード差が未確認 | CSV Contractの再作業可能性 | Canonical Templateで実装開始 | 5店舗SampleをPreflight | Product Ops | 2026-09-30 | Open |

## 13.4 未解決事項／TBR

| ID | 暫定判断 | 解消方法 | Decision owner | Owner | 期限 | Block対象 | 状態 |
|---|---|---|---|---|---|---|---|
| TBR-001 | Auditは1年Online・3年Archive | 契約、法務、顧客期待、費用をReview | Security / Legal | Product | 2026-10-16 | NFR-SEC-004 | Open |
| TBR-002 | 低在庫通知は日次Email Digest | User testで頻度・内容・Opt-outを検証 | Product | Design | 2026-09-11 | Notification Spec | Open |
| TBR-003 | CSV最大50,000行／File | 実Data分布と負荷試験で確定 | Engineering | Performance owner | 2026-10-16 | IF-003 / NFR-CAP | Open |
| TBR-004 | Support accessは時間制限付きImpersonationなしのRead-only | Support journeyとThreat modelで確定 | Security | Support / Eng | 2026-10-16 | Support Spec | Open |
| TBR-005 | GAは2027-01-20、成果KPI最終判定は2027-04-20 | Pilot leading indicatorsとGuardrailで初期GA、90日でScale判断 | Head of Product | Product | 2027-01-20 | GA decision | Open |

## 13.5 Risk review cadence

```mermaid
flowchart LR
    ID["Identify / Update"] --> SCORE["Score P x I"]
    SCORE --> TOL{"Score >= 12 or Safety/Security?"}
    TOL -->|Yes| MIT["Mitigation + Trigger + Contingency"]
    TOL -->|No| MON["Accept and Monitor"]
    MIT --> OWN["Named owner and due date"]
    MON --> OWN
    OWN --> REV["Weekly through Pilot; monthly after GA"]
    REV --> ID
```

---

# 14. 承認フロー / ステークホルダー

> **5W1H**: `Who` Product owner、Head of Product、Business、Design、Engineering、QA、Security、Privacy、Operations、Pilot代表 / `What` Problem、PRD、Spec、Security/Privacy、Pilot、GA、重大変更 / `When` 各Gateと承認後のMaterial change時 / `Where` Git Pull Request、Decision record、Review会議 / `Why` 責任、例外、手戻り、監査証跡を明確化 / `How` RACI、Blocking分類、Gate checklist、署名・再承認

## 14.1 ステークホルダー

| Stakeholder | 役割 | 関心・成功条件 | 決定権 | 主な参加 |
|---|---|---|---|---|
| Head of Product | 最終Accountable | 戦略、投資、GA、停止判断 | GA、Outcome continuation | PRD / Pilot / GA |
| Product Manager | PRD・価値・Scope owner | KPI、優先順位、Evidence | Scope内のProduct判断 | 全Phase |
| Business Sponsor | Business value | ROI、対象市場、顧客期待 | Business条件 | PRD / GA |
| Product Design | UX / Accessibility | 業務適合、操作性、Error recovery | Design recommendation | Discovery〜UAT |
| Engineering Lead | Delivery / Technical integrity | 実現性、Data integrity、Maintainability | Product Spec / ADR | PRD〜Operations |
| QA Lead | Verification owner | Traceability、Defect、Release quality | Quality Gate recommendation | Spec〜GA |
| Security / Privacy | Risk owner | Tenant分離、Data protection、Privacy | Security/Privacy Gate | Spec〜Operations |
| SRE / Operations | Reliability owner | SLI、Recovery、Runbook、On-call | Operational readiness | Build〜GA |
| Support / Customer Success | Adoption / Support | Onboarding、問い合わせ、Playbook | Support readiness | UAT〜GA |
| Pilot Store Representative | Business UAT | 日常業務で使えること | UAT accept/reject | Prototype / Pilot |

## 14.2 RACI

| 成果物／判断 | Head Product | Product | Business | Design | Engineering | QA | Sec/Privacy | Ops | Pilot rep |
|---|---|---|---|---|---|---|---|---|---|
| Problem / Outcome | A | R | C | C | C | I | I | I | C |
| PRD | A | R | C | C | C | C | C | C | I |
| UX / Accessibility | I | A | I | R | C | C | C | I | C |
| Product Spec / ADR | I | C | I | C | A/R | C | C | C | I |
| Threat / Privacy review | I | C | I | C | R | C | A/R | C | I |
| Verification / RTM | I | C | I | C | R | A/R | C | C | I |
| Pilot readiness | I | A/R | C | C | C | R | C | R | C |
| Pilot UAT | I | A | I | C | C | R | I | C | R |
| GA decision | A | R | C | C | C | C | C | C | I |
| Incident stop / rollback | I | C | I | I | R | C | C | A/R | I |

> `R`: Responsible、`A`: Accountable、`C`: Consulted、`I`: Informed。

## 14.3 承認Gate

| Gate | 対象 | 必須Review | Approver | 完了条件 | Evidence | 目標日 |
|---|---|---|---|---|---|---|
| G1 | PRD | Product、Business、Design、Engineering、QA、Security、Ops | Head of Product | Blocking 0、Must・KPI・Out of Scope合意 | PRD PR + DEC-001.. | 2026-08-18 |
| G2 | Product Spec ready | Design、Engineering、QA、Security、Privacy、Ops | Engineering Lead + Product | API/Data/UX/ADR/Threat model、RTM更新 | Spec PRs | 2026-09-18 |
| G3 | Pilot readiness | QA、Security、Privacy、Ops、Support、Pilot rep | Product Manager | 11.7 Gate、Data rehearsal、Rollback、Training | DEC-010 | 2026-12-04 |
| G4 | Beta expansion | Product、QA、Ops、Support | Head of Product | GRD-001/002=0、Sev-1/2=0、leading use/support閾値 | Pilot report | 2027-01-05 |
| G5 | GA | Product、Business、QA、Security、Ops | Head of Product | Release Gate、Operational readiness、Known risk受容 | DEC-020 | 2027-01-20 |
| G6 | 90-day Scale | Product、Business、Data | Head of Product | KPI-001〜004、Guardrail、Unit economicsの判断可能性 | Outcome review | 2027-04-20 |

## 14.4 Review・異議・変更管理

1. Commentは `Blocking / Major / Minor / Question` に分類する。
2. Blockingは要件ID、Evidence、影響、推奨代案を含める。
3. 合意できない場合はAccountableが選択肢、Trade-off、判断理由を `DEC-xxx` として記録する。
4. 承認後、次の変更はMaterial changeとして影響分析と再承認を行う。
   - Primary KPI、Guardrail、Must／Out of Scopeの変更
   - Tenant分離、Data retention、Availability、RPO/RTOの緩和
   - 目標リリースが10営業日超変動
   - 新しい外部Data recipientまたは機微Dataの追加
5. 軽微な文言・明確化はPR Reviewで処理するが、Requirement意味を変えてはならない。

## 14.5 承認記録（サンプル）

| Role | 判断 | 日付 | 条件・コメント | Evidence |
|---|---|---|---|---|
| Head of Product | Approve sample | 2026-08-18 | 実案件ではEvidenceと数値を置換すること | `DEC-SAMPLE-001` |
| Product Manager | Approve sample | 2026-08-18 | ScopeとKPIの責任を受領 | PRD v1.0.0-sample |
| Engineering Lead | Conditional sample | 2026-08-18 | Candidate技術はADRで確定 | `DEC-003` |
| QA Lead | Approve sample | 2026-08-18 | RTMを実装中も更新 | `qa/rtm/stocklens-v1.csv` |
| Security / Privacy | Conditional sample | 2026-08-18 | TBR-001/004をG2までに解消 | Review checklist |

---

# 15. 今後の拡張（Future Enhancements）

> **5W1H**: `Who` Pilot／GA利用者とProduct strategy owner / `What` POS、Barcode、Offline、Transfer、AI予測、多言語 / `When` v1成果・利用規模・Data品質のTrigger後 / `Where` 店舗現場、外部業務System、新市場 / `Why` 転記削減、Network耐性、最適化、Scale / `How` Opportunityとして再検証し、新Product Brief／PRDへ昇格。v1の約束にはしない

## 15.1 Opportunity Backlog

| ID | 将来機会 | 対象 | 想定価値 | 現在対象外の理由 | 再評価Trigger | 検証 | 依存 |
|---|---|---|---|---|---|---|---|
| FUT-001 | POS売上・返品との在庫連携 | 店長・Staff | 二重入力削減、最新性向上 | POS製品差と契約・整合性Risk | PilotでCSV作業>30分/週の店舗が50%以上 | 上位2 POSとのDiscovery | Partner API、Data contract |
| FUT-002 | Barcode scanによるSKU検索・棚卸し | Staff | 入力速度・誤選択改善 | Camera/Scanner UX未検証 | Mobile利用率>40%、検索時間が主要負担 | Prototype usability | Barcode master、Device permission |
| FUT-003 | Limited offline queue | Network不安定店舗 | 更新継続性 | Conflict・二重更新・端末Data保護が複雑 | Unknown state率>1%またはRISK-006顕在化 | Offline simulation | Sync protocol、Device security |
| FUT-004 | 店舗間在庫移動Workflow | 多店舗Manager | 移動中在庫と責任を明確化 | v1の基本台帳定着前 | 3店舗以上Tenantが30%、要望上位3 | Process research | Dual approval、Transit state |
| FUT-005 | 需要予測・発注提案AI | Owner / Buyer | 欠品・過剰在庫削減 | 販売履歴・Data品質・説明性が不足 | 12か月Data、差異率<2%、POS連携済み | Backtest + controlled trial | Sales data、Model monitoring |
| FUT-006 | 多言語・多通貨 | 海外店舗 | 市場拡大 | 初期市場外、法規・UX差 | 海外商談・契約可能性 | Market discovery | Localization、Tax/legal |

## 15.2 将来像

```mermaid
flowchart LR
    V1["v1: Trusted inventory ledger"] --> V2["vNext: Faster capture and integrations"]
    V2 --> V3["Cross-store workflows"]
    V3 --> V4["Forecasting and decision support"]
    Q["Data quality + adoption + safety gates"] --> V2
    Q --> V3
    Q --> V4
```

## 15.3 現行設計で守る境界

| 将来可能性 | v1で守る境界 | 今は実装しない | 過剰設計防止条件 |
|---|---|---|---|
| POS連携 | 在庫Commandと外部Source IDを拡張可能にする | Vendor connector、双方向同期 | Discoveryと契約前は作らない |
| Offline | Idempotency、Version、状態照会を確立 | Local write queue、Conflict merge UI | RISK-006 Trigger前は作らない |
| AI予測 | 時系列の変更時刻・理由・Data qualityを保持 | Model、Feature store、自動発注 | 予測価値・Safety条件を別PRDで承認 |
| 多言語 | UI文言をCodeから分離 | 翻訳、Locale別Format、通貨 | 対象市場決定前は翻訳しない |

---

# 16. 参考資料 / 添付文書

> **5W1H**: `Who` Product ownerがCatalogを維持し、各発行元・Ownerを記録 / `What` User evidence、業務記録、Design、Spec、Standard / `When` 取得日・版・対象期間を固定 / `Where` Git、Research repository、正本URL / `Why` 要件・数値・判断の根拠を追跡 / `How` Ref IDで引用し、信頼度・制約・更新確認を残す

## 16.1 Evidence Catalog

| Ref ID | 資料 | 種別 | Owner / 発行元 | 日付・版 | 保管場所 | 使用箇所 | 信頼度・制約 |
|---|---|---|---|---|---|---|---|
| REF-001 | Pilot候補店インタビュー記録（架空） | Research | Product Research | 2026-08 sample | `research/interviews/` | EVD-001、Personas、HYP | Medium、標本5 |
| REF-002 | 在庫作業日誌（架空） | Measurement | Pilot stores | 2026-08 sample | `research/baseline/time-study.csv` | KPI-001 | Medium、自己申告 |
| REF-003 | 棚卸し差異Dataset（架空） | Measurement | Pilot stores | 2026-08 sample | Restricted research store | KPI-002 | Low、2店舗 |
| REF-004 | UX Prototype / Test report（架空） | Design | Product Design | 2026-09-11予定 | `design/stocklens/` | SCR、AC、NFR-UX | 未実施 |
| REF-005 | Product Spec / ADR | Specification | Engineering | 2026-09-18予定 | `docs/product-spec/` | 10章、FR/NFR実装 | 未作成 |
| REF-006 | Threat model / Privacy review | Assurance | Security / Privacy | 2026-10-16予定 | `security/`, `privacy/` | NFR-SEC/PRIV | 未作成 |
| REF-007 | RTM / Test reports | Verification | QA | 2026-11-27予定 | `qa/rtm/`, CI artifacts | 11章、Release Gate | 未作成 |
| REF-008 | Pilot outcome report | Outcome | Product Data | 2027-04予定 | `reports/outcomes/` | KPI判定 | 未作成 |

## 16.2 公式資料・標準

| Ref ID | 資料 | このPRDでの利用 |
|---|---|---|
| STD-001 | ISO/IEC/IEEE 29148:2018 | 要求工学、要件情報項目、Life cycle上の追跡 |
| STD-002 | ISO/IEC 25010:2023 | 非機能要件の品質観点 |
| STD-003 | W3C WCAG 2.2 | Web accessibilityの成功基準 |
| STD-004 | OWASP ASVS 5.0.0 | Web application security verificationの観点 |
| STD-005 | NIST SP 800-218 SSDF | Secure development practiceをSDLCへ統合 |
| STD-006 | NIST Privacy Framework | Privacy riskの特定・管理 |

> 正本URLと調査時点は、同梱の `SOURCES.md` に記載する。

## 16.3 関連成果物

- Product Brief: `docs/brief/stocklens-v1.md`
- User Research Plan / Report: `research/stocklens-v1/`
- UX Specification / Prototype: `design/stocklens-v1/`
- Product Spec: `docs/product-spec/stocklens-v1.md`
- API / Data Contract: `docs/api/`, `docs/data/`
- ADR: `docs/adr/`
- Threat Model / Security Review: `security/stocklens-v1/`
- Privacy Review: `privacy/stocklens-v1/`
- RTM / Test Plan / Test Report: `qa/stocklens-v1/`
- Runbook / DR / Support Guide: `ops/stocklens-v1/`
- Release Notes / Outcome Review: `releases/stocklens-v1/`, `reports/outcomes/`

---

# Appendix A. 要求トレーサビリティの全体像

```mermaid
flowchart LR
    PROB["Problem / Evidence"] --> OBJ["OBJ-001..003"]
    OBJ --> KPI["KPI / Guardrail"]
    OBJ --> US["US-001..008"]
    US --> FR["FR-001..014"]
    FR --> AC["AC / Data AC / Ops AC"]
    FR --> NFR["NFR-* quality constraints"]
    AC --> TC["Test Cases"]
    NFR --> TC
    TC --> EVD["Test Evidence"]
    EVD --> REL["Pilot / Beta / GA"]
    REL --> KPI
    RISK["Risk / Assumption / TBR"] --> FR
    RISK --> REL
```

## A.1 主要要件の追跡確認

| Check | 結果（サンプル） |
|---|---|
| Must ObjectiveにKPIまたはGuardrailがある | Pass |
| Must User StoryにFRとACがある | Pass |
| Must FRに少なくとも1つの検証方法がある | Pass |
| Critical NFRに測定値・条件・検証がある | Pass |
| Release GateからTest evidenceへ辿れる | Pass |
| Release後にOutcome metricへ戻る | Pass |

---

# Appendix B. Rollout / Rollback Plan

## B.1 段階Rollout

| Stage | Cohort | Feature Flag | Entry | 観測窓 | Exit / Expand |
|---|---|---|---|---|---|
| Internal | 開発・QA Tenant | `stocklens_v1=internal` | CI Gate Pass | 5営業日 | Sev-1/2 0、Smoke安定 |
| Pilot wave 1 | 2店舗 | `stocklens_v1=pilot-a` | G3承認 | 3営業日 | Write success≥99.5%、Audit gap 0 |
| Pilot wave 2 | 追加3店舗 | `stocklens_v1=pilot-b` | Wave 1安定 | Pilot終了まで | GRD-001/002=0、Support閾値内 |
| Beta | 20店舗 | `stocklens_v1=beta` | G4承認 | 14日 | Operational Gate、Known risk受容 |
| GA | 対象契約Tenant | `stocklens_v1=ga` | G5承認 | 継続 | 90日Outcome review |

## B.2 停止・Rollback Trigger

| Trigger | 閾値 | 即時Action | Owner |
|---|---|---|---|
| Tenant／店舗権限逸脱 | 1件以上 | Rollout停止、Session revoke、Incident response | Security |
| 不可逆Data損失またはAudit gap | 1件以上 | Write停止、Read-only、影響範囲特定 | SRE / Engineering |
| 在庫更新失敗・不明状態率 | 15分で2%以上 | Cohort拡大停止、必要ならFeature disable | SRE |
| 在庫更新p95 | 30分で3秒超 | 拡大停止、Capacity調査 | SRE |
| Sev-1／Sev-2 | 未解決1件以上 | Release／拡大停止 | QA / Product |
| Support負荷 | 1件／店舗／週超が2週 | Cohort拡大停止、UX／Guide修正 | Support / Product |

## B.3 Rollback原則

1. Feature Flagで新規書込を停止し、必要に応じてRead-only閲覧・Exportを維持する。
2. Application versionのRollbackとData correctionを分離する。古いApplicationが新Schemaと互換であることを事前検証する。
3. 在庫・監査の不整合が疑われる場合、盲目的にBackup全復元せず、Correlation IDとAuditで影響範囲を確定する。
4. Full restoreが必要な場合はRPO/RTOに従い、復元後にTenant別件数・Balance・Audit continuityを照合する。
5. 顧客通知は、影響、保存状態、回避策、次回更新を明確にする。原因未確定時に断定しない。

```mermaid
flowchart TD
    ALERT["Trigger detected"] --> STOP["Pause rollout / disable writes"]
    STOP --> SCOPE["Determine affected tenants, stores, commands"]
    SCOPE --> CHOICE{"Integrity affected?"}
    CHOICE -->|No| APP["Rollback application / config"]
    CHOICE -->|Yes| DATA["Reconcile audit or restore data"]
    APP --> VERIFY["Smoke + SLI + audit verification"]
    DATA --> VERIFY
    VERIFY --> DEC{"Safe to resume?"}
    DEC -->|No| RO["Remain read-only and continue incident"]
    DEC -->|Yes| RESUME["Controlled cohort resume"]
```

---

# Appendix C. PRD Ready / Release Ready Checklist

## C.1 PRD Ready（2026-08-18 Sample）

- [x] Problem、対象User、Evidenceの限界が記載されている。
- [x] Primary KPI、Guardrail、定義、観測窓、失敗時判断がある。
- [x] In Scope／Out of Scope、Must／Shouldが明確である。
- [x] User Story、FR、NFR、Acceptance CriteriaがIDで追跡できる。
- [x] Loading、Empty、Error、Conflict、Unknown、Successを考慮した。
- [x] Risk、Assumption、TBR、DependencyにOwnerと期限がある。
- [x] Architecture境界とProduct Specへの委譲範囲が明確である。
- [x] Pilot、Beta、GA、90日Outcomeの判断Gateが分離されている。

## C.2 Release Ready（実装後に判定）

- [ ] Must AC 100% Pass。
- [ ] Critical NFR 100% Pass。
- [ ] Tenant isolation、Data integrity、Restore drill、Rollback rehearsal Pass。
- [ ] Sev-1／Sev-2 0件。
- [ ] Security、Privacy、Accessibility、Operations承認。
- [ ] KPI Event・Dashboard・Data quality検証完了。
- [ ] Pilot UAT、Training、Support、Runbook完了。
- [ ] Known riskと例外がOwner・期限付きで承認済み。

---

# Appendix D. 16項目と5W1Hの対応表

| # | PRD項目 | Who | What | When | Where | Why | How |
|---:|---|---|---|---|---|---|---|
| 1 | ドキュメント情報 | Product owner・承認者 | PRD版・変更 | 作成・更新・Release | Git正本 | 最新版と責任を明確化 | PR・履歴・Decision log |
| 2 | 製品概要 | 店長・在庫担当 | 在庫問題と価値 | 入荷・棚卸し・発注時 | 店舗Web/PWA | 工数・差異削減 | 単一台帳・監査・低在庫 |
| 3 | 目標・成果指標 | Product・Pilot店舗 | 工数・差異・採用・安全 | 30/60/90日 | Pilot/GA Data | 成功・失敗判定 | 作業日誌・棚卸し・Telemetry |
| 4 | Target user / Persona | Owner・Manager・Staff・Viewer | Goal・Pain・権限 | 日常業務時 | PC/Tablet/Mobile | User中心設計 | Persona・JTBD・Journey |
| 5 | Scope / Features | 全Stakeholder | In/Out、Must/Should | v1、将来 | Product boundary | Scope creep防止 | Priority・Decision rule |
| 6 | Use case / Story | 各Role | 達成したいTask | Trigger時 | 主要画面 | User価値と文脈 | Story・Flow・Exception |
| 7 | 機能要件 | Engineering・QA・Product | 認証、在庫、監査、CSV | Request・Retry・障害時 | UI/API/Data | 一意な実装・検証 | FR ID・AC・Traceability |
| 8 | 非機能要件 | Eng・SRE・Security・QA | 性能、信頼性、安全等 | Release前・稼働中 | Client/Cloud/Boundary | 総合品質保証 | 数値閾値・条件・Test |
| 9 | UI / Mockup | User・Design・QA | 画面・状態・文言 | 操作開始〜回復 | Browser/PWA | 誤操作・手戻り削減 | Flow・State・Microcopy |
| 10 | Architecture概要 | Engineering・Security・Ops | 境界・Data・Interface | 通常・障害・復旧 | Device/Cloud/External | Integrity・責任分界 | 高位図・制約・Spec委譲 |
| 11 | Test / QA | QA・Eng・Sec・Pilot | RequirementとRisk | CI〜本番確認 | Test env・Pilot | Release判断 | RTM・自動/手動・Gate |
| 12 | Schedule | Owner・各Team | Milestone・成果物 | 2026-08〜2027-04 | Dev/Pilot/Beta/GA | 順序と期待値調整 | Entry/Exit・依存・段階Rollout |
| 13 | Risk / Issues | Risk owner | Risk・Assumption・TBR | Trigger時・週次 | 業務・技術・組織 | 不確実性管理 | Score・Mitigation・Contingency |
| 14 | Approval / Stakeholder | RACI各Role | 承認対象・権限 | 各Gate・重大変更 | PR・Decision record | 責任・証跡・例外管理 | RACI・Gate・再承認 |
| 15 | Future enhancement | 将来User・Product | POS、Offline、AI等 | Trigger達成後 | 店舗・外部System・新市場 | 長期価値 | Opportunity検証・別PRD |
| 16 | References | Author・発行元・利用者 | Evidence・Spec・Standard | 取得日・版 | 正本URL・Repository | 判断根拠と再現性 | Ref ID・信頼度・版固定 |

---

# End of Sample PRD
