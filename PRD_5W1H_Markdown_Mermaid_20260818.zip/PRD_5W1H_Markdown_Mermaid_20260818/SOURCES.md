# 調査・検証メモと公式資料

- 調査基準日: **2026-08-18（JST）**
- 対象: 添付元資料の16項目を維持しながら、現行のPRD、要求工学、品質、セキュリティ、プライバシー、アクセシビリティ、トレーサビリティの実務へ適合させる
- 注意: 本書の採点は、下記資料と実務上のTrade-offに基づく設計判断であり、各発行元が公表した比較点数ではない

---

## 1. 結論

採用案は、**「Outcome中心のPRD + Product Spec／UX Spec／ADR／Test／Runbookへの明示的な分離 + 要件IDによる双方向トレーサビリティ」**である。

元資料の16章はStakeholder間の共通理解に有効なため維持した。一方、PRDへAPI、DDL、Class、Cloud resourceなどの実装詳細を詰め込み過ぎると、変更頻度の異なる情報が一文書で競合する。そこで、PRDは主として `Why / Who / What / 成功条件 / 品質・制約 / 意思決定` を確定し、`How exactly` はリンクされた仕様へ委譲する。

また、次を補強した。

1. Problem evidence、Why Now、仮説、非目標
2. KPI定義、Baseline、Target、観測窓、Data source、Guardrail
3. User storyとAcceptance Criteriaの分離
4. 一意なRequirement ID、根拠、優先度、検証方法
5. Functional requirementとNon-functional requirementの測定可能化
6. `OBJ → US → FR/NFR → AC → TC → Code/PR → Release → KPI` のRTM
7. Assumption、Risk、Issue、Dependency、TBRの分離
8. Rollout、Rollback、Release gate、運用・Support readiness
9. RACI、承認証跡、Material changeの再承認
10. 16項目すべての5W1H対応

---

## 2. 方式比較

### 2.1 評価軸と重み

| 評価軸 | 重み | 判断内容 |
|---|---:|---|
| Business / User alignment | 20% | Problem、Outcome、User value、Successの共有 |
| 要求の明確性 | 15% | Scope、Requirement、Acceptanceの曖昧さを抑える |
| 責任境界 | 15% | PRDと詳細設計の役割が混ざらない |
| Verification / Traceability | 20% | RequirementからTest、Release、Outcomeへ追跡可能 |
| 保守性・Agility | 15% | 変更時の差分、再利用、簡潔性 |
| Risk / Governance | 15% | Security、Privacy、運用、承認、監査への適合 |

### 2.2 採点

| 方式 | Alignment | 明確性 | 責任境界 | 検証・追跡 | 保守性 | Governance | 加重総合 |
|---|---:|---:|---:|---:|---:|---:|---:|
| A. すべてを1つの巨大PRDへ記載 | 90 | 82 | 45 | 80 | 45 | 88 | **73.0** |
| **B. Outcome中心PRD + 連携仕様 + RTM** | **92** | **92** | **95** | **95** | **90** | **93** | **92.9** |
| C. Product BriefとBacklogだけで運用 | 75 | 72 | 90 | 50 | 92 | 45 | **69.9** |

### 2.3 判断理由

- **Aは網羅的だが、正本が肥大化しやすい。** Business outcomeとAPI／Cloud詳細の更新周期が異なるため、承認済みPRDが頻繁な実装変更に引きずられる。
- **Bは目的と実装の境界が明確で、最も追跡性が高い。** PRDを共通契約として維持しつつ、Product Spec、ADR、Test、Runbookを各専門家が更新できる。
- **Cは小さな改善には速いが、高リスク機能や複数Stakeholderでは不足しやすい。** Acceptance、NFR、Risk、Release readiness、監査証跡がTicketへ散在する。

**推奨**: Standard案件はBを使用する。低リスクの小規模改善ではBのLean版、規制・安全・機微Dataを扱う案件ではBのHigh-assurance版を使用する。

---

## 3. 主要な検証結果と反映内容

| 観点 | 調査結果 | テンプレートへの反映 |
|---|---|---|
| PRDの役割 | Purpose、Feature、Behavior、Goal、Assumption、User story、Design、Out-of-scopeを共有し、過度に詳細化しない | 16章を維持しつつ、冒頭でPRD境界を定義 |
| PRDの必要要素 | Outcome、Success measure、Stakeholder、Persona、Scope、Release、Design、Assumption、Risk、Constraint、Dependencyが一般的 | 2〜5、12〜16章へ明示 |
| Product Specとの分離 | Product SpecはPRDで定義済みのProblem／Requirementを「どのように作るか」へ具体化 | 10章で高位境界だけを残し、API／DDL／Cloud詳細を委譲 |
| User story | User storyはOutcomeを簡潔に表し、詳細Requirementは対話後に追加する | Story、Use case、Exception、Linked FRを分離 |
| Acceptance Criteria | Complete／Acceptedとみなすための事前定義された明確・測定可能な条件 | KPIとは別にGiven/When/Then形式のACを用意 |
| Requirement quality | Clear、unambiguous、concise、rationale、assumption、verifiable、TBR管理が重要 | FR/NFR表、品質Checklist、TBR owner・期限・解消方法 |
| Requirements engineering | Life cycle全体のRequirement processと情報項目を扱う | Document lifecycle、変更管理、Traceability、Approvalを強化 |
| Quality model | ISO/IEC 25010:2023は9つのProduct quality characteristicsを定義 | NFRを9特性で点検し、条件・閾値・検証を記載 |
| Traceability | RequirementとTest、Bug、Code change、Deploymentの関連がReadiness評価に有効 | RTMとID体系を追加 |
| Accessibility | WCAG 2.2のSuccess CriteriaはTestableでTechnology-neutral | Major journey、Level AA target、Keyboard／Screen reader検証 |
| Web security | OWASP ASVSはWeb technical security controlの検証基盤 | Security NFR、Threat model、Verification gate |
| Secure development | NIST SSDFはSecure practiceを各SDLCへ統合する枠組み | CI、SAST/SCA/DAST、Review、Release gateへ統合 |
| Privacy | NIST Privacy FrameworkはPrivacy riskの識別・管理を支援 | Data inventory、Analytics最小化、Retention、Privacy review |
| Markdown / Mermaid | GitHub Markdownは`mermaid` fenced blockでDiagramをRendering可能 | Flowchart、Sequence、State、Ganttを補助図として収録 |

---

## 4. 公式・一次資料

### 4.1 Product Requirements / Product Management

1. **Atlassian — What is a Product Requirements Document (PRD)?**  
   https://www.atlassian.com/agile/product-management/requirements  
   反映: Goal、Assumption、User story、Design、Out-of-scope、簡潔性、共同更新。

2. **Atlassian — User Stories With Examples and a Template**  
   https://www.atlassian.com/agile/project-management/user-stories  
   反映: User storyをOutcome中心の簡潔な単位とし、Requirement／Acceptanceと分離。

3. **Atlassian — What is Acceptance Criteria?**  
   https://www.atlassian.com/work-management/project-management/acceptance-criteria  
   反映: 明確・測定可能な完成条件、Given／When／Then、各Storyへの関連付け。

4. **Productboard — Product Requirements Document Guide**  
   https://www.productboard.com/blog/product-requirements-document-guide/  
   反映: Quantitative／Qualitative success、Risk／Dependency、Release／Rollout notes。

5. **Productboard — Product Requirements Document Glossary**  
   https://www.productboard.com/glossary/product-requirements-document/  
   反映: Outcome、Measure、Stakeholder、Persona、Scope、Release、Design、Assumption、Risk、Constraint、Dependency。

6. **Productboard — Product Spec Template**  
   https://www.productboard.com/blog/product-spec-template/  
   反映: PRDはProblem／Requirement、Product SpecはImplementation blueprintという責任分離。

### 4.2 Requirements Engineering / Quality / Traceability

7. **ISO/IEC/IEEE 29148:2018 — Requirements engineering**  
   https://www.iso.org/standard/72089.html  
   調査時点: 2024年にReview・Confirmされ、2026-08-18時点でCurrentと表示。  
   反映: Requirement process、情報項目、Life cycle、Traceability、変更管理。

8. **NASA — Appendix C: How to Write a Good Requirement**  
   https://www.nasa.gov/reference/appendix-c-how-to-write-a-good-requirement/  
   反映: Clear／Unambiguous／Concise、Rationale、Assumption、TBD最小化、TBRのOwner・期限・解消方法。

9. **ISO/IEC 25010:2023 — Product quality model**  
   https://www.iso.org/standard/78176.html  
   反映: 9つのQuality characteristicsによるNFR completeness check。

10. **Microsoft Learn — End-to-end traceability / RTM**  
    https://learn.microsoft.com/en-us/azure/devops/cross-service/end-to-end-traceability?view=azure-devops  
    反映: RequirementとTest、Bug、Code change、DeploymentのAssociation、Delivery readiness。

### 4.3 Accessibility / Security / Privacy

11. **W3C — Web Content Accessibility Guidelines (WCAG) 2.2**  
    https://www.w3.org/TR/WCAG22/  
    反映: Technology-neutralでTestableなSuccess Criteria、主要JourneyのAccessibility verification。

12. **OWASP — Application Security Verification Standard (ASVS)**  
    https://owasp.org/www-project-application-security-verification-standard/  
    反映: Web application technical security controlとSecure development requirementのVerification basis。

13. **NIST SP 800-218 — Secure Software Development Framework 1.1**  
    https://csrc.nist.gov/pubs/sp/800/218/final  
    反映: Secure practiceをSDLC、CI、Review、Release gateへ統合。

14. **NIST — Privacy Framework**  
    https://www.nist.gov/privacy-framework  
    反映: Privacy risk identification／management、Data inventory、Retention、Privacy review。  
    注意: 調査時点のNIST pageはPrivacy Framework 1.1をInitial Public Draftとして案内しているため、組織標準で採用するVersionは内部承認時に固定する。

### 4.4 Markdown / Mermaid

15. **GitHub Docs — Creating diagrams**  
    https://docs.github.com/en/get-started/writing-on-github/working-with-advanced-formatting/creating-diagrams  
    反映: `mermaid` language identifierを持つFenced code blockによるDiagram記述。

---

## 5. 適用上の注意

1. **テンプレートを全項目必須と誤解しない。** Product riskと組織規模に応じ、Lean／Standard／High-assuranceを選ぶ。
2. **Sampleの数値を実案件へ流用しない。** Baseline、Target、SLA、RPO/RTO、Retention、Browser matrixはEvidence・契約・Risk assessmentで確定する。
3. **Standard名だけでComplianceを主張しない。** 対象Requirement、Control、Test evidence、Exception、Ownerを紐付ける。
4. **Mermaid図を正本にしない。** 数値、権限、Failure behavior、Acceptance、Approvalは本文・表にも残す。
5. **PRDを一度承認して凍結しない。** Major changeは影響分析・再承認し、Minor clarificationもHistoryへ残す。
6. **OutcomeとOutputを混同しない。** 「機能をReleaseした」はOutputであり、工数・差異・AdoptionなどのOutcomeを別に測る。
7. **Acceptance CriteriaとDefinition of Doneを混同し過ぎない。** ACはStory／Requirement固有の受入条件、DoDはTeam／Increment共通の品質条件として併用する。

---

# End of Research Notes
