# PRD 5W1H Markdown＋Mermaid パッケージ

- 作成基準日: 2026-08-18（JST）
- 形式: GitHub Flavored Markdown + Mermaid
- 目的: プロダクトの「なぜ作るか」「誰に何を提供するか」「成功をどう判定するか」を、実装・検証・運用まで追跡可能な形で合意する

## 収録ファイル

| ファイル | 内容 |
|---|---|
| `01_PRD_Template_5W1H.md` | 汎用PRDテンプレート。各章に5W1H、記入欄、Mermaidひな形、品質チェックを含む |
| `02_PRD_Sample_Inventory_5W1H.md` | 小規模小売店向けリアルタイム在庫管理Webアプリの記入サンプル |
| `SOURCES.md` | 調査に使用した一次資料・公式資料、方式比較、テンプレートへ反映した要点 |
| `VALIDATION_REPORT.md` | 章構造、5W1H、Markdown、表、Mermaid block、ID範囲の検証結果 |
| `SHA256SUMS.txt` | 同梱ファイルの改ざん・転送確認用SHA-256（ZIP作成時に生成） |

## この版で採用した設計原則

1. **元資料の16章構成を維持**  
   ドキュメント情報、製品概要、目標、ユーザー、スコープ、ユースケース、機能要件、非機能要件、UI、技術概要、QA、日程、リスク、承認、将来拡張、参考資料を残しています。

2. **PRDとProduct Specを分離**  
   PRDは主として `Why / Who / What / 成功条件` を定義します。API詳細、データモデル、クラス設計、具体的なクラウド構成などの `How exactly` は、PRD承認後にProduct Spec、Technical Spec、ADRへ記載します。PRD内の技術章は、制約・境界・主要インターフェース・参照リンクに限定します。

3. **成果指標と受入基準を分離**  
   成果指標はリリース後に「価値が出たか」を測り、受入基準はリリース前に「要求どおり作れたか」を判定します。

4. **要件を一意に識別し、双方向に追跡**  
   `OBJ-xxx → US-xxx → FR/NFR-xxx → AC-xxx → TC-xxx → Code/PR → Release → KPI` の関連を維持します。

5. **曖昧語を排除し、検証可能にする**  
   「高速」「使いやすい」「十分」「適切」ではなく、対象条件、測定方法、閾値、時間窓、例外を記載します。未確定値は `TBD` のまま放置せず、`TBR` として責任者・解消期限・解消方法を登録します。

6. **非機能要件を品質モデルから漏れなく検討**  
   ISO/IEC 25010:2023の9特性を確認軸にし、WebではWCAG 2.2、セキュリティではOWASP ASVSとNIST SSDF、個人データではNIST Privacy Frameworkを必要に応じて参照します。

7. **Markdownだけで読めることを優先**  
   Mermaid図は理解を補助するものであり、重要な要件・数値・承認条件は必ず表または本文にも記載します。

## 推奨ワークフロー

```mermaid
flowchart LR
    A["Problem / Evidence"] --> B["Product Brief"]
    B --> C["PRD Draft"]
    C --> D{"Cross-functional Review"}
    D -->|差戻し| C
    D -->|承認| E["Product Spec / UX / ADR"]
    E --> F["Build & Verify"]
    F --> G{"Release Gate"}
    G -->|未達| F
    G -->|達成| H["Rollout"]
    H --> I["Measure Outcomes"]
    I --> J{"Continue / Iterate / Stop"}
    J -->|改善| C
```

## 文書の深さを選ぶ

| 運用モード | 適用例 | 最低限残す章 |
|---|---|---|
| Lean | 小規模改善、単一チーム、低リスク | 1〜8、11、13、14、16。10・12はリンクまたは要約で可 |
| Standard | 新機能、複数職種、外部連携あり | 原則として全16章 |
| High-assurance | 規制、高リスク、個人情報、安全・セキュリティ重要 | 全16章 + 完全なRTM、監査証跡、脅威・プライバシー・安全分析、独立承認 |

## 使い方

1. `01_PRD_Template_5W1H.md` を複製し、角括弧のプレースホルダーを置換します。
2. まず問題・証拠・ユーザー・成果指標を合意し、その後にスコープと要求を確定します。
3. `FR/NFR/AC` のIDは、一度発行したら再利用しません。廃止時は削除せず `Deprecated` と履歴を残します。
4. 各要求に、根拠、優先度、検証方法、依存関係、担当者を結び付けます。
5. 承認後に詳細なProduct Spec、UX仕様、API仕様、データ仕様、ADR、テストケースへ分解します。
6. リリース後はKPIの実測値を追記し、継続・改善・撤退を判断します。

## 表記規則

| 種別 | 推奨ID | 例 |
|---|---|---|
| 目的 | `OBJ-xxx` | `OBJ-001` |
| 成果指標 | `KPI-xxx` / `GRD-xxx` | `KPI-001`, `GRD-001` |
| ユーザーストーリー | `US-xxx` | `US-004` |
| 機能要件 | `FR-xxx` | `FR-012` |
| 非機能要件 | `NFR-<分類>-xxx` | `NFR-PERF-001` |
| 受入基準 | `AC-xxx` | `AC-021` |
| テスト | `TC-xxx` | `TC-E2E-007` |
| リスク | `RISK-xxx` | `RISK-005` |
| 前提 | `ASM-xxx` | `ASM-003` |
| 未解決事項 | `OQ-xxx` / `TBR-xxx` | `OQ-004`, `TBR-002` |
| 意思決定 | `DEC-xxx` | `DEC-008` |

