# Pochi Test Orchestrator - 高度な統合ガイド

## ⚠️ 注意事項

このドキュメントは、通常のCLI運用とは異なる高度な統合方法について説明します。

**基本的な使用方法については、以下のドキュメントを参照してください：**
- [README.md](../README.md) - 概要と標準運用手順
- [INSTALLATION.md](./INSTALLATION.md) - インストールガイド
- [QUICKSTART.md](./QUICKSTART.md) - 3ステップガイド

---

## Claude Code CLI統合（実験的機能）

### 概要

Claude Code CLIを使用している環境では、プロジェクト内に存在する`SKILL.md`を自動検出し、自然言語によるキーワードトリガでSkillを起動できます。

**重要**: この機能は実験的なものです。問題が発生した場合は、[README.md](../README.md)に記載されているCLI標準手順にフォールバックしてください。

### 前提条件

- Claude Code CLIがインストール済み
- プロジェクト内に`skills/pochi-test-orchestrator/SKILL.md`が存在
- **重要**: ワークスペースは**プロジェクトルート直下**で開いてください（`skills/`ディレクトリが直下に見える状態）
- **重要**: SKILL.mdの`Do`セクションに、**環境変数`POCHI_SKILL_ACTIVE=1`付きの実行コマンド**が明記されている必要があります

### 使用方法

Claude Code CLIで以下のようなキーワードを使用すると、Skillが自動起動します：

```
「テストケースを生成して」
「パターン3で更新」
「品質チェック実行」
```

### 動作の仕組み

1. Claude Code CLIがプロジェクト内の`skills/*/SKILL.md`を検索
2. 見つかったSkillの「自動トリガ条件」をチェック
3. ユーザーの発言がキーワードにマッチすれば自動起動
4. Skillに定義された処理を実行

### 自動トリガキーワード（参考）

以下のキーワードが検出対象となります：

**テストケース操作系**:
- 「テストケース生成」「テストケース更新」「テストケース作成」
- 「再生成」「全体再生成」

**パターン指定系**:
- 「パターン1」「パターン2」「パターン3」「パターン4」
- 「Pattern1」「Pattern2」「Pattern3」「Pattern4」

**前提生成系**:
- 「app_structure」「app_structure.md」
- 「copilot_summary」「copilot_summary.md」
- 「diffs」「差分生成」「Git差分」

**検証系**:
- 「品質チェック」「品質レポート」「quality_gate」

### メリット

- 自然言語で指示できるため、コマンドを覚える必要がない
- キーワード検出で自動起動するため、手動でスクリプトを実行する手間が省ける

### 制約事項

1. **設定は不要だが、動作は環境依存**
   - Claude Code CLIのバージョンによって動作が異なる可能性があります

2. **デバッグが困難**
   - 問題が発生した場合、CLI標準手順と比較してトラブルシューティングが難しくなります

3. **完全な制御ができない**
   - パラメータの細かい指定（例: `--dry-run`、`--from`/`--to`の指定）が難しい場合があります

### トラブルシューティング

#### 問題: Skillが起動しない

**確認事項**:
```bash
# SKILL.mdが存在するか確認
ls -la skills/pochi-test-orchestrator/SKILL.md

# プロジェクトルートで実行しているか確認
pwd
```

**解決策**: CLI標準手順にフォールバック
```bash
python skills/pochi-test-orchestrator/scripts/orchestrator.py --mode auto
```

#### 問題: 意図しないパターンで実行される

**解決策**: パラメータを明示的に指定
```bash
python skills/pochi-test-orchestrator/scripts/orchestrator.py --mode pattern3
```

#### 問題: エラーメッセージが不明瞭

**解決策**: ログを確認
```bash
cat logs/run_log.txt
cat test-cases/last_run_summary.json
```

---

## VS Code拡張機能との統合（将来対応予定）

現時点では、VS Code拡張機能との直接統合はサポートしていません。

将来的に以下のような統合を検討中：
- Task定義によるワンクリック実行
- Problem Matcherによるエラーの可視化
- Output Channelへのリアルタイムログ表示

実装された場合は、このドキュメントで案内します。

---

## CI/CD統合

GitHub ActionsなどのCI/CD環境では、CLI標準手順を使用してください。

詳細は以下を参照：
- [OPERATIONS_RUNBOOK.md](./OPERATIONS_RUNBOOK.md) - 運用ガイド
- `.github/workflows/pochi-skill-dryrun.yml` - GitHub Actions設定例

---

## サポート

Claude Code CLI統合に関する問題が発生した場合：

1. **まず、CLI標準手順で動作するか確認**
   ```bash
   python skills/pochi-test-orchestrator/scripts/orchestrator.py --mode auto
   ```

2. **ログを確認**
   ```bash
   cat logs/run_log.txt
   cat test-cases/last_run_summary.json
   ```

3. **開発チームSlackで質問**
   - 「Claude Code CLI統合」であることを明記
   - ログファイルを添付
   - CLI標準手順での動作結果も併記

---

## まとめ

Claude Code CLI統合は便利な機能ですが、以下の点に注意してください：

- ✅ **基本はCLI標準手順を使用**する
- ⚠️ **問題発生時はCLI標準手順にフォールバック**する
- 📝 **詳細な制御が必要な場合はCLI標準手順を使用**する

標準的な使用方法については、[README.md](../README.md)を参照してください。
