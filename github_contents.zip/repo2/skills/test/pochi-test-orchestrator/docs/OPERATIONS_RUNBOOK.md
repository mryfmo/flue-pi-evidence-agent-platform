# Pochi Test Orchestrator - 運用ランブック

## 📅 ゴーライブ計画

### Day 0（導入当日）

#### 1. 環境確認

```bash
# Python・Gitの確認
python --version  # 3.8以上
git --version

# Skillディレクトリの確認
ls -la skills/pochi-test-orchestrator/SKILL.md
```

**期待結果**: Python 3.8以上、Git利用可能、SKILLディレクトリ存在

#### 3. スモークテスト実施

VERIFICATION_GUIDE.mdに従って順次実行:

1. **FullIntegration** - 全機能結合テスト網羅作成
2. **PartialIntegration** - 対象機能の結合テスト追加
3. **FullScenario** - 全機能シナリオテスト網羅作成

**所要時間**: 約30分

#### 4. CI連携確認

1. テストブランチ作成
2. PR作成
3. GitHub Actions実行確認
   - quality_report.mdのArtifacts化
   - last_run_summary.jsonのArtifacts化
   - PRコメント自動投稿

#### 5. 設定値の固定

`config/default_config.json`を現場合意の値に設定:

```json
{
  "target_total": 125,
  "ratios": {
    "basic": 0.6,
    "boundary": 0.2,
    "abnormal": 0.15,
    "other": 0.05
  },
  "ui_coverage_threshold": 0.9,
  "ambiguous_limit": 3,
  "concrete_value_threshold": 0.95
}
```

---

### Week 1-2（ソフトゲート期）

#### 目的
- CIは`continue-on-error`のまま運用
- quality_reportの指摘をレビュー必須項目にする
- マージブロックはしない（警告のみ）

#### メトリクス収集

2スプリント分のデータを収集:

1. **UI要素網羅率**
   - 目標: ≥ 0.9
   - 計測方法: last_run_summary.json の `ui_coverage_ratio`

2. **具体値率**
   - 目標: ≥ 0.95
   - 計測方法: 曖昧表現数 / 総記述数

3. **観点比率達成率**
   - 目標: 各観点で ≥ 0.8
   - 計測方法: last_run_summary.json の `perspective_counts`

4. **再生成回数**
   - 目標: 平均 ≤ 2回/PR
   - 計測方法: PR内でのorchestrator実行回数

5. **レビュー指摘件数**
   - 計測項目: 「観点不足」「曖昧表現」「UI未カバー」
   - 目標: 毎スプリント減少傾向

#### 週次レビュー

- メトリクスダッシュボードの確認
- しきい値の妥当性検証
- チームフィードバックの収集

---

### Week 3以降（ハードゲート移行）

#### 品質ゲートの厳格化

`.github/workflows/pochi-skill-dryrun.yml`を更新:

```yaml
- name: Run Quality Gate (Strict Mode)
  run: |
    python skills/pochi-test-orchestrator/scripts/quality_gate.py
    exit_code=$?
    if [ $exit_code -ne 0 ]; then
      echo "::error::品質ゲート不合格。quality_report.mdを確認してください。"
      exit 1
    fi
```

#### 失敗条件（例）

- UI網羅率 < 0.9
- 具体値率 < 0.95
- テストケース総数 < 125
- 曖昧表現 > 3件
- 観点比率が目標値の80%未満

#### 例外運用

緊急リリース時はラベルでバイパス:

```yaml
- name: Check bypass label
  if: contains(github.event.pull_request.labels.*.name, 'release-hotfix')
  run: echo "品質ゲートをバイパスします"
```

---

## 📋 日次・定期運用

### 日次/PRごとの作業

#### 1. テストケースの更新実行

```bash
# 追加・変更機能の結合テストを追加
POCHI_SKILL_ACTIVE=1 \
POCHI_PATTERN_SELECTION=partial_integration \
POCHI_TARGET_DIR=<対象リポジトリパス> \
POCHI_PARTIAL_SCOPE="<追加・変更機能の説明>" \
python -m core.orchestrator
```

**注記**: `POCHI_PARTIAL_SCOPE` に追加・変更した機能を具体的に記述してください。

#### 2. 品質レポート確認

```bash
# レポート表示
cat test-cases/quality_report.md

# サマリ確認
cat test-cases/last_run_summary.json | python -m json.tool
```

**確認項目**:
- ✅ バックアップが作成されている
- ✅ 観点比率が目標範囲内
- ✅ UI網羅率が基準以上
- ✅ 曖昧表現が上限以下

#### 3. 不足点の是正

quality_report.mdの改善指示に従って:

1. 不足観点のテストケース追加
2. 曖昧表現を具体値に修正
3. 未カバーUI要素のテスト追加

#### 4. 次のアクション確認

last_run_summary.jsonの`next_action`を確認:

```json
{
  "next_action": "UI要素「検索ボタン」のテストケースを追加してください"
}
```

---

### 週次作業

#### 1. 設定の見直し（30分）

**config/default_config.json**:

```bash
# チーム指摘を反映
# 例: 「保存」が曖昧語として誤検出される場合
vim config/default_config.json
# ambiguous_termsから「保存」を削除
```

**調整例**:
- `ambiguous_terms`: 誤検出が多い語を削除
- `ui_match_thresholds`: 部分一致の閾値調整
- `target_total`: プロジェクト規模に応じて調整

#### 2. トップ原因の改善（1時間）

失敗/警告のトップ原因を1件改善:

**例1: 観点の偏り**
```bash
# 境界観点が不足している場合
# プロンプトテンプレートに具体例を追加
vim prompts/generate_test_cases_prompt.md
```

**例2: UI要素未カバー**
```bash
# app_structure.mdを更新
python tools/app_structure_analyzer.py
```

#### 3. メトリクスレビュー

```bash
# 週次サマリ生成（スクリプト化推奨）
find test-cases -name "last_run_summary.json" -mtime -7 | \
  xargs cat | jq '.quality_gate' | \
  python -c "import sys, json; data = [json.loads(line) for line in sys.stdin]; print(json.dumps(data, indent=2))"
```

---

### 月次作業

#### 1. バージョン更新（30分）

**SKILL.mdの更新**:

```markdown
# バージョン履歴

## v1.1.0 (2026-02-13)
- 曖昧語リスト更新（「保存」を削除）
- UI要素マッチング閾値を0.7→0.75に調整
- 対応ドキュメント: test-case-generation-guide.md v2.1
```

**Gitタグ付け**:
```bash
git tag -a v1.1.0 -m "Pochi Test Orchestrator v1.1.0"
git push origin v1.1.0
```

#### 2. CIしきい値の見直し（1時間）

誤検知が多い項目の閾値を再調整:

```yaml
# .github/workflows/pochi-skill-dryrun.ymlの更新
# 例: UI網羅率を0.9→0.85に暫定緩和
```

**手順**:
1. 過去1ヶ月のCI失敗ログを分析
2. 誤検知パターンを特定
3. しきい値または検証ロジックを調整
4. チームに変更を周知

#### 3. ドキュメント同期確認

```bash
# 対応ドキュメントバージョンの確認
grep -r "test-case-generation-guide" skills/pochi-test-orchestrator/

# 差分検知時の警告追加（将来実装）
```

---

## 🚨 インシデント対応プレイブック

### インシデント1: 生成物上書き事故

**症状**: test_cases.mdが誤って上書きされた

**復旧手順**:

1. **最新バックアップの特定**
   ```bash
   ls -lt test-cases/test_cases.md.bak.* | head -1
   ```

2. **復元**
   ```bash
   LATEST_BACKUP=$(ls -t test-cases/test_cases.md.bak.* | head -1)
   cp "$LATEST_BACKUP" test-cases/test_cases.md
   ```

3. **差分再適用**
   ```bash
   # Pattern3で差分のみ再適用
   python skills/pochi-test-orchestrator/scripts/orchestrator.py --mode pattern3
   ```

**予防策**:
- Pattern4実行時は必ず二重確認
- 定期的なGitコミット

---

### インシデント2: app_structure_analyzer.py未検出

**症状**: "app_structure_analyzer.pyが見つかりません"

**診断**:
```bash
# guidelines/tools/ 配下に app_structure_analyzer.py があるか確認
ls /path/to/pochi-test-orchestrator/guidelines/tools/app_structure_analyzer.py
```

**復旧手順**:

1. **ガイドラインリポジトリの確認**
   ```bash
   ls tools/app_structure_analyzer.py
   ```

2. **再クローン（必要な場合）**
   ```bash
   cd /path/to/parent
   git clone https://github.com/your-org/pochi-test-guidelines.git
   ```

3. **パス設定の確認**
   ```bash
   # utils.pyのfind_app_structure_analyzer関数が正しく動作するか
   python -c "from skills.pochi-test-orchestrator.scripts.utils import find_app_structure_analyzer; print(find_app_structure_analyzer())"
   ```

---

### インシデント3: CI失敗が多発

**症状**: PRの80%以上で品質ゲート失敗

**トリアージ**:

1. **失敗項目の抽出**
   ```bash
   # last_run_summary.jsonから失敗理由を集計
   find .github -name "last_run_summary.json" | \
     xargs jq '.quality_gate.issues_count' | \
     awk '{sum+=$1} END {print "Total issues:", sum}'
   ```

2. **トップ原因の特定**
   ```bash
   # quality_report.mdから共通パターンを抽出
   grep "⚠️\|❌" test-cases/quality_report.md
   ```

**対応**:

1. **ソフトゲートへ一時戻す**
   ```yaml
   # .github/workflows/pochi-skill-dryrun.yml
   - name: Run Quality Gate
     run: |
       python skills/pochi-test-orchestrator/scripts/quality_gate.py
     continue-on-error: true  # 追加
   ```

2. **config調整**
   ```json
   {
     "target_total": 100,  // 125→100に暫定緩和
     "ui_coverage_threshold": 0.85  // 0.9→0.85に緩和
   }
   ```

3. **1週間以内に原因是正**
   - プロンプト改善
   - UI要素定義の見直し
   - しきい値の再設定

---

## 📊 変更管理とリリースノート

### セマンティックバージョニング

- **v1.0.0**: 本番初版（2026-01-13）
- **v1.1.x**: 非破壊改善（辞書/閾値追加、品質ゲート強化）
- **v2.0.0**: 破壊的変更（パス仕様や生成フォーマット変更時）

### リリースノートテンプレート

```markdown
# v1.1.0 - 2026-02-13

## 新機能
- UI要素マッチングの精度向上

## 改善
- 曖昧語リスト更新（誤検出削減）
- しきい値の最適化

## バグ修正
- Pattern4のバックアップ失敗を修正

## 対応ドキュメント
- test-case-generation-guide.md v2.1
- testing-handbook.md v1.5

## 移行ガイド
- config/default_config.jsonの更新が必要
- 既存プロジェクトは再生成推奨
```

### 変更時の手順

1. **SKILL.mdに対応ドキュメントバージョン記載**
   ```markdown
   ## 対応ドキュメント

   - test-case-generation-guide.md v2.1 (commit: abc1234)
   - testing-handbook.md v1.5 (commit: def5678)
   ```

2. **差分検知警告（将来実装）**
   ```python
   # ドキュメントハッシュを検証
   if doc_hash != expected_hash:
       logger.warning("Skill更新が必要です")
   ```

---

## 📈 監視とメトリクス活用

### メトリクス収集スクリプト（サンプル）

```bash
#!/bin/bash
# collect_metrics.sh

OUTPUT_DIR="metrics/$(date +%Y%m)"
mkdir -p "$OUTPUT_DIR"

# last_run_summary.jsonを収集
find test-cases -name "last_run_summary.json" -mtime -30 | \
  xargs cat | jq -s '.' > "$OUTPUT_DIR/summaries.json"

# メトリクス抽出
jq '[.[] | {
  date: .timestamp,
  pattern: .pattern,
  test_count: .quality_gate.test_case_count,
  ui_coverage: .quality_gate.ui_coverage_ratio,
  ambiguous_count: .quality_gate.ambiguous_count,
  passed: .quality_gate.passed
}]' "$OUTPUT_DIR/summaries.json" > "$OUTPUT_DIR/metrics.json"

echo "メトリクス収集完了: $OUTPUT_DIR/metrics.json"
```

### ダッシュボード化（推奨ツール）

- **Grafana + JSON API**: メトリクスの可視化
- **Google Sheets**: 簡易集計・グラフ化
- **Slack通知**: しきい値超過時のアラート

### 目標値（初期設定）

| メトリクス | 目標値 | 測定頻度 |
|-----------|--------|---------|
| UI網羅率 | ≥ 0.9 | PR毎 |
| 具体値率 | ≥ 0.95 | PR毎 |
| 観点比率（各） | ≥ 0.8 | PR毎 |
| 再生成回数 | ≤ 2回/PR | 週次集計 |
| 曖昧表現 | ≤ 3件 | PR毎 |
| レビュー指摘 | 減少傾向 | 月次比較 |

---

## 🎯 即時実行チェックリスト

### Day 0実施項目

- [ ] Python 3.8以上がインストール済み
- [ ] Git利用可能
- [ ] VERIFICATION_GUIDE.mdのPattern1スモーク実行
- [ ] VERIFICATION_GUIDE.mdのPattern3スモーク実行
- [ ] VERIFICATION_GUIDE.mdのPattern4スモーク実行
- [ ] CIワークフローのArtifacts確認
- [ ] PRコメント自動投稿確認
- [ ] config/default_config.json固定

### Week 1-2実施項目

- [ ] メトリクス収集開始
- [ ] 週次レビュー実施
- [ ] チームフィードバック収集

### Week 3移行項目

- [ ] ハードゲート設定
- [ ] 例外運用ルール策定
- [ ] しきい値最終調整

---

## 📞 サポート・エスカレーション

### 問題発生時の対応フロー

1. **ログ確認**
   ```bash
   cat logs/run_log.txt
   cat test-cases/last_run_summary.json
   ```

2. **VERIFICATION_GUIDE.mdのトラブルシューティング参照**

3. **開発チームSlackで質問**
   - ログファイル添付（run_log.txt、last_run_summary.json）
   - 実行コマン
