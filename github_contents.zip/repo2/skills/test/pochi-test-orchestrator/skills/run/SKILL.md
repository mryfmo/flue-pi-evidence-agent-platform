---
name: pochi-test-orchestrator
description: >-
  Pochiアプリのテストケースを FullIntegration / FullScenario /
  PartialIntegration / PartialScenario の4パターンで自動生成・更新する。
  「Pochiのテストケースを生成して」「テストケース更新」「品質チェック」
  「pochi-test-orchestratorを起動」と言われた場合に使用する。
allowed-tools: Read, Edit, Bash, AskUserQuestion, Agent
triggers:
  - Pochiのテストケースを生成して
  - テストケースを生成して
  - テストケース生成
  - テストケース更新
  - pochi-test-orchestratorを起動
  - 品質チェック
  - pochilibアップデート対応のテストケース生成
  - generate test cases
---


# Skill: Pochi Test Orchestrator

**このSkillは、Pochiデータ分析アプリのテストケース生成を自動化します。**

## When

### 起動条件
フロントマターの `triggers` に定義されたフレーズのいずれかが発話されたら、直ちにこのSkillを起動してください。

### 前提条件
- プロジェクトルートに`test-orchestrator/`ディレクトリが存在する（または作成可能）
- Skill内の`guidelines/tools/app_structure_analyzer.py`が利用されます（`--target-dir <対象リポジトリパス>` で解析対象を指定）

> 詳細なセットアップ手順: [INSTALLATION.md](../../docs/INSTALLATION.md) / [QUICKSTART.md](../../docs/QUICKSTART.md)

### 起動しない条件（誤起動防止）
以下のような曖昧な表現では起動しないでください：
- ❌ 「テストしたい」
- ❌ 「レビューして」
- ❌ 「確認して」
- ❌ 「チェックして」（曖昧。「品質チェック」は起動）
- ❌ 「テストを作って」（「テストケースを作成」は起動）

定義されたトリガーワードとの明確な一致が必要です。

## Do

**起動前にユーザーへ以下を確認してください：**
1. スコープ: 全機能（`full`）/ 特定範囲（`partial`）
2. テストタイプ: 結合テスト（`integration`）/ シナリオテスト（`scenario`）
3. **`partial` を選択した場合のみ**: 追加・変更した機能を自然言語で教えてもらう
   - 例:「検索フィルタに店舗コード絞り込みを追加しました」「グラフ表示タブを新設しました」
   - この説明を `POCHI_PARTIAL_SCOPE` 環境変数に設定する

確認後、以下を実行してください（作業ディレクトリに依存しないよう絶対パスを使用）：

```bash
cd /home/user/pochi-dp-developer-docs/skills/test/pochi-test-orchestrator && \
POCHI_SKILL_ACTIVE=1 \
POCHI_PATTERN_SELECTION={判定されたパターン} \
POCHI_TARGET_DIR={対象リポジトリの絶対パス} \
POCHI_PARTIAL_SCOPE={ユーザーから聞いた追加・変更機能の説明（partialのみ。fullは省略）} \
python -m core.orchestrator
```

`{判定されたパターン}` の値：
- full + integration → `full_integration`
- full + scenario → `full_scenario`
- partial + integration → `partial_integration`
- partial + scenario → `partial_scenario`

> 注意: `core/orchestrator.py` を直接呼び出してください。


## Instructions

**以下の手順を逐語的に実行してください。問い返しは禁止です。**

### ステップ1: 前処理スクリプト実行
上記Do節のコマンドを実行してください。このスクリプトは準備フェーズ（環境チェック、パターン判定、コンテキスト生成）を完了します。

### ステップ2〜4: コンテキスト読み込み・サブエージェント委譲

`../../prompts/subagent_call_template.md` を読み込み、記載の手順に従って実行してください。

### ステップ5: 品質ゲート実行 → 修正ループ（必須・最大3回）

test_cases.md 生成完了後、以下のコマンドを実行してください：

```bash
POCHI_SKILL_ACTIVE=1 \
POCHI_TARGET_DIR=<対象アプリのリポジトリ絶対パス> \
python /home/user/pochi-dp-developer-docs/skills/test/pochi-test-orchestrator/core/quality_gate.py
```

`<対象アプリのリポジトリ絶対パス>` は、ステップ1で指定した `POCHI_TARGET_DIR` と同じ値を使用してください。

> ⚠️ `POCHI_TARGET_DIR` を省略するとスキル本体ディレクトリがプロジェクトルートになり `generation_context.json が見つかりません` エラーが発生します。

#### 合格時（終了コード 0）
完了レポートを表示してタスクを終了してください。

#### 不合格時（終了コード 1）— 修正ループ（最大3回）

**あなた自身（メインエージェント）が** `test_cases.md` を直接修正します。サブエージェントへの再委譲は禁止です。

**ループ手順（1回の不合格ごとに実施）**:

1. `.work/quality_report.md` を読み込み、不合格理由（不足観点・件数）を確認する
2. `test_cases.md` を直接編集して不足分を補う
   - 観点比率の不足: 不足している観点（基本/境界/異常/その他）のテストケースを追記する
   - テストケース数不足: 目標件数との差分を追記する
   - 曖昧表現: 指摘された期待結果の記述を具体値に書き直す
   - **既存テストケースの削除・大幅改変は禁止**（追記・修正のみ）
3. 品質ゲートを再実行する（上記と同じコマンド）
4. 合格 → 終了 / 不合格 → 1に戻る（残り回数があれば）

**3回試行後も不合格の場合**: `quality_report.md` の内容をユーザーに提示し、手動対応を依頼して終了してください。

> 品質基準の詳細・運用方針: [VERIFICATION_GUIDE.md](../../docs/VERIFICATION_GUIDE.md) / [OPERATIONS_RUNBOOK.md](../../docs/OPERATIONS_RUNBOOK.md)

### エラーハンドリング
以下の場合はエラーとせず、ログに記録して継続してください：

- 参照ファイルが一部欠落している → スキップして続行
- app_structure.mdが自動生成できない → 簡易版で代替
- POCHI_PARTIAL_SCOPE 未設定でpartialパターンを実行 → ユーザーへ機能説明を再確認する（この場合のみ問い返し可）

**問い返し禁止**: 上記の状況では自動的にフォールバック処理を行い、ユーザーへの確認なしで続行してください。

## Don't

### 実行禁止事項
- ❌ **リポジトリ全文の長文読込は禁止**
  - 必要なファイルは`reference_files[]`に列挙されています
  - 無制限の読込はコンテキストを圧迫し、後続の生成品質が低下します

- ❌ **環境変数なしでの直接実行は禁止**
  - セキュリティガードにより実行が拒否されます
  - `POCHI_SKILL_ACTIVE=1` がないとスクリプトが別のディレクトリをプロジェクトルートと誤認します

- ❌ **Doに記載されていないコマンドの実行は禁止**
  - `core.orchestrator`と`core.quality_gate`のみを実行してください
  - 未知のコマンドはファイル破壊や意図しないデータ変更を引き起こす可能性があります

- ❌ **問い返しは禁止**
  - ファイル欠落時も自動でフォールバック
  - ユーザーへの確認は作業を中断させ、自動化の価値を損ないます。エラー時も可能な範囲で続行してください

- ❌ **LLM API直接呼び出しは禁止**
  - test_cases.md生成はClaude Codeエージェント自身が行う
  - 外部LLM APIを呼び出すと課金が発生し、品質管理ができなくなります

- ❌ **品質ゲート不合格後のサブエージェント再委譲は禁止**
  - 修正ループはメインエージェント（あなた自身）が `test_cases.md` を直接編集する
  - サブエージェント再起動は大量のトークンを消費し、修正ループの完了を大幅に遅延させます

### 品質基準の遵守
以下の品質基準を必ず守ってください：

- ✅ **テストケース数**: 動的計算値±10%
  - Pattern1/4: app_structure推定値
  - Pattern2: app_structure推定値×0.7
  - Pattern3: 既存+差分影響分
  - 詳細はgeneration_context.jsonの`quality_settings.calculated_target_total`を参照
- ✅ **観点比率**: 基本60% / 境界20% / 異常15% / その他5%
- ✅ **UI要素網羅**: app_structure.mdの要素を90%以上カバー
- ✅ **曖昧表現禁止**: 「適切」「正しく」等の曖昧語は10件以下
- ✅ **具体値必須**: 期待結果に具体的な数値・日付・データ例

## 安全対策

### Skills専用モード
- **環境変数チェック**: `POCHI_SKILL_ACTIVE=1`が必須
- **直接実行の防止**: セキュリティリスク低減

### データ保護
- 既存`test_cases.md`は自動バックアップ（.bak.{run_id}形式）
- すべての操作を`logs/skill_run_{run_id}.log`に記録
- 絶対パスによる誤動作防止
