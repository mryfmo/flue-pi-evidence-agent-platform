---
name: pochi-tdd-test-generator
description: >-
  仕様書（spec.json / plan.json）から Layer1・Layer2 の RED テスト（TDD先行テスト）を生成するスキル。
  コードが存在しない開発初期フェーズに使用する。
  T0（コード解析）は不要。spec.json の data_contracts / business_rules から contracts/ を直接生成し、
  plan.json の artifacts からモジュール構成を推定して conftest.py を生成する。
  検証は --collect-only のみで ImportError は想定内（RED期待）。
  coding-agent 向けの test-mapping.json を追加出力する。
  「仕様書からREDテストを生成して」「spec.json から TDD テスト先行生成」
  「仕様からテストを先行作成して」「pochi-tdd-test-generatorを起動」と言われたときに使用する。
allowed-tools: Read, Write, Glob, Bash, AskUserQuestion, Agent
---

# pochi-tdd-test-generator Skill

## スキル概要

仕様書（`spec.json` / `plan.json`）のみを入力として、**Layer1（データ契約テスト）** と
**Layer2（ロジック単体テスト）** の **RED テスト（TDD先行テスト）** を生成する単独実行型スキル。

`pochi-unit-test-generator` が「既存コードからGREENテストを後付けする」のに対し、
このスキルは「仕様書からREDテストを先行作成する」ために使用する。
コードが存在しない開発初期フェーズ（`pochi-spec-initializer` / `pochi-coding-agent` の前段）での使用を想定している。

### pochi-unit-test-generator との主要な差分

| 観点 | pochi-unit-test-generator | pochi-tdd-test-generator |
|---|---|---|
| 入力 | 既存コード（app_path + entrypoint） | spec.json + plan.json |
| T0（コード解析） | 必須 | **不要**（コードが存在しない） |
| contracts/ 生成 | draft-contracts/ → 確定 | **spec.json から直接マッピング** |
| conftest.py の根拠 | module-inventory.json | **plan.json の artifacts から推定** |
| Layer2 設計 | 既存コードの関数を解析 | **plan.json + spec.json から関数シグネチャを予測** |
| 検証 | pytest 実行（GREEN期待） | **--collect-only のみ（RED期待）** |
| 追加出力 | なし | **test-mapping.json（coding-agent用）** |

### 生成対象

| フェーズ | 出力先 | 内容 |
|---|---|---|
| contracts/ 直接生成 | `tests/contracts/` | テスト品質契約6ファイル（spec.jsonから直接生成） |
| T4 | `tests/fixtures/` | テストデータセット（valid/invalid/edge） |
| conftest.py | `tests/conftest.py` | フィクスチャ・モック設定（plan.jsonから推定） |
| Layer 1 | `tests/contracts/` | データ契約テスト（spec.jsonのスキーマ定義に対して検証） |
| Layer 2 | `tests/unit/` | ロジック単体テスト（関数シグネチャを仕様から予測） |
| test-mapping.json | `tests/.onboarding/` | coding-agent用のテスト-コード対応マップ |

**Layer 3（結合テスト）・Layer 4（E2Eテスト）はこのスキルでは生成しない。**
結合・シナリオテストケースが必要な場合は `pochi-test-orchestrator` を使用すること。

### テストフレームワーク

本スキルは **pytest** をテストフレームワークとして使用する。
すべてのテストは pytest の規約（`test_` プレフィックス、`@pytest.fixture`、`conftest.py` 等）に従って生成すること。

<global_constraint id="subagent-policy">
  各STEPでは指定のカスタムサブエージェントを Agent ツールで起動することを優先する。
  サブエージェントが利用不可の場合は Claude Code 本体がフォールバックモードで直接実行する。
  この方針はSTEP 2〜7の全ステップに適用される。
  使用するサブエージェント:
  - contracts生成・Layer1・Layer2設計・実装: subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"
  - テストデータ生成: subagent_type: "pochi-test-onboarding:pochi-t4-fixtures-manager"
</global_constraint>

---

## STEP 1: ユーザーからの情報収集

AskUserQuestionツールで以下を確認する（**最大2回の質問で完結させること**）：

**1回目の質問（必須）**:
- **`app_path`**: プロジェクトルートパス（例: `/home/user/my-pochi-app`）
- **`spec_json_path`**: spec.json のパス（例: `spec.json` または `docs/spec.json`）
- **`plan_json_path`**: plan.json のパス（例: `plan.json` または `docs/plan.json`）

> 💡 パスは `app_path` からの相対パスでも絶対パスでも可。
> 例: `app_path=/home/user/myapp`, `spec_json_path=spec.json` → `/home/user/myapp/spec.json` として解釈する。

> 💡 **spec.json / plan.json の自動検出**: ユーザーが正確なパスを知らない場合は、
> `app_path` が判明した時点で以下の Glob で候補を検索してユーザーに選ばせること:
> - spec.json 候補: `{app_path}/spec/features/*/spec.json`
> - plan.json 候補: `{app_path}/spec/plans/*.json`
> 候補が1件なら自動選択、複数件なら一覧を提示して選択させる。

> ⚠️ **spec.json / plan.json が存在しない場合は中断する**:
> Glob で候補が0件の場合、以下を通知してスキルを終了する:
>
> ```
> ⚠️ スキル停止
> 分類: [ファイル不在]
> 理由: spec.json / plan.json が見つかりませんでした。
>       このスキルは仕様書が存在する状態で使用してください。
> 対処: 先に pochi-spec-initializer を実行して spec.json / plan.json を生成してください:
>         「pochi-spec-initializer を起動して」
> ```
>
> spec.json のみ存在・plan.json のみ存在の場合も同様に中断し、両ファイルの生成を促す。

**2回目の質問（推奨項目を一括提示）**:
以下の項目を一覧で提示し、ユーザーが「デフォルトで続行」を選べるようにする：
- **カバレッジ目標**: 60% / 70% / 80% / カスタム（デフォルト: 60%）
- **モック方針**: 以下のデフォルト分類を提示し、変更があれば指定してもらう
  - always_mock（常にモック）: pochilib, streamlit系, Snowflake系 → デフォルト
  - never_mock（本物を使用）: pandas, numpy, whoosh, sqlalchemy → デフォルト
  - ※ T0未実行のため依存パッケージの自動検出は不可。plan.jsonのartifactsから推定する
- **Python バージョン**: pytest / fixture の互換性確認のため（デフォルト: 自動検出）
- **既存テストの有無**: `tests/` が既に存在する場合、上書き確認が必要
- **Snowflake/LLM 依存の有無**: モック戦略の事前判断（デフォルト: plan.json から自動検出）

> ヒアリング結果は以下の変数として保持し、後続ステップで直接参照する:
> - `coverage_target`: カバレッジ目標（数値、デフォルト: 60）
> - `mock_always`: 常にモックするパッケージリスト
> - `mock_never`: 本物を使用するパッケージリスト
> ※ unit-test-generatorと異なり、T0を実行しないためSTEP 2.5（モック方針自動検出）は存在しない。
> plan.jsonのartifactsに含まれるSnowflake/LLM依存情報があれば、mock_alwaysに自動追加する。

情報収集後、以下の実行計画を提示して確認を取ること：

> ⏱️ **処理時間の目安**: テスト生成全体で **5〜10分**かかる場合があります。
> 実行中は**このセッションで他の作業を行わないでください**（割り込みによる中断を防止します）。

```
実行計画:
  STEP 2&3: contracts/ 直接生成 + T4 テストデータ生成（並列実行可）
    ├ STEP 2: contracts/ 直接生成（spec.json → 6ファイル）
    └ STEP 3: T4 - テストデータ生成（pochi-t4-fixtures-manager）
  STEP 4:  conftest.py 生成（plan.json の artifacts からモジュール構成を推定）
  STEP 5:  Layer1 - データ契約テスト生成（spec.json スキーマベース）
  STEP 6:  Layer2 - ロジック単体テスト設計（関数シグネチャを仕様から予測）
  STEP 7:  Layer2 - テストコード実装
  STEP 8:  検証（--collect-only のみ、RED状態は正常）
  STEP 9:  test-mapping.json 出力（coding-agent用）
  STEP 10: 完了レポート
```

---

## STEP 2: contracts/ 直接生成（T0不要）

T0（既存コード解析）は不要。spec.json の内容を直接 contracts/ へマッピングする。

まず以下のファイルを読み込み（相互依存なし→並列で一括読み込みすること）、フォーマット検証を実施する：

<documents>
  <document index="1">
    <source>{spec_json_path}</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
  <document index="2">
    <source>{plan_json_path}</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
</documents>

<validation_rules id="spec-json-format">
  ■ spec.json フォーマット検証（STEP 2 冒頭）
  以下の必須フィールドが存在するか確認する：
  - `data_contracts`: なければ警告を出し、ユーザーに続行確認を求める
  - `business_rules`: なければ Layer1 テストのビジネスルール観点が生成されない旨を通知する

  両フィールドが存在しない場合: 中断し、以下を通知する:
    「⚠️ スキル停止
     分類: [ユーザー入力の問題]
     理由: spec.json に data_contracts / business_rules フィールドが定義されていません。
           これらのフィールドは Layer1 テスト生成に必須です。
     対処: pochi-spec-initializer で spec.json を再生成してください:
             「pochi-spec-initializer を起動して」」
  片方が存在しない場合: 警告のみで続行可（ベストエフォートで対応）。
</validation_rules>

```
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow を起動し、
（subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"）
以下を実行させてください：

【spec.json → contracts/ 直接マッピングモード（T0/T1ドラフト不要）】

■ 入力ファイルの参照（既に読み込み済みのドキュメントを参照する）
  - {spec_json_path}（data_contracts / business_rules フィールドを参照）
  - {plan_json_path}（artifacts / description 等を補助情報として参照）

■ 出力: {app_path}/tests/contracts/ 配下に以下の6ファイルを生成する

  1. data-contracts.json
     - spec.json の data_contracts フィールドをベースに生成
     - boundary フィールドを各エンティティ名から自動設定する

  2. business-rules.json
     - spec.json の business_rules フィールドをそのままマッピング
     - id / description / rule の各フィールドを保持する

  3. test-viewpoints.json
     - data_contracts の各エンティティ・フィールドに対応する観点を生成
     - business_rules に対応する観点（VP-BR-XXX）を追加する

  4. scenarios.json
     - business_rules のシナリオを正常系・異常系で展開する
     - data_contracts のエンティティごとにデータ入力シナリオを追加する

  5. risk-catalog.md
     - spec.json の内容からリスクを推定して生成する
     - nullable: false のフィールドに対するNULLリスク
     - type 定義に対する型違反リスク
     - business_rules の各ルールに対する違反リスク

  6. domain-rules.md
     - spec.json のエンティティとビジネスルールを自然言語で説明する
     - plan.json の description 等を補助情報として活用する
```

---

## STEP 2 & 3: 並列実行（contracts/ 生成 + fixtures 生成）

> 💡 STEP 2 と STEP 3 は互いに依存しないため、Agent ツールで同時起動してよい。
>    完了順は問わないが、両方が完了してから STEP 4 に進むこと。

---

## STEP 3: T4 実行（テストデータセット生成）

```
Agentツールで pochi-test-onboarding:pochi-t4-fixtures-manager を起動し、
（subagent_type: "pochi-test-onboarding:pochi-t4-fixtures-manager"）
以下を実行させてください：
- 入力: {app_path}/tests/contracts/data-contracts.json（STEP 2の出力）
- valid / invalid / edge の3種類のテストデータセット（fixtures）を生成する
- 出力先: {app_path}/tests/fixtures/
  - valid/   （正常データ: スキーマに準拠した有効データ）
  - invalid/ （異常データ: 型違反・必須欠損・範囲外など）
  - edge/    （エッジケース: 空ファイル・最大値・特殊文字など）
  - manifest.json（fixtures管理台帳）
```

STEP 2 と STEP 3 の両方が完了したら STEP 4 に進む。

---

## STEP 4: conftest.py 生成（plan.json ベース）

> **重要**: conftest.py を先に生成することで、Layer1/2 生成時のインポートエラーを防ぐ。
> `module-inventory.json` は存在しないため、`plan.json` の `artifacts` フィールドからモジュール構成を推定する。

以下のファイルを読み込む：

<documents>
  <document index="1">
    <source>{plan_json_path}</source>
    <document_content>（Readツールで読み込む。artifacts フィールドを参照する）</document_content>
  </document>
</documents>

```
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow を起動し、
（subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"）
以下を実行させてください：

【conftest.py 生成専用モード（plan.json の artifacts ベース）】

■ plan.json の artifacts からフレームワーク検出
  {plan_json_path} の artifacts フィールドを読み込み、以下のルールでフレームワークを判定する：
  - artifacts に type: "streamlit_entrypoint" が含まれる → framework: "streamlit"
  - artifacts に type: "flask_entrypoint" が含まれる → framework: "flask"
  - 上記に該当しない → framework: "cli"

■ importパスの予測ルール
  artifacts の path フィールドから sys.path への追加パスを決定する：
  - path が "app/lib/*.py" 形式 → sys.path に {app_path}/app/ を追加
    → import は "lib.module_name" 形式（"app.lib.module_name" ではない）
  - path が "app/*.py" 形式 → sys.path に {app_path}/ を追加
    → import は "app.module_name" 形式

■ フレームワーク別のモック戦略
  framework: "streamlit" の場合:
    → _passthrough_decorator を定義し st.cache_data / st.cache_resource に割り当てる
    → artifacts から _PRELOAD_MODULES を自動生成する（type: "module" のみ対象）
    → _MOCK_MODULES リストをSTEP 1で確定した `mock_always` 変数から生成する
    → `mock_never` 変数に含まれるパッケージは _MOCK_MODULES から除外する
  framework: "flask" の場合:
    → app.test_client() ファクトリパターンを conftest.py に組み込む
  framework: "cli" / その他:
    → モック不要。sys.path のみ設定する

■ conftest.py の更新方針
  - {app_path}/tests/conftest.py が既存かどうかを Glob で確認する
  - **既存ファイルが存在する場合**: 末尾追記のみ。既存行は一切変更しない。
    追記箇所は `# --- Added by pochi-tdd-test-generator {日時} ---` で明示する。
  - **既存ファイルが存在しない場合**: 新規生成する（以下の設定を適用）
    - {app_path}/tests/conftest.py を生成する

■ 収集エラー確認（生成後に必ず実行）
  以下のコマンドを実行し、SyntaxError / NameError 等のテストコード起因エラーがないか確認する
  （最大3回のリトライ）：
    cd {app_path} && python -m pytest --collect-only --tb=line -q 2>&1 \
      | grep -E "ERROR|SyntaxError|NameError|AttributeError" | head -20
  ※ ImportError / ModuleNotFoundError は「コードが存在しないため」の想定内エラーであり、修正不要。
  テストコード起因のエラー（SyntaxError 等）のみ修正すること。
```

- plan.json に `artifacts` フィールドがない場合: デフォルト（framework: "streamlit", sys.path: {app_path}/app/）で生成し、ユーザーに通知する

conftest.py が生成されたら STEP 5 に進む。

---

## STEP 5: Layer1 生成（データ契約テスト）

以下のファイルを読み込む（相互依存なし→並列で一括読み込みすること）：

<documents>
  <document index="1">
    <source>{app_path}/tests/contracts/data-contracts.json</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
  <document index="2">
    <source>{app_path}/tests/contracts/business-rules.json</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
  <document index="3">
    <source>{app_path}/tests/contracts/risk-catalog.md</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
  <document index="4">
    <source>{app_path}/tests/fixtures/</source>
    <document_content>（manifest.json を読み込み、fixtures のデータ構造を把握する）</document_content>
  </document>
</documents>

```
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow を起動し、
（subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"）
以下を実行させてください：

【Layer1 限定モード（spec.json スキーマベース）】

- 読み込み済みの data-contracts.json の内容を参照する
- 読み込み済みの business-rules.json の内容を参照する
- 読み込み済みの risk-catalog.md のリスクIDに対応するテストを優先生成する
- {app_path}/tests/fixtures/ のデータセットを @pytest.fixture で参照するテストコードを生成する
- 生成するテストには「# RISK: {リスクID}」コメントを付与すること

■ テストファイル名の決定
  data-contracts.json の boundary フィールドを参照し、
  boundary ごとに test_{boundary_name}_schema.py を生成する。

<examples label="boundary からのテストファイル名決定例">
  <example label="CsvInput エンティティの場合">
    boundary "CsvInput" → tests/contracts/test_csv_input_schema.py
  </example>
  <example label="SalesRecord エンティティの場合">
    boundary "SalesRecord" → tests/contracts/test_sales_record_schema.py
  </example>
</examples>

■ 重要: spec.json のスキーマ定義に基づく検証テストを生成すること。
  実装コードを解析するのではなく、仕様で定義されたスキーマ・ルールに対して検証するテストを書く。
  テストが参照するモジュールは「実装予定のもの」として扱い、ImportError は想定内とする。

■ test-ratio.json の保証
  STEP 5 開始時点で以下のデフォルト値を {app_path}/tests/.onboarding/test-ratio.json に書き込む。
  その後、risk-catalog.md の HIGH リスク数に応じて上書き更新する。
  （デフォルト: 正常系 40% / 異常系 40% / 境界値 20%）
  これにより、STEP 5 が途中失敗しても STEP 6 はデフォルト比率で続行できる。
  ※ risk-catalog.md に HIGH リスクが多い場合は異常系を 50% に引き上げて上書きする
```

---

## STEP 6: Layer2 設計（仕様からの関数シグネチャ予測）

以下のファイルを読み込む（相互依存なし→並列で一括読み込みすること）：

<documents>
  <document index="1">
    <source>{spec_json_path}</source>
    <document_content>（Readツールで読み込む。data_contracts / business_rules を参照する）</document_content>
  </document>
  <document index="2">
    <source>{plan_json_path}</source>
    <document_content>（Readツールで読み込む。artifacts の各モジュール・function_signatures を参照する）</document_content>
  </document>
  <document index="3">
    <source>{app_path}/tests/contracts/test-viewpoints.json</source>
    <document_content>（Readツールで読み込む。Layer2 観点を参照する）</document_content>
  </document>
  <document index="4">
    <source>{app_path}/tests/fixtures/</source>
    <document_content>（manifest.json を読み込み、valid/invalid/edge データの活用箇所を設計に組み込む）</document_content>
  </document>
</documents>

```
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow を起動し、
（subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"）
以下を実行させてください：

【Layer2 設計専用モード（仕様書からの関数シグネチャ予測）】

■ 重要: app/ 配下のコードを解析するのではなく、仕様書から関数シグネチャを予測すること。

■ function_signatures フィールドの優先参照
  plan.json に `function_signatures` フィールドが存在する場合、
  名前マッチングより優先してシグネチャを採用する。
  存在しない場合のみ名前マッチングフォールバックを使用する。

  plan.json への任意フィールド追加例:
  ```json
  {
    "artifacts": [...],
    "function_signatures": [
      {
        "module": "app/lib/parser.py",
        "functions": [
          { "name": "parse_csv", "signature": "(file_path: str) -> list[dict]" }
        ]
      }
    ]
  }
  ```

■ 関数シグネチャの取得ルール（function_signatures が存在しない場合のフォールバック）

  plan.json に `function_signatures` が存在しない場合、以下の**優先順位**で対応する：

  **ルール A（推奨）: plan.json の description / artifacts から明示的に読み取れる場合**
  - artifacts の `description` フィールドに関数名・引数が記載されている場合のみ採用する
  - 記載がないモジュールはルール B へ

  **ルール B: business_rules からバリデーション関数を導出**
  - spec.json の `business_rules` の各ルールに対して、バリデーション関数を1つ導出する
  - ルール例: `"店舗コードは5桁の数字"` → `def validate_store_code(store_code: str) -> bool`
  - 根拠: business_rules は spec.json に明示された仕様のため、導出は推測ではなく仕様準拠

  **ルール C（フォールバック時の報告義務）: 上記で解決できないモジュール**
  - 命名規則ヒューリスティック（"parser" 含む → 入力処理関数 等）は**使用禁止**
  - 代わりに、以下の形式で「シグネチャ未定義リスト」を `unit-test-design.md` の冒頭に記載する：

  ```markdown
  ## ⚠️ 関数シグネチャ未定義（ユーザー確認必須）

  以下のモジュールは plan.json に function_signatures が定義されておらず、
  仕様書からシグネチャを特定できませんでした。
  pochi-coding-agent による実装前に、plan.json へ function_signatures を追記してください。

  | モジュール | 追記が必要な理由 |
  |---|---|
  | app/lib/store_reader.py | artifacts.description にシグネチャ情報なし |
  | app/lib/calc_monthly.py | artifacts.description にシグネチャ情報なし |

  ### function_signatures 追記例（plan.json）:
  \`\`\`json
  {
    "artifacts": [...],
    "function_signatures": [
      {
        "module": "app/lib/store_reader.py",
        "functions": [
          { "name": "read_stores", "signature": "(file_path: str) -> pd.DataFrame" }
        ]
      }
    ]
  }
  \`\`\`
  ```

  シグネチャ未定義モジュールの Layer2 テストは、ルール B（business_rules 由来）のテストのみ生成し、
  シグネチャ依存テストは「TODO: function_signatures 追記後に生成」コメントで保留する。

  **目的**: 推測された架空の関数名が test-mapping.json に混入し、
  pochi-coding-agent が誤った関数名で実装するリスクを防ぐ。

■ テスト比率の適用
  STEP 5 で保存した {app_path}/tests/.onboarding/test-ratio.json を読み込み、
  同じ比率を Layer2 設計に適用する（比率の再計算は不要）。

- AAAパターンで記述した設計書を以下に出力する：
    {app_path}/tests/.onboarding/unit-test-design.md
```

---

## STEP 7: Layer2 実装（テストコード生成）

以下のファイルを読み込む：

<documents>
  <document index="1">
    <source>{app_path}/tests/.onboarding/unit-test-design.md</source>
    <document_content>（Readツールで読み込む。STEP 6 の設計書を参照する）</document_content>
  </document>
</documents>

```
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow を起動し、
（subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"）
以下を実行させてください：

【Layer2 実装専用モード】

- 読み込み済みの unit-test-design.md の内容を参照する
- tests/unit/ 配下に Layer2 テストコードを実装する
- AAAパターン・命名規則を遵守する
- 各テスト関数には仕様参照コメントを付与する（Layer1 の `# RISK:` と同様のトレーサビリティを確保する）：

  **コメント形式**:
  ```python
  # SPEC: data_contracts[N] (entity: {entity名})  ← データ契約テスト由来
  # BR: {ルールID} ({ルール概要})                  ← business_rules テスト由来
  # PRED: plan.json artifacts[N] (module: {モジュール名})  ← シグネチャ予測由来
  ```

  **付与例**:
  ```python
  def test_parse_csv_valid_input():
      # SPEC: data_contracts[0] (entity: SalesRecord)
      # フィクスチャから有効CSVを読み込み、正しい列数・型が返るか検証する
      result = parse_csv(fixtures["valid"]["sales_input.csv"])
      assert isinstance(result, list)
      assert len(result) == len(pd.read_csv(fixtures["valid"]["sales_input.csv"]))

  def test_validate_store_code_invalid():
      # BR: BR-001 (店舗コードは5桁の数字)
      result = validate_store_code("ABC12")
      assert result is False
  ```

  **重要**: PRED コメントは FIX-TDD-01 のルール A でシグネチャが artifacts.description 由来の場合にのみ付与する。
  function_signatures が明示定義された場合は SPEC または BR コメントを使用する。

- tests/fixtures/ の valid/invalid/edge データを @pytest.fixture 経由で活用する
- Snowflake依存は mock_snowflake フィクスチャでモックする
- LLM依存は mock_llm フィクスチャでモックする
- conftest.py が sys.path に app/ を追加している場合、
  import と @patch は必ず「lib.*」形式で統一する（「app.lib.*」は使わない）

■ TDD の原則（RED 先行）:
  このスキルはテスト先行開発（TDD）の RED フェーズを担当する。
  テスト対象のモジュールは「これから実装する仕様」であり、実行時に ImportError が発生するのは正常。
  目標は「実装完了後に GREEN になるテストコード」を先に書くことである。
  pochi-coding-agent が test-mapping.json を参照して実装を行う。

  テストコードは以下の前提で生成すること：
  - 実装予定モジュールの ImportError は無視してよい
  - 実装完了後に pytest tests/unit/ が GREEN になるよう関数名・引数を設計する
  - テストが参照する import パスは plan.json の artifacts から推定した正式パスを使用する

```

---

## STEP 7.5: RED テスト品質チェック

Layer2 テストの生成後、以下の品質チェックを実行する。
**RED テストは実行不可でも構わないが、アサーション品質基準は守る必要がある。**

以下のコマンドを順番に実行し、結果を集計する：

```bash
# チェック1: 型チェックのみアサーション（単独 isinstance）
grep -rn "assert isinstance" {app_path}/tests/unit/ {app_path}/tests/contracts/

# チェック2: is not None のみ
grep -rn "assert.*is not None" {app_path}/tests/unit/ {app_path}/tests/contracts/

# チェック3: try/except pass
grep -A 3 "try:" {app_path}/tests/unit/ {app_path}/tests/contracts/ | grep -A 1 "except" | grep "pass"

# チェック4: インラインデータ重複（fixtures を使わずにデータを直接定義している行）
grep -rn "pd\.DataFrame(\[" {app_path}/tests/unit/ {app_path}/tests/contracts/

# チェック5: 仕様参照コメント欠落（def test_ 行の直後に # SPEC: / # BR: / # PRED: がない）
grep -n "def test_" {app_path}/tests/unit/*.py | head -20
```

### 品質基準

| チェック | 合格基準 | 超過時の対応 |
|---|---|---|
| チェック1: 型チェックのみ | 具体値アサーションと**併用**している場合のみ可 | 単独 isinstance は FAIL → 再生成（最大1回） |
| チェック2: is not None のみ | 0件 | FAIL → 再生成（最大1回） |
| チェック3: try/except pass | 0件 | FAIL → 再生成（最大1回） |
| チェック4: インライン重複 | 0件推奨（警告扱い） | ⚠️ 警告のみ。修正推奨 |
| チェック5: 仕様参照コメント欠落 | 全 `def test_` の90%以上にコメントあり | ⚠️ 警告のみ。修正推奨 |

FAIL が検出された場合は、対象テスト関数を特定して修正し（最大1回）、その後 STEP 8 へ進む。

> 💡 **RED テスト固有の注意**: 具体値アサーションに `fixtures` の値を使う場合、
> fixtures が存在しない状態で `--collect-only` を実行すると `FileNotFoundError` が
> 発生する場合がある。これは ImportError と同様に想定内なので修正不要。
> チェック4は「テストコード内にデータをインライン定義している」場合のみ対象とすること。

---

## STEP 8: 検証（--collect-only のみ、RED期待）

生成されたテストが収集可能か確認する。
**pytest によるテスト実行は行わない**（コードが存在しないため ImportError が発生するのは正常）。

```bash
cd {app_path} && python -m pytest --collect-only tests/contracts/ tests/unit/ -q 2>&1 | head -50
```

<examples label="検証結果の判定基準">
  <example label="正常な状態（対応不要）">
    ✅ ImportError / ModuleNotFoundError が発生する
      → コードが存在しないため。修正不要。
    ✅ 「collected N items」または「N errors」が表示される
      → テストが収集されていれば正常。
  </example>
  <example label="異常な状態（要修正）">
    ❌ SyntaxError → テストコード自体の構文エラー → 修正対象
    ❌ NameError / AttributeError → テストコード内の未定義参照 → 修正対象
  </example>
</examples>

収集エラーが異常な場合（SyntaxError 等）の対応（最大3回リトライ）:

```
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow を起動し、
（subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"）
対象ファイルの SyntaxError / NameError を修正させる。
```

ImportError / ModuleNotFoundError はリトライしない（想定内のため）。

---

## STEP 9: test-mapping.json 出力（coding-agent 用）

> ⚠️ **生成順序**: STEP 9 は STEP 4 で plan.json を読み込んだ後（STEP 5〜8 完了後）に実行すること。
> plan.json のタスクID（T-XX-*）を test-mapping.json の `task_id` フィールドに紐付けるために
> plan.json が確定している必要がある。

STEP 5・7 で生成したテストファイルを解析し、coding-agent 向けのテスト-コード対応マップを生成する。

以下のコマンドで生成されたテストファイルを一覧取得する：
```bash
find {app_path}/tests/contracts/ {app_path}/tests/unit/ -name "test_*.py" | sort
```

取得したテストファイルを読み込む（相互依存なし→並列で一括読み込みすること）：

<documents>
  <document index="1">
    <source>{app_path}/tests/contracts/test_*.py（上記findで取得した全ファイル）</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
  <document index="2">
    <source>{app_path}/tests/unit/test_*.py（上記findで取得した全ファイル）</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
  <document index="3">
    <source>{plan_json_path}</source>
    <document_content>（Readツールで読み込む。tasks[].id（T-XX-*）を参照してtask_idフィールドに紐付けるため）</document_content>
  </document>
</documents>

読み込んだテストファイルと plan.json を解析し、以下のフォーマットで `test-mapping.json` を生成する：

<example label="test-mapping.json フォーマット">
```json
{
  "generated_at": "<ISO8601タイムスタンプ>",
  "spec_json": "<spec_json_path>",
  "plan_json": "<plan_json_path>",
  "tests": [
    {
      "test_file": "tests/contracts/test_{boundary}_schema.py",
      "test_name": "test_{boundary}_valid_schema",
      "task_id": "T-XX-002",
      "implementation_hint": "<実装すべきファイルパス・関数名・仕様参照先を具体的に記載>",
      "spec_reference": "data_contracts[N] (entity: {entity名})"
    }
  ]
}
```
</example>

> 💡 `task_id` は plan.json の `tasks[].id` と `artifacts` フィールドを照合して決定する。
> テストが参照するモジュール（`implementation_hint` のファイルパス）が `artifacts` に含まれるタスクの ID を設定する。
> 対応するタスクが特定できない場合は `"task_id": null` とする。

出力先: `{app_path}/tests/.onboarding/test-mapping.json`

> 💡 `test-mapping.json` は `pochi-coding-agent` が実装を生成する際に参照する。
> `implementation_hint` には具体的なファイルパス・関数名・仕様参照先を記載すること。

---

## STEP 9.5: contracts/ バリデーション（未生成entity確認）

test-mapping.json 生成後、以下のバリデーションを実施する。

test-mapping.json の全エントリの `spec_reference` フィールドから entity 名を抽出し、
対応する contracts/ テストファイルが実際に生成されているか突合する。

```bash
# 生成済みの contracts/ テストファイルを一覧取得
find {app_path}/tests/contracts/ -name "test_*_schema.py" | sort
```

**突合ルール**:
- `spec_reference` に `entity: FooBar` が含まれる場合 → `test_foo_bar_schema.py` が存在するか確認
- 存在しない場合は以下の警告を出力する：

```
⚠️ contracts/ 未生成 entity 警告
以下の entity に対応するテストファイルが contracts/ に見つかりませんでした:
  - entity: {entity名} → 期待ファイル: tests/contracts/test_{entity_snake_case}_schema.py

原因の候補:
  1. STEP 5（Layer1 生成）で生成されなかった
  2. spec.json の data_contracts 定義と test-mapping.json の spec_reference が不一致

対処: STEP 5 を再実行するか、手動でテストファイルを確認してください。
```

---

## STEP 10: 完了レポート

以下の形式で完了を報告する：

```
✅ pochi-tdd-test-generator 完了（RED状態で正常完了）

📁 生成ファイル一覧:
  contracts/:
    - {app_path}/tests/contracts/data-contracts.json
    - {app_path}/tests/contracts/business-rules.json
    - {app_path}/tests/contracts/test-viewpoints.json
    - {app_path}/tests/contracts/scenarios.json
    - {app_path}/tests/contracts/domain-rules.md
    - {app_path}/tests/contracts/risk-catalog.md
  テストデータ（fixtures）:
    - {app_path}/tests/fixtures/valid/
    - {app_path}/tests/fixtures/invalid/
    - {app_path}/tests/fixtures/edge/
    - {app_path}/tests/fixtures/manifest.json
  Layer1（データ契約テスト）:
    - {app_path}/tests/contracts/test_*.py（境界ごと）
  Layer2（ロジック単体テスト）:
    - {app_path}/tests/unit/test_*.py（X ファイル）
  共通:
    - {app_path}/tests/conftest.py
  coding-agent 用:
    - {app_path}/tests/.onboarding/test-mapping.json

📊 テスト数サマリー:
  - Layer1 テスト関数数: X 件
  - Layer2 テスト関数数: X 件
  - 合計: X 件

🔴 RED状態について:
  ImportError は「実装コードが存在しないため」の想定内状態です。
  pochi-coding-agent で実装を行うと GREEN に変わります。

 次のステップ:
  1. test-mapping.json を参照して pochi-coding-agent で実装する
       pochi-coding-agent を起動し、{app_path}/tests/.onboarding/test-mapping.json を渡す
  2. 実装後に Layer1/2 の GREEN を確認する:
       pytest tests/contracts/ tests/unit/ -q
  3. 結合テスト・シナリオテストケースが必要な場合:
       「テストケースを生成して」（pochi-test-orchestrator）
       ※ テストケースMDを生成し、人が手動で実施するフローです
```

---

<constraints>
  <constraint id="subagent-first">
    サブエージェント優先: 各ステップで指定のカスタムサブエージェントを Agent ツールで起動することを優先する。
    サブエージェントが利用不可の場合は Claude Code 本体がフォールバックモードで直接実行する。
  </constraint>
  <constraint id="no-t0">
    T0 実行禁止: このスキルでは T0（既存コード解析）を実行しない。
    理由: コードが存在しない開発初期フェーズを対象としているため、コード解析は不可能。
    spec.json / plan.json の仕様書から直接生成する。
  </constraint>
  <constraint id="import-error-ok">
    ImportError は修正不要: コードが存在しないため発生する ImportError は想定内。
    テストコード起因の SyntaxError / NameError のみ修正すること。
    理由: TDD の RED フェーズでは実装コードが存在しないため ImportError は正常状態。
  </constraint>
  <constraint id="no-pytest-run">
    pytest 実行禁止: STEP 8 では `--collect-only` のみ実行する。
    理由: コードが存在しない状態でテストを実行すると全件 FAILED になり、
    RED（正常）か本当のエラーかの区別がつかなくなるため混乱を招く。
  </constraint>
  <constraint id="test-mapping-detail">
    test-mapping.json の活用: STEP 9 で生成した test-mapping.json は
    pochi-coding-agent が実装時に参照する重要なファイル。`implementation_hint` を具体的に記載すること。
  </constraint>
  <constraint id="fixtures-reuse">
    fixtures の活用: T4 で生成した tests/fixtures/ データは、Layer1・Layer2 テストで
    @pytest.fixture 経由で参照すること。インラインでデータを重複定義しないこと。
  </constraint>
  <constraint id="no-layer3">
    Layer3 は対象外: このスキルは Layer1・Layer2 のみ生成する。
    結合・シナリオテストケースが必要な場合は `pochi-test-orchestrator` を使用すること
    （テストケースMDを生成し、人が手動実施するフロー）。
  </constraint>
</constraints>

<prerequisites>
  このスキルは以下のサブエージェントが対応していることを前提とする：

  | サブエージェント | 必要な対応 |
  |---|---|
  | `pochi-test-onboarding:pochi-t2-tdd-workflow` | conftest.py 単独生成モード（plan.json artifacts ベース）に対応していること |
  | `pochi-test-onboarding:pochi-t2-tdd-workflow` | spec.json スキーマベースのテスト生成（コード不在を前提）に対応していること |
  | `pochi-test-onboarding:pochi-t2-tdd-workflow` | 仕様書からの関数シグネチャ予測モード（app/ 解析なし）に対応していること |
  | `pochi-test-onboarding:pochi-t4-fixtures-manager` | data-contracts.json から fixtures 生成（既存実装と同じ） |
</prerequisites>
