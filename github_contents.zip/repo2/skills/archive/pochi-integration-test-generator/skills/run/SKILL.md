---
name: pochi-integration-test-generator
description: >-
  Layer3結合テスト設計書（integration-test-design.md）からpytestネイティブなテストコードを生成するSkill。
  pochi-integration-test-designerで設計書を生成した後に実行する。
  tests/integration/conftest.pyとtests/integration/test_*_integration.pyを出力する。
  「Layer3の結合テストコードを生成して」「結合テスト設計書からコードを生成して」
  「結合テストを実装して」「pochi-integration-test-generatorを起動」と言われたときに使用する。
---

# pochi-integration-test-generator Skill

## スキル概要

設計書（`integration-test-design.md`）から Layer3 テストコードを生成する。
pytest + unittest.mock パターンで統一し、Snowflake セッションはモック化する。
`pochi-integration-test-designer` の設計書を前提とする Phase2 専用スキル。

### 生成対象

| 出力 | パス | 内容 |
|---|---|---|
| Layer3 conftest | `{app_path}/tests/integration/conftest.py` | pytest フィクスチャ・Snowflake モックフィクスチャ |
| テストコード | `{app_path}/tests/integration/test_*_integration.py` | pytest テスト（設計書の全シナリオ） |

### テストフレームワーク

本スキルは **pytest + unittest.mock**（Python 標準テストライブラリ）を使用する。
すべてのテストは `unittest.mock.patch` + `pytest.fixture` の規約に従って生成すること。
Streamlit アプリの関数・ロジック層を直接テストするパターンで実装する。

> ⚠️ **絶対必須・直接実行禁止**
>
> このスキルの全ワークフローは、以下に定義するカスタムサブエージェントを
> **Agentツールで起動**して実行すること。
> Claude Code（あなた自身）が直接テストコードを生成することは**厳禁**。

---

## STEP 1: ユーザー情報収集

AskUserQuestionツールで以下を確認する（**最大2回の質問で完結させること**）：

**1回目（必須）**:
- **`app_path`**: 対象アプリのリポジトリルートパス（例: `/home/user/my-pochi-app`）
- **`entrypoint`**: アプリのエントリポイントファイル（例: `app.py`）

**2回目（必要な場合のみ）**:
- **生成対象シナリオの絞り込み**: 全シナリオ生成 or 指定シナリオのみ（デフォルト: 全シナリオ）
- **既存テストの扱い**: `tests/integration/` に既存ファイルがある場合の上書き方針

情報収集後、以下の実行計画を提示して確認を取ること：

```
実行計画:
  STEP 1.5: 前提ファイル確認（integration-test-design.md の存在チェック）
  STEP 2: 追加前提ファイル確認（module-inventory.json / contracts/ の存在チェック）
  STEP 3: Layer3 用 conftest.py 生成（tests/integration/conftest.py）
  STEP 4: Layer3 テストコード生成（設計書の全シナリオをコード化）
  STEP 5: テスト収集・実行確認（--collect-only → pytest）
  STEP 6: 完了レポート
```

---

## STEP 1.5: 設計書の存在確認

`app_path` 確定後、即座に以下を確認する：

```
Glob で {app_path}/tests/.onboarding/integration-test-design.md を検索する。
```

**ファイルが存在しない場合**:
→ 以下のメッセージを出力してスキルを終了する（以降のステップは実行しない）：

```
❌ 結合テスト設計書が見つかりません。

  必要なファイル: {app_path}/tests/.onboarding/integration-test-design.md

  このスキルを実行する前に、まず以下のコマンドで設計書を生成してください：
  「結合テストを設計して」または「pochi-integration-test-designer を起動」

  pochi-integration-test-designer は、Layer3 結合テストのシナリオ設計書を生成します。
```

**ファイルが存在する場合**:
→ STEP 2 に進む。

---

## STEP 2: 追加前提ファイル確認

### 必須ファイル（全て存在が必要）

```
{app_path}/tests/.onboarding/module-inventory.json       ← T0 の出力（必須）
{app_path}/tests/contracts/data-contracts.json           ← T1 の出力（必須）
{app_path}/tests/contracts/risk-catalog.md               ← T1 の出力（必須）
```

### 確認ロジック

**`module-inventory.json` / `contracts/` が存在しない場合**:
```
📋 前提ファイルが見つかりません。
  module-inventory.json または contracts/ が存在しません。

  先に以下のいずれかを実行してください：
    - 「単体テストを生成して」（pochi-unit-test-generator）
    - 「結合テストを設計して」（pochi-integration-test-designer）
```
→ スキル終了

**全て存在する場合** → STEP 3 へ

### `tests/conftest.py` の確認

- `{app_path}/tests/conftest.py` が存在する場合:
  → 内容を Read して、Layer3 で必要な追加設定（_passthrough_decorator / sys.path 等）を特定する
  → `tests/integration/conftest.py` には Layer3 固有設定のみを追加する（共通設定は重複しない）
- `{app_path}/tests/conftest.py` が存在しない場合:
  → STEP 3 で `tests/conftest.py`（共通）と `tests/integration/conftest.py`（Layer3 専用）の両方を生成する

---

## STEP 3: Layer3 用 conftest.py 生成

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"`）を起動すること

```
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow のサブエージェント
test-author を起動し、以下を実行させてください：

【Layer3 conftest.py 生成専用モード】

■ 入力:
  - {app_path}/tests/.onboarding/integration-test-design.md（設計書のモック対象一覧を参照）
  - {app_path}/tests/.onboarding/module-inventory.json（framework フィールドを確認）
  - {app_path}/tests/conftest.py（存在する場合は Read して重複を避ける）

■ tests/integration/conftest.py の生成内容:

  import pytest
  from unittest.mock import MagicMock, patch, ANY
  from pathlib import Path
  import pandas as pd
  import sys
  import importlib

  # ─── Snowflake モックフィクスチャ ───────────────────────────────────────────
  # 設計書の「モック対象一覧」を参照して適切な戻り値を設定すること

  @pytest.fixture
  def mock_snowflake_session():
      """Snowflake セッションのモック。SQLAlchemy ベースの呼び出し用。"""
      mock_session = MagicMock()
      mock_session.bind = MagicMock()
      mock_session.sql = MagicMock(
          return_value=MagicMock(collect=MagicMock(return_value=pd.DataFrame()))
      )
      return mock_session

  @pytest.fixture
  def mock_empty_dataframe():
      """空 DataFrame 返却時の異常系テスト用モック。"""
      return pd.DataFrame()

  @pytest.fixture
  def mock_snowflake_cursor():
      """Snowflake カーソルのモック（fetchall/fetchone 用）。"""
      mock_cursor = MagicMock()
      mock_cursor.fetchall.return_value = []
      mock_cursor.fetchone.return_value = None
      return mock_cursor

  # ─── パス・モジュール管理フィクスチャ ────────────────────────────────────────
  # app_root のパスは {app_path} を参照し、プロジェクト構造に適応させること。

  @pytest.fixture(scope="session")
  def app_path():
      """アプリのルートパスを返す（セッション全体で1回のみ初期化）。"""
      return Path("{app_path}")

  @pytest.fixture
  def app_root(app_path):
      """アプリの app/ ディレクトリへのパスを返す。
      {app_path}/app/ を指すように調整すること。
      """
      app_dir = app_path / "app"
      if not app_dir.exists():
          raise ValueError(f"app directory not found: {app_dir}")
      return app_dir

  @pytest.fixture
  def add_app_to_path(app_root):
      """sys.path にアプリディレクトリを追加するフィクスチャ。
      テスト内で lib.* が import できるようにする。
      """
      app_path_str = str(app_root)
      if app_path_str not in sys.path:
          sys.path.insert(0, app_path_str)
      yield
      if app_path_str in sys.path:
          sys.path.remove(app_path_str)

  @pytest.fixture
  def module_loader(add_app_to_path):
      """アプリ内のモジュールを動的にインポートするヘルパー。
      使用例: module_loader("lib.data_loader") → data_loader モジュール
      """
      def _load(module_path: str):
          if module_path in sys.modules:
              importlib.reload(sys.modules[module_path])
          return importlib.import_module(module_path)
      return _load

  # ─── Streamlit キャッシュのパススルー化 ──────────────────────────────────────

  @pytest.fixture(autouse=True)
  def mock_streamlit_cache():
      """@st.cache_data / @st.cache_resource をパススルー化するフィクスチャ。
      デコレータを取り除き、関数をそのまま実行する。
      """
      def passthrough(func):
          return func
      with patch("streamlit.cache_data", passthrough):
          with patch("streamlit.cache_resource", passthrough):
              yield

  # 設計書の「conftest.py 追加要件」を参照して、
  # 追加のフィクスチャを動的に生成すること

■ tests/conftest.py が存在しない場合のみ追加生成:
  pochi-unit-test-generator の STEP 5 と同等の処理で
  tests/conftest.py（共通設定: sys.path, _MOCK_MODULES）を生成する
  ※ mock_streamlit_cache は tests/integration/conftest.py で定義するため重複しない

■ 収集エラー確認（生成後に必ず実行、最大3回リトライ）:
  cd {app_path} && python -m pytest --collect-only tests/integration/ \
    --tb=line -q 2>&1 | grep -E "ERROR|ModuleNotFoundError|ImportError" | head -20

  エラーが残る場合は修正して再実行する。3回リトライ後もエラーが残る場合は
  残存エラーをユーザーに提示して判断を仰ぐ。
```

### エラー時の対応（STEP 3）
- サブエージェントがエラー終了した場合: エラーメッセージをユーザーに提示し、続行/中止/リトライを確認する

conftest.py が生成されたら STEP 4 へ。

---

## STEP 4: Layer3 テストコード生成

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"`）を起動すること

```
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow のサブエージェント
test-author を起動し、以下を実行させてください：

【Layer3 テストコード実装専用モード】

■ 入力:
  - {app_path}/tests/.onboarding/integration-test-design.md（必ず全シナリオをコード化する）
  - {app_path}/tests/.onboarding/module-inventory.json（patchパス決定に使用）
  - {app_path}/tests/integration/conftest.py（STEP 3 の出力）

■ テストファイル命名規則:
  - ページ単位: tests/integration/test_{page_name}_integration.py
  - 機能単位:   tests/integration/test_{feature_name}_integration.py
  例:
    tests/integration/test_dashboard_integration.py
    tests/integration/test_data_upload_integration.py

■ テストコード実装パターン（pytest + unittest.mock）:

  # ※ 全テストは「2つ以上の実関数を呼び、その接続を検証する」こと。
  # ※ モック対象は外部依存（Snowflake セッション等）のみ。テスト対象関数はモックしない。
  # ※ パターン例は可読性のため from ... import を使用しているが、
  # 実際のテストコード生成時は module_loader フィクスチャ経由でも構わない。
  # 重要なのは「2つ以上の実関数を呼び出す」ことであり、import方法ではない。

  import pytest
  from unittest.mock import patch, MagicMock, call
  import pandas as pd

  # conftest.py の add_app_to_path フィクスチャで sys.path に app/ が追加されている。
  # import と @patch は「lib.*」形式で統一する（「app.lib.*」は使わない）
  # テスト対象の関数は module_loader フィクスチャで import して直接呼び出すこと。

  # パターンA: session_state経由の接続テスト
  class TestSearchFlowIntegration:
      """on_click → session_state → search_btn_is_disabled の接続テスト"""

      @patch("app_pages.visualization_tool.clear_cache_snowflake_sqlalchemy_session")
      def test_検索実行後に同一条件で再検索がブロックされる(
          self, mock_clear_cache, mock_st_session_state
      ):
          # 接続ID: E-001
          from app_pages.visualization_tool import (
              on_click_search_button,      # 実関数1
              search_btn_is_disabled,       # 実関数2
          )
          conditions = InputConditions(
              start_date=date(2024, 1, 1),
              end_date=date(2024, 1, 31),
              prefecture_cd="13",
              city_cd=["13101"],
          )
          render_options = RenderOptions()

          # Step 1: 接続元を実行
          on_click_search_button(conditions, render_options)

          # Step 2: 接続経路を検証
          assert mock_st_session_state["input_conditions"] == conditions

          # Step 3: 接続先を実行
          is_disabled = search_btn_is_disabled(conditions, render_options)

          # Step 4: 最終結果を具体値で検証
          assert is_disabled is True

  # パターンB: 戻り値経由の接続テスト
  class TestAddressDataFlowIntegration:
      """filter → concat のデータフローテスト"""

      def test_フィルタ結果を住所結合に渡せる(self):
          # 接続ID: E-002
          from lib.address import (
              _filter_address_df_by_oaza_popularname,  # 実関数1
              get_concat_address,                       # 実関数2
          )
          source_df = pd.DataFrame({
              "oaza_popularname_kanji": ["神田", "大手町"],
              "city_kanji": ["千代田区", "千代田区"],
          })

          # Step 1: 接続元を実行
          filtered_df, _ = _filter_address_df_by_oaza_popularname(
              source_df, ["千代田区,神田"]
          )

          # Step 2: 接続経路を検証
          assert len(filtered_df) == 1
          assert "oaza_popularname_kanji" in filtered_df.columns

          # Step 3: 接続先を実行（接続元の実出力をそのまま渡す）
          address_list = get_concat_address(filtered_df)

          # Step 4: 最終結果を具体値で検証
          assert len(address_list) == 1
          assert "神田" in address_list[0]

  # パターンC: Snowflakeモック経由の接続テスト
  # Snowflake「セッション」のみモックし、データ取得関数自体は実コード実行する
  class TestDataFetchIntegration:
      """get_si_statistics → 後続処理 の接続テスト"""

      @patch("lib.data_loader._graph_data.get_snowflake_sqlalchemy_session")
      def test_統計データ取得と空判定の連携(self, mock_session):
          mock_session.return_value = MagicMock()
          mock_session.return_value.execute.return_value.fetchall.return_value = [
              (100, 1000000, 500, 200)
          ]

          from lib.data_loader._graph_data import get_si_statistics  # 実関数

          conditions = InputConditions(...)
          result = get_si_statistics(conditions)  # 実コード実行

          # 後続の表示判定が使う形式であることを検証
          assert not result.empty
          assert result["店舗数"].iloc[0] == 100

■ 必須実装ルール:
  1. テスト対象の関数は module_loader フィクスチャで import して直接呼び出す
  2. 関数の戻り値またはモックの呼び出しを必ず検証する
  3. conftest.py の add_app_to_path が sys.path に app/ を追加しているため、
     import と @patch は「lib.*」形式で統一する（「app.lib.*」は使わない）
  4. tests/fixtures/ のデータを活用できる場合は @pytest.fixture 経由で参照する
  5. st.cache_data / st.cache_resource のパススルー化は conftest.py の
     mock_streamlit_cache に委譲する（テストコード内で行わない）
  6. リスク対応シナリオには「# RISK: {リスクID}」コメントを必ず付与する
  7. テスト関数名: test_{機能名}_{条件}_{期待結果} 形式（日本語可）
  8. 例外テストは pytest.raises を使用する
  9. モック呼び出しの検証は assert_called / assert_called_with を使用する
  10. 各テスト関数は2つ以上の実関数を呼び出すこと（import 1つだけは禁止）
  11. モック化した関数を直接呼び出して戻り値を検証するテストは禁止
      NG例: mock_func.return_value = X; result = mock_func(args); assert result == X
  12. アサーションは具体値で書くこと。以下は単独使用禁止:
      - assert isinstance(result, pd.DataFrame)  ← 単独禁止
      - assert result is not None                 ← 単独禁止
      - assert len(result) > 0                    ← 単独禁止
      これらは具体値検証と併用する場合のみ許可
  13. 設計書の「接続経路」に記載されたデータが
      接続元→接続先で正しく受け渡されることを検証すること

■ 禁止事項（AppTest 完全排除）:
  - streamlit.testing.v1.AppTest のいかなる import も禁止
  - AppTest.from_file() / AppTest.from_function() の使用禁止
  - at.run() / at.exception / at.error / at.dataframe の参照禁止
  - create_app_test フィクスチャの使用禁止
  - テスト間の実行順序への依存
  - 本番 Snowflake への接続

■ セルフチェック（コード生成後に実施）:
  - 設計書の全シナリオがコード化されているか確認する
  - AppTest の import / 使用がないか確認する（grep で検索）
    ```bash
    grep -r "AppTest\|from streamlit.testing" tests/integration/
    ```
  - 全テストに module_loader を使ったモジュール import があるか確認する
  - リスク対応シナリオに # RISK: コメントが付与されているか確認する
  - patch パスが lib.* 形式で統一されているか確認する
  - 各テストが2つ以上の実関数を呼んでいるか確認する
    ```bash
    grep -rc "from.*import" tests/integration/
    ```
  - モック直接呼び出しがないか確認する
    ```bash
    grep -rn "mock_.*return_value" tests/integration/
    ```
    で設定した変数を直後に mock_*() で呼び出しているパターンがないか目視確認する
  - isinstance のみのアサーションがないか確認する
    ```bash
    grep -rn "assert isinstance" tests/integration/
    ```
    で検出された行の前後に具体値アサーションが存在することを確認する
  - 設計書の全接続IDがテストコードにコメントとして記載されているか確認する
    ```bash
    grep -rc "接続ID.*E-" tests/integration/
    ```
```

### エラー時の対応（STEP 4）
- サブエージェントがエラー終了した場合: エラーメッセージをユーザーに提示し、続行/中止/リトライを確認する
- `tests/integration/` にファイルが生成されなかった場合: 設計書の内容を確認し、再生成またはスキップをユーザーに確認する

---

## STEP 4.5: 生成コード品質検証

STEP 4 で生成されたテストコードに対して以下の自動チェックを実行する。
NG が検出された場合は STEP 4 のサブエージェントを再起動して修正する（最大2回）。

**チェック1: 複数関数呼び出し**
各テスト関数が少なくとも2つの実関数（from ... import した関数）を
呼び出しているか確認する。
NG: テスト関数内で1つの関数しか呼んでいない

**チェック2: モック直接呼び出し防止**
@patch でモック化した関数を直接呼び出して、
その戻り値をアサーションで検証していないか確認する。
NG: mock_get_stats.return_value = X; result = mock_get_stats(args)

**チェック3: アサーション品質**
`assert isinstance` / `assert ... is not None` / `assert len(...) > 0`
が単独で使用されているテストがないか確認する。
NG: テスト関数内のアサーションが上記のみ

**チェック4: 接続検証の存在**
テスト内で「関数Aの出力 → 関数Bの入力」パターンが存在するか確認する。
OK: `filtered_df = filter_func(df); result = concat_func(filtered_df)`
NG: `result = some_func(args)` のみ（後続関数への受け渡しなし）

grep では直接検出できないため、以下のヒューリスティックで確認する：

  各テスト関数について、以下の2条件を満たすか確認する：
  a. from ... import で2つ以上の関数を import している
  b. 変数代入（`result = func_a(...)`）の後に、
     その変数を別の関数呼び出しの引数として使用している（`func_b(result)`）

  簡易チェック（参考値）:
  ```bash
  # 各テスト関数内の代入パターン数を確認（2回以上あれば接続の可能性が高い）
  grep -rn "^\s\+\w\+ = \w\+(" tests/integration/ | grep -v "mock\|Mock\|patch"
  ```
  代入が各テストで2回以上ある場合は接続パターンの可能性が高い。
  1回のみの場合は目視確認が必要。

  自動チェックで判定できない場合は WARNING として報告し、
  ユーザーに目視確認を促す。NG とはしない。

各チェックの結果をユーザーに提示する:

```
📋 生成コード品質検証:
  チェック1（複数関数呼び出し）: ✅ PASS / ❌ FAIL（該当: test_xxx）
  チェック2（モック直接呼び出し）: ✅ PASS / ❌ FAIL（該当: test_xxx）
  チェック3（アサーション品質）: ✅ PASS / ❌ FAIL（該当: test_xxx）
  チェック4（接続検証）: ✅ PASS / ❌ FAIL（該当: test_xxx）
```

全チェックが PASS したら STEP 5 へ。FAIL がある場合は STEP 4 を再実行して修正する（最大2回）。

---

## STEP 5: テスト収集・実行確認

生成されたテストが正常に収集・実行できるか検証する。

```
以下のコマンドを順番に実行し、結果を確認する：

1. 収集エラー確認（最大3回リトライ）:
   cd {app_path} && python -m pytest --collect-only tests/integration/ -q

   収集エラーが発生した場合、エラー種別に応じて修正対象を特定する：
   - ModuleNotFoundError / ImportError:
       conftest.py の add_app_to_path フィクスチャ設定または
       module_loader の import_module 設定が原因。
       STEP 3 の test-author（subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"）を
       起動して conftest.py を修正する。
   - SyntaxError / NameError / AttributeError:
       テストコード自体に問題がある、または patch パスが不正。
       STEP 4 の test-author を起動して該当テストファイルを修正する。
   - AppTest 関連のエラー（streamlit.testing.v1 not found 等）:
       AppTest の import が残っている。
       該当テストファイルを削除して STEP 4 から再生成する。

2. テスト実行（失敗の確認）:
   cd {app_path} && python -m pytest tests/integration/ -q --tb=short

   失敗テストがある場合:
   → 失敗リストをユーザーに提示する
   → [A] 修正を試みる  [B] RED 状態で完了する  を選択させる
```

### エラー時の対応（STEP 5）
- 収集エラーが3回リトライ後も解消しない場合: 残存エラーをユーザーに提示し、手動対応を促した上で完了レポートに記載する
- テスト失敗が多数ある場合: 失敗リストを提示し、RED 状態での完了とするか修正するかをユーザーに確認する

---

## STEP 6: 完了レポート

> 📏 **実行時間の計測方法**: 各ステップのサブエージェント起動前後のタイムスタンプを記録し、差分を秒単位で記載する。

以下の形式で完了を報告する：

```
✅ pochi-integration-test-generator 完了

📁 生成ファイル一覧:
  Layer3（結合テスト）:
    - {app_path}/tests/integration/conftest.py
    - {app_path}/tests/integration/test_*_integration.py（X ファイル）

📊 テスト数サマリー:
  - Layer3 テスト関数数: X 件
  - 正常系: Y 件 / 異常系: Z 件

📋 設計書カバレッジ（全シナリオ）:
  | シナリオ名 | コード化 | テスト結果 |
  |-----------|---------|----------|
  | シナリオ1 | ✅      | PASS     |
  | シナリオ2 | ✅      | FAIL     |
  ...

📋 risk-catalog.md カバレッジ:
  | リスクID | カバー済み |
  | M001    | ✅        |
  ...

⏱ 実行時間:
  conftest.py 生成: XX 秒
  Layer3 コード生成: XX 秒
  テスト検証: XX 秒
  合計: XX 秒

🚀 次のステップ:
  pytest tests/integration/ -v
  で詳細な動作確認をしてください。

  Layer4（E2E）が必要な場合は pochi-e2e-test-generator を実行してください。
  テストピラミッド全体の監査は pochi-test-strategy-auditor を実行してください。
```

---

## STEP 7: test-progress.json の更新

完了レポート出力後、進捗ファイルを更新する。

```
{app_path}/tests/.onboarding/test-progress.json を Read する（存在する場合）。
```

**ファイルが存在する場合**:
→ `pochi-integration-test-generator` のステップを `completed` に更新し、
  `outputs` と `summary` を記入して書き戻す。
→ `test_results.L3_integration` の値を最新の実行結果に更新する。
→ `framework` フィールドを `"pytest+unittest.mock"` に更新する。
→ `next_action` を `pochi-coverage-fixer`（任意）に更新する。

**ファイルが存在しない場合**:
→ 新規作成は行わない（上流スキルが担う責務のため）。

---

## 既存ファイルの扱い

- `tests/integration/test_*.py` が既に存在する場合:
  → ユーザーに確認: [A] 上書き [B] 差分のみ追加 [C] 中止
- `tests/integration/conftest.py` が既に存在する場合:
  → 内容を Read して確認し、不足分のみ追記する（既存定義は保持する）

---

## 注意事項

- **直接生成禁止**: Claude Code 本体がテストコードを直接書くことは絶対に禁止。必ずサブエージェント経由で生成すること。
- **設計書準拠**: `integration-test-design.md` に記載のないシナリオは生成しない。追加のシナリオが必要な場合は `pochi-integration-test-designer` を再実行するよう案内する。
- **conftest.py 分離**: Layer3 固有フィクスチャは `tests/integration/conftest.py` に配置し、`tests/conftest.py`（共通設定）は Layer1・2 と共存させる。
- **Layer1・2 非対応**: このスキルは Layer3 のみを生成する。Layer1・2 が必要な場合は `pochi-unit-test-generator` を使用すること。
