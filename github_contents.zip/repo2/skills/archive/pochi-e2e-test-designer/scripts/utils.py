"""
共通ユーティリティ関数
"""
import os
import json
import shutil
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List, Tuple

# ロギング設定
logger = logging.getLogger(__name__)


def setup_logging(log_dir: str = "logs") -> None:
    """ロギングの設定"""
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    
    log_file = log_path / "run_log.txt"
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )


def load_config(config_path: Optional[str] = None) -> Dict:
    """設定ファイルを読み込む"""
    if config_path is None:
        # デフォルト設定のパスを推定
        script_dir = Path(__file__).parent
        config_path = script_dir.parent / "config" / "default_config.json"
    
    config_path = Path(config_path)
    
    if not config_path.exists():
        logger.warning(f"設定ファイルが見つかりません: {config_path}")
        # デフォルト設定を返す
        return {
            "ratios": {"basic": 0.6, "boundary": 0.2, "abnormal": 0.15, "other": 0.05},
            "target_total": 125,
            "ambiguous_terms": ["適切", "正しく", "〜すること", "期待通り", "問題ない", "正常に", "想定通り"],
            "ui_match_thresholds": {"exact": True, "partial_ratio": 0.7},
            "default_from_branch": "main",
            "default_to_branch": "HEAD",
            "artifact_dir": "app/pochi-test-guidelines-artifacts",
            "log_dir": "logs",
            "backup_extension": ".bak"
        }
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        logger.info(f"設定ファイルを読み込みました: {config_path}")
        return config
    except Exception as e:
        logger.error(f"設定ファイルの読み込みに失敗: {e}")
        raise


def find_project_root() -> Optional[Path]:
    """プロジェクトルートディレクトリを探索"""
    current = Path.cwd()
    
    # 最大10階層まで上を探索
    for _ in range(10):
        # README.mdまたはtools/ディレクトリの存在をチェック
        if (current / "README.md").exists() or (current / "tools").exists():
            logger.info(f"プロジェクトルートを検出: {current}")
            return current
        
        parent = current.parent
        if parent == current:  # ルートに到達
            break
        current = parent
    
    logger.warning("プロジェクトルートが見つかりません")
    return None


def find_app_structure_analyzer() -> Optional[Path]:
    """app_structure_analyzer.pyのパスを探索
    
    探索優先順:
    1. pochi-test-guidelines/tools/app_structure_analyzer.py
    2. tools/app_structure_analyzer.py
    3. プロジェクトルートからの再帰探索
    """
    project_root = find_project_root()
    if not project_root:
        return None
    
    # 優先順で探索
    candidates = [
        Path.home() / ".claude" / "skills" / "pochi-test-orchestrator" / "guidelines" / "tools" / "app_structure_analyzer.py",
        project_root / "skills" / "pochi-test-orchestrator" / "guidelines" / "tools" / "app_structure_analyzer.py",
        project_root / "pochi-test-guidelines" / "tools" / "app_structure_analyzer.py",  # 後方互換性
        project_root / "tools" / "app_structure_analyzer.py",
    ]
    
    for candidate in candidates:
        if candidate.exists():
            logger.info(f"app_structure_analyzer.pyを検出: {candidate}")
            return candidate
    
    # 再帰探索
    logger.info("標準パスで見つからないため、再帰探索を実行...")
    for path in project_root.rglob("app_structure_analyzer.py"):
        logger.info(f"app_structure_analyzer.pyを検出（再帰探索）: {path}")
        return path
    
    logger.warning("app_structure_analyzer.pyが見つかりません")
    return None


def ensure_artifact_dir(artifact_dir: str = "app/pochi-test-guidelines-artifacts") -> Path:
    """アーティファクトディレクトリを確保"""
    project_root = find_project_root()
    if not project_root:
        project_root = Path.cwd()
    
    artifact_path = project_root / artifact_dir
    artifact_path.mkdir(parents=True, exist_ok=True)
    logger.info(f"アーティファクトディレクトリを確保: {artifact_path}")
    return artifact_path


def create_backup(file_path: Path, backup_extension: str = ".bak") -> Optional[Path]:
    """ファイルのバックアップを作成
    
    Args:
        file_path: バックアップ対象ファイル
        backup_extension: バックアップファイルの拡張子
        
    Returns:
        バックアップファイルのパス（失敗時はNone）
    """
    if not file_path.exists():
        logger.warning(f"バックアップ対象ファイルが存在しません: {file_path}")
        return None
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = file_path.with_suffix(f"{backup_extension}.{timestamp}")
    
    try:
        shutil.copy2(file_path, backup_path)
        logger.info(f"バックアップを作成: {file_path} -> {backup_path}")
        return backup_path
    except Exception as e:
        logger.error(f"バックアップ作成に失敗: {e}")
        return None


def check_file_exists(file_path: Path) -> bool:
    """ファイルの存在確認"""
    exists = file_path.exists() and file_path.is_file()
    if exists:
        logger.debug(f"ファイルが存在します: {file_path}")
    else:
        logger.debug(f"ファイルが存在しません: {file_path}")
    return exists


def check_dir_exists(dir_path: Path) -> bool:
    """ディレクトリの存在確認"""
    exists = dir_path.exists() and dir_path.is_dir()
    if exists:
        logger.debug(f"ディレクトリが存在します: {dir_path}")
    else:
        logger.debug(f"ディレクトリが存在しません: {dir_path}")
    return exists


def check_dir_not_empty(dir_path: Path) -> bool:
    """ディレクトリが空でないことを確認"""
    if not check_dir_exists(dir_path):
        return False
    
    has_files = any(dir_path.iterdir())
    if has_files:
        logger.debug(f"ディレクトリにファイルが存在します: {dir_path}")
    else:
        logger.debug(f"ディレクトリは空です: {dir_path}")
    return has_files


def sanitize_path_for_filename(path: str) -> str:
    """パスをファイル名として使える形式にサニタイズ"""
    # スラッシュとバックスラッシュをアンダースコアに
    sanitized = path.replace("/", "_").replace("\\", "_")
    # その他の問題文字を除去
    sanitized = sanitized.replace(":", "_").replace("*", "_").replace("?", "_")
    sanitized = sanitized.replace('"', "_").replace("<", "_").replace(">", "_")
    sanitized = sanitized.replace("|", "_")
    return sanitized


def save_run_summary(summary_data: Dict, artifact_dir: str = "app/pochi-test-guidelines-artifacts") -> None:
    """実行サマリをJSONで保存"""
    artifact_path = ensure_artifact_dir(artifact_dir)
    summary_file = artifact_path / "last_run_summary.json"
    
    # タイムスタンプを追加
    summary_data["timestamp"] = datetime.now().isoformat()
    
    try:
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary_data, f, ensure_ascii=False, indent=2)
        logger.info(f"実行サマリを保存: {summary_file}")
    except Exception as e:
        logger.error(f"実行サマリの保存に失敗: {e}")


def confirm_action(message: str, default: bool = False) -> bool:
    """ユーザーに確認を求める
    
    Args:
        message: 確認メッセージ
        default: デフォルト値（Enterキーのみの場合）
        
    Returns:
        ユーザーの選択（True/False）
    """
    suffix = " [Y/n]: " if default else " [y/N]: "
    
    while True:
        response = input(message + suffix).strip().lower()
        
        if response == "":
            return default
        elif response in ["y", "yes"]:
            return True
        elif response in ["n", "no"]:
            return False
        else:
            print("無効な入力です。'y' または 'n' を入力してください。")


def get_git_branch_list() -> List[str]:
    """利用可能なGitブランチのリストを取得"""
    import subprocess
    
    try:
        result = subprocess.run(
            ["git", "branch", "-a"],
            capture_output=True,
            text=True,
            check=True
        )
        branches = []
        for line in result.stdout.split("\n"):
            line = line.strip()
            if line and not line.startswith("*"):
                # リモートブランチのプレフィックスを除去
                branch = line.replace("remotes/origin/", "")
                if branch:
                    branches.append(branch)
        return branches
    except Exception as e:
        logger.warning(f"ブランチリストの取得に失敗: {e}")
        return []


def detect_main_branch() -> str:
    """メインブランチを検出（main または develop）"""
    branches = get_git_branch_list()
    
    # 優先順: main > master > develop > HEAD
    for candidate in ["main", "master", "develop"]:
        if candidate in branches:
            logger.info(f"メインブランチを検出: {candidate}")
            return candidate
    
    logger.warning("メインブランチが検出できませんでした。HEADを使用します。")
    return "HEAD"
