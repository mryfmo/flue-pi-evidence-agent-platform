"""
品質ゲートスクリプト

test_cases.mdの品質を検証し、quality_report.mdを生成する。
観点比率、UI要素網羅、具体値必須チェックを実施。
"""
import sys
import re
import logging
import argparse
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from collections import Counter

from security import enforce_skill_only
from utils import (
    setup_logging,
    load_config,
    ensure_artifact_dir,
    check_file_exists
)

logger = logging.getLogger(__name__)


class QualityReport:
    """品質レポートを保持するクラス"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.test_case_count = 0
        self.perspective_counts = {"basic": 0, "boundary": 0, "abnormal": 0, "other": 0}
        self.ui_coverage = {"total": 0, "covered": 0, "uncovered": []}
        self.ambiguous_count = 0
        self.ambiguous_examples = []
        self.issues = []
        self.warnings = []
        self.passed = True
    
    def add_issue(self, message: str) -> None:
        """重大な問題を追加"""
        self.issues.append(message)
        self.passed = False
        logger.error(f"ISSUE: {message}")
    
    def add_warning(self, message: str) -> None:
        """警告を追加"""
        self.warnings.append(message)
        logger.warning(f"WARNING: {message}")
    
    def generate_report(self) -> str:
        """レポートを生成"""
        report = """# テストケース品質レポート

## 総合評価

"""
        
        if self.passed:
            report += "✅ **合格** - すべての品質基準を満たしています\n\n"
        else:
            report += "❌ **不合格** - 以下の問題を修正してください\n\n"
        
        # 1. テストケース数
        report += f"""## 1. テストケース数

- **総数**: {self.test_case_count}件
- **目標**: {self.config['target_total']}件
- **達成率**: {self.test_case_count / self.config['target_total'] * 100:.1f}%

"""
        
        if self.test_case_count < self.config['target_total'] * 0.9:
            report += f"⚠️ 目標件数の90%未満です。テストケースを追加してください。\n\n"
        elif self.test_case_count > self.config['target_total'] * 1.1:
            report += f"ℹ️ 目標件数の110%を超えています。必要に応じて見直しを検討してください。\n\n"
        else:
            report += f"✅ 適切な件数です。\n\n"
        
        # 2. 観点比率
        report += """## 2. 観点比率

| 観点 | 実績 | 目標 | 達成率 | 評価 |
|------|------|------|--------|------|
"""
        
        for perspective in ["basic", "boundary", "abnormal", "other"]:
            actual_count = self.perspective_counts[perspective]
            actual_ratio = actual_count / max(self.test_case_count, 1)
            target_ratio = self.config['ratios'][perspective]
            achievement = actual_ratio / target_ratio * 100 if target_ratio > 0 else 0
            
            status = "✅" if 80 <= achievement <= 120 else "⚠️"
            
            report += f"| {perspective} | {actual_count}件 ({actual_ratio*100:.1f}%) | {target_ratio*100:.0f}% | {achievement:.1f}% | {status} |\n"
        
        report += "\n"
        
        # 3. UI要素網羅
        report += f"""## 3. UI要素網羅

- **総UI要素数**: {self.ui_coverage['total']}個
- **カバー済み**: {self.ui_coverage['covered']}個
- **カバレッジ**: {self.ui_coverage['covered'] / max(self.ui_coverage['total'], 1) * 100:.1f}%

"""
        
        if self.ui_coverage['uncovered']:
            report += "### 未カバーのUI要素\n\n"
            for ui_element in self.ui_coverage['uncovered'][:10]:  # 最大10件
                report += f"- {ui_element}\n"
            if len(self.ui_coverage['uncovered']) > 10:
                report += f"\n...他{len(self.ui_coverage['uncovered']) - 10}件\n"
            report += "\n"
        else:
            report += "✅ すべてのUI要素がカバーされています。\n\n"
        
        # 4. 具体値必須チェック
        report += f"""## 4. 具体値必須チェック

- **曖昧表現の検出数**: {self.ambiguous_count}件

"""
        
        if self.ambiguous_count > 0:
            report += "### 検出された曖昧表現\n\n"
            for example in self.ambiguous_examples[:10]:  # 最大10件
                report += f"- {example}\n"
            if len(self.ambiguous_examples) > 10:
                report += f"\n...他{len(self.ambiguous_examples) - 10}件\n"
            report += "\n⚠️ 前提条件・期待結果は具体的な数値、日付、データ例を含めてください。\n\n"
        else:
            report += "✅ 曖昧な表現は検出されませんでした。\n\n"
        
        # 5. 問題と警告
        if self.issues:
            report += "## 重大な問題\n\n"
            for issue in self.issues:
                report += f"- ❌ {issue}\n"
            report += "\n"
        
        if self.warnings:
            report += "## 警告\n\n"
            for warning in self.warnings:
                report += f"- ⚠️ {warning}\n"
            report += "\n"
        
        # 6. 改善指示
        report += "## 改善指示\n\n"
        
        if not self.passed:
            report += "以下の項目を修正してください：\n\n"
            
            if self.test_case_count < self.config['target_total'] * 0.9:
                deficit = self.config['target_total'] - self.test_case_count
                report += f"1. テストケースを約{deficit}件追加（目標{self.config['target_total']}件）\n"
            
            for perspective in ["basic", "boundary", "abnormal", "other"]:
                actual_ratio = self.perspective_counts[perspective] / max(self.test_case_count, 1)
                target_ratio = self.config['ratios'][perspective]
                if actual_ratio < target_ratio * 0.8:
                    deficit = int(target_ratio * self.config['target_total']) - self.perspective_counts[perspective]
                    report += f"2. {perspective}観点のテストケースを約{deficit}件追加\n"
            
            if self.ui_coverage['uncovered']:
                report += f"3. 未カバーのUI要素（{len(self.ui_coverage['uncovered'])}個）に対応するテストケースを追加\n"
            
            if self.ambiguous_count > 10:
                report += f"4. 曖昧表現（{self.ambiguous_count}件）を具体的な値に修正\n"
        else:
            report += "品質基準を満たしています。問題ありません。\n"
        
        return report


def count_test_cases(content: str) -> int:
    """テストケースの総数をカウント"""
    # "### テストケースID: "で始まる行をカウント
    pattern = r'^###\s+テストケースID:\s+'
    matches = re.findall(pattern, content, re.MULTILINE)
    return len(matches)


def analyze_perspectives(content: str, config: Dict) -> Dict[str, int]:
    """観点の分類をカウント
    
    タグ、見出し、キーワードの三段構えで判定
    """
    counts = {"basic": 0, "boundary": 0, "abnormal": 0, "other": 0}
    
    # テストケースブロックを抽出
    test_case_blocks = re.split(r'^###\s+テストケースID:\s+', content, flags=re.MULTILINE)[1:]
    
    for block in test_case_blocks:
        # タグでの判定
        if re.search(r'\[基本\]|\[正常\]', block):
            counts["basic"] += 1
        elif re.search(r'\[境界\]|\[限界\]', block):
            counts["boundary"] += 1
        elif re.search(r'\[異常\]|\[エラー\]|\[例外\]', block):
            counts["abnormal"] += 1
        else:
            # キーワードでの判定（フォールバック）
            if re.search(r'正常|基本|通常|標準', block):
                counts["basic"] += 1
            elif re.search(r'境界|限界|最大|最小|上限|下限', block):
                counts["boundary"] += 1
            elif re.search(r'異常|エラー|例外|不正|無効', block):
                counts["abnormal"] += 1
            else:
                counts["other"] += 1
    
    return counts


def extract_ui_elements(app_structure_content: str) -> List[str]:
    """app_structure.mdからUI要素を抽出"""
    ui_elements = []
    
    # "## UI要素情報"セクションを探索
    ui_section_match = re.search(
        r'##\s+UI要素情報.*?(?=\n##|\Z)',
        app_structure_content,
        re.DOTALL
    )
    
    if ui_section_match:
        ui_section = ui_section_match.group(0)
        
        # リスト項目を抽出（"- "で始まる行）
        list_items = re.findall(r'^-\s+(.+)$', ui_section, re.MULTILINE)
        ui_elements.extend(list_items)
        
        # テーブルからも抽出（| で区切られた行）
        table_rows = re.findall(r'^\|([^|]+)\|', ui_section, re.MULTILINE)
        for row in table_rows:
            if row.strip() and not row.strip().startswith('-'):
                ui_elements.append(row.strip())
    
    # 重複を除去
    ui_elements = list(set(ui_elements))
    
    logger.info(f"UI要素を{len(ui_elements)}個抽出しました")
    return ui_elements


def check_ui_coverage(
    test_cases_content: str,
    ui_elements: List[str],
    config: Dict
) -> Dict:
    """UI要素のカバレッジをチェック"""
    covered = []
    uncovered = []
    
    exact_match = config['ui_match_thresholds']['exact']
    partial_ratio = config['ui_match_thresholds'].get('partial_ratio', 0.7)
    
    for ui_element in ui_elements:
        # 完全一致チェック
        if ui_element in test_cases_content:
            covered.append(ui_element)
            continue
        
        # 部分一致チェック（単語単位）
        words = ui_element.split()
        if len(words) > 1:
            # 複合語の場合、一定割合以上の単語が含まれているかチェック
            matched_words = sum(1 for word in words if word in test_cases_content)
            if matched_words / len(words) >= partial_ratio:
                covered.append(ui_element)
                continue
        
        # カバーされていない
        uncovered.append(ui_element)
    
    return {
        "total": len(ui_elements),
        "covered": len(covered),
        "uncovered": uncovered
    }


def check_ambiguous_terms(content: str, config: Dict) -> Tuple[int, List[str]]:
    """曖昧な表現をチェック"""
    ambiguous_terms = config.get('ambiguous_terms', [])
    examples = []
    
    # テストケースブロックを抽出
    test_case_blocks = re.split(r'^###\s+テストケースID:\s+', content, flags=re.MULTILINE)[1:]
    
    for i, block in enumerate(test_case_blocks, 1):
        # 前提条件と期待結果のセクションを抽出
        precondition_match = re.search(r'前提条件.*?:(.*?)(?=\n\*\*|###|\Z)', block, re.DOTALL)
        expected_match = re.search(r'期待結果.*?:(.*?)(?=\n\*\*|###|\Z)', block, re.DOTALL)
        
        sections = []
        if precondition_match:
            sections.append(("前提条件", precondition_match.group(1)))
        if expected_match:
            sections.append(("期待結果", expected_match.group(1)))
        
        for section_name, section_text in sections:
            for term in ambiguous_terms:
                if term in section_text:
                    examples.append(f"テストケース#{i} {section_name}に「{term}」を含む")
                    if len(examples) >= 20:  # 最大20件
                        return len(examples), examples
    
    return len(examples), examples


def run_quality_gate(
    test_cases_path: Path,
    app_structure_path: Optional[Path] = None,
    config: Optional[Dict] = None
) -> Tuple[QualityReport, str]:
    """品質ゲートを実行
    
    Args:
        test_cases_path: test_cases.mdのパス
        app_structure_path: app_structure.mdのパス
        config: 設定
        
    Returns:
        (QualityReport, レポート文字列)
    """
    if config is None:
        config = load_config()
    
    logger.info("=" * 70)
    logger.info("品質ゲートを開始します")
    logger.info("=" * 70)
    
    report = QualityReport(config)
    
    # test_cases.mdを読み込み
    if not check_file_exists(test_cases_path):
        report.add_issue(f"test_cases.mdが見つかりません: {test_cases_path}")
        return report, report.generate_report()
    
    try:
        with open(test_cases_path, 'r', encoding='utf-8') as f:
            test_cases_content = f.read()
    except Exception as e:
        report.add_issue(f"test_cases.mdの読み込みに失敗: {e}")
        return report, report.generate_report()
    
    # 1. テストケース数のカウント
    logger.info("テストケース数をカウント中...")
    report.test_case_count = count_test_cases(test_cases_content)
    logger.info(f"テストケース総数: {report.test_case_count}件")
    
    if report.test_case_count == 0:
        report.add_issue("テストケースが1件も見つかりません")
        return report, report.generate_report()
    
    if report.test_case_count < config['target_total'] * 0.9:
        report.add_issue(
            f"テストケース数が目標の90%未満です（{report.test_case_count}/{config['target_total']}件）"
        )
    elif report.test_case_count < config['target_total']:
        report.add_warning(
            f"テストケース数が目標未達です（{report.test_case_count}/{config['target_total']}件）"
        )
    
    # 2. 観点比率の分析
    logger.info("観点比率を分析中...")
    report.perspective_counts = analyze_perspectives(test_cases_content, config)
    
    for perspective, count in report.perspective_counts.items():
        actual_ratio = count / max(report.test_case_count, 1)
        target_ratio = config['ratios'][perspective]
        
        if actual_ratio < target_ratio * 0.8:
            report.add_issue(
                f"{perspective}観点の比率が目標の80%未満です（{actual_ratio*100:.1f}% / 目標{target_ratio*100:.0f}%）"
            )
        elif actual_ratio < target_ratio * 0.9:
            report.add_warning(
                f"{perspective}観点の比率が目標の90%未満です（{actual_ratio*100:.1f}% / 目標{target_ratio*100:.0f}%）"
            )
    
    # 3. UI要素網羅のチェック
    if app_structure_path and check_file_exists(app_structure_path):
        logger.info("UI要素網羅をチェック中...")
        try:
            with open(app_structure_path, 'r', encoding='utf-8') as f:
                app_structure_content = f.read()
            
            ui_elements = extract_ui_elements(app_structure_content)
            report.ui_coverage = check_ui_coverage(test_cases_content, ui_elements, config)
            
            coverage_ratio = report.ui_coverage['covered'] / max(report.ui_coverage['total'], 1)
            
            if coverage_ratio < 0.8:
                report.add_issue(
                    f"UI要素のカバレッジが80%未満です（{coverage_ratio*100:.1f}%）"
                )
            elif coverage_ratio < 0.9:
                report.add_warning(
                    f"UI要素のカバレッジが90%未満です（{coverage_ratio*100:.1f}%）"
                )
        except Exception as e:
            logger.error(f"UI要素網羅チェックに失敗: {e}")
            report.add_warning("UI要素網羅チェックをスキップしました")
    else:
        logger.warning("app_structure.mdが見つかりません。UI要素網羅チェックをスキップします。")
    
    # 4. 曖昧表現のチェック
    logger.info("曖昧表現をチェック中...")
    report.ambiguous_count, report.ambiguous_examples = check_ambiguous_terms(test_cases_content, config)
    
    if report.ambiguous_count > 20:
        report.add_issue(f"曖昧な表現が多すぎます（{report.ambiguous_count}件）")
    elif report.ambiguous_count > 10:
        report.add_warning(f"曖昧な表現が検出されました（{report.ambiguous_count}件）")
    
    # レポート生成
    logger.info("=" * 70)
    logger.info("品質ゲートが完了しました")
    logger.info(f"総合評価: {'合格' if report.passed else '不合格'}")
    logger.info("=" * 70)
    
    return report, report.generate_report()


def main():
    """メイン関数"""
    # Skills専用モードチェック
    enforce_skill_only()
    
    parser = argparse.ArgumentParser(
        description="test_cases.mdの品質を検証し、レポートを生成します",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        "--test-cases",
        type=Path,
        help="test_cases.mdのパス（デフォルト: app/pochi-test-guidelines-artifacts/test_cases.md）"
    )
    parser.add_argument(
        "--app-structure",
        type=Path,
        help="app_structure.mdのパス（デフォルト: app/pochi-test-guidelines-artifacts/app_structure.md）"
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="レポート出力先（デフォルト: app/pochi-test-guidelines-artifacts/quality_report.md）"
    )
    
    args = parser.parse_args()
    
    # ロギング設定
    setup_logging()
    
    # 設定読み込み
    config = load_config()
    
    # パスの設定
    artifact_dir = ensure_artifact_dir(config.get("artifact_dir", "app/pochi-test-guidelines-artifacts"))
    
    test_cases_path = args.test_cases if args.test_cases else artifact_dir / "test_cases.md"
    app_structure_path = args.app_structure if args.app_structure else artifact_dir / "app_structure.md"
    output_path = args.output if args.output else artifact_dir / "quality_report.md"
    
    # 品質ゲート実行
    report_obj, report_text = run_quality_gate(test_cases_path, app_structure_path, config)
    
    # レポートを保存
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(report_text)
        logger.info(f"品質レポートを保存しました: {output_path}")
    except Exception as e:
        logger.error(f"レポートの保存に失敗: {e}")
        return 1
    
    # 実行サマリを更新（last_run_summary.jsonが存在する場合）
    from utils import save_run_summary
    import json
    
    summary_file = artifact_dir / "last_run_summary.json"
    if summary_file.exists():
        try:
            with open(summary_file, 'r', encoding='utf-8') as f:
                summary_data = json.load(f)
            
            # 品質ゲート結果を追加
            summary_data["quality_gate"] = {
                "executed": True,
                "passed": report_obj.passed,
                "test_case_count": report_obj.test_case_count,
                "target_count": config['target_total'],
                "perspective_counts": report_obj.perspective_counts,
                "ui_coverage_ratio": report_obj.ui_coverage['covered'] / max(report_obj.ui_coverage['total'], 1) if report_obj.ui_coverage['total'] > 0 else 0,
                "ambiguous_count": report_obj.ambiguous_count,
                "issues_count": len(report_obj.issues),
                "warnings_count": len(report_obj.warnings),
                "report_path": str(output_path)
            }
            
            # 更新を保存
            save_run_summary(summary_data, config.get("artifact_dir", "app/pochi-test-guidelines-artifacts"))
            logger.info("実行サマリに品質ゲート結果を追加しました")
        except Exception as e:
            logger.warning(f"実行サマリの更新に失敗: {e}")
    
    # コンソールにも表示
    print("\n" + report_text)
    
    # 終了コード
    return 0 if report_obj.passed else 1


if __name__ == "__main__":
    sys.exit(main())
