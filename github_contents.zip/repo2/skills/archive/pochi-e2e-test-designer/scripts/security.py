"""
セキュリティユーティリティ

コマンドインジェクション対策、パス検証、入力サニタイズなどの
セキュリティ関連機能を提供する。
"""
import os
import sys
import re
import shlex
import logging
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)


class SecurityError(Exception):
    """セキュリティ関連のエラー"""
    pass


def enforce_skill_only():
    """Skills専用モードを強制する
    
    環境変数POCHI_SKILL_ACTIVEが"1"でない場合、スクリプトを終了する。
    デバッグ用のバイパス（POCHI_SKILL_DEBUG=1）も提供。
    
    Raises:
        SystemExit: Skills専用モードでない場合（exit code 2）
    """
    # デバッグ用バイパス（本番では使用しない）
    if os.environ.get("POCHI_SKILL_DEBUG") == "1":
        logger.warning("⚠️  デバッグモード: Skills専用チェックをバイパスしました")
        return
    
    if os.environ.get("POCHI_SKILL_ACTIVE") != "1":
        error_msg = """
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
❌ エラー: Skills専用モードでのみ実行可能

このツールはClaude Code Skills経由でのみ起動できます。

【起動方法】
Claude Codeで以下のキーワードを使用してください：
  • 「テストケースを生成して」
  • 「パターン3で更新」
  • 「品質チェックして」
  
詳細: skills/pochi-test-orchestrator/SKILL.md を参照
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        """
        print(error_msg, file=sys.stderr)
        
        # ログファイルにも記録
        logger.error("skill-only enforcement: failed - POCHI_SKILL_ACTIVE not set")
        
        sys.exit(2)
    
    logger.info("skill-only enforcement: passed")


def validate_git_ref(ref: str) -> bool:
    """Gitリファレンスの安全性を検証
    
    Args:
        ref: Gitリファレンス（ブランチ名、コミットハッシュ等）
        
    Returns:
        安全な場合True
        
    Raises:
        SecurityError: 危険な文字列が含まれる場合
    """
    # 許可する文字: 英数字、ハイフン、アンダースコア、スラッシュ、ドット、キャレット
    if not re.match(r'^[a-zA-Z0-9/_.\-^]+$', ref):
        raise SecurityError(f"不正なGitリファレンス: {ref}")
    
    # 危険なパターンを拒否
    dangerous_patterns = [
        r'\.\./',      # ディレクトリトラバーサル
        r'\$\(',       # コマンド置換
        r'`',          # バッククォート
        r'&&',         # コマンド連結
        r'\|\|',       # コマンド連結
        r';',          # コマンド区切り
        r'\|',         # パイプ
        r'>',          # リダイレクト
        r'<',          # リダイレクト
    ]
    
    for pattern in dangerous_patterns:
        if re.search(pattern, ref):
            raise SecurityError(f"危険なパターンが検出されました: {ref}")
    
    logger.debug(f"Gitリファレンスの検証成功: {ref}")
    return True


def validate_path_in_artifacts(
    path: Path,
    artifact_root: Path,
    allow_create: bool = False
) -> bool:
    """パスがアーティファクトディレクトリ配下にあることを検証
    
    Args:
        path: 検証するパス
        artifact_root: アーティファクトルートディレクトリ
        allow_create: 存在しないパスの作成を許可するか
        
    Returns:
        安全な場合True
        
    Raises:
        SecurityError: パスがアーティファクトディレクトリ外の場合
    """
    try:
        # 絶対パスに変換
        abs_path = path.resolve()
        abs_artifact_root = artifact_root.resolve()
        
        # アーティファクトディレクトリ配下かチェック
        if not str(abs_path).startswith(str(abs_artifact_root)):
            raise SecurityError(
                f"パスがアーティファクトディレクトリ外です: {path}\n"
                f"許可されるディレクトリ: {artifact_root}"
            )
        
        # 既存のパスかチェック
        if not allow_create and not abs_path.exists():
            raise SecurityError(f"パスが存在しません: {path}")
        
        logger.debug(f"パス検証成功: {path}")
        return True
        
    except Exception as e:
        if isinstance(e, SecurityError):
            raise
        raise SecurityError(f"パス検証エラー: {e}")


def sanitize_command_args(args: List[str]) -> List[str]:
    """コマンド引数をサニタイズ
    
    Args:
        args: コマンド引数のリスト
        
    Returns:
        サニタイズされた引数のリスト
        
    Raises:
        SecurityError: 危険な引数が含まれる場合
    """
    sanitized = []
    
    for arg in args:
        # 空文字列はスキップ
        if not arg:
            continue
        
        # 危険な文字を検出
        dangerous_chars = ['$', '`', '|', '&', ';', '\n', '\r']
        for char in dangerous_chars:
            if char in arg:
                raise SecurityError(
                    f"危険な文字が引数に含まれています: '{char}' in '{arg}'"
                )
        
        # shlex.quoteでエスケープ
        sanitized.append(shlex.quote(arg))
    
    logger.debug(f"コマンド引数のサニタイズ完了: {len(sanitized)}個")
    return sanitized


def validate_file_extension(
    path: Path,
    allowed_extensions: List[str]
) -> bool:
    """ファイル拡張子を検証
    
    Args:
        path: ファイルパス
        allowed_extensions: 許可する拡張子のリスト（例: ['.md', '.txt']）
        
    Returns:
        許可された拡張子の場合True
        
    Raises:
        SecurityError: 許可されていない拡張子の場合
    """
    if path.suffix not in allowed_extensions:
        raise SecurityError(
            f"許可されていないファイル拡張子: {path.suffix}\n"
            f"許可される拡張子: {', '.join(allowed_extensions)}"
        )
    
    logger.debug(f"ファイル拡張子の検証成功: {path.suffix}")
    return True


def check_file_size(
    path: Path,
    max_size_mb: int = 10
) -> bool:
    """ファイルサイズを検証
    
    Args:
        path: ファイルパス
        max_size_mb: 最大サイズ（MB）
        
    Returns:
        制限内の場合True
        
    Raises:
        SecurityError: ファイルサイズが大きすぎる場合
    """
    if not path.exists():
        raise SecurityError(f"ファイルが存在しません: {path}")
    
    size_mb = path.stat().st_size / (1024 * 1024)
    
    if size_mb > max_size_mb:
        raise SecurityError(
            f"ファイルサイズが制限を超えています: {size_mb:.2f}MB (最大{max_size_mb}MB)"
        )
    
    logger.debug(f"ファイルサイズの検証成功: {size_mb:.2f}MB")
    return True


def validate_write_operation(
    target_path: Path,
    artifact_root: Path,
    allowed_extensions: Optional[List[str]] = None,
    max_size_mb: int = 50
) -> bool:
    """書き込み操作の安全性を総合的に検証
    
    Args:
        target_path: 書き込み対象パス
        artifact_root: アーティファクトルートディレクトリ
        allowed_extensions: 許可する拡張子（Noneの場合は制限なし）
        max_size_mb: 最大ファイルサイズ（MB）
        
    Returns:
        安全な場合True
        
    Raises:
        SecurityError: 安全でない場合
    """
    logger.info(f"書き込み操作の検証: {target_path}")
    
    # パスの検証
    validate_path_in_artifacts(target_path, artifact_root, allow_create=True)
    
    # 拡張子の検証
    if allowed_extensions:
        validate_file_extension(target_path, allowed_extensions)
    
    # 既存ファイルのサイズチェック
    if target_path.exists():
        check_file_size(target_path, max_size_mb)
    
    logger.info("書き込み操作の検証成功")
    return True


# よく使う拡張子リスト
ALLOWED_MARKDOWN_EXTENSIONS = ['.md']
ALLOWED_TEXT_EXTENSIONS = ['.txt', '.md', '.json', '.csv']
ALLOWED_ALL_TEXT = ['.txt', '.md', '.json', '.csv', '.yaml', '.yml', '.log']
