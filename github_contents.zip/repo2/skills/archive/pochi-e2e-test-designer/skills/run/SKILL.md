---
name: pochi-e2e-test-designer
description: >-
  実装済みコードからLayer4 E2Eテストケース設計書（e2e-test-design-functional.md /
  e2e-test-design-scenario.md）を生成するSkill。pochi-test-orchestratorの後継で汎用化版。
  「E2Eテストケースを設計して」「E2Eテスト設計書を生成」「E2Eテストを設計」
  「pochi-e2e-test-designer を起動」「Pochiのテストケースを生成して」（後方互換）などで起動する。
triggers:
  - E2Eテストケースを設計して
  - E2Eテスト設計書を生成
  - E2Eテストを設計
  - pochi-e2e-test-designer を起動
  - Pochiのテストケースを生成して
  - pochi-test-orchestrator を起動
  - テストケースを生成して
---

# Skill: pochi-e2e-test-designer

**このSkillは、実装済みコードからLayer4（Playwright）E2Eテストケース設計書を生成します。**

`pochi-test-orchestrator` の後継・並置版。Layer名称を統一し、出力パスを `tests/.onboarding/` に統一した汎用版です。

## Layer 3 / Layer 4 の区別

| 区分 | テスト種別 | フレームワーク | Skill |
|------|----------|--------------|-------|
| Layer 3 | 結合テスト（AppTest） | AppTest（モックあり・サーバーレス・単一ページ） | pochi-integration-test-designer / pochi-integration-test-generator |
| Layer 4 | E2Eテスト（Playwright） | Playwright（実ブラウザ・実サーバー・クリティカルパス） | **このSkill** → pochi-e2e-test-generator |

**Layer 4 が必要な観点:**
- ブラウザ固有機能（ファイルDL、ポップアップ）
- 複数ページ遷移を含む重要動線
- 利用頻度の高い日常的な機能
- データ書き込みを含むクリティカルパス

## Trigger Phrases

### 汎用トリガー（推奨）
- E2Eテストケースを設計して
- E2Eテスト設計書を生成
- E2Eテストを設計
- pochi-e2e-test-designer を起動

### 後方互換トリガー（既存ユーザー向け）
- Pochiのテストケースを生成して
- pochi-test-orchestrator を起動
- テストケースを生成して

## When

### 起動条件
上記トリガーフレーズのいずれかが発話されたら、直ちにこのSkillを起動してください。

### 前提条件
- Gitリポジトリである
- アプリのソースコードが存在する（`app/` または `src/` 配下）

### 起動しない条件（誤起動防止）
- ❌ 「テストしたい」
- ❌ 「レビューして」
- ❌ 「確認して」
- ❌ 「結合テストを設計して」（→ pochi-integration-test-designer を使用）

## STEP 0: test-strategy-config.json の存在確認と e2e_enabled チェック（起動直後に必ず実行）

スクリプト実行前に `test-strategy-config.json` を確認する。

```
Glob で {app_path}/tests/.onboarding/test-strategy-config.json を検索する。
app_path が未確定の場合は、app/ または src/ ディレクトリを Glob で自動特定する。
```

**ファイルが存在しない場合**:
→ 以下のメッセージを出力してスキルを終了する（以降のステップは実行しない）：

```
❌ テスト戦略設定ファイルが見つかりません。

  必要なファイル: {app_path}/tests/.onboarding/test-strategy-config.json

  このスキルを実行する前に、まず以下のコマンドでテスト戦略を初期化してください：
  「テスト戦略を初期化して」または「pochi-test-strategy-initializer を起動」

  pochi-test-strategy-initializer は、モック方針・品質目標・Layer比率を決定し、
  test-strategy-config.json を生成します。
```

**ファイルが存在し、かつ `skill_preferences.e2e_enabled: false` の場合**:

```
このプロジェクトでは E2E テストが無効化されています。

test-strategy-config.json の設定:
  skill_preferences.e2e_enabled: false

E2E テストを有効化するには、以下のファイルを編集してください:
  {app_path}/tests/.onboarding/test-strategy-config.json
    "skill_preferences": {
      "e2e_enabled": true,        ← true に変更
      "critical_paths": [
        "ログイン → ダッシュボード表示",  ← 重要動線を記載
        "CSVアップロード → 集計 → ダウンロード"
      ]
    }

変更後、再度「E2Eテストを設計して」と入力してください。
```
→ スキルを終了する（以降のステップは実行しない）

**ファイルが存在し、かつ `skill_preferences.e2e_enabled: true` の場合**:
→ 通常通り以降のステップを実行する。

---

## Do

**STEP 1 のスクリプト実行:**

```bash
POCHI_SKILL_ACTIVE=1 python /home/user/pochi-dp-developer-docs/skills/test/pochi-e2e-test-designer/skill_entry.py
```

## Instructions

**以下の手順を順番に実行してください。**

---

### STEP 1: skill_entry.py 実行（準備フェーズ）

Do節のコマンドを実行してください。このスクリプトは環境チェック、差分生成、コンテキスト生成を行います。

**アプリパス解決（汎用化）:**
1. 環境変数 `POCHI_APP_PATH` があればそれを使用
2. なければ `app/`・`src/` ディレクトリを Glob で自動特定
3. `spec.json` に `projectRoot` があればそれを使用

**エラー時のフォールバック:**
- スクリプトが存在しない/失敗する場合: 手動で以下を特定してください
  - アプリルートパス（`{app_path}`）
  - Gitベースブランチ（`main` または `master`）
  - 差分ファイルパス（Partial選択時）

---

### STEP 2: e2e-design-context.json 読み込み（必須）

STEP 1 完了後、以下の優先順位でファイルを読み込んでください：

1. `{app_path}/tests/.onboarding/e2e-design-context.json`（設計コンテキスト・新パス）
2. `app/pochi-test-guidelines-artifacts/generation_context.json`（旧パス・後方互換フォールバック）

> **ファイル用途の区別**:
> - `e2e-design-context.json`（このSkillの出力）: 参照ファイル一覧・品質設定・パターン情報
> - `e2e-generation-context.json`（pochi-e2e-test-generator の入出力）: テストケース解析結果・生成計画

ファイルが存在しない場合は STEP 3 へ直接進み、参照ファイルを手動で特定してください。

---

### STEP 3: 参照ファイルの読み込み（必須）

以下の優先順位で参照ファイルを読み込んでください（存在するもののみ）：

**優先順位（TDDフロー対応・改善4）:**

1. **spec.json** + **plan.json**（存在する場合・最優先）
   - パス候補: `{app_path}/spec/features/*/spec.json`
   - `ui_components` から E2E 対象画面を特定
   - `business_rules` からテスト観点を導出
   - `acceptance_criteria` からテストケースを直接生成

2. **integration-test-design.md**（Layer 3 設計書・存在する場合）
   - パス: `{app_path}/tests/.onboarding/integration-test-design.md`
   - Layer 3 でカバー済みのテストケースを E2E から除外
   - 「Layer 3 でカバー済み: XX件（E2E 対象外）」を後の設計書に記載

3. **app_structure.md**（フォールバック・メイン入力）
   - パス候補: `{app_path}/app_structure.md`, `app/pochi-test-guidelines-artifacts/app_structure.md`
   - 存在しない場合は `guidelines/tools/app_structure_analyzer.py` で自動生成

4. **Git差分ファイル**（Partial 選択時のみ）
   - パス候補: `{app_path}/tests/.onboarding/diffs/`, `app/pochi-test-guidelines-artifacts/diffs/`

---

### STEP 4: E2Eテスト設計範囲の選択（改善3: 2パターンに簡素化）

ユーザーに以下の質問を **1 問だけ** 行ってください：

```
E2Eテスト設計の範囲を選択してください:
 A) 全機能（新規アプリ・大規模変更向け）
    → app_structure.md から全画面・全機能を対象
    → E2E機能テスト + E2Eシナリオテストの両方を生成
 B) 差分のみ（機能追加・バグ修正向け）
    → spec.json / Git差分から影響範囲を特定
    → 影響範囲に応じて該当ファイルのみ更新
```

**旧パターンとの互換性マッピング（後方互換）:**

| 旧パターン | 新パターン |
|-----------|----------|
| FullIntegration | A（Full） |
| FullScenario | A（Full） |
| PartialIntegration | B（Partial） |
| PartialScenario | B（Partial） |
| Pattern1 | A（Full） |
| Pattern2 / Pattern3 | B（Partial） |
| Pattern4 | A（Full） |

---

### STEP 5: サブエージェントへのE2Eテストケース設計書生成委譲（必須）

> ⚠️ **絶対必須・直接生成禁止**
> - **必ず Agentツール（subagent_type: "pochi-e2e-test-designer:test-case-specialist"）を使って `test-case-specialist` を起動すること**
> - サブエージェントは `pochi-e2e-test-designer/agents/test-case-specialist.md` として登録されている
> - Claude Code 自身が直接テストケースを生成することは厳禁

#### 5-1: サブエージェントへの指示

以下の指示で `@test-case-specialist` を呼び出してください：

```
@test-case-specialist

以下のタスクを実行してください：

## タスク概要
Layer4（Playwright）E2Eテストケース設計書を生成してください。

## 生成ルール

### Layer 4 が必要な観点のみを対象とする
- ✅ ブラウザ固有機能（ファイルDL、ポップアップ、ブラウザダイアログ）
- ✅ 複数ページ遷移を含む重要動線
- ✅ 利用頻度の高い日常的な機能
- ✅ データ書き込みを含むクリティカルパス
- ❌ AppTest で代替できる単一ページ操作（Layer 3 で実施）
- ❌ 参照のみ（書き込みなし）の単純操作
- ❌ データ検証が目的でビジュアル不要なもの

### セクション構成
**パターン A（Full）の場合:**
- セクション1: E2E機能テスト（ページ単位の機能テスト）
- セクション2: E2Eシナリオテスト（複数ページ横断の業務フロー）

**パターン B（Partial）の場合:**
- 影響範囲に応じてセクション1、セクション2のいずれか（または両方）を更新

### Layer 3 カバレッジ参照セクション（integration-test-design.md が存在する場合）
設計書の末尾に以下のセクションを追加すること:

---

## Layer 3 カバレッジ参照

以下のテストケースは Layer 3（AppTest）でカバー済みのため、E2E 対象外:

| テスト観点 | Layer 3 テストファイル | E2E 不要の理由 |
|-----------|---------------------|-------------|
| （integration-test-design.md の内容を参照して記入） | | |

E2E で追加検証が必要な観点:

| テスト観点 | E2E が必要な理由 |
|-----------|----------------|
| （上記 Layer 4 ルールに基づき記入） | |

---

### 実装詳細を除外する（エンドユーザー視点に限定）
以下は期待結果・テスト手順への記載を禁止:
- セッションステートのキー名
- API 戻り値の型
- 内部変数名
- SQL 文
- 実装クラス名・例外クラス名
- コードスニペット
- 関数の内部パラメータ

## 提供する情報
[STEP 2-4 で収集した情報をここに貼り付け]

## 出力先
[STEP 4 で決定したパターンに応じて出力先を指定]
```

#### 5-2: 出力ファイルの指定

| パターン | 出力ファイル | 旧名称との対応 |
|---------|------------|-------------|
| Full（セクション1） | `{app_path}/tests/.onboarding/e2e-test-design-functional.md` | 旧: `test_cases_integration.md` |
| Full（セクション2） | `{app_path}/tests/.onboarding/e2e-test-design-scenario.md` | 旧: `test_cases_scenario.md` |
| Partial（影響範囲に応じて） | 上記のいずれか（または両方）を更新 | |

---

### STEP 6: 品質ゲートの自動実行（改善6）

サブエージェントが設計書を生成したら、品質ゲートを自動実行してください：

```bash
POCHI_SKILL_ACTIVE=1 python /home/user/pochi-dp-developer-docs/skills/test/pochi-e2e-test-designer/scripts/quality_gate.py
```

**品質ゲートの結果に応じた処理:**

- **合格（終了コード 0）** → STEP 7 へ進む
- **不合格（終了コード 1）** → `{app_path}/tests/.onboarding/e2e-quality-report.md`（または旧パス `app/pochi-test-guidelines-artifacts/quality_report.md`）を読み込み、改善指示に従ってテストケースを修正して再実行（最大 2 回）
- **2 回不合格** → ユーザーに品質レポートの内容を報告して完了

**スクリプトが存在しない/失敗する場合:**
- 品質ゲートをスキップして STEP 7 へ進む
- その旨をユーザーに報告する

---

### STEP 7: 完了レポート

以下の形式で完了を報告してください：

```
## E2Eテスト設計書 生成完了

### 生成結果
- パターン: [Full / Partial]
- E2E機能テスト設計書: {出力パス}（XX件）
- E2Eシナリオテスト設計書: {出力パス}（XX件）

### Layer 3 との棲み分け
- Layer 3 カバー済み（E2E対象外）: XX件
- Layer 4（E2E）対象: XX件

### 品質ゲート結果
- 結果: 合格 / 不合格 / スキップ

### 次のステップ
生成した設計書をもとに E2E テストコードを生成するには:
「E2Eテストコードを生成して」と入力してください。
（pochi-e2e-test-generator が起動します）
```

---

## Don't

- ❌ **Claude Code 自身が直接 E2E テストケースを生成することは禁止**（必ずサブエージェント経由）
- ❌ **Layer 3（AppTest）でカバーできるテストを E2E に含めること**
- ❌ **実装詳細（内部変数名、SQL 文等）をテスト手順・期待結果に含めること**
- ❌ **旧パスへの出力（フォールバック時を除く）**: 新規生成は必ず `tests/.onboarding/` 配下に出力

## Inputs

| ファイル | 役割 | 必須 |
|---------|------|:---:|
| `{app_path}/tests/.onboarding/integration-test-design.md` | Layer 3 設計書（重複排除用） | 任意 |
| `spec.json` + `plan.json` | 仕様書（TDD フロー時・優先入力） | 任意 |
| `app_structure.md` | アプリ構造情報（メイン入力） | 推奨 |
| Git 差分ファイル | 変更範囲（Partial 時） | Partial 必須 |

## Outputs

| ファイル | 内容 | パターン |
|---------|------|---------|
| `{app_path}/tests/.onboarding/e2e-test-design-functional.md` | E2E機能テスト設計書（旧: test_cases_integration.md） | Full |
| `{app_path}/tests/.onboarding/e2e-test-design-scenario.md` | E2Eシナリオテスト設計書（旧: test_cases_scenario.md） | Full |
| `{app_path}/tests/.onboarding/e2e-quality-report.md` | 品質レポート（旧: quality_report.md） | 常時 |
| `{app_path}/tests/.onboarding/e2e-design-context.json` | 設計コンテキスト（旧: generation_context.json） | 常時 |

### 下流スキルとの連携

生成した設計書は **pochi-e2e-test-generator** で使用します：

```
入力ファイル優先順位（pochi-e2e-test-generator）:
  1. tests/.onboarding/e2e-test-design-functional.md （新・このSkillの出力）
  2. tests/.onboarding/e2e-test-design-scenario.md  （新・このSkillの出力）
  3. app/pochi-test-guidelines-artifacts/test_cases_integration.md （旧・後方互換）
  4. app/pochi-test-guidelines-artifacts/test_cases_scenario.md   （旧・後方互換）
  5. test_cases.md （最終フォールバック）
```

## バージョン・ライセンス

- **バージョン**: 1.0.0
- **作成者**: ryota-suzuki-xf
- **ライセンス**: 社内利用限定
- **前身 Skill**: pochi-test-orchestrator（旧名称・archive移動済み）

---

**このSkillを起動するには「E2Eテストケースを設計して」とClaude Codeに入力してください。**
