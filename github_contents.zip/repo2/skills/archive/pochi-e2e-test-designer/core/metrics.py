"""
メトリクス解析モジュール

app_structure.mdの解析と、テストケース件数の動的計算を担当する。
"""
import re
from pathlib import Path
from typing import Dict, Any, Tuple, Optional


def parse_app_structure(file_path: Path) -> Dict[str, Any]:
    """app_structure.mdを解析してメトリクスを抽出

    Args:
        file_path: app_structure.mdのパス

    Returns:
        メトリクス辞書 {
            "ui_elements": int,
            "screens": int,
            "functions": int,
            "classes": int,
            "estimated_min": int,
            "estimated_recommended": int,
            "estimated_max": int
        }
    """
    metrics = {
        "ui_elements": 0,
        "screens": 0,
        "functions": 0,
        "classes": 0,
        "estimated_min": None,
        "estimated_recommended": None,
        "estimated_max": None
    }

    if not file_path.exists():
        return metrics

    try:
        content = file_path.read_text(encoding='utf-8')

        # UI要素数の抽出（例: "**UI要素数**: 25"）
        ui_match = re.search(r'\*\*UI要素数\*\*[:\s]*(\d+)', content, re.IGNORECASE)
        if ui_match:
            metrics["ui_elements"] = int(ui_match.group(1))

        # 画面数の抽出（例: "**画面数**: 3"）
        screen_match = re.search(r'\*\*画面数\*\*[:\s]*(\d+)', content, re.IGNORECASE)
        if screen_match:
            metrics["screens"] = int(screen_match.group(1))

        # 関数数の抽出（例: "**関数数**: 32"）
        func_match = re.search(r'\*\*関数数\*\*[:\s]*(\d+)', content, re.IGNORECASE)
        if func_match:
            metrics["functions"] = int(func_match.group(1))

        # クラス数の抽出（例: "**クラス数**: 8"）
        class_match = re.search(r'\*\*クラス数\*\*[:\s]*(\d+)', content, re.IGNORECASE)
        if class_match:
            metrics["classes"] = int(class_match.group(1))

        # 推定テストケース数の抽出
        # パターン1: "推定テストケース数（最小）: 50件"
        # パターン2: "- **最小**: 50件"
        # パターン3: "推定最小: 50"

        # 最小
        min_patterns = [
            r'推定テストケース数[（(]最小[）)][:\s]*(\d+)',
            r'\*\*最小\*\*[:\s]*(\d+)',
            r'推定最小[:\s]*(\d+)'
        ]
        for pattern in min_patterns:
            min_match = re.search(pattern, content, re.IGNORECASE)
            if min_match:
                metrics["estimated_min"] = int(min_match.group(1))
                break

        # 推奨
        rec_patterns = [
            r'推定テストケース数[（(]推奨[）)][:\s]*(\d+)',
            r'\*\*推奨\*\*[:\s]*(\d+)',
            r'推定推奨[:\s]*(\d+)',
            r'推定テストケース数[:\s]*(\d+)'  # シンプルな形式
        ]
        for pattern in rec_patterns:
            rec_match = re.search(pattern, content, re.IGNORECASE)
            if rec_match:
                metrics["estimated_recommended"] = int(rec_match.group(1))
                break

        # 最大
        max_patterns = [
            r'推定テストケース数[（(]最大[）)][:\s]*(\d+)',
            r'\*\*最大\*\*[:\s]*(\d+)',
            r'推定最大[:\s]*(\d+)'
        ]
        for pattern in max_patterns:
            max_match = re.search(pattern, content, re.IGNORECASE)
            if max_match:
                metrics["estimated_max"] = int(max_match.group(1))
                break

    except Exception as e:
        # パースエラーは無視して空のメトリクスを返す
        pass

    return metrics


def calculate_from_metrics(metrics: Dict[str, Any], dynamic_config: Dict[str, Any]) -> int:
    """メトリクスから件数を計算（フォールバック用）

    Args:
        metrics: parse_app_structureの戻り値
        dynamic_config: configのtarget_total_dynamicセクション

    Returns:
        計算されたテストケース件数
    """
    base = dynamic_config.get("base_cases", 30)
    ui_weight = dynamic_config.get("ui_weight", 1.5)
    screen_weight = dynamic_config.get("screen_weight", 12)

    ui_contribution = metrics.get("ui_elements", 0) * ui_weight
    screen_contribution = metrics.get("screens", 0) * screen_weight

    return int(base + ui_contribution + screen_contribution)


def count_existing_test_cases(state) -> int:
    """既存test_cases.mdのテストケース件数をカウント

    Args:
        state: SkillState インスタンス

    Returns:
        テストケース件数
    """
    test_cases_path = state.get_artifact_path("test_cases.md")

    if not test_cases_path.exists():
        return 0

    try:
        content = test_cases_path.read_text(encoding='utf-8')
        # "### TC-" で始まる行をカウント
        count = len(re.findall(r'^### TC-', content, re.MULTILINE))
        return count
    except Exception:
        return 0


def estimate_changed_screens_from_diffs(state) -> int:
    """差分情報から変更画面数を推定

    Args:
        state: SkillState インスタンス

    Returns:
        変更画面数の推定値
    """
    # 簡易実装: diffsディレクトリの.txtファイル数を画面数と見なす
    # 将来的には差分内容を解析して精度向上可能
    diffs_dir = state.get_diffs_dir()

    if not diffs_dir.exists():
        return 0

    try:
        diff_files = list(diffs_dir.glob("*.txt"))
        # 1ファイル = 0.5画面程度と推定（複数ファイルが1画面の場合もあるため）
        return max(1, int(len(diff_files) * 0.5))
    except Exception:
        return 1  # デフォルトで1画面変更と見なす


def estimate_changed_ui_from_diffs(state) -> int:
    """差分情報から変更UI要素数を推定

    Args:
        state: SkillState インスタンス

    Returns:
        変更UI要素数の推定値
    """
    # 簡易実装: 差分行数からUI要素数を推定
    # st.xxx, html, cssなどのパターンを検出
    diffs_dir = state.get_diffs_dir()

    if not diffs_dir.exists():
        return 0

    try:
        ui_patterns = [
            r'st\.',          # Streamlit
            r'<[a-zA-Z]+',    # HTML tags
            r'class=',        # CSS classes
            r'def.*\(.*\):',  # 関数定義（UI生成関数の可能性）
        ]

        ui_count = 0
        for diff_file in diffs_dir.glob("*.txt"):
            content = diff_file.read_text(encoding='utf-8')
            for pattern in ui_patterns:
                ui_count += len(re.findall(pattern, content))

        # 重複検出を考慮して1/3程度に調整
        return max(1, int(ui_count / 3))
    except Exception:
        return 5  # デフォルトで5要素変更と見なす


def calculate_pattern3_incremental(
    state,
    metrics: Dict[str, Any],
    dynamic_config: Dict[str, Any]
) -> Tuple[int, Dict[str, Any]]:
    """Pattern3（既存更新）専用の計算: 既存+差分影響分

    Args:
        state: SkillState インスタンス
        metrics: parse_app_structureの戻り値
        dynamic_config: configのtarget_total_dynamicセクション

    Returns:
        (計算されたテストケース件数, 計算詳細の辞書)
    """
    # 既存test_cases.mdの件数を取得
    existing_count = count_existing_test_cases(state)

    # 差分情報から変更画面数・UI要素数を推定
    changed_screens = estimate_changed_screens_from_diffs(state)
    changed_ui = estimate_changed_ui_from_diffs(state)

    # Pattern3専用設定
    p3_config = dynamic_config.get("pattern3_config", {})
    screen_weight = p3_config.get("screen_weight", 12)
    ui_weight = p3_config.get("ui_weight", 1.5)
    max_ratio = p3_config.get("max_increase_ratio", 1.3)

    # 追加分を計算
    additional = (changed_screens * screen_weight) + (changed_ui * ui_weight)
    target = int(existing_count + additional)

    # 上限制限（既存の130%まで）
    max_allowed = int(existing_count * max_ratio)
    target_capped = min(target, max_allowed)

    # 下限保証（既存件数を下回らない）
    final_target = max(target_capped, existing_count)

    details = {
        "source": "pattern3_incremental",
        "existing_count": existing_count,
        "changed_screens": changed_screens,
        "changed_ui": changed_ui,
        "additional_cases": int(additional),
        "target_before_cap": target,
        "max_allowed": max_allowed,
        "final_value": final_target
    }

    return final_target, details
