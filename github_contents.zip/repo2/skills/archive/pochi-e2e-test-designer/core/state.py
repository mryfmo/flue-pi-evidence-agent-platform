"""
状態管理モジュール

Skillの実行状態、パス管理、ロギング設定、サマリ出力を一元管理する。
絶対パス使用とロガー重複ハンドラ対策を実装。
"""
import os
import sys
import json
import shutil
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional, Any


class SkillState:
    """Skill実行状態の管理クラス
    
    - 絶対パスでの一元管理
    - run_id生成（YYYYmmdd_HHMMSS）
    - ロガー設定（重複ハンドラ対策付き）
    - 自動バックアップ
    - サマリ出力
    """
    
    def __init__(self, project_root: Optional[Path] = None):
        """初期化
        
        Args:
            project_root: プロジェクトルート（Noneの場合は自動検出）
        """
        # run_id生成
        self.run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # プロジェクトルートの設定
        if project_root is None:
            self._root = self._find_project_root()
        else:
            self._root = project_root.resolve()
        
        # パス構造の初期化（すべて絶対パス）
        self._paths = self._initialize_paths()
        
        # ロガー設定（重複ハンドラ対策）
        self.logger = self._setup_logger()
        
        # 初期サマリデータ
        self._summary: Dict[str, Any] = {
            "run_id": self.run_id,
            "timestamp": datetime.now().isoformat(),
            "phase": "initialized",
            "pattern": None,
            "llm_executed": False,
            "test_type_selection": {
                "integration_tests": True,
                "scenario_tests": True
            }
        }
        
        self.logger.info(f"SkillState initialized - run_id: {self.run_id}")
        self.logger.info(f"Project root: {self._root}")
    
    def _find_project_root(self) -> Path:
        """プロジェクトルートディレクトリを返す

        Returns:
            スキルディレクトリの絶対パス
        """
        return Path(__file__).resolve().parent.parent

    def _initialize_paths(self) -> Dict[str, Path]:
        """パス構造を初期化（すべて絶対パス）

        Returns:
            パス辞書
        """
        # pochi-test-guidelinesの位置を検出
        pochi_test_guidelines_dir = self._find_pochi_test_guidelines()

        # スキル本体のディレクトリを検出（.claude/skills/pochi-test-orchestrator）
        skill_dir = self._find_skill_directory()

        # config.jsonから artifact_dir を読み込み（設定ファイルが読める場合）
        config_file = skill_dir / "config" / "default_config.json"
        artifact_dir = "output"  # デフォルト値

        if config_file.exists():
            try:
                import json
                with open(config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    artifact_dir = config.get("artifact_dir", artifact_dir)
            except Exception:
                pass  # 読み込み失敗時はデフォルト値を使用

        paths = {
            "root": self._root,
            "artifacts": self._root / artifact_dir,
            "logs": self._root / "logs",
            "tools": pochi_test_guidelines_dir / "tools",
            "config": skill_dir / "config",
            "prompts": skill_dir / "prompts",
            "guides": pochi_test_guidelines_dir / "for-gen-ai",
            "skill_core": skill_dir / "core"
        }

        # 必要なディレクトリを作成
        paths["artifacts"].mkdir(parents=True, exist_ok=True)
        paths["logs"].mkdir(parents=True, exist_ok=True)

        return paths
    
    def _find_pochi_test_guidelines(self) -> Path:
        """pochi-test-guidelinesディレクトリの位置を検出
        
        Returns:
            pochi-test-guidelinesディレクトリの絶対パス
            
        Raises:
            RuntimeError: ディレクトリが見つからない場合
        """
        # 候補パスをチェック（優先順位順）
        candidates = [
            # 0. Skill自身のguidelines/（最優先）
            self._find_skill_directory() / "guidelines",
            # 1. 現在のプロジェクト配下（後方互換性）
            self._root / "app" / "pochi-test-guidelines",
            self._root / "pochi-test-guidelines",
            self._root,  # 直接このリポジトリで実行している場合
            # 2. ホームディレクトリの.claude配下（グローバル設定）
            Path.home() / ".claude" / "pochi-test-guidelines",
            # 3. pochi-dp-developer-docs配下（開発環境）
            Path.home() / "pochi-dp-developer-docs" / "pochi-test-guidelines",
        ]
        
        for candidate in candidates:
            # tools/app_structure_analyzer.pyの存在で判定
            if (candidate / "tools" / "app_structure_analyzer.py").exists():
                return candidate.resolve()
        
        # 見つからない場合はエラー
        raise RuntimeError(
            f"pochi-test-guidelines directory not found. Checked: {[str(c) for c in candidates]}"
        )
    
    def _find_skill_directory(self) -> Path:
        """スキル本体のディレクトリを返す

        Returns:
            スキルディレクトリの絶対パス
        """
        return Path(__file__).resolve().parent.parent

    def _setup_logger(self) -> logging.Logger:
        """ロガーを設定

        Returns:
            設定済みロガー
        """
        logger = logging.getLogger("pochi_skill")

        # 既存ハンドラをクリア
        if logger.hasHandlers():
            logger.handlers.clear()

        # 親ロガーへの伝播を無効化
        logger.propagate = False

        # ログレベル設定（INFOレベル）
        logger.setLevel(logging.INFO)

        # StreamHandlerを追加（標準出力）
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter('[%(name)s] %(levelname)s: %(message)s'))
        logger.addHandler(handler)

        return logger
    
    @property
    def paths(self) -> Dict[str, Path]:
        """パス辞書を取得（読み取り専用）
        
        Returns:
            絶対パス辞書
        """
        return self._paths.copy()
    
    def get_path(self, key: str) -> Path:
        """特定のパスを取得
        
        Args:
            key: パスキー（root, artifacts, logs, tools, config, prompts, guides）
            
        Returns:
            絶対パス
            
        Raises:
            KeyError: 無効なキーの場合
        """
        if key not in self._paths:
            raise KeyError(f"Invalid path key: {key}. Available: {list(self._paths.keys())}")
        return self._paths[key]
    
    def create_backup(self, file_path: Path) -> Optional[Path]:
        """ファイルのバックアップを作成（.bak.{run_id}）
        
        Args:
            file_path: バックアップ対象ファイル（絶対/相対パス）
            
        Returns:
            バックアップファイルのパス（失敗時はNone）
        """
        # 絶対パスに変換
        abs_path = file_path if file_path.is_absolute() else self._root / file_path
        abs_path = abs_path.resolve()
        
        if not abs_path.exists():
            self.logger.warning(f"Backup target not found: {abs_path}")
            return None
        
        # バックアップパス: original.bak.{run_id}
        backup_path = abs_path.with_suffix(f".bak.{self.run_id}")
        
        try:
            shutil.copy2(abs_path, backup_path)
            self.logger.info(f"Backup created: {abs_path.name} -> {backup_path.name}")
            return backup_path
        except Exception as e:
            self.logger.error(f"Backup failed: {e}")
            return None
    
    def update_summary(self, updates: Dict[str, Any]) -> None:
        """サマリデータを更新
        
        Args:
            updates: 更新内容
        """
        self._summary.update(updates)
        self._summary["last_updated"] = datetime.now().isoformat()
    
    def write_summary(self, additional_data: Optional[Dict[str, Any]] = None) -> Path:
        """サマリをJSONファイルに書き込み

        Args:
            additional_data: 追加データ（オプション）

        Returns:
            書き込まれたファイルパス
        """
        if additional_data:
            self._summary.update(additional_data)

        # アーティファクトディレクトリに保存
        summary_file = self._paths["artifacts"] / "last_run_summary.json"

        try:
            with open(summary_file, 'w', encoding='utf-8') as f:
                json.dump(self._summary, f, ensure_ascii=False, indent=2)
            self.logger.info(f"Run summary written: {summary_file}")
            return summary_file
        except Exception as e:
            self.logger.error(f"Failed to write summary: {e}")
            return Path("/dev/null")
    
    def read_summary(self) -> Dict[str, Any]:
        """既存のサマリを読み込み
        
        Returns:
            サマリデータ（ファイルがない場合は空辞書）
        """
        summary_file = self._paths["artifacts"] / "last_run_summary.json"
        
        if not summary_file.exists():
            self.logger.debug("No existing summary found")
            return {}
        
        try:
            with open(summary_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.logger.debug("Existing summary loaded")
            return data
        except Exception as e:
            self.logger.warning(f"Failed to read summary: {e}")
            return {}
    
    def get_artifact_path(self, filename: str) -> Path:
        """アーティファクトファイルの絶対パスを取得
        
        Args:
            filename: ファイル名
            
        Returns:
            絶対パス
        """
        return self._paths["artifacts"] / filename
    
    def get_diffs_dir(self) -> Path:
        """diffs/ディレクトリの絶対パスを取得
        
        Returns:
            絶対パス
        """
        diffs_dir = self._paths["artifacts"] / "diffs"
        diffs_dir.mkdir(parents=True, exist_ok=True)
        return diffs_dir
    
    def get_config_file(self, filename: str = "default_config.json") -> Path:
        """設定ファイルの絶対パスを取得
        
        Args:
            filename: 設定ファイル名
            
        Returns:
            絶対パス
        """
        return self._paths["config"] / filename
    
    def get_prompt_file(self, filename: str = "generate_test_cases_prompt.md") -> Path:
        """プロンプトファイルの絶対パスを取得
        
        Args:
            filename: プロンプトファイル名
            
        Returns:
            絶対パス
        """
        return self._paths["prompts"] / filename
    
    def get_guide_files(self) -> list[Path]:
        """ガイドファイルのリストを取得
        
        Returns:
            絶対パスのリスト
        """
        guides_dir = self._paths["guides"]
        if not guides_dir.exists():
            self.logger.warning(f"Guides directory not found: {guides_dir}")
            return []
        
        # .mdファイルのみを取得
        guide_files = sorted(guides_dir.glob("*.md"))
        return guide_files
    
    def load_config(self) -> Dict[str, Any]:
        """設定ファイルを読み込む
        
        Returns:
            設定辞書
        """
        config_file = self.get_config_file()
        
        if not config_file.exists():
            self.logger.warning(f"Config file not found: {config_file}")
            # デフォルト設定を返す
            return {
                "ratios": {"basic": 0.6, "boundary": 0.2, "abnormal": 0.15, "other": 0.05},
                "target_total": 125,
                "ambiguous_terms": ["適切", "正しく", "〜すること", "期待通り", "問題ない", "正常に", "想定通り"],
                "ui_match_thresholds": {"exact": True, "partial_ratio": 0.7}
            }
        
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            self.logger.info(f"Config loaded: {config_file}")
            return config
        except Exception as e:
            self.logger.error(f"Failed to load config: {e}")
            raise
    
    def check_file_exists(self, path: Path) -> bool:
        """ファイルの存在確認
        
        Args:
            path: ファイルパス（絶対/相対）
            
        Returns:
            存在する場合True
        """
        abs_path = path if path.is_absolute() else self._root / path
        exists = abs_path.exists() and abs_path.is_file()
        self.logger.debug(f"File exists check: {abs_path} -> {exists}")
        return exists
    
    def check_dir_exists(self, path: Path) -> bool:
        """ディレクトリの存在確認
        
        Args:
            path: ディレクトリパス（絶対/相対）
            
        Returns:
            存在する場合True
        """
        abs_path = path if path.is_absolute() else self._root / path
        exists = abs_path.exists() and abs_path.is_dir()
        self.logger.debug(f"Dir exists check: {abs_path} -> {exists}")
        return exists
    
    def check_dir_not_empty(self, path: Path) -> bool:
        """ディレクトリが空でないことを確認

        Args:
            path: ディレクトリパス（絶対/相対）

        Returns:
            ファイルが存在する場合True
        """
        abs_path = path if path.is_absolute() else self._root / path

        if not self.check_dir_exists(abs_path):
            return False

        has_files = any(abs_path.iterdir())
        self.logger.debug(f"Dir not empty check: {abs_path} -> {has_files}")
        return has_files

    @property
    def test_type_selection(self) -> Dict[str, bool]:
        """テストタイプ選択を取得"""
        return self._summary.get("test_type_selection", {
            "integration_tests": True,
            "scenario_tests": True
        })

    def set_test_type_selection(self, selection: Dict[str, bool]) -> None:
        """テストタイプ選択を設定"""
        self._summary["test_type_selection"] = selection
        self.logger.info(f"Test type selection: {selection}")

    def set_pattern_info(self, pattern_name: str, selection_method: str, reason: str) -> None:
        """パターン情報を記録

        Args:
            pattern_name: パターン名
            selection_method: 選択方法（environment_variable, user_question, auto_detection）
            reason: 判定理由
        """
        self._summary["pattern_info"] = {
            "name": pattern_name,
            "selection_method": selection_method,
            "reason": reason
        }
        self.logger.info(f"Pattern info recorded: {pattern_name} ({selection_method})")
