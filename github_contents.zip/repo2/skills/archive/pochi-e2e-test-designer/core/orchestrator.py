"""
オーケストレーターモジュール

パターン判定、前提生成、generation_context.json準備を担当する。
"""
import os
import sys
import json
import subprocess
from pathlib import Path
from typing import Dict, Tuple, Optional, Any, List
from enum import Enum

from .state import SkillState
from .metrics import (
    parse_app_structure,
    calculate_from_metrics,
    calculate_pattern3_incremental
)
from .prompt_builder import PromptBuilder


class Pattern(Enum):
    """テストケース生成パターン"""
    # 新パターン名（優先）
    FULL_INTEGRATION = "FullIntegration"  # 全機能の結合テスト網羅生成
    FULL_SCENARIO = "FullScenario"  # 全機能のシナリオテスト網羅生成
    PARTIAL_INTEGRATION = "PartialIntegration"  # 特定範囲の結合テスト生成
    PARTIAL_SCENARIO = "PartialScenario"  # 特定範囲のシナリオテスト生成

    # 旧パターン名（互換性維持）
    PATTERN1 = "Pattern1"  # 初回網羅作成（app_structureなし、test_casesなし）→ FullIntegration
    PATTERN2 = "Pattern2"  # 初回作成+差分テスト（app_structureあり、test_casesなし、差分あり）→ PartialIntegration
    PATTERN3 = "Pattern3"  # 既存更新（test_casesあり、差分あり）→ PartialIntegration
    PATTERN4 = "Pattern4"  # 全体再生成（test_casesあり、差分なし）→ FullScenario


def ask_user_for_pattern(state: SkillState) -> Tuple[str, str]:
    """ユーザーに質問してパターンを判定

    Args:
        state: SkillState インスタンス

    Returns:
        (scope, test_type) のタプル
    """
    logger = state.logger
    config = state.load_config()

    # 質問設定を取得
    questions = config.get("user_questions", {})
    scope_q = questions.get("scope_question", {})
    type_q = questions.get("type_question", {})

    if not scope_q or not type_q:
        logger.error("質問設定が見つかりません。設定ファイルを確認してください。")
        raise ValueError("質問設定が見つかりません")

    logger.info("=" * 70)
    logger.info("パターン選択（ユーザー質問）")
    logger.info("=" * 70)

    # 質問1: スコープ選択
    print(f"\n{scope_q.get('text', '')}\n")
    for key, option in scope_q.get("options", {}).items():
        print(f"{key}) {option.get('label', '')}")
        print(f"   - {option.get('description', '')}")

    scope_answer = input("\n選択 (A/B): ").strip().upper()
    while scope_answer not in ["A", "B"]:
        print("⚠️ A または B を入力してください")
        scope_answer = input("選択 (A/B): ").strip().upper()

    scope_value = scope_q["options"][scope_answer]["value"]
    logger.info(f"スコープ選択: {scope_answer} ({scope_value})")

    # 質問2: テストタイプ選択
    print(f"\n{type_q.get('text', '')}\n")
    for key, option in type_q.get("options", {}).items():
        print(f"{key}) {option.get('label', '')}")
        print(f"   - {option.get('description', '')}")

    type_answer = input("\n選択 (A/B): ").strip().upper()
    while type_answer not in ["A", "B"]:
        print("⚠️ A または B を入力してください")
        type_answer = input("選択 (A/B): ").strip().upper()

    type_value = type_q["options"][type_answer]["value"]
    logger.info(f"テストタイプ選択: {type_answer} ({type_value})")

    return scope_value, type_value


def get_pattern_from_env(state: SkillState) -> Optional[Pattern]:
    """環境変数からパターンを取得

    Args:
        state: SkillState インスタンス

    Returns:
        Pattern、または None（未設定時）
    """
    logger = state.logger
    env_value = os.environ.get("POCHI_PATTERN_SELECTION", "").strip()

    if not env_value:
        return None

    # 環境変数値とパターンのマッピング
    pattern_map = {
        "full_integration": Pattern.FULL_INTEGRATION,
        "full_scenario": Pattern.FULL_SCENARIO,
        "partial_integration": Pattern.PARTIAL_INTEGRATION,
        "partial_scenario": Pattern.PARTIAL_SCENARIO
    }

    pattern = pattern_map.get(env_value.lower())

    if pattern:
        logger.info(f"環境変数POCHI_PATTERN_SELECTIONからパターンを取得: {pattern.value}")
        return pattern
    else:
        logger.warning(f"不正な環境変数値: {env_value}。有効な値: {list(pattern_map.keys())}")
        return None


def map_answers_to_pattern(scope: str, test_type: str) -> Pattern:
    """質問回答からパターンにマッピング

    Args:
        scope: スコープ選択値（full/partial）
        test_type: テストタイプ選択値（integration/scenario）

    Returns:
        判定されたPattern
    """
    if scope == "full" and test_type == "integration":
        return Pattern.FULL_INTEGRATION
    elif scope == "full" and test_type == "scenario":
        return Pattern.FULL_SCENARIO
    elif scope == "partial" and test_type == "integration":
        return Pattern.PARTIAL_INTEGRATION
    elif scope == "partial" and test_type == "scenario":
        return Pattern.PARTIAL_SCENARIO
    else:
        # デフォルトフォールバック
        return Pattern.FULL_INTEGRATION


def detect_spec_json(state: SkillState, feature_id: Optional[str] = None) -> Optional[Path]:
    """spec.jsonを自動検出

    優先順位:
    1. feature_id指定がある場合、pochi-spec-initializer/specs/features/{feature_id}/spec.jsonを検索
    2. Git差分からFEAT-XXX形式を抽出してマッチング
    3. pochi-spec-initializer/specs/features/*/spec.jsonで単一ファイル検出

    Args:
        state: SkillState インスタンス
        feature_id: 機能ID（オプション）

    Returns:
        spec.jsonのパス、または None（検出失敗時）
    """
    logger = state.logger
    repo_root = state.get_path("root")
    specs_dir = repo_root / "pochi-spec-initializer" / "specs" / "features"

    if not specs_dir.exists():
        logger.debug("specs/features ディレクトリが存在しません")
        return None

    # 1. feature_id指定がある場合
    if feature_id:
        candidate = specs_dir / feature_id / "spec.json"
        if candidate.exists():
            logger.info(f"spec.json検出（feature_id指定）: {candidate}")
            return candidate

    # 2. Git差分からFEAT-XXX形式を抽出
    diffs_dir = state.get_diffs_dir()
    if diffs_dir.exists():
        import re
        for diff_file in diffs_dir.glob("*.txt"):
            try:
                with open(diff_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                # FEAT-XXX-XXX-XXX形式を抽出
                matches = re.findall(r'FEAT-\d{3}-\d{3}-\d{3}', content)
                for match in matches:
                    candidate = specs_dir / match / "spec.json"
                    if candidate.exists():
                        logger.info(f"spec.json検出（Git差分マッチング）: {candidate}")
                        return candidate
            except Exception as e:
                logger.debug(f"diff読み込みエラー: {e}")

    # 3. 単一ファイル検出
    spec_files = list(specs_dir.glob("*/spec.json"))
    if len(spec_files) == 1:
        logger.info(f"spec.json検出（単一ファイル）: {spec_files[0]}")
        return spec_files[0]
    elif len(spec_files) > 1:
        logger.warning(f"複数のspec.jsonが検出されました（{len(spec_files)}件）。特定できません")

    return None


def parse_spec_json(spec_path: Path) -> Optional[Dict]:
    """spec.jsonをパース

    Args:
        spec_path: spec.jsonのパス

    Returns:
        パース済み辞書、または None（失敗時）
    """
    try:
        with open(spec_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        return None


def extract_scope_info(spec: Dict) -> Dict:
    """spec.jsonからスコープ情報を抽出

    Args:
        spec: パース済みspec.json

    Returns:
        スコープ情報辞書
    """
    scope_info = {
        "out_of_scope": spec.get("outOfScope", []) + spec.get("nonGoals", []),
        "acceptance_criteria_count": len(spec.get("acceptanceCriteria", [])),
        "target_users": [],
        "test_types": spec.get("testHarness", [])
    }

    # ユーザーロール抽出
    users = spec.get("users", {})
    if isinstance(users, dict):
        scope_info["target_users"] = users.get("internalRoles", [])

    return scope_info


def detect_pattern(state: SkillState) -> Tuple[Pattern, Dict]:
    """パターンを判定（優先順位: 環境変数 → ユーザー質問 → 自動判定）

    Args:
        state: SkillState インスタンス

    Returns:
        (判定されたパターン, 判定理由の詳細)
    """
    logger = state.logger
    details = {
        "selection_method": None,
        "confidence": 0.0,
        "reason": ""
    }

    # 優先順位1: 環境変数
    pattern = get_pattern_from_env(state)
    if pattern:
        details["selection_method"] = "environment_variable"
        details["confidence"] = 1.0
        details["reason"] = f"環境変数POCHI_PATTERN_SELECTIONで{pattern.value}が指定されました"
        logger.info(f"Pattern detected (env): {pattern.value}")
        return pattern, details

    # 優先順位2: ユーザー質問（必須）
    scope, test_type = ask_user_for_pattern(state)
    pattern = map_answers_to_pattern(scope, test_type)
    details["selection_method"] = "user_question"
    details["confidence"] = 1.0
    details["reason"] = f"User selected {scope} scope + {test_type} tests"
    logger.info(f"Pattern detected (user): {pattern.value}")
    return pattern, details


def prepare_prerequisites(pattern: Pattern, state: SkillState) -> bool:
    """前提ファイルを準備（app_structure.md等）
    
    Args:
        pattern: 判定されたパターン
        state: SkillState インスタンス
        
    Returns:
        成功した場合True
    """
    logger = state.logger
    logger.info("=" * 70)
    logger.info("Preparing prerequisites")
    logger.info("=" * 70)
    
    # app_structure.mdの準備
    app_structure_path = state.get_artifact_path("app_structure.md")

    # Full系パターンまたはapp_structure.mdが存在しない場合は生成
    if pattern in [Pattern.PATTERN1, Pattern.FULL_INTEGRATION, Pattern.FULL_SCENARIO] or not state.check_file_exists(app_structure_path):
        logger.info("app_structure.md needs to be generated")

        # app_structure_analyzer.pyのパスを探索
        analyzer_path = state.get_path("tools") / "app_structure_analyzer.py"

        if not analyzer_path.exists():
            logger.error(f"app_structure_analyzer.py not found: {analyzer_path}")
            state.update_summary({
                "prerequisite_error": "app_structure_analyzer.py not found",
                "fallback": "manual creation required"
            })
            return False

        # app_structure_analyzer.pyを実行
        success = _run_app_structure_analyzer(analyzer_path, state)

        if not success:
            logger.error("Failed to generate app_structure.md")
            state.update_summary({
                "prerequisite_error": "app_structure generation failed",
                "fallback": "check logs for details"
            })
            return False

        logger.info(f"app_structure.md generated: {app_structure_path}")
    else:
        logger.info(f"app_structure.md already exists: {app_structure_path}")

    # Partial系パターンの場合: 既存ファイルをバックアップ
    if pattern in [Pattern.PARTIAL_INTEGRATION, Pattern.PARTIAL_SCENARIO]:
        if pattern == Pattern.PARTIAL_INTEGRATION:
            integration_path = state.get_artifact_path("test_cases_integration.md")
            if state.check_file_exists(integration_path):
                state.create_backup(integration_path)
                logger.info(f"Backup created for: {integration_path}")
        elif pattern == Pattern.PARTIAL_SCENARIO:
            scenario_path = state.get_artifact_path("test_cases_scenario.md")
            if state.check_file_exists(scenario_path):
                state.create_backup(scenario_path)
                logger.info(f"Backup created for: {scenario_path}")

    # Partial系パターンの場合: copilot_summary.mdの確認（必須ではない）
    if pattern in [Pattern.PATTERN2, Pattern.PATTERN3, Pattern.PARTIAL_INTEGRATION, Pattern.PARTIAL_SCENARIO]:
        copilot_summary_path = state.get_artifact_path("copilot_summary.md")

        if not state.check_file_exists(copilot_summary_path):
            logger.warning("copilot_summary.md not found - continuing without it")
            logger.info("You can add it manually: GitHub PR -> /copilot summary")
            state.update_summary({
                "prerequisite_warning": "copilot_summary.md not found",
                "recommendation": "Add via GitHub PR /copilot summary for better context"
            })

    logger.info("Prerequisites preparation completed")
    return True


def _run_app_structure_analyzer(analyzer_path: Path, state: SkillState) -> bool:
    """app_structure_analyzer.pyを実行
    
    Args:
        analyzer_path: app_structure_analyzer.pyのパス
        state: SkillState インスタンス
        
    Returns:
        実行成功フラグ
    """
    logger = state.logger
    logger.info(f"Executing app_structure_analyzer.py: {analyzer_path}")
    
    try:
        # 環境変数を付与して実行
        import os
        env = {**os.environ, "POCHI_SKILL_ACTIVE": "1"}
        
        # アプリディレクトリ（/app）を引数として渡す
        app_dir = state.get_path("root") / "app"
        
        result = subprocess.run(
            [sys.executable, str(analyzer_path), str(app_dir)],
            cwd=analyzer_path.parent,
            capture_output=True,
            text=True,
            timeout=300,  # 5分のタイムアウト
            env=env
        )
        
        # 標準出力をログに記録
        if result.stdout:
            logger.info(f"stdout:\n{result.stdout}")
        if result.stderr:
            logger.warning(f"stderr:\n{result.stderr}")
        
        if result.returncode == 0:
            # 生成確認 - app_structure_analyzer.pyは app/pochi-test-guidelines-artifacts/ に出力する
            # state.get_artifact_path() が既に app/ 配下を指すため、コピー不要
            app_structure_path = state.get_artifact_path("app_structure.md")

            if app_structure_path.exists():
                logger.info(f"app_structure.md successfully generated at {app_structure_path}")
                return True
            else:
                logger.error(f"app_structure.md not found at expected location: {app_structure_path}")
                return False
        else:
            logger.error(f"app_structure_analyzer.py failed (exit code: {result.returncode})")
            return False
    
    except subprocess.TimeoutExpired:
        logger.error("app_structure_analyzer.py timed out")
        return False
    except Exception as e:
        logger.error(f"Error executing app_structure_analyzer.py: {e}")
        return False


def calculate_dynamic_target_total(
    state,
    pattern: Pattern,
    app_structure_path: Path
) -> Tuple[int, Dict[str, Any]]:
    """app_structureとパターンに基づいて動的にtarget_totalを計算

    Args:
        state: SkillState インスタンス
        pattern: 判定されたパターン
        app_structure_path: app_structure.mdのパス

    Returns:
        (target_total, calculation_details)
    """
    config = state.load_config()
    strategy = config.get("target_total_strategy", "dynamic")

    calculation_details = {
        "strategy": strategy,
        "pattern": pattern.value,
        "source": None,
        "base_value": None,
        "multiplier": None,
        "final_value": None
    }

    # 固定値戦略の場合
    if strategy == "fixed":
        target = config.get("target_total_fixed", 125)
        calculation_details["source"] = "fixed_value"
        calculation_details["final_value"] = target
        return target, calculation_details

    # 動的計算戦略
    dynamic_config = config.get("target_total_dynamic", {})

    # app_structure.mdを解析
    metrics = parse_app_structure(app_structure_path)

    # app_structure推定値を最優先
    use_estimate = dynamic_config.get("use_app_structure_estimate", True)

    if use_estimate and metrics.get("estimated_recommended"):
        base_target = metrics["estimated_recommended"]
        calculation_details["source"] = "app_structure_estimate"
    else:
        base_target = calculate_from_metrics(metrics, dynamic_config)
        calculation_details["source"] = "fallback_calculation"
        calculation_details["metrics"] = {
            "ui_elements": metrics.get("ui_elements", 0),
            "screens": metrics.get("screens", 0)
        }

    calculation_details["base_value"] = base_target

    # パターン別調整
    pattern_mult = dynamic_config.get("pattern_multipliers", {}).get(pattern.value, 1.0)

    # Pattern3の場合は既存+差分影響分
    if pattern == Pattern.PATTERN3 and pattern_mult == "incremental":
        target, p3_details = calculate_pattern3_incremental(state, metrics, dynamic_config)
        calculation_details.update(p3_details)
        return target, calculation_details

    # 通常のパターン倍率適用
    calculation_details["multiplier"] = pattern_mult
    target = int(base_target * pattern_mult)

    # 範囲制限
    min_cases = dynamic_config.get("min_cases", 50)
    max_cases = dynamic_config.get("max_cases", 300)
    target = max(min_cases, min(target, max_cases))

    calculation_details["final_value"] = target
    calculation_details["min_limit"] = min_cases
    calculation_details["max_limit"] = max_cases

    return target, calculation_details


def prepare_generation_context(
    pattern: Pattern,
    state: SkillState,
    base_branch_detected: Optional[str] = None,
    pattern_details: Optional[Dict] = None
) -> Dict:
    """generation_context.jsonを準備

    Args:
        pattern: 判定されたパターン
        state: SkillState インスタンス
        base_branch_detected: 検出されたベースブランチ（オプション）
        pattern_details: パターン判定の詳細情報（オプション）

    Returns:
        generation_context辞書（絶対パス使用）
    """
    logger = state.logger
    logger.info("=" * 70)
    logger.info("Preparing generation context")
    logger.info("=" * 70)

    # 設定読み込み
    config = state.load_config()

    # パターン判定詳細のデフォルト値
    if pattern_details is None:
        pattern_details = {
            "selection_method": "unknown",
            "confidence": 0.5,
            "reason": "No details provided"
        }

    # 参照ファイルリストの構築（すべて絶対パス）
    reference_files = []

    # 1. app_structure.md（全パターンで必須）
    app_structure_path = state.get_artifact_path("app_structure.md")
    if state.check_file_exists(app_structure_path):
        reference_files.append(str(app_structure_path))
    else:
        logger.warning("app_structure.md not found - should have been generated")

    # 2. spec.json（Partial系パターンで優先的に参照）
    spec_json_info = {
        "detected": False,
        "path": None,
        "feature_id": None,
        "detection_method": None,
        "scope_info": {}
    }

    # Partial系パターン（新旧両方）でspec.jsonを検出
    if pattern in [Pattern.PARTIAL_INTEGRATION, Pattern.PARTIAL_SCENARIO,
                   Pattern.PATTERN2, Pattern.PATTERN3]:
        spec_path = detect_spec_json(state)
        if spec_path:
            spec_json_info["detected"] = True
            spec_json_info["path"] = str(spec_path)
            spec_json_info["detection_method"] = "auto_detection"

            # feature_idを抽出
            feature_id = spec_path.parent.name
            spec_json_info["feature_id"] = feature_id

            # spec.jsonをパース
            spec_data = parse_spec_json(spec_path)
            if spec_data:
                scope_info = extract_scope_info(spec_data)
                spec_json_info["scope_info"] = scope_info
                logger.info(f"spec.json検出・パース成功: {spec_path}")
                logger.info(f"  - outOfScope項目: {len(scope_info.get('out_of_scope', []))}件")
                logger.info(f"  - acceptanceCriteria: {scope_info.get('acceptance_criteria_count', 0)}件")
            else:
                logger.warning(f"spec.jsonのパースに失敗: {spec_path}")

            # reference_filesに追加
            reference_files.append(str(spec_path))
        else:
            logger.info("spec.jsonは検出されませんでした（Git差分フォールバックを使用）")

    # 3. diffs/ディレクトリのファイル（Partial系パターン）
    if pattern in [Pattern.PARTIAL_INTEGRATION, Pattern.PARTIAL_SCENARIO, Pattern.PATTERN2, Pattern.PATTERN3]:
        diffs_dir = state.get_diffs_dir()
        if state.check_dir_not_empty(diffs_dir):
            for diff_file in sorted(diffs_dir.glob("*.txt")):
                reference_files.append(str(diff_file))
        else:
            logger.warning("diffs/ directory is empty")

    # 4. copilot_summary.md（Partial系パターン、あれば）
    if pattern in [Pattern.PARTIAL_INTEGRATION, Pattern.PARTIAL_SCENARIO, Pattern.PATTERN2, Pattern.PATTERN3]:
        copilot_summary_path = state.get_artifact_path("copilot_summary.md")
        if state.check_file_exists(copilot_summary_path):
            reference_files.append(str(copilot_summary_path))

    # 5. 既存test_cases.md（Pattern3, 4）
    if pattern in [Pattern.PATTERN3, Pattern.PATTERN4]:
        test_cases_path = state.get_artifact_path("test_cases.md")
        if state.check_file_exists(test_cases_path):
            reference_files.append(str(test_cases_path))

    # 6. ガイドファイル（for-gen-ai/*.md）
    guide_files = state.get_guide_files()
    for guide_file in guide_files:
        reference_files.append(str(guide_file))

    # 7. プロンプトテンプレート
    prompt_file = state.get_prompt_file()
    if prompt_file.exists():
        reference_files.append(str(prompt_file))

    # 動的target_totalの計算（spec.json情報も考慮）
    calculated_target_total, calculation_details = calculate_dynamic_target_total(
        state, pattern, app_structure_path
    )

    # spec.jsonのacceptanceCriteria数に基づく調整
    if spec_json_info["detected"]:
        ac_count = spec_json_info["scope_info"].get("acceptance_criteria_count", 0)
        if ac_count > 0:
            # 1 AC = 約2-3件のテストケースと仮定
            spec_estimated = ac_count * 2.5
            calculation_details["spec_json_adjustment"] = int(spec_estimated)
            logger.info(f"spec.json調整: AC {ac_count}件 → 推定{int(spec_estimated)}件")

    logger.info(f"Calculated target_total: {calculated_target_total}")
    logger.info(f"Calculation strategy: {calculation_details.get('strategy')}")
    logger.info(f"Source: {calculation_details.get('source')}")

    # テストタイプ選択情報を取得
    test_type_selection = state.test_type_selection

    # quality_settingsを動的計算(テストタイプ選択に応じて目標件数を調整)
    target_by_type = config.get("target_by_type", {
        "integration_tests": 108,
        "scenario_tests": 17,
        "integration_ratio": 0.85,
        "scenario_ratio": 0.15
    })

    if test_type_selection["integration_tests"] and test_type_selection["scenario_tests"]:
        # 両方選択: 結合85%, シナリオ15%
        target_integration = int(calculated_target_total * target_by_type["integration_ratio"])
        target_scenario = int(calculated_target_total * target_by_type["scenario_ratio"])
    elif test_type_selection["integration_tests"]:
        # 結合のみ
        target_integration = calculated_target_total
        target_scenario = 0
    else:
        # シナリオのみ
        target_integration = 0
        target_scenario = calculated_target_total

    logger.info(f"Test type selection: {test_type_selection}")
    logger.info(f"Target integration tests: {target_integration}")
    logger.info(f"Target scenario tests: {target_scenario}")

    # パターン情報の構築（version 2.0フォーマット）
    config_pattern_names = config.get("pattern_names", {})
    legacy_mapping = config.get("pattern_legacy_mapping", {})

    # legacy_nameを逆引き
    legacy_name = None
    for legacy, new_name in legacy_mapping.items():
        if new_name == pattern.value:
            legacy_name = legacy
            break

    pattern_info = {
        "name": pattern.value,
        "legacy_name": legacy_name or pattern_details.get("legacy_pattern"),
        "selection_method": pattern_details.get("selection_method", "unknown"),
        "confidence": pattern_details.get("confidence", 0.0),
        "reason": pattern_details.get("reason", "")
    }

    # generation_context構築（version 2.0）
    context = {
        "run_id": state.run_id,
        "version": "2.0",
        "pattern": pattern_info,
        "scope": {
            "type": "full" if pattern in [Pattern.FULL_INTEGRATION, Pattern.FULL_SCENARIO] else "partial",
            "basis": pattern_details.get("selection_method", "auto_detection")
        },
        "test_type_selection": {
            "integration_tests": test_type_selection.get("integration_tests", True),
            "scenario_tests": test_type_selection.get("scenario_tests", True),
            "selection_method": pattern_details.get("selection_method", "default")
        },
        "development_scope": {
            "type": "full" if pattern in [Pattern.FULL_INTEGRATION, Pattern.FULL_SCENARIO] else "partial",
            "basis": pattern_details.get("selection_method", "auto_detection"),
            "files_changed": len(list(state.get_diffs_dir().glob("*.txt"))) if state.check_dir_not_empty(state.get_diffs_dir()) else 0,
            "diffs_generated": state.check_dir_not_empty(state.get_diffs_dir()),
            "has_copilot_summary": state.check_file_exists(state.get_artifact_path("copilot_summary.md"))
        },
        "spec_json": spec_json_info,
        "pochilib_update": {"enabled": False},
        "repo_root": str(state.get_path("root")),
        "base_branch_detected": base_branch_detected or "origin/main",
        "reference_files": reference_files,
        # パターンに基づいて出力ファイルを決定
        "output_files": {
            "integration": str(state.get_artifact_path("test_cases_integration.md")) if pattern in [Pattern.FULL_INTEGRATION, Pattern.PARTIAL_INTEGRATION] else None,
            "scenario": str(state.get_artifact_path("test_cases_scenario.md")) if pattern in [Pattern.FULL_SCENARIO, Pattern.PARTIAL_SCENARIO] else None
        },
        "output_file": str(state.get_artifact_path("test_cases_integration.md")) if pattern in [Pattern.FULL_INTEGRATION, Pattern.PARTIAL_INTEGRATION] else str(state.get_artifact_path("test_cases_scenario.md")),  # 後方互換性
        "file_separation_enabled": True,
        "prompts_path": str(state.get_artifact_path("prompts_last_run.md")),
        "quality_gate_entry": f"python {state.get_path('skill_core') / 'quality_gate.py'}",
        "quality_settings": {
            "calculated_target_total": calculated_target_total,
            "calculation_details": calculation_details,
            "target_integration_tests": target_integration,
            "target_scenario_tests": target_scenario,
            "ratios": config.get("ratios", {
                "basic": 0.6,
                "boundary": 0.2,
                "abnormal": 0.15,
                "other": 0.05
            })
        },
        "generation_phase": "prepared",
        "llm_executed": False
    }

    # generation_context.jsonを保存
    context_file = state.get_artifact_path("generation_context.json")

    try:
        with open(context_file, 'w', encoding='utf-8') as f:
            json.dump(context, f, ensure_ascii=False, indent=2)
        logger.info(f"Generation context saved: {context_file}")
    except Exception as e:
        logger.error(f"Failed to save generation context: {e}")

    logger.info(f"Pattern: {pattern.value}")
    logger.info(f"Reference files: {len(reference_files)} files")
    logger.info(f"Output: {context['output_file']}")

    # プロンプトファイル作成（エージェント向け指示）
    _create_prompts_file(pattern, context, state)

    return context


def _create_prompts_file(pattern: Pattern, context: Dict, state: SkillState) -> None:
    """prompts_last_run.mdを作成（エージェント向け指示）

    Args:
        pattern: パターン
        context: generation_context辞書
        state: SkillState インスタンス
    """
    logger = state.logger

    # PromptBuilderを使用して最適化されたプロンプトを構築
    prompts_dir = Path(__file__).parent.parent / "prompts"
    builder = PromptBuilder(prompts_dir)

    logger.info(f"Building optimized prompt for pattern: {pattern.value}")
    optimized_prompt = builder.build_optimized_prompt(pattern.value, context)

    # トークン数推定結果をログ出力
    estimated_tokens = builder.estimate_token_count(optimized_prompt)
    logger.info(f"Optimized prompt token count: {estimated_tokens} tokens")

    # 実行手順セクションを追加
    execution_instructions = f"""
# 実行手順

## 1. generation_context.jsonの読み込み

ファイルパス: {context['prompts_path'].replace('prompts_last_run.md', 'generation_context.json')}

このファイルをJSONとして読み込み、以下の情報を取得してください:
- reference_files[]: 参照すべきファイルの絶対パスリスト
- output_file: 出力先ファイルの絶対パス
- quality_settings: 品質基準設定

## 2. 参照ファイルの読み込み

generation_context.jsonのreference_files[]に記載された各ファイルを**ファイル参照機能で開いてください**（コピペ禁止）:

"""

    # 参照ファイルリストを追加
    for ref_file in context["reference_files"]:
        execution_instructions += f"- {ref_file}\n"

    execution_instructions += f"""
## 3. 出力先

ファイル名: test_cases.md（アプリ名を含めない）
配置先: {context['output_file']}

## 4. 生成後の品質検証（必須）

test_cases.mdの生成が完了したら、以下のコマンドを実行してください:

```bash
{context['quality_gate_entry']}
```

このコマンドは:
- テストケースの品質を検証
- 観点比率、総数、具体性をチェック
- quality_report.mdを生成
- generation_context.jsonを更新（llm_executed=True）

**重要**: 品質検証で成功終了コード0が返されるまで、修正と再検証を繰り返してください。

## 5. 問い返し禁止ルール

- 参照ファイルが欠落している場合でもエラーを出さず、利用可能な情報で継続
- 不明な点があっても推測して実装を進める
- 完全な情報が揃わなくても、ベストエフォートで生成を完了する

---
"""

    # 最終的なプロンプトを構築
    final_prompt = execution_instructions + "\n\n" + optimized_prompt

    # prompts_last_run.mdを保存
    prompts_path = state.get_artifact_path("prompts_last_run.md")

    try:
        with open(prompts_path, 'w', encoding='utf-8') as f:
            f.write(final_prompt)
        logger.info(f"Prompts file saved: {prompts_path}")
    except Exception as e:
        logger.error(f"Failed to save prompts file: {e}")

    logger.info(f"Total prompt size: {len(final_prompt)} chars, estimated {builder.estimate_token_count(final_prompt)} tokens")
