"""
Prompt Builder - 階層化プロンプトの動的構築

このモジュールは、パターンに応じて最適なプロンプトを動的に構築します。
トークン使用量を削減するため、必要な情報のみを組み合わせます。
"""

from pathlib import Path
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)


class PromptBuilder:
    """
    階層化されたプロンプトファイルを組み合わせて、
    パターンに応じた最適なプロンプトを動的に構築するクラス
    """

    def __init__(self, prompts_dir: Path):
        """
        Args:
            prompts_dir: プロンプトファイルが格納されているディレクトリ
        """
        self.prompts_dir = Path(prompts_dir)
        self.core_dir = self.prompts_dir / "core"
        self.patterns_dir = self.prompts_dir / "patterns"
        self.reference_dir = self.prompts_dir / "reference_handling"

    def build_optimized_prompt(self, pattern: str, context: Dict) -> str:
        """
        パターンとコンテキストに基づいて最適なプロンプトを構築

        Args:
            pattern: テスト生成パターン（FullIntegration, FullScenario,
                     PartialIntegration, PartialScenario）
            context: generation_context.jsonの内容

        Returns:
            構築されたプロンプト文字列
        """
        logger.info(f"Building optimized prompt for pattern: {pattern}")

        sections = []

        # 1. core/minimal_prompt.md（必須情報）
        sections.append(self._load_file(self.core_dir / "minimal_prompt.md"))

        # 2. generate_test_cases_prompt.md（統合プロンプト）
        # セクション2・3の詳細な生成指示を含む
        sections.append(self._load_file(self.prompts_dir / "generate_test_cases_prompt.md"))

        # 3. patterns/pattern_full.md または pattern_partial.md（パターン判定）
        if pattern in ["FullIntegration", "FullScenario"]:
            sections.append(self._load_file(self.patterns_dir / "pattern_full.md"))
        elif pattern in ["PartialIntegration", "PartialScenario"]:
            sections.append(self._load_file(self.patterns_dir / "pattern_partial.md"))
        else:
            logger.warning(f"Unknown pattern: {pattern}, using pattern_full.md as default")
            sections.append(self._load_file(self.patterns_dir / "pattern_full.md"))

        # 4. core/quality_rules.md（品質ルール）
        sections.append(self._load_file(self.core_dir / "quality_rules.md"))

        # 5. core/format_spec.md（フォーマット仕様）
        sections.append(self._load_file(self.core_dir / "format_spec.md"))

        # 6. reference_handling/file_list_template.md（参照ファイル処理）
        sections.append(self._load_file(self.reference_dir / "file_list_template.md"))

        # 7. コンテキスト情報セクション（動的生成）
        sections.append(self._build_context_section(context))

        # すべてを区切り線で結合
        prompt = "\n\n---\n\n".join(sections)

        # トークン数推定
        estimated_tokens = self.estimate_token_count(prompt)
        logger.info(f"Optimized prompt built. Estimated tokens: {estimated_tokens}")

        return prompt

    def _load_file(self, path: Path) -> str:
        """
        プロンプトファイルを読み込み

        Args:
            path: 読み込むファイルのパス

        Returns:
            ファイルの内容
        """
        try:
            content = path.read_text(encoding="utf-8")
            logger.debug(f"Loaded prompt file: {path}")
            return content
        except FileNotFoundError:
            logger.error(f"Prompt file not found: {path}")
            raise
        except Exception as e:
            logger.error(f"Error loading prompt file {path}: {e}")
            raise

    def _build_context_section(self, context: Dict) -> str:
        """
        generation_context.jsonの情報から動的にコンテキストセクションを生成

        Args:
            context: generation_context.jsonの内容

        Returns:
            コンテキスト情報のマークダウン文字列
        """
        sections = ["# コンテキスト情報"]

        # 品質設定
        quality_settings = context.get("quality_settings", {})
        sections.append("## 品質設定")
        sections.append(f"- **目標総数**: {quality_settings.get('calculated_target_total', 'N/A')}件")
        sections.append(f"- **結合テスト目標**: {quality_settings.get('target_integration_tests', 'N/A')}件")
        sections.append(f"- **シナリオテスト目標**: {quality_settings.get('target_scenario_tests', 'N/A')}件")

        # テストタイプ選択
        test_type = context.get("test_type_selection", {})
        sections.append("\n## テストタイプ選択")
        sections.append(f"- **結合テスト生成**: {'はい' if test_type.get('integration_tests') else 'いいえ'}")
        sections.append(f"- **シナリオテスト生成**: {'はい' if test_type.get('scenario_tests') else 'いいえ'}")

        # spec.json情報（存在する場合）
        spec_json = context.get("spec_json", {})
        if spec_json.get("detected"):
            sections.append("\n## spec.json情報")
            sections.append(f"- **検出**: はい")
            sections.append(f"- **パス**: {spec_json.get('path', 'N/A')}")
            scope_info = spec_json.get("scope_info", {})
            if scope_info:
                sections.append(f"- **除外範囲**: {', '.join(scope_info.get('out_of_scope', []))}")
                sections.append(f"- **AC件数**: {scope_info.get('acceptance_criteria_count', 'N/A')}件")
                sections.append(f"- **対象ユーザー**: {', '.join(scope_info.get('target_users', []))}")

        # 参照ファイル
        ref_files = context.get("reference_files", [])
        sections.append("\n## 参照ファイル")
        if ref_files:
            for ref_file in ref_files:
                sections.append(f"- {ref_file}")
        else:
            sections.append("- （なし）")

        return "\n".join(sections)

    def estimate_token_count(self, prompt: str) -> int:
        """
        プロンプトのトークン数を推定

        Args:
            prompt: プロンプト文字列

        Returns:
            推定トークン数（文字数×0.28）
        """
        char_count = len(prompt)
        estimated_tokens = int(char_count * 0.28)
        return estimated_tokens


def create_optimized_prompt(
    pattern: str,
    context: Dict,
    prompts_dir: Optional[Path] = None
) -> str:
    """
    最適化されたプロンプトを生成する便利関数

    Args:
        pattern: テスト生成パターン
        context: generation_context.jsonの内容
        prompts_dir: プロンプトディレクトリ（Noneの場合はデフォルトパス）

    Returns:
        構築されたプロンプト文字列
    """
    if prompts_dir is None:
        # デフォルトパス: skills/pochi-test-orchestrator/prompts
        prompts_dir = Path(__file__).parent.parent / "prompts"

    builder = PromptBuilder(prompts_dir)
    return builder.build_optimized_prompt(pattern, context)
