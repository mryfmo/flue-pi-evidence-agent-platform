"""
環境・構成チェックモジュール

Pythonバージョン、Gitコマンド、プロジェクト構成などを検証する。
非対話的に動作し、自動修復可能なものは修復する。
"""
import sys
import subprocess
import platform
from pathlib import Path
from typing import Tuple

from .state import SkillState


def run(state: SkillState) -> bool:
    """環境チェックを実行（非対話版）
    
    Args:
        state: SkillState インスタンス
        
    Returns:
        成功した場合True
    """
    logger = state.logger
    logger.info("=" * 70)
    logger.info("Environment precheck")
    logger.info("=" * 70)
    
    all_ok = True
    
    # 1. Pythonバージョンチェック
    py_ok, py_version = _check_python_version()
    logger.info(f"Python version: {py_version}")
    if not py_ok:
        logger.error(f"Python version too old (required: 3.8+, detected: {py_version})")
        all_ok = False
    
    # 2. OS検出
    os_name = platform.system()
    logger.info(f"OS: {os_name}")
    
    # 3. Gitコマンドチェック
    git_ok, git_info = _check_git_command()
    if git_ok:
        logger.info(f"Git: {git_info}")
    else:
        logger.error(f"Git command not found: {git_info}")
        all_ok = False
    
    # 4. Gitリポジトリチェック
    if git_ok:
        repo_ok, repo_info = _check_git_repository()
        if repo_ok:
            logger.info(f"Git repository: {repo_info}")
        else:
            logger.warning(f"Not a Git repository - some features will be limited")
    
    # 5. 権限チェック（自動修復可能）
    perm_ok = _check_permissions(state)
    if not perm_ok:
        logger.error("File operation permission error")
        all_ok = False
    
    # 6. app_structure_analyzer.pyチェック
    analyzer_path = state.get_path("tools") / "app_structure_analyzer.py"
    if analyzer_path.exists():
        logger.info(f"app_structure_analyzer.py: {analyzer_path}")
    else:
        logger.warning(f"app_structure_analyzer.py not found: {analyzer_path}")
        logger.warning("Will need manual setup if Pattern1/2 is detected")
    
    # サマリ更新
    state.update_summary({
        "precheck_passed": all_ok,
        "python_version": py_version,
        "os": os_name,
        "git_available": git_ok
    })
    
    if all_ok:
        logger.info("✅ All prechecks passed")
    else:
        logger.warning("⚠️ Some prechecks failed - review logs")
    
    logger.info("=" * 70)
    
    return all_ok


def _check_python_version() -> Tuple[bool, str]:
    """Pythonバージョンをチェック（3.8+必須）"""
    version_info = sys.version_info
    version_str = f"{version_info.major}.{version_info.minor}.{version_info.micro}"
    
    if version_info.major == 3 and version_info.minor >= 8:
        return True, version_str
    else:
        return False, version_str


def _check_git_command() -> Tuple[bool, str]:
    """Gitコマンドの存在確認"""
    try:
        result = subprocess.run(
            ["git", "--version"],
            capture_output=True,
            text=True,
            check=True,
            timeout=5
        )
        version = result.stdout.strip()
        return True, version
    except FileNotFoundError:
        return False, "Git command not found"
    except subprocess.TimeoutExpired:
        return False, "Git command timed out"
    except Exception as e:
        return False, f"Error: {str(e)}"


def _check_git_repository() -> Tuple[bool, str]:
    """Gitリポジトリであることを確認"""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True,
            text=True,
            check=True,
            timeout=5
        )
        git_dir = result.stdout.strip()
        return True, git_dir
    except subprocess.CalledProcessError:
        return False, "Not a Git repository"
    except Exception as e:
        return False, f"Error: {str(e)}"


def _check_permissions(state: SkillState) -> bool:
    """ファイル操作の権限をチェック"""
    try:
        # テンポラリファイルの作成・削除を試行
        test_file = state.get_path("logs") / ".__pochi_test_permission__"
        test_file.write_text("test", encoding='utf-8')
        test_file.unlink()
        state.logger.info("File operation permission: OK")
        return True
    except Exception as e:
        state.logger.error(f"File operation permission error: {e}")
        return False
