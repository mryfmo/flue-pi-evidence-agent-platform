"""
品質ゲートモジュール

test_cases.mdの品質を検証し、quality_report.mdを生成する。
観点比率、UI要素網羅、具体値必須チェックを実施。

二重の役割:
1. 関数API: run(state) -> bool
2. CLIエントリ: python core/quality_gate.py
"""
import sys
import re
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from collections import Counter


class QualityReport:
    """品質レポートを保持するクラス"""

    def __init__(self, config: Dict, logger, test_type_selection: Dict[str, bool] = None):
        self.config = config
        self.logger = logger
        self.test_case_count = 0
        self.perspective_counts = {"basic": 0, "boundary": 0, "abnormal": 0, "other": 0}
        self.ui_coverage = {"total": 0, "covered": 0, "uncovered": []}
        self.ambiguous_count = 0
        self.ambiguous_examples = []
        self.issues = []
        self.warnings = []
        self.passed = True
        # Phase 2: 詳細定義検証
        self.detailed_definitions = {
            "section_exists": False,
            "total_test_cases": 0,
            "defined_count": 0,
            "undefined_cases": [],
            "steps_completeness": 0.0,
            "expected_completeness": 0.0
        }
        # 動的計算の詳細（存在する場合）
        self.target_calculation_details = config.get("calculation_details", {})
        # テストタイプ選択（Phase 3追加）
        self.test_type_selection = test_type_selection or {
            "integration_tests": True,
            "scenario_tests": True
        }
        self.integration_test_count = 0
        self.scenario_test_count = 0
    
    def add_issue(self, message: str) -> None:
        """重大な問題を追加"""
        self.issues.append(message)
        self.passed = False
        self.logger.error(f"ISSUE: {message}")
    
    def add_warning(self, message: str) -> None:
        """警告を追加"""
        self.warnings.append(message)
        self.logger.warning(f"WARNING: {message}")
    
    def generate_report(self) -> str:
        """レポートを生成"""
        report = """# テストケース品質レポート

## 総合評価

"""
        
        if self.passed:
            report += "✅ **合格** - すべての品質基準を満たしています\n\n"
        else:
            report += "❌ **不合格** - 以下の問題を修正してください\n\n"
        
        # 1. テストケース数
        # target_totalの取得（calculated_target_totalを優先）
        target_total = self.config.get('calculated_target_total') or self.config.get('target_total', 125)

        report += f"""## 1. テストケース数

- **総数**: {self.test_case_count}件
  - 結合テスト: {self.integration_test_count}件
  - シナリオテスト: {self.scenario_test_count}件
- **目標**: {target_total}件
- **達成率**: {self.test_case_count / target_total * 100:.1f}%

"""

        # セクション別の目標との比較
        if self.test_type_selection["integration_tests"] or self.test_type_selection["scenario_tests"]:
            report += "### セクション別の達成状況\n\n"

            if self.test_type_selection["integration_tests"]:
                target_integration = self.config.get("target_integration_tests", int(target_total * 0.85))
                integration_achievement = self.integration_test_count / target_integration * 100 if target_integration > 0 else 0
                report += f"- **結合テスト**: {self.integration_test_count}件 / 目標{target_integration}件 ({integration_achievement:.1f}%)\n"

            if self.test_type_selection["scenario_tests"]:
                target_scenario = self.config.get("target_scenario_tests", int(target_total * 0.15))
                scenario_achievement = self.scenario_test_count / target_scenario * 100 if target_scenario > 0 else 0
                report += f"- **シナリオテスト**: {self.scenario_test_count}件 / 目標{target_scenario}件 ({scenario_achievement:.1f}%)\n"

            report += "\n"

        # 動的計算の根拠を表示
        if self.target_calculation_details:
            report += """### 目標件数の計算根拠

"""
            details = self.target_calculation_details
            report += f"- **戦略**: {details.get('strategy', 'N/A')}\n"

            # パターン名を取得（version 2.0対応）
            pattern_value = details.get('pattern', 'N/A')
            if isinstance(pattern_value, dict):
                pattern_name = pattern_value.get('name', 'N/A')
            else:
                pattern_name = pattern_value

            report += f"- **パターン**: {pattern_name}\n"
            report += f"- **計算元**: {details.get('source', 'N/A')}\n"

            if details.get('source') == 'app_structure_estimate':
                report += f"- **app_structure推定値**: {details.get('base_value', 'N/A')}件\n"
            elif details.get('source') == 'fallback_calculation':
                metrics = details.get('metrics', {})
                report += f"- **UI要素数**: {metrics.get('ui_elements', 0)}\n"
                report += f"- **画面数**: {metrics.get('screens', 0)}\n"
                report += f"- **基本値**: {details.get('base_value', 'N/A')}件\n"
            elif details.get('source') == 'pattern3_incremental':
                report += f"- **既存件数**: {details.get('existing_count', 0)}件\n"
                report += f"- **変更画面**: {details.get('changed_screens', 0)}画面\n"
                report += f"- **変更UI要素**: {details.get('changed_ui', 0)}要素\n"
                report += f"- **追加分**: {details.get('additional_cases', 0)}件\n"
                report += f"- **上限**: {details.get('max_allowed', 0)}件（既存×130%）\n"

            if details.get('multiplier'):
                report += f"- **パターン倍率**: {details.get('multiplier')}\n"

            report += f"- **最終目標**: {details.get('final_value', target_total)}件\n\n"

        if self.test_case_count < target_total * 0.9:
            report += f"⚠️ 目標件数の90%未満です。テストケースを追加してください。\n\n"
        elif self.test_case_count > target_total * 1.1:
            report += f"ℹ️ 目標件数の110%を超えています。必要に応じて見直しを検討してください。\n\n"
        else:
            report += f"✅ 適切な件数です。\n\n"

        # 2. 観点比率
        report += """## 2. 観点比率

| 観点 | 実績 | 目標 | 達成率 | 評価 |
|------|------|------|--------|------|
"""
        
        for perspective in ["basic", "boundary", "abnormal", "other"]:
            actual_count = self.perspective_counts[perspective]
            actual_ratio = actual_count / max(self.test_case_count, 1)
            target_ratio = self.config['ratios'][perspective]
            achievement = actual_ratio / target_ratio * 100 if target_ratio > 0 else 0
            
            status = "✅" if 80 <= achievement <= 120 else "⚠️"
            
            report += f"| {perspective} | {actual_count}件 ({actual_ratio*100:.1f}%) | {target_ratio*100:.0f}% | {achievement:.1f}% | {status} |\n"
        
        report += "\n"
        
        # 3. UI要素網羅
        report += f"""## 3. UI要素網羅

- **総UI要素数**: {self.ui_coverage['total']}個
- **カバー済み**: {self.ui_coverage['covered']}個
- **カバレッジ**: {self.ui_coverage['covered'] / max(self.ui_coverage['total'], 1) * 100:.1f}%

"""
        
        if self.ui_coverage['uncovered']:
            report += "### 未カバーのUI要素\n\n"
            for ui_element in self.ui_coverage['uncovered'][:10]:  # 最大10件
                report += f"- {ui_element}\n"
            if len(self.ui_coverage['uncovered']) > 10:
                report += f"\n...他{len(self.ui_coverage['uncovered']) - 10}件\n"
            report += "\n"
        else:
            report += "✅ すべてのUI要素がカバーされています。\n\n"
        
        # 4. 具体値必須チェック
        report += f"""## 4. 具体値必須チェック

- **曖昧表現の検出数**: {self.ambiguous_count}件

"""
        
        if self.ambiguous_count > 0:
            report += "### 検出された曖昧表現\n\n"
            for example in self.ambiguous_examples[:10]:  # 最大10件
                report += f"- {example}\n"
            if len(self.ambiguous_examples) > 10:
                report += f"\n...他{len(self.ambiguous_examples) - 10}件\n"
            report += "\n⚠️ 期待結果は具体的な数値、日付、データ例を含めてください。\n\n"
        else:
            report += "✅ 曖昧な表現は検出されませんでした。\n\n"

        # 5. テストケース詳細定義（Phase 2追加）
        report += f"""## 5. テストケース詳細定義

- **セクション存在**: {"✅" if self.detailed_definitions["section_exists"] else "❌"}
- **詳細定義カバレッジ**: {self.detailed_definitions["defined_count"]}/{self.detailed_definitions["total_test_cases"]}件 ({self.detailed_definitions["defined_count"] / max(self.detailed_definitions["total_test_cases"], 1) * 100:.1f}%)
- **テスト手順完全性**: {self.detailed_definitions["steps_completeness"]:.1f}%
- **期待結果観測可能性**: {self.detailed_definitions["expected_completeness"]:.1f}%

"""

        if not self.detailed_definitions["section_exists"]:
            report += "❌ セクション3「テストケース詳細定義」が存在しません。\n\n"
        elif self.detailed_definitions["defined_count"] / max(self.detailed_definitions["total_test_cases"], 1) < 0.8:
            report += f"⚠️ 詳細定義カバレッジが80%未満です（目標100%）。\n\n"
            if self.detailed_definitions["undefined_cases"]:
                report += "### 未定義テストケース\n\n"
                for case_id in self.detailed_definitions["undefined_cases"][:10]:
                    report += f"- {case_id}\n"
                if len(self.detailed_definitions["undefined_cases"]) > 10:
                    report += f"\n...他{len(self.detailed_definitions['undefined_cases']) - 10}件\n"
                report += "\n"
        else:
            report += "✅ 詳細定義カバレッジが基準を満たしています。\n\n"

        # 6. 問題と警告
        if self.issues:
            report += "## 6. 重大な問題\n\n"
            for issue in self.issues:
                report += f"- ❌ {issue}\n"
            report += "\n"

        if self.warnings:
            report += "## 7. 警告\n\n"
            for warning in self.warnings:
                report += f"- ⚠️ {warning}\n"
            report += "\n"

        # 8. 改善指示
        report += "## 8. 改善指示\n\n"
        
        if not self.passed:
            report += "以下の項目を修正してください：\n\n"
            
            if self.test_case_count < self.config['target_total'] * 0.9:
                deficit = self.config['target_total'] - self.test_case_count
                report += f"1. テストケースを約{deficit}件追加（目標{self.config['target_total']}件）\n"
            
            for perspective in ["basic", "boundary", "abnormal", "other"]:
                actual_ratio = self.perspective_counts[perspective] / max(self.test_case_count, 1)
                target_ratio = self.config['ratios'][perspective]
                if actual_ratio < target_ratio * 0.8:
                    deficit = int(target_ratio * self.config['target_total']) - self.perspective_counts[perspective]
                    report += f"2. {perspective}観点のテストケースを約{deficit}件追加\n"
            
            if self.ui_coverage['uncovered']:
                report += f"3. 未カバーのUI要素（{len(self.ui_coverage['uncovered'])}個）に対応するテストケースを追加\n"
            
            if self.ambiguous_count > 10:
                report += f"4. 曖昧表現（{self.ambiguous_count}件）を具体的な値に修正\n"
        else:
            report += "品質基準を満たしています。問題ありません。\n"
        
        return report


def count_test_cases(content: str) -> int:
    """テストケースの総数をカウント"""
    # "#### テストケースID: "または"### テストケースID: "で始まる行をカウント
    pattern = r'^#{3,4}\s+テストケースID:\s+'
    matches = re.findall(pattern, content, re.MULTILINE)
    return len(matches)


def count_test_cases_by_section(content: str) -> Tuple[int, int]:
    """セクション1とセクション2のテストケース数をカウント

    Returns:
        (integration_count, scenario_count)
    """
    integration_count = 0
    scenario_count = 0
    current_section = None

    for line in content.split('\n'):
        # セクション1の開始を検出
        if line.startswith('## セクション1:') or line.startswith('## セクション1 :'):
            current_section = 'integration'
        # セクション2の開始を検出
        elif line.startswith('## セクション2:') or line.startswith('## セクション2 :'):
            current_section = 'scenario'
        # セクション3以降は無視
        elif line.startswith('## セクション3:'):
            current_section = None
        # テストケースIDをカウント
        elif line.startswith('#### テストケースID:') or line.startswith('### テストケースID:'):
            if current_section == 'integration':
                integration_count += 1
            elif current_section == 'scenario':
                scenario_count += 1

    return integration_count, scenario_count


def analyze_perspectives(content: str, config: Dict) -> Dict[str, int]:
    """観点の分類をカウント
    
    タグ、見出し、キーワードの三段構えで判定
    """
    counts = {"basic": 0, "boundary": 0, "abnormal": 0, "other": 0}
    
    # テストケースブロックを抽出（#### または ### に対応）
    test_case_blocks = re.split(r'^#{3,4}\s+テストケースID:\s+', content, flags=re.MULTILINE)[1:]
    
    for block in test_case_blocks:
        # タグでの判定
        if re.search(r'\[基本\]|\[正常\]', block):
            counts["basic"] += 1
        elif re.search(r'\[境界\]|\[限界\]', block):
            counts["boundary"] += 1
        elif re.search(r'\[異常\]|\[エラー\]|\[例外\]', block):
            counts["abnormal"] += 1
        else:
            # キーワードでの判定（フォールバック）
            if re.search(r'正常|基本|通常|標準', block):
                counts["basic"] += 1
            elif re.search(r'境界|限界|最大|最小|上限|下限', block):
                counts["boundary"] += 1
            elif re.search(r'異常|エラー|例外|不正|無効', block):
                counts["abnormal"] += 1
            else:
                counts["other"] += 1
    
    return counts


def extract_ui_elements(app_structure_content: str) -> List[str]:
    """app_structure.mdからUI要素を抽出"""
    ui_elements = []
    
    # "## UI要素情報"セクションを探索
    ui_section_match = re.search(
        r'##\s+UI要素情報.*?(?=\n##|\Z)',
        app_structure_content,
        re.DOTALL
    )
    
    if ui_section_match:
        ui_section = ui_section_match.group(0)
        
        # リスト項目を抽出（"- "で始まる行）
        list_items = re.findall(r'^-\s+(.+)$', ui_section, re.MULTILINE)
        ui_elements.extend(list_items)
        
        # テーブルからも抽出（| で区切られた行）
        table_rows = re.findall(r'^\|([^|]+)\|', ui_section, re.MULTILINE)
        for row in table_rows:
            if row.strip() and not row.strip().startswith('-'):
                ui_elements.append(row.strip())
    
    # 重複を除去
    ui_elements = list(set(ui_elements))
    
    return ui_elements


def check_ui_coverage(
    test_cases_content: str,
    ui_elements: List[str],
    config: Dict
) -> Dict:
    """UI要素のカバレッジをチェック"""
    covered = []
    uncovered = []
    
    exact_match = config.get('ui_match_thresholds', {}).get('exact', True)
    partial_ratio = config.get('ui_match_thresholds', {}).get('partial_ratio', 0.7)
    
    for ui_element in ui_elements:
        # 完全一致チェック
        if ui_element in test_cases_content:
            covered.append(ui_element)
            continue
        
        # 部分一致チェック（単語単位）
        words = ui_element.split()
        if len(words) > 1:
            # 複合語の場合、一定割合以上の単語が含まれているかチェック
            matched_words = sum(1 for word in words if word in test_cases_content)
            if matched_words / len(words) >= partial_ratio:
                covered.append(ui_element)
                continue
        
        # カバーされていない
        uncovered.append(ui_element)
    
    return {
        "total": len(ui_elements),
        "covered": len(covered),
        "uncovered": uncovered
    }


def check_ambiguous_terms(content: str, config: Dict) -> Tuple[int, List[str]]:
    """曖昧な表現をチェック"""
    ambiguous_terms = config.get('ambiguous_terms', [])
    examples = []
    
    # テストケースブロックを抽出
    test_case_blocks = re.split(r'^###\s+テストケースID:\s+', content, flags=re.MULTILINE)[1:]
    
    for i, block in enumerate(test_case_blocks, 1):
        # 期待結果のセクションを抽出
        expected_match = re.search(r'期待結果.*?:(.*?)(?=\n\*\*|###|\Z)', block, re.DOTALL)

        sections = []
        if expected_match:
            sections.append(("期待結果", expected_match.group(1)))
        
        for section_name, section_text in sections:
            for term in ambiguous_terms:
                if term in section_text:
                    examples.append(f"テストケース#{i} {section_name}に「{term}」を含む")
                    if len(examples) >= 20:  # 最大20件
                        return len(examples), examples
    
    return len(examples), examples


def validate_detailed_definitions(content: str, total_test_cases: int) -> Dict:
    """テストケース詳細定義を検証（Phase 2追加）

    Args:
        content: test_cases.mdの内容
        total_test_cases: 総テストケース数

    Returns:
        詳細定義検証結果の辞書
    """
    result = {
        "section_exists": False,
        "total_test_cases": total_test_cases,
        "defined_count": 0,
        "undefined_cases": [],
        "steps_completeness": 0.0,
        "expected_completeness": 0.0
    }

    # セクション3の存在確認
    section3_pattern = r'^##\s+セクション3:\s*テストケース詳細定義'
    if re.search(section3_pattern, content, re.MULTILINE):
        result["section_exists"] = True
    else:
        return result  # セクションが存在しない場合は早期リターン

    # すべてのテストケースIDを抽出（TC-XXX, SC-XXX）
    test_case_ids = set()
    test_case_pattern = r'^#{3,4}\s+テストケースID:\s+(TC-\d+|SC-\d+)'
    for match in re.finditer(test_case_pattern, content, re.MULTILINE):
        test_case_ids.add(match.group(1))

    # 詳細定義が存在するテストケースIDを抽出
    detailed_def_pattern = r'^###\s+(TC-\d+|SC-\d+)\s+詳細定義:'
    defined_cases = set()
    for match in re.finditer(detailed_def_pattern, content, re.MULTILINE):
        defined_cases.add(match.group(1))

    result["defined_count"] = len(defined_cases)
    result["undefined_cases"] = sorted(list(test_case_ids - defined_cases))

    # 詳細定義ブロックを抽出して品質を検証
    detailed_blocks = re.split(r'^###\s+(TC-\d+|SC-\d+)\s+詳細定義:', content, flags=re.MULTILINE)[1:]

    steps_scores = []
    expected_scores = []

    for i in range(0, len(detailed_blocks), 2):
        if i + 1 >= len(detailed_blocks):
            break

        case_id = detailed_blocks[i]
        block = detailed_blocks[i + 1]

        # テスト手順の完全性（ステップ数）
        steps_match = re.search(r'\*\*テスト手順\(詳細\)\*\*:(.*?)(?=\n\*\*|###|\Z)', block, re.DOTALL)
        if steps_match:
            steps_text = steps_match.group(1)
            # 番号付きリストの数をカウント
            step_count = len(re.findall(r'^\s*\d+\.', steps_text, re.MULTILINE))
            steps_scores.append(1.0 if step_count >= 1 else 0.0)

        # 期待結果の観測可能性（具体値の有無）
        expected_match = re.search(r'\*\*期待結果\(詳細\)\*\*:(.*?)(?=\n\*\*|###|\Z)', block, re.DOTALL)
        if expected_match:
            expected_text = expected_match.group(1)
            # 具体値パターン
            has_concrete_values = bool(
                re.search(r'\d+', expected_text) or  # 数値
                re.search(r'\d{4}[/-]\d{1,2}[/-]\d{1,2}', expected_text) or  # 日付
                re.search(r'[「『].*?[」』]', expected_text)  # 引用符で囲まれたテキスト
            )
            expected_scores.append(1.0 if has_concrete_values else 0.0)

    # 平均スコアを計算
    if steps_scores:
        result["steps_completeness"] = sum(steps_scores) / len(steps_scores) * 100
    if expected_scores:
        result["expected_completeness"] = sum(expected_scores) / len(expected_scores) * 100

    return result


def run_quality_gate_core(
    test_cases_path: Path,
    app_structure_path: Optional[Path],
    config: Dict,
    logger,
    test_type_selection: Dict[str, bool] = None,
    pattern_type: str = "integration"
) -> Tuple['QualityReport', str]:
    """品質ゲート実行（コアロジック）

    Args:
        test_cases_path: test_cases.mdのパス
        app_structure_path: app_structure.mdのパス
        config: 品質設定
        logger: ロガー
        test_type_selection: テストタイプ選択情報
        pattern_type: パターンタイプ ("integration" or "scenario")

    Returns:
        (QualityReport, レポート文字列)
    """
    logger.info("=" * 70)
    logger.info("品質ゲートを開始します")
    logger.info("=" * 70)

    report = QualityReport(config, logger, test_type_selection)
    
    # test_cases.mdを読み込み
    if not test_cases_path.exists():
        report.add_issue(f"test_cases.mdが見つかりません: {test_cases_path}")
        return report, report.generate_report()
    
    try:
        with open(test_cases_path, 'r', encoding='utf-8') as f:
            test_cases_content = f.read()
    except Exception as e:
        report.add_issue(f"test_cases.mdの読み込みに失敗: {e}")
        return report, report.generate_report()
    
    # 1. テストケース数のカウント（セクション別）
    logger.info("テストケース数をカウント中...")
    report.test_case_count = count_test_cases(test_cases_content)
    integration_count, scenario_count = count_test_cases_by_section(test_cases_content)
    report.integration_test_count = integration_count
    report.scenario_test_count = scenario_count

    logger.info(f"テストケース総数: {report.test_case_count}件")
    logger.info(f"  - 結合テスト: {integration_count}件")
    logger.info(f"  - シナリオテスト: {scenario_count}件")

    if report.test_case_count == 0:
        report.add_issue("テストケースが1件も見つかりません")
        return report, report.generate_report()

    # 選択されたテストタイプのみを検証
    if report.test_type_selection["integration_tests"]:
        target_integration = config.get("target_integration_tests", int(config.get('calculated_target_total', 125) * 0.85))
        if integration_count < target_integration * 0.9:
            report.add_issue(
                f"結合テストケース数が目標の90%未満です（{integration_count}/{target_integration}件）"
            )
        elif integration_count < target_integration:
            report.add_warning(
                f"結合テストケース数が目標未達です（{integration_count}/{target_integration}件）"
            )

    if report.test_type_selection["scenario_tests"]:
        target_scenario = config.get("target_scenario_tests", int(config.get('calculated_target_total', 125) * 0.15))
        if scenario_count < target_scenario * 0.9:
            report.add_issue(
                f"シナリオテストケース数が目標の90%未満です（{scenario_count}/{target_scenario}件）"
            )
        elif scenario_count < target_scenario:
            report.add_warning(
                f"シナリオテストケース数が目標未達です（{scenario_count}/{target_scenario}件）"
            )
    
    # 2. 観点比率の分析
    logger.info("観点比率を分析中...")
    report.perspective_counts = analyze_perspectives(test_cases_content, config)
    
    for perspective, count in report.perspective_counts.items():
        actual_ratio = count / max(report.test_case_count, 1)
        target_ratio = config['ratios'][perspective]
        
        if actual_ratio < target_ratio * 0.8:
            report.add_issue(
                f"{perspective}観点の比率が目標の80%未満です（{actual_ratio*100:.1f}% / 目標{target_ratio*100:.0f}%）"
            )
        elif actual_ratio < target_ratio * 0.9:
            report.add_warning(
                f"{perspective}観点の比率が目標の90%未満です（{actual_ratio*100:.1f}% / 目標{target_ratio*100:.0f}%）"
            )
    
    # 3. UI要素網羅のチェック
    if app_structure_path and app_structure_path.exists():
        logger.info("UI要素網羅をチェック中...")
        try:
            with open(app_structure_path, 'r', encoding='utf-8') as f:
                app_structure_content = f.read()
            
            ui_elements = extract_ui_elements(app_structure_content)
            logger.info(f"UI要素を{len(ui_elements)}個抽出しました")
            
            report.ui_coverage = check_ui_coverage(test_cases_content, ui_elements, config)
            
            coverage_ratio = report.ui_coverage['covered'] / max(report.ui_coverage['total'], 1)
            
            if coverage_ratio < 0.8:
                report.add_issue(
                    f"UI要素のカバレッジが80%未満です（{coverage_ratio*100:.1f}%）"
                )
            elif coverage_ratio < 0.9:
                report.add_warning(
                    f"UI要素のカバレッジが90%未満です（{coverage_ratio*100:.1f}%）"
                )
        except Exception as e:
            logger.error(f"UI要素網羅チェックに失敗: {e}")
            report.add_warning("UI要素網羅チェックをスキップしました")
    else:
        logger.warning("app_structure.mdが見つかりません。UI要素網羅チェックをスキップします。")
    
    # 4. 曖昧表現のチェック
    logger.info("曖昧表現をチェック中...")
    report.ambiguous_count, report.ambiguous_examples = check_ambiguous_terms(test_cases_content, config)

    if report.ambiguous_count > 20:
        report.add_issue(f"曖昧な表現が多すぎます（{report.ambiguous_count}件）")
    elif report.ambiguous_count > 10:
        report.add_warning(f"曖昧な表現が検出されました（{report.ambiguous_count}件）")

    # 5. テストケース詳細定義のチェック（Phase 2追加）
    logger.info("テストケース詳細定義をチェック中...")
    report.detailed_definitions = validate_detailed_definitions(test_cases_content, report.test_case_count)

    if not report.detailed_definitions["section_exists"]:
        report.add_warning("セクション3「テストケース詳細定義」が存在しません")
    else:
        coverage = report.detailed_definitions["defined_count"] / max(report.detailed_definitions["total_test_cases"], 1)
        logger.info(f"詳細定義カバレッジ: {coverage*100:.1f}% ({report.detailed_definitions['defined_count']}/{report.detailed_definitions['total_test_cases']}件)")

        if coverage < 0.8:
            report.add_warning(f"詳細定義カバレッジが80%未満です（{coverage*100:.1f}%、目標100%）")

    # レポート生成
    logger.info("=" * 70)
    logger.info("品質ゲートが完了しました")
    logger.info(f"総合評価: {'合格' if report.passed else '不合格'}")
    logger.info("=" * 70)
    
    return report, report.generate_report()


def run(state: 'SkillState') -> bool:
    """品質ゲート実行（関数API）

    Args:
        state: SkillState インスタンス

    Returns:
        品質ゲート合格時 True、不合格時 False
    """
    from .state import SkillState

    state.logger.info("品質ゲートを実行します")

    # generation_context.jsonから設定を読み込む
    context_path = state.paths["artifacts"] / "generation_context.json"

    if not context_path.exists():
        state.logger.error(f"generation_context.jsonが見つかりません: {context_path}")
        return False

    try:
        with open(context_path, 'r', encoding='utf-8') as f:
            context = json.load(f)
    except Exception as e:
        state.logger.error(f"generation_context.jsonの読み込みに失敗: {e}")
        return False

    # output_filesを取得
    output_files = context.get("output_files", {})

    # パターンに応じて検証対象を決定
    test_cases_path = None
    pattern_type = None

    if output_files.get("integration"):
        test_cases_path = Path(output_files["integration"])
        pattern_type = "integration"
    elif output_files.get("scenario"):
        test_cases_path = Path(output_files["scenario"])
        pattern_type = "scenario"
    else:
        # 後方互換性: output_fileを使用
        test_cases_path = Path(context.get("output_file", ""))
        pattern_type = "integration"  # デフォルト

    app_structure_path = None

    # reference_filesからapp_structure.mdを探す
    for ref_file in context.get("reference_files", []):
        if "app_structure.md" in ref_file:
            app_structure_path = Path(ref_file)
            break

    # 品質設定の取得
    quality_settings = context.get("quality_settings", {})

    # テストタイプ選択を取得
    test_type_selection = context.get("test_type_selection", {
        "integration_tests": True,
        "scenario_tests": True
    })

    # 品質ゲート実行
    report_obj, report_text = run_quality_gate_core(
        test_cases_path,
        app_structure_path,
        quality_settings,
        state.logger,
        test_type_selection,
        pattern_type
    )
    
    # quality_report.mdの保存を無効化
    report_path = Path("/dev/null")
    
    # generation_context.jsonを更新（llm_executed=True、generation_phase="quality_checked"）
    context["llm_executed"] = True
    context["generation_phase"] = "quality_checked"
    context["quality_report_path"] = str(report_path)
    
    try:
        with open(context_path, 'w', encoding='utf-8') as f:
            json.dump(context, f, indent=2, ensure_ascii=False)
        state.logger.info("generation_context.jsonを更新しました（llm_executed=True）")
    except Exception as e:
        state.logger.error(f"generation_context.jsonの更新に失敗: {e}")
        return False
    
    # last_run_summary.jsonを最終確定更新
    from datetime import datetime
    state.update_summary({
        "llm_executed": True,
        "quality_gate": {
            "executed": True,
            "passed": report_obj.passed,
            "completed_at": datetime.now().isoformat(),
            "test_case_count": report_obj.test_case_count,
            "target_count": quality_settings.get("calculated_target_total") or quality_settings.get("target_total", 0),
            "perspective_counts": report_obj.perspective_counts,
            "ui_coverage_ratio": report_obj.ui_coverage['covered'] / max(report_obj.ui_coverage['total'], 1) if report_obj.ui_coverage['total'] > 0 else 0,
            "ambiguous_count": report_obj.ambiguous_count,
            "issues_count": len(report_obj.issues),
            "warnings_count": len(report_obj.warnings),
            "report_path": str(report_path)
        }
    })
    state.write_summary()
    
    return report_obj.passed


def main():
    """CLIエントリポイント
    
    generation_context.jsonから設定を読み込み、品質ゲートを実行します。
    
    実行フロー:
    1. generation_context.jsonを読み込み
    2. test_cases.mdとapp_structure.mdの品質検証
    3. quality_report.md生成
    4. generation_context.json更新（llm_executed=True）
    5. last_run_summary.json最終確定更新（品質ゲートメトリクス含む）
    """
    # パスの設定（リポジトリルートから実行される想定）
    repo_root = Path.cwd()

    # generation_context.jsonを読み込む
    context_path = repo_root / "app" / "pochi-test-guidelines-artifacts" / "generation_context.json"
    
    if not context_path.exists():
        print(f"❌ エラー: generation_context.jsonが見つかりません: {context_path}")
        print("   skill_entry.pyを先に実行してください。")
        return 1
    
    try:
        with open(context_path, 'r', encoding='utf-8') as f:
            context = json.load(f)
    except Exception as e:
        print(f"❌ エラー: generation_context.jsonの読み込みに失敗: {e}")
        return 1
    
    # SkillStateを初期化（ロガーのみ使用）
    from .state import SkillState
    state = SkillState()
    
    state.logger.info("=" * 70)
    state.logger.info("品質ゲート（CLI実行）")
    state.logger.info("=" * 70)

    # output_filesを取得
    output_files = context.get("output_files", {})

    # パターンに応じて検証対象を決定
    test_cases_path = None
    pattern_type = None

    if output_files.get("integration"):
        test_cases_path = Path(output_files["integration"])
        pattern_type = "integration"
    elif output_files.get("scenario"):
        test_cases_path = Path(output_files["scenario"])
        pattern_type = "scenario"
    else:
        # 後方互換性: output_fileを使用
        test_cases_path = Path(context.get("output_file", ""))
        pattern_type = "integration"  # デフォルト

    app_structure_path = None

    # reference_filesからapp_structure.mdを探す
    for ref_file in context.get("reference_files", []):
        if "app_structure.md" in ref_file:
            app_structure_path = Path(ref_file)
            break

    # 品質設定の取得
    quality_settings = context.get("quality_settings", {})

    # テストタイプ選択を取得
    test_type_selection = context.get("test_type_selection", {
        "integration_tests": True,
        "scenario_tests": True
    })

    # 品質ゲート実行
    report_obj, report_text = run_quality_gate_core(
        test_cases_path,
        app_structure_path,
        quality_settings,
        state.logger,
        test_type_selection,
        pattern_type
    )

    # quality_report.mdの保存を無効化
    artifacts_dir = Path(context.get("repo_root", repo_root)) / "app" / "pochi-test-guidelines-artifacts"
    report_path = Path("/dev/null")
    
    # generation_context.jsonを更新
    context["llm_executed"] = True
    context["generation_phase"] = "quality_checked"
    context["quality_report_path"] = str(report_path)
    
    try:
        with open(context_path, 'w', encoding='utf-8') as f:
            json.dump(context, f, indent=2, ensure_ascii=False)
        state.logger.info("generation_context.jsonを更新しました（llm_executed=True）")
    except Exception as e:
        state.logger.error(f"generation_context.jsonの更新に失敗: {e}")
        return 1
    
    # last_run_summary.jsonを最終確定更新
    from datetime import datetime
    state.update_summary({
        "llm_executed": True,
        "quality_gate": {
            "executed": True,
            "passed": report_obj.passed,
            "completed_at": datetime.now().isoformat(),
            "test_case_count": report_obj.test_case_count,
            "target_count": quality_settings.get("calculated_target_total") or quality_settings.get("target_total", 0),
            "perspective_counts": report_obj.perspective_counts,
            "ui_coverage_ratio": report_obj.ui_coverage['covered'] / max(report_obj.ui_coverage['total'], 1) if report_obj.ui_coverage['total'] > 0 else 0,
            "ambiguous_count": report_obj.ambiguous_count,
            "issues_count": len(report_obj.issues),
            "warnings_count": len(report_obj.warnings),
            "report_path": str(report_path)
        }
    })
    state.write_summary()
    
    # コンソール出力
    print("\n" + report_text)
    
    # 終了コード（合格: 0、不合格: 1）
    return 0 if report_obj.passed else 1


if __name__ == "__main__":
    sys.exit(main())
