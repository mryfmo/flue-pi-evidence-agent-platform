"""
Git差分生成モジュール

OS非依存でGit差分を生成し、app/pochi-test-guidelines-artifacts/diffs/に保存する。
bash排除、subprocess使用（shell=False）。
"""
import subprocess
from pathlib import Path
from typing import Tuple, List, Optional

from .state import SkillState


def ensure_generated(state: SkillState, from_ref: Optional[str] = None) -> Tuple[bool, str]:
    """Git差分が生成されていることを確認し、なければ生成
    
    Args:
        state: SkillState インスタンス
        from_ref: 比較元のGit参照（Noneの場合は自動推定）
        
    Returns:
        (成功フラグ, 検出/使用されたベースブランチ)
    """
    logger = state.logger
    diffs_dir = state.get_diffs_dir()
    
    # 既存の差分ファイルをチェック
    if state.check_dir_not_empty(diffs_dir):
        logger.info(f"Existing diffs found: {diffs_dir}")
        # ベースブランチを推定（ファイル名から）
        base_branch = _detect_base_from_files(diffs_dir)
        return True, base_branch
    
    # 差分を生成
    logger.info("No diffs found - generating...")
    
    # from_refの自動推定
    if from_ref is None:
        from_ref = _detect_base_branch(logger)
        logger.info(f"Auto-detected base branch: {from_ref}")
    
    # 差分生成実行
    success, count = _generate_diffs(state, from_ref, "HEAD")
    
    if success and count > 0:
        logger.info(f"Successfully generated {count} diff files")
        return True, from_ref
    elif success and count == 0:
        logger.warning("No changes detected between branches")
        return False, from_ref
    else:
        logger.error("Failed to generate diffs")
        return False, from_ref


def _detect_base_branch(logger) -> str:
    """ベースブランチを自動推定
    
    優先順: origin/main → origin/develop → main → develop → HEAD
    
    Args:
        logger: ロガー
        
    Returns:
        検出されたブランチ名
    """
    candidates = ["origin/main", "origin/develop", "main", "develop"]
    
    for candidate in candidates:
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--verify", candidate],
                capture_output=True,
                text=True,
                check=True,
                timeout=5
            )
            logger.info(f"Base branch detected: {candidate}")
            return candidate
        except subprocess.CalledProcessError:
            continue
        except Exception:
            continue
    
    logger.warning("No standard base branch found - using HEAD")
    return "HEAD"


def _detect_base_from_files(diffs_dir: Path) -> str:
    """差分ファイル名からベースブランチを推定
    
    Args:
        diffs_dir: diffs ディレクトリ
        
    Returns:
        推定されたベースブランチ（不明の場合は"origin/main"）
    """
    # changed_files_{from}_{to}.txt のファイルを探す
    for file in diffs_dir.glob("changed_files_*.txt"):
        parts = file.stem.split("_")
        if len(parts) >= 3:
            # changed_files_origin/main_to_HEAD.txt のようなケース
            # → "origin/main" を抽出したいが、ファイル名では / が _ になっている
            # 簡易的に origin_main があれば origin/main と推定
            from_part = parts[2]
            if from_part == "origin":
                return "origin/main"
            return from_part
    
    return "origin/main"


def _generate_diffs(state: SkillState, from_ref: str, to_ref: str) -> Tuple[bool, int]:
    """Git差分を生成（内部実装）
    
    Args:
        state: SkillState インスタンス
        from_ref: 比較元
        to_ref: 比較先
        
    Returns:
        (成功フラグ, 生成ファイル数)
    """
    logger = state.logger
    diffs_dir = state.get_diffs_dir()
    
    # Git参照の検証
    for ref in [from_ref, to_ref]:
        if not _validate_git_ref(ref, logger):
            logger.error(f"Invalid Git ref: {ref}")
            return False, 0
    
    # 変更ファイルリストを取得
    changed_files = _get_changed_files(from_ref, to_ref, logger)
    
    if not changed_files:
        logger.warning("No changed files detected")
        return True, 0
    
    logger.info(f"Changed files: {len(changed_files)}")
    
    # 変更ファイルリストを保存
    _save_changed_files_list(diffs_dir, from_ref, to_ref, changed_files, logger)
    
    # 各ファイルの差分を生成
    count = 0
    for i, file_path in enumerate(changed_files, 1):
        success = _save_file_diff(diffs_dir, from_ref, to_ref, file_path, logger, i, len(changed_files))
        if success:
            count += 1
    
    logger.info(f"Generated {count} diff files in {diffs_dir}")
    
    return True, count


def _validate_git_ref(ref: str, logger) -> bool:
    """Git参照の妥当性を検証
    
    Args:
        ref: Git参照
        logger: ロガー
        
    Returns:
        有効な場合True
    """
    try:
        subprocess.run(
            ["git", "rev-parse", "--verify", ref],
            capture_output=True,
            text=True,
            check=True,
            timeout=5
        )
        return True
    except Exception as e:
        logger.error(f"Git ref validation failed for {ref}: {e}")
        return False


def _get_changed_files(from_ref: str, to_ref: str, logger) -> List[str]:
    """変更されたファイルのリストを取得
    
    Args:
        from_ref: 比較元
        to_ref: 比較先
        logger: ロガー
        
    Returns:
        変更ファイルパスのリスト
    """
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", f"{from_ref}..{to_ref}"],
            capture_output=True,
            text=True,
            check=True,
            timeout=10
        )
        files = [f.strip() for f in result.stdout.split("\n") if f.strip()]
        return files
    except Exception as e:
        logger.error(f"Failed to get changed files: {e}")
        return []


def _save_changed_files_list(diffs_dir: Path, from_ref: str, to_ref: str, files: List[str], logger) -> None:
    """変更ファイルリストを保存（無効化）

    Args:
        diffs_dir: 出力ディレクトリ
        from_ref: 比較元
        to_ref: 比較先
        files: ファイルリスト
        logger: ロガー
    """
    # ファイル出力を無効化
    pass


def _save_file_diff(diffs_dir: Path, from_ref: str, to_ref: str, file_path: str, logger, index: int, total: int) -> bool:
    """特定ファイルの差分を保存（無効化）

    Args:
        diffs_dir: 出力ディレクトリ
        from_ref: 比較元
        to_ref: 比較先
        file_path: ファイルパス
        logger: ロガー
        index: 現在のインデックス
        total: 総数

    Returns:
        成功した場合True
    """
    # ファイル出力を無効化
    return True
