"""
Pochi Test Orchestrator - Skill Entry Point

スキル起動のメインエントリポイント。
準備フェーズ（Precheck → 差分生成 → パターン判定 → コンテキスト生成）まで実行し、
LLM実行はClaude Codeエージェントに委譲する。
"""
import os
import sys
from pathlib import Path
from typing import Dict

# coreモジュールをインポート
from core.state import SkillState
from core import precheck, diff, orchestrator


def get_test_type_selection() -> Dict[str, bool]:
    """テストタイプ選択を環境変数から取得

    環境変数: POCHI_TEST_TYPE_SELECTION
    - integration_only: 結合テストのみ
    - scenario_only: シナリオテストのみ
    - both: 両方(デフォルト)

    Returns:
        {
            "integration_tests": bool,
            "scenario_tests": bool
        }
    """
    selection_mode = os.environ.get("POCHI_TEST_TYPE_SELECTION", "both")

    valid_modes = ["integration_only", "scenario_only", "both"]
    if selection_mode not in valid_modes:
        print(f"⚠️ 警告: 不正な環境変数値: {selection_mode}. デフォルト(both)を使用します")
        selection_mode = "both"

    if selection_mode == "integration_only":
        return {"integration_tests": True, "scenario_tests": False}
    elif selection_mode == "scenario_only":
        return {"integration_tests": False, "scenario_tests": True}
    else:  # both
        return {"integration_tests": True, "scenario_tests": True}


def get_pochilib_update_info(config: Dict) -> Dict:
    """pochilibアップデート情報（廃止済み - 常にdisabledを返す）

    Args:
        config: 設定ファイルの内容（未使用）

    Returns:
        {"enabled": False}
    """
    return {"enabled": False}


def main():
    """メインエントリポイント
    
    Returns:
        0: 成功
        1: 失敗
    """
    # 1. 環境変数設定（スキル実行中であることを示す）
    os.environ["POCHI_SKILL_ACTIVE"] = "1"
    
    # 2. SkillState初期化
    try:
        state = SkillState()
    except Exception as e:
        print(f"❌ エラー: SkillState初期化失敗: {e}")
        return 1
    
    state.logger.info("=" * 70)
    state.logger.info("Pochi Test Orchestrator - Skill Entry")
    state.logger.info("=" * 70)
    state.logger.info(f"Run ID: {state.run_id}")
    state.logger.info(f"Repository Root: {state.paths['root']}")
    state.logger.info("")

    # 2.5. テストタイプ選択
    test_type_selection = get_test_type_selection()
    state.set_test_type_selection(test_type_selection)
    state.logger.info(f"テストタイプ選択: {test_type_selection}")
    state.logger.info("")

    # 3. Precheck（環境チェック）
    state.logger.info("[1/5] 環境チェックを実行中...")
    if not precheck.run(state):
        state.logger.error("環境チェックに失敗しました")
        state.update_summary({
            "phase": "precheck_failed",
            "status": "failed"
        })
        state.write_summary()
        return 1
    
    state.logger.info("✅ 環境チェック完了")
    state.logger.info("")
    
    # 4. 差分生成確認
    state.logger.info("[2/5] 差分ファイルの確認・生成中...")
    has_diffs, base_branch = diff.ensure_generated(state)
    
    if has_diffs:
        state.logger.info(f"✅ 差分ファイルを確認しました（ベースブランチ: {base_branch}）")
    else:
        state.logger.info("✅ 差分なし（Pattern1またはPattern4として処理）")
    state.logger.info("")
    
    # 5. パターン判定
    state.logger.info("[3/5] パターンを判定中...")
    pattern, details = orchestrator.detect_pattern(state)
    
    state.logger.info(f"✅ パターン判定完了: {pattern.value}")
    state.logger.info(f"   詳細: {details}")
    state.logger.info("")
    
    # 6. 前提生成（app_structure.md等）
    state.logger.info("[4/5] 前提ファイルを生成中...")
    if not orchestrator.prepare_prerequisites(pattern, state):
        state.logger.error("前提ファイルの生成に失敗しました")
        state.update_summary({
            "phase": "prerequisites_failed",
            "pattern": pattern.value,
            "status": "failed"
        })
        state.write_summary()
        return 1
    
    state.logger.info("✅ 前提ファイル生成完了")
    state.logger.info("")
    
    # 7. generation_context.json生成
    state.logger.info("[5/5] コンテキストファイルを生成中...")
    try:
        context = orchestrator.prepare_generation_context(pattern, state, base_branch, details)
        state.logger.info("✅ コンテキストファイル生成完了")
        state.logger.info(f"   generation_context.json: {context['prompts_path'].replace('prompts_last_run.md', 'generation_context.json')}")
        state.logger.info(f"   prompts_last_run.md: {context['prompts_path']}")
        state.logger.info(f"   パターン選択方法: {details.get('selection_method', 'unknown')}")
    except Exception as e:
        state.logger.error(f"コンテキストファイルの生成に失敗: {e}")
        state.update_summary({
            "phase": "context_generation_failed",
            "pattern": pattern.value,
            "status": "failed",
            "error": str(e)
        })
        state.write_summary()
        return 1
    
    state.logger.info("")
    
    # 8. サマリ更新
    state.update_summary({
        "phase": "preparation_complete",
        "pattern": pattern.value,
        "base_branch": base_branch,
        "has_diffs": has_diffs,
        "llm_executed": False,
        "status": "ready_for_agent",
        "next_action": "Agent should read prompts_last_run.md and generate test_cases.md using the instructions",
        "context_file": str(state.paths["artifacts"] / "generation_context.json"),
        "prompts_file": context['prompts_path'],
        "quality_gate_entry": context['quality_gate_entry']
    })
    state.write_summary()
    
    # 9. 完了メッセージ
    state.logger.info("=" * 70)
    state.logger.info("✅ 準備フェーズ完了 - Claude Codeエージェント準備完了")
    state.logger.info("=" * 70)
    state.logger.info("")
    state.logger.info("📋 次のステップ（エージェント向け）:")
    state.logger.info("")
    state.logger.info("1. 以下のファイルをJSONとして読み込んでください:")
    state.logger.info(f"   {state.paths['artifacts'] / 'generation_context.json'}")
    state.logger.info("")
    state.logger.info("2. reference_files[]内の各絶対パスを順番に開いて内容を確認してください")
    state.logger.info("")
    state.logger.info("3. prompts_path で指定されたファイルを開き、指示に従ってtest_cases.mdを生成してください:")
    state.logger.info(f"   {context['prompts_path']}")
    state.logger.info("")
    state.logger.info("4. test_cases.md生成後、以下のコマンドを実行してください:")
    state.logger.info(f"   {context['quality_gate_entry']}")
    state.logger.info("")
    state.logger.info("5. 品質ゲートが終了コード0で完了すれば、タスク完了です")
    state.logger.info("")
    state.logger.info("=" * 70)
    state.logger.info(f"📊 実行サマリ: {state.paths['artifacts'] / 'last_run_summary.json'}")
    state.logger.info(f"📝 実行ログ: {state.paths['logs'] / f'skill_run_{state.run_id}.log'}")
    state.logger.info("=" * 70)

    # 既存のtest_cases.md（統合版）が存在する場合の通知
    legacy_path = state.get_artifact_path("test_cases.md")
    if legacy_path.exists():
        state.logger.warning("")
        state.logger.warning("=" * 70)
        state.logger.warning("⚠️  既存のtest_cases.md（統合版）が検出されました")
        state.logger.warning("新しいファイル分離方式では以下のファイル名を使用します：")
        state.logger.warning("  - test_cases_integration.md（結合テスト）")
        state.logger.warning("  - test_cases_scenario.md（シナリオテスト）")
        state.logger.warning("既存のtest_cases.mdは手動でバックアップまたは削除してください")
        state.logger.warning("=" * 70)
        state.logger.warning("")

    return 0


if __name__ == "__main__":
    sys.exit(main())
