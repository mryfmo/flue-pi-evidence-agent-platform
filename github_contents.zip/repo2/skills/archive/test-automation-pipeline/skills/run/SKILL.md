---
name: test-automation-pipeline
description: git差分からテスト計画・実装・実行・失敗分析を自動実行するパイプラインSkill。「テスト自動化パイプラインを実行して」「git差分からテストを生成・実行」「test-automation-pipelineを起動」「新規実装のテストを全自動化」「プッシュ前の包括的テスト」「変更内容を自動テスト」「新機能のテスト自動化ワークフロー」と言われたときに使用する。
---

> [!WARNING]
> **このスキルは廃止されました。**
> 後継スキル: `pochi-unit-test-generator` + `pochi-integration-test-designer/generator`
> このスキルは何も実行せずに終了します。後継スキルのトリガーフレーズを入力してください。

このスキルは廃止済みのため、**何も実行しません。**

後継スキル **`pochi-unit-test-generator` + `pochi-integration-test-designer/generator`** を使用してください。


# Skill: Test Automation Pipeline

## Trigger Phrases

- 「テスト自動化パイプラインを実行して」
- 「git差分からテストを生成・実行」
- 「test-automation-pipelineを起動」
- 「新規実装のテストを全自動化」
- 「プッシュ前の包括的テスト」
- 「変更内容を自動テスト」
- 「新機能のテスト自動化ワークフロー」

## When

以下の状況でこのSkillを使用する：

- git差分からテスト計画・実装・実行・失敗分析を自動化したいとき
- プッシュ前に包括的なテストを実行したいとき
- 新機能実装後にテストを自動生成・実行したいとき
- CI/CDパイプラインの一部としてテスト自動化を実施したいとき

## Do

以下のフローを実行する：

1. **前確認**: git差分とディレクトリ準備
2. **チーム作成**: TeamCreate でエージェントチームを作成し、4タスクを登録
3. **Planner起動**: test-planner チームメンバーを起動してテスト計画書作成（完了待ち）
4. **Author起動**: test-author チームメンバーを起動してテストコード実装（完了待ち）
5. **Runner起動**: test-runner チームメンバーを起動してテスト実行・レポート作成（完了待ち）
6. **Triage起動**: 失敗がある場合のみ test-triage チームメンバーを起動して失敗分析（完了待ち）
7. **シャットダウン**: 全メンバーにシャットダウン要求を送信し TeamDelete でクリーンアップ
8. **最終レポート**: 全フェーズの成果物を統合してユーザーに報告

## Instructions

### 概要

このSkillは4つの専門エージェント（test-planner / test-author / test-runner / test-triage）を
**エージェントチーム方式（TeamCreate）**で順序実行し、テスト自動化パイプラインを実行します。

リーダー（メインセッション）が TeamCreate でチームを作成し、TaskCreate でタスクを登録した後、
各チームメンバーを foreground（完了待ち）で順序起動します。
これにより、Planner → Author → Runner → Triage の順序依存関係を確実に保証します。

### 前提条件

- `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` が有効になっていること（settings.local.json に設定済み）

### 詳細な実行手順

#### Step 0: 実行前確認

```
実行前に以下を確認してください：
1. 現在のgitブランチとステータス
2. 変更済みファイルの有無
3. tests/ ディレクトリの存在
4. output/ ディレクトリの準備
```

Bash ツールで以下を実行：
```bash
# git ステータス確認
git status
git diff --name-only HEAD~1 HEAD 2>/dev/null || git diff --name-only HEAD

# output ディレクトリの準備
mkdir -p output
```

#### Step 1: エージェントチームの作成

TeamCreate ツールでチームを作成する：

```
TeamCreate:
  team_name: "test-automation-pipeline"
  description: "テスト自動化パイプライン：Planner→Author→Runner→Triage の順序実行"
```

#### Step 2: タスクの作成（依存関係付き）

TaskCreate ツールで4つのタスクを作成する。
タスク2以降は前のタスクの ID を `addBlockedBy` で指定して依存関係を設定する。

```
タスク1: TaskCreate
  subject: "テスト計画書の作成"
  description: |
    git diff --name-only で変更ファイルを特定し、各ファイルの内容を確認する。
    テストケース一覧（正常系・異常系・境界値、10〜30件目標）を生成し、
    テスト種別（Unit/Integration/E2E/Snowflake）と優先度（P0/P1/P2）を付与して
    output/test-plan.md に書き出す。

タスク2: TaskCreate
  subject: "テストコードの実装"
  description: |
    output/test-plan.md のテスト計画書を読み込み、計画書の全テストケースを
    pytestコードとして実装する（AAAパターン・命名規則・モック戦略を遵守）。
    テストファイルを tests/ に書き出す。
  ※ タスク1のIDを addBlockedBy に設定

タスク3: TaskCreate
  subject: "テストの実行とレポート作成"
  description: |
    3段階のテスト実行（新規のみ→全体スイート→カバレッジ測定）を行い、
    各ログを output/results_phase*.log に保存する。
    output/test-report.md に構造化レポートを作成し、失敗テスト件数を明記する。
  ※ タスク2のIDを addBlockedBy に設定

タスク4: TaskCreate
  subject: "失敗テストのトリアージ（失敗ありの場合のみ）"
  description: |
    output/test-report.md から失敗テスト一覧を読み込み、スタックトレースを確認して
    テスト側/プロダクション側の切り分けを行う。
    優先度付き（P0/P1/P2）修正提案を output/triage-report.md に出力する。
  ※ タスク3のIDを addBlockedBy に設定
```

#### Step 3: test-planner チームメンバーの起動

Agent ツールで test-planner チームメンバーを **foreground** で起動し、完了を待つ：

```
subagent_type: "test-planner"
prompt: |
  あなたは test-automation-pipeline チームの test-planner です。

  タスク一覧を TaskList で確認し、「テスト計画書の作成」タスクを TaskUpdate で
  自分のもの（owner: "test-planner"）としてクレームし、status を in_progress に更新してください。

  実行内容：
  1. git diff --name-only HEAD~1 HEAD で変更ファイルを特定
  2. 各変更ファイルの内容を確認（Streamlit UI/Snowflakeクエリ/LLM呼び出し）
  3. tests/ ディレクトリの既存テストカバー状況を確認
  4. テストケース一覧を正常系・異常系・境界値で生成（10〜30件目標）
  5. テスト種別（Unit/Integration/E2E/Snowflake）と優先度（P0/P1/P2）を付与
  6. output/test-plan.md に計画書を書き出す

  完了後、TaskUpdate でタスクを completed に更新してから、
  SendMessage でリーダーに完了を報告してください。
  最後に、shutdown_request が届いたら shutdown_response で承認してシャットダウンしてください。
```

完了通知を受け取ったら、`output/test-plan.md` が作成されたことを Read ツールで確認する。

#### Step 4: test-author チームメンバーの起動

test-planner の完了確認後、Agent ツールで test-author チームメンバーを **foreground** で起動し、完了を待つ：

```
subagent_type: "test-author"
prompt: |
  あなたは test-automation-pipeline チームの test-author です。

  タスク一覧を TaskList で確認し、「テストコードの実装」タスクを TaskUpdate で
  自分のもの（owner: "test-author"）としてクレームし、status を in_progress に更新してください。

  実行内容：
  1. output/test-plan.md のテスト計画書を読み込む
  2. tests/ ディレクトリ構造と既存テストパターンを確認
  3. conftest.py の共通フィクスチャを確認（なければ作成）
  4. 計画書の全テストケースをpytestコードとして実装
  5. AAAパターン・命名規則・モック戦略（Snowflake/LLM/session_state）を遵守
  6. テストファイルを tests/ に書き出す

  完了後、TaskUpdate でタスクを completed に更新してから、
  SendMessage でリーダーに完了を報告してください。
  最後に、shutdown_request が届いたら shutdown_response で承認してシャットダウンしてください。
```

完了通知を受け取ったら、`tests/test_*.py` が作成されたことを Glob ツールで確認する。

#### Step 5: test-runner チームメンバーの起動

test-author の完了確認後、Agent ツールで test-runner チームメンバーを **foreground** で起動し、完了を待つ：

```
subagent_type: "test-runner"
prompt: |
  あなたは test-automation-pipeline チームの test-runner です。

  タスク一覧を TaskList で確認し、「テストの実行とレポート作成」タスクを TaskUpdate で
  自分のもの（owner: "test-runner"）としてクレームし、status を in_progress に更新してください。

  実行内容：
  1. Phase 1: 新規テストファイルのみ実行
     pytest <新規テストファイル> -v --tb=short 2>&1 | tee output/results_phase1.log
  2. Phase 2: 全体スイート実行
     pytest tests/ -v --tb=short 2>&1 | tee output/results_phase2.log
  3. Phase 3: カバレッジ測定
     pytest tests/ --cov=app --cov-report=json --cov-report=term-missing 2>&1 | tee output/results_phase3.log
  4. output/test-report.md に構造化レポートを作成
  5. 失敗テスト件数を明確に報告する

  完了後、TaskUpdate でタスクを completed に更新してから、
  SendMessage でリーダーに完了を報告してください（失敗テスト件数を必ず含める）。
  最後に、shutdown_request が届いたら shutdown_response で承認してシャットダウンしてください。
```

完了通知を受け取ったら、`output/test-report.md` を Read ツールで読み込み、失敗テスト件数を確認する。

#### Step 6: test-triage チームメンバーの起動（条件付き）

`output/test-report.md` を確認し、**失敗テストが1件以上ある場合のみ** test-triage を起動する。

失敗テストが0件の場合はこのステップをスキップする。

```
subagent_type: "test-triage"
prompt: |
  あなたは test-automation-pipeline チームの test-triage です。

  タスク一覧を TaskList で確認し、「失敗テストのトリアージ」タスクを TaskUpdate で
  自分のもの（owner: "test-triage"）としてクレームし、status を in_progress に更新してください。

  実行内容：
  1. output/test-report.md から失敗テスト一覧を読み込む
  2. output/results_phase1.log, output/results_phase2.log のスタックトレースを確認
  3. 各失敗テストについてテスト側/プロダクト側の切り分けを行う
  4. 優先度付き（P0/P1/P2）修正提案を作成
  5. output/triage-report.md にトリアージレポートを出力

  完了後、TaskUpdate でタスクを completed に更新してから、
  SendMessage でリーダーに完了を報告してください。
  最後に、shutdown_request が届いたら shutdown_response で承認してシャットダウンしてください。
```

#### Step 7: シャットダウンとクリーンアップ

全チームメンバーの完了後、SendMessage でシャットダウン要求を送信し、TeamDelete でチームを削除する：

```
# 全メンバーにシャットダウン要求を送信
SendMessage:
  to: "*"
  message:
    type: "shutdown_request"
    reason: "全タスク完了。シャットダウンしてください。"

# シャットダウン応答を待った後、チームを削除
TeamDelete
```

#### Step 8: 最終レポート作成

全チームメンバーの完了後、以下の情報を統合してユーザーに報告する：

```markdown
## テスト自動化パイプライン 実行結果

### 実行サマリ

| フェーズ | 状態 | 成果物 |
|---|---|---|
| test-planner | ✅ 完了 | output/test-plan.md |
| test-author | ✅ 完了 | tests/test_xxx.py |
| test-runner | ✅ 完了 | output/test-report.md |
| test-triage | ✅ 完了 / ⏭️ スキップ（失敗0件） | output/triage-report.md |

### テスト実行結果

- **成功**: X 件 ✅
- **失敗**: X 件 ❌
- **カバレッジ**: XX%

### 次のアクション

[失敗がある場合] output/triage-report.md の修正提案を参照してください
[失敗がない場合] テストが全件成功しました。プッシュ準備完了です
```

---

## 出力ファイル一覧

| ファイル | 作成者 | 内容 |
|---|---|---|
| `output/test-plan.md` | test-planner | テスト計画書 |
| `tests/test_*.py` | test-author | pytestテストコード |
| `output/results_phase1.log` | test-runner | Phase1実行ログ |
| `output/results_phase2.log` | test-runner | Phase2実行ログ |
| `output/results_phase3.log` | test-runner | Phase3カバレッジログ |
| `output/test-report.md` | test-runner | 構造化テスト実行レポート |
| `output/triage-report.md` | test-triage | 失敗分析・修正提案レポート（失敗がある場合のみ） |

---

## 既存Skillとの役割分担

| Skill/Agent | 入力 | 出力 | 用途 |
|---|---|---|---|
| `pochi-test-orchestrator`（既存） | 開発内容の説明文 | 4パターンのテストケース（テキスト） | 手動テストケース設計 |
| `test-case-specialist`（既存Agent） | 実装ファイル | 80〜110件のテストケース（テキスト） | 包括的テスト設計 |
| `test-automation-pipeline`（**本Skill**） | git差分（自動解析） | pytest実行可能コード + 実行結果 + 失敗分析 | CI/CD自動化 |
