---
name: view-migration-planner
description: >-
  SnowflakeのVIEW廃止対応を調査・分析・計画書生成まで一貫して行うスキル。
  summary-reportを読み込み対応方針を分類した後、廃止VIEWと代替VIEWの両方に対して
  Snowflakeで SHOW COLUMNS / DESCRIBE を実行し、カラム差分（削除・追加・型変更・リネーム候補）を分析する。
  代替VIEWが未定の分類BのVIEWに対しては、3層フィルタリング（スキーマ絞込・名前マッチ・カラム類似度）で
  代替VIEW候補をSnowflakeから自動探索する。
  分析結果をview-migration-knowledge.md（ナレッジ）・db-changes.md（db-impact-analyzer入力）・
  migration-plan.md（優先度別タスクリスト）の3ファイルに出力する。
  「VIEW移行計画を立てて」「廃止VIEW対応を自動化して」「view-migration-plannerを起動」
  「代替VIEWのカラム差分を調査して」「移行計画書を作成して」と言われたときに使用する。
---

# view-migration-planner — VIEW移行調査・計画生成スキル

## 役割

Snowflake VIEW廃止対応を **調査から計画書生成まで** 一貫して行うスキル。

```
[入力] summary-report_YYYYMMDD.md
         ↓ 手順1: summary-report 解析・分類
         ↓ 手順2-A: 分類A → 廃止VIEW・代替VIEW 両方のカラム取得
         ↓ 手順2-B: 分類B → 廃止VIEWのカラム取得 + 代替VIEW候補を3層フィルタで自動探索
         ↓ 手順3: カラム差分を分析（削除/追加/型変更/リネーム候補）
         ↓ 手順4: 3ファイルを生成
[出力 1] view-migration-knowledge.md  ← カラム差分・代替候補を含む移行ナレッジ
[出力 2] db-changes.md                ← db-impact-analyzer への入力
[出力 3] migration-plan_{日付}.md     ← アプリ別・優先度別タスクリスト
```

---

## 実行手順

### 手順0: 入力ファイルの確認

入力となる summary-report ファイルを特定し、ユーザーに確認する。

**優先順位でファイルを探す:**
1. ユーザーが指定したパス
2. `plan/ALADIN-WDH/summary-report_*.md`（最新日付を自動選択）
3. カレントディレクトリ直下の `summary-report_*.md`

複数ファイルがある場合はファイル名の `_YYYYMMDD` が最新のものを使用。

```
確認: 以下のファイルを使用します。よろしいですか？
  - {ファイルパス}（{行数}行）
出力先ディレクトリ: {入力ファイルと同じディレクトリ}/
```

---

### 手順1: summary-report の解析・分類

入力ファイルを全行読み込み、各VIEWエントリを以下の5分類に振り分ける。

#### 1-1. 抽出する列

| 列名 | 用途 |
|------|------|
| App / アプリ名 / リポジトリ | アプリ特定 |
| 判断 | 🔴/🟠/🔵/🟢 |
| VIEW名 | 廃止対象VIEW（バッククォート内） |
| 対応方針 | 分類の根拠 |
| 削除期限 | タスク優先度 |
| 移行先VIEW | 代替VIEW名（Snowflake調査の対象） |

#### 1-2. 5分類ルール

| 分類 | 判定条件 | Snowflake調査 | db-changes.md |
|------|---------|--------------|--------------|
| **A: 代替有り移行** | 対応方針に「削除(代替有り)」 かつ 移行先VIEWが明記されている | ✅ 廃止・代替 両方 | ✅ 要対応セクション |
| **B: 代替未定** | 「残留(リファクタ有り)」「断捨離」「検討中」「残留(方針検討中)」「個別マスタ別途」「リファクタ(ALADIN)」「VIEW統合」「廃止」等 | ✅ 廃止VIEWのみ + **3層フィルタで代替候補自動探索** | ✅ 別管理セクション |
| **C: 緊急（代替なし）** | 「削除(代替無し)」または「dMC廃止」かつ本番コード使用 | ❌ 代替がないため省略 | ✅ 緊急セクション |
| **D: コード削除のみ** | 判断🟢 かつ「dMC廃止」でコード削除記述あり | ❌ 不要 | ✅ 削除セクション |
| **E: 継続提供** | 「継続提供」または備考に「★継続提供」 | ❌ 不要 | ❌ 除外 |

分類が終わったら件数をユーザーに報告してから次へ進む:
```
解析完了:
  A（代替有り移行）: {件数}件 → Snowflakeで両VIEW調査
  B（代替未定）:     {件数}件 → 廃止VIEWのみ調査 + 代替候補を自動探索
  C（緊急・代替なし）:{件数}件 → 調査省略
  D（コード削除のみ）:{件数}件 → 調査省略
  E（継続提供）:     {件数}件 → 除外
  重複排除後の調査VIEW数: {件数}件（廃止VIEW）+ {件数}件（代替VIEW）
```

#### 1-3. 英語→日本語変換辞書の構築

分類Aの既知ペア（廃止VIEW名 → 代替VIEW名）を解析し、後の代替候補探索で使う変換辞書を作る。
分類Aのペアが少ない・0件の場合でもLayer 1が機能するよう、以下の**初期辞書**をデフォルトとして組み込む。

**初期辞書（分類Aの学習結果で上書き・補完される）:**

| 英語キーワード | 日本語候補 |
|-------------|----------|
| `CONTRACT` | 契約 |
| `BASIC_CONTRACT` | 契約基本 |
| `MASTER` | マスタ |
| `SALES` | 販売 |
| `SALES_MANAGEMENT` | 販売管理 |
| `SALESOUTLET` | 販売拠点 |
| `CUSTOMER` | 顧客 |
| `ACCOUNT` | 口座 / アカウント |
| `PAYMENT` | 支払 |
| `BILLING` | 請求 |
| `ORDER` | 注文 / オーダー |
| `PRODUCT` | 商品 / プロダクト |
| `SERVICE` | サービス |
| `USER` | ユーザー |
| `HISTORY` | 履歴 |
| `SUMMARY` | サマリ / 集計 |
| `DAILY` | 日次 |
| `MONTHLY` | 月次 |
| `STATUS` | ステータス / 状態 |
| `MANAGEMENT` | 管理 |
| `RESULT` | 実績 |
| `PLAN` | 計画 |
| `DEVICE` | 端末 / デバイス |
| `LINE` | 回線 |
| `MOBILE` | 携帯 |
| `FIXED` | 固定 |

**プレフィックス/サフィックス対応（初期値）:**

| パターン | 意味 |
|---------|------|
| `DNCD` | 日次（データ種別コード） |
| `MECD` | 月末（データ種別コード） |
| `MB` | （省略されることが多い、スコアリング時は無視可） |
| `_V2` / `_NEW` | バージョン違い（同一ドメイン扱い） |

**辞書の更新ルール:**
- 分類Aの既知ペアから学習した結果が初期辞書と競合する場合、**学習結果を優先**する
- 初期辞書に無いキーワードが分類Aから学習された場合、**辞書に追加**される

**学習例:**
```
分類Aの既知ペア:
  VW_ADM_DNCD_BASIC_CONTRACT_MB → VW_DSC_DNCD_携帯-契約基本
  → BASIC_CONTRACT = 契約基本（初期辞書と一致、学習確認）
  → MB = （省略。初期辞書と一致）

  VW_ADW_MECD_BASIC_CONTRACT_MB → VW_DSC_MECD_携帯-契約基本-月末
  → MECD = 月末（初期辞書と一致、学習確認）
```

これにより、分類Aの既知ペアが多いほど辞書が充実し、分類Bの探索精度が向上する。
---

### 手順2-A: 分類A — 廃止VIEW・代替VIEW のカラム取得

分類AのVIEWペアについて、廃止VIEW・代替VIEW の両方のカラム情報を取得する。

#### Pythonスクリプト（一時作成・実行後削除）

```python
# /tmp/view_schema_fetcher.py
import json
import sys
from pochilib.snowflake import generate_pochi_snowflake_connector

VIEW_LIST = json.loads(sys.argv[1])  # フルパスのVIEW名リスト

psc = generate_pochi_snowflake_connector()
results = {}

with psc.connect() as cnx:
    for view_full_name in VIEW_LIST:
        try:
            res = cnx.get_records_and_fetchall(
                f"SHOW COLUMNS IN VIEW {view_full_name};"
            )
            df = res.to_pandas()
            results[view_full_name] = [
                {
                    "column_name": row["column_name"],
                    "data_type": row["data_type"],   # JSON文字列で型情報が入る
                    "null?": row.get("null?", "Y"),
                    "comment": row.get("comment", ""),
                }
                for _, row in df.iterrows()
            ]
        except Exception as e:
            results[view_full_name] = {"error": str(e)}

print(json.dumps(results, ensure_ascii=False, indent=2))
```

**実行コマンド:**
```bash
cd /home/user/{任意のpochiアプリディレクトリ}
poetry run python /tmp/view_schema_fetcher.py '["{DB}.{SCHEMA}.{VIEW_NAME}", ...]'
```

#### VIEWのフルパス解決

summary-report の VIEW名はスキーマ修飾なし（例: `VW_ADM_DNCD_BASIC_CONTRACT_MB`）のことが多い。
以下のルールでフルパスを解決する:

| VIEW名のプレフィックス | 推定DB・スキーマ |
|----------------------|---------------|
| `VW_ADM_` | `PROCDB_B_P01_LAK.D_MR_000` |
| `VW_ADW_` | `PROCDB_B_P01_LAK.D_MR_000` |
| `VW_DIC_` | `PROCDB_B_P01_LAK.D_MR_000` |
| `VW_HMD_` | `PROCDB_B_P01_LAK.D_MR_000` |
| `VW_PGN_` | `PROCDB_B_P01_LAK.D_MR_000` |
| `VW_DTT_` | `PROCDB_B_P01_LAK.D_MR_000` |
| `VW_DSH_` | `PROCDB_B_P01_LAK.D_MR_000` |
| `VW_DMC_` | `PROCDB_B_P01_LAK.D_MC_000`（dMC廃止対象） |
| `VUSER_`  | `PROCDB_B_P01_LAK.D_MC_000`（dMC廃止対象） |
| 代替VIEW `VW_DSC_` | `PROCDB_B_P01_LAK.D_CM_000` |
| 代替VIEW `VW_DIC_` (新設) | `PROCDB_B_P01_LAK.D_MR_000_CK` |
| 代替VIEW `VW_PGN_DNHL_` | `PROCDB_B_P01_LAK.L_MR_000` |

> **解決できない場合**: `SHOW TERSE VIEWS LIKE '%{VIEW_NAME}%' IN DATABASE PROCDB_B_P01_LAK;` で検索する。

#### エラー処理

- `SQL compilation error` (VIEW が存在しない) → すでに廃止済み。その旨をナレッジに記録。
- `Insufficient privileges` → 権限不足。ユーザーに確認を求める。
- その他のエラー → エラー内容をそのままナレッジの「カラム差分」欄に記録し、調査継続。

---

### 手順2-B: 分類B — 廃止VIEWのカラム取得 + 代替VIEW候補の自動探索

代替VIEWが未定の分類Bについて、2つの作業を並行して行う:

1. 廃止VIEWのカラム構成を取得（手順2-Aと同じスクリプトを使用）
2. Snowflakeを3層フィルタリングで横断検索し、代替VIEW候補を自動発見する

---

#### Layer 1: スキーマ絞込 + 名前ベース候補抽出（高速・広範囲）

**目的**: 全VIEWの総当たりを避け、代替候補を数十件に絞る。

##### 1-1. 探索対象スキーマを限定する

廃止VIEWが置かれているスキーマと、代替VIEWが配置される既知の移行先スキーマをマッピング:

| 廃止VIEW所在スキーマ | 探索対象スキーマ（候補） |
|--------------------|----------------------|
| `D_MR_000`（VW_ADM_ / VW_ADW_ / VW_DIC_ / VW_HMD_ / VW_PGN_ 等） | `D_CM_000`, `D_MR_000_CK`, `L_MR_000` |
| `D_MC_000`（VW_DMC_ / VUSER_ 等） | `D_CM_000`, `D_MR_000` |

**Snowflakeで各スキーマのVIEW一覧を一括取得（カラムはまだ取得しない）:**
```sql
SHOW TERSE VIEWS IN SCHEMA PROCDB_B_P01_LAK.D_CM_000;
SHOW TERSE VIEWS IN SCHEMA PROCDB_B_P01_LAK.D_MR_000_CK;
SHOW TERSE VIEWS IN SCHEMA PROCDB_B_P01_LAK.L_MR_000;
```

##### 1-2. 名前ベースでスコアリングし候補を絞る

廃止VIEW名からビジネスドメインキーワードを抽出し、取得したVIEW名一覧とマッチング:

```
廃止VIEW例: VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER

キーワード抽出:
  - データ種別コード: DNCD
  - ビジネス用語: SALES_MANAGEMENT, SALESOUTLET, MASTER
  - 辞書変換後: 販売管理, 販売拠点, マスタ
```

**スコアリングルール:**

| マッチ条件 | スコア | 例 |
|-----------|--------|---|
| データ種別コード完全一致（DNCD/MECD等） | +30 | `VW_DSC_DNCD_...` ← DNCD一致 |
| 辞書変換後の日本語キーワード一致 | +20/語 | `販売拠点` ← SALESOUTLET変換 |
| 英語キーワードの部分文字列一致 | +10 | `SALES_MANAGEMENT` ⊂ VIEW名 |
| 既知の廃止→代替プレフィックス対応 | +15 | `VW_HMD_` → `VW_DSC_` は既知パターン |

**閾値**: スコア **40以上** の候補をLayer 2へ進める（それ以外は除外）。

---

#### Layer 2: カラムフィンガープリント照合（中速・精度向上）

**目的**: Layer 1の候補（数件〜数十件）に対してのみ `SHOW COLUMNS` を実行し、カラム類似度で精度を上げる。

##### 2-1. 候補VIEWのカラムを一括取得

Layer 1でスコア40以上になった候補VIEWのフルパスリストを作り、手順2-Aと同じスクリプトでまとめて `SHOW COLUMNS` を実行する。

##### 2-2. カラム類似度スコアの計算

カラムを2種類に分類して重み付きスコアを計算する:

**汎用カラム（重み 0.5）** — 以下のパターンに該当するもの:
- 完全一致: `ID`, `NAME`, `CODE`, `STATUS`, `FLAG`, `TYPE`, `CATEGORY`, `CREATE_TS`, `UPDATE_TS`, `DELETE_TS`, `CREATED_AT`, `UPDATED_AT`, `INSERT_DATE`, `UPDATE_DATE`, `DELETE_DATE`, `CREATED_BY`, `UPDATED_BY`, `IS_DELETED`, `IS_ACTIVE`, `VALID_FROM`, `VALID_TO`, `START_DATE`, `END_DATE`, `RECORD_ID`, `ROW_NUMBER`, `SEQ_NO`, `SORT_ORDER`, `REMARKS`, `NOTES`, `COMMENT`, `DESCRIPTION`（必要に応じて追加可能）
- サフィックス一致: `*_ID`, `*_CD`, `*_FLG`, `*_FLAG`, `*_KBN`, `*_TIMESTAMP`, `*_TS`, `*_DATE`, `*_YMD`, `*_BY`, `*_USER`、および先頭にドメイン語を含まない `*_NAME`

**ドメインカラム（重み 1.0）** — 上記に該当しないもの

```
重み付きカバー率 = Σ(一致カラムの重み) / Σ(廃止VIEWの全カラムの重み)
重み付き余剰率  = Σ(余剰カラムの重み) / Σ(候補VIEWの全カラムの重み)
類似度スコア    = 重み付きカバー率 × 0.7 + (1 - 重み付き余剰率) × 0.3
```

**追加条件（スコアを下げる/除外する）:**
- ドメインカラムの一致が0件の場合 → スコアに関わらず **✗除外**（汎用カラムのみの一致は不可）
- `|候補VIEWカラム数 / 廃止VIEWカラム数| > 5` の場合 → 類似度スコアに **×0.8** を乗算する

**判定例（汎用カラムのみ一致 → 除外）:**
```
廃止VIEW: [USER_ID, CONTRACT_ID, STATUS, CREATE_TS, UPDATE_TS]  (5カラム)
候補VIEW: [USER_ID, ORDER_ID, STATUS, CREATE_TS, UPDATE_TS]     (5カラム)

一致: USER_ID（汎用）, STATUS（汎用）, CREATE_TS（汎用）, UPDATE_TS（汎用）
ドメイン一致: 0件 → CONTRACT_ID と ORDER_ID は不一致（ドメインカラム）

→ ドメインカラムの一致0件 → ✗除外（スコア計算せず除外）
```

##### 2-3. 判定基準

| 類似度スコア | 判定 | アクション |
|------------|------|----------|
| 0.8 以上 | ★ 強候補 | 「代替VIEW候補（高確度）」としてknowledge・migration-planに記載。手順3のカラム差分分析を実施する |
| 0.5 〜 0.8 | △ 参考候補 | 「代替VIEW候補（要確認）」としてknowledgeに記載。カラム差分分析も実施して人間に判断を委ねる |
| 0.5 未満 | ✗ 除外 | 候補から除外 |

---

#### Layer 3: ユーザー確認 + 差分分析

Layer 2で★強候補が見つかった場合、手順3のカラム差分分析ロジックをそのまま適用する。
△参考候補も差分分析を実施し、「要確認」フラグを付けてナレッジに記録する。

候補が1件も見つからなかった場合は「代替VIEW未発見」としてナレッジに記録し、人間による調査が必要であることを明示する。

---

### 手順3: カラム差分の分析

手順2で取得した廃止VIEWと代替VIEWのカラム情報を比較し、差分を分析する。
分類Aは確定済み代替VIEWと、分類Bは自動探索で見つかった代替VIEW候補（★/△）と比較する。

#### 3-1. 差分の判定ルール

| 差分種別 | 判定条件 | コード修正の必要性 |
|---------|---------|----------------|
| **削除カラム** | 廃止VIEWにあって代替VIEWにない | ⚠️ 高 — SQLから該当カラムの参照を削除または代替カラムに置換 |
| **追加カラム** | 代替VIEWにあって廃止VIEWにない | ℹ️ 低 — 活用可能だが既存クエリには影響しない |
| **型変更** | 同名カラムで `data_type` が異なる | ⚠️ 中 — キャスト・比較式が壊れる可能性あり |
| **リネーム候補** | 削除カラムと追加カラムの名前が部分一致または意味的に近い | ⚠️ 中 — 手動確認が必要 |
| **NULL制約変更** | `null?` フィールドが Y→N に変化 | ⚠️ 中 — NULL値をそのまま渡すとエラーになる可能性 |

#### 3-2. リネーム候補の推定ロジック

リネーム候補の判定は以下の3ルールを**優先度順**に適用する（上位ルールで判定済みのペアは下位ルールの対象から除外）。

**ルール3（最優先）: 既知の対応関係**
手順1-3で構築した辞書に含まれるカラム名対応があればリネーム候補とする。
例: `COMNID` ↔ `ACCTID`（辞書に登録済みの既知対応）

**ルール2: サフィックス除去後の完全一致**
`_MB`, `_CD`, `_CODE`, `_FLG`, `_FLAG`, `_KBN`, `_TYPE`, `_V2`, `_NEW` を除去して比較し、除去後に完全一致すればリネーム候補とする。

```
通過例:
  COMNID_MB → _MB除去 → COMNID = COMNID ✓
  CONTRACT_CD → _CD除去 → CONTRACT = CONTRACT ✓

除外例:
  SALES_AMOUNT_CD → _CD除去 → SALES_AMOUNT ≠ SALES_TARGET ✗
```

**ルール1: 文字列類似度の閾値（最後の判定）**
一致文字数 / min(カラム名Aの文字数, カラム名Bの文字数) > 0.6 の場合にリネーム候補とする。
（閾値0.6は調整可能）

```
通過例:
  CONTRACT_ID(11文字) vs CONTRACT_IDENTIFIER(19文字)
  → 先頭11文字一致 → 11/11 = 1.0 > 0.6 ✓

  SALESOUTLET_CODE(15文字) vs SALESOUTLET_NAME(15文字)
  → 先頭11文字一致 → 11/15 = 0.73 > 0.6 ✓

除外例:
  SALES_AMOUNT(12文字) vs SALES_TARGET(12文字)
  → SALES_の5文字一致 → 5/12 = 0.42 < 0.6 ✗

  STATUS_CODE(11文字) vs STATUS_FLAG(11文字)
  → STATUS_の7文字一致 → 7/11 = 0.64 > 0.6（ただしSTATUS_は汎用プレフィックスのため実質除外推奨）
```

#### 3-3. 代替候補が見つからなかった場合

分類Bで3層フィルタリングを経ても代替候補が見つからなかったVIEWについては:
- 廃止VIEWのカラム一覧のみを記録する
- 「代替VIEW未発見 — 手動調査が必要」として migration-plan に明示する

---

### 手順4: 3ファイルの生成

#### 出力ファイル1: `view-migration-knowledge.md`

ナレッジファイル。カラム差分の実データ・自動探索結果を含む移行マッピング情報。

```markdown
# VIEW移行ナレッジ

> 生成日: {YYYY-MM-DD}
> 元ファイル: {入力ファイル名}
> ステータス: Snowflake実測（{調査成功件数}/{全件数} VIEW 取得成功）

---

## 分類A: 代替VIEW有り — カラム差分詳細

### `VW_ADM_DNCD_BASIC_CONTRACT_MB` → `VW_DSC_DNCD_携帯-契約基本`

- **廃止期限**: 2026年9月
- **提供スキーマ**: D_CM_000
- **影響アプリ数**: {件数}（pochi-extract-user-by-contract 他）

#### カラム差分

| 差分種別 | カラム名 | 廃止VIEW型 | 代替VIEW型 | 対応方針 |
|---------|---------|-----------|-----------|---------|
| ⚠️ 削除 | `BASCID` | VARCHAR | — | 代替カラム `BASIC_CONTRACT_ID` に置換 |
| ⚠️ 削除 | `LINE_CTR_STT` | VARCHAR | — | 代替カラム `LINE_STATUS_CODE` に置換 |
| ℹ️ 追加 | `DATA_GENERATION_YM` | VARCHAR | — | 新規利用可（既存クエリへの影響なし） |
| ⚠️ 型変更 | `COMNID` | NUMBER | VARCHAR | キャスト式を確認 |
| 🔁 リネーム候補 | `BASCID` → `BASIC_CONTRACT_ID` | — | — | 名称変更の可能性。手動確認推奨 |

#### SQL修正パターン

```sql
-- Before（廃止VIEW使用）
FROM PROCDB_B_P01_LAK.D_MR_000.VW_ADM_DNCD_BASIC_CONTRACT_MB
WHERE LINE_CTR_STT = '01'

-- After（代替VIEW使用）
FROM PROCDB_B_P01_LAK.D_CM_000.VW_DSC_DNCD_携帯-契約基本
WHERE LINE_STATUS_CODE = '01'  -- カラム名変更
```

---

（以降、分類Aの全VIEWペアを同形式で記載）

---

## 分類B: 代替VIEW自動探索結果

### `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER`

- **対応方針**: 残留(方針検討中)
- **廃止期限**: 未定
- **影響アプリ数**: {件数}

#### 🔍 代替VIEW候補（自動探索結果）

| 候補VIEW | スキーマ | 類似度 | 判定 | カラム一致率 | 探索根拠 |
|---------|---------|--------|------|------------|---------|
| `VW_DSC_DNCD_販売管理-販売拠点マスタ` | D_CM_000 | 0.87 | ★ 強候補 | 15/18 (83%) | DNCD一致 + SALESOUTLET→販売拠点 |
| `VW_DSC_MECD_販売管理-販売拠点マスタ-月末` | D_CM_000 | 0.72 | △ 参考 | 13/18 (72%) | SALESOUTLET一致（月末版の可能性） |

> ⚠️ **人間による確認が必要**: 自動探索結果は候補の提示のみ。移行先として確定する前にALADINチームへ確認してください。

#### ★ 強候補のカラム差分

`VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` → `VW_DSC_DNCD_販売管理-販売拠点マスタ`（類似度0.87）

| 差分種別 | カラム名 | 廃止VIEW型 | 代替VIEW型 | 対応方針 |
|---------|---------|-----------|-----------|---------|
| ⚠️ 削除 | `LEGACY_CODE` | VARCHAR | — | 削除または代替カラム調査 |
| ℹ️ 追加 | `OUTLET_CATEGORY` | VARCHAR | — | 新規利用可 |
| ...  | | | | |

#### 現在のカラム構成（廃止で失われる情報）

| カラム名 | 型 | NULL | 説明（推定） |
|---------|---|------|------------|
| `SALESOUTLET_CODE` | VARCHAR | N | 販売店コード |
| `SALESOUTLET_NAME` | VARCHAR | Y | 販売店名 |
| ... | | | |

---

### `VW_DTT_XXXX_YYYY` （代替VIEW未発見の例）

- **対応方針**: 断捨離(ADM)
- **自動探索結果**: 類似度0.5以上の候補が見つかりませんでした
- **推奨アクション**: ALADINチームに代替VIEWの有無を直接確認

#### 現在のカラム構成

| カラム名 | 型 | NULL |
|---------|---|------|
| ... | | |

---

## 分類C: 緊急対応（代替なし）

| VIEW名 | 廃止期限 | 影響アプリ | ビジネス影響 |
|-------|---------|---------|-----------|
| `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` | **2026年3月末** | 時系列分析 他 | ユーザーフィルタリング停止 |
| `VW_PGN_MECD_STARTDASH_BASIC_ATTRIBUTE_AREA_OTHER` | **2026年3月末** | Snowcampゼロ次分析 | 婚姻・子供属性分析停止 |

---

## VIEW別影響アプリ一覧（横断サマリー）

| VIEW名 | 影響アプリ（リポジトリ） |
|-------|----------------------|
| `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | pochi-docomo-shop-analyzer, pochi-store-area-analysis, ... |
```

---

#### 出力ファイル2: `db-changes.md`

`db-impact-analyzer` への入力ファイル。カラム差分情報を含む。

```markdown
# DB変更内容定義 — VIEW廃止対応

> 生成日: {YYYY-MM-DD}  スキル: view-migration-planner v2.0.0

## 廃止VIEWリスト

### 🔴 緊急（代替なし・2026年3月末期限）
- `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` — 削除(代替無し)
- `VW_PGN_MECD_STARTDASH_BASIC_ATTRIBUTE_AREA_OTHER` — 削除(代替無し)

### 🟠 代替VIEW有り（2026年9月までに移行）

| 廃止VIEW | 代替VIEW | 主な削除カラム | 削除期限 |
|---------|---------|-------------|---------|
| `VW_ADM_DNCD_BASIC_CONTRACT_MB` | `VW_DSC_DNCD_携帯-契約基本` | `BASCID`, `LINE_CTR_STT` | 2026年9月 |
| `VW_ADW_MECD_BASIC_CONTRACT_MB` | `VW_DSC_MECD_携帯-契約基本-月末` | (要確認) | 2026年9月 |
...

### 🟡 対応方針未定（コード内使用箇所の特定が必要）

| 廃止VIEW | 代替VIEW候補（自動探索） | 類似度 | 削除期限 |
|---------|----------------------|--------|---------|
| `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | `VW_DSC_DNCD_販売管理-販売拠点マスタ`（★要確認） | 0.87 | 未定 |
| `VW_DTT_XXXX_YYYY` | 未発見 | — | 未定 |
...

### 🟢 コード削除のみ
- `VW_DMC_DNCL_LINE_FRIEND_LIST` — dMC廃止
...

## 調査対象アプリケーション

**ベースパス**: /home/user

**リポジトリ**:
- pochi-extract-user-by-contract-repository
- pochi-telema-measure-visualization-repository
...（29アプリ全件）
```

---

#### 出力ファイル3: `migration-plan_{YYYYMMDD}.md`

アプリ別・優先度別の作業タスクリスト。カラム差分・自動探索結果を活用した具体的な修正指針を含む。

```markdown
# VIEW移行計画書

> 生成日: {YYYY-MM-DD}  対象: {件数}アプリ / {件数}VIEW（継続提供除く）

## サマリー

| 優先度 | アプリ数 | VIEW数 |
|-------|---------|-------|
| 🔴 緊急 | {件数} | {件数} |
| 🟠 要対応（代替有り） | {件数} | {件数} |
| 🔍 候補発見（要確認） | {件数} | {件数} |
| 🔵 代替未発見（手動調査必要） | {件数} | {件数} |
| 🟢 コード削除のみ | {件数} | {件数} |

---

## 🔴 緊急対応（即時・2026年3月末）

### 時系列分析アプリ（pochi-timeseries-data-analyzer-repository）

- [ ] `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` — **代替なし・機能縮小で対応中**
  - 対応: 当該VIEWを参照するUIコンポーネント・SQLを削除または無効化
  - 参照箇所: db-impact-analyzer で特定（db-changes.md 実行後）

---

## 🟠 要対応（2026年9月まで）

### 契約状態抽出（pochi-extract-user-by-contract-repository）

| VIEW | 代替VIEW | 主な修正内容 |
|-----|---------|------------|
| `VW_ADM_DNCD_BASIC_CONTRACT_MB` | `VW_DSC_DNCD_携帯-契約基本` | `BASCID`→`BASIC_CONTRACT_ID`、`LINE_CTR_STT`→`LINE_STATUS_CODE` に置換 |
| `VW_ADW_MECD_BASIC_CONTRACT_MB` | `VW_DSC_MECD_携帯-契約基本-月末` | カラム差分は view-migration-knowledge.md 参照 |

---

## 🔍 代替VIEW候補あり（要確認・ALADINチームへ確認後に移行）

### {アプリ名}（{リポジトリ名}）

- [ ] `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER`
  - **自動探索候補**: `VW_DSC_DNCD_販売管理-販売拠点マスタ`（類似度0.87 ★）
  - **確認事項**: ALADINチームに代替VIEWとして使用可能か確認する
  - **カラム差分**: view-migration-knowledge.md の分類B該当セクション参照
  - **修正手順**（確認後）:
    1. db-impact-analyzer で修正対象ファイル・行番号を特定
    2. view-migration-knowledge.md のカラム差分を参照して書き換え

---

## 🔵 代替VIEW未発見（手動調査が必要）

- [ ] `VW_DTT_XXXX_YYYY` — 類似度0.5以上の代替候補なし
  - **アクション**: ALADINチームに代替VIEWの有無を直接確認する
  - **現在のカラム**: view-migration-knowledge.md 参照

---

## 作業フロー

```
1. migration-plan.md で優先度・修正内容を確認（このファイル）
   ↓
2. 対象リポジトリを dev ブランチに切り替えて git pull
   ↓
3. db-changes.md を db-impact-analyzer に渡してコードスキャン実行
   「DB影響分析をして」と入力し db-changes.md のパスを指定
   ↓
4. impact-report.md（修正ファイル・行番号）と
   view-migration-knowledge.md（カラム差分・SQL修正パターン）を参照して実装
```
```

---

### 手順5: 完了報告

```
## view-migration-planner 完了

### Snowflake調査結果
- 調査対象VIEW数: {件数}（廃止VIEW {件数} + 代替VIEW {件数}）
- 取得成功: {件数}件
- エラー（存在しない/権限不足）: {件数}件
  - {VIEW名}: {エラー内容}

### 代替VIEW自動探索結果（分類B）
- 探索対象: {件数}件
- ★ 強候補発見（類似度0.8以上）: {件数}件
- △ 参考候補のみ（類似度0.5〜0.8）: {件数}件
- ✗ 候補未発見（類似度0.5未満）: {件数}件

### 生成ファイル
| ファイル | 内容 |
|--------|------|
| view-migration-knowledge.md | カラム差分 + 代替候補付き移行ナレッジ |
| db-changes.md | db-impact-analyzer 用入力 |
| migration-plan_{日付}.md | 優先度別タスクリスト |

### 次のステップ
1. migration-plan_{日付}.md で優先度・修正内容を確認
2. 🔍候補あり のVIEWは ALADINチームに代替VIEW確認を依頼
3. 対象リポジトリを dev ブランチに切り替えて git pull
4. 「DB影響分析をして」と入力し db-changes.md のパスを指定して db-impact-analyzer を実行
```

---

## 注意事項

- **SELECT専用**: Snowflakeへのアクセスは `SHOW COLUMNS` / `SHOW TERSE VIEWS` のみ。データの取得・書き込みは行わない
- **VIEW名の大文字変換**: Snowflakeに渡す VIEW 名は大文字で渡す（小文字だと一致しないことがある）
- **フルパスが不明な場合**: `SHOW TERSE VIEWS LIKE '%{VIEW_NAME}%' IN DATABASE PROCDB_B_P01_LAK;` で検索してから `SHOW COLUMNS` を実行する
- **継続提供VIEWは除外**: `★継続提供` と記載されているものは Snowflake 調査・出力ファイルの両方から除外する
- **既存ファイルの上書き確認**: `view-migration-knowledge.md` / `db-changes.md` が既に存在する場合は上書きの可否を確認する
- **一時スクリプトの削除**: Snowflake 取得用の一時 Python ファイルは実行後に削除する
- **自動探索結果は候補提示のみ**: 類似度★の候補も確定した代替VIEWではない。ALADINチームへの確認を必ず挟むこと

---

## 対応方針 → 分類マッピング表

| summary-report の対応方針 | 分類 | Snowflake調査 | db-changes.md |
|--------------------------|------|-------------|--------------|
| 削除(代替有り) | A | 廃止・代替 両方 | 🟠 要対応 |
| 削除(代替無し) + 期限あり | C | なし | 🔴 緊急 |
| 残留(リファクタ有り) | B | 廃止のみ + 代替候補探索 | 🟡 別管理 |
| 残留(方針検討中) | B | 廃止のみ + 代替候補探索 | 🟡 別管理 |
| 断捨離(ADM) | B | 廃止のみ + 代替候補探索 | 🟡 別管理 |
| 断捨離(DWH層代替) | B | 廃止のみ + 代替候補探索 | 🟡 別管理 |
| 検討中(内容吟味) | B | 廃止のみ + 代替候補探索 | 🟡 別管理 |
| 個別マスタ別途 | B | 廃止のみ + 代替候補探索 | 🟡 別管理 |
| リファクタ(ALADIN) | B | 廃止のみ + 代替候補探索 | 🟡 別管理 |
| VIEW統合 | B | 廃止・代替 両方 + 代替候補探索 | 🟡 別管理 |
| 廃止 | B | 廃止のみ + 代替候補探索 | 🟡 別管理 |
| 残す方向 | B | 廃止のみ + 代替候補探索 | 🟡 別管理 |
| dMC廃止 + 本番コード使用あり | C | なし | 🔴 緊急 |
| dMC廃止 + コード削除のみ | D | なし | 🟢 削除のみ |
| 継続提供（★継続提供） | E | なし | ❌ 除外 |
