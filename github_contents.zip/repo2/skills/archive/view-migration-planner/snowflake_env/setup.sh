#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# べき等性: .venv が存在する場合はスキップ
if [ -d "$SCRIPT_DIR/.venv" ]; then
    echo "✓ 仮想環境は既に存在します: $SCRIPT_DIR/.venv"
    exit 0
fi

echo "セットアップを開始します..."

_POETRY_VERSION=$(cat "$SCRIPT_DIR/deployment_config.json" | python3 -c "import sys,json; print(json.load(sys.stdin)['poetry_version'])")
_ARTIFACTREGISTRY_AUTH_VERSION=$(cat "$SCRIPT_DIR/deployment_config.json" | python3 -c "import sys,json; print(json.load(sys.stdin)['artifactregistry_sdk_version'])")

echo "poetryバージョン: $_POETRY_VERSION"
echo "artifactregistry_sdk_version: $_ARTIFACTREGISTRY_AUTH_VERSION"

# keyrings インストール
poetry self add keyrings.google-artifactregistry-auth==$_ARTIFACTREGISTRY_AUTH_VERSION

# poetry install
cd "$SCRIPT_DIR"
poetry install --no-root --sync

echo "✓ セットアップ完了"
