"""
VIEW カラム情報取得スクリプト

使用方法:
    # 英語名VIEWのカラム取得（JSONファイルからVIEWリストを読み込む）
    poetry run python view_schema_fetcher.py --views-file /path/to/views.json

    # 単一VIEW（英語名）
    poetry run python view_schema_fetcher.py --view PROCDB_B_P01_LAK.D_MR_000.VW_ADM_DNCD_BASIC_CONTRACT_MB

    # 日本語名VIEWのカラム取得（引用識別子）
    poetry run python view_schema_fetcher.py --quoted PROCDB_B_P01_LAK D_CM_000 "VW_DSC_DNCD_携帯-契約基本"

    # スキーマのVIEW一覧取得（SHOW TERSE VIEWS）
    poetry run python view_schema_fetcher.py --terse-views PROCDB_B_P01_LAK.D_CM_000

出力: 標準出力にJSONを出力する
"""

import sys
import json
import argparse

from pochilib.snowflake import generate_pochi_snowflake_connector


def _parse_data_type(dt) -> str:
    """data_type JSONから型文字列を取得する"""
    if isinstance(dt, str):
        try:
            dt = json.loads(dt)
        except Exception:
            return dt
    if isinstance(dt, dict):
        return dt.get("type", str(dt))
    return str(dt)


def fetch_columns(view_full_name: str, cnx) -> dict:
    """SHOW COLUMNS IN VIEW でカラム情報を取得する（英語名VIEW用）"""
    try:
        result = cnx.get_records_and_fetchall(
            f"SHOW COLUMNS IN VIEW {view_full_name};"
        )
        df = result.to_pandas()
        if df.empty:
            return {"error": "empty_result (VIEWが存在しないか権限不足)"}
        columns = []
        for _, row in df.iterrows():
            columns.append({
                "column_name": row["column_name"],
                "type": _parse_data_type(row["data_type"]),
                "nullable": row.get("null?", "Y"),
                "comment": row.get("comment", ""),
            })
        return {"columns": columns}
    except Exception as e:
        return {"error": str(e)}


def fetch_columns_quoted(db: str, schema: str, view: str, cnx) -> dict:
    """引用識別子でVIEWのカラム情報を取得する（日本語名VIEW用）"""
    quoted = f'"{db}"."{schema}"."{view}"'
    try:
        result = cnx.get_records_and_fetchall(
            f"SHOW COLUMNS IN VIEW {quoted};"
        )
        df = result.to_pandas()
        if df.empty:
            return {"error": "empty_result (VIEWが存在しないか権限不足)"}
        columns = []
        for _, row in df.iterrows():
            columns.append({
                "column_name": row["column_name"],
                "type": _parse_data_type(row["data_type"]),
                "nullable": row.get("null?", "Y"),
                "comment": row.get("comment", ""),
            })
        return {"columns": columns}
    except Exception as e:
        return {"error": str(e)}


def fetch_terse_views(schema_full: str, cnx) -> dict:
    """SHOW TERSE VIEWS IN SCHEMA でVIEW名一覧を取得する"""
    try:
        result = cnx.get_records_and_fetchall(
            f"SHOW TERSE VIEWS IN SCHEMA {schema_full};"
        )
        df = result.to_pandas()
        if df.empty:
            return {"views": []}
        # 'name' カラムがVIEW名
        name_col = "name" if "name" in df.columns else df.columns[1]
        return {"views": sorted(df[name_col].tolist())}
    except Exception as e:
        return {"error": str(e)}


def main():
    parser = argparse.ArgumentParser(description="Snowflake VIEW カラム情報取得")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--views-file", help="VIEWフルパスのJSONリストファイル")
    group.add_argument("--view", help="単一VIEW フルパス（DB.SCHEMA.VIEW）")
    group.add_argument(
        "--quoted", nargs=3,
        metavar=("DB", "SCHEMA", "VIEW"),
        help="日本語名VIEW: DB SCHEMA VIEW（引用識別子で実行）"
    )
    group.add_argument("--terse-views", metavar="DB.SCHEMA", help="SHOW TERSE VIEWS IN SCHEMA")

    args = parser.parse_args()

    psc = generate_pochi_snowflake_connector()
    cnx = psc.connect()

    try:
        if args.views_file:
            with open(args.views_file) as f:
                view_list = json.load(f)
            results = {}
            for view in view_list:
                print(f"[INFO] 取得中: {view}", file=sys.stderr)
                results[view] = fetch_columns(view, cnx)
            print(json.dumps(results, ensure_ascii=False, indent=2))

        elif args.view:
            view = args.view
            print(f"[INFO] 取得中: {view}", file=sys.stderr)
            result = fetch_columns(view, cnx)
            print(json.dumps({view: result}, ensure_ascii=False, indent=2))

        elif args.quoted:
            db, schema, view = args.quoted
            key = f"{db}.{schema}.{view}"
            print(f"[INFO] 取得中（引用識別子）: {key}", file=sys.stderr)
            result = fetch_columns_quoted(db, schema, view, cnx)
            print(json.dumps({key: result}, ensure_ascii=False, indent=2))

        elif args.terse_views:
            schema_full = args.terse_views
            print(f"[INFO] SHOW TERSE VIEWS: {schema_full}", file=sys.stderr)
            result = fetch_terse_views(schema_full, cnx)
            print(json.dumps({schema_full: result}, ensure_ascii=False, indent=2))

    finally:
        cnx.close()


if __name__ == "__main__":
    main()
