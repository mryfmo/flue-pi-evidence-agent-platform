---
name: pochi-skill-risk-checker
description: >-
  スキルのTier分類（Tier 1〜3）を自動判定し、スキルリスク管理ガイドの展開前チェックリスト（Phase 1〜3）を自動実施して、
  チェックシートMDを生成するスキル。全社公開・開発チーム配布前の必須確認フローを支援する。
  「スキルのリスクチェックをして」「Tier分類をして」「展開前チェックをして」「pochi-skill-risk-checkerを起動」などと言われたときに使用する。
---

> ⚠️ **このスキルは廃止されました（2026-05-11）**
> Tier判定・展開前チェックシート生成の機能は `pochi-skill-qa-scanner` に統合されました。
> 起動してしまった場合は何も実行せず即座に終了してください。

# Pochi Skill Risk Checker（廃止済み）

スキルを全社公開・開発チーム配布する前に、**Tier分類の自動判定**と**展開前チェックリストの自動実施**を行い、チェックシートを生成します。

---

## When

### 起動条件

- 「スキルのリスクチェックをして」
- 「Tier分類をして」「Tierを判定して」
- 「展開前チェックをして」「展開前確認をして」
- 「pochi-skill-risk-checkerを起動」
- スキルを全社公開・開発チーム配布する前

### 起動しない条件

- ❌ スキルの品質・セキュリティ診断 → `pochi-skill-qa-scanner` を使うこと
- ❌ 新規スキル雛形作成 → `pochi-skill-generator` を使うこと
- ❌ Pochiアプリ本体のリスク確認（スキル以外）

---

## Do

### STEP 0: 前提説明の表示

以下を表示してスキルの位置づけを案内する：

```
📋 Pochi Skill Risk Checker

このスキルは「スキルリスク管理ガイド §8〜§12」に基づき、
スキルのTier分類と展開前チェックリスト（Phase 1〜3）を自動実施します。

【自動チェック範囲】
  ✅ Tier分類の自動判定（SKILL.md を解析）
  ✅ Phase 1: スキル品質チェック（機械的項目）
  ✅ Phase 2: セキュリティ・リスクチェック（機械的項目）
  ✅ Phase 3: ドキュメント・登録チェック（機械的項目）

【人間確認が必要な範囲（チェックシートに「要確認」で記載）】
  ❌ 1.4 適用実績の有無
  ❌ 1.6 出力物の品質評価
  ❌ 2.3 基盤チームレビュー（Tier 3スキルのみ）
  ❌ Phase 4〜5 展開先環境・展開後フォロー

※ pochi-skill-qa-scanner と組み合わせると、展開前チェックの約80%を自動化できます。
```

---

### STEP 1: 対象スキル選択

1. `/home/user/pochi-dp-developer-docs/.claude/skills.json` を Read で読み込む
2. `skills[]` の `id` 一覧を番号付きで表示する（例: `1. pochi-baseline-builder`）
3. ユーザーに以下を入力させる:
   - 番号（例: `3`）→ 該当スキルのみチェック
   - `A` → 全件チェック（大量スキルがある場合は確認してから実行）
4. 選択スキルの `path` を確認し、スキルディレクトリを特定する

---

### STEP 2: SKILL.md と plugin.json の読み込み

選択されたスキルに対して以下のファイルを Read で読み込む：

1. 正式パス: `skills/<category>/<skill_id>/skills/run/SKILL.md`
   - 存在しない場合は旧パス: `.claude/skills/<skill_id>/SKILL.md`
2. `skills/<category>/<skill_id>/plugin.json`（存在する場合）
3. `/home/user/pochi-dp-developer-docs/.claude-plugin/marketplace.json`（登録確認用）
4. `/home/user/pochi-dp-developer-docs/.claude/skills.json`（登録確認用）

---

### STEP 3: Tier自動判定

SKILL.md の本文を解析し、スキルリスク管理ガイド §3.1 の判定フローに従って Tier 候補を判定する。

#### 判定ロジック

**Step A: 外部システム操作の検出（Tier 3 判定）**

以下のいずれかが検出された場合 → **Tier 3 候補**:
- `git push` / `git commit --amend` の記述
- `requests.post` / `requests.put` / `requests.delete` の記述
- `snowflake` + `INSERT` / `UPDATE` / `DELETE` の組み合わせ
- `poetry update` / `pip install` の記述
- Slack / メール等の実送信を行う記述
- 外部APIへの POST/PUT/DELETE リクエストの記述

**Step B: ファイル生成・編集操作の検出（Tier 2 判定）**

Tier 3 非該当の場合、以下のいずれかが検出されたら → **Tier 2 候補**:
- `Write` / `Edit` / `write` / `edit` ツールの使用記述
- 「ファイルを生成」「ファイルを作成」「出力する」「保存する」の記述
- `git commit`（ローカルコミット）の記述
- MarkdownやJSONファイルへの出力記述

**Step C: 読取専用操作のみ（Tier 1 判定）**

Step A・B のいずれも検出されない場合 → **Tier 1 候補**

**複数 Tier 該当**: 最上位 Tier を適用（例: Tier 2 + Tier 3 の操作両方あり → Tier 3）

#### 判定結果の出力形式

```
📊 Tier自動判定結果

判定Tier: Tier X — [名称]
判定根拠:
  [検出された操作内容とその根拠をリストアップ]

⚠️ この判定は候補です。最終Tierはスキル開発者が確認・承認してください。
   スキルリスク管理ガイド §3.3「判定に迷う場合のルール」を参照してください。
```

---

### STEP 4: チェックリスト自動実施

判定した Tier に基づき、スキルリスク管理ガイド §10 のチェックリストを実施する。
**Tier別必須チェック早見表**に従い、当該 Tier の必須項目のみを実施する。

#### Phase 1: スキル品質チェック

| # | チェック項目 | 判定方法 | 自動/要確認 |
|:---:|---|---|:---:|
| 1.1 | plugin.json の status が `"beta"` 以上 | plugin.json の `"status"` フィールドを確認。フィールドがない場合は WARN | 自動 |
| 1.2 | SKILL.md にYAMLフロントマターが記載されている | `---` 囲み + `name` + `description`（20文字以上）の存在を確認 | 自動 |
| 1.3 | トリガーフレーズが他スキルと重複していない | skills.json の全 `triggers[]` を走査して重複を検出 | 自動 |
| 1.4 | 自チーム内で最低1回の実プロジェクト適用実績がある | output/ に `.gitkeep` 以外のファイルがあれば「実績あり可能性」と記録。確認は人間が実施 | 要確認 |
| 1.5 | エラーハンドリングが適切 | SKILL.md に「Error Handling」「エラーハンドリング」「Troubleshooting」セクションが存在するか確認 | 自動（近似） |
| 1.6 | 出力物の品質が一定水準 | 人間が確認。自動チェック不可 | 要確認 |
| 1.7 | plugin.json の author が個人GitHubアカウント名 | `"author"` フィールドを確認。汎用値（"Pochi Development Team"等）は WARN | 自動 |
| 1.8 | plugin.json に keywords フィールドが存在する | `"keywords"` フィールドの存在を確認 | 自動 |

#### Phase 2: セキュリティ・リスクチェック

| # | チェック項目 | 判定方法 | 自動/要確認 |
|:---:|---|---|:---:|
| 2.1 | Tier分類が完了している | plugin.json に `"tier"` フィールドが存在するか確認 | 自動 |
| 2.2 | Tier 2: Human-in-the-Loop が機能する（Tier 2 のみ） | SKILL.md に「ユーザー確認」「Human-in-the-Loop」「確認してから」等の記述があるか確認 | 自動（近似） |
| 2.3 | Tier 3: 基盤チームレビュー済み（Tier 3 のみ） | 人間が確認。自動チェック不可 | 要確認 |
| 2.4 | 外部入力をコマンドとして解釈・実行しない | SKILL.md にシェルコマンド直接実行パターンがないか確認 | 自動（近似） |
| 2.5 | インジェクション対策が施されている | `pochi-skill-qa-scanner` の実施確認 → qa-scan 出力ファイルの有無で判断 | 自動（代替） |
| 2.6 | 認証情報がハードコードされていない | SKILL.md / plugin.json に APIキー・トークン等の直接記載がないか確認 | 自動 |
| 2.7 | 脆弱性診断を実施済み | `output/qa-scan-*.md` の存在を Glob で確認 | 自動（代替） |

#### Phase 3: ドキュメント・登録チェック

| # | チェック項目 | 判定方法 | 自動/要確認 |
|:---:|---|---|:---:|
| 3.1 | marketplace.json にエントリが存在する | marketplace.json から skill_id を検索 | 自動 |
| 3.2 | skills.json にエントリが存在する | skills.json から skill_id を検索し、path 形式も確認 | 自動 |
| 3.3 | README.md に記載されている（3箇所） | README.md を Grep で確認（スキル一覧・installコマンド・一括コマンド） | 自動 |
| 3.4 | pochi-skill-navigator に登録されている | `skills/tools/pochi-skill-navigator/skills/run/SKILL.md` を Grep で確認 | 自動 |
| 3.5 | release-note.md に記載されている | `release-note.md` を Grep で確認 | 自動 |
| 3.6 | SKILLS_MANAGEMENT.md に記載されている | `.claude/skills/SKILLS_MANAGEMENT.md` を Grep で確認 | 自動 |
| 3.7 | 利用手順が分かるドキュメントがある | SKILL.md に「When」「Do」「入力」「使い方」いずれかのセクションがあるか確認 | 自動（近似） |
| 3.8 | 依存スキルの実行順序が明記されている | SKILL.md に「依存」「前提スキル」「before」等の記述があるか、または SKILL.md の説明で依存関係がないことを確認 | 自動（近似） |

---

### STEP 5: チェックシート生成

スキルリスク管理ガイド §11 のテンプレートに基づき、以下の内容を含むチェックシートを生成する。

```markdown
## スキル展開チェックシート

- **スキルID**: <skill_id>
- **展開先チーム**: （人間が記入）
- **確認者**: （人間が記入）
- **確認日**: YYYY-MM-DD
- **Tier分類（自動判定）**: Tier X — [名称]
- **Tier判定根拠**: [自動判定の根拠]
- **Tier最終承認**: ☐ 開発者確認済み

---

### Phase 1: スキル品質
- [x] or [ ] 1.1 plugin.json status: <結果と値>
- [x] or [ ] 1.2 SKILL.md フロントマター: <結果>
- [x] or [ ] 1.3 トリガー重複なし: <結果>
- [ ] 1.4 適用実績 ⚠️ **要確認**: output/ ファイル状況 = <確認結果>
- [x] or [ ] 1.5 エラーハンドリング（近似チェック）: <結果>
- [ ] 1.6 出力物の品質 ⚠️ **要確認**: 人間が実際の生成物を評価すること
- [x] or [ ] 1.7 author: <結果と値>
- [x] or [ ] 1.8 keywords: <結果>

### Phase 2: セキュリティ・リスク
- [x] or [ ] 2.1 Tier分類完了（plugin.json "tier" フィールド）: <結果>
  ※ 自動判定結果: Tier X。plugin.json に "tier" フィールドがない場合は追加が必要です
- [x] or [ ] 2.2 HITL確認（Tier 2のみ・近似チェック）: <結果>
- [ ] 2.3 基盤チームレビュー（Tier 3のみ）⚠️ **要確認**: 基盤チームと協議してください
- [x] or [ ] 2.4 外部入力コマンド非解釈（近似チェック）: <結果>
- [x] or [ ] 2.5 インジェクション対策（qa-scan 実施確認）: <結果>
- [x] or [ ] 2.6 認証情報ハードコードなし: <結果>
- [x] or [ ] 2.7 脆弱性診断済み（qa-scan 出力確認）: <結果>

### Phase 3: ドキュメント・登録
- [x] or [ ] 3.1 marketplace.json: <結果>
- [x] or [ ] 3.2 skills.json: <結果>
- [x] or [ ] 3.3 README.md（3箇所）: <結果>
- [x] or [ ] 3.4 pochi-skill-navigator: <結果>
- [x] or [ ] 3.5 release-note.md: <結果>
- [x] or [ ] 3.6 SKILLS_MANAGEMENT.md: <結果>
- [x] or [ ] 3.7 利用手順ドキュメント（近似チェック）: <結果>
- [x] or [ ] 3.8 依存スキル順序（近似チェック）: <結果>

### Phase 4: 展開先環境 ⚠️ **人間が実施**
- [ ] 4.1 Claude Code 利用可能
- [ ] 4.2 enabledPlugins 設定済み
- [ ] 4.3 extraKnownMarketplaces 設定済み
- [ ] 4.4 /plugin install 成功
- [ ] 4.5 前提ツール・ライブラリ利用可能
- [ ] 4.6 CLAUDE.md/Rules 管理ルール準拠

### Phase 5: 展開後フォロー ⚠️ **人間が実施**
- [ ] 5.1 ハンズオン実施/予定
- [ ] 5.2 フィードバック収集チャネル設定
- [ ] 5.3 KPI計測可能
- [ ] 5.4 エスカレーションルート明確
- [ ] 5.5 次回棚卸し時期設定

---

### 自動チェック サマリ

| フェーズ | 自動PASS | 自動FAIL | 要確認 |
|---------|:------:|:------:|:------:|
| Phase 1 | X | X | X |
| Phase 2 | X | X | X |
| Phase 3 | X | X | X |

**自動チェック結果**:
- ✅ 自動PASS: X / XX 項目
- ❌ 自動FAIL: X 項目（詳細は各フェーズ参照）
- ⚠️ 要確認: X 項目（人間が記入してください）

### 判定結果
- **展開可否**: （人間が判定: 可 / 条件付き可 / 不可）
- **条件付きの場合の残課題**: 
- **承認者**: 
- **承認日**: 
```

---

### STEP 6: チェックシートの保存

1. 現在の日時を取得し `yyyymmddHHmmss` 形式にフォーマットする
2. 以下のパスに Write で保存する:
   - 正式パスのスキル: `skills/<category>/<skill_id>/output/risk-check-<timestamp>.md`
   - 旧パスのスキル: `.claude/skills/<skill_id>/output/risk-check-<timestamp>.md`
   - output/ が存在しない場合は `.gitkeep` を配置して作成する
3. 以下のサマリを表示する:

```
📋 <skill_id> リスクチェック完了

Tier判定: Tier X（自動判定 — 開発者確認要）
自動PASS: X / XX 項目
自動FAIL: X 項目（詳細はチェックシート参照）
要確認: X 項目（人間が記入）

チェックシート保存先: <保存パス>

次のステップ:
1. チェックシートを開き、「要確認」項目を記入する
2. Tier判定の根拠を確認し、plugin.json に "tier" フィールドを追加する
   例: "tier": "Tier X"
3. 未実施の場合は pochi-skill-qa-scanner でセキュリティ診断を実施する（2.5/2.7）
4. Phase 4〜5 は展開先担当者と共同で記入する
```

---

## Validation Steps（自己チェック）

- [ ] Tier判定の根拠（検出した操作内容）が具体的に記載されているか
- [ ] FAIL 項目に具体的な理由と対応方法が付記されているか
- [ ] 自動チェック・要確認の区別が明確になっているか
- [ ] チェックシートが §11 のテンプレート形式に準拠しているか
- [ ] 保存先パスの形式が正しいか（`risk-check-<yyyymmddHHmmss>.md`）

---

## Error Handling

| 状況 | 対応 |
|------|------|
| skills.json が読み込めない | 「スキル一覧を取得できませんでした。skills.json を確認してください」と表示して終了 |
| SKILL.md が存在しない | 「SKILL.md が見つかりません。正式パス・旧パスを確認してください」と表示。チェック項目を全て FAIL として記録 |
| plugin.json が存在しない | 各チェックを WARN として記録し、「plugin.json が存在しない場合、marketplace 登録に必要なためファイルを作成してください」と案内 |
| output/ への保存失敗 | 「チェックシートの保存に失敗しました」と表示し、チェックシート内容をコンソール出力 |

---

## 注意事項

- このスキルは **Tier 候補を提示するだけ**であり、最終的な Tier 決定はスキル開発者が行うこと
- `pochi-skill-qa-scanner` と役割が異なる: qa-scanner は品質・セキュリティ・ドキュメント整合、このスキルはリスク管理ガイドへの準拠確認
- 2.5（インジェクション対策）と 2.7（脆弱性診断）は `pochi-skill-qa-scanner` の実施を前提とする
- Phase 4〜5 は展開先担当者が記入する。このスキルでは「要確認」として空欄を出力するのみ
- `claude-code-guide/official/` 配下のファイルは絶対に編集しない
