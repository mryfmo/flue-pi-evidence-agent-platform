# DB変更内容定義（検証用ダミー）

## 廃止テーブル/ビュー

- `VW_SAMPLE_USER_PROFILE` — ユーザープロファイルビュー（廃止予定）
- `TBL_LEGACY_ORDERS` — 旧オーダーテーブル（廃止予定）

## カラム削除

- `USER_MASTER.old_flag` — 廃止フラグカラム
- `ORDER_DETAIL.legacy_col` — 旧カラム

## 調査対象アプリケーション

- `/home/user/pochi-timeseries-data-analyzer-repository`
- `/home/user/pochi-user-behavior-map-repository`
- `/home/user/pochi-sales-data-visualization-repository`
