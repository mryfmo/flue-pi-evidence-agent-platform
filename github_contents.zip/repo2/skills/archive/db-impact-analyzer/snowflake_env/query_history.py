"""
Snowflakeクエリヒストリー照会スクリプト

使用方法:
    poetry run python query_history.py "<VIEW名カンマ区切り>" <調査日数>

例:
    poetry run python query_history.py "VIEW_A,VIEW_B" 7

出力:
    標準出力にJSONを出力する
"""

import sys
import json
import re
from datetime import datetime, timezone, timedelta


# ── Snowflake接続スイッチ ──────────────────────────────────
# False にするとSnowflake接続を行わずスタブレスポンスを返す
# 再度有効化する場合は True に戻すだけでよい
SNOWFLAKE_ENABLED = False
# ──────────────────────────────────────────────────────────

# VIEW名に許可する文字のホワイトリスト（英数字・アンダースコア・ドット）
_VALID_IDENTIFIER_RE = re.compile(r"^[A-Za-z0-9_.]+$")

# daysパラメータの上限
_MAX_QUERY_HISTORY_DAYS = 365

JST = timezone(timedelta(hours=9))


def _to_jst_str(dt) -> str | None:
    """datetime を JST 文字列に変換する"""
    if dt is None:
        return None
    if hasattr(dt, "tzinfo") and dt.tzinfo is not None:
        dt_jst = dt.astimezone(JST)
    else:
        # タイムゾーン情報がない場合は UTC として扱う
        dt_jst = dt.replace(tzinfo=timezone.utc).astimezone(JST)
    return dt_jst.strftime("%Y-%m-%dT%H:%M:%S+09:00")


def _sanitize_view_name(name: str) -> str:
    """VIEW名をホワイトリスト検証し、安全な文字列のみ許可する"""
    if not _VALID_IDENTIFIER_RE.match(name):
        raise ValueError(f"不正なVIEW名です: {name}")
    return name


def _validate_days(days: int) -> int:
    """days パラメータを正数かつ上限以内に制限する"""
    if days < 1:
        days = 1
    if days > _MAX_QUERY_HISTORY_DAYS:
        days = _MAX_QUERY_HISTORY_DAYS
    return days


def _escape_sql_string(value: str) -> str:
    """SQL文字列リテラル用にシングルクォートをエスケープする"""
    return value.replace("'", "''")


def fetch_query_history(view_names: list[str], days: int) -> dict:
    """
    全VIEW名を一括でSnowflakeクエリヒストリーを照会し、結果を返す

    DIRECT_OBJECTS_ACCESSED を使用してVIEWアクセスを正確に検出する。
    QUERY_TAG フィルタによりPochiアプリからのクエリのみに限定し、
    スキル自身が実行したクエリを除外する。

    Returns:
        dict: {"success": True, "query_period_days": days, "executed_sql": "...", "results": {...}}
              または {"success": False, "error": "...", "error_type": "..."}
    """
    # ── 入力バリデーション ──
    days = _validate_days(days)

    try:
        validated_names = [_sanitize_view_name(v) for v in view_names]
    except ValueError as e:
        return {
            "success": False,
            "error": str(e),
            "error_type": "VALIDATION_ERROR",
        }

    # ── Snowflake接続スイッチ判定 ──
    if not SNOWFLAKE_ENABLED:
        return {
            "success": False,
            "error": "Snowflake接続は現在無効化されています (SNOWFLAKE_ENABLED=False)",
            "error_type": "DISABLED",
            "query_period_days": days,
            "results": {
                view_name: {
                    "total_executions": 0,
                    "last_execution": None,
                    "earliest_execution": None,
                    "services": [],
                    "user_access_last_30days": [],
                }
                for view_name in validated_names
            },
        }

    try:
        from pochilib.snowflake import generate_pochi_snowflake_connector
    except ImportError as e:
        return {
            "success": False,
            "error": f"pochilib のインポートに失敗しました: {e}",
            "error_type": "IMPORT_ERROR",
        }

    try:
        psc = generate_pochi_snowflake_connector()
        psc.timeout = 600
    except Exception:
        return {
            "success": False,
            "error": "Snowflakeコネクター生成に失敗しました",
            "error_type": "CONNECTION_ERROR",
        }

    try:
        cnx = psc.connect()
    except Exception:
        return {
            "success": False,
            "error": "Snowflake接続に失敗しました",
            "error_type": "CONNECTION_ERROR",
        }

    # 全VIEW名をIN句用のプレースホルダーに変換（バリデーション済み + エスケープ）
    view_name_placeholders = ", ".join(f"'{_escape_sql_string(v)}'" for v in validated_names)
    year_filter = int(datetime.now().year)
    days = int(days)  # バリデーション済みだが明示的にint化

    sql = f"""
SELECT
    plan.PHYSICAL_NAME AS physical_view_name,
    REGEXP_SUBSTR(H.QUERY_TAG, 'service:([^,]+)', 1, 1, 'e', 1) AS service_name,
    COUNT(*) AS usage_count,
    MAX(H.QUERY_START_TIME) AS latest_access_time,
    MIN(H.QUERY_START_TIME) AS earliest_access_time
FROM
    PROCDB_B_P01_LAK.S_CM_000.VW_COM_ACCESS_AND_QUERY_HISTORY H,
    LATERAL FLATTEN(input => H.DIRECT_OBJECTS_ACCESSED) F
    INNER JOIN USERDB_B_P01_LAK.USER_MP001_01.A_DWH_MASTER_20251215 plan
        ON F.value:"objectName"::string LIKE '%' || plan.PHYSICAL_NAME || '%'
WHERE
    plan.PHYSICAL_NAME IN ({view_name_placeholders})
    AND YEAR(H.QUERY_START_TIME) >= {year_filter}
    AND H.QUERY_START_TIME >= DATEADD('day', -{days}, CURRENT_TIMESTAMP())
    AND H.QUERY_TAG LIKE '%from:pochi%'
    AND H.QUERY_TAG LIKE '%service:%'
GROUP BY
    plan.PHYSICAL_NAME,
    service_name
ORDER BY
    physical_view_name,
    usage_count DESC
"""

    # アプリ全体クエリ数取得クエリ（VIEW利用割合の分母）
    sql_app_total = f"""
SELECT
    REGEXP_SUBSTR(H.QUERY_TAG, 'service:([^,]+)', 1, 1, 'e', 1) AS service_name,
    COUNT(*) AS total_app_query_count
FROM
    PROCDB_B_P01_LAK.S_CM_000.VW_COM_ACCESS_AND_QUERY_HISTORY H
WHERE
    YEAR(H.QUERY_START_TIME) >= {year_filter}
    AND H.QUERY_START_TIME >= DATEADD('day', -{days}, CURRENT_TIMESTAMP())
    AND H.QUERY_TAG LIKE '%from:pochi%'
    AND H.QUERY_TAG LIKE '%service:%'
GROUP BY
    service_name
"""

    # ユーザー別VIEWアクセス数クエリ（直近30日固定）
    sql_user_access = f"""
SELECT
    plan.PHYSICAL_NAME AS physical_view_name,
    H.USER_NAME,
    COUNT(*) AS user_access_count
FROM
    PROCDB_B_P01_LAK.S_CM_000.VW_COM_ACCESS_AND_QUERY_HISTORY H,
    LATERAL FLATTEN(input => H.DIRECT_OBJECTS_ACCESSED) F
    INNER JOIN USERDB_B_P01_LAK.USER_MP001_01.A_DWH_MASTER_20251215 plan
        ON F.value:"objectName"::string LIKE '%' || plan.PHYSICAL_NAME || '%'
WHERE
    plan.PHYSICAL_NAME IN ({view_name_placeholders})
    AND YEAR(H.QUERY_START_TIME) >= {year_filter}
    AND H.QUERY_START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    AND H.QUERY_TAG LIKE '%from:pochi%'
    AND H.QUERY_TAG LIKE '%service:%'
GROUP BY
    plan.PHYSICAL_NAME,
    H.USER_NAME
ORDER BY
    physical_view_name,
    user_access_count DESC
"""

    # 全VIEW名を初期化（結果がなかったVIEWも含める）
    results = {
        view_name: {
            "total_executions": 0,
            "last_execution": None,
            "earliest_execution": None,
            "services": [],
            "user_access_last_30days": [],
        }
        for view_name in validated_names
    }

    try:
        result = cnx.get_records_and_fetchall(sql)
        df = result.to_pandas()

        if not df.empty:
            for view_name, group in df.groupby("PHYSICAL_VIEW_NAME"):
                if view_name not in results:
                    continue

                services = []
                for _, row in group.iterrows():
                    services.append({
                        "service_name": str(row["SERVICE_NAME"]) if row["SERVICE_NAME"] is not None else None,
                        "usage_count": int(row["USAGE_COUNT"]),
                    })

                total_executions = int(group["USAGE_COUNT"].sum())
                latest_raw = group["LATEST_ACCESS_TIME"].max()
                earliest_raw = group["EARLIEST_ACCESS_TIME"].min()

                results[view_name]["total_executions"] = total_executions
                results[view_name]["last_execution"] = _to_jst_str(latest_raw)
                results[view_name]["earliest_execution"] = _to_jst_str(earliest_raw)
                results[view_name]["services"] = services

    except Exception:
        cnx.close()
        return {
            "success": False,
            "error": "クエリ実行に失敗しました",
            "error_type": "QUERY_ERROR",
        }

    # アプリ全体クエリ数を取得（サービス別辞書として保持）
    app_total_query_counts: dict = {}
    try:
        result_total = cnx.get_records_and_fetchall(sql_app_total)
        df_total = result_total.to_pandas()
        if not df_total.empty:
            for _, row in df_total.iterrows():
                svc = str(row["SERVICE_NAME"]) if row["SERVICE_NAME"] is not None else None
                if svc:
                    app_total_query_counts[svc] = int(row["TOTAL_APP_QUERY_COUNT"])
    except Exception as e:
        print(f"[WARN] アプリ全体クエリ数取得失敗: {type(e).__name__}", file=sys.stderr)

    # services に app_total_query_count と usage_ratio_pct を付与
    for view_name in results:
        enriched_services = []
        for svc_info in results[view_name]["services"]:
            svc_name = svc_info.get("service_name")
            total_cnt = app_total_query_counts.get(svc_name) if svc_name else None
            usage_cnt = svc_info.get("usage_count", 0)
            if total_cnt and total_cnt > 0:
                ratio_pct = round(usage_cnt / total_cnt * 100, 2)
            else:
                ratio_pct = None
            enriched_services.append({
                "service_name": svc_name,
                "usage_count": usage_cnt,
                "app_total_query_count": total_cnt,
                "usage_ratio_pct": ratio_pct,
            })
        results[view_name]["services"] = enriched_services

    # ユーザー別VIEWアクセス数を取得（直近30日）
    try:
        result_user = cnx.get_records_and_fetchall(sql_user_access)
        df_user = result_user.to_pandas()
        if not df_user.empty:
            for view_name, group in df_user.groupby("PHYSICAL_VIEW_NAME"):
                if view_name not in results:
                    continue
                user_access = []
                for _, row in group.iterrows():
                    user_access.append({
                        "user_name": str(row["USER_NAME"]) if row["USER_NAME"] is not None else None,
                        "access_count": int(row["USER_ACCESS_COUNT"]),
                    })
                results[view_name]["user_access_last_30days"] = user_access
    except Exception as e:
        print(f"[WARN] ユーザー別アクセス数取得失敗: {type(e).__name__}", file=sys.stderr)

    cnx.close()
    return {
        "success": True,
        "query_period_days": days,
        "results": results,
    }


def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            "success": False,
            "error": "引数が不足しています。使用方法: python query_history.py '<VIEW名カンマ区切り>' <調査日数>",
            "error_type": "ARGUMENT_ERROR",
        }, ensure_ascii=False))
        sys.exit(0)

    view_names_csv = sys.argv[1]
    view_names = [v.strip() for v in view_names_csv.split(",") if v.strip()]

    days = 7
    if len(sys.argv) >= 3:
        try:
            days = int(sys.argv[2])
            days = _validate_days(days)
        except ValueError:
            pass

    output = fetch_query_history(view_names, days)
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
