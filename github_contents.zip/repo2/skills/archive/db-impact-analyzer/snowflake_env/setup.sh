#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# べき等性: .venv が存在する場合はスキップ
if [ -d "$SCRIPT_DIR/.venv" ]; then
    echo "✓ 仮想環境は既に存在します: $SCRIPT_DIR/.venv"
    exit 0
fi

echo "セットアップを開始します..."

# deployment_config.json からバージョンを読み取る
_POETRY_VERSION=$(cat "$SCRIPT_DIR/deployment_config.json" | jq -r '.poetry_version')
_ARTIFACTREGISTRY_AUTH_VERSION=$(cat "$SCRIPT_DIR/deployment_config.json" | jq -r '.artifactregistry_sdk_version')

echo "
【 poetryの仮想環境構築 】
次の設定値でpoetryの仮想環境構築します。

- poetryバージョン: $_POETRY_VERSION
- artifactregistry_sdk_version: $_ARTIFACTREGISTRY_AUTH_VERSION
"

# poetryバージョン更新
poetry self update $_POETRY_VERSION

# keyrings インストール（バージョン固定）
poetry self add keyrings.google-artifactregistry-auth==$_ARTIFACTREGISTRY_AUTH_VERSION

# poetry install
cd "$SCRIPT_DIR"
poetry install --no-root --sync

echo "✓ セットアップ完了"
