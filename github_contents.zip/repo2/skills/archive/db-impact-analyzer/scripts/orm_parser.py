"""
ORM解析

SQLAlchemy等のORMコードからテーブル・カラム参照を抽出します。
"""

import re
from typing import List, Dict, Any, Tuple
import logging


class ORMParser:
    """ORMコードを解析するクラス"""

    def __init__(self, detection_patterns: Dict[str, Any], logger: logging.Logger):
        """
        ORMParserを初期化します。

        Args:
            detection_patterns: 検出パターン設定
            logger: ロガー
        """
        self.detection_patterns = detection_patterns
        self.logger = logger
        self.orm_patterns = detection_patterns.get("orm", {})

    def extract_orm_models(self, code: str) -> List[Tuple[str, int, str]]:
        """
        SQLAlchemyモデル定義を抽出します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (モデル/テーブル名, 行番号, コード行) のリスト
        """
        results = []
        lines = code.split("\n")

        sqlalchemy_patterns = self.orm_patterns.get("sqlalchemy", {})
        model_patterns = sqlalchemy_patterns.get("model_definition", {}).get("patterns", [])

        for line_num, line in enumerate(lines, start=1):
            # コメント行をスキップ
            if self._is_comment_line(line):
                continue

            # 各パターンで検索
            for pattern in model_patterns:
                match = re.search(pattern, line)
                if match:
                    model_name = match.group(1)
                    if self._is_valid_identifier(model_name):
                        results.append((model_name, line_num, line.strip()))
                        self.logger.debug(f"ORMモデル検出: {model_name} at line {line_num}")

        return results

    def extract_orm_columns(self, code: str) -> List[Tuple[str, int, str]]:
        """
        SQLAlchemy Column定義を抽出します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (カラム名, 行番号, コード行) のリスト
        """
        results = []
        lines = code.split("\n")

        sqlalchemy_patterns = self.orm_patterns.get("sqlalchemy", {})
        column_patterns = sqlalchemy_patterns.get("column_definition", {}).get("patterns", [])

        for line_num, line in enumerate(lines, start=1):
            # コメント行をスキップ
            if self._is_comment_line(line):
                continue

            # 各パターンで検索
            for pattern in column_patterns:
                match = re.search(pattern, line)
                if match:
                    column_name = match.group(1)
                    if self._is_valid_identifier(column_name):
                        results.append((column_name, line_num, line.strip()))
                        self.logger.debug(f"ORMカラム検出: {column_name} at line {line_num}")

        return results

    def extract_orm_queries(self, code: str) -> List[Tuple[str, int, str]]:
        """
        SQLAlchemyクエリを抽出します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (テーブル/カラム名, 行番号, コード行) のリスト
        """
        results = []
        lines = code.split("\n")

        sqlalchemy_patterns = self.orm_patterns.get("sqlalchemy", {})
        query_patterns = sqlalchemy_patterns.get("query", {}).get("patterns", [])

        for line_num, line in enumerate(lines, start=1):
            # コメント行をスキップ
            if self._is_comment_line(line):
                continue

            # 各パターンで検索
            for pattern in query_patterns:
                matches = re.finditer(pattern, line)
                for match in matches:
                    # パターンによってグループ数が異なる
                    if match.lastindex >= 1:
                        ref_name = match.group(1)
                        if self._is_valid_identifier(ref_name):
                            results.append((ref_name, line_num, line.strip()))
                            self.logger.debug(f"ORMクエリ検出: {ref_name} at line {line_num}")

                    # filter(Table.column) パターンの場合
                    if match.lastindex >= 2:
                        table_name = match.group(1)
                        column_name = match.group(2)
                        qualified = f"{table_name}.{column_name}"
                        results.append((qualified, line_num, line.strip()))
                        self.logger.debug(f"ORMクエリ検出: {qualified} at line {line_num}")

        return results

    def extract_new_style_queries(self, code: str) -> List[Tuple[str, int, str]]:
        """
        SQLAlchemy新スタイルAPI (select, text, with_entities) を抽出します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (テーブル/カラム名, 行番号, コード行) のリスト
        """
        results = []
        lines = code.split("\n")

        sqlalchemy_patterns = self.orm_patterns.get("sqlalchemy", {})
        new_style_patterns = sqlalchemy_patterns.get("new_style_query", {}).get("patterns", [])

        for line_num, line in enumerate(lines, start=1):
            if self._is_comment_line(line):
                continue

            for pattern in new_style_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    ref_name = match.group(1)
                    if ref_name and self._is_valid_identifier(ref_name.split(".")[0]):
                        results.append((ref_name, line_num, line.strip()))
                        self.logger.debug(f"新スタイルAPI検出: {ref_name} at line {line_num}")
                        break

        return results

    def extract_pochilib_snowflake_calls(self, code: str) -> List[Tuple[str, int, str]]:
        """
        pochilib独自のSnowflake関数からSQL参照を抽出します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (view名/SQL参照, 行番号, コード行) のリスト
        """
        results = []
        lines = code.split("\n")

        pochilib_patterns = self.detection_patterns.get("pochilib_snowflake", {})
        connector_patterns = pochilib_patterns.get("connector_functions", {}).get("patterns", [])

        # テーブル/view名抽出用パターン
        # 完全修飾名（db.schema.table または schema.table）にも対応し、最後のセグメントを抽出
        table_pattern = re.compile(
            r'(?:FROM|JOIN|INTO|UPDATE)\s+'
            r'(?:[a-zA-Z_][a-zA-Z0-9_]*\.)*'   # オプションのスキーマプレフィックス
            r'([a-zA-Z_][a-zA-Z0-9_]*)',         # テーブル/VIEW名（最後のセグメント）
            re.IGNORECASE
        )

        for line_num, line in enumerate(lines, start=1):
            if self._is_comment_line(line):
                continue

            for pattern in connector_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    # 引数内からview名・テーブル名を抽出
                    table_matches = table_pattern.findall(line)
                    for table_name in table_matches:
                        if self._is_valid_identifier(table_name):
                            results.append((table_name, line_num, line.strip()))
                            self.logger.debug(f"pochilib Snowflake呼び出し検出: {table_name} at line {line_num}")

                    # view名が見つからなくても行自体を記録（呼び出し元でLOW扱い）
                    if not table_matches:
                        results.append(("pochilib_snowflake_call", line_num, line.strip()))
                        self.logger.debug(f"pochilib Snowflake呼び出し検出 (table不明) at line {line_num}")
                    break

        return results

    def extract_multiline_sql(self, code: str) -> List[Tuple[str, int, str]]:
        """
        三重引用符の複数行SQL文字列を検出・解析します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (テーブル/カラム名, 行番号, コード行) のリスト
        """
        results = []

        # 三重引用符ブロックを検出
        triple_quote_pattern = re.compile(
            r'(""".*?"""|\'\'\'.*?\'\'\')',
            re.DOTALL
        )

        # 完全修飾名（db.schema.table）対応: 最後のセグメントをテーブル名として抽出
        table_pattern = re.compile(
            r'(?:FROM|JOIN|INTO|UPDATE)\s+'
            r'(?:[a-zA-Z_][a-zA-Z0-9_]*\.)*'
            r'([a-zA-Z_][a-zA-Z0-9_]*)',
            re.IGNORECASE
        )
        column_pattern = re.compile(
            r'(?:SELECT|WHERE|ORDER\s+BY|GROUP\s+BY)\s+([a-zA-Z_][a-zA-Z0-9_]*)',
            re.IGNORECASE
        )

        for match in triple_quote_pattern.finditer(code):
            block = match.group(0)

            # SQLキーワードを含むかチェック
            if not any(kw in block.upper() for kw in ["SELECT", "FROM", "UPDATE", "INSERT", "DELETE"]):
                continue

            # ブロック開始の行番号を計算
            block_start_pos = match.start()
            line_num = code[:block_start_pos].count("\n") + 1

            # ブロック内の最初の行をコードスニペットとして使用
            block_first_line = block.split("\n")[0].strip() or block[:100].strip()

            # テーブル名を抽出
            for table_name in table_pattern.findall(block):
                if self._is_valid_identifier(table_name):
                    results.append((table_name, line_num, block_first_line))
                    self.logger.debug(f"複数行SQLテーブル検出: {table_name} at line {line_num}")

            # カラム名を抽出
            for column_name in column_pattern.findall(block):
                if self._is_valid_identifier(column_name) and column_name.upper() not in {
                    "SELECT", "FROM", "WHERE", "BY", "AND", "OR", "AS", "ON"
                }:
                    results.append((column_name, line_num, block_first_line))
                    self.logger.debug(f"複数行SQLカラム検出: {column_name} at line {line_num}")

        return results

    def detect_orm_usage(self, code: str) -> bool:
        """
        コードがORMを使用しているかを判定します。

        Args:
            code: 解析対象コード

        Returns:
            bool: ORMを使用している場合True
        """
        # SQLAlchemyインポート検出
        sqlalchemy_imports = [
            "from sqlalchemy",
            "import sqlalchemy",
            "from flask_sqlalchemy",
            "from sqlalchemy import select",
            "text(",
        ]

        for import_stmt in sqlalchemy_imports:
            if import_stmt in code:
                self.logger.debug("ORMインポート検出")
                return True

        # ORM特有のパターン検出
        orm_keywords = ["Base", "Column", "session.query", "__tablename__", "select(", "with_entities("]
        for keyword in orm_keywords:
            if keyword in code:
                self.logger.debug(f"ORMキーワード検出: {keyword}")
                return True

        return False

    def _is_comment_line(self, line: str) -> bool:
        """行がコメントかどうかを判定"""
        stripped = line.strip()
        return stripped.startswith("#") or stripped.startswith("//")

    def _is_valid_identifier(self, name: str) -> bool:
        """有効な識別子かを判定"""
        if not name:
            return False
        # Pythonキーワードを除外
        reserved = {"as", "on", "and", "or", "in", "is", "not", "self", "cls", "def", "class"}
        return name.lower() not in reserved


def extract_table_name_from_model(model_code: str) -> str:
    """
    モデル定義から__tablename__を抽出します（補助関数）。

    Args:
        model_code: モデル定義コード

    Returns:
        str: テーブル名（見つからない場合は空文字列）
    """
    match = re.search(r'__tablename__\s*=\s*["\']([a-zA-Z_][a-zA-Z0-9_]*)["\']', model_code)
    if match:
        return match.group(1)
    return ""
