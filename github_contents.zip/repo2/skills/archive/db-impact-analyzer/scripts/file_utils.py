"""
ファイル操作ユーティリティ

ファイル検索、読み込み、エンコーディング処理を提供します。
"""

import logging
from pathlib import Path
from typing import List, Optional


def find_files(
    root_dir: Path,
    extensions: List[str],
    exclude_dirs: List[str],
    max_size_mb: int = 10,
    logger: Optional[logging.Logger] = None
) -> List[Path]:
    """
    ディレクトリ内のファイルを検索します。

    Args:
        root_dir: ルートディレクトリ
        extensions: 対象拡張子リスト (例: [".py", ".sql"])
        exclude_dirs: 除外ディレクトリリスト
        max_size_mb: 最大ファイルサイズ（MB）
        logger: ロガー（オプション）

    Returns:
        List[Path]: 検索されたファイルパスリスト
    """
    if not root_dir.exists():
        if logger:
            logger.warning(f"ディレクトリが存在しません: {root_dir}")
        return []

    found_files = []
    max_size_bytes = max_size_mb * 1024 * 1024

    try:
        for ext in extensions:
            # 再帰的に検索
            for file_path in root_dir.rglob(f"*{ext}"):
                # 除外ディレクトリチェック
                if any(excluded in file_path.parts for excluded in exclude_dirs):
                    continue

                # ファイルサイズチェック
                try:
                    file_size = file_path.stat().st_size
                    if file_size > max_size_bytes:
                        if logger:
                            logger.debug(f"ファイルサイズ超過（スキップ）: {file_path} ({file_size / 1024 / 1024:.1f}MB)")
                        continue
                except Exception as e:
                    if logger:
                        logger.debug(f"ファイル情報取得失敗（スキップ）: {file_path} - {e}")
                    continue

                found_files.append(file_path)

        if logger:
            logger.debug(f"ファイル検索完了: {len(found_files)}件")

    except Exception as e:
        if logger:
            logger.error(f"ファイル検索エラー: {root_dir} - {e}")

    return found_files


def read_file_safe(
    file_path: Path,
    encoding: str = "utf-8",
    fallback_encoding: str = "latin-1",
    logger: Optional[logging.Logger] = None
) -> Optional[str]:
    """
    ファイルを安全に読み込みます（エンコーディングフォールバック付き）。

    Args:
        file_path: ファイルパス
        encoding: 主エンコーディング
        fallback_encoding: フォールバックエンコーディング
        logger: ロガー（オプション）

    Returns:
        str: ファイル内容（失敗時はNone）
    """
    if not file_path.exists():
        if logger:
            logger.warning(f"ファイルが存在しません: {file_path}")
        return None

    # まず主エンコーディングで試行
    try:
        with open(file_path, "r", encoding=encoding) as f:
            content = f.read()
        if logger:
            logger.debug(f"ファイル読み込み成功（{encoding}）: {file_path}")
        return content
    except UnicodeDecodeError:
        # フォールバックエンコーディングで再試行
        try:
            with open(file_path, "r", encoding=fallback_encoding) as f:
                content = f.read()
            if logger:
                logger.debug(f"ファイル読み込み成功（{fallback_encoding}）: {file_path}")
            return content
        except Exception as e:
            if logger:
                logger.error(f"ファイル読み込みエラー: {file_path} - {e}")
            return None
    except Exception as e:
        if logger:
            logger.error(f"ファイル読み込みエラー: {file_path} - {e}")
        return None


def write_file_safe(
    file_path: Path,
    content: str,
    encoding: str = "utf-8",
    logger: Optional[logging.Logger] = None
) -> bool:
    """
    ファイルを安全に書き込みます。

    Args:
        file_path: ファイルパス
        content: 書き込む内容
        encoding: エンコーディング
        logger: ロガー（オプション）

    Returns:
        bool: 成功時True
    """
    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, "w", encoding=encoding) as f:
            f.write(content)
        if logger:
            logger.debug(f"ファイル書き込み成功: {file_path}")
        return True
    except Exception as e:
        if logger:
            logger.error(f"ファイル書き込みエラー: {file_path} - {e}")
        return False


def is_text_file(file_path: Path) -> bool:
    """
    ファイルがテキストファイルかを判定します。

    Args:
        file_path: ファイルパス

    Returns:
        bool: テキストファイルの場合True
    """
    text_extensions = {".py", ".sql", ".txt", ".md", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg"}
    return file_path.suffix.lower() in text_extensions


def get_file_info(file_path: Path) -> dict:
    """
    ファイル情報を取得します。

    Args:
        file_path: ファイルパス

    Returns:
        dict: ファイル情報 (size, modified_time等)
    """
    try:
        stat = file_path.stat()
        return {
            "size_bytes": stat.st_size,
            "size_mb": stat.st_size / 1024 / 1024,
            "modified_time": stat.st_mtime,
            "is_file": file_path.is_file(),
            "is_dir": file_path.is_dir(),
            "extension": file_path.suffix
        }
    except Exception:
        return {
            "size_bytes": 0,
            "size_mb": 0,
            "modified_time": 0,
            "is_file": False,
            "is_dir": False,
            "extension": ""
        }
