"""
SQL解析

Pythonコード内のSQL文字列からテーブル名・カラム名を抽出します。
"""

import re
from typing import List, Dict, Any, Tuple
import logging


class SQLParser:
    """SQL文字列を解析するクラス"""

    def __init__(self, detection_patterns: Dict[str, Any], logger: logging.Logger):
        """
        SQLParserを初期化します。

        Args:
            detection_patterns: 検出パターン設定
            logger: ロガー
        """
        self.detection_patterns = detection_patterns
        self.logger = logger
        self.sql_patterns = detection_patterns.get("sql", {})

    def extract_table_references(self, code: str) -> List[Tuple[str, int, str]]:
        """
        コードからテーブル参照を抽出します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (テーブル名, 行番号, コード行) のリスト
        """
        results = []
        lines = code.split("\n")

        # FROM, JOIN, INTOパターン
        table_patterns = self.sql_patterns.get("table_references", {}).get("patterns", [])

        for line_num, line in enumerate(lines, start=1):
            # コメント行をスキップ
            if self._is_comment_line(line):
                continue

            # 除外パターンマッチング（_contains_sql_keywords内で実施されるが念のため）
            if self._matches_exclusion_pattern(line):
                continue

            # SQL文字列検出
            if not self._contains_sql_keywords(line):
                continue

            # 各パターンで検索
            for pattern in table_patterns:
                matches = re.finditer(pattern, line, re.IGNORECASE)
                for match in matches:
                    table_name = match.group(1)
                    if self._is_valid_identifier(table_name):
                        results.append((table_name, line_num, line.strip()))
                        self.logger.debug(f"テーブル検出: {table_name} at line {line_num}")

        return results

    def extract_column_references(self, code: str) -> List[Tuple[str, int, str]]:
        """
        コードからカラム参照を抽出します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (カラム名, 行番号, コード行) のリスト
        """
        results = []
        lines = code.split("\n")

        # table.column パターン
        qualified_pattern = r'([a-zA-Z_][a-zA-Z0-9_]*)\.([a-zA-Z_][a-zA-Z0-9_]*)'

        # 除外対象のプレフィックスリストを取得
        excluded_prefixes = set(self.detection_patterns.get("excluded_qualified_prefixes", []))

        for line_num, line in enumerate(lines, start=1):
            # コメント行をスキップ
            if self._is_comment_line(line):
                continue

            # SQL文字列検出
            if not self._contains_sql_keywords(line):
                continue

            # table.column形式を抽出
            matches = re.finditer(qualified_pattern, line)
            for match in matches:
                table_name = match.group(1)
                column_name = match.group(2)

                # 除外リストチェック
                if table_name.lower() in excluded_prefixes:
                    self.logger.debug(f"除外対象: {table_name}.{column_name}")
                    continue

                qualified_col = f"{table_name}.{column_name}"
                if self._is_valid_identifier(table_name) and self._is_valid_identifier(column_name):
                    results.append((qualified_col, line_num, line.strip()))
                    self.logger.debug(f"カラム検出: {qualified_col} at line {line_num}")

        return results

    def detect_dynamic_sql(self, code: str) -> List[Tuple[str, int, str]]:
        """
        動的SQL生成を検出します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (検出パターン, 行番号, コード行) のリスト
        """
        results = []
        lines = code.split("\n")

        dynamic_patterns = self.sql_patterns.get("dynamic_sql", {}).get("patterns", [])

        for line_num, line in enumerate(lines, start=1):
            # コメント行をスキップ
            if self._is_comment_line(line):
                continue

            # 除外パターンマッチング
            if self._matches_exclusion_pattern(line):
                continue

            # 各動的SQLパターンで検索
            for pattern in dynamic_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    results.append(("dynamic_sql", line_num, line.strip()))
                    self.logger.warning(f"動的SQL検出: line {line_num}: {line.strip()}")
                    break  # 1行に複数マッチしても1回だけ記録

        return results

    def detect_select_star(self, code: str) -> List[Tuple[str, int, str]]:
        """
        SELECT * を検出します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (パターン名, 行番号, コード行) のリスト
        """
        results = []
        lines = code.split("\n")

        select_star_patterns = self.sql_patterns.get("select_star", {}).get("patterns", [])

        for line_num, line in enumerate(lines, start=1):
            # コメント行をスキップ
            if self._is_comment_line(line):
                continue

            for pattern in select_star_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    results.append(("select_star", line_num, line.strip()))
                    self.logger.debug(f"SELECT * 検出: line {line_num}")
                    break

        return results

    def extract_variable_assigned_sql(self, code: str) -> List[Tuple[str, int, str]]:
        """
        変数代入パターン (query = "SELECT ... FROM ...") のSQL検出します。

        Args:
            code: 解析対象コード

        Returns:
            List[Tuple[str, int, str]]: (テーブル名, 行番号, コード行) のリスト
        """
        results = []
        lines = code.split("\n")

        # 変数代入SQL検出パターン
        assignment_pattern = re.compile(
            r'[a-zA-Z_]\w*\s*=\s*(?:f?["\']|f?""")',
            re.IGNORECASE
        )
        # 完全修飾名（db.schema.table）対応: 最後のセグメントをテーブル名として抽出
        table_pattern = re.compile(
            r'(?:FROM|JOIN|INTO|UPDATE)\s+'
            r'(?:[a-zA-Z_][a-zA-Z0-9_]*\.)*'
            r'([a-zA-Z_][a-zA-Z0-9_]*)',
            re.IGNORECASE
        )

        for line_num, line in enumerate(lines, start=1):
            if self._is_comment_line(line):
                continue

            # 変数代入パターンにマッチするか確認
            if not assignment_pattern.search(line):
                continue

            # SQLキーワードを含むか確認
            if not self._contains_sql_keywords(line):
                continue

            # テーブル名を抽出
            for table_name in table_pattern.findall(line):
                if self._is_valid_identifier(table_name):
                    results.append((table_name, line_num, line.strip()))
                    self.logger.debug(f"変数代入SQL検出: {table_name} at line {line_num}")

        return results

    def _is_comment_line(self, line: str) -> bool:
        """行がコメントかどうかを判定"""
        stripped = line.strip()
        return stripped.startswith("#") or stripped.startswith("//") or stripped.startswith("--")

    def _matches_exclusion_pattern(self, line: str) -> bool:
        """
        除外パターンに該当するかを判定

        Returns:
            True: 除外対象（スキャン不要）
            False: チェック対象
        """
        exclusion_patterns = self.detection_patterns.get("exclusion_patterns", {})

        for category, patterns in exclusion_patterns.items():
            if isinstance(patterns, dict):
                # prefixes, methods, patterns のいずれか
                for pattern_type, pattern_list in patterns.items():
                    if pattern_type == "description":
                        continue
                    for pattern in pattern_list:
                        if re.search(pattern, line, re.IGNORECASE):
                            self.logger.debug(f"除外パターンマッチ: {category}.{pattern_type} - {pattern}")
                            return True

        return False

    def _contains_sql_keywords(self, line: str) -> bool:
        """
        行にSQLキーワードが含まれるかを判定（改善版）

        改善点:
        - 単語境界チェック（\b）を使用
        - 除外パターンを先にチェック
        """
        # コメント行は除外
        if self._is_comment_line(line):
            return False

        # 除外パターンマッチング
        if self._matches_exclusion_pattern(line):
            return False

        # 単語境界チェック付きのキーワード検出
        sql_keywords = ["SELECT", "FROM", "JOIN", "WHERE", "UPDATE", "INSERT", "DELETE", "TABLE"]
        for keyword in sql_keywords:
            pattern = rf'\b{keyword}\b'
            if re.search(pattern, line, re.IGNORECASE):
                return True

        return False

    def _is_valid_identifier(self, name: str) -> bool:
        """有効な識別子かを判定"""
        if not name:
            return False
        # Pythonキーワードや一般的な予約語を除外
        reserved = {"as", "on", "and", "or", "in", "is", "not", "null", "true", "false", "self", "cls"}
        return name.lower() not in reserved


def extract_sql_strings(code: str) -> List[str]:
    """
    PythonコードからSQL文字列を抽出します（補助関数）。

    Args:
        code: Pythonコード

    Returns:
        List[str]: 抽出されたSQL文字列リスト
    """
    sql_strings = []

    # 三重引用符文字列
    triple_quote_pattern = r'(""".*?"""|\'\'\'.*?\'\'\')'
    matches = re.findall(triple_quote_pattern, code, re.DOTALL)
    for match in matches:
        if any(kw in match.upper() for kw in ["SELECT", "FROM", "UPDATE", "INSERT"]):
            sql_strings.append(match)

    # 通常の文字列
    string_pattern = r'(f?["\'].*?["\'])'
    matches = re.findall(string_pattern, code)
    for match in matches:
        if any(kw in match.upper() for kw in ["SELECT", "FROM", "UPDATE", "INSERT"]):
            sql_strings.append(match)

    return sql_strings
