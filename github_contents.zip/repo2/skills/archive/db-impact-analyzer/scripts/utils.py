"""
共通ユーティリティ関数

ロギング、JSON操作、日時フォーマット等の汎用機能を提供します。
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional


def setup_logging(
    log_file: Path,
    log_level: str = "INFO",
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
) -> logging.Logger:
    """
    ロギングを設定します。

    Args:
        log_file: ログファイルパス
        log_level: ログレベル (DEBUG/INFO/WARNING/ERROR)
        log_format: ログフォーマット

    Returns:
        logging.Logger: 設定済みロガー
    """
    # ロガー作成
    logger = logging.getLogger("db-impact-analyzer")
    logger.setLevel(getattr(logging, log_level.upper()))

    # 既存ハンドラをクリア
    logger.handlers = []

    # ファイルハンドラ
    log_file.parent.mkdir(parents=True, exist_ok=True)
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(getattr(logging, log_level.upper()))
    file_formatter = logging.Formatter(log_format)
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    # コンソールハンドラ
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter("%(levelname)s - %(message)s")
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)

    logger.info(f"ロギング初期化完了: {log_file}")

    return logger


def load_json_safe(
    json_path: Path,
    logger: Optional[logging.Logger] = None
) -> Optional[Dict[str, Any]]:
    """
    JSONファイルを安全に読み込みます。

    Args:
        json_path: JSONファイルパス
        logger: ロガー（オプション）

    Returns:
        Dict: JSON内容（失敗時はNone）
    """
    if not json_path.exists():
        if logger:
            logger.warning(f"JSONファイルが存在しません: {json_path}")
        return None

    try:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if logger:
            logger.debug(f"JSON読み込み成功: {json_path}")
        return data
    except json.JSONDecodeError as e:
        if logger:
            logger.error(f"JSON解析エラー: {json_path} - {e}")
        return None
    except Exception as e:
        if logger:
            logger.error(f"JSON読み込みエラー: {json_path} - {e}")
        return None


def save_json_safe(
    data: Dict[str, Any],
    json_path: Path,
    logger: Optional[logging.Logger] = None,
    indent: int = 2
) -> bool:
    """
    JSONファイルを安全に保存します。

    Args:
        data: 保存するデータ
        json_path: 保存先パス
        logger: ロガー（オプション）
        indent: インデント幅

    Returns:
        bool: 成功時True
    """
    try:
        json_path.parent.mkdir(parents=True, exist_ok=True)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=indent)
        if logger:
            logger.debug(f"JSON保存成功: {json_path}")
        return True
    except Exception as e:
        if logger:
            logger.error(f"JSON保存エラー: {json_path} - {e}")
        return False


def format_datetime(dt: Optional[datetime] = None, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    日時をフォーマットします。

    Args:
        dt: datetimeオブジェクト（Noneの場合は現在時刻）
        fmt: フォーマット文字列

    Returns:
        str: フォーマット済み日時文字列
    """
    if dt is None:
        dt = datetime.now()
    return dt.strftime(fmt)


def format_date(dt: Optional[datetime] = None) -> str:
    """
    日付をフォーマットします（YYYY-MM-DD形式）。

    Args:
        dt: datetimeオブジェクト（Noneの場合は現在日付）

    Returns:
        str: フォーマット済み日付文字列
    """
    return format_datetime(dt, fmt="%Y-%m-%d")


def truncate_string(text: str, max_length: int = 200, suffix: str = "...") -> str:
    """
    文字列を指定長に切り詰めます。

    Args:
        text: 元の文字列
        max_length: 最大長
        suffix: 切り詰め時の接尾辞

    Returns:
        str: 切り詰めた文字列
    """
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def ensure_dir(dir_path: Path, logger: Optional[logging.Logger] = None) -> bool:
    """
    ディレクトリを作成します（存在しない場合）。

    Args:
        dir_path: ディレクトリパス
        logger: ロガー（オプション）

    Returns:
        bool: 成功時True
    """
    try:
        dir_path.mkdir(parents=True, exist_ok=True)
        if logger:
            logger.debug(f"ディレクトリ作成: {dir_path}")
        return True
    except Exception as e:
        if logger:
            logger.error(f"ディレクトリ作成エラー: {dir_path} - {e}")
        return False


def count_lines(file_path: Path) -> int:
    """
    ファイルの行数をカウントします。

    Args:
        file_path: ファイルパス

    Returns:
        int: 行数（読み込み失敗時は0）
    """
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return sum(1 for _ in f)
    except Exception:
        return 0


def get_relative_path(file_path: Path, base_path: Path) -> str:
    """
    相対パスを取得します。

    Args:
        file_path: ファイルパス
        base_path: ベースパス

    Returns:
        str: 相対パス文字列
    """
    try:
        return str(file_path.relative_to(base_path))
    except ValueError:
        return str(file_path)
