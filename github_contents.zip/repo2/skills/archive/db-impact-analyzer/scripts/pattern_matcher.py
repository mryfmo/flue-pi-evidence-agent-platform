"""
パターンマッチングユーティリティ

正規表現ベースのマッチング、曖昧検索を提供します。
"""

import re
from typing import List, Optional, Pattern
import logging


class PatternMatcher:
    """パターンマッチングを実行するクラス"""

    def __init__(self, case_sensitive: bool = False, logger: Optional[logging.Logger] = None):
        """
        PatternMatcherを初期化します。

        Args:
            case_sensitive: 大文字小文字を区別するか
            logger: ロガー（オプション）
        """
        self.case_sensitive = case_sensitive
        self.logger = logger
        self._compiled_patterns = {}

    def match(self, pattern: str, text: str) -> bool:
        """
        パターンマッチングを実行します。

        Args:
            pattern: 正規表現パターン
            text: 検索対象テキスト

        Returns:
            bool: マッチした場合True
        """
        try:
            compiled = self._get_compiled_pattern(pattern)
            return compiled.search(text) is not None
        except re.error as e:
            if self.logger:
                self.logger.error(f"正規表現エラー: {pattern} - {e}")
            return False

    def find_all(self, pattern: str, text: str) -> List[str]:
        """
        パターンマッチングを実行し、全マッチを返します。

        Args:
            pattern: 正規表現パターン
            text: 検索対象テキスト

        Returns:
            List[str]: マッチ文字列リスト
        """
        try:
            compiled = self._get_compiled_pattern(pattern)
            return compiled.findall(text)
        except re.error as e:
            if self.logger:
                self.logger.error(f"正規表現エラー: {pattern} - {e}")
            return []

    def fuzzy_match(self, keyword: str, text: str, threshold: float = 0.8) -> bool:
        """
        曖昧マッチングを実行します（簡易版）。

        Args:
            keyword: キーワード
            text: 検索対象テキスト
            threshold: 類似度閾値 (0.0-1.0)

        Returns:
            bool: マッチした場合True
        """
        # 単純な部分一致
        keyword_lower = keyword.lower() if not self.case_sensitive else keyword
        text_lower = text.lower() if not self.case_sensitive else text

        if keyword_lower in text_lower:
            return True

        # 単語境界を考慮した検索
        words = text_lower.split()
        return any(keyword_lower in word for word in words)

    def extract_quoted_strings(self, text: str) -> List[str]:
        """
        引用符で囲まれた文字列を抽出します。

        Args:
            text: 検索対象テキスト

        Returns:
            List[str]: 抽出された文字列リスト
        """
        # ダブルクォート
        double_quoted = re.findall(r'"([^"]+)"', text)
        # シングルクォート
        single_quoted = re.findall(r"'([^']+)'", text)

        return double_quoted + single_quoted

    def extract_identifiers(self, text: str) -> List[str]:
        """
        識別子（変数名、テーブル名等）を抽出します。

        Args:
            text: 検索対象テキスト

        Returns:
            List[str]: 識別子リスト
        """
        # [a-zA-Z_][a-zA-Z0-9_]* パターン
        pattern = r'\b([a-zA-Z_][a-zA-Z0-9_]*)\b'
        return re.findall(pattern, text)

    def escape_regex(self, text: str) -> str:
        """
        正規表現の特殊文字をエスケープします。

        Args:
            text: エスケープするテキスト

        Returns:
            str: エスケープされたテキスト
        """
        return re.escape(text)

    def _get_compiled_pattern(self, pattern: str) -> Pattern:
        """
        コンパイル済みパターンを取得します（キャッシュ付き）。

        Args:
            pattern: 正規表現パターン

        Returns:
            Pattern: コンパイル済みパターン
        """
        cache_key = (pattern, self.case_sensitive)
        if cache_key not in self._compiled_patterns:
            flags = 0 if self.case_sensitive else re.IGNORECASE
            self._compiled_patterns[cache_key] = re.compile(pattern, flags)
        return self._compiled_patterns[cache_key]


def match_any_pattern(patterns: List[str], text: str, case_sensitive: bool = False) -> bool:
    """
    複数パターンのいずれかにマッチするかを判定します。

    Args:
        patterns: パターンリスト
        text: 検索対象テキスト
        case_sensitive: 大文字小文字を区別するか

    Returns:
        bool: いずれかのパターンにマッチした場合True
    """
    flags = 0 if case_sensitive else re.IGNORECASE
    for pattern in patterns:
        try:
            if re.search(pattern, text, flags):
                return True
        except re.error:
            continue
    return False


def extract_table_column_pairs(text: str) -> List[tuple]:
    """
    table.column形式のペアを抽出します。

    Args:
        text: 検索対象テキスト

    Returns:
        List[tuple]: (table, column) タプルリスト
    """
    pattern = r'([a-zA-Z_][a-zA-Z0-9_]*)\.([a-zA-Z_][a-zA-Z0-9_]*)'
    matches = re.findall(pattern, text)
    return matches
