# DB変更影響分析レポート

**生成日時**: 2026-02-27 06:22:36
**分析ID**: 20260227_062227
**変更内容定義ファイル**: /home/user/pochi-dp-developer-docs/skills/db-impact-analyzer/input/db-changes.md

---

## サマリ

| 項目 | 値 |
|-----|-----|
| 調査対象アプリ数 | 3 |
| 影響を受けるアプリ数 | 3 |
| 検出された問題総数 | 152 |
| CRITICAL（重大） | 0 |
| HIGH（高） | 8 |
| MEDIUM（中） | 113 |
| LOW（低） | 31 |
| 動的SQL検出数 | 0 |
| SELECT * 検出数 | 1 |

---

## リスク評価

### 影響度レベルの定義

- **CRITICAL**: アプリケーション起動・主要機能に必須の変更。即座の対応が必要。
- **HIGH**: 重要機能に影響する変更。優先的な対応が必要。
- **MEDIUM**: 限定的な機能に影響する変更。計画的な対応が望ましい。
- **LOW**: 影響が軽微またはほぼない変更。時間のある時に対応可能。

### 全体リスク

**中〜高リスク** - HIGH問題が8件検出されています。優先的な対応が必要です。

---

## 影響を受けるアプリケーション一覧

以下のアプリケーションで影響が検出されました：




## 1. pochi-timeseries-data-analyzer-repository

**アプリパス**: `/home/user/pochi-timeseries-data-analyzer-repository`
**最大影響度**: HIGH
**影響ファイル数**: 9
**検出問題数**: 13

### 影響度別サマリ

| 影響度 | 件数 |
|--------|-----|
| CRITICAL | 0 |
| HIGH | 8 |
| MEDIUM | 3 |
| LOW | 2 |

### 影響を受けるファイル

- `/home/user/pochi-timeseries-data-analyzer-repository/app/lib/data/sql/demographic_additional.sql`
- `/home/user/pochi-timeseries-data-analyzer-repository/app/lib/data/sql/dpoint_usage.sql`
- `/home/user/pochi-timeseries-data-analyzer-repository/app/test_apps/20241217_datatest.py`
- `/home/user/pochi-timeseries-data-analyzer-repository/app/lib/data/sql/service_contract.sql`
- `/home/user/pochi-timeseries-data-analyzer-repository/app/lib/data/sql/demographic_basic.sql`
- `/home/user/pochi-timeseries-data-analyzer-repository/app/lib/data/sql/mobile_info.sql`
- `/home/user/pochi-timeseries-data-analyzer-repository/app/lib/data/sql/dpoint_club_mau.sql`
- `/home/user/pochi-timeseries-data-analyzer-repository/app/lib/data/sql/service_usage.sql`
- `/home/user/pochi-timeseries-data-analyzer-repository/app/lib/session_manager/snowflake_sqlalchemy.py`

### 深層調査

#### dPointクラブMAU分析
- **廃止VIEW**: `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION`, `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION`
- **呼び出し連鎖**: `dpoint_club_mau.sql` → `dpoint_usage.py::get_dpoint_club_mau_data()` → `visualizer/dpoint_usage.py::visualization_dpoint_usage()` → `app_pages/timeseries_data_visualizer.py`
- **エラートリガー**: 「時系列データの可視化」ページのdPointクラブMAUグラフ描画時
- **症状**: `ProgrammingError: 002003 (02000): SQL compilation error: Object 'procdb_b_p01_lak.d_mr_000.VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION' does not exist or not authorized.` が発生し、dPointクラブMAUグラフが表示されない
- **修正対象**:
  - `app/lib/data/sql/dpoint_club_mau.sql:91`
    ```sql
    >>> procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_use_information AS u
    ```
    対応: VIEW名を代替VIEWに置換
  - `app/lib/data/sql/dpoint_club_mau.sql:94`
    ```sql
    >>> JOIN procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_basic_information AS b
    ```
    対応: VIEW名を代替VIEWに置換

#### dPointUsage分析
- **廃止VIEW**: `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION`, `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION`
- **呼び出し連鎖**: `dpoint_usage.sql` → `dpoint_usage.py::get_dpoint_usage_data()` → `visualizer/dpoint_usage.py::visualization_dpoint_usage()` → `app_pages/timeseries_data_visualizer.py`
- **エラートリガー**: 「時系列データの可視化」ページのdPoint利用額グラフ表示時
- **症状**: ProgrammingError発生によりdPoint利用状況グラフが表示されない
- **修正対象**:
  - `app/lib/data/sql/dpoint_usage.sql:96`
    ```sql
    >>> procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_use_information AS u
    ```
    対応: VIEW名を代替VIEWに置換
  - `app/lib/data/sql/dpoint_usage.sql:99`
    ```sql
    >>> JOIN procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_basic_information AS b
    ```
    対応: VIEW名を代替VIEWに置換

#### 回線契約データ分析（Mobile Info）
- **廃止VIEW**: `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION`
- **呼び出し連鎖**: `mobile_info.sql` → `mobile_info.py::get_mobile_contract_and_billing_data()` → `visualizer/mobile_info.py::visualization_mobile_contract_and_billing_data()` → `app_pages/timeseries_data_visualizer.py`
- **エラートリガー**: 「時系列データの可視化」ページの「📱回線契約データ」セクション描画時
- **症状**: ProgrammingError発生により回線契約グラフが表示されない
- **修正対象**:
  - `app/lib/data/sql/mobile_info.sql:8`
    ```sql
    >>> procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_basic_information AS m
    ```
    対応: VIEW名を代替VIEWに置換

#### サービス利用状況分析
- **廃止VIEW**: `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION`
- **呼び出し連鎖**: `service_usage.sql` → `service_usage.py::get_service_usage_data()` → `visualizer/service_usage.py::visualization_service_usage()` → `app_pages/timeseries_data_visualizer.py`
- **エラートリガー**: 「時系列データの可視化」ページのサービス利用状況グラフ表示時
- **症状**: ProgrammingError発生によりサービス利用状況グラフが表示されない
- **修正対象**:
  - `app/lib/data/sql/service_usage.sql:5`
    ```sql
    >>> procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_use_information AS m
    ```
    対応: VIEW名を代替VIEWに置換

#### サービス契約状況分析
- **廃止VIEW**: `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION`
- **呼び出し連鎖**: `service_contract.sql` → `service_contract.py::get_service_contract_data()` → `visualizer/service_contract.py::visualization_service_contract()` → `app_pages/timeseries_data_visualizer.py`
- **エラートリガー**: 「時系列データの可視化」ページのサービス契約状況グラフ表示時
- **症状**: ProgrammingError発生によりサービス契約状況グラフが表示されない
- **修正対象**:
  - `app/lib/data/sql/service_contract.sql:46`
    ```sql
    >>> procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_basic_information AS m
    ```
    対応: VIEW名を代替VIEWに置換

#### 顧客属性分析（Demographic）
- **廃止VIEW**: `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION`
- **呼び出し連鎖**: `demographic_basic.sql`, `demographic_additional.sql` → `demographic.py::get_demographic_basic_raw_data()`, `get_demographic_additional_raw_data()` → 各統計関数（`get_gender_summary()`, `get_age_summary()` 等） → `app_pages/timeseries_data_visualizer.py`
- **エラートリガー**: 「時系列データの可視化」ページの性別・年代・地方などの顧客属性グラフ表示時
- **症状**: ProgrammingError発生により全ての顧客属性グラフが表示されない
- **修正対象**:
  - `app/lib/data/sql/demographic_basic.sql:117`
    ```sql
    >>> procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_basic_information AS m
    ```
    対応: VIEW名を代替VIEWに置換
  - `app/lib/data/sql/demographic_basic.sql:127`
    ```sql
    >>> procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_basic_information
    ```
    対応: VIEW名を代替VIEWに置換
  - `app/lib/data/sql/demographic_additional.sql:89`
    ```sql
    >>> procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_basic_information AS m
    ```
    対応: VIEW名を代替VIEWに置換
  - `app/lib/data/sql/demographic_additional.sql:99`
    ```sql
    >>> procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_basic_information
    ```
    対応: VIEW名を代替VIEWに置換

#### テストアプリ（20241217_datatest.py）
- **廃止VIEW**: `VUSER_CUST_INFO`
- **呼び出し連鎖**: `20241217_datatest.py::get_acctid_list()` → テストケース実行時
- **エラートリガー**: テストアプリ起動時、アカウント識別子リスト取得フェーズ
- **症状**: ProgrammingError発生によりテスト自体が起動できない（`test_apps/` 配下のテストファイルへの影響）
- **修正対象**:
  - `app/test_apps/20241217_datatest.py:289`
    ```python
    >>> sql = "select acctid from procdb_b_p01_lak.d_ma_000.vuser_cust_info limit %(rows)s"
    ```
    対応: VIEW名を代替VIEWに置換（代替VIEWが存在しない場合はテストを無効化を検討）

#### ORM経由の廃止VIEW参照

ORM経由の廃止VIEW参照なし（`VwAllArpu` クラスは `vw_all_arpu` を参照しており、廃止対象外）

### Snowflakeクエリヒストリー検証

> 調査期間: 過去180日間

#### VIEWごとの検出状況

| 廃止VIEW名 | 過去180日の実行件数 | 最終実行日時 | 実行ユーザー（サービス）例 |
|----------|--------------|------------|----------|
| `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` | 1,090件（timeseries-data-analyzer: 376件） | 2026-02-27 14:53 JST | timeseries-data-analyzer, target-vol-of-specific-char, user-behavior-map |
| `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | 9,539件（timeseries-data-analyzer: 773件） | 2026-02-27 14:54 JST | timeseries-data-analyzer, settlement-by-region, katikan |
| `VUSER_CUST_INFO` | **0件** | - | - |

#### 要約・所見

- `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` は過去180日以内に本番で376件実行されており（timeseries-data-analyzerから）、廃止時に即時エラーが発生するリスクあり
- `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` は過去180日以内に本番で773件実行されており（timeseries-data-analyzerから）、廃止時に即時エラーが発生するリスクあり
- `VUSER_CUST_INFO` はクエリヒストリーに存在しない（テストコードの参照のみで現在未実行の可能性）

#### 実行クエリ

```sql
SELECT
    plan.PHYSICAL_NAME AS physical_view_name,
    REGEXP_SUBSTR(H.QUERY_TAG, 'service:([^,]+)', 1, 1, 'e', 1) AS service_name,
    COUNT(*) AS usage_count,
    MAX(H.QUERY_START_TIME) AS latest_access_time,
    MIN(H.QUERY_START_TIME) AS earliest_access_time
FROM
    PROCDB_B_P01_LAK.S_CM_000.VW_COM_ACCESS_AND_QUERY_HISTORY H,
    LATERAL FLATTEN(input => H.DIRECT_OBJECTS_ACCESSED) F
    INNER JOIN USERDB_B_P01_LAK.USER_MP001_01.A_DWH_MASTER_20251215 plan
        ON F.value:"objectName"::string LIKE '%' || plan.PHYSICAL_NAME || '%'
WHERE
    plan.PHYSICAL_NAME IN ('VW_ADM_DNCD_DEALER_DETAILS_MASTER', 'VW_ADM_DNCL_COMNID_INTEGRATION', 'VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER', 'VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER', 'VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER', 'VW_DIC_DNHD_CUSTOMER_CHANGE_MB', 'VW_DIC_DNHD_SETTLEMENT_INTEGRATION', 'VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB', 'VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION', 'VW_DIC_MECL_TRAFFIC_INTEGRATION_MB', 'VUSER_CUST_INFO', 'VUSER_SO_CONTRACT_CURRENT', 'VW_DMC_HNCL_SO_CONTRACT_CURRENT', 'VW_ADM_DNCD_BASIC_CONTRACT_MB', 'VW_ADW_DNCD_SERVICE_BASIC_2_MB', 'VW_ADW_DNCD_SERVICE_BASIC_3_MB', 'VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION')
    AND YEAR(H.QUERY_START_TIME) >= 2026
    AND H.QUERY_START_TIME >= DATEADD('day', -180, CURRENT_TIMESTAMP())
    AND H.QUERY_TAG LIKE '%from:pochi%'
    AND H.QUERY_TAG LIKE '%service:%'
GROUP BY
    plan.PHYSICAL_NAME,
    service_name
ORDER BY
    physical_view_name,
    usage_count DESC
```

---



## 2. pochi-user-behavior-map-repository

**アプリパス**: `/home/user/pochi-user-behavior-map-repository`
**最大影響度**: MEDIUM
**影響ファイル数**: 25
**検出問題数**: 137

### 影響度別サマリ

| 影響度 | 件数 |
|--------|-----|
| CRITICAL | 0 |
| HIGH | 0 |
| MEDIUM | 110 |
| LOW | 27 |

### 影響を受けるファイル

- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/assets/get_user_locations_from_dpay_data.sql.j2`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/_get_user_list_and_attribute_data.py`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/assets/create_user_list.sql.j2`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/assets/get_latest_date_section/vw_dic_mecl_traffic_integration_mb.sql`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/priceplan_selector/assets/get_latest_date_section_from_classifiedbyaction_fee_master.sql`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/assets/get_user_list_and_attribute_data.sql.j2`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/assets/get_latest_date_section/vw_dic_mecd_member_profile_use_information.sql`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/assets/aggregate_by_stay_area.sql.j2`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/_get_terminal_type_list.py`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/assets/aggregate_by_dpay_merchant_and_time.sql.j2`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/priceplan_selector/assets/price_plan_list.sql`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/_dpay_settlement_data.py`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/components/stay_area_point_selector/_get_stay_area_point_list.py`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/assets/get_terminal_type_list.sql`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/_get_latest_date_section.py`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/address_selector/_get_address_master.py`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/_stay_area_data.py`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/_holiday_data.py`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/assets/aggregate_by_dpay_merchant.sql.j2`
- `/home/user/pochi-user-behavior-map-repository/app/mylib/data_loader/assets/get_holiday_data.sql`
- ...他5件

### 深層調査

#### 料金プラン選択機能
- **廃止VIEW**: `VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER`
- **呼び出し連鎖**: `price_plan_list.sql` → `_get_price_plan_list.py::get_price_plan_list()` → `user_behavior_analysis_tools.py::PricePlanSelector`
- **エラートリガー**: PricePlanSelector コンポーネント初期化時（画面読み込み時）
- **症状**: ProgrammingError発生により料金プラン一覧取得がエラーになり、画面のプルダウン初期化に失敗
- **修正対象**:
  - `app/mylib/priceplan_selector/assets/price_plan_list.sql:11`
    ```sql
    >>> FROM procdb_b_p01_lak.l_mr_000.vw_adm_mecl_classifiedbyaction_fee_master
    ```
    対応: 廃止VIEW参照を代替VIEWに置換
  - `app/mylib/priceplan_selector/assets/get_latest_date_section_from_classifiedbyaction_fee_master.sql:4`
    ```sql
    >>> FROM procdb_b_p01_lak.l_mr_000.vw_adm_mecl_classifiedbyaction_fee_master
    ```
    対応: 廃止VIEW参照を代替VIEWに置換

#### 端末タイプ選択機能
- **廃止VIEW**: `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB`
- **呼び出し連鎖**: `get_terminal_type_list.sql` → `_get_terminal_type_list.py::get_terminal_type_list()` → `user_behavior_analysis_tools.py`（端末フィルタ）
- **エラートリガー**: 端末タイプフィルター有効時のユーザーリスト作成画面
- **症状**: ProgrammingError発生により端末タイプ一覧取得失敗・端末フィルタのドロップダウンが表示されない
- **修正対象**:
  - `app/mylib/data_loader/assets/get_terminal_type_list.sql:4`
    ```sql
    >>> FROM procdb_b_p01_lak.d_mr_000.vw_dic_mecd_classifiedbyaction_customer_mb
    ```
    対応: 廃止VIEW参照を代替VIEWに置換
  - `app/mylib/data_loader/assets/get_latest_date_section/vw_dic_mecd_classifiedbyaction_customer_mb.sql:4`
    ```sql
    >>> FROM procdb_b_p01_lak.d_mr_000_sa.vw_dic_mecd_classifiedbyaction_customer_mb
    ```
    対応: 廃止VIEW参照を代替VIEWに置換

#### マイショップ店舗選択機能
- **廃止VIEW**: `VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER`
- **呼び出し連鎖**: `get_my_shop_store_list.sql` → `_get_my_shop_store_list.py::get_my_shop_store_list()` → `user_behavior_analysis_tools.py`
- **エラートリガー**: マイショップフィルター有効化時
- **症状**: ProgrammingError発生により店舗一覧取得失敗・地域・店舗選択画面が表示されない
- **修正対象**:
  - `app/mylib/data_loader/assets/get_my_shop_store_list.sql:16`
    ```sql
    >>> FROM procdb_b_p01_lak.l_mr_000.vw_adw_dncl_store_information_management_master
    ```
    対応: 廃止VIEW参照を代替VIEWに置換

#### 祝日データ取得機能
- **廃止VIEW**: `VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER`
- **呼び出し連鎖**: `get_holiday_data.sql` → `_holiday_data.py::get_holiday_data()` → 日付フィルタ処理（内部利用）
- **エラートリガー**: 祝日フィルター有効化時
- **症状**: ProgrammingError発生により祝日データ取得失敗・祝日を含める/除外する機能が動作しない
- **修正対象**:
  - `app/mylib/data_loader/assets/get_holiday_data.sql:5`
    ```sql
    >>> FROM procdb_b_p01_lak.l_mr_000.vw_adw_dncl_public_holiday_master
    ```
    対応: 廃止VIEW参照を代替VIEWに置換

#### ユーザーリスト・属性データ取得（Jinja2テンプレートSQL）
- **廃止VIEW**: `VW_DIC_DNHD_SETTLEMENT_INTEGRATION`, `VUSER_CUST_INFO`, `VUSER_SO_CONTRACT_CURRENT`, `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB`, `VW_ADM_DNCD_DEALER_DETAILS_MASTER`, `VW_DIC_DNHD_CUSTOMER_CHANGE_MB`, `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION`
- **呼び出し連鎖**: `get_user_list_and_attribute_data.sql.j2` → `_get_user_list_and_attribute_data.py::get_user_list_and_attribute_data()` → `user_behavior_analysis_tools.py::create_filtered_user_list()`
- **エラートリガー**: ユーザーリスト作成時、対応するフィルター有効化時（条件分岐依存）
- **症状**: ProgrammingError発生により特定フィルター有効時にのみユーザーリスト作成が失敗
- **修正対象（Jinja2条件分岐別）**:
  - `app/mylib/data_loader/assets/get_user_list_and_attribute_data.sql.j2:87` （`{% if enable_merchant_store_filter %}`）
    ```sql
    >>> FROM procdb_b_p01_lak.d_mr_000.vw_dic_dnhd_settlement_integration
    ```
    対応: d払い決済フィルター有効時のVIEW参照を代替VIEWに置換
  - `app/mylib/data_loader/assets/get_user_list_and_attribute_data.sql.j2:139` （`{% if enable_last_contact_channel %}`）
    ```sql
    >>> FROM procdb_b_p01_lak.d_mr_000.vw_adm_dncd_dealer_details_master
    ```
    対応: 最終接点チャネルフィルター有効時のVIEW参照を代替VIEWに置換
  - `app/mylib/data_loader/assets/get_user_list_and_attribute_data.sql.j2:155` （`{% if enable_last_contact_channel %}`）
    ```sql
    >>> FROM procdb_b_p01_lak.d_mr_000.vw_dic_dnhd_customer_change_mb AS customer_change_mb
    ```
    対応: 最終接点チャネルフィルター有効時のVIEW参照を代替VIEWに置換
  - `app/mylib/data_loader/assets/get_user_list_and_attribute_data.sql.j2:180-191` （`{% if enable_gender/age_era/contract_shisha %}`）
    ```sql
    >>> WHEN (vuser_cust_info.dpntc_memb_utlr_atr_cd_dpfi IS NOT NULL ...
    ```
    対応: 性別・年代・契約支社属性フィルター有効時のVUSER_CUST_INFO参照を代替VIEWに置換
  - `app/mylib/data_loader/assets/get_user_list_and_attribute_data.sql.j2:286` （`{% if enable_price_plan %}`）
    ```sql
    >>> LEFT JOIN procdb_b_p01_lak.d_ma_000.vuser_so_contract_current as vuser_so_contract_current
    ```
    対応: 料金プランフィルター有効時のVIEW参照を代替VIEWに置換
  - `app/mylib/data_loader/assets/get_user_list_and_attribute_data.sql.j2:291` （`{% if enable_terminal %}`）
    ```sql
    >>> LEFT JOIN procdb_b_p01_lak.d_mr_000.vw_dic_mecd_classifiedbyaction_customer_mb
    ```
    対応: 端末フィルター有効時のVIEW参照を代替VIEWに置換

#### d払い決済集計・滞在エリア集計（Jinja2テンプレートSQL）
- **廃止VIEW**: `VW_DIC_DNHD_SETTLEMENT_INTEGRATION`, `VUSER_CUST_INFO`
- **呼び出し連鎖**: 各Jinja2テンプレート → `_dpay_settlement_data.py` / `_stay_area_data.py` → `user_behavior_analysis_tools.py::visualize_map()`
- **エラートリガー**: マップビジュアライゼーション表示時、集計実行時
- **症状**: ProgrammingError発生によりd払い決済データ/滞在エリア集計が失敗しマップが表示されない
- **修正対象**:
  - `app/mylib/data_loader/assets/aggregate_by_dpay_merchant_and_time.sql.j2:43`
    ```sql
    >>> FROM procdb_b_p01_lak.d_mr_000.vw_dic_dnhd_settlement_integration
    ```
    対応: 代替VIEWに置換
  - `app/mylib/data_loader/assets/aggregate_by_stay_area.sql.j2:43,45,50,51`
    ```sql
    >>> LEFT JOIN procdb_b_p01_lak.d_ma_000.vuser_cust_info as vuser_cust_info
    ```
    対応: 代替VIEWに置換
  - `app/mylib/data_loader/assets/get_user_locations_from_dpay_data.sql.j2:24`
    ```sql
    >>> FROM procdb_b_p01_lak.d_mr_000.vw_dic_dnhd_settlement_integration
    ```
    対応: 代替VIEWに置換
  - `app/mylib/data_loader/assets/aggregate_by_dpay_merchant.sql.j2:48,70-76`
    ```sql
    >>> FROM procdb_b_p01_lak.d_mr_000.vw_dic_dnhd_settlement_integration
    >>> LEFT JOIN procdb_b_p01_lak.d_ma_000.vuser_cust_info as vuser_cust_info
    ```
    対応: 代替VIEWに置換

#### ユーザーリスト作成（create_user_list.sql.j2）
- **廃止VIEW**: `VW_ADM_DNCL_COMNID_INTEGRATION`, `VUSER_CUST_INFO`, `VUSER_SO_CONTRACT_CURRENT`, `VW_ADM_DNCD_BASIC_CONTRACT_MB`, `VW_ADW_DNCD_SERVICE_BASIC_2_MB`, `VW_ADW_DNCD_SERVICE_BASIC_3_MB`, `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB`, `VW_DIC_MECL_TRAFFIC_INTEGRATION_MB`, `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION`, `VW_ADM_DNCD_DEALER_DETAILS_MASTER`, `VW_DIC_DNHD_CUSTOMER_CHANGE_MB`
- **呼び出し連鎖**: `create_user_list.sql.j2` → `_create_filtered_user_list.py::create_filtered_user_list()` → `user_behavior_analysis_tools.py`
- **エラートリガー**: 各フィルター条件有効時のユーザーリスト作成実行
- **症状**: ProgrammingError発生により対応フィルター有効時にのみユーザーリスト投入が失敗
- **修正対象（主要な廃止VIEW参照箇所）**:
  - `app/mylib/data_loader/assets/create_user_list.sql.j2:8` （`{% if enable_service_contract_filter %}`）: `VW_ADM_DNCL_COMNID_INTEGRATION` → 代替VIEWに置換
  - `app/mylib/data_loader/assets/create_user_list.sql.j2:28` （常時）: `VUSER_CUST_INFO` → 代替VIEWに置換
  - `app/mylib/data_loader/assets/create_user_list.sql.j2:111-120` （`{% if enable_service_contract_filter %}`）: `VUSER_SO_CONTRACT_CURRENT`, `VW_ADM_DNCD_BASIC_CONTRACT_MB`, `VW_ADW_DNCD_SERVICE_BASIC_2_MB`, `VW_ADW_DNCD_SERVICE_BASIC_3_MB` → 代替VIEWに置換
  - `app/mylib/data_loader/assets/create_user_list.sql.j2:320` （`{% if enable_terminal_user_info_filter %}`）: `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` → 代替VIEWに置換
  - `app/mylib/data_loader/assets/create_user_list.sql.j2:377` （`{% if enable_traffic_usage_filter %}`）: `VW_DIC_MECL_TRAFFIC_INTEGRATION_MB` → 代替VIEWに置換
  - `app/mylib/data_loader/assets/create_user_list.sql.j2:483` （`{% if enable_member_profile_use_information_filter %}`）: `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` → 代替VIEWに置換
  - `app/mylib/data_loader/assets/create_user_list.sql.j2:525-535` （`{% if enable_last_contact_channel_filter %}`）: `VW_ADM_DNCD_DEALER_DETAILS_MASTER`, `VW_DIC_DNHD_CUSTOMER_CHANGE_MB` → 代替VIEWに置換

#### ORM経由の廃止VIEW参照

ORM経由の廃止VIEW参照なし（`StayAreaMaster` クラスは `USPIDB_N_P01_LAK.USER_SENSE_01.STAY_AREA_MASTER` を参照しており、廃止対象外）

### Snowflakeクエリヒストリー検証

> 調査期間: 過去180日間

#### VIEWごとの検出状況（このアプリ関連分）

| 廃止VIEW名 | 過去180日の実行件数 | 最終実行日時 | user-behavior-mapからの実行件数 |
|----------|--------------|------------|----------|
| `VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER` | 3,326件（合計） | 2026-02-27 14:38 JST | 104件 |
| `VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER` | 271件（合計） | 2026-02-26 17:14 JST | 16件 |
| `VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER` | 1,299件（合計） | 2026-02-26 17:56 JST | 15件 |
| `VW_DIC_DNHD_CUSTOMER_CHANGE_MB` | 6,913件（合計） | 2026-02-27 14:38 JST | 32件 |
| `VW_DIC_DNHD_SETTLEMENT_INTEGRATION` | 16,376件（合計） | 2026-02-27 14:56 JST | 407件 |
| `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` | 6,677件（合計） | 2026-02-27 14:27 JST | 84件 |
| `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` | 1,090件（合計） | 2026-02-27 14:53 JST | 41件 |
| `VW_DIC_MECL_TRAFFIC_INTEGRATION_MB` | 1,363件（合計） | 2026-02-27 14:38 JST | 42件 |
| `VUSER_CUST_INFO` | **0件** | - | - |
| `VUSER_SO_CONTRACT_CURRENT` | **0件** | - | - |
| `VW_ADM_DNCL_COMNID_INTEGRATION` | 3,097件（合計） | 2026-02-27 14:57 JST | 471件 |
| `VW_ADM_DNCD_BASIC_CONTRACT_MB` | 1,722件（合計） | 2026-02-27 14:19 JST | 33件 |
| `VW_ADW_DNCD_SERVICE_BASIC_2_MB` | 628件（合計） | 2026-02-27 13:03 JST | 29件 |
| `VW_ADW_DNCD_SERVICE_BASIC_3_MB` | 909件（合計） | 2026-02-27 13:03 JST | 29件 |
| `VW_ADM_DNCD_DEALER_DETAILS_MASTER` | 2,379件（合計） | 2026-02-27 14:46 JST | 32件 |

#### 要約・所見

- `VW_DIC_DNHD_SETTLEMENT_INTEGRATION` はuser-behavior-mapから過去180日で407件実行されており、廃止時に即時エラーのリスクが最も高い
- `VW_ADM_DNCL_COMNID_INTEGRATION` はuser-behavior-mapから471件実行されており、ユーザーリスト作成機能への影響が大きい
- `VUSER_CUST_INFO` および `VUSER_SO_CONTRACT_CURRENT` はクエリヒストリーに存在しない（コード参照は残っているが現在未実行の可能性）

#### 実行クエリ

```sql
SELECT
    plan.PHYSICAL_NAME AS physical_view_name,
    REGEXP_SUBSTR(H.QUERY_TAG, 'service:([^,]+)', 1, 1, 'e', 1) AS service_name,
    COUNT(*) AS usage_count,
    MAX(H.QUERY_START_TIME) AS latest_access_time,
    MIN(H.QUERY_START_TIME) AS earliest_access_time
FROM
    PROCDB_B_P01_LAK.S_CM_000.VW_COM_ACCESS_AND_QUERY_HISTORY H,
    LATERAL FLATTEN(input => H.DIRECT_OBJECTS_ACCESSED) F
    INNER JOIN USERDB_B_P01_LAK.USER_MP001_01.A_DWH_MASTER_20251215 plan
        ON F.value:"objectName"::string LIKE '%' || plan.PHYSICAL_NAME || '%'
WHERE
    plan.PHYSICAL_NAME IN ('VW_ADM_DNCD_DEALER_DETAILS_MASTER', 'VW_ADM_DNCL_COMNID_INTEGRATION', 'VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER', 'VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER', 'VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER', 'VW_DIC_DNHD_CUSTOMER_CHANGE_MB', 'VW_DIC_DNHD_SETTLEMENT_INTEGRATION', 'VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB', 'VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION', 'VW_DIC_MECL_TRAFFIC_INTEGRATION_MB', 'VUSER_CUST_INFO', 'VUSER_SO_CONTRACT_CURRENT', 'VW_DMC_HNCL_SO_CONTRACT_CURRENT', 'VW_ADM_DNCD_BASIC_CONTRACT_MB', 'VW_ADW_DNCD_SERVICE_BASIC_2_MB', 'VW_ADW_DNCD_SERVICE_BASIC_3_MB', 'VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION')
    AND YEAR(H.QUERY_START_TIME) >= 2026
    AND H.QUERY_START_TIME >= DATEADD('day', -180, CURRENT_TIMESTAMP())
    AND H.QUERY_TAG LIKE '%from:pochi%'
    AND H.QUERY_TAG LIKE '%service:%'
GROUP BY
    plan.PHYSICAL_NAME,
    service_name
ORDER BY
    physical_view_name,
    usage_count DESC
```

---



## 3. pochi-docomo-zero-order-analysis-repository

**アプリパス**: `/home/user/pochi-docomo-zero-order-analysis-repository`
**最大影響度**: LOW
**影響ファイル数**: 1
**検出問題数**: 2

### 影響度別サマリ

| 影響度 | 件数 |
|--------|-----|
| CRITICAL | 0 |
| HIGH | 0 |
| MEDIUM | 0 |
| LOW | 2 |

### 影響を受けるファイル

- `/home/user/pochi-docomo-zero-order-analysis-repository/app/01_📈ゼロ次分析ツール.py`

### 深層調査

#### ゼロ次分析ツール（決済統合ジャンル検索・店舗詳細機能）
- **廃止VIEW**: `VW_DIC_DNHD_SETTLEMENT_INTEGRATION`
- **呼び出し連鎖**: `sql.py::get_sql("settlement_target_sql")`, `get_sql("settlement_store_target_sql")`, `get_sql("store_detail_sql")` → `functions.py::display_result()` → `01_📈ゼロ次分析ツール.py::page()`
- **エラートリガー**: 決済統合ジャンル検索を選択して「実行」ボタン押下時、「店舗一覧を取得」ボタン押下時
- **症状**: ProgrammingError発生によりユーザーがターゲット検索を実行できない
- **修正対象**:
  - `app/functions/sql.py:238`
    ```sql
    >>> from "PROCDB_B_P01_LAK"."D_MR_000"."VW_DIC_DNHD_SETTLEMENT_INTEGRATION"
    ```
    対応: 代替VIEWに置換（代替VIEW名をドコモデータ管理チームに確認）
  - `app/functions/sql.py:253`
    ```sql
    >>> from "PROCDB_B_P01_LAK"."D_MR_000"."VW_DIC_DNHD_SETTLEMENT_INTEGRATION"
    ```
    対応: 同上
  - `app/functions/sql.py:341`
    ```sql
    >>> from "PROCDB_B_P01_LAK"."D_MR_000"."VW_DIC_DNHD_SETTLEMENT_INTEGRATION"
    ```
    対応: 同上

#### ゼロ次分析ツール（デモグラフィック集計機能）
- **廃止VIEW**: `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION`
- **呼び出し連鎖**: `sql.py::get_sql("summary_sql")` → `functions.py::display_result()` → `01_📈ゼロ次分析ツール.py::page()`, `02_🔍実行履歴.py::page()`
- **エラートリガー**: 分析実行時（「実行」ボタン押下時）、過去の分析結果表示時
- **症状**: ProgrammingError発生によりデモグラフィック情報のタブが表示されずエラーが発生
- **修正対象**:
  - `app/functions/sql.py:42`
    ```sql
    >>> from "PROCDB_B_P01_LAK"."D_MR_000"."VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION" as t1
    ```
    対応: 代替VIEWに置換
  - `app/functions/sql.py:88`
    ```sql
    >>> left outer join "PROCDB_B_P01_LAK"."D_MR_000"."VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION" as p
    ```
    対応: 同上

#### ORM経由の廃止VIEW参照

ORM経由の廃止VIEW参照なし

### Snowflakeクエリヒストリー検証

> 調査期間: 過去180日間

#### VIEWごとの検出状況（このアプリ関連分）

| 廃止VIEW名 | 過去180日の実行件数（合計） | 最終実行日時 | docomo-zero-order-analysisからの実行件数 |
|----------|--------------|------------|----------|
| `VW_DIC_DNHD_SETTLEMENT_INTEGRATION` | 16,376件（合計） | 2026-02-27 14:56 JST | 21件 |
| `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | 9,539件（合計） | 2026-02-27 14:54 JST | 20件 |

#### 要約・所見

- `VW_DIC_DNHD_SETTLEMENT_INTEGRATION` はdocomo-zero-order-analysisから過去180日で21件実行されており、廃止時にエラーが発生するリスクあり
- `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` はdocomo-zero-order-analysisから20件実行されており、デモグラフィック集計機能に影響する
- 自動スキャンではLOW（SELECT*とpochilib呼び出し）のみ検出されたが、深層調査によりsql.pyに廃止VIEW参照が発見された。修正が必要

#### 実行クエリ

```sql
SELECT
    plan.PHYSICAL_NAME AS physical_view_name,
    REGEXP_SUBSTR(H.QUERY_TAG, 'service:([^,]+)', 1, 1, 'e', 1) AS service_name,
    COUNT(*) AS usage_count,
    MAX(H.QUERY_START_TIME) AS latest_access_time,
    MIN(H.QUERY_START_TIME) AS earliest_access_time
FROM
    PROCDB_B_P01_LAK.S_CM_000.VW_COM_ACCESS_AND_QUERY_HISTORY H,
    LATERAL FLATTEN(input => H.DIRECT_OBJECTS_ACCESSED) F
    INNER JOIN USERDB_B_P01_LAK.USER_MP001_01.A_DWH_MASTER_20251215 plan
        ON F.value:"objectName"::string LIKE '%' || plan.PHYSICAL_NAME || '%'
WHERE
    plan.PHYSICAL_NAME IN ('VW_ADM_DNCD_DEALER_DETAILS_MASTER', 'VW_ADM_DNCL_COMNID_INTEGRATION', 'VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER', 'VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER', 'VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER', 'VW_DIC_DNHD_CUSTOMER_CHANGE_MB', 'VW_DIC_DNHD_SETTLEMENT_INTEGRATION', 'VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB', 'VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION', 'VW_DIC_MECL_TRAFFIC_INTEGRATION_MB', 'VUSER_CUST_INFO', 'VUSER_SO_CONTRACT_CURRENT', 'VW_DMC_HNCL_SO_CONTRACT_CURRENT', 'VW_ADM_DNCD_BASIC_CONTRACT_MB', 'VW_ADW_DNCD_SERVICE_BASIC_2_MB', 'VW_ADW_DNCD_SERVICE_BASIC_3_MB', 'VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION')
    AND YEAR(H.QUERY_START_TIME) >= 2026
    AND H.QUERY_START_TIME >= DATEADD('day', -180, CURRENT_TIMESTAMP())
    AND H.QUERY_TAG LIKE '%from:pochi%'
    AND H.QUERY_TAG LIKE '%service:%'
GROUP BY
    plan.PHYSICAL_NAME,
    service_name
ORDER BY
    physical_view_name,
    usage_count DESC
```

---



---

## 次のステップ（アクションリスト）

1. **[ ] HIGH対応（優先的に対応）**
   - 8件のHIGH問題を確認・修正してください
   - ビジネス機能への影響度を個別に評価
   - 代替VIEWが存在する場合はVIEW名を置換、存在しない場合は機能を無効化

2. **[ ] MEDIUM/LOW対応（計画的に対応）**
   - 113件のMEDIUM、31件のLOW問題を確認してください
   - 影響度を確認し、必要に応じて修正

3. **[ ] pochi-docomo-zero-order-analysis-repositoryの再評価**
   - 自動スキャンではLOW判定だったが、深層調査により `app/functions/sql.py` に廃止VIEW参照を発見
   - `VW_DIC_DNHD_SETTLEMENT_INTEGRATION`（21件実行）、`VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION`（20件実行）が対象
   - MEDIUMレベルの対応が必要

---

**レポート生成日時**: 2026-02-27 06:22:36
