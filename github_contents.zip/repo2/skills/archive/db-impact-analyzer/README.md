# db-impact-analyzer

DB変更影響分析Skill

## クイックスタート

### 方法1: 環境変数 + 対話形式（推奨）

最もシンプルな方法です。リポジトリ名のみで実行できます。

```bash
# 環境変数でデフォルト設定
export DB_CHANGE_REPOSITORIES="pochi-sales-dashboard,pochi-inventory-app"
export DB_CHANGE_BASE_PATH="/home/user"

# Skillを実行
cd .claude/skills/db-impact-analyzer
python skill_entry.py
```

インプットファイルは `input/` ディレクトリに配置してください。1件のみの場合は自動選択されます。

### 方法2: db-changes.mdファイル（新形式）

リポジトリ名のみを記載するシンプルな形式です。

**インプットファイルの配置**:
```bash
# input/ ディレクトリにファイルを配置
cp your-db-changes.md .claude/skills/db-impact-analyzer/input/db-changes.md
```

**db-changes.md**:
```markdown
## 調査対象アプリケーション

**ベースパス**: /home/user

**リポジトリ**:
- pochi-sales-dashboard
- pochi-inventory-app
- pochi-analytics
```

実行：
```bash
cd .claude/skills/db-impact-analyzer
python skill_entry.py
# input/ 内のファイルが自動検出されます
```

### 方法3: db-changes.mdファイル（旧形式・後方互換）

絶対パスでの指定も引き続きサポートされています。

**db-changes.md**:
```markdown
## 調査対象アプリケーション

- /home/user/pochi-sales-dashboard/
- /home/user/pochi-inventory-app/
```

### レポート確認

生成されたレポートを確認します：

```bash
cat reports/impact-report.md
```

## 主要機能

### 1. DB変更内容解析

- テーブル廃止、カラム削除、リネーム等を自動検出
- 検索キーワードを自動生成

### 2. コードスキャン

- Pythonコード内のSQL文字列を解析
- SQLAlchemy等のORMモデルを検出
- 動的SQL生成を警告

### 3. 影響度分析

- CRITICAL/HIGH/MEDIUM/LOWで分類
- ファイルパス、クエリタイプから自動判定

### 4. レポート生成

- Markdown形式の詳細レポート
- アプリ別サマリ
- 推奨対応アクション

### 5. 機能影響分析（NEW）

- ファイルパスから影響を受ける機能を特定
- ビジネス視点の影響説明（ユーザー影響、推奨対応）
- マッピング設定による高精度分析
- 未設定でもパターンマッチングでフォールバック

**機能マッピング設定例**（`config/app_feature_mapping.json`）:
```json
{
  "repositories": {
    "pochi-sales-dashboard": {
      "features": {
        "sales_report": {
          "name": "売上レポート機能",
          "description": "日次売上データの集計とダッシュボード表示",
          "file_patterns": ["/reporting/.*sales", "/dashboard/.*sales"],
          "user_impact": "売上ダッシュボードが表示されなくなる",
          "affected_users": "営業チーム全員",
          "urgency_default": "high",
          "recommended_action": "テーブル名を新しいビュー名に変更してください"
        }
      }
    }
  }
}
```

**レポート出力例**:
```markdown
#### 🟡 売上レポート機能

- **影響度**: HIGH
- **機能概要**: 日次売上データの集計とダッシュボード表示
- **想定される影響**: 売上ダッシュボードが表示されなくなる
- **影響範囲**: 営業チーム全員
- **対応の緊急度**: 高 - 即座に対応が必要

**推奨対応**:
テーブル名を新しいビュー名に変更してください
```

## ディレクトリ構造

```
db-impact-analyzer/
├── core/                  # コアロジック
│   ├── state.py           # 状態管理
│   ├── change_parser.py   # DB変更解析
│   ├── code_scanner.py    # コードスキャン
│   ├── impact_analyzer.py # 影響度分析
│   └── report_builder.py  # レポート生成
├── scripts/               # ユーティリティ
│   ├── utils.py           # 共通関数
│   ├── file_utils.py      # ファイル操作
│   ├── sql_parser.py      # SQL解析
│   ├── orm_parser.py      # ORM解析
│   └── pattern_matcher.py # パターンマッチング
├── config/                # 設定ファイル
│   ├── default_config.json
│   ├── detection_patterns.json
│   ├── severity_rules.json
│   ├── feature_patterns.json        # 機能名パターン（フォールバック用）
│   └── app_feature_mapping.json     # 機能マッピング（高精度分析用）
├── templates/             # レポートテンプレート
│   ├── impact_header.md
│   ├── app_section.md
│   ├── issue_detail.md
│   ├── feature_impact.md            # 機能影響セクション
│   └── feature_impact_detailed.md   # 機能影響セクション（詳細版）
├── logs/                  # ログ出力先
├── reports/               # レポート出力先
├── skill_entry.py         # エントリポイント
├── SKILL.md               # Skill定義
└── README.md              # このファイル
```

## カスタマイズ

### 検出パターンの追加

`config/detection_patterns.json`を編集：

```json
{
  "sql": {
    "table_references": {
      "patterns": [
        "FROM\\s+([a-zA-Z_][a-zA-Z0-9_]*)",
        "あなたのパターン"
      ]
    }
  }
}
```

### 影響度ルールの調整

`config/severity_rules.json`を編集：

```json
{
  "severity_levels": {
    "CRITICAL": {
      "score": 100,
      "criteria": [
        "あなたの条件"
      ]
    }
  }
}
```

### レポートフォーマットの変更

`templates/*.md`を編集してレポート形式をカスタマイズできます。

### 機能マッピングの設定

プロジェクト固有の機能マッピングを定義することで、高精度な機能影響分析が可能です。

`config/app_feature_mapping.json`を作成/編集：

```json
{
  "repositories": {
    "your-app-repository": {
      "features": {
        "feature_id": {
          "name": "機能名",
          "description": "機能の概要説明",
          "file_patterns": [
            "/path/pattern/.*keyword"
          ],
          "user_impact": "ユーザーへの影響説明",
          "affected_users": "影響を受けるユーザー",
          "urgency_default": "high|medium|low",
          "recommended_action": "推奨される対応方法"
        }
      }
    }
  },
  "fallback_to_pattern_matching": true
}
```

**フィールド説明**:
- `name`: レポートに表示される機能名
- `description`: 機能の概要（ビジネス視点）
- `file_patterns`: 正規表現パターンのリスト
- `user_impact`: 想定されるユーザーへの影響
- `affected_users`: 影響を受けるユーザーの範囲
- `urgency_default`: 対応の緊急度（high/medium/low）
- `recommended_action`: 推奨される具体的な対応方法

**マッピングが未定義の場合**:
- `config/feature_patterns.json`のパターンマッチングで自動推測
- レポートに警告が表示され、手動確認を促します

## トラブルシューティング

### db-changes.mdが見つからない

```bash
# input/ ディレクトリを確認
ls .claude/skills/db-impact-analyzer/input/

# ファイルを配置
cp your-db-changes.md .claude/skills/db-impact-analyzer/input/
```

### 検出数が0件

- db-changes.mdの「調査対象アプリケーション」セクションを確認
- 検索キーワードが正しいか確認
- ログファイルで詳細を確認：

```bash
tail -f logs/db-impact-analyzer-*.log
```

### メモリ不足

`config/default_config.json`で設定を調整：

```json
{
  "scan": {
    "max_file_size_mb": 5
  }
}
```

### 機能マッピングが反映されない

- `config/app_feature_mapping.json`の存在を確認
- JSON構文が正しいか確認（バリデーション）
- リポジトリ名が正確に一致しているか確認
- ログで詳細を確認：

```bash
grep "app_feature_mapping" logs/db-impact-analyzer-*.log
```

## 連携Skill

### migration-planner

impact-report.mdから移行計画を生成：

```
migration-plannerを起動して、移行計画を作成してください
```

### db-change-analyst Agent

ワークフロー全体を統括：

```
db-change-analyst Agentに影響調査を依頼してください
```

## サポート

問題が発生した場合は、以下を確認してください：

1. ログファイル: `logs/db-impact-analyzer-*.log`
2. コンテキストファイル: `logs/context-*.json`
3. SKILL.md: 詳細仕様

## ライセンス

内部利用のみ
