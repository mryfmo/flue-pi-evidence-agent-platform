#!/usr/bin/env python3
"""
db-impact-analyzer 統合テスト

新形式（リポジトリ名ベース）と旧形式（絶対パス）の両方をテストします。
"""

import sys
import os
from pathlib import Path

# プロジェクトルートをPythonパスに追加
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.change_parser import ChangeParser
import logging

# ロガー設定
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("integration_test")


def test_new_format():
    """新形式（ベースパス + リポジトリ名）のテスト"""
    print("\n" + "=" * 60)
    print("テスト1: 新形式（ベースパス + リポジトリ名）")
    print("=" * 60)

    content = """
# DB変更内容定義

## 調査対象アプリケーション

**ベースパス**: /home/user/pochi-dp-developer-docs

**リポジトリ**:
- test_apps/sales_dashboard
- test_apps/inventory_system

## 変更内容

### 1. テーブル廃止

| テーブル名 | スキーマ | 廃止理由 |
|-----------|---------|---------|
| `orders_legacy` | `public` | システム統合 |

### 2. カラム削除

| テーブル名 | カラム名 | データ型 |
|-----------|---------|---------|
| `customers` | `fax_number` | VARCHAR(20) |
"""

    # テンポラリファイルに保存
    test_file = PROJECT_ROOT / "test_new_format.md"
    test_file.write_text(content, encoding="utf-8")

    try:
        parser = ChangeParser(logger)
        result = parser.parse_db_changes(test_file)

        print(f"\n✅ ベースパス検出: /home/user/pochi-dp-developer-docs")
        print(f"✅ リポジトリ数: {len(result['target_apps'])}")
        print(f"   調査対象アプリ:")
        for app in result["target_apps"]:
            print(f"   - {app}")

        expected_apps = [
            "/home/user/pochi-dp-developer-docs/test_apps/sales_dashboard",
            "/home/user/pochi-dp-developer-docs/test_apps/inventory_system",
        ]
        assert result["target_apps"] == expected_apps, f"Expected {expected_apps}, got {result['target_apps']}"
        print("\n✅ 新形式テスト成功!")

    finally:
        test_file.unlink()


def test_old_format():
    """旧形式（絶対パス）のテスト"""
    print("\n" + "=" * 60)
    print("テスト2: 旧形式（絶対パス）- 後方互換性確認")
    print("=" * 60)

    content = """
# DB変更内容定義

## 調査対象アプリケーション

- /home/user/pochi-dp-developer-docs/test_apps/sales_dashboard/
- /home/user/pochi-dp-developer-docs/test_apps/inventory_system/

## 変更内容

### 1. テーブル廃止

| テーブル名 | スキーマ | 廃止理由 |
|-----------|---------|---------|
| `orders_legacy` | `public` | システム統合 |
"""

    # テンポラリファイルに保存
    test_file = PROJECT_ROOT / "test_old_format.md"
    test_file.write_text(content, encoding="utf-8")

    try:
        parser = ChangeParser(logger)
        result = parser.parse_db_changes(test_file)

        print(f"\n✅ 旧形式検出（絶対パス）")
        print(f"✅ アプリ数: {len(result['target_apps'])}")
        print(f"   調査対象アプリ:")
        for app in result["target_apps"]:
            print(f"   - {app}")

        expected_apps = [
            "/home/user/pochi-dp-developer-docs/test_apps/sales_dashboard/",
            "/home/user/pochi-dp-developer-docs/test_apps/inventory_system/",
        ]
        assert result["target_apps"] == expected_apps, f"Expected {expected_apps}, got {result['target_apps']}"
        print("\n✅ 旧形式テスト成功（後方互換性OK）!")

    finally:
        test_file.unlink()


def test_keyword_extraction():
    """検索キーワード抽出のテスト"""
    print("\n" + "=" * 60)
    print("テスト3: 検索キーワード抽出")
    print("=" * 60)

    content = """
# DB変更内容定義

## 調査対象アプリケーション

**ベースパス**: /home/user

**リポジトリ**:
- test_app

## 変更内容

### 1. テーブル廃止

| テーブル名 | スキーマ | 廃止理由 |
|-----------|---------|---------|
| `orders_legacy` | `public` | システム統合 |

### 2. カラム削除

| テーブル名 | カラム名 | データ型 |
|-----------|---------|---------|
| `customers` | `fax_number` | VARCHAR(20) |

### 3. カラムリネーム

| テーブル名 | 旧カラム名 | 新カラム名 |
|-----------|-----------|-----------|
| `orders` | `total` | `total_amount` |
"""

    # テンポラリファイルに保存
    test_file = PROJECT_ROOT / "test_keywords.md"
    test_file.write_text(content, encoding="utf-8")

    try:
        parser = ChangeParser(logger)
        result = parser.parse_db_changes(test_file)

        print(f"\n✅ 検索キーワード数: {len(result['search_keywords'])}")
        print(f"   キーワード例:")
        for keyword in sorted(result["search_keywords"])[:10]:
            print(f"   - {keyword}")

        assert "orders_legacy" in result["search_keywords"], "テーブル廃止キーワードが見つかりません"
        assert "customers.fax_number" in result["search_keywords"], "カラム削除キーワードが見つかりません"
        assert "orders.total" in result["search_keywords"], "カラムリネームキーワードが見つかりません"
        print("\n✅ 検索キーワード抽出成功!")

    finally:
        test_file.unlink()


def main():
    """メイン処理"""
    print("\n" + "=" * 60)
    print("db-impact-analyzer 統合テスト")
    print("=" * 60)

    try:
        test_new_format()
        test_old_format()
        test_keyword_extraction()

        print("\n" + "=" * 60)
        print("✅ 全テスト成功!")
        print("=" * 60)
        print("\n新形式（リポジトリ名ベース）と旧形式（絶対パス）の両方が正しく動作します。")
        return 0

    except AssertionError as e:
        print(f"\n❌ テスト失敗: {e}")
        return 1
    except Exception as e:
        print(f"\n❌ エラー: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
