---
name: db-impact-analyzer
description: データベース変更（テーブル廃止、カラム削除、リネーム等）が複数のStreamlitアプリケーションに与える影響を自動分析する。「DB影響分析」「データベース変更の影響調査」「DB変更の影響を調査して」「テーブル廃止の影響範囲を確認」「db-impact-analyzerを実行して」「impact analysis」「analyze DB impact」と言われたときに使用する。
---

> [!CAUTION]
> **このスキルは廃止・使用禁止です。**
> 起動した場合でも**何も実行せずに即座に終了してください。**
> 後継スキル: なし（廃止）— DB影響調査は手動で実施してください

**このスキルは使用禁止です。絶対に実行しないでください。**

後継スキル **なし（廃止）— DB影響調査は手動で実施してください** を使用してください。


# db-impact-analyzer Skill

## スキル概要

**スキルID**: `db-impact-analyzer`
**バージョン**: 1.7.0
**目的**: データベース変更（テーブル廃止、カラム削除、リネーム等）が複数のStreamlitアプリケーションに与える影響を自動分析し、詳細なレポートを生成する

## トリガーフレーズ

以下のフレーズでこのSkillを起動できます：

- "DB影響分析"
- "データベース変更の影響調査"
- "impact analysis"
- "analyze DB impact"
- "DB変更の影響を調査して"
- "テーブル廃止の影響範囲を確認"
- "db-impact-analyzerを実行して"

## 使用可能なツール

このスキルはClaude Codeから実行する際、以下のツールを使用します：

- **AskUserQuestion**: 環境変数が未設定の場合のパラメータ収集
- **Bash**: skill_entry.pyの実行
- **Read**: レポートファイルの読み込み（オプション）

## 機能

### 1. DB変更内容解析

`db-changes.md`を解析し、以下を抽出します：

- テーブル廃止リスト
- カラム削除リスト
- カラムリネームマッピング
- データ型変更リスト
- テーブル統合情報
- 調査対象アプリケーション

### 2. コードスキャン

複数リポジトリを横断的にスキャンし、以下を検出します：

- Pythonコード内のSQL文字列（テーブル・カラム参照）
- SQLAlchemy等のORMモデル定義
- ORMクエリビルダー使用箇所
- .sqlファイル内のテーブル・カラム参照
- 動的SQL生成（f-string、.format()等）
- SELECT * 使用箇所

### 3. 影響度分析

検出結果を以下の基準で分類します：

#### 影響度レベル

- **CRITICAL**: アプリケーション起動・主要機能に必須の変更
  - 主要エントリポイント（app.py, main.py）での使用
  - 複数ファイル（5ファイル以上）での参照
  - データ更新・削除クエリでの使用

- **HIGH**: 重要機能に影響する変更
  - ビジネスロジックでの使用
  - 複数ファイル（3-4ファイル）での参照
  - 重要なレポート生成での使用

- **MEDIUM**: 限定的な機能に影響する変更
  - 特定機能のみでの使用
  - 1-2ファイルでの参照
  - 代替手段が存在

- **LOW**: 影響が軽微またはほぼない変更
  - SELECT * での暗黙的参照
  - テストコードのみでの使用
  - コメントアウトされたコード

### 3.5. Claude探索的調査フェーズ（自動実行）

Phase 3後に**自動的に実行されます**（環境変数設定不要）。
スキル起動時に一度で深層調査まで完結します。

自動スキャナーが「どのファイルにVIEW名が出現するか」を列挙した後、Claude Codeが以下を深く調査します：

- **呼び出し連鎖の追跡**: SQL/Python関数/Streamlit画面の呼び出し関係
- **Jinja2条件分岐解析**: `{% if %}` ブロックのどの条件下でVIEWが使われるか
- **ビジネス影響の意味解釈**: 停止する機能名・エラーが発生するトリガー操作・症状
- **具体的な対応手順生成**: 修正すべきファイル・行・修正内容

**出力ファイル**:
- `logs/claude-investigation-context-{run_id}.json`: Claude調査の起点となる中間データ（検出ファイル、調査タスクリスト）

### 4. レポート生成

Markdown形式の詳細レポートを生成します：

- サマリテーブル（影響アプリ数、影響度別カウント）
- アプリケーション別の詳細セクション
  - 影響度別サマリ
  - 影響ファイル一覧
  - 深層調査セクション（Phase 3.5のClaude調査で入力）
    - 機能名・廃止VIEW・呼び出し連鎖・エラートリガー・症状
    - 修正対象（ファイル・行番号・コードスニペット・対応手順）
- 優先度付きアクションリスト（チェックボックス形式）

## 入出力

### 入力

1. **db-changes.md**: DB変更内容定義ファイル
   - デフォルトパス: `.claude/skills/db-impact-analyzer/input/` 内の `.md` ファイル
   - ファイルが1件のみの場合は自動選択、複数の場合はユーザーに選択を求める
   - 調査対象アプリパスリストを含む

### 出力

1. **impact-report.md**: 統合影響分析レポート（自動スキャン + 深層調査）
   - 保存先（優先順位）:
     1. **db-changes.mdと同じディレクトリ**（db-changes.mdが指定されている場合）
        - 例: db-changes.mdが `/home/user/project/db-changes.md` の場合 → `/home/user/project/impact-report.md`
     2. `.claude/skills/db-impact-analyzer/reports/impact-report.md`（フォールバック: db-changes.md未指定時）
   - 内容: 自動スキャン結果（問題検出・推奨対応）+ 深層調査結果（呼び出し連鎖・停止機能）

2. **ログファイル**: 実行ログ
   - 保存先: `.claude/skills/db-impact-analyzer/logs/db-impact-analyzer-{run_id}.log`

3. **コンテキストファイル**: 実行コンテキスト
   - 保存先: `.claude/skills/db-impact-analyzer/logs/context-{run_id}.json`

## 使用例

### 例1: Claude Code経由での実行（標準）

> ⚠️ **絶対必須・直接実行禁止**
>
> このスキルが起動されたとき、Claude Code（あなた自身）が直接ワークフローを実行することは**厳禁**です。
> **必ず最初に `db-change-analyst` カスタムサブエージェントをAgentツールで起動し、ワークフロー全体を委譲してください。**
>
> ```
> Agentツール（subagent_type: "db-impact-analyzer:db-change-analyst"）で
> db-change-analyst カスタムサブエージェントを起動し、
> 以下のタスクを実行させてください：
> - db-changes.mdの確認と読み込み
> - スキャン対象リポジトリの確認
> - skill_entry.py の実行
> - Phase 3.5・Phase 5 のサブエージェント並列起動による深層調査
> - レポートの生成・保存
> ```

```
db-impact-analyzerのSKILL.mdを読み込んで、DB変更影響分析を実行してください
```

Claude Codeは自動的に以下を実行します：
1. **db-change-analyst カスタムサブエージェントを起動**（必須）
2. サブエージェントがAskUserQuestionツールでリポジトリとベースパスを質問
3. サブエージェントが環境変数を設定してskill_entry.pyを実行
4. サブエージェントがレポートを生成

### 例2: 環境変数を事前設定して実行

```bash
export DB_CHANGE_REPOSITORIES="pochi-sales-dashboard,pochi-inventory-app"
export DB_CHANGE_BASE_PATH="/home/user"
export DB_CHANGE_FILE="/path/to/db-changes.md"  # オプション

python /home/user/pochi-dp-developer-docs/skills/db-impact-analyzer/skill_entry.py
```

### 例3: 特定のdb-changes.mdを指定

```
DB_CHANGE_FILE=/path/to/db-changes.md を使って影響分析を実行してください。
```

### 例4: 深層調査まで含めて実行（デフォルト動作）

```bash
DB_CHANGE_REPOSITORIES="pochi-timeseries-data-analyzer-repository,pochi-user-behavior-map-repository" \
DB_CHANGE_BASE_PATH="/home/user" \
python /home/user/pochi-dp-developer-docs/skills/db-impact-analyzer/skill_entry.py
```

実行後、標準出力にClaude Codeへの調査プロンプトが表示されます。
Claude CodeがExplore・Bash・Readツールを活用した深い調査を自動的に実施し、
`reports/impact-report.md` に統合します。

**Phase 3.5の調査内容**:
- 検出ファイルの詳細読み込み（VIEW名がどのSQL句に出現するか）
- Jinja2テンプレートの条件分岐解析
- 呼び出し連鎖の追跡（SQL → Python関数 → Streamlit画面）
- 停止する機能名・エラー症状の特定
- ファイル・行レベルの対応手順生成

### 例5: db-change-analyst カスタムエージェントの直接起動

このスキルのすべての実行は、db-change-analyst カスタムエージェント経由で行われます。

```
db-change-analyst カスタムエージェント（subagent_type: "db-impact-analyzer:db-change-analyst"）を
Agentツールで起動して、orders_legacyテーブルの廃止による影響を調査してください。
```

## ワークフロー

### ⚠️ スキル起動前の必須確認事項

> **重要**: 検査対象となるアプリリポジトリは、**devブランチに切り替えたうえでpullして最新化**しておく必要があります。

スキルを実行する前に、必ず以下を各リポジトリで実施してください：

1. **devブランチへ切り替え**: `git checkout dev`
2. **最新コードを取得**: `git pull`

⚠️ **この手順が完了していない場合、古いコードに基づいた誤った影響分析結果が出力されます。**

上記の準備が完了したことを確認してから、次の「実行前の準備」ステップへ進んでください。

---

### 実行前の準備（AskUserQuestionツール使用）

Claude Codeがこのスキルを実行する際、環境変数が未設定の場合は**必ずAskUserQuestionツールで質問**してください。

#### 0. db-changes.md のインプット確認（スキル実行前に必ず実施）

`input/` ディレクトリ内に既存の `.md` ファイルが存在する場合、そのまま使用するかを確認します：

```
AskUserQuestionツールで質問:
- question: "input/ ディレクトリ内のインプットファイルをそのまま使用しますか？それとも db-changes.md の内容で書き換えてから実行しますか？"
- header: "インプット確認"
- options:
  - label: "そのまま使用する"
    description: "input/ 内の既存ファイルをそのまま使用する（前回のままの内容）"
  - label: "db-changes.md から書き換える"
    description: "db-changes.md の内容を input/db-changes-skill-input.md にコピーしてから実行する"
```

「db-changes.md から書き換える」を選択した場合、Claude Code は Read + Write ツールで `db-changes.md` の内容を `input/db-changes-skill-input.md` にコピーしてから `skill_entry.py` を実行します。

#### 1. DB_CHANGE_REPOSITORIESの確認

環境変数`DB_CHANGE_REPOSITORIES`が未設定の場合、以下の質問をします：

```
AskUserQuestionツールで質問:
- question: "スキャン対象のリポジトリを指定してください（カンマ区切り）"
- header: "リポジトリ"
- options:
  - label: "すべてのアプリ"
    description: "pochi-*パターンのすべてのリポジトリ"
  - label: "カスタム指定"
    description: "カンマ区切りで手動入力"
- multiSelect: false
```

回答を環境変数`DB_CHANGE_REPOSITORIES`に設定してください。

#### 2. DB_CHANGE_BASE_PATHの確認

環境変数`DB_CHANGE_BASE_PATH`が未設定の場合、以下の質問をします：

```
AskUserQuestionツールで質問:
- question: "リポジトリが配置されているベースパスを入力してください"
- header: "ベースパス"
- options:
  - label: "/home/user (推奨)"
    description: "標準の開発環境パス"
  - label: "/workspace"
    description: "コンテナ環境のパス"
  - label: "カスタムパス"
    description: "手動でパスを入力"
- multiSelect: false
```

回答を環境変数`DB_CHANGE_BASE_PATH`に設定してください。

#### 3. skill_entry.py実行

環境変数設定後、以下のコマンドでskill_entry.pyを実行してください（レポートファイル名に実行日時が自動付与されます）：

```bash
DB_CHANGE_REPOSITORIES="<回答内容>" DB_CHANGE_BASE_PATH="<回答内容>" \
python /home/user/pochi-dp-developer-docs/skills/db-impact-analyzer/skill_entry.py
```

#### 4. Claude Code自動実行指示（重要）

> **手順5はskill_entry.py実行前に実施します（下記参照）**



`skill_entry.py` を実行したら、標準出力に調査プロンプトが表示されます。
**そのプロンプトに従い、以下を自動的に実施してください**：

1. `logs/claude-investigation-context-{run_id}.json` を確認

> ⚠️ **絶対必須・直接調査禁止**
> - 手順2〜3は**必ずAgentツール（subagent_type: "Explore"）を使って影響アプリごとにExploreサブエージェントを並列起動すること**
> - Claude Code（あなた自身）が直接コードを読んで調査することは**厳禁**
> - サブエージェントを起動せずに次の手順へ進むことを禁止する

2. Agentツール（subagent_type: "Explore"）を使って、影響アプリごとにExploreサブエージェントを**並列起動**（単一メッセージで複数のAgent tool callを実行）
3. 各サブエージェントが担当アプリの深層調査結果（Markdown文字列）を返す
4. **Editツールを使用して**、骨格レポートの各 `### 深層調査` プレースホルダーを結果で置換して上書き保存
5. **保存確認（必須）**: 保存後にReadツールでレポートを再度読み込み、チャット画面に表示した各VIEWの影響内容がレポートに含まれているか確認すること。含まれていない場合は追記すること

**出力フォーマット例**:

```markdown
### 深層調査

#### [機能名] （例: dポイントクラブMAU分析）
- **廃止VIEW**: `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION`, `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION`
- **呼び出し連鎖**: `dpoint_club_mau.sql` → `dpoint_usage.py::get_dpoint_club_mau_data()` → `timeseries_data_visualizer.py::visualization_dpoint_usage()`
- **エラートリガー**: dポイント利用状況セクション表示時
- **症状**: `ProgrammingError`発生、画面全体がエラー表示
- **修正対象**:
  - `app/lib/data/sql/dpoint_club_mau.sql:91`
    ```sql
    >>> procdb_b_p01_lak.d_mr_000.vw_dic_mecd_member_profile_use_information AS u
    ```
    対応: VIEW名を代替VIEWに置換（代替VIEWが存在しない場合は機能削除を検討）
```

#### 手順5. レポート出力先の確認（skill_entry.py実行前に実施）

レポート出力先ディレクトリに既存の `impact-report*.md` が存在する場合は以下を確認します：

```
AskUserQuestionツールで質問:
- question: "既存のレポートファイルが見つかりました。どのように保存しますか？"
- header: "保存方法"
- options:
  - label: "日付付きで新規保存（推奨）"
    description: "impact-report_YYYYMMDD_HHMMSS.md として保存（既存ファイルは保持）"
  - label: "impact-report.md に上書き"
    description: "既存の impact-report.md を上書きする"
```

`skill_entry.py` はデフォルトで日付付きファイル名（`impact-report_YYYYMMDD_HHMMSS.md`）で保存します。
「impact-report.md に上書き」を選択した場合は、生成後に `report_YYYYMMDD_HHMMSS.md` を `impact-report.md` にリネームしてください。

#### Step 3: Phase 5 整合性チェック（Step 2完了後）

Step 2のレポート統合・保存が完了したら、生成したレポートが実際のコードと整合しているか検証します。

> ⚠️ **絶対必須・直接確認禁止**
> - 整合性チェックは**必ずAgentツール（subagent_type: "Explore"）を使って影響アプリごとにExploreサブエージェントを並列起動すること**
> - Claude Code（あなた自身）が直接コードを読んで確認することは**厳禁**
> - サブエージェントを起動せずに「完了」と報告することを禁止する

Agentツール（subagent_type: "Explore"）を使って、影響アプリごとにExploreサブエージェントを**並列起動**（単一メッセージで複数のAgent tool callを実行）し、以下を検証させます：
- 記載の行番号・コードスニペットが実コードと一致するか
- 呼び出し連鎖が正しいか
- db-changes.mdに記載の廃止VIEWで見落としがないか

全サブエージェントの結果を受け取り、誤り・見落とし（実行SQLのみ対象）がある場合はEditツールでレポートを修正します。

**これをもってスキル全体が完了です。**

**結果**: `reports/impact-report.md` 1ファイルに自動スキャンと深層調査が統合されます。

### 実行フロー

1. **環境チェック**: POCHI_SKILL_ACTIVE確認
2. **SkillState初期化**: パス設定、ロガー初期化、設定読み込み
3. **環境変数読み込み**: DB_CHANGE_REPOSITORIES、DB_CHANGE_BASE_PATH
4. **Phase 1: DB変更内容解析**
   - db-changes.md解析
   - 検索キーワード生成
5. **Phase 2: コードスキャン**
   - `.py`, `.sql`, `.sql.j2`, `.j2` ファイルをスキャン
   - テーブル・カラム参照検出（スキーマ修飾名対応）
6. **Phase 3: 影響度分析**
   - 影響度判定（CRITICAL/HIGH/MEDIUM/LOW）
   - アプリ別集計
7. **Phase 3.5: Claude探索的調査フェーズ（自動実行）**
   - 常時実行（環境変数設定不要）
   - 中間データファイル（JSON）を生成
   - Claude Codeへの詳細調査プロンプトを標準出力に表示
8. **Phase 4: レポート生成**
   - Markdownレポート生成（ファイルタイプ別の具体的な推奨対応付き）
   - ファイル保存（`### Snowflakeクエリヒストリー検証` プレースホルダーを含む）
9. **Phase 4.5: Snowflakeクエリヒストリー照会（Claude Codeが実施）**
   - 深層調査（Phase 3.5 Step 1）完了後、廃止VIEW名ごとにクエリを実行
   - 調査期間: Skill起動時にユーザーが指定した日数（デフォルト7日）
   - 接続失敗時は警告ログのみ記録してスキップ（処理継続）
   - VIEWごとの実行件数・最終実行日時・エラー有無・実行ユーザーを集計
   - アプリ全体クエリ数に対するVIEWアクセス割合（usage_ratio_pct）を算出
   - ユーザー別VIEWアクセス数（直近30日）を集計
   - アプリ別使用状況としてどのアプリが該当VIEWを使用しているかを判定
   - 各アプリセクションの `### Snowflakeクエリヒストリー検証` プレースホルダーを結果で置換
10. **Phase 5: 整合性チェック（Claude Codeが実施）**
   - 影響アプリ数分のExploreサブエージェントを並列起動
   - impact-report.mdの深層調査内容をコードと照合
   - 誤り・見落としを修正して最終レポートを確定

### 環境変数一覧

| 環境変数 | 必須 | 説明 | 例 |
|---------|------|------|-----|
| `DB_CHANGE_REPOSITORIES` | ✅ 必須 | スキャン対象リポジトリ名（カンマ区切り） | `pochi-sales-dashboard,pochi-app` |
| `DB_CHANGE_BASE_PATH` | - | リポジトリが配置されているベースパス | `/home/user` |
| `DB_CHANGE_FILE` | - | db-changes.mdの明示的なパス | `/path/to/db-changes.md` |
| `DB_QUERY_HISTORY_DAYS` | - | Snowflakeクエリヒストリーの調査期間（日数）。未設定の場合はSkill起動時にユーザーへ質問 | `7` |
| `POCHI_SKILL_ACTIVE` | - | `false` にするとSkill実行を無効化 | `false` |

## 設定ファイル

### config/default_config.json

- スキャン設定（対象拡張子、除外ディレクトリ）
- ロギング設定
- 出力設定

### config/detection_patterns.json

- SQL検出パターン（FROM, JOIN, UPDATE等）
- ORM検出パターン（SQLAlchemy等）
- 動的SQL検出パターン

### config/severity_rules.json

- 影響度レベル定義
- ファイルパスパターン
- クエリタイプパターン
- 調整ルール

## テンプレート

> **テンプレートファイルの場所**: このSKILL.mdと**同じディレクトリの `templates/` サブディレクトリ**に格納されています。
> - SKILL.mdパス: `/home/user/pochi-dp-developer-docs/.claude/skills/db-impact-analyzer/SKILL.md`
> - テンプレートディレクトリ: `/home/user/pochi-dp-developer-docs/.claude/skills/db-impact-analyzer/templates/`
>
> `find` コマンドでの検索は不要です。上記のパスを直接参照してください。

### templates/impact_header.md

レポートヘッダーテンプレート（サマリテーブル、リスク評価）

- パス: `/home/user/pochi-dp-developer-docs/.claude/skills/db-impact-analyzer/templates/impact_header.md`

### templates/app_section.md

アプリセクションテンプレート（影響度別サマリ、ファイルリスト）

- パス: `/home/user/pochi-dp-developer-docs/.claude/skills/db-impact-analyzer/templates/app_section.md`

### templates/issue_detail.md

問題詳細テンプレート（ファイル、行番号、コード、推奨対応）

- パス: `/home/user/pochi-dp-developer-docs/.claude/skills/db-impact-analyzer/templates/issue_detail.md`

## 制約事項

- 静的解析のみ（コード実行なし）
- 外部接続なし（ローカルファイルのみ）
- 正規表現ベースのパターンマッチング
- 動的SQL検出は完全ではない（WARNING扱い）
- 呼び出し連鎖の自動追跡は限定的（Phase 3.5のClaude調査で補完）

## 連携Skill

### migration-planner

impact-report.mdを入力として、移行計画（migration-plan.md）を生成します。

```
migration-plannerを起動して、impact-report.mdから移行計画を作成してください。
```

### db-change-analyst Agent

DB変更分析の専門家Agentとして、ワークフロー全体を統括します。

```
db-change-analyst Agentに、orders_legacyテーブルの廃止影響を調査してもらってください。
```

## トラブルシューティング

### 環境変数DB_CHANGE_REPOSITORIESが未設定

**エラー**: `❌ エラー: 環境変数 DB_CHANGE_REPOSITORIES が設定されていません`

**解決方法**:

1. **Claude Code経由で実行（推奨）**:
   ```
   db-impact-analyzerのSKILL.mdを読み込んで、DB変更影響分析を実行してください
   ```
   Claude CodeがAskUserQuestionツールで質問します。

2. **環境変数を手動設定**:
   ```bash
   export DB_CHANGE_REPOSITORIES="pochi-sales-dashboard,pochi-inventory-app"
   export DB_CHANGE_BASE_PATH="/home/user"
   python /home/user/pochi-dp-developer-docs/skills/db-impact-analyzer/skill_entry.py
   ```

### db-changes.mdが見つからない

**警告**: `⚠️ 警告: input/ ディレクトリにインプットファイルが見つかりません`

- インプットファイルは `.claude/skills/db-impact-analyzer/input/` に配置してください
- 環境変数`DB_CHANGE_FILE`で任意のパスを指定することも可能
- 見つからない場合は、リポジトリ情報のみで実行されます

### 検出数が0件

- db-changes.mdの「調査対象アプリケーション」セクションを確認
- 検索キーワードが正しいか確認
- ログファイルで詳細を確認
- リポジトリパスが正しいか確認

### メモリ不足

- `config/default_config.json` の `max_file_size_mb` を調整
- 除外ディレクトリを追加

## 開発者向け情報

### ディレクトリ構造

```
db-impact-analyzer/
├── core/
│   ├── state.py              # SkillState
│   ├── change_parser.py      # DB変更解析
│   ├── code_scanner.py       # コードスキャン
│   ├── impact_analyzer.py    # 影響度分析
│   └── report_builder.py     # レポート生成
├── scripts/
│   ├── utils.py              # 共通ユーティリティ
│   ├── file_utils.py         # ファイル操作
│   ├── sql_parser.py         # SQL解析
│   ├── orm_parser.py         # ORM解析
│   └── pattern_matcher.py    # パターンマッチング
├── config/                   # 設定ファイル
├── templates/                # レポートテンプレート
├── logs/                     # ログ出力
├── reports/                  # レポート出力
├── skill_entry.py            # エントリポイント
├── SKILL.md                  # このファイル
└── README.md                 # クイックスタート
```

### 拡張方法

- 検出パターン追加: `config/detection_patterns.json`
- 影響度ルール調整: `config/severity_rules.json`
- レポートカスタマイズ: `templates/*.md`

## ライセンス

内部利用のみ

## 更新履歴

- 1.7.0 (2026-03-03):
  - 「実行前の準備」に手順0（db-changes.md インプット確認）を追加
  - 「実行前の準備」に手順5（レポート出力先上書き確認）を追加
  - レポートファイル名にデフォルトで実行日時サフィックスを付与（impact-report_YYYYMMDD_HHMMSS.md）
  - Phase 3.5 プロンプト内の Step 2 レポートパスを日付付きファイル名に更新
  - query_history.py にアプリ全体クエリ数クエリを追加（VIEW利用割合の分母）
  - query_history.py にユーザー別VIEWアクセス数クエリを追加（直近30日固定）
  - 返却値に app_total_query_count、usage_ratio_pct、user_access_last_30days を追加
  - Phase 4.5 書き込み形式テンプレートに割合テーブル・ユーザー別テーブルを追加
  - report_builder.py の影響ファイル省略を全廃（_format_affected_files、_build_issue_details、_build_feature_section の上限撤廃）
- 1.6.0 (2026-03-02):
  - テンプレートディレクトリの絶対パスをSKILL.mdに明示（findコマンド不要化）
  - Phase 4開始時にテンプレートパスをprint出力するよう改善
  - レポート出力先をdb-changes.mdと同じディレクトリに変更（優先順位: db-changes.mdと同ディレクトリ > reports/フォールバック）
  - state.pyのget_report_path()にdb_changes_dirベースの出力先ロジックを追加
  - Step 2の保存確認指示を強化（Editツール使用の明示・保存後のReadツールによる確認を必須化）
- 1.5.0 (2026-02-26):
  - Snowflakeクエリヒストリー統合機能を追加（Phase 4.5）
  - Skill起動時にクエリヒストリー調査期間（日数）をユーザーへ質問（環境変数 DB_QUERY_HISTORY_DAYS で事前設定も可能）
  - 接続失敗時は警告ログのみ記録して処理継続
  - templates/app_section.md に `### Snowflakeクエリヒストリー検証` セクションとプレースホルダーを追加
  - VIEWごとの実行件数・最終実行日時・エラー有無・アプリ別使用状況をレポートに掲載
- 1.4.0 (2026-02-25):
  - Phase 3.5プロンプトを並列サブエージェント化（Taskツールで影響アプリ数分のExploreサブエージェントを並列起動）
  - SKILL.md Step 4の説明を並列起動フローに更新
- 1.3.0 (2026-02-25):
  - レポート構造を再設計: 「### 詳細」「### 影響を受ける機能」セクションを廃止
  - 「### 深層調査」セクションに統合（コードスニペットも対応手順内に含む）
  - 骨格レポートに「### 深層調査」プレースホルダーを埋め込み、Claude調査で入力する形式に変更
  - Claude調査コンテキストJSONにissue_details（コードスニペット・行番号・推奨対応）を追加
  - SKILL.mdのStep 4指示文・出力フォーマット例を更新
- 1.2.0 (2026-02-25):
  - Phase 3.5を常時実行化（ENABLE_CLAUDE_INVESTIGATION環境変数廃止）
  - レポートを1ファイル（impact-report.md）に統合
  - スキル起動1回で深層調査まで完結するよう改善
- 1.1.0 (2026-02-25): バグ修正・機能強化
  - `.sql.j2` / `.j2` ファイルのスキャン対応追加（Phase 1-A）
  - `pochilib_snowflake_call` 誤検知（false positive HIGH）を修正（Phase 1-B）
  - `.sql` ファイルの大文字小文字を無視した検索に修正（Phase 1-C）
  - スキーマ修飾名（`db.schema.view_name`）のパース対応（Phase 1-D）
  - Phase 3.5: Claude探索的調査フェーズ追加（`ENABLE_CLAUDE_INVESTIGATION=true`）
  - レポートの推奨対応をファイルタイプ・match_type別に具体化
  - Jinja2テンプレートの条件分岐注意メッセージ追加
  - フッターを優先度付きアクションリスト（チェックボックス形式）に改善
- 1.0.0 (2026-02-13): 初版リリース
