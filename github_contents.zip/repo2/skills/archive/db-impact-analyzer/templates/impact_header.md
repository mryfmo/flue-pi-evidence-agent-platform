# DB変更影響分析レポート

**生成日時**: {timestamp}
**分析ID**: {run_id}
**変更内容定義ファイル**: {db_changes_file}

---

## サマリ

| 項目 | 値 |
|-----|-----|
| 調査対象アプリ数 | {total_apps} |
| 影響を受けるアプリ数 | {affected_apps} |
| 検出された問題総数 | {total_issues} |
| CRITICAL（重大） | {critical_count} |
| HIGH（高） | {high_count} |
| MEDIUM（中） | {medium_count} |
| LOW（低） | {low_count} |
| 動的SQL検出数 | {dynamic_sql_count} |
| SELECT * 検出数 | {select_star_count} |

---

## リスク評価

### 影響度レベルの定義

- **CRITICAL**: アプリケーション起動・主要機能に必須の変更。即座の対応が必要。
- **HIGH**: 重要機能に影響する変更。優先的な対応が必要。
- **MEDIUM**: 限定的な機能に影響する変更。計画的な対応が望ましい。
- **LOW**: 影響が軽微またはほぼない変更。時間のある時に対応可能。

### 全体リスク

{overall_risk_summary}

---

## 影響を受けるアプリケーション一覧

以下のアプリケーションで影響が検出されました：

