
## {app_index}. {app_name}

**アプリパス**: `{app_path}`
**最大影響度**: {max_severity}
**影響ファイル数**: {file_count}
**検出問題数**: {total_issues}

### 影響度別サマリ

| 影響度 | 件数 |
|--------|-----|
| CRITICAL | {critical_count} |
| HIGH | {high_count} |
| MEDIUM | {medium_count} |
| LOW | {low_count} |

### 影響を受けるファイル

{affected_files_list}

### 深層調査

> この欄はPhase 3.5のClaude探索的調査フェーズで自動入力されます。

### Snowflakeクエリヒストリー検証

{snowflake_verification_placeholder}

---

