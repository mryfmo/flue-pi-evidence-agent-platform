### 影響を受ける機能

{features_content}