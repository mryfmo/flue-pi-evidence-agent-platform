#### {severity} - {match_type}

**ファイル**: `{file_path}:{line_number}`
**検出キーワード**: `{matched_keyword}`
**検出方法**: {detection_method}
{warning_flag}

**コード**:
```{language}
{code_snippet}
```
{context_display_block}
**推奨対応**:
{recommended_action}


