"""
db-impact-analyzer Skill Entry Point

DB変更影響分析を実行します。
"""

import os
import sys
from pathlib import Path

# プロジェクトルートをPythonパスに追加
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.state import SkillState
from core.change_parser import ChangeParser
from core.code_scanner import CodeScanner
from core.impact_analyzer import ImpactAnalyzer
from core.report_builder import ReportBuilder
from scripts.file_utils import write_file_safe


def check_environment():
    """実行環境をチェックします"""
    # POCHI_SKILL_ACTIVE環境変数チェック（オプション）
    if os.getenv("POCHI_SKILL_ACTIVE") == "false":
        print("⚠️ Skill実行が無効化されています（POCHI_SKILL_ACTIVE=false）")
        return False
    return True


def get_user_input(state: SkillState):
    """ユーザー入力を取得します（環境変数のみ）"""
    print("\n" + "=" * 60)
    print("DB変更影響分析 (db-impact-analyzer)")
    print("=" * 60)

    # 環境変数から読み込み（必須）
    env_repositories = os.getenv("DB_CHANGE_REPOSITORIES")
    env_base_path = os.getenv("DB_CHANGE_BASE_PATH")

    if not env_repositories:
        print("\n❌ エラー: 環境変数 DB_CHANGE_REPOSITORIES が設定されていません")
        print("\n【解決方法】")
        print("このスキルはClaude Code経由での実行を推奨します。")
        print("\nClaude Codeに以下のように依頼してください：")
        print('  "db-impact-analyzerのSKILL.mdを読み込んで、DB変更影響分析を実行してください"')
        print("\nまたは、環境変数を設定して実行してください：")
        print('  export DB_CHANGE_REPOSITORIES="pochi-sales-dashboard,pochi-inventory-app"')
        print('  export DB_CHANGE_BASE_PATH="/home/user"')
        print('  python /home/user/pochi-dp-developer-docs/skills/db-impact-analyzer/skill_entry.py')
        state.logger.error("DB_CHANGE_REPOSITORIES未設定")
        sys.exit(1)

    repositories = [repo.strip() for repo in env_repositories.split(",") if repo.strip()]
    base_path = env_base_path if env_base_path else "/home/user"

    # パストラバーサル検証
    base_path_resolved = Path(base_path).resolve()
    target_apps = []
    for repo in repositories:
        app_path = (base_path_resolved / repo).resolve()
        if not str(app_path).startswith(str(base_path_resolved) + os.sep) and app_path != base_path_resolved:
            print(f"❌ エラー: 不正なリポジトリパスです（パストラバーサル検出）: {repo}")
            state.logger.error(f"パストラバーサル検出: {repo}")
            sys.exit(1)
        target_apps.append(str(app_path))

    print(f"✓ リポジトリ: {', '.join(repositories)}")
    print(f"✓ ベースパス: {base_path}\n")

    print(f"対象リポジトリ: {len(repositories)}件")
    for repo in repositories:
        print(f"  - {repo}")

    # db-changes.mdパス（環境変数 or input/ ディレクトリから自動検出）
    env_db_changes = os.getenv("DB_CHANGE_FILE")
    if env_db_changes:
        db_changes_path = Path(env_db_changes)
        if db_changes_path.exists():
            print(f"\n✓ インプットファイル（環境変数）: {db_changes_path}")
        else:
            print(f"\n⚠️ 警告: 指定されたファイルが見つかりません: {db_changes_path}")
            print("リポジトリ情報のみで実行します")
            db_changes_path = None
    else:
        input_dir = PROJECT_ROOT / "input"
        input_dir.mkdir(exist_ok=True)
        md_files = sorted(input_dir.glob("*.md"))

        if len(md_files) == 1:
            db_changes_path = md_files[0]
            print(f"\n✓ インプットファイル: {db_changes_path.name}")
        elif len(md_files) > 1:
            print("\n複数のインプットファイルが見つかりました。使用するファイルを選択してください：")
            for i, f in enumerate(md_files, 1):
                print(f"  {i}. {f.name}")
            while True:
                try:
                    choice = input(f"番号を入力してください [1-{len(md_files)}]: ").strip()
                    idx = int(choice) - 1
                    if 0 <= idx < len(md_files):
                        db_changes_path = md_files[idx]
                        print(f"✓ 選択: {db_changes_path.name}")
                        break
                    else:
                        print(f"1〜{len(md_files)} の番号を入力してください")
                except (ValueError, EOFError):
                    print(f"1〜{len(md_files)} の番号を入力してください")
        else:
            print(f"\n⚠️ 警告: input/ ディレクトリにインプットファイルが見つかりません")
            print(f"  パス: {input_dir}")
            print("リポジトリ情報のみで実行します")
            db_changes_path = None

    state.logger.info(f"リポジトリ: {repositories}")
    state.logger.info(f"ベースパス: {base_path}")
    state.logger.info(f"調査対象アプリ: {target_apps}")
    if db_changes_path:
        state.logger.info(f"db-changes.mdパス: {db_changes_path}")
        # レポート出力先をdb-changes.mdと同じディレクトリに設定
        state.db_changes_dir = db_changes_path.parent
        print(f"✓ レポート出力先: {db_changes_path.parent} (db-changes.mdと同じディレクトリ)")

    # クエリヒストリー期間（環境変数未設定の場合はユーザーに質問）
    env_history_days = os.getenv("DB_QUERY_HISTORY_DAYS")
    if env_history_days:
        try:
            history_days = int(env_history_days)
            print(f"✓ クエリヒストリー期間: {history_days}日")
        except ValueError:
            history_days = 7
            print(f"⚠️ DB_QUERY_HISTORY_DAYSの値が不正なため、デフォルト({history_days}日)を使用します")
    else:
        presets = [7, 14, 30, 90]
        print("\nクエリヒストリーの調査期間を選択してください:")
        for i, days in enumerate(presets, 1):
            print(f"  {i}. {days}日")
        print(f"  {len(presets) + 1}. 日数を直接入力")
        while True:
            try:
                choice = input(f"番号を入力してください [1-{len(presets) + 1}、デフォルト: 1]: ").strip()
                if choice == "":
                    history_days = presets[0]
                    break
                choice_int = int(choice)
                if 1 <= choice_int <= len(presets):
                    history_days = presets[choice_int - 1]
                    break
                elif choice_int == len(presets) + 1:
                    while True:
                        try:
                            days_input = input("日数を入力してください: ").strip()
                            history_days = int(days_input)
                            if history_days <= 0:
                                print("1以上の整数を入力してください")
                                continue
                            break
                        except (ValueError, EOFError):
                            history_days = presets[0]
                            break
                    break
                else:
                    print(f"1〜{len(presets) + 1} の番号を入力してください")
            except (ValueError, EOFError):
                history_days = presets[0]
                break
        print(f"✓ クエリヒストリー期間: {history_days}日")

    state.logger.info(f"クエリヒストリー期間: {history_days}日")

    return {
        "repositories": repositories,
        "base_path": base_path,
        "target_apps": target_apps,
        "db_changes_path": db_changes_path,
        "history_days": history_days
    }


def validate_inputs(inputs: dict, state: SkillState) -> bool:
    """入力を検証します"""
    repositories = inputs.get("repositories", [])
    target_apps = inputs.get("target_apps", [])
    db_changes_path = inputs.get("db_changes_path")

    # リポジトリまたはdb-changes.mdのいずれかが必要
    if not repositories and not target_apps:
        if not db_changes_path or not db_changes_path.exists():
            state.logger.error("リポジトリまたはdb-changes.mdが必要です")
            return False

    # target_appsの存在確認
    if target_apps:
        for app_path in target_apps:
            if not Path(app_path).exists():
                state.logger.warning(f"アプリパスが存在しません: {app_path}")

    state.logger.info("入力検証OK")
    return True


def _write_claude_investigation_prompt(
    impact_results: dict,
    parsed_changes: dict,
    scan_results: dict,
    state: "SkillState",
    db_changes_path,
    history_days: int = 7,
    report_path=None,
) -> None:
    """
    Claude探索的調査フェーズ用の調査プロンプトを生成・出力します。

    スキャナーが「どのファイルにVIEW名が出現するか」を列挙した後、
    Claude Codeがサブエージェントを使って以下を調査できるよう、
    中間情報をファイルとして出力し、調査プロンプトを標準出力に表示します。

    調査内容:
    - 呼び出し連鎖の追跡（Python → SQL → VIEW）
    - Jinja2テンプレートの条件分岐解析
    - 影響機能のビジネス的な意味の解釈
    - 対応手順の具体的な生成
    """
    import json as _json

    # 中間ファイル: スキャン結果サマリ（Claude調査の起点）
    investigation_context = {
        "scan_summary": {
            "target_apps": parsed_changes.get("target_apps", []),
            "search_keywords": parsed_changes.get("search_keywords", []),
            "table_drops": parsed_changes.get("table_drops", []),
            "column_drops": parsed_changes.get("column_drops", []),
            "renames": parsed_changes.get("renames", {}),
        },
        "detected_files": {},
        "investigation_tasks": [],
        "issue_details_by_app": {},
        "orm_models": {}
    }

    # アプリ別の問題詳細（コードスニペット・行番号・推奨対応）をコンテキストに埋め込む
    for app_path, app_impact in impact_results.get("apps", {}).items():
        app_issues = {}
        for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            issues = app_impact.get("issues_by_severity", {}).get(severity, [])
            if issues:
                app_issues[severity] = [
                    {
                        "file": issue.get("file", ""),
                        "line": issue.get("line", 0),
                        "matched_keyword": issue.get("matched_keyword", ""),
                        "match_type": issue.get("match_type", ""),
                        "code": issue.get("code", ""),
                        "context_before": issue.get("context_before", []),
                        "context_after": issue.get("context_after", []),
                    }
                    for issue in issues[:10]
                ]
        if app_issues:
            investigation_context["issue_details_by_app"][app_path] = app_issues

    # アプリ別のORMモデル情報を整理（deprecated_view_match を設定）
    for app_path, orm_model_list in scan_results.get("orm_models_by_app", {}).items():
        enriched = []
        for model in orm_model_list:
            tablename_lower = model.get("tablename", "").lower()
            # 廃止VIEW名と一致するか照合
            matched = None
            for drop_name in parsed_changes.get("table_drops", []):
                if drop_name.lower() == tablename_lower:
                    matched = drop_name
                    break
            enriched.append({
                "class_name": model.get("class_name"),
                "file": model.get("file"),
                "tablename": model.get("tablename"),
                "schema": model.get("schema"),
                "full_qualified_name": model.get("full_qualified_name"),
                "column_count": model.get("column_count", 0),
                "is_view": model.get("is_view", False),
                "deprecated_view_match": matched,
            })
        investigation_context["orm_models"][app_path] = enriched

    # アプリ別の検出ファイルリストを整理
    for app_path, app_scan in scan_results.get("apps", {}).items():
        matches = app_scan.get("matches", [])
        if not matches:
            continue

        # ファイル別にマッチをグループ化
        files_info = {}
        for m in matches:
            f = m["file"]
            if f not in files_info:
                files_info[f] = {
                    "matched_keywords": [],
                    "match_types": [],
                    "lines": []
                }
            kw = m.get("matched_keyword", "")
            if kw and kw not in files_info[f]["matched_keywords"]:
                files_info[f]["matched_keywords"].append(kw)
            mt = m.get("match_type", "")
            if mt and mt not in files_info[f]["match_types"]:
                files_info[f]["match_types"].append(mt)
            files_info[f]["lines"].append(m.get("line", 0))

        investigation_context["detected_files"][app_path] = files_info

        # 調査タスクを生成
        for file_path, info in files_info.items():
            keywords_str = ", ".join(info["matched_keywords"])
            investigation_context["investigation_tasks"].append({
                "app": app_path,
                "file": file_path,
                "keywords": info["matched_keywords"],
                "match_types": info["match_types"],
                "task": (
                    f"`{file_path}` で {keywords_str} が検出されました。"
                    f"このファイルがどの機能・画面から呼ばれているかを追跡し、"
                    f"VIEW廃止による具体的な影響（停止する機能・エラーメッセージ等）を特定してください。"
                )
            })

    # 中間ファイルを保存
    investigation_file = state.paths["logs_dir"] / f"claude-investigation-context-{state.run_id}.json"
    try:
        investigation_file.parent.mkdir(parents=True, exist_ok=True)
        investigation_file.write_text(
            _json.dumps(investigation_context, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        state.logger.info(f"Claude調査コンテキスト保存: {investigation_file}")
    except Exception as e:
        state.logger.error(f"Claude調査コンテキスト保存失敗: {e}")

    # Claude Codeへの調査プロンプトを標準出力に表示
    affected_apps = [ap for ap, s in scan_results.get("apps", {}).items() if s.get("total_matches", 0) > 0]
    keywords = parsed_changes.get("table_drops", []) + list(parsed_changes.get("renames", {}).keys())

    skill_root = str(state.paths["skill_root"])
    view_names_csv = ",".join(keywords[:20])
    view_list_markdown = "\n".join(f"  - `{kw}`" for kw in keywords[:20])
    report_path_str = str(report_path) if report_path else str(state.get_report_path("impact-report.md"))

    prompt = f"""
{'=' * 60}
🤖 Claude探索的調査フェーズ - 実施プロンプト
{'=' * 60}

## 概要

自動スキャナーが「どのファイルにVIEW名が出現するか」を列挙しました。
**影響が検出されたアプリごとにTaskツールでExploreサブエージェントを並列起動し**、
深層調査と `{report_path_str}` への統合を実施してください。

## 調査対象

**廃止VIEW（検索キーワード）**:
{chr(10).join(f'  - {kw}' for kw in keywords[:20])}

**影響が検出されたアプリ**:
{chr(10).join(f'  - {ap}' for ap in affected_apps)}

**中間データファイル**: `{investigation_file}`

## Step 1: サブエージェントの並列起動（重要）

Taskツールを使って、以下の各アプリに対してExploreサブエージェントを**1つのメッセージで並列起動**してください。
サブエージェントは対応するアプリのみを調査し、「### 深層調査」セクションに記載する内容を文字列で返します。

各サブエージェントへのプロンプト例（アプリパスと検出情報を差し込む）:
```
あなたは `<アプリパス>` の深層調査を担当します。
中間データファイル `{investigation_file}` の `detected_files["<アプリパス>"]` および `issue_details_by_app["<アプリパス>"]` を参照してください。

以下を調査し、「### 深層調査」セクションに記載する Markdown を返してください（コードブロックで囲まない）。

## 調査内容
1. 検出ファイルを Read ツールで読み込み、VIEW名がどの行・どのSQL句に出現するか確認
2. .sql/.sql.j2 ファイルを呼び出しているPythonファイルを Grep で特定
3. そのPythonファイルを呼び出している画面/モジュール（app.py等）を追跡
4. 停止する機能・エラートリガー・症状を特定

## ORM調査（必須）
中間データの `orm_models["<アプリパス>"]` を確認し、以下を調査してください：
- `deprecated_view_match` が null でないモデルがある場合：そのORMクラスがどのPythonコードから呼ばれているかを Grep で追跡し、深層調査セクションに記載する
- `deprecated_view_match` が全て null の場合：「ORM経由の廃止VIEW参照なし」と記載する

## 出力フォーマット（この形式で返してください）

#### [機能名]
- **廃止VIEW**: `VIEW名`
- **呼び出し連鎖**: `sql_file.sql` → `python_func.py::func_name()` → `app.py::page_name()`
- **エラートリガー**: ページ表示時 / ボタン押下時 など
- **症状**: ProgrammingError発生、画面全体がエラー表示 など
- **修正対象**:
  - `ファイルパス:行番号`
    ```sql
    >>> 該当コード行
    ```
    対応: VIEW名を代替VIEWに置換（代替VIEWが存在しない場合は機能削除を検討）
```

## Step 1.5: Snowflakeクエリヒストリー照会（深層調査完了後・Step 2の前に実施）

深層調査（Step 1）のサブエージェントが全て完了したら、廃止VIEWが実際に本番で使われているかをSnowflakeで確認します。

### 実行手順

1. **セットアップ（初回のみ）**:
   ```bash
   bash {skill_root}/snowflake_env/setup.sh
   ```
   `.venv` が存在する場合は自動スキップされます。

2. **クエリヒストリー照会**:
   ```bash
   cd {skill_root}/snowflake_env
   poetry run python query_history.py "{view_names_csv}" {history_days}
   ```

   **廃止VIEW一覧**:
{view_list_markdown}

3. **出力（JSON）**:
   - 成功時: `"success": true` + 各VIEWの実行件数・最終実行日時・エラー有無・ユーザー一覧
   - 失敗時: `"success": false` + エラー内容

4. **結果の統合**:
   - `success: true` → 照会結果をレポートに統合
   - `success: false` → 以下の警告テキストでプレースホルダーを置換しStepをスキップ:
     ```
     > ⚠️ Snowflake接続に失敗したため、クエリヒストリー検証をスキップしました。
     > 静的解析結果のみを参照してください。
     ```

5. **レポートへの書き込み形式**（各アプリセクションの `### Snowflakeクエリヒストリー検証` に記入）:
   ```markdown
   ### Snowflakeクエリヒストリー検証

   > 調査期間: 過去{history_days}日間

   #### VIEWごとの検出状況

   | 廃止VIEW名 | 過去{history_days}日の実行件数 | 最終実行日時 | エラー有無 | 実行ユーザー |
   |----------|--------------|------------|----------|------------|
   | `VIEW名` | N件 | YYYY-MM-DD HH:MM JST | あり/なし/- | ユーザー名 |

   #### アプリ利用頻度に対するVIEWアクセス割合

   | 廃止VIEW名 | アプリ名 | アプリ全体クエリ数 | VIEW利用数 | 割合 |
   |-----------|--------|----------------|----------|-----|
   | `VIEW名` | アプリ名 | N件 | N件 | N.N% |

   #### ユーザー別VIEWアクセス数（直近30日）

   | 廃止VIEW名 | ユーザー名 | アクセス数 |
   |-----------|---------|---------|
   | `VIEW名` | USER_A | N件 |

   #### 要約・所見

   - `VIEW名` は過去{history_days}日以内に本番実行されており、廃止時にリスクあり
   - `VIEW名` はクエリヒストリーに存在しない（コード参照は残っているが現在未実行の可能性）

   #### 実行クエリ

   ```sql
   -- query_history.py が返す executed_sql フィールドの内容をそのまま貼り付ける。
   -- 重要: IN (...) を省略せず、全VIEW名を展開した状態で記載すること。
   ```
   ```

## Step 2: 結果の統合と保存

> ⚠️ **重要**: チャット画面に表示した調査内容を**必ずすべてレポートファイルに書き込むこと**。
> チャット画面の出力とファイル内容が一致しない場合、スキルは失敗とみなします。

全サブエージェントの結果（深層調査 + Snowflakeクエリヒストリー）が揃ったら：

1. `{report_path_str}` を **Read ツールで読み込む**
2. **Edit ツール**を使用して、各アプリセクションの `### 深層調査` 以下にある
   `> この欄はPhase 3.5のClaude探索的調査フェーズで自動入力されます。` を、
   対応するサブエージェントの返答内容で**置換する**
3. **Edit ツール**を使用して、各アプリセクションの `### Snowflakeクエリヒストリー検証` 以下にある
   `> Snowflakeクエリヒストリー検証はPhase 4.5で入力されます。` を、
   Step 1.5で収集した結果で**置換する**
4. 置換後のレポート全体を `{report_path_str}` に**上書き保存**する
5. **保存確認**: 保存後に `{report_path_str}` を **Read ツールで再度読み込み**、
   チャット出力した各VIEWの影響内容がレポートに含まれているか確認すること。
   含まれていない場合は**追記すること**（保存確認を省略してはならない）

（deep-investigation-report-{state.run_id}.md は生成しない）

## Step 3: Phase 5 整合性チェック（Step 2完了後に実施）

Step 2でレポートへの統合・保存が完了したら、次に整合性チェックを実施してください。

**目的**: impact-report.mdの深層調査セクションが、実際のコードおよびdb-changes.mdと整合しているか検証し、誤り・見落としを修正する。

### サブエージェントの並列起動

Taskツールを使って、以下の各アプリに対してExploreサブエージェントを**Step 2と同様に1つのメッセージで並列起動**してください。

各サブエージェントへのプロンプト：
```
あなたは `<アプリパス>` の整合性チェックを担当します。

## 調査内容
1. `{report_path_str}` を Read ツールで読み込み、このアプリのセクション（「### 深層調査」）の内容を把握する
2. `{db_changes_path}` を Read ツールで読み込み、廃止VIEW一覧を把握する
3. 深層調査に記載されている各ファイルを実際に Read ツールで読み込み、以下を検証：
   - 記載されている行番号は正しいか
   - 記載されているコードスニペットは実際のコードと一致するか
   - VIEW名は実際にそのファイルに存在するか
   - 呼び出し連鎖は正しいか（Grepで確認）
4. db-changes.mdに記載の廃止VIEWで、このアプリに存在するがレポートに記載されていないものがないかGrepで確認

## 返答フォーマット
以下の形式で返してください（修正が不要な場合でも必ずこの形式で返す）：

### 検証結果サマリ
- 正確: X件
- 誤り: X件
- 見落とし: X件

### 正確な記載
- [機能名]: OK

### 誤りのある記載（あれば）
- [機能名]: NG
  - 誤り: ...
  - 正しい内容: ...

### 見落とし（あれば）
- [ファイル/機能]: レポートに記載なし
  - 詳細: ...
  - 実行SQLかどうか: YES/NO
```

### 整合性チェック結果の反映

全サブエージェントの結果が揃ったら：

1. 誤りまたは見落とし（実行SQLのみ対象）がある場合：
   - `{report_path_str}` を Read ツールで読み込む
   - Edit ツールで該当箇所を修正する
   - 修正後のファイルを確認する

2. 誤り・見落としがない場合：
   - 修正不要としてスキル完了

**スキル完了**: 整合性チェックと必要な修正が完了したらスキル全体が完了です。

{'=' * 60}
"""
    print(prompt)
    state.logger.info("Claude調査プロンプトを出力しました")


def main():
    """メイン処理"""
    # 環境チェック
    if not check_environment():
        sys.exit(1)

    try:
        # SkillState初期化
        state = SkillState()
        state.logger.info("=" * 60)
        state.logger.info("DB変更影響分析 開始")
        state.logger.info("=" * 60)

        # ユーザー入力取得
        inputs = get_user_input(state)
        if inputs is None:
            sys.exit(1)

        # 入力検証
        if not validate_inputs(inputs, state):
            sys.exit(1)

        db_changes_path = inputs.get("db_changes_path")
        target_apps = inputs.get("target_apps", [])

        # フェーズ1: DB変更内容解析
        print("\n📊 Phase 1: DB変更内容解析")
        state.logger.info("Phase 1: DB変更内容解析開始")

        parser = ChangeParser(state.logger)

        # db-changes.mdが指定されている場合はパース
        if db_changes_path and db_changes_path.exists():
            parsed_changes = parser.parse_db_changes(db_changes_path)
            # 入力されたtarget_appsで上書き（入力があれば優先）
            if target_apps:
                parsed_changes["target_apps"] = target_apps
        else:
            # db-changes.mdがない場合、入力されたtarget_appsを使用
            parsed_changes = {
                "target_apps": target_apps,
                "table_drops": [],
                "column_drops": [],
                "renames": {},
                "type_changes": [],
                "table_merges": [],
                "search_keywords": []
            }

        if not parsed_changes["target_apps"]:
            print("⚠️ 警告: 調査対象アプリが指定されていません")
            state.logger.warning("調査対象アプリが空です")
            # デモ用にカレントディレクトリを追加
            parsed_changes["target_apps"] = [str(Path.cwd())]
            print(f"デモモード: カレントディレクトリを対象とします ({Path.cwd()})")

        state.update_context(
            db_changes_file=str(db_changes_path) if db_changes_path else None,
            repositories=inputs.get("repositories", []),
            base_path=inputs.get("base_path", ""),
            target_apps=parsed_changes["target_apps"],
            search_keywords=parsed_changes["search_keywords"]
        )

        print(f"✅ 検索キーワード: {len(parsed_changes['search_keywords'])}件")
        print(f"✅ 調査対象アプリ: {len(parsed_changes['target_apps'])}個")

        # フェーズ2: コードスキャン
        print("\n🔍 Phase 2: コードスキャン")
        state.logger.info("Phase 2: コードスキャン開始")

        scanner = CodeScanner(state.config, state.detection_patterns, state.logger)
        scan_results = scanner.scan_repositories(
            repo_paths=parsed_changes["target_apps"],
            search_keywords=parsed_changes["search_keywords"]
        )

        state.update_context(scan_results=scan_results)

        print(f"✅ スキャンファイル数: {scan_results['total_files_scanned']}")
        print(f"✅ 検出数: {scan_results['total_matches']}")

        # フェーズ3: 影響度分析
        print("\n📈 Phase 3: 影響度分析")
        state.logger.info("Phase 3: 影響度分析開始")

        config_dir = PROJECT_ROOT / "config"
        analyzer = ImpactAnalyzer(state.severity_rules, state.logger, config_dir=config_dir)
        impact_results = analyzer.analyze_impact(scan_results)

        state.update_context(impact_summary=impact_results["summary"])

        print(f"✅ 影響アプリ数: {impact_results['summary']['affected_apps']}")
        print(f"   - CRITICAL: {impact_results['summary']['severity_counts']['CRITICAL']}")
        print(f"   - HIGH: {impact_results['summary']['severity_counts']['HIGH']}")
        print(f"   - MEDIUM: {impact_results['summary']['severity_counts']['MEDIUM']}")
        print(f"   - LOW: {impact_results['summary']['severity_counts']['LOW']}")

        # レポートファイル名を実行日時で決定（Phase 3.5 のプロンプトで使用するため先に生成）
        from datetime import datetime as _datetime
        timestamp = _datetime.now().strftime("%Y%m%d_%H%M%S")
        report_filename = f"impact-report_{timestamp}.md"
        report_path = state.get_report_path(report_filename)

        # フェーズ3.5: Claude探索的調査フェーズ
        print("\n🤖 Phase 3.5: Claude探索的調査フェーズ")
        state.logger.info("Phase 3.5: Claude探索的調査フェーズ開始")
        _write_claude_investigation_prompt(
            impact_results=impact_results,
            parsed_changes=parsed_changes,
            scan_results=scan_results,
            state=state,
            db_changes_path=db_changes_path,
            history_days=inputs.get("history_days", 7),
            report_path=report_path,
        )

        # フェーズ4: レポート生成
        print("\n📝 Phase 4: レポート生成")
        print(f"📁 テンプレートディレクトリ: {state.paths['templates_dir']}")
        state.logger.info("Phase 4: レポート生成開始")

        builder = ReportBuilder(state.paths["templates_dir"], state.config, state.logger)
        report_content = builder.build_report(
            impact_results=impact_results,
            db_changes_file=str(db_changes_path),
            run_id=state.run_id
        )

        # レポート保存
        write_file_safe(report_path, report_content, logger=state.logger)

        print(f"\n✅ 骨格レポート生成完了（深層調査フェーズで統合します）")
        print(f"📄 レポートパス（最終）: {report_path}")

        state.logger.info("=" * 60)
        state.logger.info("DB変更影響分析 完了")
        state.logger.info("=" * 60)

        # 結果表示
        print("\n" + "=" * 60)
        print("分析完了")
        print("=" * 60)
        print(f"レポート（最終）: {report_path}")
        print(f"ログ: {state.paths['log_file']}")
        print(f"コンテキスト: {state.paths['logs_dir']}/context-{state.run_id}.json")
        print("=" * 60)

        return 0

    except KeyboardInterrupt:
        print("\n\n⚠️ ユーザーによる中断")
        return 130
    except Exception as e:
        print(f"\n❌ エラーが発生しました: {e}")
        if 'state' in locals():
            state.logger.exception("予期しないエラー")
        return 1


if __name__ == "__main__":
    sys.exit(main())
