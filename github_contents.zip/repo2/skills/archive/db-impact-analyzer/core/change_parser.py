"""
DB変更内容解析

db-changes.mdを解析し、検索キーワードリストと調査対象アプリを抽出します。
"""

import re
from pathlib import Path
from typing import Dict, List, Any
import logging


class ChangeParser:
    """DB変更内容を解析するクラス"""

    def __init__(self, logger: logging.Logger):
        """
        ChangeParserを初期化します。

        Args:
            logger: ロガー
        """
        self.logger = logger

    def parse_db_changes(self, db_changes_path: Path) -> Dict[str, Any]:
        """
        db-changes.mdを解析し、変更内容を構造化します。

        Args:
            db_changes_path: db-changes.mdのパス

        Returns:
            Dict: 解析結果
                - target_apps: List[str] - 調査対象アプリパス
                - table_drops: List[str] - 廃止テーブル名
                - column_drops: List[str] - 削除カラム名 (テーブル.カラム形式)
                - renames: Dict[str, str] - カラムリネーム (旧名 → 新名)
                - type_changes: List[str] - データ型変更カラム
                - table_merges: List[str] - テーブル統合元
                - search_keywords: List[str] - 検索キーワード全リスト
        """
        self.logger.info(f"db-changes.md解析開始: {db_changes_path}")

        if not db_changes_path.exists():
            self.logger.error(f"db-changes.mdが見つかりません: {db_changes_path}")
            return self._empty_result()

        try:
            content = db_changes_path.read_text(encoding="utf-8")
        except Exception as e:
            self.logger.error(f"db-changes.md読み込み失敗: {e}")
            return self._empty_result()

        # 解析結果初期化
        result = {
            "target_apps": self._parse_target_apps(content),
            "table_drops": self._parse_table_drops(content),
            "column_drops": self._parse_column_drops(content),
            "renames": self._parse_renames(content),
            "type_changes": self._parse_type_changes(content),
            "table_merges": self._parse_table_merges(content),
            "search_keywords": [],
        }

        # 検索キーワードリスト生成
        result["search_keywords"] = self._generate_search_keywords(result)

        self.logger.info(f"解析完了: テーブル廃止={len(result['table_drops'])}, "
                        f"カラム削除={len(result['column_drops'])}, "
                        f"リネーム={len(result['renames'])}, "
                        f"対象アプリ={len(result['target_apps'])}")

        return result

    def _empty_result(self) -> Dict[str, Any]:
        """空の解析結果を返す"""
        return {
            "target_apps": [],
            "table_drops": [],
            "column_drops": [],
            "renames": {},
            "type_changes": [],
            "table_merges": [],
            "search_keywords": [],
        }

    def _parse_target_apps(self, content: str) -> List[str]:
        """
        調査対象アプリケーションを解析

        新形式（ベースパス + リポジトリ名）と旧形式（絶対パス）の両方に対応
        """
        base_path = None
        repositories = []
        absolute_paths = []
        in_target_section = False

        for line in content.split("\n"):
            # セクション検出
            if "## 調査対象アプリケーション" in line:
                in_target_section = True
                continue

            # 次のセクションで終了
            if in_target_section and line.startswith("##"):
                break

            # ベースパス抽出（新形式）
            if in_target_section and "**ベースパス**:" in line:
                base_path = line.split("**ベースパス**:")[1].strip()
                self.logger.debug(f"ベースパス検出: {base_path}")
                continue

            # リポジトリ名またはパス抽出
            if in_target_section and line.strip().startswith("-"):
                item = line.strip().lstrip("- ").strip()
                if not item or item.startswith("/path/to"):  # テンプレート除外
                    continue

                if item.startswith("/"):
                    # 絶対パス（旧形式）
                    absolute_paths.append(item)
                    self.logger.debug(f"絶対パス検出: {item}")
                else:
                    # リポジトリ名（新形式）
                    repositories.append(item)
                    self.logger.debug(f"リポジトリ名検出: {item}")

        # 絶対パス構築
        if repositories and base_path:
            # 新形式: ベースパス + リポジトリ名
            apps = [str(Path(base_path) / repo) for repo in repositories]
            self.logger.info(f"新形式: ベースパス={base_path}, リポジトリ={len(repositories)}件")
        elif absolute_paths:
            # 旧形式: 絶対パス
            apps = absolute_paths
            self.logger.info(f"旧形式: 絶対パス={len(absolute_paths)}件")
        else:
            apps = []
            self.logger.warning("調査対象アプリが見つかりません")

        self.logger.debug(f"調査対象アプリ検出: {len(apps)}件")
        return apps

    def _parse_table_drops(self, content: str) -> List[str]:
        """テーブル廃止を解析"""
        tables = []
        in_section = False

        for line in content.split("\n"):
            if "### 1. テーブル廃止" in line:
                in_section = True
                continue

            if in_section and line.startswith("###"):
                break

            # テーブル行パターン: | `table_name` | schema | ... |
            if in_section and line.strip().startswith("|") and "`" in line:
                match = re.search(r'\|\s*`([a-zA-Z_][a-zA-Z0-9_]*)`', line)
                if match:
                    table_name = match.group(1)
                    if table_name and not table_name.startswith("テーブル名"):
                        tables.append(table_name)

        self.logger.debug(f"廃止テーブル検出: {tables}")
        return tables

    def _parse_column_drops(self, content: str) -> List[str]:
        """カラム削除を解析"""
        columns = []
        in_section = False

        for line in content.split("\n"):
            if "### 2. カラム削除" in line:
                in_section = True
                continue

            if in_section and line.startswith("###"):
                break

            # カラム行パターン: | `table_name` | `column_name` | ... |
            if in_section and line.strip().startswith("|") and "`" in line:
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 3:
                    table_match = re.search(r'`([a-zA-Z_][a-zA-Z0-9_]*)`', parts[1])
                    column_match = re.search(r'`([a-zA-Z_][a-zA-Z0-9_]*)`', parts[2])
                    if table_match and column_match:
                        table_name = table_match.group(1)
                        column_name = column_match.group(1)
                        if not table_name.startswith("テーブル名"):
                            columns.append(f"{table_name}.{column_name}")

        self.logger.debug(f"削除カラム検出: {columns}")
        return columns

    def _parse_renames(self, content: str) -> Dict[str, str]:
        """カラムリネームを解析"""
        renames = {}
        in_section = False

        for line in content.split("\n"):
            if "### 3. カラムリネーム" in line:
                in_section = True
                continue

            if in_section and line.startswith("###"):
                break

            # リネーム行パターン: | `table` | `old_col` | `new_col` | ... |
            if in_section and line.strip().startswith("|") and "`" in line:
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 4:
                    table_match = re.search(r'`([a-zA-Z_][a-zA-Z0-9_]*)`', parts[1])
                    old_match = re.search(r'`([a-zA-Z_][a-zA-Z0-9_]*)`', parts[2])
                    new_match = re.search(r'`([a-zA-Z_][a-zA-Z0-9_]*)`', parts[3])
                    if table_match and old_match and new_match:
                        table_name = table_match.group(1)
                        old_col = old_match.group(1)
                        new_col = new_match.group(1)
                        if not table_name.startswith("テーブル名"):
                            old_full = f"{table_name}.{old_col}"
                            new_full = f"{table_name}.{new_col}"
                            renames[old_full] = new_full

        self.logger.debug(f"リネーム検出: {renames}")
        return renames

    def _parse_type_changes(self, content: str) -> List[str]:
        """データ型変更を解析"""
        changes = []
        in_section = False

        for line in content.split("\n"):
            if "### 4. データ型変更" in line:
                in_section = True
                continue

            if in_section and line.startswith("###"):
                break

            # 型変更行パターン: | `table_name` | `column_name` | ... |
            if in_section and line.strip().startswith("|") and "`" in line:
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 3:
                    table_match = re.search(r'`([a-zA-Z_][a-zA-Z0-9_]*)`', parts[1])
                    column_match = re.search(r'`([a-zA-Z_][a-zA-Z0-9_]*)`', parts[2])
                    if table_match and column_match:
                        table_name = table_match.group(1)
                        column_name = column_match.group(1)
                        if not table_name.startswith("テーブル名"):
                            changes.append(f"{table_name}.{column_name}")

        self.logger.debug(f"型変更検出: {changes}")
        return changes

    def _parse_table_merges(self, content: str) -> List[str]:
        """テーブル統合を解析"""
        merges = []
        in_section = False

        for line in content.split("\n"):
            if "### 5. テーブル統合" in line:
                in_section = True
                continue

            if in_section and line.startswith("###"):
                break

            # 統合行パターン: | `table1`, `table2` | ... |
            if in_section and line.strip().startswith("|") and "`" in line:
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 2:
                    # カンマ区切りのテーブル名を抽出
                    table_names = re.findall(r'`([a-zA-Z_][a-zA-Z0-9_]*)`', parts[1])
                    for table in table_names:
                        if not table.startswith("統合元"):
                            merges.append(table)

        self.logger.debug(f"統合テーブル検出: {merges}")
        return merges

    def _generate_search_keywords(self, parsed_data: Dict[str, Any]) -> List[str]:
        """
        解析結果から検索キーワードリストを生成

        Args:
            parsed_data: 解析結果

        Returns:
            List[str]: 検索キーワードリスト
        """
        keywords = []

        # テーブル廃止
        for table in parsed_data["table_drops"]:
            keywords.append(table)
            keywords.append(f'"{table}"')  # ダブルクォート版
            keywords.append(f"'{table}'")  # シングルクォート版

        # テーブル統合元
        for table in parsed_data["table_merges"]:
            keywords.append(table)
            keywords.append(f'"{table}"')
            keywords.append(f"'{table}'")

        # カラム削除
        for column in parsed_data["column_drops"]:
            keywords.append(column)  # table.column形式
            column_name = column.split(".")[-1]
            keywords.append(column_name)  # column名のみ

        # カラムリネーム（旧名のみ）
        for old_name in parsed_data["renames"].keys():
            keywords.append(old_name)
            column_name = old_name.split(".")[-1]
            keywords.append(column_name)

        # データ型変更
        for column in parsed_data["type_changes"]:
            keywords.append(column)
            column_name = column.split(".")[-1]
            keywords.append(column_name)

        # 重複除去
        keywords = list(set(keywords))
        keywords.sort()

        self.logger.debug(f"検索キーワード生成: {len(keywords)}件")
        return keywords
