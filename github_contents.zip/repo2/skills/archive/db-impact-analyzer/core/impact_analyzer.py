"""
影響度分析

スキャン結果を分析し、影響度を判定します。
"""

import re
import json
from pathlib import Path
from typing import Dict, List, Any
import logging
from collections import Counter


class ImpactAnalyzer:
    """影響度分析を実行するクラス"""

    def __init__(
        self,
        severity_rules: Dict[str, Any],
        logger: logging.Logger,
        config_dir: Path = None
    ):
        """
        ImpactAnalyzerを初期化します。

        Args:
            severity_rules: 影響度判定ルール
            logger: ロガー
            config_dir: 設定ディレクトリ（feature_patterns.json読み込み用）
        """
        self.severity_rules = severity_rules
        self.logger = logger
        self.severity_levels = severity_rules.get("severity_levels", {})
        self.detection_rules = severity_rules.get("detection_rules", {})
        self.config_dir = config_dir
        self.feature_patterns = self._load_feature_patterns()

    def analyze_impact(self, scan_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        スキャン結果を分析し、影響度を判定します。

        Args:
            scan_results: スキャン結果

        Returns:
            Dict: 影響度分析結果
                - apps: Dict[app_path, app_impact]
                - summary: サマリ統計
        """
        self.logger.info("影響度分析開始")

        impact_results = {
            "apps": {},
            "summary": {
                "total_apps": 0,
                "affected_apps": 0,
                "severity_counts": {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0},
                "total_issues": 0,
                "dynamic_sql_count": 0,
                "select_star_count": 0
            }
        }

        # アプリごとに分析
        for app_path, app_scan in scan_results["apps"].items():
            if app_scan["total_matches"] == 0:
                continue

            impact_results["summary"]["total_apps"] += 1
            app_impact = self._analyze_app_impact(app_path, app_scan)

            if app_impact["total_issues"] > 0:
                # 機能影響分析を追加
                all_matches_with_severity = []
                for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
                    for issue in app_impact["issues_by_severity"][severity]:
                        issue_with_severity = issue.copy()
                        issue_with_severity["severity"] = severity
                        all_matches_with_severity.append(issue_with_severity)

                affected_features = self.identify_affected_features(all_matches_with_severity, app_path=app_path)
                app_impact["affected_features"] = affected_features

                impact_results["apps"][app_path] = app_impact
                impact_results["summary"]["affected_apps"] += 1

                # サマリ集計
                for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
                    impact_results["summary"]["severity_counts"][severity] += \
                        app_impact["severity_counts"][severity]

                impact_results["summary"]["total_issues"] += app_impact["total_issues"]
                impact_results["summary"]["dynamic_sql_count"] += app_impact["dynamic_sql_count"]
                impact_results["summary"]["select_star_count"] += app_impact["select_star_count"]

        self.logger.info(f"影響度分析完了: {impact_results['summary']['affected_apps']}アプリに影響")

        return impact_results

    def _analyze_app_impact(self, app_path: str, app_scan: Dict[str, Any]) -> Dict[str, Any]:
        """
        単一アプリの影響度を分析します。

        Args:
            app_path: アプリパス
            app_scan: アプリスキャン結果

        Returns:
            Dict: アプリ影響度分析結果
        """
        matches = app_scan.get("matches", [])

        # 影響度別に分類
        issues_by_severity = {
            "CRITICAL": [],
            "HIGH": [],
            "MEDIUM": [],
            "LOW": []
        }

        dynamic_sql_count = 0
        select_star_count = 0

        for match in matches:
            # 動的SQL・SELECT *カウント
            if match.get("match_type") == "dynamic_sql":
                dynamic_sql_count += 1
            if match.get("match_type") == "select_star":
                select_star_count += 1

            # 影響度判定
            severity = self._determine_severity(match, matches)
            issues_by_severity[severity].append(match)

        # ファイル統計
        affected_files = list(set(m["file"] for m in matches))
        file_path_counts = Counter(m["file"] for m in matches)

        return {
            "app_path": app_path,
            "total_issues": len(matches),
            "affected_files": affected_files,
            "file_count": len(affected_files),
            "severity_counts": {
                "CRITICAL": len(issues_by_severity["CRITICAL"]),
                "HIGH": len(issues_by_severity["HIGH"]),
                "MEDIUM": len(issues_by_severity["MEDIUM"]),
                "LOW": len(issues_by_severity["LOW"])
            },
            "issues_by_severity": issues_by_severity,
            "dynamic_sql_count": dynamic_sql_count,
            "select_star_count": select_star_count,
            "most_affected_files": file_path_counts.most_common(5),
            "max_severity": self._get_max_severity(issues_by_severity)
        }

    def _determine_severity(self, match: Dict[str, Any], all_matches: List[Dict[str, Any]]) -> str:
        """
        マッチの影響度を判定します。

        Args:
            match: マッチ情報
            all_matches: 全マッチリスト（ファイル数カウント用）

        Returns:
            str: 影響度 (CRITICAL/HIGH/MEDIUM/LOW)
        """
        # 明示的な低影響フラグ
        if match.get("low_severity"):
            return "LOW"

        # ファイルパスベースの判定
        file_path = match["file"]
        file_severity = self._get_severity_by_file_path(file_path)

        # クエリタイプベースの判定
        code = match.get("code", "")
        query_severity = self._get_severity_by_query_type(code)

        # 複数ファイル参照による影響度上昇
        file_count = len(set(m["file"] for m in all_matches if m["matched_keyword"] == match["matched_keyword"]))

        # 基本影響度
        base_severity = max(file_severity, query_severity, key=lambda s: self._severity_score(s))

        # 調整ルール適用
        adjusted_severity = self._apply_adjustment_rules(base_severity, match, file_count)

        return adjusted_severity

    def _get_severity_by_file_path(self, file_path: str) -> str:
        """ファイルパスから影響度を判定"""
        file_patterns = self.detection_rules.get("file_path_patterns", {})

        for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            patterns = file_patterns.get(severity, [])
            for pattern in patterns:
                if re.search(pattern, file_path):
                    return severity

        return "MEDIUM"  # デフォルト

    def _get_severity_by_query_type(self, code: str) -> str:
        """クエリタイプから影響度を判定"""
        query_patterns = self.detection_rules.get("query_type_patterns", {})

        code_upper = code.upper()

        for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            patterns = query_patterns.get(severity, [])
            for pattern in patterns:
                if re.search(pattern, code_upper):
                    return severity

        return "MEDIUM"  # デフォルト

    def _apply_adjustment_rules(self, base_severity: str, match: Dict[str, Any], file_count: int) -> str:
        """調整ルールを適用"""
        severity = base_severity

        # 多数のファイルで参照されている場合は影響度を上げる
        if file_count >= 5:
            severity = self._increase_severity(severity)

        # 動的SQL検出時は警告フラグ（影響度は変えない）
        if match.get("warning"):
            # 動的SQLは既に記録済み
            pass

        # テストファイルのみの場合は影響度を下げる
        if "test" in match["file"].lower():
            severity = "LOW"

        return severity

    def _increase_severity(self, severity: str) -> str:
        """影響度を1段階上げる"""
        severity_order = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
        current_index = severity_order.index(severity)
        if current_index < len(severity_order) - 1:
            return severity_order[current_index + 1]
        return severity

    def _severity_score(self, severity: str) -> int:
        """影響度をスコアに変換"""
        scores = {"LOW": 25, "MEDIUM": 50, "HIGH": 75, "CRITICAL": 100}
        return scores.get(severity, 50)

    def _get_max_severity(self, issues_by_severity: Dict[str, List]) -> str:
        """最大影響度を取得"""
        for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            if issues_by_severity[severity]:
                return severity
        return "LOW"

    def _load_feature_patterns(self) -> Dict[str, Any]:
        """
        feature_patterns.jsonを読み込みます

        Returns:
            Dict: 機能推測パターン定義
        """
        if not self.config_dir:
            self.logger.warning("config_dirが未設定のため、デフォルトパターンを使用します")
            return {
                "path_patterns": {},
                "file_name_keywords": {},
                "default_feature_name": "その他の機能"
            }

        patterns_file = self.config_dir / "feature_patterns.json"
        if not patterns_file.exists():
            self.logger.warning(f"feature_patterns.jsonが見つかりません: {patterns_file}")
            return {
                "path_patterns": {},
                "file_name_keywords": {},
                "default_feature_name": "その他の機能"
            }

        try:
            with open(patterns_file, 'r', encoding='utf-8') as f:
                patterns = json.load(f)
            self.logger.debug(f"feature_patterns.json読み込み完了: {patterns_file}")
            return patterns
        except Exception as e:
            self.logger.error(f"feature_patterns.json読み込みエラー: {e}")
            return {
                "path_patterns": {},
                "file_name_keywords": {},
                "default_feature_name": "その他の機能"
            }

    def _load_app_feature_mapping(self) -> Dict[str, Any]:
        """
        app_feature_mapping.jsonを読み込みます

        Returns:
            Dict: アプリケーション固有の機能マッピング定義
        """
        if not self.config_dir:
            self.logger.warning("config_dirが未設定のため、マッピングファイルを読み込めません")
            return {"repositories": {}, "fallback_to_pattern_matching": True}

        mapping_file = self.config_dir / "app_feature_mapping.json"
        if not mapping_file.exists():
            self.logger.debug(f"app_feature_mapping.jsonが見つかりません: {mapping_file}")
            return {"repositories": {}, "fallback_to_pattern_matching": True}

        try:
            with open(mapping_file, 'r', encoding='utf-8') as f:
                mapping = json.load(f)
            self.logger.debug(f"app_feature_mapping.json読み込み完了: {mapping_file}")
            return mapping
        except Exception as e:
            self.logger.error(f"app_feature_mapping.json読み込みエラー: {e}")
            return {"repositories": {}, "fallback_to_pattern_matching": True}

    def _match_feature_mapping(self, file_path: str, app_path: str) -> Dict[str, Any]:
        """
        app_feature_mapping.jsonから機能定義を検索

        Args:
            file_path: 検出されたファイルパス
            app_path: アプリケーションパス

        Returns:
            Dict: 機能定義（見つからない場合は空のdict）
        """
        mapping = self._load_app_feature_mapping()
        app_name = Path(app_path).name

        if app_name not in mapping.get("repositories", {}):
            return {}

        features = mapping["repositories"][app_name].get("features", {})

        for feature_id, feature_def in features.items():
            for pattern in feature_def.get("file_patterns", []):
                if re.search(pattern, file_path):
                    return feature_def

        return {}

    def _detect_affected_pages(self, affected_files: List[str]) -> List[str]:
        """
        pages/ 配下のファイルからStreamlitページ名を検出します。

        Args:
            affected_files: 影響を受けるファイルのリスト

        Returns:
            List[str]: 検出されたページ名のリスト
        """
        pages = []
        for f in affected_files:
            if "/pages/" in f:
                stem = Path(f).stem
                pages.append(stem)
        return list(set(pages))

    def _infer_user_experience_impact(
        self,
        feature_name: str,
        affected_files: List[str],
        matches: List[Dict]
    ) -> Dict[str, str]:
        """
        ユーザー体験レベルの影響を推測してDict返却します。
        Streamlitページ検出 + マッチタイプ分析で具体的な症状を推測します。

        Args:
            feature_name: 機能名
            affected_files: 影響を受けるファイルのリスト
            matches: 検出された問題のリスト

        Returns:
            Dict: {
                "symptom": "〇〇画面でデータが表示されない",
                "specific_action": "〇〇ボタンをクリックすると動作しない",
                "data_issue": "〇〇の集計が正しく行われない"
            }
        """
        impact = {"symptom": "", "specific_action": "", "data_issue": ""}

        # pages/ 配下のファイルを検出してページ名から症状を推測
        page_names = self._detect_affected_pages(affected_files)
        if page_names:
            impact["symptom"] = f"{'/'.join(page_names)} ページでデータ表示エラーが発生する可能性"

        # マッチタイプから具体的な影響を推測
        match_types = {m.get("match_type", "") for m in matches}
        if "column_reference" in match_types:
            impact["data_issue"] = "削除/変更されたカラムを参照しているため、該当項目が表示されない"
        if "table_reference" in match_types or "orm_model" in match_types:
            impact["data_issue"] = (
                impact["data_issue"] or "テーブル/ビューへのアクセスに失敗しデータが読み込まれない"
            )
        if "multiline_sql" in match_types or "variable_assigned_sql" in match_types:
            impact["data_issue"] = (
                impact["data_issue"] or "SQL文字列内のテーブル/カラム参照に影響があり、データ取得が失敗する可能性"
            )
        if "dynamic_sql" in match_types:
            impact["specific_action"] = "フィルタや検索条件が動的に生成されるため、エラーが発生する可能性"
        if "pochilib_snowflake" in match_types:
            impact["specific_action"] = (
                impact["specific_action"] or "pochilib経由のSnowflakeクエリが失敗する可能性"
            )
        if "orm_new_style" in match_types:
            impact["specific_action"] = (
                impact["specific_action"] or "SQLAlchemy新スタイルAPIによるクエリが失敗する可能性"
            )

        return impact

    def identify_affected_features(self, matches: List[Dict], app_path: str = "") -> List[Dict]:
        """
        影響を受けるファイルから機能を特定します

        Args:
            matches: 検出された問題のリスト
            app_path: アプリケーションパス（マッピング検索用）

        Returns:
            List[Dict]: 機能別の影響情報
        """
        # 機能別にグルーピング（マッピング優先）
        feature_map = {}
        for match in matches:
            file_path = match["file"]

            # マッピング検索（優先）
            feature_mapping = self._match_feature_mapping(file_path, app_path) if app_path else {}

            if feature_mapping:
                # マッピングが見つかった場合
                feature_name = feature_mapping.get("name", "不明な機能")
            else:
                # フォールバック：パターンマッチング
                feature_name = self._infer_feature_from_path(file_path)

            if feature_name not in feature_map:
                feature_map[feature_name] = {
                    "feature_name": feature_name,
                    "affected_files": [],
                    "severities": [],
                    "issues": [],
                    "mapping": feature_mapping  # マッピング情報を保持
                }

            feature_map[feature_name]["affected_files"].append(file_path)
            severity = match.get("severity", "MEDIUM")
            feature_map[feature_name]["severities"].append(severity)
            feature_map[feature_name]["issues"].append(match)

        # 機能別に集計
        features = []
        for feature_name, data in feature_map.items():
            affected_files_unique = list(set(data["affected_files"]))
            feature_info = {
                "feature_name": feature_name,
                "severity": self._get_max_severity_from_list(data["severities"]),
                "affected_files": affected_files_unique,
                "file_count": len(affected_files_unique),
                "issue_count": len(data["issues"])
            }

            # 説明文生成（マッピング優先）
            description_dict = self._generate_feature_description_dict(data, data["mapping"])
            feature_info.update(description_dict)

            # ユーザー体験レベルの影響推測
            user_experience_impact = self._infer_user_experience_impact(
                feature_name, affected_files_unique, data["issues"]
            )
            feature_info["user_experience_impact"] = user_experience_impact

            features.append(feature_info)

        # 影響度順にソート
        features.sort(key=lambda x: self._severity_score(x["severity"]), reverse=True)

        return features

    def _infer_feature_from_path(self, file_path: str) -> str:
        """
        ファイルパスから機能名を推測

        優先順位:
        1. ファイル名キーワードマッチ（settlement → 決済処理）
        2. パスパターンマッチ（/data_loader/ → データ読み込み）
        3. デフォルト（その他の機能）

        Args:
            file_path: ファイルパス

        Returns:
            str: 推測された機能名
        """
        file_name = Path(file_path).stem.lower()

        # ファイル名キーワードマッチ（優先）
        for keyword, feature_name in self.feature_patterns.get("file_name_keywords", {}).items():
            if keyword in file_name:
                return feature_name

        # パスパターンマッチ
        for pattern, feature_name in self.feature_patterns.get("path_patterns", {}).items():
            if pattern in file_path:
                return feature_name

        # デフォルト
        return self.feature_patterns.get("default_feature_name", "その他の機能")

    def _generate_feature_description_dict(
        self,
        feature_data: Dict,
        feature_mapping: Dict
    ) -> Dict[str, str]:
        """
        機能の説明を生成（マッピング優先、フォールバックはパターンマッチング）

        Args:
            feature_data: 機能データ（issues, affected_filesを含む）
            feature_mapping: マッピング定義（空の場合はフォールバック）

        Returns:
            Dict: {
                "description": "機能概要",
                "user_impact": "ユーザーへの影響",
                "affected_users": "影響を受けるユーザー",
                "urgency": "対応の緊急度",
                "recommended_action": "推奨対応"
            }
        """
        if feature_mapping:
            # マッピングが見つかった場合：高精度の説明
            return {
                "description": feature_mapping.get("description", ""),
                "user_impact": feature_mapping.get("user_impact", ""),
                "affected_users": feature_mapping.get("affected_users", ""),
                "urgency": feature_mapping.get("urgency_default", "medium"),
                "recommended_action": feature_mapping.get("recommended_action", "")
            }

        # フォールバック: 技術的な説明のみ
        file_types = self._extract_file_types(feature_data)
        technical_desc = ", ".join(sorted(file_types)) + "に影響" if file_types else "機能に影響"

        return {
            "description": technical_desc,
            "user_impact": "詳細は不明（手動確認が必要）",
            "affected_users": "不明",
            "urgency": "medium",
            "recommended_action": "影響範囲を確認し、必要に応じて修正してください"
        }

    def _extract_file_types(self, feature_data: Dict) -> set:
        """
        検出された問題からファイルタイプを抽出

        Args:
            feature_data: 機能データ

        Returns:
            set: ファイルタイプのセット
        """
        file_types = set()
        for issue in feature_data["issues"]:
            match_type = issue.get("match_type", "")
            if "orm" in match_type.lower():
                file_types.add("ORMモデル定義")
            elif "sql" in match_type.lower():
                file_types.add("SQLクエリ")
            elif "table" in match_type.lower():
                file_types.add("テーブル参照")
            elif "column" in match_type.lower():
                file_types.add("カラム参照")

            # codeまたはcode_snippetフィールドを確認
            code = issue.get("code", "") or issue.get("code_snippet", "")
            if isinstance(code, str) and "import" in code.lower():
                file_types.add("モジュールインポート")

        return file_types

    def _get_max_severity_from_list(self, severities: List[str]) -> str:
        """
        影響度リストから最大影響度を取得

        Args:
            severities: 影響度リスト

        Returns:
            str: 最大影響度
        """
        for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            if severity in severities:
                return severity
        return "LOW"
