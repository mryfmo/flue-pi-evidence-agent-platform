"""
レポート生成

影響度分析結果からMarkdownレポートを生成します。
"""

from pathlib import Path
from typing import Dict, Any, List
import logging
from datetime import datetime

from scripts.utils import format_datetime, truncate_string


class ReportBuilder:
    """レポート生成を実行するクラス"""

    def __init__(
        self,
        templates_dir: Path,
        config: Dict[str, Any],
        logger: logging.Logger
    ):
        """
        ReportBuilderを初期化します。

        Args:
            templates_dir: テンプレートディレクトリ
            config: 設定
            logger: ロガー
        """
        self.templates_dir = templates_dir
        self.config = config
        self.logger = logger
        self.output_config = config.get("output", {})

        # テンプレート読み込み
        self.templates = self._load_templates()

    def _load_templates(self) -> Dict[str, str]:
        """テンプレートファイルを読み込みます"""
        templates = {}
        template_files = ["impact_header.md", "app_section.md", "issue_detail.md"]

        for template_file in template_files:
            template_path = self.templates_dir / template_file
            if template_path.exists():
                try:
                    templates[template_file] = template_path.read_text(encoding="utf-8")
                    self.logger.debug(f"テンプレート読み込み: {template_file}")
                except Exception as e:
                    self.logger.error(f"テンプレート読み込みエラー: {template_file} - {e}")
                    templates[template_file] = ""
            else:
                self.logger.warning(f"テンプレートファイルが見つかりません: {template_file}")
                templates[template_file] = ""

        return templates

    def build_report(
        self,
        impact_results: Dict[str, Any],
        db_changes_file: str,
        run_id: str
    ) -> str:
        """
        影響度分析レポートを生成します。

        Args:
            impact_results: 影響度分析結果
            db_changes_file: db-changes.mdパス
            run_id: 実行ID

        Returns:
            str: Markdownレポート
        """
        self.logger.info("レポート生成開始")

        # ヘッダー生成
        header = self._build_header(impact_results, db_changes_file, run_id)

        # アプリセクション生成
        app_sections = []
        sorted_apps = self._sort_apps_by_severity(impact_results["apps"])

        for app_index, (app_path, app_impact) in enumerate(sorted_apps, start=1):
            section = self._build_app_section(app_index, app_path, app_impact)
            app_sections.append(section)

        # フッター生成
        footer = self._build_footer(impact_results)

        # 結合
        report = header + "\n\n" + "\n".join(app_sections) + "\n\n" + footer

        self.logger.info("レポート生成完了")

        return report

    def _build_header(self, impact_results: Dict[str, Any], db_changes_file: str, run_id: str) -> str:
        """ヘッダーセクションを生成"""
        summary = impact_results["summary"]

        # リスク評価サマリ
        overall_risk = self._assess_overall_risk(summary)

        template = self.templates.get("impact_header.md", "")
        header = template.format(
            timestamp=format_datetime(),
            run_id=run_id,
            db_changes_file=db_changes_file,
            total_apps=summary["total_apps"],
            affected_apps=summary["affected_apps"],
            total_issues=summary["total_issues"],
            critical_count=summary["severity_counts"]["CRITICAL"],
            high_count=summary["severity_counts"]["HIGH"],
            medium_count=summary["severity_counts"]["MEDIUM"],
            low_count=summary["severity_counts"]["LOW"],
            dynamic_sql_count=summary["dynamic_sql_count"],
            select_star_count=summary["select_star_count"],
            overall_risk_summary=overall_risk
        )

        return header

    def _build_app_section(self, app_index: int, app_path: str, app_impact: Dict[str, Any]) -> str:
        """アプリセクションを生成"""
        # アプリ名抽出
        app_name = Path(app_path).name or app_path

        # 影響ファイルリスト
        affected_files_list = self._format_affected_files(app_impact["affected_files"])

        template = self.templates.get("app_section.md", "")
        section = template.format(
            app_index=app_index,
            app_name=app_name,
            app_path=app_path,
            max_severity=app_impact["max_severity"],
            file_count=app_impact["file_count"],
            total_issues=app_impact["total_issues"],
            critical_count=app_impact["severity_counts"]["CRITICAL"],
            high_count=app_impact["severity_counts"]["HIGH"],
            medium_count=app_impact["severity_counts"]["MEDIUM"],
            low_count=app_impact["severity_counts"]["LOW"],
            affected_files_list=affected_files_list,
            snowflake_verification_placeholder=(
                "> Snowflakeクエリヒストリー検証はPhase 4.5で入力されます。"
            ),
        )

        return section

    def _build_feature_section(self, features: List[Dict]) -> str:
        """
        機能影響セクションを生成

        Args:
            features: 機能影響リスト

        Returns:
            str: 機能影響セクションのMarkdown
        """
        if not features:
            return ""

        feature_items = []
        for feature in features:
            severity_icon = self._get_severity_icon(feature["severity"])
            affected_files = feature["affected_files"]
            files_list = "\n".join([f"  - `{f}`" for f in affected_files])

            # ユーザー体験影響セクション生成
            ux_impact = feature.get("user_experience_impact", {})
            ux_lines = []
            if ux_impact.get("symptom"):
                ux_lines.append(f"- 症状: {ux_impact['symptom']}")
            if ux_impact.get("specific_action"):
                ux_lines.append(f"- 操作時の問題: {ux_impact['specific_action']}")
            if ux_impact.get("data_issue"):
                ux_lines.append(f"- データの問題: {ux_impact['data_issue']}")
            ux_section = (
                "\n**想定されるユーザー体験への影響**:\n" + "\n".join(ux_lines)
                if ux_lines else ""
            )

            # マッピング情報がある場合は詳細表示
            if feature.get("user_impact") and feature["user_impact"] != "詳細は不明（手動確認が必要）":
                feature_item = f"""#### {severity_icon} {feature["feature_name"]}

- **影響度**: {feature["severity"]}
- **機能概要**: {feature.get("description", "")}
- **想定される影響**: {feature.get("user_impact", "")}
- **影響範囲**: {feature.get("affected_users", "")}
- **対応の緊急度**: {self._format_urgency(feature.get("urgency", "medium"))}
{ux_section}

**関連ファイル**:
{files_list}

**推奨対応**:
{feature.get("recommended_action", "")}
"""
            else:
                # フォールバック：簡易表示
                feature_item = f"""#### {severity_icon} {feature["feature_name"]}

- **影響度**: {feature["severity"]}
- **影響ファイル数**: {feature["file_count"]}件
- **検出問題数**: {feature["issue_count"]}件
- **説明**: {feature.get("description", "")}
{ux_section}

**関連ファイル**:
{files_list}

⚠️ **注意**: この機能は自動推測されたものです。詳細は手動で確認してください。
"""
            feature_items.append(feature_item)

        features_section = "\n".join(feature_items)

        # 詳細テンプレート優先
        template = self.templates.get("feature_impact_detailed.md", "") or self.templates.get("feature_impact.md", "")
        if template:
            return template.format(features_content=features_section)
        else:
            # テンプレートがない場合はデフォルト形式
            return f"### 影響を受ける機能\n\n{features_section}"

    def _format_urgency(self, urgency: str) -> str:
        """緊急度を日本語に変換"""
        urgency_map = {
            "high": "高 - 即座に対応が必要",
            "medium": "中 - アプリ起動前に修正推奨",
            "low": "低 - 時間のある時に対応"
        }
        return urgency_map.get(urgency.lower(), urgency)

    def _get_severity_icon(self, severity: str) -> str:
        """影響度アイコンを取得"""
        icons = {
            "CRITICAL": "🔴",
            "HIGH": "🟠",
            "MEDIUM": "🟡",
            "LOW": "🟢"
        }
        return icons.get(severity, "⚪")

    def _build_issue_details(self, app_impact: Dict[str, Any]) -> str:
        """問題詳細セクションを生成"""
        details = []

        # 影響度の高い順に出力
        for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            issues = app_impact["issues_by_severity"][severity]
            if not issues:
                continue

            for issue in issues:
                detail = self._build_issue_detail(severity, issue)
                details.append(detail)

        if not details:
            return "問題は検出されませんでした。"

        return "\n\n".join(details)

    def _format_context_display(
        self,
        context_before: List[str],
        match_line: str,
        context_after: List[str]
    ) -> str:
        """
        コンテキスト行を整形します。マッチ行は>>> でハイライトします。

        Args:
            context_before: マッチ行の前の行リスト
            match_line: マッチした行
            context_after: マッチ行の後の行リスト

        Returns:
            str: 整形されたコンテキスト表示文字列
        """
        lines = []
        for line in context_before:
            lines.append(f"  {line.rstrip()}")
        lines.append(f">>> {match_line.rstrip()}")
        for line in context_after:
            lines.append(f"  {line.rstrip()}")
        return "\n".join(lines)

    def _build_issue_detail(self, severity: str, issue: Dict[str, Any]) -> str:
        """個別問題の詳細を生成"""
        # 警告フラグ
        warning_flag = ""
        if issue.get("warning"):
            match_type = issue.get("match_type", "")
            if match_type == "dynamic_sql":
                warning_flag = "\n⚠️ **警告**: 動的SQL検出 - ランタイムで生成されるSQL。静的解析では完全な影響把握が困難です。手動確認が必要です。"
            elif match_type == "pochilib_snowflake":
                warning_flag = "\n⚠️ **警告**: Snowflakeコネクタ呼び出し検出 - 実際に参照するVIEW/テーブルを手動で確認してください。"
            else:
                warning_flag = "\n⚠️ **警告**: 手動での確認が必要です"

        # コードスニペット
        code_snippet = issue.get("code", "")
        max_length = self.output_config.get("max_code_length", 200)
        if len(code_snippet) > max_length:
            code_snippet = truncate_string(code_snippet, max_length)

        # ファイルパス
        file_path = issue.get("file", "")
        line_number = issue.get("line", 0)

        # 推奨対応（ファイルパスとmatch_typeを渡して具体的なアクションを生成）
        matched_keyword = issue.get("matched_keyword", "")
        recommended_action = self._get_recommended_action(
            severity, issue.get("match_type", ""), file_path, matched_keyword
        )

        # 言語（ファイル拡張子から判定）
        if file_path.endswith(".py"):
            language = "python"
        elif file_path.endswith(".j2") or file_path.endswith(".sql.j2"):
            language = "sql+jinja2"
        else:
            language = "sql"

        # Jinja2テンプレートの場合、条件分岐の可視化
        jinja2_note = ""
        if file_path.endswith(".j2") or file_path.endswith(".sql.j2"):
            # コードスニペットにJinja2の条件分岐({%if%}等)が含まれているか確認
            if "{%" in code_snippet or "{%" in "\n".join(issue.get("context_before", []) + issue.get("context_after", [])):
                jinja2_note = (
                    "\n> **Jinja2テンプレート注意**: `{% if %}` 条件分岐が存在します。"
                    " VIEW名がどの条件下で使用されているかを確認してください。"
                    " 条件分岐によっては、特定のパラメータ時のみ影響が発生する場合があります。"
                )

        # コンテキスト行の整形
        context_before = issue.get("context_before", [])
        context_after = issue.get("context_after", [])
        if context_before or context_after:
            context_display = self._format_context_display(
                context_before, code_snippet, context_after
            )
            context_display_block = (
                f"\n**コンテキスト** (前後{len(context_before) + len(context_after)}行):\n"
                f"```{language}\n{context_display}\n```\n"
                f"{jinja2_note}\n"
            )
        else:
            context_display_block = jinja2_note + "\n" if jinja2_note else ""

        template = self.templates.get("issue_detail.md", "")
        detail = template.format(
            severity=severity,
            match_type=issue.get("match_type", "unknown"),
            file_path=file_path,
            line_number=line_number,
            matched_keyword=issue.get("matched_keyword", ""),
            detection_method=issue.get("detection_method", ""),
            warning_flag=warning_flag,
            code_snippet=code_snippet,
            language=language,
            recommended_action=recommended_action,
            context_display_block=context_display_block
        )

        return detail

    def _build_footer(self, impact_results: Dict[str, Any]) -> str:
        """フッターセクションを生成"""
        summary = impact_results["summary"]
        critical = summary['severity_counts']['CRITICAL']
        high = summary['severity_counts']['HIGH']
        medium = summary['severity_counts']['MEDIUM']
        low = summary['severity_counts']['LOW']
        dynamic_sql = summary['dynamic_sql_count']

        # 対応アクションを優先度付きで生成
        action_items = []

        if critical > 0:
            action_items.append(
                f"1. **[ ] CRITICAL対応（即座に対応 - 本番デプロイ前に必須）**\n"
                f"   - {critical}件のCRITICAL問題を修正してください\n"
                f"   - 上記レポートの「CRITICAL」セクションの各ファイルを修正\n"
                f"   - VIEW名を新しいVIEW名または代替クエリに置換"
            )
        if high > 0:
            action_items.append(
                f"{'2' if critical > 0 else '1'}. **[ ] HIGH対応（優先的に対応）**\n"
                f"   - {high}件のHIGH問題を確認・修正してください\n"
                f"   - ビジネス機能への影響度を個別に評価\n"
                f"   - 代替VIEWが存在する場合はVIEW名を置換、存在しない場合は機能を無効化"
            )
        if medium + low > 0:
            n = 1 + (1 if critical > 0 else 0) + (1 if high > 0 else 0)
            action_items.append(
                f"{n}. **[ ] MEDIUM/LOW対応（計画的に対応）**\n"
                f"   - {medium}件のMEDIUM、{low}件のLOW問題を確認してください\n"
                f"   - 影響度を確認し、必要に応じて修正"
            )
        if dynamic_sql > 0:
            n = 1 + (1 if critical > 0 else 0) + (1 if high > 0 else 0) + (1 if medium + low > 0 else 0)
            action_items.append(
                f"{n}. **[ ] 動的SQL手動確認**\n"
                f"   - {dynamic_sql}件の動的SQL生成箇所を手動で確認してください\n"
                f"   - 実行時に組み立てられるSQL文にVIEW名が含まれていないか確認\n"
                f"   - f-string・.format()・文字列結合を使ったSQL文を重点的に確認"
            )

        if not action_items:
            action_items.append("✅ 対応が必要な問題は検出されませんでした。")

        actions_text = "\n\n".join(action_items)

        footer = f"""---

## 次のステップ（アクションリスト）

{actions_text}

---

**レポート生成日時**: {format_datetime()}
"""

        return footer

    def _format_affected_files(self, files: List[str]) -> str:
        """影響ファイルリストをフォーマット"""
        if not files:
            return "なし"

        file_list = "\n".join([f"- `{f}`" for f in files])

        return file_list

    def _get_recommended_action(
        self, severity: str, match_type: str,
        file_path: str = "", matched_keyword: str = ""
    ) -> str:
        """推奨対応を取得（ファイルタイプとキーワードを考慮した具体的な指示）"""
        # ファイルタイプ判定
        is_sql_j2 = file_path.endswith(".j2") or file_path.endswith(".sql.j2")
        is_sql = file_path.endswith(".sql") and not is_sql_j2
        is_python = file_path.endswith(".py")

        # キーワード表示用（空の場合はデフォルト）
        kw = f"`{matched_keyword}`" if matched_keyword else "該当のVIEW/テーブル名"

        # match_type別・ファイルタイプ別の具体的な対応
        if match_type == "sql_file":
            if is_sql_j2:
                return (
                    f"このJinja2 SQLテンプレートで {kw} を参照している行を修正してください。\n"
                    f"  1. `{{% if %}}` 条件分岐を確認し、どの条件下で {kw} が使われているかを特定\n"
                    f"  2. 代替VIEWがある場合: VIEW名を新しいVIEW名に置換\n"
                    f"  3. 代替VIEWがない場合: 該当クエリをコメントアウトし、機能を無効化"
                )
            elif is_sql:
                return (
                    f"このSQLファイルで {kw} を参照している行を修正してください。\n"
                    f"  1. FROM句・JOIN句でのVIEW名を特定\n"
                    f"  2. 代替VIEWがある場合: VIEW名を新しいVIEW名に置換\n"
                    f"  3. 代替VIEWがない場合: クエリを削除またはコメントアウト"
                )
        elif match_type == "table_reference":
            if is_python:
                return (
                    f"このPythonファイルのSQL文字列内で {kw} を参照している箇所を修正してください。\n"
                    f"  1. FROM句・JOIN句のVIEW名を新しいVIEW名に置換\n"
                    f"  2. 対応するSQL文字列をgrepで全件確認: `grep -r '{matched_keyword}' <アプリパス>`\n"
                    f"  3. 代替VIEWがない場合: 該当データ取得ロジックを削除し、UIからも該当項目を非表示に"
                )
        elif match_type == "multiline_sql":
            return (
                f"このファイルの三重引用符SQLブロック内で {kw} を参照しています。\n"
                f"  1. 三重引用符（\"\"\"...\"\"\" または '''...'''）内のSQLを確認\n"
                f"  2. FROM/JOIN句のVIEW名を新しいVIEW名に置換\n"
                f"  3. 代替VIEWがない場合: 該当SQLブロックを削除し、呼び出し元の処理も削除"
            )
        elif match_type == "variable_assigned_sql":
            return (
                f"SQL文字列が変数に代入されている箇所で {kw} を参照しています。\n"
                f"  1. 変数代入文のSQL文字列内のVIEW名を修正\n"
                f"  2. その変数を使用している後続の処理も確認"
            )
        elif match_type in ("orm_query", "orm_new_style"):
            return (
                f"ORMクエリで {kw} を参照しています。\n"
                f"  1. `session.query()`・`select()` の引数を確認\n"
                f"  2. ORMモデルのテーブル名を新しいテーブル名に更新"
            )
        elif match_type == "orm_model":
            return (
                f"ORMモデル定義で {kw} が使用されています。\n"
                f"  1. `__tablename__` または `Table()` のテーブル名を更新\n"
                f"  2. このモデルを使用しているすべてのクエリも確認"
            )
        elif match_type == "column_reference":
            return (
                f"カラム参照 {kw} が検出されました。\n"
                f"  1. カラムが属するテーブル/VIEWが廃止対象か確認\n"
                f"  2. 廃止対象の場合: カラム名を新しいカラム名に変更、または参照を削除"
            )
        elif match_type == "dynamic_sql":
            return (
                "動的SQL生成箇所です。静的解析では完全な影響把握が困難です。\n"
                "  1. f-string・.format()・文字列結合でSQLを組み立てている箇所を手動確認\n"
                "  2. 実行時に廃止VIEWが含まれるSQL文が生成されないかテスト\n"
                "  3. 影響がある場合: テンプレート文字列内のVIEW名を修正"
            )
        elif match_type in ("select_star", "pochilib_snowflake"):
            return (
                "この箇所は自動検出された可能性のある参照です。手動で確認してください。\n"
                "  1. 廃止対象のVIEWが実際に参照されているかを確認\n"
                "  2. 影響がある場合のみ修正してください"
            )

        # フォールバック: 影響度別のデフォルトメッセージ
        default_actions = {
            "CRITICAL": "即座に修正してください。上記コードを確認し、廃止されるVIEW名を新しいVIEW名または代替クエリに置換してください。",
            "HIGH": "優先的に修正してください。廃止されるVIEW名の参照を特定し、代替手段に変更してください。",
            "MEDIUM": "計画的に修正してください。廃止VIEWへの参照を確認し、必要に応じて修正してください。",
            "LOW": "時間のある時に確認してください。"
        }
        return default_actions.get(severity, "確認してください。")

    def _assess_overall_risk(self, summary: Dict[str, Any]) -> str:
        """全体リスクを評価"""
        critical = summary["severity_counts"]["CRITICAL"]
        high = summary["severity_counts"]["HIGH"]
        medium = summary["severity_counts"]["MEDIUM"]
        low = summary["severity_counts"]["LOW"]

        if critical > 0:
            risk_level = "**高リスク**"
            description = f"CRITICAL問題が{critical}件検出されています。即座の対応が必要です。"
        elif high > 5:
            risk_level = "**中〜高リスク**"
            description = f"HIGH問題が{high}件検出されています。優先的な対応が必要です。"
        elif high > 0 or medium > 10:
            risk_level = "**中リスク**"
            description = "計画的な対応が推奨されます。"
        else:
            risk_level = "**低リスク**"
            description = "影響は限定的です。"

        return f"{risk_level} - {description}"

    def _sort_apps_by_severity(self, apps: Dict[str, Any]) -> List[tuple]:
        """アプリを影響度順にソート"""
        severity_order = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}

        def sort_key(item):
            app_path, app_impact = item
            max_severity = app_impact.get("max_severity", "LOW")
            return severity_order.get(max_severity, 0)

        return sorted(apps.items(), key=sort_key, reverse=True)
