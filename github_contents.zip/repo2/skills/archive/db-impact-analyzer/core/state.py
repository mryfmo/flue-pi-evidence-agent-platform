"""
Skill実行状態管理

SkillStateクラスによる状態、パス、ロギング、コンテキストの一元管理を提供します。
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from scripts.utils import load_json_safe, setup_logging


class SkillState:
    """Skill実行状態を管理するクラス"""

    def __init__(self, project_root: Optional[Path] = None):
        """
        SkillStateを初期化します。

        Args:
            project_root: プロジェクトルートパス（Noneの場合は自動検出）
        """
        # プロジェクトルートの設定
        if project_root is None:
            # state.pyから2階層上がプロジェクトルート
            self.project_root = Path(__file__).resolve().parent.parent
        else:
            self.project_root = Path(project_root).resolve()

        # run_id生成（YYYYmmdd_HHMMSS）
        self.run_id = datetime.now().strftime("%Y%m%d_%H%M%S")

        # パス構造初期化（すべて絶対パス）
        self.paths = {
            "skill_root": self.project_root,
            "config_dir": self.project_root / "config",
            "logs_dir": self.project_root / "logs",
            "reports_dir": self.project_root / "reports",
            "templates_dir": self.project_root / "templates",
            "log_file": self.project_root / "logs" / f"db-impact-analyzer-{self.run_id}.log",
        }

        # ディレクトリ作成
        for key in ["logs_dir", "reports_dir"]:
            self.paths[key].mkdir(parents=True, exist_ok=True)

        # ロギング設定
        self._logger: Optional[logging.Logger] = None
        self._init_logger()

        # コンテキスト初期化
        self.context: Dict[str, Any] = {
            "run_id": self.run_id,
            "start_time": datetime.now().isoformat(),
            "db_changes_file": None,
            "target_apps": [],
            "scan_results": {},
            "impact_summary": {},
        }

        # 設定読み込み
        self.config = self.load_config("default_config.json")
        self.detection_patterns = self.load_config("detection_patterns.json")
        self.severity_rules = self.load_config("severity_rules.json")

        self._logger.info(f"SkillState初期化完了 (run_id={self.run_id})")

    def _init_logger(self) -> None:
        """ロガーを初期化します（内部用）"""
        self._logger = setup_logging(
            log_file=self.paths["log_file"],
            log_level="INFO",
            log_format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )

    @property
    def logger(self) -> logging.Logger:
        """
        ロガーを取得します。

        Returns:
            logging.Logger: 設定済みロガー
        """
        if self._logger is None:
            self._init_logger()
        return self._logger

    def load_config(self, config_name: str) -> Dict[str, Any]:
        """
        設定ファイルを読み込みます。

        Args:
            config_name: 設定ファイル名（例: "default_config.json"）

        Returns:
            Dict: 設定内容（読み込み失敗時は空辞書）
        """
        config_path = self.paths["config_dir"] / config_name
        config = load_json_safe(config_path, logger=self.logger)

        if config is None:
            self.logger.warning(f"設定ファイル読み込み失敗（空辞書を返します）: {config_name}")
            return {}

        self.logger.info(f"設定ファイル読み込み成功: {config_name}")
        return config

    def save_context(self, context: Dict[str, Any]) -> None:
        """
        コンテキストを保存します。

        Args:
            context: 保存するコンテキスト
        """
        self.context.update(context)
        context_file = self.paths["logs_dir"] / f"context-{self.run_id}.json"

        try:
            with open(context_file, "w", encoding="utf-8") as f:
                json.dump(self.context, f, ensure_ascii=False, indent=2)
            self.logger.debug(f"コンテキスト保存成功: {context_file}")
        except Exception as e:
            self.logger.error(f"コンテキスト保存失敗: {e}")

    def update_context(self, **kwargs) -> None:
        """
        コンテキストを更新します（キーワード引数版）。

        Args:
            **kwargs: 更新する項目
        """
        self.context.update(kwargs)
        self.save_context(self.context)

    def get_report_path(self, report_name: str = "impact-report.md") -> Path:
        """
        レポートファイルパスを取得します。

        出力先の優先順位:
        1. db-changes.mdと同じディレクトリ（db_changes_dirが設定されている場合）
        2. .claude/skills/db-impact-analyzer/reports/（フォールバック）

        Args:
            report_name: レポートファイル名

        Returns:
            Path: レポートファイルパス
        """
        db_changes_dir = getattr(self, "db_changes_dir", None)
        if db_changes_dir is not None:
            return Path(db_changes_dir) / report_name
        return self.paths["reports_dir"] / report_name

    def __repr__(self) -> str:
        return f"<SkillState run_id={self.run_id} project_root={self.project_root}>"
