"""
コードスキャン

複数リポジトリをスキャンし、DB変更の影響箇所を検出します。
"""

from pathlib import Path
from typing import Dict, List, Any, Tuple
import logging

from scripts.sql_parser import SQLParser
from scripts.orm_parser import ORMParser
from scripts.file_utils import find_files, read_file_safe


class CodeScanner:
    """コードスキャンを実行するクラス"""

    def __init__(
        self,
        config: Dict[str, Any],
        detection_patterns: Dict[str, Any],
        logger: logging.Logger
    ):
        """
        CodeScannerを初期化します。

        Args:
            config: 設定
            detection_patterns: 検出パターン
            logger: ロガー
        """
        self.config = config
        self.detection_patterns = detection_patterns
        self.logger = logger

        # パーサー初期化
        self.sql_parser = SQLParser(detection_patterns, logger)
        self.orm_parser = ORMParser(detection_patterns, logger)

        # スキャン設定
        self.scan_config = config.get("scan", {})
        self.target_extensions = self.scan_config.get("target_extensions", [".py", ".sql"])
        self.exclude_dirs = self.scan_config.get("exclude_dirs", [])
        self.max_file_size_mb = self.scan_config.get("max_file_size_mb", 10)

    def scan_repositories(
        self,
        repo_paths: List[str],
        search_keywords: List[str]
    ) -> Dict[str, Any]:
        """
        複数リポジトリをスキャンします。

        Args:
            repo_paths: リポジトリパスリスト
            search_keywords: 検索キーワードリスト

        Returns:
            Dict: スキャン結果
                - total_files_scanned: int
                - total_matches: int
                - apps: Dict[app_path, app_scan_result]
                - orm_models_by_app: Dict[app_path, List[orm_model_info]]
        """
        self.logger.info(f"スキャン開始: {len(repo_paths)}個のリポジトリ")

        results = {
            "total_files_scanned": 0,
            "total_matches": 0,
            "apps": {},
            "orm_models_by_app": {}
        }

        for repo_path in repo_paths:
            self.logger.info(f"リポジトリスキャン: {repo_path}")
            app_result = self._scan_single_repository(repo_path, search_keywords)
            results["apps"][repo_path] = app_result
            results["total_files_scanned"] += app_result["files_scanned"]
            results["total_matches"] += app_result["total_matches"]
            results["orm_models_by_app"][repo_path] = app_result.get("orm_models", [])

        self.logger.info(f"スキャン完了: {results['total_files_scanned']}ファイル, "
                        f"{results['total_matches']}件の検出")

        return results

    def _scan_single_repository(
        self,
        repo_path: str,
        search_keywords: List[str]
    ) -> Dict[str, Any]:
        """
        単一リポジトリをスキャンします。

        Args:
            repo_path: リポジトリパス
            search_keywords: 検索キーワードリスト

        Returns:
            Dict: スキャン結果
                - files_scanned: int
                - total_matches: int
                - matches: List[match_detail]
                - orm_models: List[orm_model_info]
        """
        repo = Path(repo_path)
        if not repo.exists():
            self.logger.warning(f"リポジトリが存在しません: {repo_path}")
            return {"files_scanned": 0, "total_matches": 0, "matches": [], "orm_models": []}

        # ファイル検索
        target_files = find_files(
            root_dir=repo,
            extensions=self.target_extensions,
            exclude_dirs=self.exclude_dirs,
            max_size_mb=self.max_file_size_mb,
            logger=self.logger
        )

        self.logger.debug(f"検索対象ファイル: {len(target_files)}件")

        matches = []
        for file_path in target_files:
            file_matches = self._scan_single_file(file_path, search_keywords)
            matches.extend(file_matches)

        # ORMモデル静的抽出
        orm_models = self._extract_orm_models(repo)

        return {
            "files_scanned": len(target_files),
            "total_matches": len(matches),
            "matches": matches,
            "orm_models": orm_models
        }

    def _extract_orm_models(self, repo_path: Path) -> List[Dict[str, Any]]:
        """
        リポジトリ内のSQLAlchemy ORMモデル定義を静的抽出します。

        __tablename__ を持つクラスを対象に、スキーマ・カラム一覧を抽出します。

        Args:
            repo_path: リポジトリルートパス

        Returns:
            List[Dict]: ORMモデル情報のリスト
        """
        import re as _re

        results = []

        # .py ファイルのみが対象
        py_files = find_files(
            root_dir=repo_path,
            extensions=[".py"],
            exclude_dirs=self.exclude_dirs,
            max_size_mb=self.max_file_size_mb,
            logger=self.logger
        )

        for file_path in py_files:
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            # __tablename__ を含まないファイルは早期スキップ
            if "__tablename__" not in content:
                continue

            lines = content.splitlines()

            # クラス定義の開始行を特定
            class_start_pattern = _re.compile(r"^class\s+(\w+)\s*[\(:]")
            tablename_pattern = _re.compile(r'__tablename__\s*=\s*["\']([^"\']+)["\']')
            schema_pattern = _re.compile(r'"schema"\s*:\s*["\']([^"\']+)["\']')
            column_pattern = _re.compile(r'^\s+(\w+)\s*:\s*Mapped\[([^\]]+)\]')
            primary_key_pattern = _re.compile(r'mapped_column\(.*primary_key\s*=\s*True', _re.IGNORECASE)

            i = 0
            while i < len(lines):
                line = lines[i]
                class_match = class_start_pattern.match(line)
                if not class_match:
                    i += 1
                    continue

                class_name = class_match.group(1)
                class_start = i

                # クラスブロックの終端を特定（次の非インデント行まで）
                j = i + 1
                while j < len(lines):
                    next_line = lines[j]
                    # 空行・コメント行はスキップ
                    if next_line.strip() == "" or next_line.strip().startswith("#"):
                        j += 1
                        continue
                    # 次のクラスまたはトップレベル定義に到達
                    if next_line and not next_line[0].isspace():
                        break
                    j += 1

                class_block_lines = lines[class_start:j]
                class_block = "\n".join(class_block_lines)

                # __tablename__ 抽出
                tbl_match = tablename_pattern.search(class_block)
                if not tbl_match:
                    i = j
                    continue

                tablename = tbl_match.group(1)

                # スキーマ抽出
                schema_match = schema_pattern.search(class_block)
                schema = schema_match.group(1) if schema_match else None

                # 完全修飾名
                full_qualified_name = f"{schema}.{tablename}" if schema else tablename

                # カラム定義抽出（Mapped[...] スタイル）
                columns = []
                for cl in class_block_lines:
                    col_match = column_pattern.match(cl)
                    if col_match:
                        attr_name = col_match.group(1)
                        col_type = col_match.group(2).strip()
                        is_pk = bool(primary_key_pattern.search(cl))
                        columns.append({
                            "attr_name": attr_name,
                            "type": col_type,
                            "primary_key": is_pk
                        })

                self.logger.debug(
                    f"ORMモデル抽出: {class_name} ({full_qualified_name}), "
                    f"カラム数={len(columns)}, ファイル={file_path}"
                )

                results.append({
                    "class_name": class_name,
                    "file": str(file_path),
                    "tablename": tablename,
                    "schema": schema,
                    "full_qualified_name": full_qualified_name,
                    "columns": columns,
                    "column_count": len(columns),
                    "is_view": tablename.lower().startswith("vw_"),
                    "deprecated_view_match": None,  # skill_entry.py で後から設定
                })

                i = j

        self.logger.info(f"ORMモデル抽出完了: {len(results)}件 ({repo_path})")
        return results

    def _extract_context_lines(
        self,
        lines: List[str],
        target_line_num: int,
        context_length: int = 3
    ) -> Tuple[List[str], List[str]]:
        """
        マッチ行の前後N行を返します。ファイル境界は安全にクリップします。

        Args:
            lines: 全行リスト
            target_line_num: 対象行番号（1ベース）
            context_length: 前後の行数

        Returns:
            Tuple[List[str], List[str]]: (前のN行, 後のN行)
        """
        idx = target_line_num - 1  # 1ベース → 0ベース
        before = lines[max(0, idx - context_length):idx]
        after = lines[idx + 1:min(len(lines), idx + 1 + context_length)]
        return before, after

    def _scan_single_file(
        self,
        file_path: Path,
        search_keywords: List[str]
    ) -> List[Dict[str, Any]]:
        """
        単一ファイルをスキャンします。

        Args:
            file_path: ファイルパス
            search_keywords: 検索キーワードリスト

        Returns:
            List[Dict]: 検出結果リスト
        """
        # ファイル読み込み
        content = read_file_safe(file_path, logger=self.logger)
        if content is None:
            return []

        matches = []

        # 全行リスト（コンテキスト抽出用）
        all_lines = content.split("\n")

        # SQL解析
        if file_path.suffix == ".py":
            # テーブル参照検出
            table_refs = self.sql_parser.extract_table_references(content)
            for table_name, line_num, code_line in table_refs:
                if self._is_keyword_match(table_name, search_keywords):
                    ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                    matches.append({
                        "file": str(file_path),
                        "line": line_num,
                        "code": code_line,
                        "match_type": "table_reference",
                        "matched_keyword": table_name,
                        "detection_method": "sql_parser",
                        "context_before": ctx_before,
                        "context_after": ctx_after
                    })

            # カラム参照検出
            column_refs = self.sql_parser.extract_column_references(content)
            for column_name, line_num, code_line in column_refs:
                if self._is_keyword_match(column_name, search_keywords):
                    ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                    matches.append({
                        "file": str(file_path),
                        "line": line_num,
                        "code": code_line,
                        "match_type": "column_reference",
                        "matched_keyword": column_name,
                        "detection_method": "sql_parser",
                        "context_before": ctx_before,
                        "context_after": ctx_after
                    })

            # 動的SQL検出
            dynamic_sqls = self.sql_parser.detect_dynamic_sql(content)
            for _, line_num, code_line in dynamic_sqls:
                ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                matches.append({
                    "file": str(file_path),
                    "line": line_num,
                    "code": code_line,
                    "match_type": "dynamic_sql",
                    "matched_keyword": "dynamic_sql",
                    "detection_method": "sql_parser",
                    "warning": True,
                    "context_before": ctx_before,
                    "context_after": ctx_after
                })

            # SELECT * 検出
            select_stars = self.sql_parser.detect_select_star(content)
            for _, line_num, code_line in select_stars:
                ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                # SELECT * は影響度LOW
                matches.append({
                    "file": str(file_path),
                    "line": line_num,
                    "code": code_line,
                    "match_type": "select_star",
                    "matched_keyword": "SELECT *",
                    "detection_method": "sql_parser",
                    "low_severity": True,
                    "context_before": ctx_before,
                    "context_after": ctx_after
                })

            # ORM解析
            if self.orm_parser.detect_orm_usage(content):
                # ORMモデル検出
                orm_models = self.orm_parser.extract_orm_models(content)
                for model_name, line_num, code_line in orm_models:
                    if self._is_keyword_match(model_name, search_keywords):
                        ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                        matches.append({
                            "file": str(file_path),
                            "line": line_num,
                            "code": code_line,
                            "match_type": "orm_model",
                            "matched_keyword": model_name,
                            "detection_method": "orm_parser",
                            "context_before": ctx_before,
                            "context_after": ctx_after
                        })

                # ORMクエリ検出
                orm_queries = self.orm_parser.extract_orm_queries(content)
                for ref_name, line_num, code_line in orm_queries:
                    if self._is_keyword_match(ref_name, search_keywords):
                        ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                        matches.append({
                            "file": str(file_path),
                            "line": line_num,
                            "code": code_line,
                            "match_type": "orm_query",
                            "matched_keyword": ref_name,
                            "detection_method": "orm_parser",
                            "context_before": ctx_before,
                            "context_after": ctx_after
                        })

                # SQLAlchemy新スタイルAPI検出
                new_style_queries = self.orm_parser.extract_new_style_queries(content)
                for ref_name, line_num, code_line in new_style_queries:
                    if self._is_keyword_match(ref_name, search_keywords):
                        ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                        matches.append({
                            "file": str(file_path),
                            "line": line_num,
                            "code": code_line,
                            "match_type": "orm_new_style",
                            "matched_keyword": ref_name,
                            "detection_method": "orm_parser",
                            "context_before": ctx_before,
                            "context_after": ctx_after
                        })

                # pochilib Snowflake関数検出
                pochilib_calls = self.orm_parser.extract_pochilib_snowflake_calls(content)
                for ref_name, line_num, code_line in pochilib_calls:
                    if ref_name == "pochilib_snowflake_call":
                        # テーブル名が特定できなかった場合: LOW警告として記録（誤検知防止）
                        ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                        matches.append({
                            "file": str(file_path),
                            "line": line_num,
                            "code": code_line,
                            "match_type": "pochilib_snowflake",
                            "matched_keyword": "pochilib_snowflake_call",
                            "detection_method": "orm_parser",
                            "low_severity": True,
                            "warning": True,
                            "context_before": ctx_before,
                            "context_after": ctx_after
                        })
                    elif self._is_keyword_match(ref_name, search_keywords):
                        # テーブル名が特定でき、かつ検索キーワードと一致した場合のみ HIGH として記録
                        ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                        matches.append({
                            "file": str(file_path),
                            "line": line_num,
                            "code": code_line,
                            "match_type": "pochilib_snowflake",
                            "matched_keyword": ref_name,
                            "detection_method": "orm_parser",
                            "context_before": ctx_before,
                            "context_after": ctx_after
                        })

            # 複数行SQL検出（ORMとは独立して実行）
            multiline_sqls = self.orm_parser.extract_multiline_sql(content)
            for ref_name, line_num, code_line in multiline_sqls:
                if self._is_keyword_match(ref_name, search_keywords):
                    ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                    matches.append({
                        "file": str(file_path),
                        "line": line_num,
                        "code": code_line,
                        "match_type": "multiline_sql",
                        "matched_keyword": ref_name,
                        "detection_method": "orm_parser",
                        "context_before": ctx_before,
                        "context_after": ctx_after
                    })

            # 変数代入SQL検出
            variable_sqls = self.sql_parser.extract_variable_assigned_sql(content)
            for ref_name, line_num, code_line in variable_sqls:
                if self._is_keyword_match(ref_name, search_keywords):
                    ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                    matches.append({
                        "file": str(file_path),
                        "line": line_num,
                        "code": code_line,
                        "match_type": "variable_assigned_sql",
                        "matched_keyword": ref_name,
                        "detection_method": "sql_parser",
                        "context_before": ctx_before,
                        "context_after": ctx_after
                    })

        elif file_path.suffix in (".sql", ".j2") or str(file_path).endswith(".sql.j2"):
            # .sql / .sql.j2 / .j2 ファイルは直接キーワード検索
            for line_num, line in enumerate(all_lines, start=1):
                # SQLコメント行をスキップ
                stripped = line.strip()
                if stripped.startswith("--") or stripped.startswith("/*"):
                    continue
                # Jinja2コメント行をスキップ
                if stripped.startswith("{#"):
                    continue

                for keyword in search_keywords:
                    # 大文字小文字を無視した単語境界付き検索
                    import re as _re
                    if _re.search(r'(?<![A-Z0-9_])' + _re.escape(keyword.upper()) + r'(?![A-Z0-9_])',
                                  line.upper()):
                        ctx_before, ctx_after = self._extract_context_lines(all_lines, line_num)
                        matches.append({
                            "file": str(file_path),
                            "line": line_num,
                            "code": line.strip(),
                            "match_type": "sql_file",
                            "matched_keyword": keyword,
                            "detection_method": "direct_search",
                            "context_before": ctx_before,
                            "context_after": ctx_after
                        })

        if matches:
            self.logger.debug(f"{file_path}: {len(matches)}件検出")

        return matches

    def _is_keyword_match(self, text: str, keywords: List[str]) -> bool:
        """
        テキストがキーワードリストにマッチするかを判定します。

        Args:
            text: 検証するテキスト
            keywords: キーワードリスト

        Returns:
            bool: マッチする場合True
        """
        text_lower = text.lower()
        for keyword in keywords:
            keyword_lower = keyword.lower().strip('"').strip("'")
            if keyword_lower == text_lower or keyword_lower in text_lower:
                return True
        return False
