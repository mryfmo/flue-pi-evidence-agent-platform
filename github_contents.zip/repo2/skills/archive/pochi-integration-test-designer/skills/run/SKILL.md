---
name: pochi-integration-test-designer
description: >-
  Layer3 結合テストの設計書をMarkdown形式で生成するSkill。
  @st.cache_data/@st.cache_resource付き関数・Streamlit UI結合・session_state操作を
  対象にした結合テストシナリオを設計する。テストコードは生成しない（Phase1のみ担当）。
  「Layer3の結合テストを設計して」「結合テスト設計書を作成して」
  「結合テストのシナリオを設計して」「pochi-integration-test-designerを起動」と言われたときに使用する。
---

# pochi-integration-test-designer Skill

## スキル概要

Layer3 結合テストの**設計書**をMarkdown形式で生成する。テストコードは生成しない（Phase1のみ担当）。
設計書を人間がレビュー・修正した後、`pochi-integration-test-generator` でテストコードを生成する2段階ワークフロー。

### 生成対象

| 出力 | パス | 内容 |
|---|---|---|
| 設計書 | `{app_path}/tests/.onboarding/integration-test-design.md` | Layer3 シナリオ一覧 |

### テスト対象（Layer3 の守備範囲）

- `@st.cache_data` / `@st.cache_resource` デコレータ付き関数（単体テスト単独ではテスト不可）
- Streamlit の `session_state` を操作・参照する関数
- UI 要素（`st.dataframe`, `st.plotly_chart` 等）を呼び出す関数
- ページ単位の表示フロー（正常系・異常系）

> ⚠️ **絶対必須・直接実行禁止**
>
> このスキルの全ワークフローは、以下に定義するカスタムサブエージェントを
> **Agentツールで起動**して実行すること。
> Claude Code（あなた自身）が直接設計書を生成することは**厳禁**。

---

## STEP 0: test-strategy-config.json の確認

情報収集前に `test-strategy-config.json` を確認する。

```
Glob で {app_path}/tests/.onboarding/test-strategy-config.json を検索する。
app_path が未確定の場合は、STEP 1 の情報収集後に確認する。
```

**ファイルが存在する場合**:
→ ファイルを Read して以下を確認する：
  - `layers.L3_integration.ratio` → Layer3 の目標比率
  - `app_specific_rules.key_rules` → 設計時に考慮するドメインルール
  - `quality_targets.coverage_minimum` → カバレッジ目標

これらの値を STEP 4（設計書生成）のサブエージェント指示に含める。

**mock_strategy の参照（追加確認項目）**:
ファイルが存在する場合、さらに以下を確認する：
  - `mock_strategy.always_mock` → Layer3 でも必ずモックするパッケージ一覧
  - `mock_strategy.never_mock` → Layer3 では本物を使うパッケージ一覧
  - `mock_strategy.layer_conditional` → Layer 別に切り替えるパッケージと方針

`mock_strategy` が存在しない場合はデフォルト方針（Snowflake/Streamlit はモック、その他は本物）を使用する。
これらの値を STEP 4（設計書生成）のサブエージェント指示に含める。

**ファイルが存在しない場合**:
→ 以下のメッセージを出力してスキルを終了する（以降のステップは実行しない）：

```
❌ テスト戦略設定ファイルが見つかりません。

  必要なファイル: {app_path}/tests/.onboarding/test-strategy-config.json

  このスキルを実行する前に、まず以下のコマンドでテスト戦略を初期化してください：
  「テスト戦略を初期化して」または「pochi-test-strategy-initializer を起動」

  pochi-test-strategy-initializer は、モック方針・品質目標・Layer比率を決定し、
  test-strategy-config.json を生成します。
```

---

## STEP 1: ユーザー情報収集

AskUserQuestionツールで以下を確認する（**最大2回の質問で完結させること**）：

**1回目（必須）**:
- **`app_path`**: 対象アプリのリポジトリルートパス（例: `/home/user/my-pochi-app`）
- **`entrypoint`**: アプリのエントリポイントファイル（例: `app.py`）

**2回目（推奨項目を一括提示）**:
以下の項目を一覧で提示し、ユーザーが「デフォルトで続行」を選べるようにする：
- **対象ページの絞り込み**: `pages/` 配下が多い場合にテスト対象を限定可能
- **既存設計書の有無**: `tests/.onboarding/integration-test-design.md` が既に存在する場合、上書き確認
- **リスク重点カバー**: `risk-catalog.md` の特定リスクIDを優先してシナリオ設計するか

情報収集後、以下の実行計画を提示して確認を取ること：

```
実行計画:
  STEP 2:   前提ファイル確認（contracts/ / module-inventory.json の存在チェック）
  STEP 3-A: Layer3 対象関数の特定（@st.cache_data 付き関数 / session_state 操作関数）
  STEP 3-B: 依存グラフの抽出（関数間接続の特定）
  STEP 4:   設計書生成（pochi-t2-tdd-workflow / integration-test-designer）
  STEP 5:   設計書レビュー確認
  STEP 6:   完了レポート
```

---

## STEP 2: 前提ファイル確認

以下のファイルの存在を確認する：

**必須ファイル**:
```
{app_path}/tests/.onboarding/module-inventory.json
{app_path}/tests/contracts/data-contracts.json
{app_path}/tests/contracts/business-rules.json
{app_path}/tests/contracts/test-viewpoints.json
{app_path}/tests/contracts/risk-catalog.md
```

### ファイルが存在する場合 → STEP 3 へ

### ファイルが存在しない場合 → ユーザーに選択肢を提示

```
📋 前提ファイルが見つかりません。
Layer3 結合テスト設計には以下が必要です：
  - module-inventory.json（コード解析結果）
  - contracts/ 6ファイル（テスト品質契約）

どうしますか？

[A] pochi-unit-test-generator を先に実行する
    → Layer1・2テストも同時に生成されます（推奨）
[B] 前提ファイルのみ生成する（T0→T1→T4）
    → Layer1・2テストは生成しません。このスキル内でT0→T1→T4を実行します。
[C] 中止する
```

- **[A]** を選択: 「`pochi-unit-test-generator` を実行してから、このスキルを再度起動してください」と案内してスキル終了
- **[B]** を選択: STEP 2-B へ
- **[C]** を選択: スキル終了

### STEP 2-B: T0→T1→T4 内部実行

> ⚠️ **必須**: 各フェーズで必ず対応するカスタムサブエージェントを起動すること

**B-1: T0 実行（既存コード解析）**

```
Agentツールで pochi-t0-legacy-analyzer カスタムサブエージェント
（subagent_type: "pochi-test-onboarding:pochi-t0-legacy-analyzer"）を起動し、
以下を実行させてください：
- {app_path} 配下の既存コードを静的解析する
- エントリポイント: {entrypoint}
- 出力先: {app_path}/tests/.onboarding/draft-contracts/（ドラフト契約ファイル群）
- 出力先: {app_path}/tests/.onboarding/module-inventory.json（モジュール一覧）
  ※ framework フィールドを必ず出力すること（"streamlit" / "flask" / "cli" 等）
  ※ streamlit_decorators フィールドを必ず出力すること（@st.cache_data 付き関数のリスト）
```

**B-2: T1 実行（テスト契約初期化）**

```
Agentツールで pochi-t1-contract-initializer カスタムサブエージェント
（subagent_type: "pochi-test-onboarding:pochi-t1-contract-initializer"）を起動し、
以下を実行させてください：
- 入力: {app_path}/tests/.onboarding/draft-contracts/（T0の出力）
- ドラフト契約を確認モードで読み込み、最終的な6ファイルを確定する
- 出力先: {app_path}/tests/contracts/
```

T1完了後、以下の情報をユーザーに提示する：

```
📋 T1 完了 - 契約ファイル確認
  - data-contracts.json: エンティティ数 X / フィールド数合計 Y
  - business-rules.json: ルール数 X 件
  - test-viewpoints.json: 観点数 X 件

内容を確認しますか？ それとも続行しますか？
  [A] 続行する
  [B] contracts/ の内容を確認してから続行する
```

ユーザーが [B] を選択した場合は `{app_path}/tests/contracts/` の内容を提示し、
以下の選択肢を提示する：

```
  [B-1] 内容を確認済み。このまま続行する
  [B-2] 内容に問題があるため T1 を再実行する（pochi-t1-contract-initializer を再起動）
  [B-3] 中止する
```

- [B-1] を選択: T4（B-3）に進む
- [B-2] を選択: B-2 の T1 実行ブロックに戻り、再実行後に再度チェックポイントを表示する
- [B-3] を選択: スキル終了

**B-3: T4 実行（テストデータセット生成）**

```
Agentツールで pochi-t4-fixtures-manager カスタムサブエージェント
（subagent_type: "pochi-test-onboarding:pochi-t4-fixtures-manager"）を起動し、
以下を実行させてください：
- 入力: {app_path}/tests/contracts/data-contracts.json（T1の出力）
- valid / invalid / edge の3種類のテストデータセットを生成する
- 出力先: {app_path}/tests/fixtures/
```

完了後 STEP 3 へ。

---

## STEP 3-A: Layer3 対象関数の特定

`{app_path}/tests/.onboarding/module-inventory.json` を読み込み、以下の条件で Layer3 対象関数を抽出する：

**抽出条件**:
1. `streamlit_decorators` フィールドに `@st.cache_data` / `@st.cache_resource` が含まれる関数
2. `app.py` / `pages/*.py` から直接呼び出されている関数（ページのエントリ関数）
3. `st.session_state` を操作・参照する関数
4. UI 要素（`st.dataframe`, `st.plotly_chart`, `st.write` 等）を呼び出す関数

抽出結果をユーザーに提示する：

```
📋 Layer3 対象関数（Layer3 結合テストで検証すべき関数）:

| # | 関数名 | モジュールパス | 理由 |
|---|--------|--------------|------|
| 1 | load_data() | lib/data_loader.py | @st.cache_data 付き |
| 2 | render_chart() | lib/viz.py | st.plotly_chart 使用 |
| 3 | update_filters() | pages/dashboard.py | session_state 操作 |

この一覧で進めますか？ 追加・除外があれば指定してください。
```

ユーザーの確認を取ってから STEP 3-B へ。

---

## STEP 3-B: 依存グラフの抽出

STEP 3-A で特定した関数について、`{app_path}/app/` 配下のソースコードを読み取り、
関数間の「接続」を抽出する。

**抽出する接続の種類**:
- **a. 直接呼び出し**: 関数A の中で関数B を呼んでいる
- **b. session_state 経由**: 関数A が書き込んだキーを関数B が読み取る
- **c. 戻り値経由**: 関数A の戻り値が関数B の引数として渡される

**テスト優先度の判定基準**:
- 高: session_state 経由 or 型変換を伴う戻り値受け渡し
- 中: 同一モジュール内の直接呼び出し
- 低: ユーティリティ関数の呼び出し

抽出結果をユーザーに提示する（設計書内にも記載する）：

```
📋 関数間接続一覧（依存グラフ）:

| 接続ID | 接続元 | 接続先 | 経路 | 受け渡すデータ | テスト優先度 |
|--------|--------|--------|------|---------------|------------|
| E-001 | on_click_search_button | search_btn_is_disabled | session_state | input_conditions, render_options | 高 |
| E-002 | _filter_by_oaza | get_concat_address | 戻り値 | DataFrame(oaza_popularname_kanji, ...) | 高 |

この接続一覧で進めますか？ 追加・修正があれば指定してください。
```

ユーザーの確認を取ってから STEP 4 へ。

---

## STEP 4: 設計書生成

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"`）を起動すること。
> Claude Code 自身が設計書を直接書くことは厳禁。

```
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow のサブエージェント
integration-test-designer を起動し、以下を実行させてください：

【Layer3 設計書生成モード】

■ 入力情報:
  - STEP 3 で特定した Layer3 対象関数リスト
  - {app_path}/tests/contracts/data-contracts.json
  - {app_path}/tests/contracts/business-rules.json
  - {app_path}/tests/contracts/test-viewpoints.json
  - {app_path}/tests/contracts/risk-catalog.md
  - {app_path}/tests/.onboarding/module-inventory.json
  - {app_path}/app/ 配下のソースコード（対象関数の実装を読む）

■ 出力先:
  {app_path}/tests/.onboarding/integration-test-design.md

■ 設計書フォーマット（以下の構造で出力すること）:

---
# Layer3 結合テスト設計書

## 生成メタデータ
- 生成日時: {timestamp}
- 対象アプリ: {app_path}
- エントリポイント: {entrypoint}
- 対象関数数: {count}

## テスト対象関数一覧
| # | 関数名 | モジュールパス | デコレータ | テスト優先度 | 理由 |
|---|--------|--------------|-----------|------------|------|

## 関数間接続一覧（依存グラフ）
| 接続ID | 接続元 | 接続先 | 経路 | 受け渡すデータ | テスト優先度 |
|--------|--------|--------|------|---------------|------------|
| E-001 | {関数名} | {関数名} | {session_state / 戻り値 / 直接呼び出し} | {データ内容} | {高/中/低} |

## テストシナリオ（正常系）

### シナリオ1: {接続元}→{接続先}の{接続経路}連携
- **接続ID**: E-XXX（依存グラフから参照）
- **接続元関数**: {関数名}（実コード実行）
- **接続先関数**: {関数名}（実コード実行）
- **接続経路**: {session_state["キー名"] / 戻り値 DataFrame / 引数}
- **モック対象**: {外部依存のみ。接続元・接続先の関数自体はモックしない}
- **前提状態**:
  - session_state: {初期状態}
  - モックデータ: {fixtures 参照}
- **手順**:
  1. 接続元関数を実行する（実コード）
  2. 接続経路（session_state / 戻り値）の中間状態を検証する
  3. 接続先関数を実行する（実コード）
  4. 最終結果を具体値で検証する
- **検証ポイント**:
  - [ ] 接続元の実行後に接続経路にデータが存在すること
  - [ ] 接続先が接続経路のデータを正しく読み取れること
  - [ ] 最終結果が具体的な期待値と一致すること
- **禁止事項**:
  - [ ] 接続元・接続先の関数をモック化していないこと
  - [ ] モックの戻り値を直接検証するテストになっていないこと
- **リスク対応**: {risk-catalog.md のリスクID（該当する場合）}

### シナリオ2: ...

## テストシナリオ（異常系）

### 異常系1: {Snowflake接続エラー時の画面表示}
- **関連する接続ID**: E-XXX（正常系シナリオとの対応を明示）
- Snowflake モックが例外を送出する
- エラーメッセージ / 警告メッセージが画面に表示されることを検証する

### 異常系2: {空データ返却時の画面表示}
- **関連する接続ID**: E-XXX（正常系シナリオとの対応を明示）
- モックが空 DataFrame を返却する
- 「データがありません」等のフォールバック表示を検証する

## モック対象一覧
| # | 対象 | importパス | patchパス | モック方針 |
|---|------|-----------|----------|-----------|
| 1 | Snowflake セッション | lib.xxx | lib.xxx.get_session | スタブに差し替える |
| 2 | @st.cache_data | streamlit | キャッシュを無効化してテスト用に差し替える |

## テスト前提条件・フィクスチャ要件
- テスト共通セットアップに必要な前提条件一覧
- 既存テスト設定との重複回避方針
---

■ 設計ルール（必ず遵守すること）:

【カバレッジ観点（必ず網羅）】
1. 正常表示: 各ページの主要UI要素が表示されること
2. データ連携: Snowflakeから取得→加工→UI表示の一連フロー
3. ユーザー操作: ボタン/セレクトボックス/スライダー等の操作後の状態変化
4. エラーハンドリング: 外部サービスエラー時のフォールバック表示
5. キャッシュ: @st.cache_data 付き関数が正しくモック化されること
6. セッション状態: session_state の読み書きが正しいこと
7. 関数間接続: 依存グラフで抽出した全接続（優先度「高」）がシナリオ化されていること

【シナリオ粒度】
- 1シナリオ = 1接続（依存グラフの1エッジ）
- 複数の接続が連鎖するフロー（A→B→C）は1シナリオにまとめてよい
- 同一接続の入力パターン違いはシナリオ内のバリエーションとして扱う

【命名規則】
- シナリオ名: {接続元}_{接続先}_{接続経路}_{期待結果}
  例: on_click_search_btn_is_disabled_session_state_再検索ブロック
      filter_oaza_get_concat_address_戻り値_住所結合成功

【risk-catalog.md との対応】
- risk-catalog.md の全リスクIDを参照し、Layer3 で対応可能なリスクにシナリオを設計する
- シナリオの「リスク対応」フィールドにリスクIDを記載する
```

### エラー時の対応（STEP 4）
- サブエージェントがエラー終了した場合: エラーメッセージをユーザーに提示し、続行/中止/リトライを確認する
- `integration-test-design.md` が出力されなかった場合: contracts/ / app/ の内容を確認し、解析対象の再指定を促す

設計書が生成されたら STEP 5 へ。

---

## STEP 5: 設計書レビュー確認

生成された設計書を読み取り、以下の要約をユーザーに提示する：

```
📋 Layer3 結合テスト設計書 生成完了

  シナリオ数: 正常系 X 件 / 異常系 Y 件 / 合計 Z 件
  対象ページ: {ページ一覧}
  対象関数: W 件
  モック対象: {モック一覧（主要なもの）}
  リスクカバレッジ: {対応済みリスクID / 全リスクID} 件

設計書を確認しますか？
  [A] 確認してから次に進む
  [B] このままテストコード生成に進む（pochi-integration-test-generator）
  [C] 完了（設計書のみで終了）
```

- **[A]** を選択: `{app_path}/tests/.onboarding/integration-test-design.md` の内容を提示し、
  「内容を確認しました。次のステップを選択してください」として再度 [B] / [C] を提示する
- **[B]** を選択: 「`pochi-integration-test-generator` で テストコードを生成してください」と案内して STEP 6 へ
- **[C]** を選択: STEP 6 へ

---

## STEP 6: 完了レポート

以下の形式で完了を報告する：

```
✅ pochi-integration-test-designer 完了

📁 生成ファイル:
  - {app_path}/tests/.onboarding/integration-test-design.md

📊 設計サマリー:
  - 正常系シナリオ: X 件
  - 異常系シナリオ: Y 件
  - 合計シナリオ数: Z 件
  - 対象関数数: W 件
  - モック対象: {主要なもの}

🚀 次のステップ:
  1. 設計書を確認・修正してください:
     {app_path}/tests/.onboarding/integration-test-design.md

  2. テストコードを生成する場合:
     「結合テストコードを生成して」と依頼してください
     （pochi-integration-test-generator が起動します）
```

---

## 既存ファイルの扱い

- `integration-test-design.md` が既に存在する場合:
  → `.bak` ファイルにバックアップしてから上書きする
  → ユーザーに「既存の設計書をバックアップして上書きします」と通知する

---

## 注意事項

- **直接生成禁止**: Claude Code 本体が設計書を直接書くことは絶対に禁止。必ずサブエージェント経由で生成すること。
- **Layer1・2 非対応**: このスキルは Layer3 設計書のみを生成する。Layer1・2 が必要な場合は `pochi-unit-test-generator` を使用すること。
- **テスト実行設定は生成しない**: テスト実行設定ファイルの生成は `pochi-integration-test-generator`（Phase2）の責務。
- **Layer4（E2E）非対応**: このスキルは Layer3 のみ対象。Layer4 が必要な場合は `pochi-e2e-test-generator` を使用すること。
