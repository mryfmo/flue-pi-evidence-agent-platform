---
name: pochi-e2e-base-verifier
description: >-
  E2Eテストジェネレーターが生成したBasePage等の基盤ファイルを検証する固定テストファイル
  をアプリリポジトリに配置するSkill。
  「E2Eベース検証ファイルを配置して」「pochi-e2e-base-verifier を起動」で起動する。
---

# Skill: Pochi E2E Base Verifier

**このSkillは、`pochi-e2e-test-generator` が生成したE2Eテスト基盤ファイル（`base_page.py` 等）を検証するための固定テストファイルをアプリリポジトリに配置します。**

## Trigger Phrases

### 固有トリガー（推奨・明示的）
- E2Eベース検証ファイルを配置して
- BasePage検証ファイルを配置して
- E2Eテスト基盤を検証して

### Skill直接起動
- pochi-e2e-base-verifier を起動
- pochi-e2e-base-verifier 起動
- Skillツールを使用して pochi-e2e-base-verifier を起動してください

### 英語トリガー
- deploy e2e base verifier
- install e2e base verifier
- place e2e base verification files

## When

### 起動条件
上記TriggerPhrasesのいずれかが発話されたら、直ちにこのSkillを起動してください。

### 前提条件
- `pochi-e2e-test-generator` がすでに実行済みで、対象アプリに `tests/e2e/pages/base_page.py` が生成済みであること
- 対象アプリリポジトリのパスが特定できること

### 起動しない条件（誤起動防止）
- ❌ 「E2Eテストを生成して」（→ pochi-e2e-test-generator を使用）
- ❌ 「E2Eテストを実行して」（→ 直接 pytest を実行）
- ❌ 「BasePage を確認して」（→ 読み取り操作）

## Do

**以下の手順を順番に実行してください。**

### ステップ1: 対象アプリリポジトリのパスを確認

ユーザーに対象アプリリポジトリの絶対パスを確認してください。
例: `/home/user/ALADIN-WDH`

既にコンテキストから判明している場合はスキップしてよい。

### ステップ2: 前提条件チェック

以下のファイルが存在するか確認してください：

```
{app_path}/tests/e2e/pages/base_page.py       # BasePage（必須）
{app_path}/tests/e2e/conftest.py              # conftest（必須）
{app_path}/tests/e2e/e2e_config.py            # e2e_config（必須）
```

存在しない場合は、先に `pochi-e2e-test-generator` を実行するよう案内してスキルを終了する。

### ステップ3: 検証ファイルの配置先ディレクトリを確認・作成

```
{app_path}/tests/e2e/                        # 既存ディレクトリ
{app_path}/tests/e2e/pages/                  # 既存ディレクトリ
{app_path}/tests/e2e/test_apps/              # 新規作成（スタンドアロンテストアプリ置き場）
```

`tests/e2e/test_apps/` が存在しない場合は作成する。

### ステップ4: 検証ファイルを配置

このスキルリポジトリ（`pochi-dp-developer-docs`）の以下のソースファイルを読み込み、アプリリポジトリに配置してください。

**配置対象ファイル一覧:**

| ソース（このリポジトリ） | 配置先（アプリリポジトリ） |
|---|---|
| `plan/ALADIN-WDH/test_alert_display.py` | `{app_path}/tests/e2e/test_alert_display.py` |
| `plan/ALADIN-WDH/test_dataframe_download_button.py` | `{app_path}/tests/e2e/test_dataframe_download_button.py` |

**注意事項:**
- ソースファイルを読み込んで内容をそのまま配置する（内容を変更しない）
- 既にファイルが存在する場合はユーザーに確認してから上書きする

### ステップ5: DataframeDownloadButtonTestPage クラスを生成・配置

`test_dataframe_download_button.py` が依存する Page Object クラスを生成してください。

配置先: `{app_path}/tests/e2e/pages/dataframe_download_button_test_page.py`

生成するクラスの仕様:
- `BasePage` を継承する
- `{app_path}/tests/e2e/pages/base_page.py` を読み込み、`BasePage` のインタフェースに合わせた実装にする
- 以下のメソッドを実装する:

```python
class DataframeDownloadButtonTestPage(BasePage):
    """DataFrameダウンロードボタン非表示検証用のPage Object"""

    def verify_page_loaded(self) -> None:
        """ページの読み込み完了を待機・確認"""
        # BasePage の wait_for_app_ready() または wait_for_not_running() を使用

    def get_dataframe_container(self):
        """st.dataframe のコンテナ要素を返す（最初のDataFrame）"""
        # data-testid="stDataFrame" を使用

    def get_data_editor_container(self):
        """st.data_editor のコンテナ要素を返す（最初のDataEditor）"""
        # data-testid="stDataEditor" を使用

    def verify_dataframe_download_button_hidden(self) -> None:
        """st.dataframe のダウンロードボタンが非表示であることを確認"""
        # ダウンロードボタンのセレクタ: [data-testid="stElementToolbarButton"][title="Download as CSV"]
        # または同等のセレクタ
        # Playwright の expect(locator).to_be_hidden() を使用

    def verify_data_editor_download_button_hidden(self) -> None:
        """st.data_editor のダウンロードボタンが非表示であることを確認"""
        # 同上
```

**重要**: `base_page.py` の実際の内容を確認してから、既存メソッドと整合するように実装すること。

### ステップ6: テスト用スタンドアロンアプリを生成・配置（オプション）

`test_alert_display.py` が参照するテスト用アプリ（コメントに `tests/e2e/playwright/test_apps/test_alert_display_app.py` と記載）が必要な場合、ユーザーに確認してから生成する。

生成するアプリの仕様:
- 配置先: `{app_path}/tests/e2e/test_apps/test_alert_display_app.py`
- Streamlit アプリとして機能する
- 以下のボタンを持つ:
  - ✅ Success → `st.success("成功メッセージです")` を表示
  - ❌ Error → `st.error("エラーメッセージです")` を表示
  - ⚠️ Warning → `st.warning("警告メッセージです")` を表示
  - ℹ️ Info → `st.info("情報メッセージです")` を表示
  - 💥 Exception → `st.exception(Exception("test exception"))` を表示
  - 🗑️ Clear → ページをリロード（アラートをクリア）

### ステップ7: conftest の fixture パスを確認・修正

`test_alert_display.py` と `test_dataframe_download_button.py` のインポートパスが、対象アプリの実際のパス構成と合っているか確認してください。

**確認項目:**
- `from tests.e2e.playwright.pages.base_page import BasePage` → `from tests.e2e.pages.base_page import BasePage` に修正が必要な場合あり
- `from tests.e2e.playwright.conftest import find_available_port` → `from tests.e2e.conftest import find_available_port` に修正が必要な場合あり
- `from e2e_config import get_e2e_config` → `from tests.e2e.e2e_config import get_e2e_config` に修正が必要な場合あり

対象アプリの `tests/e2e/` ディレクトリ構造を確認してから、実際のパスに合わせて修正してください。

### ステップ8: 完了報告

以下のサマリを報告してください：

```
# pochi-e2e-base-verifier 配置完了

## 配置したファイル
- {app_path}/tests/e2e/test_alert_display.py（BasePage アラート検証・10テスト）
- {app_path}/tests/e2e/test_dataframe_download_button.py（ダウンロードボタン非表示検証・2テスト）
- {app_path}/tests/e2e/pages/dataframe_download_button_test_page.py（Page Object）
- {app_path}/tests/e2e/test_apps/test_alert_display_app.py（テスト用スタンドアロンアプリ）※生成した場合

## 実行方法
cd {app_path}

# アラート検証（BasePage メソッド全般）
poetry run pytest tests/e2e/test_alert_display.py -v

# DataFrameダウンロードボタン非表示検証
poetry run pytest tests/e2e/test_dataframe_download_button.py -v

# 全検証ファイルをまとめて実行
poetry run pytest tests/e2e/test_alert_display.py tests/e2e/test_dataframe_download_button.py -v

## 注意事項
- これらのテストは pytest.mark.local_only が付いており、ローカル環境専用です
- Playwright と Firefox がインストール済みであることを確認してください
```

## Instructions

このSkillはサブエージェントに委譲せず、上記Do節の手順を直接実行します。

### 重要な実装判断

- `base_page.py` の実際の内容を必ず読み込んでから `DataframeDownloadButtonTestPage` を実装する
- インポートパスの修正は対象アプリの実際のディレクトリ構造に基づいて行う
- 既存ファイルの上書きは必ずユーザー確認を取ってから行う

## Inputs

### 必須入力
- **対象アプリリポジトリのパス**
  - 形式: 絶対パス
  - 例: `/home/user/ALADIN-WDH`
  - 内容: `pochi-e2e-test-generator` で E2E テストを生成済みのアプリ

### 前提ファイル（対象アプリに存在必須）
- `{app_path}/tests/e2e/pages/base_page.py`
- `{app_path}/tests/e2e/conftest.py`
- `{app_path}/tests/e2e/e2e_config.py`

## Outputs

### 主要成果物
- **`{app_path}/tests/e2e/test_alert_display.py`**
  - BasePage の全アラートメソッドを検証する10テスト
- **`{app_path}/tests/e2e/test_dataframe_download_button.py`**
  - DataFrameダウンロードボタン非表示を検証する2テスト
- **`{app_path}/tests/e2e/pages/dataframe_download_button_test_page.py`**
  - test_dataframe_download_button.py が依存する Page Object

### 副次成果物（オプション）
- **`{app_path}/tests/e2e/test_apps/test_alert_display_app.py`**
  - test_alert_display.py が使用するスタンドアロン Streamlit アプリ

## Don't

- ❌ **`pochi-e2e-test-generator` の実行前に起動しない**
  - `base_page.py` が存在しない場合は先に `pochi-e2e-test-generator` を実行するよう案内して終了すること
- ❌ **検証ファイルの内容を勝手に変更しない**
  - `test_alert_display.py` と `test_dataframe_download_button.py` はソースを読み込んでそのまま配置する
  - インポートパスの修正のみ許容する
- ❌ **既存ファイルを確認なしに上書きしない**
  - 配置先に同名ファイルが存在する場合はユーザーに確認してから上書きする
- ❌ **`base_page.py` を読まずに `DataframeDownloadButtonTestPage` を実装しない**
  - 必ず実際の `base_page.py` の実装を確認してから整合する実装を行うこと

## Troubleshooting

### テストが `ImportError` で失敗する場合
インポートパスが対象アプリの構造と合っていない可能性がある。
`tests/e2e/` 配下の `__init__.py` の有無と、実際のディレクトリ構造を確認してパスを修正する。

### `DataframeDownloadButtonTestPage` のメソッドが動作しない場合
`base_page.py` のロケーター戦略（`data-testid` 属性）が Streamlit のバージョンによって異なる場合がある。
ブラウザの開発者ツールで実際の `data-testid` を確認して修正する。

### `test_alert_display_app.py` が見つからない場合
`test_alert_display.py` のコメントには `tests/e2e/playwright/test_apps/` と記載されているが、
実際の配置先は `tests/e2e/test_apps/` に修正している。conftest のサーバー起動パスを確認すること。

## バージョン・ライセンス

- **バージョン**: 1.0.0
- **作成者**: ryota-suzuki-xf
- **ライセンス**: 社内利用限定
