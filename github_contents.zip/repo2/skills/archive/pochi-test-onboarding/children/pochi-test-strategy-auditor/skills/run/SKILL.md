---
name: pochi-test-strategy-auditor
description: >-
  既存テストがテスト戦略（ピラミッド比率）に準拠しているか監査し、
  テスト層ごとの比率を算出して改善推奨を tests/test-strategy-audit.md に出力する。
  「テスト戦略の監査を実行」「テストピラミッド比率を確認」と言われたときに使用する。
---

> [!WARNING]
> **このスキルは廃止されました。**
> 後継スキル: `pochi-test-strategy-initializer` — 「テスト戦略を初期化して」で起動
> このスキルは何も実行せずに終了します。後継スキルのトリガーフレーズを入力してください。

このスキルは廃止済みのため、**何も実行しません。**

後継スキル **`pochi-test-strategy-initializer` — 「テスト戦略を初期化して」で起動** を使用してください。


Read the file `SKILL.md` located in the same directory as this plugin's root (two levels up from this file), then follow those instructions exactly to complete the task.
