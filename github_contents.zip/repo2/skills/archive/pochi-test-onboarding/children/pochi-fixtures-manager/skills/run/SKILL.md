---
name: pochi-fixtures-manager
description: >-
  テストデータ（fixtures）のライフサイクル管理を支援するSkill。
  init/generate/validate/audit/migrate/extract の6サブコマンドを提供する。
  T1(pochi-contract-initializer)が生成したcontracts/data-contracts.jsonから
  fixturesを自動生成・検証・監査するworkflowを提供する。
  レガシー対応として本番データからのfixtures抽出・サニタイズも行う。
  「fixturesを初期化して」「テストデータを生成して」と言われたときに使用する。
---

> [!WARNING]
> **このスキルは廃止されました。**
> 後継スキル: `pochi-unit-test-generator` — 「単体テストを生成して」で起動
> このスキルは何も実行せずに終了します。後継スキルのトリガーフレーズを入力してください。

このスキルは廃止済みのため、**何も実行しません。**

後継スキル **`pochi-unit-test-generator` — 「単体テストを生成して」で起動** を使用してください。


# Skill: Pochi Fixtures Manager

## Trigger Phrases

- fixturesを初期化して
- テストデータを生成して
- fixturesを検証して
- fixtures利用状況を監査
- pochi-fixtures-managerを起動
- 本番データからfixturesを生成
- 本番データをサニタイズしてfixturesに追加
- レガシーデータをfixturesに変換
- --mode=legacy でfixtures生成

## When

AI駆動開発において、テストデータ（fixtures）は「AIへの入力仕様の具体例」として機能し、
テストコードと同等の重要性を持つ。以下の場面で使用する：

- 新規アプリ開発時: T1でcontracts/を初期化した後にfixturesを生成する
- 開発中: fixturesが契約に準拠しているか検証したい
- 定期監査: 未使用・重複fixturesや カバレッジ不足を検出したい
- 契約変更時: data-contracts.jsonのバージョンアップに伴いfixturesを移行したい

## Do

`contracts/data-contracts.json` を読み込み、fixturesの初期化・生成・検証・監査・移行を行う。
各サブコマンドに応じて適切なステップを実行し、成果物を `fixtures/` および `output/` に出力する。

---

## Instructions

### 起動時: サブコマンドを確認

ユーザーのメッセージから以下のサブコマンドを判断し、該当ステップへ分岐する：

| サブコマンド | トリガーキーワード |
|---|---|
| `init` | 「初期化」「fixturesを作成」「ディレクトリを作る」 |
| `generate` | 「生成」「data-contractsから作成」「自動生成」 |
| `validate` | 「検証」「契約に準拠しているか」「チェック」 |
| `audit` | 「監査」「未使用」「利用状況」 |
| `migrate` | 「移行」「バージョンアップ」「マイグレーション」 |
| `extract` | 「本番データから」「レガシーデータ」「サニタイズ」「realistic」 |

サブコマンドが不明な場合は以下を確認する：

```
どのサブコマンドを実行しますか？

1. init — fixtures/ディレクトリとmanifest.jsonを初期化
2. generate — contracts/data-contracts.jsonからfixturesを自動生成
3. validate — fixturesが契約に準拠しているか検証
4. audit — fixtures利用状況を監査（未使用・重複・カバレッジ）
5. migrate — 契約変更時にfixturesを移行
6. extract — 本番データからfixturesを抽出・サニタイズ（レガシー対応）

番号またはサブコマンド名を入力してください。
```

---

### init: fixtures/ディレクトリとmanifest.jsonを初期化

#### Step 1: 既存状態を確認

```
Glob: fixtures/**/*
```

既に `fixtures/` が存在する場合はユーザーに確認を取る：

```
fixtures/ ディレクトリが既に存在します。
上書き初期化しますか？（既存のfixturesは保持されます。manifest.jsonのみ更新されます）

- 「はい」→ manifest.jsonのみ再生成します
- 「いいえ」→ 処理を中止します
```

#### Step 2: ディレクトリ構造を作成

以下のディレクトリ構造を作成する：

```
fixtures/
├── manifest.json          # fixtures管理台帳
├── README.md              # fixtures利用ガイド
├── inputs/
│   ├── valid/             # 正常系入力データ
│   ├── invalid/           # 異常系入力データ
│   ├── edge/              # エッジケース入力データ
│   └── realistic/         # 本番に近いリアルなデータ
└── expected/
    └── snapshots/         # 期待出力スナップショット
```

#### Step 3: manifest.jsonを生成

```json
{
  "version": "1.0.0",
  "created_at": "YYYY-MM-DD",
  "data_contracts_version": "（contracts/data-contracts.jsonのversionを参照）",
  "fixtures": []
}
```

**manifest.json のポリシーフィールド説明**:

各fixtureエントリには以下のポリシーフィールドを付与できる：

| フィールド | 型 | 説明 |
|---|---|---|
| `frozen` | boolean | `true` の場合、AI・自動化による変更を禁止。人間のレビュー必須 |
| `ai_can_generate` | boolean | `true` の場合、AIによる自動生成を許可 |
| `author` | string | 作成者（`"ai-generated"` / `"human"` / `"mixed"`） |
| `used_by` | array | このfixtureを使用するテストファイルのリスト |
| `tags` | array | 分類タグ（`"valid"`, `"invalid"`, `"edge"`, `"realistic"` 等） |

#### Step 4: fixtures/README.mdを生成

```markdown
# Fixtures 利用ガイド

## ディレクトリ構造

- `inputs/valid/` — 正常系入力データ（契約に準拠したデータ）
- `inputs/invalid/` — 異常系入力データ（型エラー・必須欠損等）
- `inputs/edge/` — エッジケース（0行・1行・Unicode等）
- `inputs/realistic/` — 本番に近いリアルなサンプルデータ
- `expected/snapshots/` — 期待出力スナップショット

## manifest.json の管理

fixturesの追加・変更・削除は必ずmanifest.jsonに反映してください。
`frozen: true` のfixtureは手動で変更してください（AIによる自動変更を禁止）。

## pochi-fixtures-manager との連携

- `generate` — data-contracts.jsonから自動生成
- `validate` — 契約への準拠を検証
- `audit` — 利用状況を監査
- `migrate` — 契約バージョンアップ時に移行
```

**完了報告**:

```
✅ fixtures/ の初期化が完了しました。

作成したディレクトリ:
- fixtures/inputs/valid/
- fixtures/inputs/invalid/
- fixtures/inputs/edge/
- fixtures/inputs/realistic/
- fixtures/expected/snapshots/

生成したファイル:
- fixtures/manifest.json
- fixtures/README.md

次のステップ: 「テストデータを生成して」と入力すると、
contracts/data-contracts.jsonから fixtures を自動生成します。
```

---

### generate: data-contracts.jsonからfixturesを自動生成

#### Step 1: contracts/data-contracts.jsonを読み込む

```
Read: contracts/data-contracts.json
```

ファイルが存在しない場合:

```
contracts/data-contracts.json が見つかりません。
T1 (pochi-contract-initializer) を先に実行して contracts/ を初期化してください。

「テスト契約を初期化して」と入力すると T1 が起動します。
```

#### Step 2: fixturesを自動生成

`data-contracts.json` の各スキーマエントリから以下のfixturesを生成する：

**正常系（valid）**:

| ファイル | 内容 |
|---|---|
| `inputs/valid/<contract_id>_minimal.csv` | 最小構成（必須カラムのみ） |
| `inputs/valid/<contract_id>_full.csv` | 全カラム含む完全版 |

**異常系（invalid）**:

| ファイル | 内容 |
|---|---|
| `inputs/invalid/<contract_id>_missing_<col>.csv` | 各必須カラムを1つずつ欠損 |
| `inputs/invalid/<contract_id>_type_error_<col>.csv` | 型エラー（数値カラムに文字列等） |

**エッジケース（edge）**:

| ファイル | 内容 |
|---|---|
| `inputs/edge/<contract_id>_empty.csv` | 0行（ヘッダーのみ） |
| `inputs/edge/<contract_id>_single_row.csv` | 1行のみ |
| `inputs/edge/<contract_id>_unicode_header.csv` | Unicodeヘッダー含む |

#### Step 3: manifest.jsonを更新

生成した各fixtureをmanifest.jsonに登録する：

```json
{
  "id": "<contract_id>_minimal",
  "path": "fixtures/inputs/valid/<contract_id>_minimal.csv",
  "contract_id": "<contract_id>",
  "tags": ["valid", "minimal"],
  "author": "ai-generated",
  "ai_can_generate": true,
  "frozen": false,
  "used_by": []
}
```

**完了報告**:

```
✅ fixturesの自動生成が完了しました。

生成したfixtures:
- valid: X件
- invalid: X件
- edge: X件

manifest.json を更新しました（総fixture数: X件）。

次のステップ:
- 「fixturesを検証して」— 生成したfixturesが契約に準拠しているか確認
- 「TDDで開発を開始」— T2(pochi-tdd-workflow)でテストコードを生成
```

---

### validate: fixturesが契約に準拠しているか検証

#### Step 1: manifest.jsonとdata-contracts.jsonを読み込む

```
Read: fixtures/manifest.json
Read: contracts/data-contracts.json
```

#### Step 2: 各fixtureを照合

manifest.jsonの各fixtureについて以下を検証する：

| 検証項目 | 確認内容 |
|---|---|
| ファイル存在 | `path` に指定されたファイルが存在するか |
| カラム名 | data-contracts.jsonのスキーマと一致するか |
| 型 | 各カラムの型がスキーマ定義と一致するか |
| 必須カラム | 必須カラムがすべて存在するか |
| contract_id | manifest.jsonの `contract_id` が data-contracts.json に存在するか |

#### Step 3: 結果を報告

```
## fixtures 検証結果

| fixture | ファイル | 検証結果 | 詳細 |
|---|---|:---:|---|
| sales_minimal | fixtures/inputs/valid/sales_minimal.csv | ✅ | 準拠 |
| sales_missing_date | fixtures/inputs/invalid/sales_missing_date.csv | ✅ | 準拠（意図的欠損） |
| （例） | fixtures/inputs/valid/xxx.csv | ❌ | カラム "amount" の型が不一致 |
| （例） | fixtures/inputs/edge/xxx.csv | ⚠️ | ファイルが存在しない |

### サマリー
- ✅ 準拠: X件
- ❌ 不準拠: X件
- ⚠️ 警告: X件
```

❌ が存在する場合はユーザーに確認し、修正を提案する。

---

### audit: fixtures利用状況を監査

#### Step 1: manifest.jsonとテストファイルを読み込む

```
Read: fixtures/manifest.json
Glob: tests/**/*.py
```

#### Step 2: 利用状況を分析

以下の観点で監査を実施する：

**未使用fixturesの検出**:
- `used_by: []` のfixtureをリストアップ
- テストファイル内でfixtureのパスが参照されていないものを検出

**重複fixturesの検出**:
- ファイルサイズ・カラム構成が同一のfixturesを特定

**カバレッジ評価**:

| 観点 | 評価基準 |
|---|---|
| valid カバレッジ | 各contract_idに最低1つのvalidがあるか |
| invalid カバレッジ | 各必須カラムに対応するinvalidがあるか |
| edge カバレッジ | 0行・1行ケースが各contract_idに存在するか |

#### Step 3: output/fixtures-audit.mdに出力

```markdown
# fixtures 利用状況監査レポート

**監査日時**: YYYY-MM-DD HH:MM:SS
**fixtures総数**: X件
**manifest.json バージョン**: X.X.X

## 未使用fixtures

| fixture ID | パス | タグ |
|---|---|---|
| xxx | fixtures/inputs/valid/xxx.csv | valid |

## 重複fixtures

| fixture A | fixture B | 重複理由 |
|---|---|---|

## カバレッジ評価

| contract_id | valid | invalid | edge | 判定 |
|---|:---:|:---:|:---:|:---:|
| sales | ✅ | ✅ | ⚠️ | 要追加 |

## 推奨アクション

1. 未使用fixturesの削除または used_by への登録
2. カバレッジ不足の契約へのfixtures追加（`generate` サブコマンドで補完可能）
3. 重複fixturesの統合
```

**完了報告**:

```
✅ fixtures監査が完了しました。
レポート: output/fixtures-audit.md

概要:
- 未使用: X件
- 重複: X件
- カバレッジ不足の契約: X件
```

---

### migrate: 契約変更時にfixturesを移行

#### Step 1: バージョン変更を検出

```
Read: fixtures/manifest.json       # data_contracts_version を確認
Read: contracts/data-contracts.json  # 現在のバージョンを確認
```

バージョンが一致している場合:

```
contracts/data-contracts.json のバージョン（X.X.X）と
fixtures/manifest.json の data_contracts_version（X.X.X）が一致しています。
移行は不要です。
```

#### Step 2: 影響を受けるfixturesを特定

バージョンが異なる場合、変更されたスキーマに対応するfixturesを特定する：

- カラム追加: 既存fixturesへの列追加が必要
- カラム削除: 既存fixturesから列削除が必要
- 型変更: 値の変換が必要
- カラムリネーム: ヘッダーの更新が必要

#### Step 3: frozen fixtureの確認

`frozen: true` のfixtureが影響を受ける場合、手動対応を促す：

```
⚠️ 以下のfixturesは frozen: true に設定されており、自動変更できません。
手動で確認・更新してください：

- fixtures/inputs/realistic/sales_2024_q4.csv
  変更内容: カラム "product_code" が追加されました
```

#### Step 4: 自動変換プランを提示

`frozen: false` かつ `ai_can_generate: true` のfixturesについて、変換プランを提示する：

```
以下のfixturesを自動移行できます。実行しますか？

| fixture | 変更内容 | 対応 |
|---|---|---|
| sales_minimal.csv | カラム "product_code" 追加 | 空値("")で追加 |
| sales_full.csv | カラム "product_code" 追加 | サンプル値("P001")で追加 |
| sales_empty.csv | カラム "product_code" 追加 | ヘッダーのみ追加 |

- 「はい」→ 自動変換を実行します
- 「いいえ」→ 変換プランのみ保存します（output/migrate-plan.md）
```

#### Step 5: manifest.jsonのバージョンを更新

移行完了後、manifest.jsonの `data_contracts_version` を更新する。

**完了報告**:

```
✅ fixtures移行が完了しました。

移行済み: X件（自動）
手動対応が必要: X件（frozen: trueのfixtures）
manifest.json のバージョンを X.X.X に更新しました。
```

---

### extract: 本番データからfixturesを抽出・サニタイズ

本番に近いリアルなデータを fixtures/inputs/realistic/ に配置する。
個人情報・機密情報をサニタイズ（マスク/匿名化/削除）する。

#### Step 1: 本番データの読み込みと確認

ユーザーに以下を確認する：

```
本番データのパスを教えてください（例: /path/to/sample.csv）
また、以下の情報があれば教えてください：
1. 個人情報・機密情報が含まれるカラム（サニタイズ対象）
2. 抽出する行数（デフォルト: 10行）
3. サニタイズ方法（マスク / 匿名化 / 削除）
```

#### Step 2: contracts/data-contracts.json との照合

本番データのカラム構成を data-contracts.json のスキーマと照合する。
差異がある場合はユーザーに報告し、スキーマ更新の要否を確認する。

#### Step 3: サニタイズ処理

指定されたカラムを以下のルールでサニタイズする：

| サニタイズ方法 | 処理 | 例 |
|---|---|---|
| マスク | 値を "***" に置換 | 氏名 → "***" |
| 匿名化 | 意味を保ちつつ値を変換 | 山田太郎 → "テストユーザーA" |
| 削除 | カラムごと削除 | パスワードカラム削除 |

日付・数値は範囲を保ちつつランダム化（元データとの直接対応をなくす）。

#### Step 4: fixtures/inputs/realistic/ に配置

サニタイズ済みデータを以下のファイル名で保存：
- `fixtures/inputs/realistic/<contract_id>_sample.csv`

#### Step 5: manifest.json に登録

```json
{
  "id": "<contract_id>_realistic_sample",
  "path": "fixtures/inputs/realistic/<contract_id>_sample.csv",
  "contract_id": "<contract_id>",
  "tags": ["realistic"],
  "author": "human",
  "ai_can_generate": false,
  "frozen": true,
  "used_by": [],
  "source": "production",
  "sanitized": true,
  "sanitized_columns": ["（サニタイズしたカラム名）"],
  "sanitized_at": "YYYY-MM-DD"
}
```

**完了報告**:

```
✅ 本番データからのfixtures抽出・サニタイズが完了しました。

抽出行数: X行
サニタイズしたカラム: [カラム名リスト]
出力先: fixtures/inputs/realistic/<contract_id>_sample.csv

manifest.json に登録しました（frozen: true、source: "production"）。

⚠️ このfixtureは frozen: true に設定されています。
  自動変更・上書きは行われません。必要な場合は手動で更新してください。

次のステップ:
- T2 (pochi-tdd-workflow) --mode=characterization で Characterization Test を生成
```

---

## 他Skillとの連携

```
T1 (pochi-contract-initializer)
  ↓ contracts/data-contracts.json を生成
T4 (pochi-fixtures-manager) generate
  ↓ fixtures/ を自動生成
T2 (pochi-tdd-workflow)
  ↓ fixtures を使ったテストコードを生成
T3 / T4 (pochi-test-strategy-auditor / pochi-fixtures-manager) audit
  ↓ テスト戦略・fixtures利用状況を監査
```

| 入力 | 生成Skill | 出力 |
|---|---|---|
| ヒアリング | T1 pochi-contract-initializer | `contracts/`（6ファイル） |
| `contracts/data-contracts.json` | **T4** pochi-fixtures-manager (generate) | `fixtures/`（CSV群 + manifest.json） |
| `fixtures/` + テストコード | **T4** pochi-fixtures-manager (audit) | `output/fixtures-audit.md` |
| `contracts/data-contracts.json` 更新 | **T4** pochi-fixtures-manager (migrate) | fixtures移行 + manifest更新 |

---

## 完了条件

### init
- [ ] `fixtures/` 配下のディレクトリ構造が作成されている
- [ ] `fixtures/manifest.json` が存在する
- [ ] `fixtures/README.md` が存在する

### generate
- [ ] `contracts/data-contracts.json` を読み込んだ
- [ ] valid/invalid/edge の各fixturesが生成された
- [ ] `fixtures/manifest.json` が更新された

### validate
- [ ] `fixtures/manifest.json` の全fixtureを照合した
- [ ] ✅/❌/⚠️ で結果を報告した

### audit
- [ ] 未使用fixturesを検出した
- [ ] 重複fixturesを検出した
- [ ] カバレッジを評価した
- [ ] `output/fixtures-audit.md` に出力した

### migrate
- [ ] バージョン差分を検出した
- [ ] 影響を受けるfixturesを特定した
- [ ] frozen fixtureの手動対応を促した
- [ ] ユーザー確認後に自動変換を実行した
- [ ] `fixtures/manifest.json` のバージョンを更新した

### extract
- [ ] 本番データのパスとサニタイズ対象カラムを確認した
- [ ] data-contracts.json のスキーマと照合した
- [ ] サニタイズ処理を実施した
- [ ] `fixtures/inputs/realistic/` に出力した
- [ ] `fixtures/manifest.json` に `source: "production"`, `frozen: true` で登録した
