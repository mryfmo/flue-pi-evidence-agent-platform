---
name: pochi-contract-initializer
description: >-
  新規Pochiアプリ開発時に、テスト品質契約ファイル群（contracts/）を一括初期化する。
  ヒアリングを通じて data-contracts.json / business-rules.json / test-viewpoints.json /
  scenarios.json / domain-rules.md / risk-catalog.md の6ファイルを生成する。
  「テスト契約を初期化して」「contracts ディレクトリを作成」と言われたときに使用する。
---

> [!WARNING]
> **このスキルは廃止されました。**
> 後継スキル: `pochi-test-strategy-initializer` — 「テスト戦略を初期化して」で起動
> このスキルは何も実行せずに終了します。後継スキルのトリガーフレーズを入力してください。

このスキルは廃止済みのため、**何も実行しません。**

後継スキル **`pochi-test-strategy-initializer` — 「テスト戦略を初期化して」で起動** を使用してください。


Read the file `SKILL.md` located in the same directory as this plugin's root (two levels up from this file), then follow those instructions exactly to complete the task.
