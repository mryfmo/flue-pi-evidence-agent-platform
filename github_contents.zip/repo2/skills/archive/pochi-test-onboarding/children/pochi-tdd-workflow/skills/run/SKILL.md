---
name: pochi-tdd-workflow
description: >-
  TDD（テスト駆動開発）フローを支援するSkill。変更要求を受け取り、
  failing testを先に生成→AIに実装させる→test-runnerで検証、のループを実行する。
  「TDDで開発を開始」「テスト駆動開発を実行」「failing testから実装」と言われたときに使用する。
---

> [!WARNING]
> **このスキルは廃止されました。**
> 後継スキル: `pochi-tdd-test-generator` — 「仕様書からREDテストを生成して」で起動
> このスキルは何も実行せずに終了します。後継スキルのトリガーフレーズを入力してください。

このスキルは廃止済みのため、**何も実行しません。**

後継スキル **`pochi-tdd-test-generator` — 「仕様書からREDテストを生成して」で起動** を使用してください。


# pochi-tdd-workflow Skill

## スキル概要

TDD（テスト駆動開発）フローを支援するSkill。以下の11個のカスタムサブエージェントを適切な順序で起動し、テストピラミッド（契約30〜50%/ロジック30〜50%/結合15〜25%/E2E 5〜15%）を自動生成・検証する。

## 使用可能なカスタムサブエージェント

| エージェント名 | 役割 |
|---|---|
| `unit-test-designer` | ビジネスロジック関数の単体テスト設計書を生成（Layer 2） |
| `integration-test-designer` | Streamlit UI+ロジック連携の結合テスト設計書を生成（Layer 3） |
| `scenario-test-designer` | 複数ステップを含むE2Eシナリオテスト設計書を生成（Layer 4） |
| `golden-data-manager` | ゴールデンデータセット（冪等性保証）を管理・検証 |
| `test-author` | 設計書を基にpytestテストコードを実装 |
| `test-runner` | pytestを段階的に実行し結果を構造化レポートで出力 |
| `test-triage` | 失敗テストのスタックトレースを解析・P0/P1/P2優先度付けで修正提案 |
| `fix-implementer` | test-triageの修正提案を基にテストコード・プロダクトコードを自動修正 |
| `business-rule-validator` | contracts/business-rules.json からビジネスルール検証テストを生成（Layer 1） |
| `contract-test-generator` | contracts/data-contracts.json からデータ契約テストを生成（Layer 1） |
| `regression-test-selector` | git差分から影響を受ける既存テストを特定・回帰テスト計画を作成 |

---

## ワークフロー

> ⚠️ **絶対必須・直接実行禁止**
>
> このスキルの全ワークフローは、以下に定義するカスタムサブエージェントを**Agentツールで起動**して実行すること。
> Claude Code（あなた自身）が直接テストコードを生成・実行・修正することは**厳禁**。
> 各ステップで必ず対応するカスタムサブエージェントを起動すること。

### STEP 1: ユーザーからの情報収集

AskUserQuestionツールで以下を確認する：

- **実行パターンの選択**（詳細は各パターンを参照）:
  - パターンA: 新規機能開発（TDD完全フロー）
  - パターンB: 回帰テスト検証（git差分ベース）
  - パターンC: ビジネスルール・データ契約の検証テスト追加
- 対象アプリのリポジトリパス
- characterization（既存動作固定）モードか、新規TDDモードか

---

## パターン A: 新規機能開発（TDD完全フロー）

設計→実装→実行→分析→修正の反復ループ。

### A-1: 単体テスト設計

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:unit-test-designer"`）を起動すること

```
Agentツールで unit-test-designer カスタムサブエージェントを起動し、
以下を実行させてください：
- ビジネスロジック関数を分析
- 純粋関数・境界値・モック対象を洗い出し
- AAAパターンで単体テスト設計書を生成
- 出力先: output/unit-test-design.md
```

### A-2: 結合テスト設計

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:integration-test-designer"`）を起動すること

```
Agentツールで integration-test-designer カスタムサブエージェントを起動し、
以下を実行させてください：
- Streamlit UI+ロジック連携（session_state変化→表示結果）のフローを設計
- AppTestを使った結合テスト設計書を生成
- 出力先: output/integration-test-design.md
```

### A-3: E2Eシナリオテスト設計（必要な場合）

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:scenario-test-designer"`）を起動すること

```
Agentツールで scenario-test-designer カスタムサブエージェントを起動し、
以下を実行させてください：
- 複数ステップ/ファイルDL/ページ遷移を含むE2Eシナリオを設計
- Playwright(Firefox)での「操作→待機→確認」形式で設計
- 出力先: output/scenario-test-design.md
```

### A-4: ゴールデンデータ準備（並列実行可）

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:golden-data-manager"`）を起動すること

```
Agentツールで golden-data-manager カスタムサブエージェントを起動し、
以下を実行させてください：
- tests/fixtures/golden/ にゴールデンデータセットを配置
- MANIFEST.json でチェックサム・バージョン情報を管理
- 出力先: tests/fixtures/golden/golden_v*/
```

### A-5: テストコード実装

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:test-author"`）を起動すること

```
Agentツールで test-author カスタムサブエージェントを起動し、
以下を実行させてください：
- output/unit-test-design.md, integration-test-design.md, scenario-test-design.md を参照
- AAAパターン・命名規則・モック戦略（Snowflakeモック/LLMモック）を遵守
- tests/ 配下にテストコードを実装
```

### A-6: テスト実行

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:test-runner"`）を起動すること

```
Agentツールで test-runner カスタムサブエージェントを起動し、
以下を実行させてください：
- 3フェーズ（新規テストのみ→全体スイート→カバレッジ）で実行
- 失敗テストのスタックトレースを保存
- 出力先: output/test-report.md, output/results_phase*.log
```

### A-7: 失敗テスト分析（テスト失敗時のみ）

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:test-triage"`）を起動すること

```
Agentツールで test-triage カスタムサブエージェントを起動し、
以下を実行させてください：
- 失敗テストのスタックトレースを解析
- テスト側/プロダクト側の切り分け
- P0/P1/P2優先度付きで修正提案を作成（実装は行わない）
- 出力先: output/triage-report.md
```

### A-8: 修正実装（失敗テスト分析後）

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:fix-implementer"`）を起動すること

```
Agentツールで fix-implementer カスタムサブエージェントを起動し、
以下を実行させてください：
- output/triage-report.md を読み込み
- P0→P1→P2 優先度順に修正を実施
- git commit は行わない
- 出力先: output/fix-summary.md
```

### A-9: 再テスト実行（修正後）

A-6と同様に test-runner を再度起動し、修正後の動作を検証する。

---

## パターン B: 回帰テスト検証（git差分ベース）

変更コードが既存テストに与える影響を特定し、回帰テストを実行する。

### B-1: 回帰テスト対象の選定

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:regression-test-selector"`）を起動すること

```
Agentツールで regression-test-selector カスタムサブエージェントを起動し、
以下を実行させてください：
- ベースブランチとのgit差分を分析
- 直接テスト・間接依存テストを優先度付きで抽出
- 出力先: output/regression-plan.md
```

### B-2: 回帰テスト実行

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:test-runner"`）を起動すること

B-1の出力（output/regression-plan.md）を参照してtest-runnerを起動する。

### B-3: 失敗テスト分析（必要な場合）

失敗テストがあれば A-7 と同様に `test-triage` を起動する。

### B-4: 修正実装（必要な場合）

失敗テストがあれば A-8 と同様に `fix-implementer` を起動する。

---

## パターン C: ビジネスルール・データ契約の検証テスト追加

contracts/ ディレクトリの定義から検証テストを自動生成する。

### C-1: ビジネスルール検証テスト生成

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:business-rule-validator"`）を起動すること

```
Agentツールで business-rule-validator カスタムサブエージェントを起動し、
以下を実行させてください：
- contracts/business-rules.json からビジネスルールを読み込み
- 業務制約・計算ロジック・状態遷移の正合性をpytestでテスト化
- 出力先: tests/contracts/test_business_rules.py
```

### C-2: データ契約テスト生成

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-tdd-workflow:contract-test-generator"`）を起動すること

```
Agentツールで contract-test-generator カスタムサブエージェントを起動し、
以下を実行させてください：
- contracts/data-contracts.json からデータ契約を読み込み
- CSV/pandas DataFrame と Snowflake クエリ出力のスキーマ検証テストを自動生成
- 出力先: tests/contracts/test_input_schema.py, tests/contracts/test_output_schema.py
```

### C-3: テスト実行

C-1、C-2の後に test-runner を起動する（A-6と同様）。

---

## 注意事項

- 各サブエージェントは**独立して起動**可能（部分的なTDDも可能）
- 並列起動できるのは依存関係のないステップのみ（例: A-1、A-2、A-3は並列起動可）
- A-5（test-author）はA-1〜A-3の完了後に起動すること
- A-7、A-8はテスト失敗時のみ起動する
