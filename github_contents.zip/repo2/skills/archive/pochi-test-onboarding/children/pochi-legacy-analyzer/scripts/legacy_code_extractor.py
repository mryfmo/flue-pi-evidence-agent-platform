"""
Legacy Code Extractor

目的: レガシーアプリのソースコードを静的解析し、カラム情報・セキュリティリスクを事前抽出する。
      LLMに渡すことで解析精度・再現性を向上させる。

使用方法:
    python legacy_code_extractor.py <app_path> [--output-dir <dir>]

出力:
    <output_dir>/legacy_structure.md     ← LLMに読ませるMarkdownレポート
    <output_dir>/analysis_context.json   ← LLM参照用コンテキスト（JSON）
"""

import ast
import json
import os
import re
import sys
import argparse
from pathlib import Path
from datetime import datetime


# ---------------------------------------------------------------------------
# DataFrameAnalyzer
# ---------------------------------------------------------------------------

class DataFrameAnalyzer:
    """SQL文・DataFrame操作からカラム名を抽出する"""

    # SQL SELECT句からカラムを抽出する正規表現
    _RE_SELECT = re.compile(
        r'SELECT\s+(.*?)\s+FROM',
        re.IGNORECASE | re.DOTALL,
    )
    # WHERE 句のカラム参照 (col = / col BETWEEN / col IN)
    _RE_WHERE_COL = re.compile(
        r'WHERE\s+.*?(\w+)\s+(?:=|BETWEEN|IN|LIKE|>|<|>=|<=)',
        re.IGNORECASE | re.DOTALL,
    )

    def __init__(self, source_path: str):
        self.source_path = source_path

    def extract_columns(self, tree: ast.AST, source_lines: list[str]) -> list[dict]:
        """ASTを走査してカラム情報を収集する"""
        columns: list[dict] = []

        for node in ast.walk(tree):
            # -----------------------------------------------------------------
            # パターン 1: f-string / 文字列内の SQL SELECT 句  → HIGH
            # -----------------------------------------------------------------
            if isinstance(node, (ast.JoinedStr, ast.Constant)):
                sql_text = self._extract_sql_text(node)
                if sql_text:
                    cols = self._parse_select_columns(sql_text)
                    lineno = getattr(node, 'lineno', 0)
                    for col in cols:
                        columns.append({
                            'column': col,
                            'confidence': 'HIGH',
                            'source': f'{self.source_path}:{lineno}',
                            'context': 'SQL SELECT',
                        })
                    # WHERE句カラム
                    where_cols = self._parse_where_columns(sql_text)
                    for col in where_cols:
                        columns.append({
                            'column': col,
                            'confidence': 'HIGH',
                            'source': f'{self.source_path}:{lineno}',
                            'context': 'SQL WHERE',
                        })

            # -----------------------------------------------------------------
            # パターン 2: df["column_name"]  → HIGH
            # -----------------------------------------------------------------
            if isinstance(node, ast.Subscript):
                col = self._extract_subscript_column(node)
                if col:
                    columns.append({
                        'column': col,
                        'confidence': 'HIGH',
                        'source': f'{self.source_path}:{node.lineno}',
                        'context': 'df["column"]',
                    })

            # -----------------------------------------------------------------
            # パターン 3: df.rename(columns={...})  → HIGH
            # -----------------------------------------------------------------
            if isinstance(node, ast.Call):
                rename_cols = self._extract_rename_columns(node)
                for col in rename_cols:
                    columns.append({
                        'column': col,
                        'confidence': 'HIGH',
                        'source': f'{self.source_path}:{node.lineno}',
                        'context': 'df.rename(columns=...)',
                    })

                # -------------------------------------------------------------
                # パターン 4: df.groupby(["col1", "col2"])  → MEDIUM
                # -------------------------------------------------------------
                groupby_cols = self._extract_groupby_columns(node)
                for col in groupby_cols:
                    columns.append({
                        'column': col,
                        'confidence': 'MEDIUM',
                        'source': f'{self.source_path}:{node.lineno}',
                        'context': 'df.groupby(...)',
                    })

                # -------------------------------------------------------------
                # パターン 5: df.merge(on="col")  → MEDIUM
                # -------------------------------------------------------------
                merge_cols = self._extract_merge_columns(node)
                for col in merge_cols:
                    columns.append({
                        'column': col,
                        'confidence': 'MEDIUM',
                        'source': f'{self.source_path}:{node.lineno}',
                        'context': 'df.merge(on=...)',
                    })

        return self._deduplicate(columns)

    # ------------------------------------------------------------------
    # 内部ヘルパー
    # ------------------------------------------------------------------

    def _extract_sql_text(self, node: ast.AST) -> str | None:
        """f-string または文字列定数から SQL らしいテキストを取得する"""
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            text = node.value
            if re.search(r'\bSELECT\b', text, re.IGNORECASE):
                return text
        if isinstance(node, ast.JoinedStr):
            # f-string のリテラル部分を結合
            parts = []
            for value in node.values:
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    parts.append(value.value)
                else:
                    parts.append(' __VAR__ ')
            text = ''.join(parts)
            if re.search(r'\bSELECT\b', text, re.IGNORECASE):
                return text
        return None

    def _parse_select_columns(self, sql: str) -> list[str]:
        m = self._RE_SELECT.search(sql)
        if not m:
            return []
        cols_str = m.group(1)
        # * は無視
        if cols_str.strip() == '*':
            return []
        cols = [c.strip().split()[-1].strip('"\'`') for c in cols_str.split(',')]
        return [c for c in cols if c and re.match(r'^[A-Za-z_]\w*$', c)]

    def _parse_where_columns(self, sql: str) -> list[str]:
        m = self._RE_WHERE_COL.search(sql)
        if not m:
            return []
        col = m.group(1).strip()
        if re.match(r'^[A-Za-z_]\w*$', col):
            return [col]
        return []

    def _extract_subscript_column(self, node: ast.Subscript) -> str | None:
        """df["col"] パターン"""
        if isinstance(node.slice, ast.Constant) and isinstance(node.slice.value, str):
            col = node.slice.value
            if re.match(r'^[A-Za-z_]\w*$', col):
                return col
        return None

    def _extract_rename_columns(self, node: ast.Call) -> list[str]:
        """df.rename(columns={"old": "new"}) のキーと値を取得"""
        if not isinstance(node.func, ast.Attribute):
            return []
        if node.func.attr != 'rename':
            return []
        for kw in node.keywords:
            if kw.arg == 'columns' and isinstance(kw.value, ast.Dict):
                cols = []
                for k in kw.value.keys:
                    if isinstance(k, ast.Constant) and isinstance(k.value, str):
                        cols.append(k.value)
                for v in kw.value.values:
                    if isinstance(v, ast.Constant) and isinstance(v.value, str):
                        cols.append(v.value)
                return [c for c in cols if re.match(r'^[A-Za-z_]\w*$', c)]
        return []

    def _extract_groupby_columns(self, node: ast.Call) -> list[str]:
        """df.groupby(["col1", "col2"]) または df.groupby("col") を取得"""
        if not isinstance(node.func, ast.Attribute):
            return []
        if node.func.attr != 'groupby':
            return []
        if not node.args:
            return []
        arg = node.args[0]
        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
            return [arg.value] if re.match(r'^[A-Za-z_]\w*$', arg.value) else []
        if isinstance(arg, ast.List):
            cols = []
            for elt in arg.elts:
                if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                    if re.match(r'^[A-Za-z_]\w*$', elt.value):
                        cols.append(elt.value)
            return cols
        return []

    def _extract_merge_columns(self, node: ast.Call) -> list[str]:
        """df.merge(on="col") または df.merge(on=["col1", "col2"]) を取得"""
        if not isinstance(node.func, ast.Attribute):
            return []
        if node.func.attr != 'merge':
            return []
        for kw in node.keywords:
            if kw.arg == 'on':
                if isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
                    return [kw.value.value]
                if isinstance(kw.value, ast.List):
                    cols = []
                    for elt in kw.value.elts:
                        if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                            cols.append(elt.value)
                    return cols
        return []

    @staticmethod
    def _deduplicate(columns: list[dict]) -> list[dict]:
        """同一カラム・同一コンテキストの重複を除去し、Confidence の高い方を残す"""
        PRIORITY = {'HIGH': 0, 'MEDIUM': 1, 'LOW': 2}
        seen: dict[tuple, dict] = {}
        for col in columns:
            key = (col['column'], col['context'])
            if key not in seen or PRIORITY[col['confidence']] < PRIORITY[seen[key]['confidence']]:
                seen[key] = col
        return list(seen.values())


# ---------------------------------------------------------------------------
# RiskDetector
# ---------------------------------------------------------------------------

class RiskDetector:
    """セキュリティリスク・エラーハンドリング欠如を検出する"""

    def __init__(self, source_path: str):
        self.source_path = source_path

    def detect_risks(self, tree: ast.AST, source_lines: list[str]) -> list[dict]:
        risks: list[dict] = []
        self._detect_dangerous_calls(tree, risks)
        self._detect_unprotected_calls(tree, source_lines, risks)
        self._detect_magic_numbers(tree, risks)
        return risks

    # ------------------------------------------------------------------
    # HIGH リスク: eval / exec / os.system / subprocess.call(shell=True)
    #              f-string 内変数を含む SQL SELECT
    # ------------------------------------------------------------------

    def _detect_dangerous_calls(self, tree: ast.AST, risks: list[dict]) -> None:
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func_name = self._get_func_name(node.func)
            lineno = getattr(node, 'lineno', 0)

            # eval / exec
            if func_name in ('eval', 'exec'):
                risks.append({
                    'risk_id': self._make_risk_id('HIGH', len(risks)),
                    'level': 'HIGH',
                    'category': 'セキュリティ',
                    'description': f'`{func_name}()` の使用（任意コード実行リスク）',
                    'source': f'{self.source_path}:{lineno}',
                })

            # os.system
            if func_name == 'os.system':
                risks.append({
                    'risk_id': self._make_risk_id('HIGH', len(risks)),
                    'level': 'HIGH',
                    'category': 'セキュリティ',
                    'description': '`os.system()` の使用（コマンドインジェクションリスク）',
                    'source': f'{self.source_path}:{lineno}',
                })

            # subprocess.call(shell=True)
            if func_name in ('subprocess.call', 'subprocess.run', 'subprocess.Popen'):
                for kw in node.keywords:
                    if kw.arg == 'shell' and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                        risks.append({
                            'risk_id': self._make_risk_id('HIGH', len(risks)),
                            'level': 'HIGH',
                            'category': 'セキュリティ',
                            'description': f'`{func_name}(shell=True)` の使用（コマンドインジェクションリスク）',
                            'source': f'{self.source_path}:{lineno}',
                        })

        # f-string 内変数を含む SELECT 文（SQL インジェクションリスク）
        for node in ast.walk(tree):
            if isinstance(node, ast.JoinedStr):
                has_var = any(not isinstance(v, ast.Constant) for v in node.values)
                if has_var:
                    parts = []
                    for v in node.values:
                        if isinstance(v, ast.Constant) and isinstance(v.value, str):
                            parts.append(v.value)
                        else:
                            parts.append('__VAR__')
                    text = ''.join(parts)
                    if re.search(r'\bSELECT\b', text, re.IGNORECASE):
                        lineno = getattr(node, 'lineno', 0)
                        risks.append({
                            'risk_id': self._make_risk_id('HIGH', len(risks)),
                            'level': 'HIGH',
                            'category': 'SQLインジェクション',
                            'description': 'f-string 内に変数を含む SQL SELECT 文（SQLインジェクションリスク）',
                            'source': f'{self.source_path}:{lineno}',
                        })

    # ------------------------------------------------------------------
    # MEDIUM リスク: snowflake.connector.connect / requests.get /
    #               .astype() が try/except で保護されていない
    # ------------------------------------------------------------------

    def _detect_unprotected_calls(
        self, tree: ast.AST, source_lines: list[str], risks: list[dict]
    ) -> None:
        # try/except で保護されている行番号範囲を収集
        protected_ranges: list[tuple[int, int]] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Try):
                start = node.lineno
                end = max(
                    (getattr(h, 'end_lineno', h.lineno) for h in node.handlers),
                    default=node.lineno,
                )
                protected_ranges.append((start, end))

        def is_protected(lineno: int) -> bool:
            return any(s <= lineno <= e for s, e in protected_ranges)

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func_name = self._get_func_name(node.func)
            lineno = getattr(node, 'lineno', 0)

            # snowflake.connector.connect()
            if func_name in ('snowflake.connector.connect', 'SnowflakeConnector'):
                if not is_protected(lineno):
                    risks.append({
                        'risk_id': self._make_risk_id('MEDIUM', len(risks)),
                        'level': 'MEDIUM',
                        'category': 'エラーハンドリング欠如',
                        'description': '`snowflake.connector.connect()` が try/except で保護されていない',
                        'source': f'{self.source_path}:{lineno}',
                    })

            # requests.get / requests.post
            if func_name in ('requests.get', 'requests.post', 'httpx.get', 'httpx.post'):
                if not is_protected(lineno):
                    risks.append({
                        'risk_id': self._make_risk_id('MEDIUM', len(risks)),
                        'level': 'MEDIUM',
                        'category': 'エラーハンドリング欠如',
                        'description': f'`{func_name}()` が try/except で保護されていない',
                        'source': f'{self.source_path}:{lineno}',
                    })

            # .astype()
            if isinstance(node.func, ast.Attribute) and node.func.attr == 'astype':
                if not is_protected(lineno):
                    risks.append({
                        'risk_id': self._make_risk_id('MEDIUM', len(risks)),
                        'level': 'MEDIUM',
                        'category': '型変換の無保護',
                        'description': '`.astype()` が try/except で保護されていない（NaN 含む場合に例外）',
                        'source': f'{self.source_path}:{lineno}',
                    })

    # ------------------------------------------------------------------
    # LOW リスク: 100 超のハードコード数値（マジックナンバー）
    # ------------------------------------------------------------------

    def _detect_magic_numbers(self, tree: ast.AST, risks: list[dict]) -> None:
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
                val = node.value
                if isinstance(val, float):
                    val = int(val)
                if abs(val) > 100 and val not in (0, 1, -1):
                    lineno = getattr(node, 'lineno', 0)
                    risks.append({
                        'risk_id': self._make_risk_id('LOW', len(risks)),
                        'level': 'LOW',
                        'category': 'マジックナンバー',
                        'description': f'ハードコードされた数値 `{node.value}` （マジックナンバー）',
                        'source': f'{self.source_path}:{lineno}',
                    })

    # ------------------------------------------------------------------
    # ユーティリティ
    # ------------------------------------------------------------------

    @staticmethod
    def _get_func_name(node: ast.expr) -> str:
        if isinstance(node, ast.Attribute):
            parent = RiskDetector._get_func_name(node.value)
            return f'{parent}.{node.attr}' if parent else node.attr
        if isinstance(node, ast.Name):
            return node.id
        return ''

    @staticmethod
    def _make_risk_id(level: str, index: int) -> str:
        prefix = {'HIGH': 'H', 'MEDIUM': 'M', 'LOW': 'L'}.get(level, 'X')
        return f'RISK-{prefix}{index + 1:03d}'


# ---------------------------------------------------------------------------
# LegacyCodeExtractor  (メインクラス)
# ---------------------------------------------------------------------------

class LegacyCodeExtractor:
    """レガシーアプリの静的解析を行い、2本のファイルを出力する"""

    _EXCLUDE_DIRS = {'__pycache__', '.venv', 'venv', 'node_modules', 'tests', '.git', '.claude'}
    _EXCLUDE_PREFIXES = ('test_', '.test')

    def __init__(self, app_path: str, output_dir: str | None = None):
        self.app_path = Path(app_path).resolve()
        if output_dir:
            self.output_dir = Path(output_dir).resolve()
        else:
            # デフォルト: スクリプト配置ディレクトリの ../output/
            script_dir = Path(__file__).parent
            self.output_dir = script_dir.parent / 'output'

        self.py_files: list[Path] = []
        self.all_columns: list[dict] = []
        self.all_risks: list[dict] = []
        self.imports: dict[str, list[str]] = {}
        self.entry_point: str | None = None

    # ------------------------------------------------------------------
    # 公開 API
    # ------------------------------------------------------------------

    def run(self) -> dict:
        """解析を実行し、出力ファイルを生成する"""
        print(f'🔍 解析対象: {self.app_path}')
        self._collect_py_files()
        self._detect_entry_point()
        self._analyze_all_files()
        result = self._build_context()
        self._write_outputs(result)
        print(f'✅ 完了: {self.output_dir}')
        return result

    # ------------------------------------------------------------------
    # ファイル収集
    # ------------------------------------------------------------------

    def _collect_py_files(self) -> None:
        for f in sorted(self.app_path.rglob('*.py')):
            # 除外ディレクトリ
            if any(part in self._EXCLUDE_DIRS for part in f.parts):
                continue
            # 除外プレフィックス
            if any(f.name.startswith(p) for p in self._EXCLUDE_PREFIXES):
                continue
            self.py_files.append(f)
        print(f'  📂 Pythonファイル: {len(self.py_files)} 件')

    def _detect_entry_point(self) -> None:
        candidates = ['app.py', 'main.py', 'Home.py']
        for c in candidates:
            for f in self.py_files:
                if f.name == c:
                    self.entry_point = f.name
                    return
        if self.py_files:
            self.entry_point = self.py_files[0].name

    # ------------------------------------------------------------------
    # ファイル解析
    # ------------------------------------------------------------------

    def _analyze_all_files(self) -> None:
        for f in self.py_files:
            try:
                source = f.read_text(encoding='utf-8', errors='replace')
                source_lines = source.splitlines()
                tree = ast.parse(source)
            except SyntaxError as e:
                print(f'  ⚠️  構文エラー ({f.name}): {e}')
                continue
            except Exception as e:
                print(f'  ⚠️  読み込みエラー ({f.name}): {e}')
                continue

            rel = str(f.relative_to(self.app_path))

            # カラム抽出
            analyzer = DataFrameAnalyzer(rel)
            cols = analyzer.extract_columns(tree, source_lines)
            self.all_columns.extend(cols)

            # リスク検出
            detector = RiskDetector(rel)
            risks = detector.detect_risks(tree, source_lines)
            self.all_risks.extend(risks)

            # import 収集
            self._collect_imports(tree, rel)

        # risk_id を通し番号で振り直す
        self._reassign_risk_ids()

    def _collect_imports(self, tree: ast.AST, rel: str) -> None:
        INTERESTING = {
            'streamlit', 'pandas', 'polars', 'snowflake', 'pochilib',
            'sqlalchemy', 'requests', 'httpx',
        }
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    base = alias.name.split('.')[0]
                    if base in INTERESTING:
                        self.imports.setdefault(base, [])
                        if rel not in self.imports[base]:
                            self.imports[base].append(rel)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    base = node.module.split('.')[0]
                    if base in INTERESTING:
                        self.imports.setdefault(base, [])
                        if rel not in self.imports[base]:
                            self.imports[base].append(rel)

    def _reassign_risk_ids(self) -> None:
        counters: dict[str, int] = {}
        for risk in self.all_risks:
            level = risk['level']
            prefix = {'HIGH': 'H', 'MEDIUM': 'M', 'LOW': 'L'}.get(level, 'X')
            counters[prefix] = counters.get(prefix, 0) + 1
            risk['risk_id'] = f'RISK-{prefix}{counters[prefix]:03d}'

    # ------------------------------------------------------------------
    # コンテキスト構築
    # ------------------------------------------------------------------

    def _build_context(self) -> dict:
        risks_by_level = {
            'HIGH': sum(1 for r in self.all_risks if r['level'] == 'HIGH'),
            'MEDIUM': sum(1 for r in self.all_risks if r['level'] == 'MEDIUM'),
            'LOW': sum(1 for r in self.all_risks if r['level'] == 'LOW'),
        }
        return {
            '_meta': {
                'generated_by': 'pochi-legacy-analyzer/legacy_code_extractor.py',
                'generated_at': datetime.now().isoformat(),
                'schema_version': '1.0.0',
            },
            'app': {
                'app_path': str(self.app_path),
                'entry_point': self.entry_point,
                'total_files': len(self.py_files),
                'reference_files': [str(f) for f in self.py_files],
            },
            'detected_columns': self.all_columns,
            'detected_risks': self.all_risks,
            'imports': self.imports,
            'summary': {
                'total_columns_detected': len(self.all_columns),
                'total_risks_detected': len(self.all_risks),
                'risks_by_level': risks_by_level,
            },
            'output_dir': str(self.output_dir),
        }

    # ------------------------------------------------------------------
    # ファイル出力
    # ------------------------------------------------------------------

    def _write_outputs(self, context: dict) -> None:
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # 1. analysis_context.json
        json_path = self.output_dir / 'analysis_context.json'
        json_path.write_text(
            json.dumps(context, ensure_ascii=False, indent=2),
            encoding='utf-8',
        )
        print(f'  📄 {json_path}')

        # 2. legacy_structure.md
        md_path = self.output_dir / 'legacy_structure.md'
        md_path.write_text(self._build_markdown(context), encoding='utf-8')
        print(f'  📄 {md_path}')

    def _build_markdown(self, ctx: dict) -> str:
        now = ctx['_meta']['generated_at'][:16].replace('T', ' ')
        app = ctx['app']
        summary = ctx['summary']
        rbyl = summary['risks_by_level']

        high_cols = [c for c in ctx['detected_columns'] if c['confidence'] == 'HIGH']
        med_cols = [c for c in ctx['detected_columns'] if c['confidence'] == 'MEDIUM']
        high_risks = [r for r in ctx['detected_risks'] if r['level'] == 'HIGH']
        med_risks = [r for r in ctx['detected_risks'] if r['level'] == 'MEDIUM']
        low_risks = [r for r in ctx['detected_risks'] if r['level'] == 'LOW']

        lines = [
            '# レガシーコード事前解析レポート',
            '',
            f'生成日時: {now}',
            f'解析対象: `{app["app_path"]}`',
            f'エントリポイント: `{app["entry_point"]}`',
            '',
            '> このレポートは静的解析スクリプト（`legacy_code_extractor.py`）が自動生成しました。',
            '> LLMはこの情報を参照して解析の精度を高めてください。',
            '',
            '---',
            '',
            '## サマリー',
            '',
            '| 項目 | 値 |',
            '|:---|:---|',
            f'| 解析ファイル数 | {app["total_files"]} 件 |',
            f'| 検出カラム数 | {summary["total_columns_detected"]} 件 |',
            f'| 検出リスク数 | {summary["total_risks_detected"]} 件（High: {rbyl["HIGH"]}, Medium: {rbyl["MEDIUM"]}, Low: {rbyl["LOW"]}） |',
            '',
            '---',
            '',
            '## 検出カラム（HIGH Confidence）',
            '',
        ]

        if high_cols:
            lines += [
                '| カラム名 | コンテキスト | ソース |',
                '|:---|:---|:---|',
            ]
            for c in high_cols:
                lines.append(f'| `{c["column"]}` | {c["context"]} | `{c["source"]}` |')
        else:
            lines.append('（HIGH Confidence のカラムは検出されませんでした）')

        lines += [
            '',
            '## 検出カラム（MEDIUM Confidence）',
            '',
        ]

        if med_cols:
            lines += [
                '| カラム名 | コンテキスト | ソース |',
                '|:---|:---|:---|',
            ]
            for c in med_cols:
                lines.append(f'| `{c["column"]}` | {c["context"]} | `{c["source"]}` |')
        else:
            lines.append('（MEDIUM Confidence のカラムは検出されませんでした）')

        lines += [
            '',
            '---',
            '',
            '## セキュリティリスク（HIGH）',
            '',
        ]

        if high_risks:
            lines += [
                '| ID | カテゴリ | 説明 | ソース |',
                '|:---|:---|:---|:---|',
            ]
            for r in high_risks:
                lines.append(f'| {r["risk_id"]} | {r["category"]} | {r["description"]} | `{r["source"]}` |')
        else:
            lines.append('（HIGH リスクは検出されませんでした）')

        lines += [
            '',
            '## セキュリティリスク（MEDIUM）',
            '',
        ]

        if med_risks:
            lines += [
                '| ID | カテゴリ | 説明 | ソース |',
                '|:---|:---|:---|:---|',
            ]
            for r in med_risks:
                lines.append(f'| {r["risk_id"]} | {r["category"]} | {r["description"]} | `{r["source"]}` |')
        else:
            lines.append('（MEDIUM リスクは検出されませんでした）')

        lines += [
            '',
            '## セキュリティリスク（LOW）',
            '',
        ]

        if low_risks:
            lines += [
                '| ID | カテゴリ | 説明 | ソース |',
                '|:---|:---|:---|:---|',
            ]
            for r in low_risks:
                lines.append(f'| {r["risk_id"]} | {r["category"]} | {r["description"]} | `{r["source"]}` |')
        else:
            lines.append('（LOW リスクは検出されませんでした）')

        lines += [
            '',
            '---',
            '',
            '## 注意事項（静的解析の限界）',
            '',
            '以下の仕様は静的解析では検出できません。LLM による追加調査・T1（pochi-contract-initializer）のヒアリングで補完してください：',
            '',
            '- **動的生成カラム**: `df[variable]` 系（変数名が解析不能）',
            '- **外部設定ファイル**: `config.yaml` / `.env` 由来のスキーマ・閾値',
            '- **実行時評価**: `eval()` / `exec()` 内のロジック',
            '- **暗黙の型変換**: Pandas の自動型推論による実際の型',
            '- **ビジネス的意味**: ドメイン知識（例: 「売上」の定義）',
        ]

        return '\n'.join(lines) + '\n'


# ---------------------------------------------------------------------------
# CLI エントリポイント
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description='レガシーアプリのソースコードを静的解析し、カラム・リスク情報を抽出する'
    )
    parser.add_argument('app_path', help='解析対象アプリのディレクトリパス')
    parser.add_argument('--output-dir', default=None, help='出力ディレクトリ（省略時: <skill_dir>/output/）')
    args = parser.parse_args()

    extractor = LegacyCodeExtractor(args.app_path, args.output_dir)
    result = extractor.run()

    summary = result['summary']
    rbyl = summary['risks_by_level']
    print()
    print('=' * 60)
    print('📊 解析サマリー')
    print('=' * 60)
    print(f'  解析ファイル数: {result["app"]["total_files"]} 件')
    print(f'  検出カラム数:   {summary["total_columns_detected"]} 件')
    print(f'  検出リスク数:   {summary["total_risks_detected"]} 件'
          f'（High: {rbyl["HIGH"]}, Medium: {rbyl["MEDIUM"]}, Low: {rbyl["LOW"]}）')
    print()
    print(f'  📄 {result["output_dir"]}/legacy_structure.md')
    print(f'  📄 {result["output_dir"]}/analysis_context.json')
    print('=' * 60)


if __name__ == '__main__':
    main()
