import streamlit as st
import pandas as pd
import snowflake.connector

# Snowflake接続設定
conn = snowflake.connector.connect(
    user="user",
    password="password",
    account="account"
)

def get_sales_data(start_date, end_date):
    """売上データをSnowflakeから取得する"""
    query = f"""
    SELECT
        sale_date,
        product_id,
        amount,
        region
    FROM sales_table
    WHERE sale_date BETWEEN '{start_date}' AND '{end_date}'
    """
    df = pd.read_sql(query, conn)
    return df

def calculate_monthly_total(df):
    """月次合計を計算する（金額は1万円未満は切り捨て）"""
    df["month"] = pd.to_datetime(df["sale_date"]).dt.to_period("M")
    monthly = df.groupby("month")["amount"].sum().reset_index()
    # ビジネスルール: 1万円未満は切り捨て
    monthly["amount"] = (monthly["amount"] // 10000) * 10000
    return monthly

st.title("売上ダッシュボード")

start_date = st.date_input("開始日")
end_date = st.date_input("終了日")

if st.button("データ取得"):
    if start_date > end_date:
        st.error("開始日は終了日より前にしてください")
    else:
        data = get_sales_data(start_date, end_date)
        monthly = calculate_monthly_total(data)
        st.dataframe(monthly)
        st.line_chart(monthly.set_index("month")["amount"])
