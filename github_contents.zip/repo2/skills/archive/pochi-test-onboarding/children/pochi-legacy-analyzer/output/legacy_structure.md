# レガシーコード事前解析レポート

生成日時: 2026-03-18 07:10
解析対象: `/home/user/pochi-dp-developer-docs/skills/pochi-legacy-analyzer/test/test-input`
エントリポイント: `dummy-app.py`

> このレポートは静的解析スクリプト（`legacy_code_extractor.py`）が自動生成しました。
> LLMはこの情報を参照して解析の精度を高めてください。

---

## サマリー

| 項目 | 値 |
|:---|:---|
| 解析ファイル数 | 1 件 |
| 検出カラム数 | 9 件 |
| 検出リスク数 | 4 件（High: 1, Medium: 1, Low: 2） |

---

## 検出カラム（HIGH Confidence）

| カラム名 | コンテキスト | ソース |
|:---|:---|:---|
| `sale_date` | SQL SELECT | `dummy-app.py:14` |
| `product_id` | SQL SELECT | `dummy-app.py:14` |
| `amount` | SQL SELECT | `dummy-app.py:14` |
| `region` | SQL SELECT | `dummy-app.py:14` |
| `sale_date` | SQL WHERE | `dummy-app.py:14` |
| `month` | df["column"] | `dummy-app.py:28` |
| `amount` | df["column"] | `dummy-app.py:31` |
| `sale_date` | df["column"] | `dummy-app.py:28` |

## 検出カラム（MEDIUM Confidence）

| カラム名 | コンテキスト | ソース |
|:---|:---|:---|
| `month` | df.groupby(...) | `dummy-app.py:29` |

---

## セキュリティリスク（HIGH）

| ID | カテゴリ | 説明 | ソース |
|:---|:---|:---|:---|
| RISK-H001 | SQLインジェクション | f-string 内に変数を含む SQL SELECT 文（SQLインジェクションリスク） | `dummy-app.py:14` |

## セキュリティリスク（MEDIUM）

| ID | カテゴリ | 説明 | ソース |
|:---|:---|:---|:---|
| RISK-M001 | エラーハンドリング欠如 | `snowflake.connector.connect()` が try/except で保護されていない | `dummy-app.py:6` |

## セキュリティリスク（LOW）

| ID | カテゴリ | 説明 | ソース |
|:---|:---|:---|:---|
| RISK-L001 | マジックナンバー | ハードコードされた数値 `10000` （マジックナンバー） | `dummy-app.py:31` |
| RISK-L002 | マジックナンバー | ハードコードされた数値 `10000` （マジックナンバー） | `dummy-app.py:31` |

---

## 注意事項（静的解析の限界）

以下の仕様は静的解析では検出できません。LLM による追加調査・T1（pochi-contract-initializer）のヒアリングで補完してください：

- **動的生成カラム**: `df[variable]` 系（変数名が解析不能）
- **外部設定ファイル**: `config.yaml` / `.env` 由来のスキーマ・閾値
- **実行時評価**: `eval()` / `exec()` 内のロジック
- **暗黙の型変換**: Pandas の自動型推論による実際の型
- **ビジネス的意味**: ドメイン知識（例: 「売上」の定義）
