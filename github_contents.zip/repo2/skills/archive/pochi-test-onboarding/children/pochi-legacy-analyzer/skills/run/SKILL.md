---
name: pochi-legacy-analyzer
description: >-
  既存コード（レガシーアプリ）を解析し、テスト品質契約ファイル群のドラフト
  （data-contracts.json / business-rules.json / risk-catalog.md）を自動逆抽出する。
  ヒアリングなしにコードから「仕様の種」を自動抽出し、T1（pochi-contract-initializer）の
  「確認モード」へ渡すことで、レガシーアプリへのテスト基盤導入を加速する。
  「既存コードを解析して」「レガシーアプリにテストを導入したい」と言われたときに使用する。
---

> [!WARNING]
> **このスキルは廃止されました。**
> 後継スキル: `pochi-unit-test-generator` — 「単体テストを生成して」で起動
> このスキルは何も実行せずに終了します。後継スキルのトリガーフレーズを入力してください。

このスキルは廃止済みのため、**何も実行しません。**

後継スキル **`pochi-unit-test-generator` — 「単体テストを生成して」で起動** を使用してください。


Read the file `SKILL.md` located in the same directory as this plugin's root (two levels up from this file), then follow those instructions exactly to complete the task.
