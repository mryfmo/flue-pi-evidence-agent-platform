# T4: pochi-fixtures-manager 生成プロンプト

## 目的

`pochi-fixtures-manager` を起動し、`{app_path}/tests/contracts/data-contracts.json` から
valid / invalid / edge のテストデータセット（fixtures）を生成する。

## 実行手順（サブエージェント内での処理）

> このプロンプトは **Agent ツールで起動したサブエージェント** が実行する。
> オーケストレーター（pochi-test-onboarding 本体）はこのファイルを直接読まない。

1. `skills/pochi-fixtures-manager/SKILL.md` を Read する
2. `{app_path}/tests/contracts/data-contracts.json` を Read して入力スキーマを把握する
3. pochi-fixtures-manager を実行し、以下を生成する：
   - `{app_path}/tests/fixtures/` 配下の CSV 群（valid / invalid / edge 各データ）
   - `{app_path}/tests/fixtures/manifest.json`（fixtures 管理台帳）
4. 生成を Glob で確認する
5. 返答の末尾に生成結果サマリー（成功/失敗）を明記してオーケストレーターに報告する

## 変数

- `{app_path}`: 対象アプリのリポジトリパス

## 生成するファイルの構成

```
{app_path}/tests/fixtures/
├── valid/          ← 正常データ（各入力スキーマに対して1〜3件）
│   └── *.csv
├── invalid/        ← 異常データ（型違反・必須欠損等）
│   └── *.csv
├── edge/           ← エッジケース（空ファイル・境界値等）
│   └── *.csv
└── manifest.json   ← fixtures 管理台帳
```

## 完了メッセージ（T4完了時に表示）

```
✅ T4（pochi-fixtures-manager）完了
   - テストデータ（fixtures）を生成しました
   - {app_path}/tests/fixtures/valid/
   - {app_path}/tests/fixtures/invalid/
   - {app_path}/tests/fixtures/edge/
   - {app_path}/tests/fixtures/manifest.json

📋 次は T2（pochi-tdd-workflow）でテストコードを生成します...
```

## エラー時の対応

`tests/contracts/data-contracts.json` が存在しない場合：
- エラーを報告し、T1 の完了を確認するよう促す
- T1 が完了している場合は pochi-contract-initializer を再実行する
