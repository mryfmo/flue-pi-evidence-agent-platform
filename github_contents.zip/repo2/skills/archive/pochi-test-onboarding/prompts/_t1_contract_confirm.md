# T1: pochi-contract-initializer 確認モード呼び出しプロンプト

## 目的

`pochi-contract-initializer` を確認モードで起動し、T0 が生成した
`{app_path}/tests/.onboarding/draft-contracts/` のドラフトを読み込んで、
`{app_path}/tests/contracts/` に最終的な contracts 6ファイルを確定する。

## 実行手順（サブエージェント内での処理）

> このプロンプトは **Agent ツールで起動したサブエージェント** が実行する。
> オーケストレーター（pochi-test-onboarding 本体）はこのファイルを直接読まない。

1. `skills/pochi-contract-initializer/SKILL.md` を Read する
2. T0 のドラフトファイルを先に Read して内容を把握する：
   - `{app_path}/tests/.onboarding/draft-contracts/data-contracts.json`
   - `{app_path}/tests/.onboarding/draft-contracts/business-rules.json`
   - `{app_path}/tests/.onboarding/draft-contracts/risk-catalog.md`
3. pochi-contract-initializer を「確認モード」で実行する：
   - ドラフト内容をベースに不明点のみをユーザーにヒアリングする
   - 大幅な変更がある場合はユーザーに確認を取る
4. 以下の6ファイルを `{app_path}/tests/contracts/` に生成する：
   - `data-contracts.json`
   - `business-rules.json`
   - `test-viewpoints.json`
   - `scenarios.json`
   - `domain-rules.md`
   - `risk-catalog.md`
5. 生成を Glob で確認する（全6ファイルの存在確認）
6. 返答の末尾に生成結果サマリー（成功/失敗・欠落ファイル一覧）を明記してオーケストレーターに報告する

## 変数

- `{app_path}`: 対象アプリのリポジトリパス

## 確認モードの動作

通常の T1 はヒアリング形式でゼロから仕様を引き出すが、
確認モードではドラフトをベースに差分のみを確認する。

ユーザーへの確認メッセージ例：
```
T0 の解析結果を確認します。
以下の内容でよいですか？（修正がある場合は指摘してください）

【入力データ】
- データソース: {detected_sources}
- 主要カラム: {detected_columns}

【ビジネスルール】
- バリデーション: {validation_count} 件
- 計算ロジック: {calculation_count} 件

【リスク】
- High: {high_count} 件
- Medium: {medium_count} 件
```

## 完了メッセージ（T1完了時に表示）

```
✅ T1（pochi-contract-initializer）完了
   - tests/contracts/ に 6ファイルを生成しました
   - {app_path}/tests/contracts/data-contracts.json
   - {app_path}/tests/contracts/business-rules.json
   - {app_path}/tests/contracts/test-viewpoints.json
   - {app_path}/tests/contracts/scenarios.json
   - {app_path}/tests/contracts/domain-rules.md
   - {app_path}/tests/contracts/risk-catalog.md

📋 次は T4（pochi-fixtures-manager）でテストデータを生成します...
```

## エラー時の対応

6ファイルが揃わない場合：
- 欠落ファイルを列挙してユーザーに報告する
- 手動での補完を促し、完了したら継続確認を行う
