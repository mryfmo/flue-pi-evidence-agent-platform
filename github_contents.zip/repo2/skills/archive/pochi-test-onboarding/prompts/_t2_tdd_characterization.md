# T2: pochi-tdd-workflow characterization モード プロンプト

## 目的

`pochi-tdd-workflow` を characterization（既存動作固定）モードで起動し、
`{app_path}` の既存コードと `tests/contracts/` を参照して、
既存の動作を固定するテストコードを `tests/` に生成する。

## 実行手順（サブエージェント内での処理）

> このプロンプトは **Agent ツールで起動したサブエージェント** が実行する。
> オーケストレーター（pochi-test-onboarding 本体）はこのファイルを直接読まない。

1. `skills/pochi-tdd-workflow/SKILL.md` を Read する
2. 以下のファイルを Read して contracts の内容を把握する：
   - `{app_path}/tests/contracts/data-contracts.json`
   - `{app_path}/tests/contracts/business-rules.json`
   - `{app_path}/tests/contracts/test-viewpoints.json`
   - `{app_path}/tests/contracts/scenarios.json`（E2Eシナリオ定義）
   - `{app_path}/tests/contracts/risk-catalog.md`（**必須**: リスク対応テスト生成に使用）
3. **定量目標を事前に算出する**（生成前に必ず実施）：
   - `test-viewpoints.json` の Layer 2 観点数を数える（= N）
   - Layer 2 最低生成数 = N × 2 件
   - 総テスト予定数の目安: Layer1 + Layer2 + Layer3 + Layer4
   - Layer 2 目標 = MAX(N × 2, 総テスト予定数 × 0.40 の整数部) 件
   - 算出した目標件数をコメントとして記録してから生成を開始する
4. **risk-catalog.md の全リスクIDに対応するテストを最優先で生成する**：
   - risk-catalog.md の全リスクID（M001, M002 等）を列挙する
   - 各リスクIDに対して1件以上のテスト関数を生成する（Layer 2 または Layer 3 に配置）
   - リスク対応テストにはコメントで `# RISK: {リスクID}` を明記する
5. pochi-tdd-workflow を characterization モードで実行する：
   - 「新機能を追加するのではなく、既存動作を固定する」という指示を明示する
   - 各テスト層（Layer 1〜4）のテストを生成する
6. 以下のディレクトリにテストコードを生成する：
   - `{app_path}/tests/contracts/` （Layer 1: データ契約テスト 30〜50%目標）
   - `{app_path}/tests/unit/` または `{app_path}/tests/logic/` （Layer 2: ロジックテスト 30〜50%目標）
   - `{app_path}/tests/integration/` （Layer 3: 結合テスト 15〜25%目標）
   - `{app_path}/tests/e2e/` （Layer 4: E2Eテスト 5〜15%目標、AppTest または Playwright 使用）
7. **生成後にセルフチェックを行う**：
   - Glob で各テストファイルを収集し、各層のテスト関数数（`def test_` の数）を集計する
   - Layer 2 が全体の 30% 未満であれば、不足分を追加生成してから完了とする
   - **[リスクID検証]** risk-catalog.md から全リスクID（M001, M002, ...）を列挙し、
     各リスクIDに対して Grep で `# RISK: {リスクID}` をテストファイルから検索する。
     未対応のリスクIDがあれば、対応するテストを追加生成してから完了とする。
   - **[観点カバレッジ検証]** test-viewpoints.json の全観点を列挙し、各観点名を Grep で
     テストファイルから検索する（観点名が docstring やコメントに含まれているか確認）。
     未カバーの観点があれば、対応するテストを追加生成してから完了とする。
   - **[実コードインポート検証]** 生成した全テストファイルで
     `from app.` または `import app.` を Grep する。
     app/ をインポートしていないテストファイルが存在する場合、
     そのファイルを修正して実コードを呼び出すよう書き直してから完了とする。
   - **[⑥ モジュールカバレッジ検証]**（T3補完モードで実行した場合は必須）:
     - `{app_path}/tests/.onboarding/module-inventory.json` を Read する
       （ファイルが存在しない場合はこの検証をスキップする）
     - `module-inventory.json` の全モジュールパスについて、`{app_path}/tests/**/*.py` から
       モジュール名を Grep（`import` 文または `from` 文の有無）して未カバーを特定する
     - `priority = "high"` かつ未カバーのモジュールがあれば、
       `{app_path}/tests/unit/test_{module_name}.py` を追加生成する
     - 生成するテストの品質基準:
       * 関数の存在確認（`callable()` チェック）ではなく、戻り値の型・構造を `assert` すること
       * Snowflake 依存は `unittest.mock.patch` でモック化すること
       * `fuzzy_search.py` 等でモジュール内に `if __name__ == '__main__':` があるものは
         pytest 未対応のため、`def test_*` 形式のテストファイルを生成すること
8. 生成を Glob で確認する
9. 返答の末尾に以下を明記してオーケストレーターに報告する：
   - 成功/失敗・生成ファイル数
   - 各層のテスト関数数と比率（例: Layer 1: 12件(40%), Layer 2: 13件(43%), ...）
   - risk-catalog.md のリスクIDと対応テスト関数名の対応表（全リスクID・カバー状況）:
     | リスクID | リスク概要 | 対応テスト関数 | カバー済み |
   - test-viewpoints.json の観点と対応テスト関数のカバレッジ表（全観点・カバー状況）:
     | 観点ID | 観点名 | 対応テスト関数 | カバー済み |

## 変数

- `{app_path}`: 対象アプリのリポジトリパス

## Characterization モードの動作

通常の TDD フロー（新機能実装）とは異なり、characterization モードでは：

1. **既存コードを読んで現在の動作を把握し、テスト対象の関数・クラスのインポートパスを特定する**
2. **その動作を「期待値」としてテストに固定する**（正しいかどうかではなく、「現状こう動く」という記録）
3. **テストが PASS することを確認する**（既存動作と一致するため当初 PASS のはず）

## リスク対応テストの生成（必須）

`risk-catalog.md` の各リスクIDに対して、以下のようなテストを生成する：

```python
# RISK: M001 - Snowflake接続エラー
def test_snowflake_connection_error_is_handled():
    """Snowflake接続失敗時にエラーが適切に処理されること"""
    with patch("pochilib.snowflake.get_connection", side_effect=Exception("Connection failed")):
        result = fetch_data_from_snowflake()
        # エラー時は None または空の DataFrame を返すことを確認
        assert result is None or (hasattr(result, "empty") and result.empty)

# RISK: M002 - IndexError（空リスト・空DataFrame）
def test_empty_dataframe_does_not_raise_index_error():
    """空DataFrameを渡してもIndexErrorが発生しないこと"""
    import pandas as pd
    df = pd.DataFrame()
    # 例外が発生しないことを確認
    try:
        result = process_dataframe(df)
        assert result is not None
    except IndexError:
        pytest.fail("IndexError が発生した（リスクM002 未対応）")
```

リスクIDが不明な場合は `risk-catalog.md` に記載された全エントリを参照すること。

## 定量目標の算出ガイド

生成開始前に以下を計算して記録する：

```
【定量目標の事前計算】
test-viewpoints.json の Layer 2 観点数: {N} 件
→ Layer 2 最低生成数 = {N} × 2 = {N*2} 件

総テスト数の目安:
  Layer 1: {目標件数} 件
  Layer 2: {目標件数} 件（最低 {N*2} 件）
  Layer 3: {目標件数} 件
  Layer 4: {目標件数} 件
  合計: {総件数} 件

risk-catalog.md リスクID一覧: {M001, M002, ...}
→ 各リスクに最低1テスト = {リスク数} 件（Layer 2 or 3 に含む）
```

生成するテストの指示例：
```
# contracts/data-contracts.json のスキーマを元に
# Layer 1（データ契約テスト）を生成する

# tests/contracts/test_data_contracts.py
def test_input_schema_valid():
    """正常入力データがスキーマ定義に準拠していることを検証"""
    ...

def test_input_schema_invalid_type():
    """型違反データが適切に検出されることを検証"""
    ...
```

Layer 4（E2Eテスト）の生成例：
```python
# contracts/scenarios.json の各シナリオを元に
# Streamlit AppTest を使って tests/e2e/ にテストを生成する

# tests/e2e/test_e2e_scenarios.py
from streamlit.testing.v1 import AppTest

def test_scenario_upload_and_analyze():
    """シナリオ: CSVアップロード → 分析実行 → 結果表示"""
    at = AppTest.from_file("app.py")
    at.run()
    # ファイルアップロード操作
    at.file_uploader[0].upload(valid_csv_bytes, name="test.csv")
    at.run()
    # 分析ボタンクリック
    at.button[0].click()
    at.run()
    # 結果が表示されることを確認
    assert not at.error
    assert len(at.dataframe) > 0
```

> **注意**: `contracts/scenarios.json` に定義されたシナリオをすべて網羅するよう、
> 各シナリオに対応するE2Eテスト関数を生成すること。
> Streamlit アプリの場合は `AppTest`、Web アプリの場合は `Playwright` を使用する。
>
> **scenarios.json が空または存在しない場合のフォールバック**:
> シナリオ定義がない場合でも Layer 4 テストの生成をスキップしてはならない。
> 以下のデフォルトシナリオを最低 1 件生成すること：
> - アプリ起動テスト: `AppTest.from_file("app.py")` で起動し、エラーが発生しないことを確認
> - 基本操作テスト: メイン UI 要素（ボタン・セレクトボックス等）が表示されることを確認

## テストコード品質基準

生成するテストコードは以下の品質基準を満たすこと。

### ① 曖昧表現禁止ルール

docstring・コメントで抽象的な表現を使用してはならない。

```
禁止表現: 「適切に」「正しく」「正常に」「問題なく」「うまく」

禁止例: """Snowflake接続が適切に処理されること"""
推奨例: """Snowflake接続失敗時にNoneまたは空DataFrameを返すこと"""
```

### ② テスト関数命名規則

`test_{機能名}_{条件}_{期待結果}` パターンを基本とし、テスト名だけで仕様が伝わるようにする。

```
良い例:
  test_fetch_data_when_snowflake_down_returns_none
  test_process_empty_dataframe_no_index_error
  test_filter_multiple_conditions_returns_correct_count

悪い例:
  test_fetch_data  （条件・期待結果が不明）
  test_error_case  （何のエラーか不明）
```

### ③ アサーション具体性ルール

`assert result is not None` のような存在確認のみのアサーションを禁止し、型・値・件数を明示する。

```
禁止: assert result is not None            （存在のみ確認）
推奨: assert isinstance(result, pd.DataFrame)   （型を明示）
     assert len(result) == 0               （件数を明示）
     assert result["col"].dtype == "int64" （スキーマを明示）
     assert "error" not in result          （内容を明示）
```

### ④ 実コードインポート必須ルール

テストは必ず `app/` 配下の実装コードをインポートして呼び出すこと。
テスト内でビジネスロジックを再実装してはならない。

```
禁止パターン:
  # NG: テスト内で sum を直接実行（app/ のコードを呼んでいない）
  total = sum(transactions)
  assert total == expected_total

  # NG: 文字列定数を検証しているだけ
  error_class = "snowflake.connector.errors.ProgrammingError"
  assert "ProgrammingError" in error_class

  # NG: app/ をインポートしていない
  df = pd.DataFrame({"col": [1, 2, 3]})
  assert len(df) == 3

推奨パターン:
  # OK: app/ の実装をインポートして呼び出す
  from app.lib.data_loader import fetch_data
  result = fetch_data(conditions)
  assert isinstance(result, pd.DataFrame)

  # OK: Snowflake依存はモックして実コードのフローをテスト
  from app.reporting_function._reporting_page import get_data
  with patch("app.reporting_function._reporting_page.session") as mock_session:
      mock_session.query.return_value.filter.return_value.all.return_value = [...]
      result = get_data(conditions)
      assert isinstance(result, pd.DataFrame)
```

### ⑤ Snowflake/Streamlit依存のモック戦略

Snowflake・Streamlit に依存した実コードをテストする場合は、
依存部分をモックして実コードのフロー全体をカバーすること。

```
モック対象と推奨パターン:
  # Snowflake セッション
  with patch("app.XXX.session") as mock_session:
      mock_session.query.return_value...

  # pochilib 経由の接続
  with patch("pochilib.snowflake.get_connection", return_value=mock_conn):
      ...

  # SQLAlchemy クエリ結果
  with patch.object(Session, "query") as mock_query:
      mock_query.return_value.filter.return_value.all.return_value = [...]

  # Streamlit session_state
  import streamlit as st
  st.session_state["key"] = value  # AppTest 外では直接設定可能
```

## 完了メッセージ（T2完了時に表示）

```
✅ T2（pochi-tdd-workflow）完了
   - テストコードを生成しました
   - {app_path}/tests/contracts/   （Layer 1: データ契約テスト）
   - {app_path}/tests/unit/        （Layer 2: ロジックテスト）
   - {app_path}/tests/integration/ （Layer 3: 結合テスト）
   - {app_path}/tests/e2e/         （Layer 4: E2Eテスト）

📋 次は T3（pochi-test-strategy-auditor）で監査します...
```

## エラー時の対応

`tests/contracts/` が存在しない場合：
- T1 の完了を確認するよう促す
- tests/contracts/ がない状態では T2 を実行できない旨を説明する
