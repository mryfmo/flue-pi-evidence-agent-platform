# T0: pochi-legacy-analyzer 呼び出しプロンプト

## 目的

`pochi-legacy-analyzer` を起動し、`{app_path}` の既存コードを静的解析して、
テスト品質契約ファイル群のドラフトを自動逆抽出する。

## 実行手順（サブエージェント内での処理）

> このプロンプトは **Agent ツールで起動したサブエージェント** が実行する。
> オーケストレーター（pochi-test-onboarding 本体）はこのファイルを直接読まない。

1. `skills/pochi-legacy-analyzer/SKILL.md` を Read する
2. その SKILL.md の指示に従い、以下の情報を引き渡して T0 を実行する：
   - 解析対象アプリパス: `{app_path}`
   - エントリポイント: `{entrypoint}` （「不明」の場合は自動推定）
3. T0 の完了を待ち、以下のファイルが生成されたことを Glob で確認する：
   - `{app_path}/tests/.onboarding/legacy-analysis.md`
   - `{app_path}/tests/.onboarding/draft-contracts/data-contracts.json`
   - `{app_path}/tests/.onboarding/draft-contracts/business-rules.json`
   - `{app_path}/tests/.onboarding/draft-contracts/risk-catalog.md`
4. 返答の末尾に生成結果サマリー（成功/失敗・欠落ファイル一覧）を明記してオーケストレーターに報告する

## 変数

- `{app_path}`: ユーザーが入力した対象アプリのリポジトリパス
- `{entrypoint}`: ユーザーが入力したエントリポイント（「不明」の場合は空欄）

## 完了メッセージ（T0完了時に表示）

```
✅ T0（pochi-legacy-analyzer）完了
   - 解析レポート: {app_path}/tests/.onboarding/legacy-analysis.md
   - ドラフト契約: {app_path}/tests/.onboarding/draft-contracts/（3ファイル）

📋 次は T1（pochi-contract-initializer）でドラフトを確認します...
```

## エラー時の対応

T0 の生成ファイルが存在しない場合：
- 欠落ファイルを列挙してユーザーに報告する
- 「T0 を手動で再実行しますか？」とユーザーに確認する
- ユーザーが「いいえ」を選択した場合は T1 をスキップして T4 に進む（contracts/ が手動作成済みの場合のみ）
