---
name: pochi-test-onboarding
description: >-
  既存アプリ（レガシー）にテスト基盤を一括導入する統合Skill。
  T0(pochi-legacy-analyzer)→T1(pochi-contract-initializer)→
  T4(pochi-fixtures-manager)→T2(pochi-tdd-workflow)→
  T3(pochi-test-strategy-auditor)を順次実行し、
  テストピラミッド（契約30〜50%/ロジック30〜50%/結合15〜25%/E2E 5〜15%）を自動生成・監査する。
---

> [!WARNING]
> **このスキルは廃止されました。**
> 後継スキル: `pochi-test-strategy-initializer` → `pochi-unit-test-generator` → `pochi-integration-test-designer/generator` → `pochi-e2e-test-designer/generator`
> このスキルは何も実行せずに終了します。後継スキルのトリガーフレーズを入力してください。

このスキルは廃止済みのため、**何も実行しません。**

後継スキル **`pochi-test-strategy-initializer` → `pochi-unit-test-generator` → `pochi-integration-test-designer/generator` → `pochi-e2e-test-designer/generator`** を使用してください。


# pochi-test-onboarding Skill

## スキル概要

既存アプリ（レガシー）にテスト基盤を一括導入する統合Skill。以下の5個のカスタムサブエージェントをT0→T1→T4→T2→T3の順に起動し、テストピラミッドを自動生成・監査する。

## 使用可能なカスタムサブエージェント

| フェーズ | エージェント名 | 役割 |
|---|---|---|
| T0 | `pochi-t0-legacy-analyzer` | 既存コード静的解析 → contracts ドラフトを逆抽出 |
| T1 | `pochi-t1-contract-initializer` | ドラフト確認 → 6ファイル確定 + VP-Auto 自動追加 |
| T4 | `pochi-t4-fixtures-manager` | data-contracts.json からテストデータセット生成 |
| T2 | `pochi-t2-tdd-workflow` | characterization モードで既存動作を固定するテスト生成 |
| T3 | `pochi-t3-test-strategy-auditor` | テストピラミッド監査・不足層補完推奨 |

---

## ワークフロー

> ⚠️ **絶対必須・直接実行禁止**
>
> このスキルの全ワークフローは、以下に定義するカスタムサブエージェントを**Agentツールで起動**して実行すること。
> Claude Code（あなた自身）が直接コードを解析・テストを生成・監査することは**厳禁**。
> 各STEPで必ず対応するカスタムサブエージェントを起動すること。

---

### STEP 1-2: ユーザーからの情報収集

AskUserQuestionツールで以下を確認する：

- 対象アプリのリポジトリパス（絶対パス）
- アプリのエントリポイント（例: `app/app.py`）
- テストピラミッドの目標比率（デフォルト: 契約30〜50%/ロジック30〜50%/結合15〜25%/E2E 5〜15%）

---

### STEP 3: T0フェーズ（既存コード静的解析）

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-test-onboarding:pochi-t0-legacy-analyzer"`）を起動すること。Claude Code自身が直接コードを解析することは厳禁。

```
Agentツールで pochi-t0-legacy-analyzer カスタムサブエージェントを起動し、
以下を実行させてください：
- 対象アプリのコードを静的解析
- tests/.onboarding/draft-contracts/ に以下の3ファイルを生成：
  - data-contracts.json（ドラフト）
  - business-rules.json（ドラフト）
  - risk-catalog.md（ドラフト）
- module-inventory.json を生成
```

T0フェーズ完了を確認してから次のSTEPへ進む。

---

### STEP 4: T1フェーズ（テスト品質契約ファイル確定）

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-test-onboarding:pochi-t1-contract-initializer"`）を起動すること。Claude Code自身が直接ファイルを作成することは厳禁。

```
Agentツールで pochi-t1-contract-initializer カスタムサブエージェントを起動し、
以下を実行させてください：
- tests/.onboarding/draft-contracts/ のドラフトを確認モードで読み込み
- 不明点のみユーザーにヒアリング
- tests/contracts/ に以下の6ファイルを確定：
  - data-contracts.json
  - business-rules.json
  - test-viewpoints.json
  - scenarios.json
  - domain-rules.md
  - risk-catalog.md
- module-inventory.json を参照してVP-Auto-* を自動追加
```

T1フェーズ完了を確認してから次のSTEPへ進む。

---

### STEP 5: T4フェーズ（テストデータセット生成）

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-test-onboarding:pochi-t4-fixtures-manager"`）を起動すること。Claude Code自身が直接テストデータを作成することは厳禁。

```
Agentツールで pochi-t4-fixtures-manager カスタムサブエージェントを起動し、
以下を実行させてください：
- tests/contracts/data-contracts.json から valid/invalid/edge のテストデータセットを生成
- tests/fixtures/ 配下に manifest.json を含めて配置
```

T4フェーズ完了を確認してから次のSTEPへ進む。

---

### STEP 6: T2フェーズ（characterization テスト生成）

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"`）を起動すること。Claude Code自身が直接テストコードを生成することは厳禁。

```
Agentツールで pochi-t2-tdd-workflow カスタムサブエージェントを起動し、
characterization（既存動作固定）モードで以下を実行させてください：
- tests/contracts/ を参照して既存動作を固定するテストコードを tests/ に生成
- risk-catalog.md の全リスクに対応するテストを優先生成
- 全観点（test-viewpoints.json）のテストを生成
- 各層（Layer 1-4）のテストを生成
- 実コードインポート・モジュールカバレッジを検証
- セルフチェック（リスク・観点・モジュールカバレッジの整合性）
```

T2フェーズ完了を確認してから次のSTEPへ進む。

---

### STEP 7: T3フェーズ（テスト戦略監査）

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-test-onboarding:pochi-t3-test-strategy-auditor"`）を起動すること。Claude Code自身が直接テスト比率を算出・判断することは厳禁。

```
Agentツールで pochi-t3-test-strategy-auditor カスタムサブエージェントを起動し、
以下を実行させてください：
- tests/ 配下の全テストを分析してテストピラミッド比率を算出
- リスク対応テスト・観点・モジュールカバレッジを検証
- 実コードカバレッジ率（pytest --cov）を計測
- 不足層・未対応リスク・未カバー観点を特定
- tests/test-strategy-audit.md に監査結果を出力
- T2補完プロンプトを生成（必要に応じてSTEP 8へ）
```

T3フェーズの監査結果を確認する。

---

### STEP 8（オプション）: T2補完実行

T3の監査で不足が検出された場合に実施する。

> ⚠️ **必須**: 補完も同様にAgentツールで `pochi-t2-tdd-workflow` を起動すること。Claude Code自身が直接テストを追加することは厳禁。

```
Agentツールで pochi-t2-tdd-workflow カスタムサブエージェントを再起動し、
T3で指摘された以下の不足を補完させてください：
- 未対応リスクのテスト追加
- 未カバー観点のテスト追加
- モジュールカバレッジ不足の補完
```

STEP 7に戻り、補完後の監査を実施する。

---

## 完了条件

- テストピラミッド比率が目標値（契約30〜50%/ロジック30〜50%/結合15〜25%/E2E 5〜15%）の範囲内に収まっている
- risk-catalog.md の全リスクがテストでカバーされている
- 実コードカバレッジ率が 60% 以上、または未達の場合は T2補完プロンプトが生成されている
- tests/test-strategy-audit.md が生成されている
