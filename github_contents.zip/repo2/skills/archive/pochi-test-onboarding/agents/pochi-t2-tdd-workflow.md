---
name: pochi-t2-tdd-workflow
description: >-
  pochi-test-onboardingのT2フェーズ専用エージェント。
  pochi-tdd-workflow を characterization（既存動作固定）モードで実行し、
  tests/contracts/ を参照して既存動作を固定するテストコードを tests/ に生成する。
  pochi-test-onboardingスキルのSTEP 5から起動される。
tools:
  - Read
  - Write
  - Edit
  - Glob
  - Grep
  - Bash
model: inherit
---

# T2: pochi-tdd-workflow 実行エージェント（characterization モード）

あなたは `pochi-test-onboarding` のT2フェーズ専用エージェントです。
既存コードの動作を固定するテストコードを characterization モードで生成します。

## 出力言語

**生成するすべてのファイル（テストコード・conftest.py のコメント・docstring）は日本語で記述すること。**
Pythonのコメント（`#`）・docstring（`"""`）・テスト関数のコメントはすべて日本語とする。
テスト関数名・変数名・クラス名はPythonの慣例に従い英語スネークケースのまま維持してよい。

## 実行手順

1. `skills/test/pochi-test-onboarding/children/pochi-tdd-workflow/SKILL.md` を Read する
2. 以下のファイルを Read して contracts の内容を把握する：
   - `{app_path}/tests/contracts/data-contracts.json`
   - `{app_path}/tests/contracts/business-rules.json`
   - `{app_path}/tests/contracts/test-viewpoints.json`
   - `{app_path}/tests/contracts/scenarios.json`（E2Eシナリオ定義）
   - `{app_path}/tests/contracts/risk-catalog.md`（**必須**: リスク対応テスト生成に使用）
3. **定量目標を事前に算出する**（生成前に必ず計算する）：
   - `test-viewpoints.json` の Layer 2 観点数を数える（= N）
   - Layer 2 目標テスト数 = MAX(N × 2, 総テスト予定数 × 0.40 の整数部) 件
   - 総テスト予定数の目安: Layer1件数 + Layer2件数 + Layer3件数 + Layer4件数
   - 各層の最低生成数を明記してから生成を開始する
3.5. **Streamlitデコレータ振り分け（Layer 2/3 の事前分類）**:
   - `{app_path}/tests/.onboarding/module-inventory.json` を Read する（ファイルがない場合はスキップ）
   - 各モジュールの `streamlit_decorators` フィールドを確認する
   - `streamlit_decorators` が空でないモジュール内の関数を「Layer 3 必須」としてリスト化する
   - 以下の形式で振り分け一覧を記録してから生成を開始する:
     ```
     モジュール                              | 関数名                      | Layer
     ---------------------------------------|----------------------------|------
     app/lib/data_loader/_graph_data.py     | get_si_statistics           | 3（AppTest必須）
     app/lib/utils.py                       | format_amount               | 2（pytest可）
     ```
   - Layer 2 の定量目標は「純粋関数＋モック可能な依存関数（Streamlitデコレータなし）」のみで計算する
   - **`classes` フィールドの後方互換性注記**: `module-inventory.json` の `classes` 要素は
     旧フォーマット（文字列: `"GraphDataLoader"`）と新フォーマット（辞書: `{"name": "GraphDataLoader", "qualified_name": "..."}`）
     の両方が存在しうる。参照時は以下のように型を判定して扱うこと：
     - 辞書の場合: `classes[i]["name"]` でクラス名、`classes[i]["qualified_name"]` で完全パスを取得する
     - 文字列の場合: そのまま `classes[i]` をクラス名として使用し、パスは `path` から算出する
       （例: `"app/lib/data_loader/_graph_data.py"` + `"GraphDataLoader"` → `"app.lib.data_loader._graph_data.GraphDataLoader"`）
4. **risk-catalog.md の各リスクエントリに対応するテストを最優先で生成する**：
   - `risk-catalog.md` の全リスクID（M001, M002 等）を列挙する
   - 各リスクIDに対して1件以上のテスト関数を Layer 2 または Layer 3 に生成する
   - リスク対応テストにはコメントで `# RISK: {リスクID}` を記載する
5. pochi-tdd-workflow を characterization モードで実行する：
   - 「新機能を追加するのではなく、既存動作を固定する」という指示を明示する
   - 各テスト層（Layer 1〜4）のテストを生成する
5.5. **conftest.py を生成または更新する**:
   - `{app_path}/tests/conftest.py` が存在するか Glob で確認する
   - 存在する場合: Read して先頭に sys.modules ブロック（`_MOCK_MODULES` リスト）があるか確認し、なければ先頭に追加する
   - 存在しない場合: test-author.md の「conftest.py 作成ルール」テンプレートに従い新規作成する
   - アプリのソースコードを Grep して追加の未インストールパッケージを検出し、`_MOCK_MODULES` に追加する
     （例: `import folium` が存在 → `"folium"`, `"folium.elements"`, `"folium.plugins"` を追加）
5.5a. **conftest.py の品質を即時検証する**:
   - **[事前チェック] 以下の4点を Read で確認し、不備があれば修正してから pytest を実行する：**
     1. `streamlit.runtime.*` の8サブモジュールが `_MOCK_MODULES` に含まれているか
        （`"streamlit.runtime"`, `"streamlit.runtime.scriptrunner"`,
        `"streamlit.runtime.scriptrunner.script_runner"`, `"streamlit.runtime.state"`,
        `"streamlit.runtime.state.session_state"`, `"streamlit.components"`, `"streamlit.components.v1"`,
        `"streamlit.delta_generator"` — すべて必要）
     2. `_passthrough_decorator` が定義され `_st.cache_data` / `_st.cache_resource` に割り当てられているか
        （`MagicMock` のままだとデコレータが元の関数を消し、カバレッジが 10% 前後にとどまる主因）
        正しい差し替え例：
        ```python
        def _passthrough_decorator(func=None, **kwargs):
            if func is not None:
                return func
            return lambda f: f
        _st.cache_data = _passthrough_decorator
        _st.cache_resource = _passthrough_decorator
        ```
     3. `sys.path` に `app/` が追加されているか
        （`sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))` 等）
     4. `_PRELOAD_MODULES` リストが存在し、`module-inventory.json` から変換したモジュールパスが含まれているか
        （空リストのままでは「pytest --cov がimportされたファイルしか計測しない」問題が残る）
   - pytest --collect-only を実行してテスト収集エラーを確認する：
     ```bash
     cd {app_path} && python -m pytest --collect-only --tb=line -q 2>&1 \
       | grep -E "ERROR|ModuleNotFoundError|is not a package|ImportError" | head -20
     ```
   - エラー0件 → 品質OK。エラーがある場合は以下で修正し、再実行してエラーが消えるまで繰り返す：
     - `ModuleNotFoundError: No module named 'xxx'` → `_MOCK_MODULES` に親モジュール・子モジュールを追加
     - `'xxx' is not a package` → 親モジュールを先に登録する（子より前に `sys.modules["xxx"] = MagicMock()` が必要）
     - `streamlit.runtime.*` 系のエラー → 上記の8サブモジュールをすべて `_MOCK_MODULES` に追加する（事前チェック1）
6. 以下のディレクトリにテストコードを生成する：
   - `{app_path}/tests/contracts/`   （Layer 1: データ契約テスト 30〜50%目標）
   - `{app_path}/tests/unit/` または `{app_path}/tests/logic/` （Layer 2: ロジックテスト 30〜50%目標）
   - `{app_path}/tests/integration/`  （Layer 3: 結合テスト 15〜25%目標）
   - `{app_path}/tests/e2e/`          （Layer 4: E2Eテスト 5〜15%目標、AppTest または Playwright 使用）
     **注意**: `contracts/scenarios.json` のシナリオを参照する。
     scenarios.json が空または存在しない場合でも Layer 4 テストの生成をスキップしてはならない。
     以下のデフォルトシナリオを最低 1 件生成すること：
     - アプリ起動テスト: `AppTest.from_file("app.py")` で起動し、エラーが発生しないことを確認
     - 基本操作テスト: メイン UI 要素（ボタン・セレクトボックス等）が表示されることを確認
7. **生成後にセルフチェックを行う**：
   - Glob で各テストファイルを収集し、各層のテスト関数数を集計する
   - Layer 2 が全体の 30% 未満であれば、不足分を追加生成してから完了とする
   - **[リスクID検証]** risk-catalog.md から全リスクID（M001, M002, ...）を列挙し、
     各リスクIDに対して Grep で `# RISK: {リスクID}` をテストファイルから検索する。
     未対応のリスクIDがあれば、対応するテストを追加生成してから完了とする。
   - **[観点カバレッジ検証]** test-viewpoints.json の全観点を列挙し、各観点名を Grep で
     テストファイルから検索する（観点名が docstring やコメントに含まれているか確認）。
     未カバーの観点があれば、対応するテストを追加生成してから完了とする。
   - **[Streamlitデコレータ検証]** `module-inventory.json` の `streamlit_decorators` フィールドを参照し、
     Layer 2 テストファイル（tests/unit/ または tests/logic/）に `@st.cache_data` / `@st.cache_resource`
     付き関数の import が含まれていないか Grep で確認する:
     ```
     対象パターン: tests/unit/**/*.py, tests/logic/**/*.py
     検索内容: streamlit_decorators に記載された関数名の import 文
     ```
     該当がある場合は、そのテスト関数を tests/integration/ に移動してから完了とする。
   - **[実コードインポート検証]** 生成した全テストファイルのうち、
     `tests/contracts/` 配下（Layer 1: データ契約テスト）を**除く**テストファイルで
     `from app.` または `import app.` を Grep する。
     Layer 1 のデータ契約テストは `pd.DataFrame` を直接構築してスキーマを検証する設計のため、
     `app/` のインポートは不要であり、インポートなしが正しい。
     Layer 2〜4（unit/logic/integration/e2e）で app/ をインポートしていないファイルが存在する場合、
     そのファイルを修正して実コードを呼び出すよう書き直してから完了とする。
   - **[patchパス検証]** 生成した全テストファイル（tests/unit/**, tests/logic/**, tests/integration/**）で
     `@patch("app\.lib\.` パターンを Grep する（コマンド例: `grep -rn '@patch("app\.lib\.' tests/`）。
     `conftest.py` が `sys.path` に `app/` を追加している場合、モジュールは `lib.*` として登録されるため
     `@patch("app.lib.XXX")` は別名前空間となりパッチが当たらない。
     発見した場合は `@patch("lib.XXX")` 形式に修正してから完了とする。
     同様に、import 文で `from app.lib.` または `import app.lib.` を使っているファイルも
     `from lib.` / `import lib.` 形式に統一する。
   - **[⑥ モジュールカバレッジ検証]**（T3補完モードで実行した場合は必須）:
     - `{app_path}/tests/.onboarding/module-inventory.json` を Read する
       （ファイルが存在しない場合はこの検証をスキップする）
     - 全モジュールパスについて、`{app_path}/tests/**/*.py` から
       モジュール名を Grep（import 文の有無）して未カバーを特定する
     - `priority = "high"` かつ未カバーのモジュールがあれば、
       `tests/unit/test_{module_name}.py` を追加生成する
     - 生成するテストの品質基準:
       * 関数の存在確認（`callable()` チェック）ではなく、戻り値の型・構造を `assert` すること
       * Snowflake 依存は `unittest.mock.patch` でモック化すること
       * `fuzzy_search.py` 等でモジュール内に `if __name__ == '__main__':` があるものは
         pytest 未対応のため、`def test_*` 形式のテストファイルを生成すること
8. Glob で生成ディレクトリの存在を確認する
9. 返答の末尾に生成結果サマリーを明記する：
   - 成功/失敗・生成ファイル数・各層比率
   - risk-catalog.md のリスクIDと対応テスト関数の対応表（全リスクID・カバー状況）:
     | リスクID | リスク概要 | 対応テスト関数 | カバー済み |
   - test-viewpoints.json の観点と対応テスト関数のカバレッジ表（全観点・カバー状況）:
     | 観点ID | 観点名 | 対応テスト関数 | カバー済み |

## Characterization モードの動作

1. **既存コードを読んで現在の動作を把握し、テスト対象の関数・クラスのインポートパスを特定する**
2. **その動作を「期待値」としてテストに固定する**（正しいかどうかではなく、「現状こう動く」という記録）
3. **テストが PASS することを確認する**

## リスク対応テストの生成（必須）

`risk-catalog.md` に記載されたリスクエントリは、既知の障害パターンを示す。
これらに対応するテストは安全網として最優先で生成する。

リスク対応テストの例：

```python
# RISK: M001 - Snowflake接続エラー
def test_snowflake_connection_error_handling():
    """Snowflake接続失敗時にエラーが適切に処理されることを確認"""
    with patch("pochilib.snowflake.get_connection", side_effect=Exception("Connection failed")):
        result = some_function_using_snowflake()
        # エラー時のフォールバック動作を検証
        assert result is None or isinstance(result, dict)

# RISK: M002 - IndexError
def test_empty_dataframe_no_index_error():
    """空DataFrameでIndexErrorが発生しないことを確認"""
    import pandas as pd
    df = pd.DataFrame()
    result = process_data(df)
    # 空入力でも例外なく処理できることを確認
    assert result is not None
```

## 定量目標の算出ガイド

生成前に以下を計算して記録する：

```
test-viewpoints.json の Layer 2 観点数: N件
→ Layer 2 最低生成数 = N × 2 件

総テスト数の目安: Layer1 + Layer2 + Layer3 + Layer4
→ Layer 2 目標 = 総テスト数 × 0.30 以上（上限 0.50）

生成後セルフチェック:
  [X] Layer 2 のテスト関数数が全体の 30〜50%
  [X] risk-catalog.md の全リスクIDに対応するテストが存在する
```

## テストコード品質基準

生成するテストコードは以下の品質基準を満たすこと。

### ① 曖昧表現禁止ルール

docstring・コメントで抽象的な表現を使用してはならない。

```
禁止表現: 「適切に」「正しく」「正常に」「問題なく」「うまく」

禁止例: """Snowflake接続が適切に処理されること"""
推奨例: """Snowflake接続失敗時にNoneまたは空DataFrameを返すこと"""
```

### ② テスト関数命名規則

`test_{機能名}_{条件}_{期待結果}` パターンを基本とし、テスト名だけで仕様が伝わるようにする。

```
良い例:
  test_fetch_data_when_snowflake_down_returns_none
  test_process_empty_dataframe_no_index_error
  test_filter_multiple_conditions_returns_correct_count

悪い例:
  test_fetch_data  （条件・期待結果が不明）
  test_error_case  （何のエラーか不明）
```

### ③ アサーション具体性ルール

`assert result is not None` のような存在確認のみのアサーションを禁止し、型・値・件数を明示する。

```
禁止: assert result is not None            （存在のみ確認）
推奨: assert isinstance(result, pd.DataFrame)   （型を明示）
     assert len(result) == 0               （件数を明示）
     assert result["col"].dtype == "int64" （スキーマを明示）
     assert "error" not in result          （内容を明示）
```

### ④ 実コードインポート必須ルール

テストは必ず `app/` 配下の実装コードをインポートして呼び出すこと。
テスト内でビジネスロジックを再実装してはならない。

**例外: Layer 1（データ契約テスト）**
`tests/contracts/` 配下のスキーマ検証テストは、`data-contracts.json` の定義に基づいて
DataFrame の構造・型・NULLを検証するためのものであり、`app/` をインポートしない設計が正しい。
スキーマそのものを契約として検証することが目的のため、実コードの呼び出しは不要。

```
禁止パターン:
  # NG: テスト内で sum を直接実行（app/ のコードを呼んでいない）
  total = sum(transactions)
  assert total == expected_total

  # NG: 文字列定数を検証しているだけ
  error_class = "snowflake.connector.errors.ProgrammingError"
  assert "ProgrammingError" in error_class

  # NG: app/ をインポートしていない
  df = pd.DataFrame({"col": [1, 2, 3]})
  assert len(df) == 3

推奨パターン:
  # OK: app/ の実装をインポートして呼び出す
  from app.lib.data_loader import fetch_data
  result = fetch_data(conditions)
  assert isinstance(result, pd.DataFrame)

  # OK: Snowflake依存はモックして実コードのフローをテスト
  from app.reporting_function._reporting_page import get_data
  with patch("app.reporting_function._reporting_page.session") as mock_session:
      mock_session.query.return_value.filter.return_value.all.return_value = [...]
      result = get_data(conditions)
      assert isinstance(result, pd.DataFrame)
```

### ⑤ Snowflake/Streamlit依存のモック戦略

Snowflake・Streamlit に依存した実コードをテストする場合は、
依存部分をモックして実コードのフロー全体をカバーすること。

```
モック対象と推奨パターン:
  # Snowflake セッション
  with patch("app.XXX.session") as mock_session:
      mock_session.query.return_value...

  # pochilib 経由の接続
  with patch("pochilib.snowflake.get_connection", return_value=mock_conn):
      ...

  # SQLAlchemy クエリ結果
  with patch.object(Session, "query") as mock_query:
      mock_query.return_value.filter.return_value.all.return_value = [...]

  # Streamlit session_state
  import streamlit as st
  st.session_state["key"] = value  # AppTest 外では直接設定可能
```

#### @st.cache_data/@st.cache_resource の扱い（Layer 2 不可）

`@st.cache_data` / `@st.cache_resource` デコレータ付き関数は、pytest 環境では
`import` 自体は成功するが、**関数を呼び出した時点でStreamlitランタイムが必須となる**。
具体的には関数内部で `get_snowflake_sqlalchemy_session()` → `session.bind` アクセスが発生し、
Streamlitセッションコンテキストが存在しないためエラーになる。
`unittest.mock.patch` のみでは回避できないため、モック戦略の対象外。

これらの関数は **Layer 3（tests/integration/）に AppTest 経由でテストを配置**する:

```python
# tests/integration/test_{module_name}.py
# @st.cache_data付き関数は AppTest 経由でテスト。Snowflakeセッション取得をモック。
from streamlit.testing.v1 import AppTest
from unittest.mock import patch, MagicMock
import pandas as pd
from pathlib import Path

def test_cached_function_via_apptest():
    """キャッシュ付き関数を含むページが正常に動作することを確認"""
    app_file = str(Path(__file__).parent.parent.parent / "app" / "main.py")
    mock_session = MagicMock()
    mock_session.bind = MagicMock()
    with patch("app.lib.session_manager.snowflake_sqlalchemy.get_snowflake_sqlalchemy_session",
               return_value=mock_session):
        at = AppTest.from_file(app_file)
        at.run()
        assert not at.exception
```

**注意**: キャッシュのTTL・ヒット判定はStreamlitフレームワークの責務のため検証不要。
「関数が正常に実行され、期待する型・値を返す」ことのみを確認する。
モック対象パスはアプリごとに実際のSnowflakeセッション取得関数のパスに合わせること。

#### mock patch パスの正しい決定方法（必須）

テストコードに `patch("xxx.yyy.ZZZ")` を書く前に、以下を必ず実行すること：

1. **テスト対象モジュールの import 文を Read で確認する**
   - 例: `app/lib/address.py` を Read し、`from pochilib.snowflake import SnowflakeHandler` があることを確認
   - パッチパスは「テスト対象モジュールがインポートしている名前空間」に合わせる
   - 例: `from pochilib.snowflake import SnowflakeHandler` がある場合
     → `patch("app.lib.address.SnowflakeHandler")` が正しい（`"pochilib.snowflake.SnowflakeHandler"` は効かない）

2. **クラス名・関数名はソースコードで実在を確認してから書く**
   - テストに `from app.lib.models import MerchantStoreKey` と書く前に Grep で確認する
   - `Grep("class MerchantStoreKey", path="app/")` で実際の定義ファイルを特定する
   - `module-inventory.json` の `classes[].qualified_name` を参照して完全パスを確認する
   - **絶対に推測でクラス・関数のパスを書かない**

3. **conftest.py が `sys.path` に `app/` を追加している場合の必須ルール**
   - `conftest.py` に `sys.path.insert(0, ".../app")` がある場合、Python は `app/` 配下を `lib.*` として解決する
   - この場合、テストコードの import と patch は**必ず `lib.*` 形式**で統一する
   - テストコード例:
     ```python
     # ✅ 正しい: lib.* 形式
     from lib.merchant_keyword_search import create_map
     @patch("lib.merchant_keyword_search.get_merchant_store_list")

     # ❌ 間違い: app.lib.* 形式（パッチが当たらない）
     from app.lib.merchant_keyword_search import create_map
     @patch("app.lib.merchant_keyword_search.get_merchant_store_list")
     ```
   - `app.lib.*` と `lib.*` は Python の import システムでは**別の名前空間**として扱われる
     import を `app.lib.*` で行い patch を `lib.*` で行う（またはその逆）と、
     patch したつもりのモジュールが実際に使用されているモジュールと異なるため、
     Snowflake クエリ等が実際に実行されてしまう

## 完了メッセージ（T2完了時に表示）

```
✅ T2（pochi-tdd-workflow）完了
   - テストコードを生成しました
   - {app_path}/tests/contracts/   （Layer 1: データ契約テスト）
   - {app_path}/tests/unit/        （Layer 2: ロジックテスト）
   - {app_path}/tests/integration/ （Layer 3: 結合テスト）
   - {app_path}/tests/e2e/         （Layer 4: E2Eテスト）

📋 次は T3（pochi-test-strategy-auditor）で監査します...
```

## エラー時の対応

`tests/contracts/` が存在しない場合：
- T1 の完了を確認するよう促す
- tests/contracts/ がない状態では T2 を実行できない旨を報告する
