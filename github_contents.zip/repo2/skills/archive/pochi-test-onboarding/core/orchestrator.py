"""
pochi-test-onboarding のオーケストレーターモジュール

T0→T1→T4→T2→T3 の順次実行フローを管理する。
実際の実行は Claude Code の AI エージェントが行うため、
このモジュールはフロー定義とメッセージ生成のみを担当する。
"""

PHASE_ORDER = ["T0", "T1", "T4", "T2", "T3"]

PHASE_SKILL_MAP = {
    "T0": "pochi-legacy-analyzer",
    "T1": "pochi-contract-initializer",
    "T4": "pochi-fixtures-manager",
    "T2": "pochi-tdd-workflow",
    "T3": "pochi-test-strategy-auditor",
}

PHASE_PROMPT_MAP = {
    "T0": "prompts/_t0_legacy_analyzer.md",
    "T1": "prompts/_t1_contract_confirm.md",
    "T4": "prompts/_t4_fixtures_generate.md",
    "T2": "prompts/_t2_tdd_characterization.md",
    "T3": "prompts/_t3_auditor.md",
}

PHASE_DESCRIPTION = {
    "T0": "既存コード解析（pochi-legacy-analyzer）",
    "T1": "テスト契約初期化（pochi-contract-initializer）",
    "T4": "テストデータ生成（pochi-fixtures-manager）",
    "T2": "テストコード生成（pochi-tdd-workflow）",
    "T3": "テスト戦略監査（pochi-test-strategy-auditor）",
}


def get_execution_plan(app_path: str, entrypoint: str) -> str:
    """実行計画の表示文字列を生成する"""
    return f"""
【実行計画の確認】
- 対象アプリ: {app_path}
- エントリポイント: {entrypoint or "自動推定"}
- 実行フロー: T0 → T1 → T4 → T2 → T3

この設定で実行してよいですか？（はい/いいえ）
""".strip()


def get_completion_report(app_path: str, skipped: list = None) -> str:
    """最終完了レポートの表示文字列を生成する"""
    skipped = skipped or []
    skipped_note = ""
    if skipped:
        skipped_note = f"\n⚠️  スキップしたフェーズ: {', '.join(skipped)}\n"

    return f"""
✅ テスト基盤の一括導入が完了しました！
{skipped_note}
📂 生成された成果物:
  {app_path}/
  ├── output/
  │   ├── legacy-analysis.md              （T0: コード解析レポート）
  │   ├── draft-contracts/                （T0: contracts ドラフト）
  │   └── test-strategy-audit.md          （T3: 監査レポート）
  └── tests/                              （T2: テストコード）
      ├── contracts/                      （T1: テスト品質契約 6ファイル + データ契約テスト 30〜50%）
      │   ├── data-contracts.json
      │   ├── business-rules.json
      │   ├── test-viewpoints.json
      │   ├── scenarios.json
      │   ├── domain-rules.md
      │   └── risk-catalog.md
      ├── unit/                           → ロジックテスト（目標: 30〜50%）
      └── fixtures/                       → テストデータ（T4生成）

【次のアクション】
1. `tests/contracts/` を確認し、自動逆抽出の精度をレビューしてください
2. `tests/` のテストを実行し、PASSを確認してください（pytest {app_path}/tests/）
3. 不足しているテスト層は T2（pochi-tdd-workflow）で随時追加できます
4. 定期的に T3（pochi-test-strategy-auditor）でピラミッド比率を監査してください
""".strip()
