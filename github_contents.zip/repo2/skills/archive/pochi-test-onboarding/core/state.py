"""
pochi-test-onboarding の実行状態管理モジュール

各フェーズ（T0〜T3）の実行状態を追跡する。
"""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class OnboardingState:
    """テスト基盤一括導入の実行状態"""

    # 入力パラメータ
    app_path: str = ""
    entrypoint: str = ""

    # フェーズ完了状態
    t0_completed: bool = False
    t1_completed: bool = False
    t4_completed: bool = False
    t2_completed: bool = False
    t3_completed: bool = False

    # 生成ファイルパス
    draft_contracts_path: str = ""
    contracts_path: str = ""
    fixtures_path: str = ""
    tests_path: str = ""
    audit_report_path: str = ""

    # エラー情報
    errors: list = field(default_factory=list)
    skipped_phases: list = field(default_factory=list)

    def all_completed(self) -> bool:
        """全フェーズが完了しているか確認"""
        return (
            self.t0_completed
            and self.t1_completed
            and self.t4_completed
            and self.t2_completed
            and self.t3_completed
        )

    def next_phase(self) -> Optional[str]:
        """次に実行すべきフェーズを返す"""
        if not self.t0_completed:
            return "T0"
        if not self.t1_completed:
            return "T1"
        if not self.t4_completed:
            return "T4"
        if not self.t2_completed:
            return "T2"
        if not self.t3_completed:
            return "T3"
        return None
