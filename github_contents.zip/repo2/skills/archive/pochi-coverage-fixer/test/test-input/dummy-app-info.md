# テスト対象アプリ情報

## アプリパス

`/home/user/sample-pochi-app`

## 前提条件

- pochi-test-onboarding 実行済みのアプリを想定
- tests/ ディレクトリが存在する
- カバレッジが低い状態（例: 全体35%）

## 期待する動作

1. conftest.py の品質検証・自動修正
2. カバレッジ計測（pytest --cov）
3. 不足テストの生成
4. 再計測・レポート出力（tests/coverage-report.md）
