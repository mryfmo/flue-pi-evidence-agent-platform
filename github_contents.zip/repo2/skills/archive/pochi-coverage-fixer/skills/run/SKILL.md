---
name: pochi-coverage-fixer
description: >-
  テスト生成Skill実行後にカバレッジを向上させるスキル。
  conftest.py検証・自動修正 → カバレッジ計測 → 不足テスト自動生成 → 再計測 の4フェーズを実行し、
  実コードカバレッジ60%以上を目標とする。
  tdd-test-scaffolder / unit-test-generator / integration-test-generator の
  いずれの実行後でも使用可能。
  「カバレッジを改善して」「テストが通らない」「カバレッジが低いので修正」
  「pochi-coverage-fixerを起動」と言われたときに使用する。
---

# pochi-coverage-fixer

テスト生成Skill（`tdd-test-scaffolder` / `unit-test-generator` / `integration-test-generator`）実行後のカバレッジ向上スキル。
**conftest.py 検証・修正 → カバレッジ計測 → 不足テスト生成 → 再計測** の 4 フェーズで実コードカバレッジ 60% 以上を目指す。

## STEP 0: test-strategy-config.json の読み込み

前提確認の前に、プロジェクト固有のテスト設定を読み込む。

```
Glob で {app_path}/tests/.onboarding/test-strategy-config.json を検索する。
app_path が未確定の場合は、前提確認で特定後に読み込む。
```

**ファイルが存在する場合**:
→ `quality_targets.coverage_minimum` を読み込み、カバレッジ目標として使用する。
   （後述のフェーズ2・4 で「目標 60%」と記載している箇所を、この値で読み替える）

**ファイルが存在しない場合**:
→ デフォルト `coverage_minimum: 60` を使用する。

> 💡 カバレッジ目標をプロジェクトごとに変更したい場合は
> `{app_path}/tests/.onboarding/test-strategy-config.json` の
> `quality_targets.coverage_minimum` を編集してください。

---

## 前提確認

まず以下を確認する：

- 対象アプリのルートパス（`{app_path}`）を特定する
  - ユーザーから指定がない場合は Glob で `**/tests/conftest.py` を検索してルートを特定する
- `{app_path}/tests/` が存在するか Glob で確認する（存在しない場合は tdd-test-scaffolder または unit-test-generator を先に実行するよう案内する）
- `{app_path}/setup.cfg` が存在するか確認する（カバレッジ除外設定ファイル）

---

## フェーズ1: conftest.py 品質検証・差分修正

### 前提判定

`{app_path}/tests/.onboarding/coverage-gaps.json` が存在するか Glob で確認する：

- **存在する（pochi-test-coverage-analyzer 実行済み）** → F1-1（差分チェック）を実行
- **存在しない（通常ケース・常にこちら）** → F1-2（完全チェック）を実行

---

### F1-1: 差分チェック（coverage-gaps.json が存在する場合）

`pochi-test-coverage-analyzer` がすでに conftest.py を修正済みの前提で、残存エラーのみを確認する。

```bash
cd {app_path} && python -m pytest --collect-only --tb=line -q 2>&1 \
  | grep -E "ERROR|ModuleNotFoundError|is not a package|ImportError" | head -20
```

- エラー 0 件 → フェーズ 2 に進む
- エラーがある場合 → 残存モジュールを `_MOCK_MODULES` に追加して再実行する（最大 3 サイクル）
- 3サイクル後もエラーが残る場合はエラー内容を報告しフェーズ 2 に進む

---

### F1-2: 完全チェック（通常ケース）

`coverage-gaps.json` が存在しない場合（現状は常にこちら）、以下の完全チェックと修正を実行する。

#### 1-2-1. テスト収集エラーの検出

```bash
cd {app_path} && python -m pytest --collect-only --tb=line -q 2>&1 \
  | grep -E "ERROR|ModuleNotFoundError|is not a package|ImportError" | head -20
```

エラー 0 件であれば 1-2-3 に進む。

#### 1-2-2. エラーの分類と修正

エラーが検出された場合、以下を繰り返す（エラーが 0 件になるまで）：

| エラーパターン | 修正内容 |
|---|---|
| `ModuleNotFoundError: No module named 'xxx'` | `tests/conftest.py` の `_MOCK_MODULES` に `"xxx"` とその親モジュールを追加 |
| `'xxx' is not a package` | `sys.modules` に親モジュールを先に登録する（子モジュールより前に追加） |
| `streamlit.runtime.*` 系のエラー | 以下を全て追加: `"streamlit.runtime"`, `"streamlit.runtime.scriptrunner"`, `"streamlit.runtime.scriptrunner.script_runner"`, `"streamlit.runtime.state"`, `"streamlit.runtime.state.session_state"`, `"streamlit.components"`, `"streamlit.components.v1"`, `"streamlit.delta_generator"` |
| `ImportError: cannot import name 'Yyy' from 'lib.zzz'` | Grep でクラス・関数の正しい定義ファイルを特定して import パスを修正する |

修正後、1-2-1 を再実行してエラーが消えたことを確認する。

#### 1-2-3. conftest.py 品質チェック（4項目）

`{app_path}/tests/conftest.py` を Read し、以下を確認する：

**① `st.cache_data` / `st.cache_resource` 透過デコレータ**

`MagicMock()` のままだとデコレータが元の関数を消してカバレッジ計測不能になる。
以下の行（または同等のコード）が存在するか確認する：

```python
def _passthrough_decorator(func=None, **kwargs):
    if func is not None:
        return func
    return lambda f: f
sys.modules["streamlit"].cache_data = _passthrough_decorator
sys.modules["streamlit"].cache_resource = _passthrough_decorator
```

存在しない場合、`_MOCK_MODULES` 登録処理の直後に追加する。

**② `sys.path` に `app/` を追加**

以下の形式（またはパス指定は異なっても同等）が存在するか確認する：

```python
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))
```

存在しない場合、conftest.py の先頭（`sys.modules` 設定ブロックの前）に追加する。

**③ streamlit サブモジュールの個別登録**

`streamlit.runtime.state.session_state` など深いサブモジュールが `_MOCK_MODULES` に含まれているか確認する。
不足している場合は 1-2-2 のリストを参照して追加する。

**④ コアモジュールのプリロード**

`pytest --cov` は「テスト実行中に import されたファイル」しか計測しない。
テストが import していないコアモジュールを計測対象に含めるため、以下のようなプリロードブロックが必要：

```python
_PRELOAD_MODULES = [
    "lib.graph_visualizer",
    "lib.merchant_map",
    "lib.data_loader",
    # ... アプリのコアモジュールを列挙
]
for _mod in _PRELOAD_MODULES:
    try:
        __import__(_mod)
    except Exception:
        pass
```

存在しない場合、アプリの `app/` 配下を Glob でスキャンしてコアモジュールを特定し、プリロードブロックを追加する。

---

## フェーズ2: カバレッジ計測・低カバレッジモジュール特定

### 2-0. coverage-gaps.json の確認（T3連携）

> ⚠️ **注意**: `coverage-gaps.json` を生成する `pochi-test-coverage-analyzer`（T3）は現時点では未実装のスキルです。
> このため、`coverage-gaps.json` が存在する場合の分岐は将来実装予定のスキルに向けた拡張ポイントとして維持しています。
> 現状では `coverage-gaps.json` は常に存在しないため、以下の分岐は実質的にフル計測（2-1〜2-3）が常に実行されます。

`coverage-gaps.json` が存在するか Glob で確認する：

**ファイルが存在する場合（pochi-test-coverage-analyzer 実行済み）**:
- `{app_path}/tests/.onboarding/coverage-gaps.json` を Read する
- `gaps[]` から `priority: "high"` および `priority: "medium"` のモジュールを抽出する
- これらを `実装コードの調査対象リスト` として使用し、**2-1〜2-3をスキップして直接フェーズ 3 に進む**
- T3 の計測値をそのまま表示する：
  ```
  📊 T3計測済みカバレッジ: {total_coverage}%（再計測スキップ）
  高優先度対象: {priorityがhighのモジュール一覧}
  中優先度対象: {priorityがmediumのモジュール一覧}
  ```

**ファイルが存在しない場合（T3未実行）**:
- 従来通り 2-1（pytest --cov 実行）から開始する

---

### 2-1. pytest --cov 実行

> ⚠️ **絶対禁止**: `app/` 配下への書き込みは一切禁止。
> `--cov-report=annotate` は `*.py,cover` ファイルをソースコードと同じディレクトリに生成するため**絶対に使用しない**こと。
> レポートは必ず `term`（標準出力）のみを指定すること。

`setup.cfg` が存在する場合：

```bash
cd {app_path} && python -m pytest tests/ --cov=app --cov-config=setup.cfg --cov-report=term -q 2>&1 | tail -40
```

`setup.cfg` が存在しない場合：

```bash
cd {app_path} && python -m pytest tests/ --cov=app --cov-report=term -q 2>&1 | tail -40
```

### 2-2. 出力の分析

出力から各モジュールの `Stmts / Miss / Cover%` と TOTAL 行を抽出し、以下の表を作成する：

```
全体カバレッジ: {total_cov}%（目標: {coverage_minimum}%以上）

| モジュール | Stmts | Miss | Cover% | 判定 |
|:---|---:|---:|---:|:---:|
| app/xxx.py | 100 | 80 | 20% | 🔴 |
| app/yyy.py | 50  | 20 | 60% | ✅ |

判定基準:
- ✅ 良好: 60%以上
- 🟡 要改善: 30〜59%
- 🔴 不足: 30%未満
```

### 2-3. 優先対象の特定

以下の基準で「追加テスト優先対象」を選定する：

1. Cover% が 40% 未満 かつ Stmts が 50 以上（効果大・規模大）
2. Cover% が 40% 未満 かつ Stmts が 20〜49（効果中）
3. Streamlit UI 主体（`_reporting_page.py` 等）は ROI が低いため後回し

選定した対象モジュールを `実装コードの調査対象リスト` として記録してフェーズ3に渡す。

---

## フェーズ3: 不足テスト生成・既存テスト修正

### 3-1. patchパス不整合の修正（最優先）

既存テストに `app.lib.*` 形式のパッチや import が存在する場合、カバレッジに計上されない。

```bash
grep -rn '@patch("app\.lib\.' {app_path}/tests/
grep -rn 'from app\.lib\.' {app_path}/tests/
grep -rn 'import app\.lib\.' {app_path}/tests/
```

発見した場合は `lib.*` 形式に修正する。

**conftest.py が `sys.path` に `app/` を追加している場合のルール**：
- Python は `app/` 配下を `lib.*` として解決する
- `app.lib.*` と `lib.*` は別の名前空間 — `@patch("app.lib.XXX")` は `lib.XXX` に効かない
- import も patch も **必ず `lib.*` 形式**で統一する

### 3-2. 優先対象モジュールへのテスト追加

フェーズ 2 で特定した各モジュールについて以下を実行する：

#### a) 対象モジュールの調査

```python
# 対象ファイルを Read して以下を特定する：
# - 純粋関数（Snowflake / Streamlit 非依存）
# - Snowflake 依存関数（@patch でモック可能か確認）
# - @st.cache_data / @st.cache_resource 付き関数（Layer 3 送り）
# - Streamlit UI 関数（テスト困難 — 後回し）
```

#### b) テストを生成する

**純粋関数（優先度 高）**：
直接 import して戻り値の型・値・件数を assert する。

```python
from lib.{module_name} import {function_name}

def test_{function_name}_{condition}_{expected}():
    result = {function_name}(...)
    assert isinstance(result, pd.DataFrame)
    assert len(result) == 0
```

**Snowflake 依存関数（優先度 中）**：
`@patch` でクエリ結果をモックしてフロー全体をカバーする。

```python
@patch("lib.{module_name}.{snowflake_function}")
def test_{function_name}_with_mock_data(mock_sf):
    mock_sf.return_value = pd.DataFrame({"col": [1, 2, 3]})
    result = {function_name}(conditions)
    assert isinstance(result, pd.DataFrame)
```

patchパスは「テスト対象モジュールでバインドされた名前」を指定する（`lib.{module_name}.{name}` 形式）。

**`@st.cache_data` / `@st.cache_resource` 付き関数（Layer 3）**：
`tests/integration/` に AppTest 経由のテストを配置する（Layer 2 に配置しない）。

#### c) テストファイルの配置

| テストの種類 | 配置先 |
|---|---|
| 純粋関数・モック可能な依存関数 | `{app_path}/tests/unit/test_{module_name}_unit.py` |
| `@st.cache_data` 付き関数 | `{app_path}/tests/integration/test_{module_name}_integration.py` |

#### d) 生成後のセルフチェック

生成したテストファイルごとに以下を確認する：

- `@patch("app.lib.XXX")` 形式が含まれていないか
- import が `lib.*` 形式になっているか
- assert が型・値・件数を具体的に確認しているか（`assert result is not None` のみの禁止）

#### e) Layer 3/4 のフレームワーク選択ガイド

テストを生成する際、以下のレイヤ定義を厳守すること：

| Layer | フレームワーク | 適用条件 |
|---|---|---|
| Layer 3 | **AppTest** | `@st.cache_data`/`@st.cache_resource`付き関数、Streamlit session_state 使用 |
| Layer 4 | **Playwright** | 実ブラウザ操作、マルチページ遷移、ファイルDL等 |

**既存 Layer 4 テストが AppTest で書かれている場合**:
`tests/e2e/` 配下を Grep して `AppTest` の使用を確認し、発見した場合は移行提案を返答に記載する（自動修正は行わない）：
```
⚠️ Layer 4（tests/e2e/）に AppTest が使用されています。
   Playwright への移行を推奨します：
   - {test_file}::{test_function}
   → ブラウザE2Eには Playwright（pytest-playwright）を使用してください。
     AppTest は Layer 3（Streamlitコンポーネント結合）に適切です。
```

---

## フェーズ4: 再計測・レポート出力

### 4-1. pytest --cov 再実行

フェーズ 2 と同じコマンドで再計測する。

### 4-2. 改善確認

フェーズ 2 の結果と比較して改善量を確認する：

```
改善前: {old_cov}%
改善後: {new_cov}%
改善量: +{diff}%
```

目標 {coverage_minimum}%（STEP 0 で読み込んだ値、デフォルト 60%）未達の場合、フェーズ 3 に戻って追加テストを生成する（最大 3 サイクル）。

### 4-3. coverage-report.md の出力

`{app_path}/tests/coverage-report.md` に以下の内容で出力する：

```markdown
# カバレッジ改善レポート

実行日: {date}

## 最終結果

全体カバレッジ: {final_cov}%（目標: {coverage_minimum}%以上）

## 改善履歴

| フェーズ | カバレッジ | 主な作業内容 |
|---|---|---|
| 開始時 | {initial_cov}% | テスト生成Skill実行直後 |
| F1完了 | {after_f1_cov}% | conftest.py 修正 |
| F3完了 | {after_f3_cov}% | 不足テスト追加 |
| F4完了 | {final_cov}% | 再計測 |

## モジュール別カバレッジ（最終）

| モジュール | Stmts | Miss | Cover% | 判定 |
|:---|---:|---:|---:|:---:|
...

## 残課題

カバレッジ 60% 未達のモジュール（Streamlit UI 主体など ROI が低いもの）：
...
```

---

## 完了メッセージ

```
✅ pochi-coverage-fixer 完了

📈 カバレッジ改善結果:
   開始時: {initial_cov}%
   最終:   {final_cov}%  / 目標: {coverage_minimum}%以上（test-strategy-config.json より）

📋 実行サマリー:
   F1: conftest.py 検証（{T3実行済みの場合は「差分チェック」、未実行の場合は「完全チェック」}、{f1_fixes}件対応）
   F3: テスト追加（{added_tests}件のテスト関数を追加）

📄 詳細レポート: {app_path}/tests/coverage-report.md

🔗 関連ファイル:
   - T3カバレッジデータ: {app_path}/tests/.onboarding/coverage-gaps.json（T3実行済みの場合）
```

---

## test-progress.json の更新

完了メッセージ出力後、進捗ファイルを更新する。

```
{app_path}/tests/.onboarding/test-progress.json を Read する（存在する場合）。
```

**ファイルが存在する場合**:
→ `pochi-coverage-fixer` のステップを `completed` に更新し、
  `outputs` と `summary` を記入して書き戻す。
→ `coverage` の値を最終計測値に更新する。

**ファイルが存在しない場合**:
→ 新規作成は行わない。coverage-fixer は単独で実行されることが多く、
  `test-progress.json` の作成責務は上流スキル（unit-test-generator / tdd-test-scaffolder）が担う。

---

## 注意事項

- **`app/` 配下へのファイル追加・修正は絶対禁止**
  - `*.py,cover`（`--cov-report=annotate` の出力）はソースコードと同じディレクトリに生成されるため、`--cov-report=annotate` は絶対に使用しない
  - `coverage annotate` コマンドも同様に禁止
  - `app/` 配下に書き込んでよいのは `tests/` 以下のテストファイル・設定ファイルのみ
  - カバレッジレポートの出力先は `{app_path}/tests/coverage-report.md` のみ（`app/` 直下は禁止）
- **patchパスは「使用側モジュールでバインドされた名前」に合わせる**
  - `from lib.X import func` → `@patch("lib.X.func")`（`lib.X` が使用側）
  - `from lib.Y import func; func(...)` → `@patch("lib.Y.func")`
- **`app.lib.*` と `lib.*` は別の名前空間** — conftest.py が `sys.path` に `app/` を追加している場合、常に `lib.*` を使う
- **`graph_visualizer.py` の `__` 接頭辞関数** は Python の name-mangling で外部からアクセス不可 — 公開ラッパー関数経由でテストする
- **空リストを渡すと range(0,0,0) エラーになるプロダクションバグ** が存在する場合があるため、空入力テストは慎重に設計する
- **Streamlit UI が複雑すぎるファイル**（`_reporting_page.py` 等）は ROI が低いため対象外でもよい
