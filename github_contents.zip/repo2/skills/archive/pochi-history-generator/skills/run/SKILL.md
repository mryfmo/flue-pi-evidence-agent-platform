---
skill_id: pochi-history-generator
id: pochi-history-generator
title: Pochi History Generator
name: Pochi History Generator
version: 1.0.0
description: GitHubイシュー履歴から時系列形式のアプリ開発履歴を自動生成する際に使用。ユーザーが「アプリの歴史を生成して」「開発履歴を作成」などと依頼した時に起動する。
entrypoint:
  type: prompt
  path: prompts/generate_app_history.md
triggers:
  - アプリの歴史を生成して
  - アプリの歴史を作成して
  - 開発履歴を作成
  - 開発履歴を生成
  - app historyを生成
  - app historyを作成
  - プロジェクトの歴史を作成
  - プロジェクトの歴史を生成
  - アプリ開発の歴史を作成
  - アプリ開発の歴史を生成
  - 開発の歴史を生成
  - 開発の歴史を作成
  - pochi-history-generator を起動
  - Skillツールを使用して pochi-history-generator を起動してください
  - history generation
  - app history作成
---

> [!CAUTION]
> **このスキルは廃止・使用禁止です。**
> 起動した場合でも**何も実行せずに即座に終了してください。**
> 後継スキル: `pochi-baseline-builder` — 「ベースライン仕様書を作成して」で起動

**このスキルは使用禁止です。絶対に実行しないでください。**

後継スキル **`pochi-baseline-builder` — 「ベースライン仕様書を作成して」で起動** を使用してください。


# Skill: Pochi History Generator

**このSkillは、GitHubイシュー履歴から時系列形式のアプリ開発履歴を自動生成します。**

## Trigger Phrases

### パターンA: リポジトリ名なし（Claudeが質問）
- アプリの歴史を生成して
- アプリの歴史を作成して
- 開発履歴を作成
- 開発履歴を生成
- app historyを生成
- app historyを作成
- プロジェクトの歴史を作成
- プロジェクトの歴史を生成

### パターンB: リポジトリ名を含む（自動検出）
- {repository}のアプリの歴史を生成して
- {owner/repository}の開発履歴を作成
- {repo-name}のapp historyを生成

例:
- pochi-app-repoのアプリの歴史を生成して
- nttdocomo-com/pochi-app-repoの開発履歴を作成
- my-repoのapp historyを作成

### 汎用トリガー
- アプリ開発の歴史を作成
- アプリ開発の歴史を生成
- 開発の歴史を生成
- 開発の歴史を作成
- history generation
- app history作成
- pochi-history-generator を起動
- Skillツールを使用して pochi-history-generator を起動してください

## When

### 起動条件
- 上記Trigger Phrasesのいずれかが発話された
- リポジトリ名が指定されている（トリガーワードに含まれる、または後で質問）
- （オプション）ツール③でADR・baseline_specが生成済み

### 前提条件

#### リポジトリ名の指定
以下のいずれかの方法でリポジトリ名を指定します：

1. **トリガーワードに含める**（推奨）
   - 例: 「pochi-app-repoのアプリの歴史を生成して」
   - 例: 「nttdocomo-com/my-repoの開発履歴を作成」

2. **環境変数で指定**
   - `GITHUB_REPOSITORY=owner/repository`

3. **実行時に質問に答える**
   - トリガーワード: 「アプリの歴史を生成して」
   - → Claudeが質問: 「リポジトリ名を教えてください」
   - → ユーザー回答: 「nttdocomo-com/pochi-app-repo」

#### イシューデータ
以下のいずれかの状態である必要があります：

**パターン1: 既存CSVファイルを使用**
- `spec-driven-development/output/issues_detail.csv` が存在
- `spec-driven-development/output/issues_comments.csv` が存在
- `spec-driven-development/output/issues_events.csv` が存在

**パターン2: GitHubから自動取得**（🆕 v1.0.0）
- 上記CSVファイルが存在しない場合、**自動的にGitHub APIから取得**
- `gh` CLIでGitHub認証済みである必要あり
- **進捗表示**: パーセンテージ、残り時間推定を表示
- **Rate Limit対策**: 自動リトライ、待機時間表示を実装
- **500件以上のイシュー対応**: 効率的な取得・進捗表示

#### ADR・baseline_spec（必須）
**自動生成機能**（🆕 v1.0.0）:
- ADR・baseline_specが存在しない場合、**自動的にツール③（pochi-baseline-detailed）を実行**
- **確認なし**で自動実行されます
- 生成失敗時はエラーで終了します

**必須ファイル**:
- `spec-driven-development/output/architecture_decision_record.md` - ADR完成版（必須）
- `spec-driven-development/output/baseline_spec.md` - baseline_spec完成版（必須）
- 存在しない場合は、自動的に生成を試みます
- 自動生成に失敗した場合は、手動で「既存アプリのベースライン仕様書を作成」とClaude Codeに指示してください

#### 推奨ファイル
- `spec-driven-development/output/app_info.json` - アプリケーション情報
- `spec-driven-development/output/baseline_spec_config.json` - イシュー分類結果

### 起動しない条件（誤起動防止）
以下のような曖昧な表現では起動しないでください：
- ❌ 「履歴を作って」（何の履歴か不明）
- ❌ 「ドキュメント作成」（ドキュメントの種類が不明）
- ❌ 「イシューを見て」（閲覧のみ）
- ❌ 「確認して」

明確に「アプリの歴史」「開発履歴」「app history」などのキーワードが含まれる必要があります。

## Do

**単一コマンドでSkillを起動します：**

### Linux/Mac環境
```bash
POCHI_SKILL_ACTIVE=1 python /home/user/pochi-dp-developer-docs/skills/pochi-history-generator/skill_entry.py
```

### Windows環境

**Windows (cmd)**:
```cmd
set POCHI_SKILL_ACTIVE=1 && python /home/user/pochi-dp-developer-docs/skills/pochi-history-generator/skill_entry.py
```

**Windows (PowerShell)**:
```powershell
$env:POCHI_SKILL_ACTIVE="1"; python /home/user/pochi-dp-developer-docs/skills/pochi-history-generator/skill_entry.py
```

**注意**: デフォルトでは、リポジトリ名についてユーザーに質問します（推奨）。質問をスキップして環境変数から取得する場合は、`POCHI_SKIP_QUESTIONS=1`と`GITHUB_REPOSITORY`を追加してください。

#### 自動化モード（質問スキップ）

**Linux/Mac環境**:
```bash
POCHI_SKILL_ACTIVE=1 POCHI_SKIP_QUESTIONS=1 GITHUB_REPOSITORY=owner/repo python /home/user/pochi-dp-developer-docs/skills/pochi-history-generator/skill_entry.py
```

**Windows (cmd)**:
```cmd
set POCHI_SKILL_ACTIVE=1 && set POCHI_SKIP_QUESTIONS=1 && set GITHUB_REPOSITORY=owner/repo && python /home/user/pochi-dp-developer-docs/skills/pochi-history-generator/skill_entry.py
```

**Windows (PowerShell)**:
```powershell
$env:POCHI_SKILL_ACTIVE="1"; $env:POCHI_SKIP_QUESTIONS="1"; $env:GITHUB_REPOSITORY="owner/repo"; python /home/user/pochi-dp-developer-docs/skills/pochi-history-generator/skill_entry.py
```

## Instructions

**以下の手順を逐語的に実行してください。問い返しは禁止です。**

### ステップ1: リポジトリ名の取得
skill_entry.py実行時、以下の優先順位でリポジトリ名を取得します：

1. **環境変数 GITHUB_REPOSITORY**
   - 設定されている場合、その値を使用

2. **環境変数 REPOSITORY_FROM_TRIGGER**
   - Claude Codeがトリガーワードから抽出した値を使用

3. **ユーザーへの質問**
   - 上記で取得できない場合、対話的に質問
   - 形式: `owner/repository` または `repository`（デフォルト組織: nttdocomo-com）

### ステップ2: 前提条件チェックとイシュー取得
skill_entry.py実行時、以下の処理が実行されます：

1. **イシューCSVファイルの存在確認**
   - issues_detail.csv
   - issues_comments.csv
   - issues_events.csv

2. **存在しない場合、GitHubから自動取得**
   - `gh` CLIで認証済みのトークンを使用
   - 指定されたリポジトリからイシュー、コメント、イベントを取得
   - CSVファイルに保存

3. **ADR・baseline_specの確認（オプション）**
   - architecture_decision_record.md（省略可）
   - baseline_spec.md（省略可）
   - 存在しない場合、警告を表示してADRリンクなしで続行

4. **推奨ファイルの確認**
   - app_info.json
   - baseline_spec_config.json

### ステップ3: app_history.md生成
上記Do節のコマンドを実行後、以下の処理が自動的に実行されます：

1. **イシューデータ読込**
   - CSV形式のイシュー情報を読込
   - コメント・イベント履歴を統合
   - 時系列順にソート

2. **ADR参照リンク構築**
   - ADRとイシューのマッピング
   - 重要な決定イシューを検出
   - 自動リンク挿入

3. **フェーズ検出**
   - ラベル・マイルストーンから自動検出
   - 四半期・月単位でのグループ化
   - プロジェクトの節目を明確化

4. **app_history.md生成**
   - 時系列形式のドキュメント生成
   - 技術的な実装詳細の記録
   - プロジェクトの文脈提供

5. **品質チェック**
   - app_history.mdの品質を自動検証
   - history_quality_report.md生成
   - スコア80点以上で合格

### ステップ3: 生成結果の確認
skill_entry.py完了後、以下のファイルが生成されます：

```
spec-driven-development/output/
├── app_history.md                    # アプリ開発の歴史（完成版）
└── history_quality_report.md         # 品質検証レポート
```

### ステップ4: 品質レポートの確認
`spec-driven-development/output/history_quality_report.md`を開き、以下を確認してください：

- **総合スコア**: 80点以上で合格
- **時系列の正確性**: 日付順に正しく整理されているか
- **ADR参照の正確性**: 重要な決定にADRリンクが設定されているか
- **フェーズ分類**: 適切にフェーズ・期間が分類されているか
- **実装詳細の記述**: 技術的な実装内容が具体的に記載されているか
- **読みやすさ**: 新規参加者が理解しやすい文章か

### ステップ5: 完了確認
品質チェック合格（スコア80点以上）で、アプリ開発の歴史生成が完了です。

## Don't

### 実行禁止事項
- ❌ **環境変数なしでの直接実行は禁止**
  - セキュリティガードにより実行が拒否されます

- ❌ **問い返しは禁止**
  - 必要な情報はすべて既存ファイルから取得します
  - すべて自動処理

### 自動化されている事項（v1.0.0）
- ✅ **ADR・baseline_spec生成**: 存在しない場合、自動的にツール③を実行
- ✅ **イシューデータ取得**: 存在しない場合、自動的にGitHub APIから取得
- ✅ **リポジトリ名取得**: トリガーワードから自動抽出、または実行時に質問

### 品質基準の遵守
app_history.mdの品質基準：

| 項目 | 基準 | 配点 |
|-----|------|------|
| ✅ **時系列の正確性** | 日付順に正しく整理されている | 20点 |
| ✅ **ADR参照の正確性** | 重要な決定にADRリンクが設定されている | 20点 |
| ✅ **フェーズ分類** | 適切にフェーズ・期間が分類されている | 15点 |
| ✅ **実装詳細の記述** | 技術的な実装内容が具体的に記載されている | 15点 |
| ✅ **読みやすさ** | 新規参加者が理解しやすい文章 | 15点 |
| ✅ **網羅性** | 全イシューが記録されている | 10点 |
| ✅ **構造の一貫性** | セクション構成が統一されている | 5点 |

**合格基準**: 80点以上

## Inputs

### 必須入力
- **GitHubイシュー履歴**: CSV形式（issues_detail.csv, issues_comments.csv, issues_events.csv）
- **ADR（完成版）**: architecture_decision_record.md
- **baseline_spec（完成版）**: baseline_spec.md

### オプション入力
- **アプリ情報**: app_info.json
- **イシュー分類結果**: baseline_spec_config.json

### 自動取得される情報
- イシューの時系列順
- フェーズ・マイルストーン情報
- ADRとイシューのマッピング
- 技術的な実装詳細

## Outputs

### 主要成果物
- `app_history.md`
  - アプリ開発の歴史（完成版）
  - 時系列形式
  - ADR参照リンク付き
  - フェーズ別グループ化

### レポート
- `history_quality_report.md`: 品質検証レポート

## 実行フロー

```mermaid
graph TD
    A[Skill起動] --> B[前提条件チェック]
    B --> C{必須ファイル存在?}
    C -->|No| D[エラー: 前提条件未満足]
    C -->|Yes| E[イシューデータ読込]
    E --> F[時系列整理]
    F --> G[フェーズ検出]
    G --> H[ADR参照リンク構築]
    H --> I[app_history.md生成]
    I --> J[品質チェック]
    J --> K{スコア80点以上?}
    K -->|Yes| L[完了]
    K -->|No| M[要改善]
```

## ドキュメントの役割分担

### app_history.md（ツール⑦で生成）
- **目的**: 開発の経緯を時系列で記録
- **内容**: 「いつ、何が起きたか」
  - 時系列での開発経緯
  - フェーズ・マイルストーン
  - イシューの実装内容
  - ADRへの参照リンク
- **読者**: 新規参加者、プロジェクトマネージャー

### architecture_decision_record.md（ツール③で生成）
- **目的**: 重要な決定を記録
- **内容**: 「なぜ、どのように決定したか」
  - 重要な決定の背景・理由
  - 検討した選択肢
  - 決定の影響
  - 実装結果
- **読者**: 開発者、アーキテクト

### baseline_spec.md（ツール③で生成）
- **目的**: 現在の実装仕様を記述
- **内容**: 「現在、どう実装されているか」
  - 現在の機能仕様
  - 技術スタック
  - データモデル
  - UI/UX仕様
- **読者**: 開発者

## Troubleshooting

### Skillが起動しない場合

#### 1. SKILL.mdの配置を確認
```bash
# プロジェクトルートで以下が見えるか確認
ls -la skills/pochi-history-generator/
```

**期待される状態**:
```
プロジェクトルート/
└── skills/
    └── pochi-history-generator/
        ├── SKILL.md              # このファイル
        ├── skill_entry.py        # メインエントリ
        ├── core/                 # コアモジュール
        ├── prompts/              # プロンプトテンプレート
        └── README.md
```

#### 2. トリガーワードを確認
- ✅ 「アプリの歴史を生成して」（推奨）
- ✅ 「pochi-history-generator を起動」（明示的）
- ✅ 「開発履歴を作成」
- ❌ 「履歴を作って」（曖昧）

### 実行エラーが発生する場合

#### エラー: 「Skills専用モードでのみ実行可能」
**原因**: 環境変数が設定されていない
**解決**: Claude Code経由で起動（自動で環境変数が設定されます）

#### エラー: 「前提条件ファイルが見つかりません」
**原因**: ツール③が未実行、または必須ファイルが不足
**解決**:
```bash
# ツール③を実行
# 「既存アプリのベースライン仕様書を作成」とClaude Codeに指示

# または手動で前提条件を準備
python pochi-history-generator/run_baseline_workflow.py --repo リポジトリ名
```

#### エラー: 「ADRファイルが見つかりません」
**原因**: architecture_decision_record.md（完成版）が存在しない
**解決**: ツール③でADRを生成してください

#### 品質チェック不合格（スコア80点未満）
**原因**: app_history.mdの品質に問題あり
**解決**:
1. `history_quality_report.md`を確認
2. 問題点を特定
3. 必要に応じてイシューデータを補完
4. 再実行

## 安全対策

### Skills専用モード
- **環境変数チェック**: `POCHI_SKILL_ACTIVE=1`が必須
- **直接実行の防止**: セキュリティリスク低減

### データ保護
- イシューデータはローカルのみ保存
- 外部APIへのデータ送信なし

### プライバシー
- イシュー内の機密情報は手動で確認
- app_history.md公開前に内容を確認

## 既存ツールとの関係

### ツール③（pochi-baseline-detailed）との関係

**従来（ツール③のみ）**:
```
ツール③
  ├─ ADR骨格版生成
  ├─ baseline_spec骨格版生成
  └─ 時系列サマリー（ADR内に統合）
```

**新構成（ツール③ + ツール⑦）**:
```
ツール③
  ├─ ADR骨格版生成（重要な決定の記録）
  └─ baseline_spec骨格版生成（現在の仕様）

ツール⑦（新規）
  └─ app_history.md生成（時系列の歴史記録）
```

### ワークフロー統合
```
Phase 1: ベースライン仕様書の作成
  ↓
ツール③実行
  ├─ GitHubイシュー取得
  ├─ ADR候補分類
  ├─ ADR骨格版生成
  └─ baseline_spec骨格版生成
  ↓
ツール⑦実行（新規）
  ├─ ADR（完成版）参照
  ├─ baseline_spec（完成版）参照
  └─ app_history.md生成
  ↓
完成
```

## 使用例

### 例1: 初回実行
```
ユーザー: 「アプリの歴史を生成して」

実行フロー:
1. skill_entry.py起動
2. 前提条件チェック: OK
3. イシュー読込: 50件
4. フェーズ検出: 3フェーズ（立ち上げ、機能拡張、UI刷新）
5. ADRリンク挿入: 5件
6. app_history.md生成完了
7. 品質チェック: 85点（合格）
8. 完了
```

### 例2: 大規模プロジェクト
```
ユーザー: 「開発履歴を作成」

実行フロー:
1. イシュー読込: 500件
2. フェーズ検出: 8フェーズ（2年間）
3. ADRリンク挿入: 50件
4. 技術スタック変遷: 3回
5. app_history.md生成（大規模）
6. 品質チェック: 82点（合格）
7. 完了
```

## バージョン・ライセンス

- **バージョン**: 1.0.0
- **作成者**: Pochi Development Team
- **ライセンス**: Internal Use Only

## 変更履歴

### v1.0.0 (2026-01-26)

**新機能**:
1. **トリガーワードからリポジトリ名自動抽出**
   - 「{repository}のアプリの歴史を生成して」からリポジトリ名を自動認識
   - GitHub API直接アクセス（ローカルリポジトリ探索を削除）

2. **ADR・baseline_spec自動生成機能**
   - ADR・baseline_specが存在しない場合、自動的にツール③を実行
   - 確認なしで自動実行（完全自動化）
   - 生成失敗時も続行可能

3. **500件以上のイシュー対策（基本対策版）**
   - **進捗表示改善**: パーセンテージ、残り時間推定を表示
   - **Rate Limit対策強化**: 自動リトライ、待機時間表示
   - **総イシュー数の事前取得**: ユーザーに見通しを提供
   - **所要時間表示**: 取得完了時に所要時間を表示

**改善項目**:
- イシュー取得のsleep時間を0.1秒→0.2秒に延長（Rate Limit対策）
- コメント・イベント取得の進捗表示を10件ごと→5%ごとに改善
- Rate Limit到達時の自動リトライ機能を追加
- エラーハンドリングを強化

## 参照ドキュメント

- [README.md](./README.md): 概要とクイックスタート
- [tool-plan/アプリ開発の歴史生成ツール開発計画.md](../../tool-plan/アプリ開発の歴史生成ツール開発計画.md): 開発計画
- [ツール③: pochi-baseline-detailed](../pochi-baseline-detailed/README.md): 前提ツール

---

**🚀 このSkillを起動するには、「アプリの歴史を生成して」とClaude Codeに指示してください。**
