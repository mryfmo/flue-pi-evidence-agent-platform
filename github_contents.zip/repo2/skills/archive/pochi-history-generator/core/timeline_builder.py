"""
Timeline Builder Module

イシューを時系列順に整理し、フェーズでグループ化するモジュール
"""

from typing import Dict, List
from datetime import datetime
from collections import defaultdict


class TimelineBuilder:
    """タイムラインを構築するクラス"""

    def __init__(self, issues: List[Dict], phase_detector):
        """
        Args:
            issues: イシュー情報のリスト
            phase_detector: PhaseDetectorのインスタンス
        """
        self.issues = issues
        self.phase_detector = phase_detector

    def sort_by_created_date(self) -> List[Dict]:
        """
        イシューを作成日時順にソート

        Returns:
            ソート済みイシューリスト
        """
        return sorted(
            self.issues,
            key=lambda x: x.get('created_at_dt') or datetime.min
        )

    def group_by_year_month(self) -> Dict[str, List[Dict]]:
        """
        イシューを年月でグループ化

        Returns:
            年月をキーとした辞書
        """
        grouped = defaultdict(list)

        for issue in self.issues:
            created_at = issue.get('created_at_dt')
            if created_at:
                year_month = created_at.strftime('%Y年%m月')
                grouped[year_month].append(issue)

        return dict(grouped)

    def group_by_quarter(self) -> Dict[str, List[Dict]]:
        """
        イシューを四半期でグループ化

        Returns:
            四半期をキーとした辞書
        """
        grouped = defaultdict(list)

        for issue in self.issues:
            created_at = issue.get('created_at_dt')
            if created_at:
                year = created_at.year
                quarter = (created_at.month - 1) // 3 + 1
                key = f'{year}年Q{quarter}'
                grouped[key].append(issue)

        return dict(grouped)

    def build_timeline(self) -> Dict[str, Dict]:
        """
        フェーズ別・年月別のタイムラインを構築

        Returns:
            タイムライン構造の辞書
        """
        timeline = {}

        # イシューをフェーズで分類
        phases = self.phase_detector.detect_phases(self.issues)

        for phase_name, phase_issues in phases.items():
            # 各フェーズ内で年月グループ化
            phase_timeline = {}

            # フェーズの期間を取得
            if phase_issues:
                start_date = min(
                    issue.get('created_at_dt') or datetime.max
                    for issue in phase_issues
                )
                end_date = max(
                    issue.get('created_at_dt') or datetime.min
                    for issue in phase_issues
                )

                # 四半期情報を追加
                start_quarter = f"{start_date.year}年Q{(start_date.month - 1) // 3 + 1}"

                phase_timeline['period'] = start_quarter
                phase_timeline['start_date'] = start_date
                phase_timeline['end_date'] = end_date
                phase_timeline['months'] = self._group_by_month(phase_issues)

            timeline[phase_name] = phase_timeline

        return timeline

    def _group_by_month(self, issues: List[Dict]) -> Dict[str, List[Dict]]:
        """
        イシューを月別にグループ化（内部メソッド）

        Args:
            issues: イシューリスト

        Returns:
            月別のイシュー辞書
        """
        grouped = defaultdict(list)

        for issue in issues:
            created_at = issue.get('created_at_dt')
            if created_at:
                year_month = created_at.strftime('%Y年%m月')
                grouped[year_month].append(issue)

        # 月順にソート
        return dict(sorted(grouped.items()))

    def get_project_start_date(self) -> datetime:
        """
        プロジェクト開始日を取得（最も古いイシューの作成日）

        Returns:
            開始日のdatetimeオブジェクト
        """
        if not self.issues:
            return datetime.now()

        return min(
            issue.get('created_at_dt') or datetime.max
            for issue in self.issues
        )

    def get_project_milestones(self) -> List[Dict]:
        """
        プロジェクトの主要マイルストーンを取得

        Returns:
            マイルストーン情報のリスト
        """
        milestones = []

        # フェーズごとの開始日をマイルストーンとして追加
        phases = self.phase_detector.detect_phases(self.issues)

        for phase_name, phase_issues in phases.items():
            if phase_issues:
                start_date = min(
                    issue.get('created_at_dt') or datetime.max
                    for issue in phase_issues
                )
                milestones.append({
                    'date': start_date,
                    'name': phase_name,
                    'type': 'phase_start'
                })

        # マイルストーンラベルを持つイシューを追加
        for issue in self.issues:
            milestone = issue.get('milestone')
            if milestone:
                created_at = issue.get('created_at_dt')
                if created_at:
                    milestones.append({
                        'date': created_at,
                        'name': milestone,
                        'type': 'milestone',
                        'issue_number': issue.get('number')
                    })

        # 日付順にソート
        milestones.sort(key=lambda x: x['date'])

        return milestones

    def format_period(self, start_date: datetime, end_date: datetime = None) -> str:
        """
        期間を整形して文字列で返す

        Args:
            start_date: 開始日
            end_date: 終了日（オプション）

        Returns:
            整形された期間文字列
        """
        start_str = start_date.strftime('%Y-%m-%d')

        if end_date:
            end_str = end_date.strftime('%Y-%m-%d')
            return f"{start_str} 〜 {end_str}"
        else:
            return start_str
