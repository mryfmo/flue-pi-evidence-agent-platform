"""
ADR Linker Module

ADRとイシューのマッピングを行い、参照リンクを自動挿入するモジュール
"""

import re
from typing import Dict, List, Optional
from pathlib import Path


class ADRLinker:
    """ADR参照リンクを管理するクラス"""

    def __init__(self, output_dir: Path, config: Dict = None):
        """
        Args:
            output_dir: 出力ディレクトリのパス
            config: baseline_spec_config.json の内容（オプション）
        """
        self.output_dir = output_dir
        self.config = config or {}
        self.adr_content = None
        self.issue_adr_map = {}

    def load_adr(self) -> str:
        """
        architecture_decision_record.mdを読込

        Returns:
            ADRの内容
        """
        adr_file = self.output_dir / 'architecture_decision_record.md'
        if not adr_file.exists():
            raise FileNotFoundError(f"ADRファイルが見つかりません: {adr_file}")

        with open(adr_file, 'r', encoding='utf-8') as f:
            self.adr_content = f.read()

        # イシュー番号とADR番号のマッピングを構築
        self._build_issue_adr_map()

        return self.adr_content

    def _build_issue_adr_map(self):
        """
        ADR内のイシュー番号からマッピングを構築
        """
        if not self.adr_content:
            return

        # ADR-XXX形式のADR番号を検出
        adr_pattern = r'##\s+ADR-(\d+):'
        adr_matches = re.finditer(adr_pattern, self.adr_content)

        for match in adr_matches:
            adr_number = match.group(1)
            adr_section_start = match.start()

            # 次のADRセクションまでの範囲を取得
            next_match = re.search(adr_pattern, self.adr_content[match.end():])
            if next_match:
                adr_section_end = match.end() + next_match.start()
            else:
                adr_section_end = len(self.adr_content)

            adr_section = self.adr_content[adr_section_start:adr_section_end]

            # セクション内のイシュー番号を検出
            issue_pattern = r'#(\d+)'
            issue_matches = re.finditer(issue_pattern, adr_section)

            for issue_match in issue_matches:
                issue_number = issue_match.group(1)
                self.issue_adr_map[issue_number] = adr_number

    def get_adr_link(self, issue_number: str) -> Optional[str]:
        """
        イシュー番号に対応するADRリンクを取得

        Args:
            issue_number: イシュー番号

        Returns:
            ADRリンク文字列、見つからない場合はNone
        """
        adr_number = self.issue_adr_map.get(str(issue_number))
        if adr_number:
            return f"→ **ADR-{adr_number}参照**"
        return None

    def should_link_to_adr(self, issue: Dict) -> bool:
        """
        イシューがADRにリンクすべきかを判定

        Args:
            issue: イシュー情報

        Returns:
            リンクすべき場合はTrue
        """
        issue_number = str(issue.get('number', ''))

        # 既にマッピングがある場合
        if issue_number in self.issue_adr_map:
            return True

        # configにADR優先度情報がある場合
        if self.config:
            adr_issues = self.config.get('adr_issues', {})
            for priority in ['high', 'medium']:
                priority_issues = adr_issues.get(priority, [])
                if any(str(i.get('number')) == issue_number for i in priority_issues):
                    return True

        # ラベルベースの判定
        labels = self._get_labels(issue)
        adr_labels = {'architecture', 'design', 'decision'}
        if any(label in adr_labels for label in labels):
            return True

        # コメント数・リアクション数ベースの判定
        comment_count = int(issue.get('comments', 0))
        reactions = int(issue.get('reactions', 0))

        if comment_count >= 5 or reactions >= 3:
            return True

        return False

    def _get_labels(self, issue: Dict) -> List[str]:
        """
        イシューのラベルをリストで取得

        Args:
            issue: イシュー情報

        Returns:
            ラベルのリスト
        """
        labels = issue.get('labels', '')
        if not labels:
            return []

        return [label.strip().lower() for label in labels.split(',') if label.strip()]

    def get_adr_summary(self) -> Dict:
        """
        ADRのサマリー情報を取得

        Returns:
            ADRサマリー情報
        """
        if not self.adr_content:
            self.load_adr()

        # ADR数をカウント
        adr_pattern = r'##\s+ADR-(\d+):'
        adr_count = len(re.findall(adr_pattern, self.adr_content))

        # リンクされているイシュー数
        linked_issues = len(self.issue_adr_map)

        return {
            'total_adrs': adr_count,
            'linked_issues': linked_issues,
            'issue_adr_map': self.issue_adr_map
        }

    def extract_tech_stack_changes(self) -> List[Dict]:
        """
        ADRから技術スタックの変更履歴を抽出

        Returns:
            技術スタック変更情報のリスト
        """
        if not self.adr_content:
            self.load_adr()

        changes = []

        # 技術関連のキーワード
        tech_keywords = {
            'database': ['PostgreSQL', 'Snowflake', 'MySQL', 'MongoDB'],
            'framework': ['Streamlit', 'React', 'Vue', 'Django', 'Flask'],
            'language': ['Python', 'JavaScript', 'TypeScript', 'Java'],
            'cloud': ['AWS', 'GCP', 'Azure', 'Heroku'],
        }

        # ADRセクションごとに技術変更を検出
        adr_pattern = r'##\s+ADR-(\d+):\s+(.+?)(?=##|\Z)'
        adr_matches = re.finditer(adr_pattern, self.adr_content, re.DOTALL)

        for match in adr_matches:
            adr_number = match.group(1)
            adr_content = match.group(2)
            adr_title_match = re.match(r'(.+?)(?:\n|$)', adr_content.strip())
            adr_title = adr_title_match.group(1) if adr_title_match else ''

            # 技術キーワードの検出
            for category, keywords in tech_keywords.items():
                for keyword in keywords:
                    if keyword in adr_content:
                        # 採用・変更・移行のキーワードを検出
                        if any(word in adr_content for word in ['採用', '選定', '導入']):
                            change_type = '採用'
                        elif any(word in adr_content for word in ['移行', '変更', '切替']):
                            change_type = '移行'
                        else:
                            continue

                        changes.append({
                            'adr_number': adr_number,
                            'adr_title': adr_title,
                            'category': category,
                            'technology': keyword,
                            'change_type': change_type
                        })

        return changes
