"""
GitHub Issues取得モジュール（ツール⑦用）

pochi-baseline-detailedのGitHubIssueFetcherをベースに、
ツール⑦に必要な機能を実装。
"""

import re
import subprocess
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


def validate_repo_name(repo: str) -> str:
    """リポジトリ名をバリデーション

    Args:
        repo: リポジトリ名（owner/repo形式またはrepo名のみ）

    Returns:
        バリデーション済みのリポジトリ名

    Raises:
        ValueError: 無効なリポジトリ名の場合
    """
    if '/' in repo:
        parts = repo.split('/')
        if len(parts) != 2:
            raise ValueError(f"無効なリポジトリ名: {repo}")
        org, name = parts
    else:
        org, name = None, repo

    pattern = r'^[a-zA-Z0-9._-]+$'
    if org and not re.match(pattern, org):
        raise ValueError(f"無効な組織名: {org}")
    if not re.match(pattern, name):
        raise ValueError(f"無効なリポジトリ名: {name}")
    return repo


def validate_issue_number(issue_number) -> int:
    """イシュー番号を整数バリデーション

    Args:
        issue_number: イシュー番号

    Returns:
        バリデーション済みの正の整数

    Raises:
        ValueError: 無効なイシュー番号の場合
    """
    try:
        num = int(issue_number)
        if num <= 0:
            raise ValueError
        return num
    except (ValueError, TypeError):
        raise ValueError(f"無効なイシュー番号: {issue_number}")


class GitHubIssueFetcher:
    """GitHub Issues取得クラス"""

    def __init__(self, org: str = 'nttdocomo-com'):
        """
        初期化

        Args:
            org: GitHub組織名（デフォルト: nttdocomo-com）
        """
        self.org = org
        self.token = None
        self.session = None

    def _get_github_token(self) -> Optional[str]:
        """
        `gh` CLIを使って認証済みトークンを安全に取得

        Returns:
            GitHubトークン、取得できない場合はNone
        """
        try:
            result = subprocess.run(
                ['gh', 'auth', 'token'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=10
            )
            if result.returncode == 0:
                return result.stdout.decode('utf-8').strip()

        except subprocess.TimeoutExpired:
            print("⚠️  GitHub認証トークン取得がタイムアウトしました")
        except FileNotFoundError:
            print("⚠️  'gh' CLIが見つかりません。インストールしてください。")
        except Exception as e:
            print(f"⚠️  GitHub認証トークンの取得に失敗: {e}")

        return None

    def _create_session(self) -> requests.Session:
        """
        リトライ機能付きのHTTPセッションを作成

        Returns:
            設定済みのrequests.Session
        """
        session = requests.Session()
        retries = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504]
        )
        session.mount('https://', HTTPAdapter(max_retries=retries))
        return session

    def initialize(self) -> bool:
        """
        認証とセッションの初期化

        Returns:
            初期化成功時True、失敗時False
        """
        print("🔐 GitHub認証トークンを取得中...")
        self.token = self._get_github_token()

        if not self.token:
            print("❌ GitHub認証トークンが取得できませんでした")
            print("   'gh auth login' を実行して認証してください")
            return False

        self.session = self._create_session()
        print("✅ GitHub認証成功")
        return True

    def _get_total_issue_count(self, repo: str, headers: dict) -> int:
        """総イシュー数を取得"""
        url = f"https://api.github.com/repos/{self.org}/{repo}"
        try:
            response = self.session.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            repo_data = response.json()
            return repo_data.get('open_issues_count', 0)
        except requests.RequestException:
            return 0

    def _wait_for_rate_limit_reset(self, headers: dict):
        """Rate Limitリセットを待つ"""
        MAX_WAIT_SECONDS = 900  # 最大15分
        url = "https://api.github.com/rate_limit"
        try:
            response = self.session.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            rate_limit = response.json()
            reset_time = rate_limit['resources']['core']['reset']

            wait_seconds = min(reset_time - time.time() + 10, MAX_WAIT_SECONDS)
            if wait_seconds > 0:
                print(f"⏳ Rate Limit到達。{wait_seconds:.0f}秒待機します...")
                time.sleep(wait_seconds)
            else:
                print("⏳ Rate Limit対策として60秒待機します...")
                time.sleep(60)
        except requests.RequestException:
            # デフォルトで1分待機
            print("⏳ Rate Limit対策として60秒待機します...")
            time.sleep(60)

    def fetch_issues(
        self,
        repo: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        per_page: int = 100
    ) -> pd.DataFrame:
        """
        指定リポジトリのイシュー一覧を取得（進捗表示改善版）

        Args:
            repo: リポジトリ名
            start_date: 取得開始日（省略時は全期間）
            end_date: 取得終了日（省略時は全期間）
            per_page: ページあたりのイシュー数

        Returns:
            イシュー情報のDataFrame

        Raises:
            RuntimeError: 初期化されていない場合
            requests.RequestException: API呼び出しエラー
        """
        if not self.session or not self.token:
            raise RuntimeError("initialize()を先に呼び出してください")

        headers = {
            'Authorization': f'token {self.token}',
            'Accept': 'application/vnd.github.v3+json'
        }

        # リポジトリ名バリデーション
        validated_repo = validate_repo_name(f"{self.org}/{repo}")

        # 総イシュー数を事前取得
        total_issues = self._get_total_issue_count(repo, headers)
        print(f"📥 {validated_repo} からイシューを取得中...")
        if total_issues > 0:
            print(f"   総イシュー数（推定）: {total_issues}件")

        if total_issues > 500:
            print(f"⚠️  イシュー数が多いため、取得に時間がかかります")

        page = 1
        all_issues = []
        processed_count = 0
        start_time = time.time()

        while True:
            url = f"https://api.github.com/repos/{validated_repo}/issues"
            params = {
                'state': 'all',
                'page': page,
                'per_page': per_page
            }

            try:
                response = self.session.get(url, headers=headers, params=params, timeout=30)
                response.raise_for_status()
                page_issues = response.json()

                # APIレスポンスの型検証
                if not isinstance(page_issues, list):
                    print(f"⚠️  予期しないAPIレスポンス形式 (page {page}): スキップします")
                    break

                # PRを除外
                page_issues = [
                    issue for issue in page_issues
                    if isinstance(issue, dict) and 'pull_request' not in issue
                ]

                all_issues.extend(page_issues)
                processed_count += len(page_issues)

                # 進捗表示（詳細版）
                if total_issues > 0:
                    progress = (processed_count / total_issues * 100)
                    elapsed_time = time.time() - start_time
                    if processed_count > 0:
                        estimated_total_time = (elapsed_time / processed_count) * total_issues
                        remaining_time = estimated_total_time - elapsed_time
                        print(f"   進捗: {processed_count}/{total_issues}件 ({progress:.1f}%) - 残り約{remaining_time/60:.1f}分")
                    else:
                        print(f"   進捗: {processed_count}/{total_issues}件 ({progress:.1f}%)")

                if len(page_issues) < per_page:
                    break

                page += 1
                time.sleep(0.2)  # Rate Limit対策（強化）

            except requests.Timeout:
                print(f"⚠️  タイムアウト (page {page}): スキップします")
                break
            except requests.RequestException as e:
                print(f"⚠️  イシュー取得エラー (page {page}): {e}")
                # Rate Limitエラーの場合、リトライ
                if 'rate limit' in str(e).lower():
                    self._wait_for_rate_limit_reset(headers)
                    continue
                break

        print(f"   取得完了: {len(all_issues)}件 (所要時間: {(time.time() - start_time)/60:.1f}分)")

        # 期間フィルタリング
        if start_date or end_date:
            filtered_issues = self._filter_by_date(all_issues, start_date, end_date)
            print(f"   期間フィルタ後: {len(filtered_issues)}件")
            all_issues = filtered_issues

        # DataFrameに変換
        return self._issues_to_dataframe(all_issues)

    def _filter_by_date(
        self,
        issues: List[Dict],
        start_date: Optional[datetime],
        end_date: Optional[datetime]
    ) -> List[Dict]:
        """イシューを作成日時でフィルタリング"""
        filtered = []

        for issue in issues:
            created_at = datetime.strptime(
                issue['created_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )

            if start_date and created_at < start_date:
                continue
            if end_date and created_at > end_date:
                continue

            filtered.append(issue)

        return filtered

    def _issues_to_dataframe(self, issues: List[Dict]) -> pd.DataFrame:
        """イシューリストをDataFrameに変換"""
        records = []

        for issue in issues:
            created_at = datetime.strptime(
                issue['created_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )
            updated_at = datetime.strptime(
                issue['updated_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )

            closed_at = None
            if issue.get('closed_at'):
                closed_at = datetime.strptime(
                    issue['closed_at'],
                    "%Y-%m-%dT%H:%M:%SZ"
                )

            body = issue.get('body') or ''
            labels = [label['name'] for label in issue.get('labels', [])]
            assignees = [user['login'] for user in issue.get('assignees', [])]
            milestone = issue['milestone']['title'] if issue.get('milestone') else None

            records.append({
                'number': issue['number'],
                'title': issue['title'],
                'body': body,
                'created_at': created_at,
                'updated_at': updated_at,
                'closed_at': closed_at,
                'state': issue['state'],
                'state_reason': issue.get('state_reason'),
                'creator': issue['user']['login'],
                'author_association': issue.get('author_association'),
                'assignees': assignees,
                'labels': labels,
                'milestone': milestone,
                'comments_count': issue.get('comments', 0),
                'reactions_total': issue.get('reactions', {}).get('total_count', 0),
                'url': issue['html_url']
            })

        df = pd.DataFrame(records)

        # 作成日時でソート
        if not df.empty:
            df = df.sort_values('created_at').reset_index(drop=True)

        return df

    def fetch_comments(
        self,
        repo: str,
        issue_numbers: List[int]
    ) -> pd.DataFrame:
        """
        複数イシューのコメントを一括取得（進捗表示改善版）

        Args:
            repo: リポジトリ名
            issue_numbers: イシュー番号のリスト

        Returns:
            コメント情報のDataFrame
        """
        if not self.session or not self.token:
            raise RuntimeError("initialize()を先に呼び出してください")

        headers = {
            'Authorization': f'token {self.token}',
            'Accept': 'application/vnd.github.v3+json'
        }

        print(f"💬 コメントを取得中... (対象: {len(issue_numbers)}件)")

        all_comments = []
        start_time = time.time()

        for i, issue_number in enumerate(issue_numbers, 1):
            validated_issue_number = validate_issue_number(issue_number)
            # 進捗表示（5%ごと、または10件ごと）
            if i % max(len(issue_numbers) // 20, 10) == 0 or i == len(issue_numbers):
                progress = i / len(issue_numbers) * 100
                elapsed = time.time() - start_time
                if i > 0:
                    estimated_total = (elapsed / i) * len(issue_numbers)
                    remaining = estimated_total - elapsed
                    print(f"   進捗: {i}/{len(issue_numbers)}件 ({progress:.1f}%) - 残り約{remaining/60:.1f}分")

            url = f"https://api.github.com/repos/{self.org}/{repo}/issues/{validated_issue_number}/comments"

            try:
                response = self.session.get(url, headers=headers, timeout=30)
                response.raise_for_status()
                comments = response.json()

                # APIレスポンスの型検証
                if not isinstance(comments, list):
                    print(f"⚠️  Issue #{validated_issue_number} のコメント: 予期しないレスポンス形式")
                    continue

                for comment in comments:
                    comment['issue_number'] = validated_issue_number
                all_comments.extend(comments)

                time.sleep(0.1)  # Rate Limit対策

            except requests.RequestException as e:
                # Rate Limitエラーの場合、リトライ
                if 'rate limit' in str(e).lower():
                    self._wait_for_rate_limit_reset(headers)
                    # リトライ
                    try:
                        response = self.session.get(url, headers=headers, timeout=30)
                        response.raise_for_status()
                        comments = response.json()
                        if isinstance(comments, list):
                            for comment in comments:
                                comment['issue_number'] = validated_issue_number
                            all_comments.extend(comments)
                    except requests.RequestException:
                        print(f"⚠️  Issue #{validated_issue_number} のコメント取得エラー: {e}")
                else:
                    print(f"⚠️  Issue #{validated_issue_number} のコメント取得エラー: {e}")
                continue

        print(f"   取得完了: {len(all_comments)}件 (所要時間: {(time.time() - start_time)/60:.1f}分)")

        return self._comments_to_dataframe(all_comments)

    def _comments_to_dataframe(self, comments: List[Dict]) -> pd.DataFrame:
        """コメントリストをDataFrameに変換"""
        if not comments:
            return pd.DataFrame()

        records = []

        for comment in comments:
            created_at = datetime.strptime(
                comment['created_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )
            updated_at = datetime.strptime(
                comment['updated_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )

            records.append({
                'issue_number': comment['issue_number'],
                'comment_id': comment['id'],
                'author': comment['user']['login'],
                'author_association': comment.get('author_association'),
                'created_at': created_at,
                'updated_at': updated_at,
                'body': comment['body'],
                'reactions_total': comment.get('reactions', {}).get('total_count', 0)
            })

        return pd.DataFrame(records)

    def fetch_events(
        self,
        repo: str,
        issue_numbers: List[int]
    ) -> pd.DataFrame:
        """
        複数イシューのイベント履歴を一括取得（進捗表示改善版）

        Args:
            repo: リポジトリ名
            issue_numbers: イシュー番号のリスト

        Returns:
            イベント情報のDataFrame
        """
        if not self.session or not self.token:
            raise RuntimeError("initialize()を先に呼び出してください")

        headers = {
            'Authorization': f'token {self.token}',
            'Accept': 'application/vnd.github.v3+json'
        }

        print(f"📋 イベント履歴を取得中... (対象: {len(issue_numbers)}件)")

        all_events = []
        start_time = time.time()

        for i, issue_number in enumerate(issue_numbers, 1):
            validated_issue_number = validate_issue_number(issue_number)
            # 進捗表示（5%ごと、または10件ごと）
            if i % max(len(issue_numbers) // 20, 10) == 0 or i == len(issue_numbers):
                progress = i / len(issue_numbers) * 100
                elapsed = time.time() - start_time
                if i > 0:
                    estimated_total = (elapsed / i) * len(issue_numbers)
                    remaining = estimated_total - elapsed
                    print(f"   進捗: {i}/{len(issue_numbers)}件 ({progress:.1f}%) - 残り約{remaining/60:.1f}分")

            url = f"https://api.github.com/repos/{self.org}/{repo}/issues/{validated_issue_number}/events"

            try:
                response = self.session.get(url, headers=headers, timeout=30)
                response.raise_for_status()
                events = response.json()

                # APIレスポンスの型検証
                if not isinstance(events, list):
                    print(f"⚠️  Issue #{validated_issue_number} のイベント: 予期しないレスポンス形式")
                    continue

                for event in events:
                    event['issue_number'] = validated_issue_number
                all_events.extend(events)

                time.sleep(0.1)  # Rate Limit対策

            except requests.RequestException as e:
                # Rate Limitエラーの場合、リトライ
                if 'rate limit' in str(e).lower():
                    self._wait_for_rate_limit_reset(headers)
                    # リトライ
                    try:
                        response = self.session.get(url, headers=headers, timeout=30)
                        response.raise_for_status()
                        events = response.json()
                        if isinstance(events, list):
                            for event in events:
                                event['issue_number'] = validated_issue_number
                            all_events.extend(events)
                    except requests.RequestException:
                        print(f"⚠️  Issue #{validated_issue_number} のイベント取得エラー: {e}")
                else:
                    print(f"⚠️  Issue #{validated_issue_number} のイベント取得エラー: {e}")
                continue

        print(f"   取得完了: {len(all_events)}件 (所要時間: {(time.time() - start_time)/60:.1f}分)")

        return self._events_to_dataframe(all_events)

    def _events_to_dataframe(self, events: List[Dict]) -> pd.DataFrame:
        """イベントリストをDataFrameに変換"""
        if not events:
            return pd.DataFrame()

        records = []

        for event in events:
            created_at = datetime.strptime(
                event['created_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )

            # イベントタイプに応じた情報を取得
            label_name = ''
            if event['event'] in ['labeled', 'unlabeled'] and event.get('label'):
                label_name = event['label'].get('name', '')

            milestone_title = ''
            if event['event'] in ['milestoned', 'demilestoned'] and event.get('milestone'):
                milestone_title = event['milestone'].get('title', '')

            assignee = ''
            if event['event'] in ['assigned', 'unassigned'] and event.get('assignee'):
                assignee = event['assignee'].get('login', '')

            actor_login = ''
            if event.get('actor'):
                actor_login = event['actor'].get('login', '')

            records.append({
                'issue_number': event['issue_number'],
                'event_id': event['id'],
                'event_type': event['event'],
                'actor': actor_login,
                'created_at': created_at,
                'label_name': label_name,
                'milestone_title': milestone_title,
                'assignee': assignee
            })

        return pd.DataFrame(records)
