"""
Issue Processor Module

GitHubイシューデータの読込・整形を行うモジュール
"""

import csv
import json
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime


class IssueProcessor:
    """イシューデータを処理するクラス"""

    def __init__(self, output_dir: Path):
        """
        Args:
            output_dir: 出力ディレクトリのパス
        """
        self.output_dir = output_dir
        self.issues = []
        self.comments = []
        self.events = []

    def load_issues(self) -> List[Dict]:
        """
        issues_detail.csvからイシュー情報を読込

        Returns:
            イシュー情報のリスト
        """
        issues_file = self.output_dir / 'issues_detail.csv'
        if not issues_file.exists():
            raise FileNotFoundError(f"イシューファイルが見つかりません: {issues_file}")

        with open(issues_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            self.issues = list(reader)

        # 日付文字列をdatetimeに変換
        for issue in self.issues:
            issue['created_at_dt'] = self._parse_datetime(issue.get('created_at'))
            if issue.get('closed_at'):
                issue['closed_at_dt'] = self._parse_datetime(issue['closed_at'])

        return self.issues

    def load_comments(self) -> List[Dict]:
        """
        issues_comments.csvからコメント情報を読込

        Returns:
            コメント情報のリスト
        """
        comments_file = self.output_dir / 'issues_comments.csv'
        if not comments_file.exists():
            raise FileNotFoundError(f"コメントファイルが見つかりません: {comments_file}")

        with open(comments_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            self.comments = list(reader)

        return self.comments

    def load_events(self) -> List[Dict]:
        """
        issues_events.csvからイベント情報を読込

        Returns:
            イベント情報のリスト
        """
        events_file = self.output_dir / 'issues_events.csv'
        if not events_file.exists():
            raise FileNotFoundError(f"イベントファイルが見つかりません: {events_file}")

        with open(events_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            self.events = list(reader)

        return self.events

    def load_config(self) -> Optional[Dict]:
        """
        baseline_spec_config.jsonからイシュー分類結果を読込

        Returns:
            設定情報の辞書、ファイルが存在しない場合はNone
        """
        config_file = self.output_dir / 'baseline_spec_config.json'
        if not config_file.exists():
            return None

        with open(config_file, 'r', encoding='utf-8') as f:
            return json.load(f)

    def load_app_info(self) -> Optional[Dict]:
        """
        app_info.jsonからアプリケーション情報を読込

        Returns:
            アプリ情報の辞書、ファイルが存在しない場合はNone
        """
        app_info_file = self.output_dir / 'app_info.json'
        if not app_info_file.exists():
            return None

        with open(app_info_file, 'r', encoding='utf-8') as f:
            return json.load(f)

    def get_issue_by_number(self, issue_number: str) -> Optional[Dict]:
        """
        イシュー番号からイシュー情報を取得

        Args:
            issue_number: イシュー番号

        Returns:
            イシュー情報、見つからない場合はNone
        """
        for issue in self.issues:
            if issue.get('number') == str(issue_number):
                return issue
        return None

    def get_comments_by_issue(self, issue_number: str) -> List[Dict]:
        """
        イシュー番号に紐づくコメントを取得

        Args:
            issue_number: イシュー番号

        Returns:
            コメント情報のリスト
        """
        return [
            comment for comment in self.comments
            if comment.get('issue_number') == str(issue_number)
        ]

    def get_events_by_issue(self, issue_number: str) -> List[Dict]:
        """
        イシュー番号に紐づくイベントを取得

        Args:
            issue_number: イシュー番号

        Returns:
            イベント情報のリスト
        """
        return [
            event for event in self.events
            if event.get('issue_number') == str(issue_number)
        ]

    def _parse_datetime(self, datetime_str: Optional[str]) -> Optional[datetime]:
        """
        日付文字列をdatetimeオブジェクトに変換

        Args:
            datetime_str: ISO形式の日付文字列

        Returns:
            datetimeオブジェクト、変換できない場合はNone
        """
        if not datetime_str:
            return None

        try:
            # ISO 8601形式をパース（Zタイムゾーン対応）
            if datetime_str.endswith('Z'):
                datetime_str = datetime_str[:-1] + '+00:00'
            return datetime.fromisoformat(datetime_str)
        except (ValueError, TypeError):
            return None

    def get_label_list(self, issue: Dict) -> List[str]:
        """
        イシューのラベルをリストで取得

        Args:
            issue: イシュー情報

        Returns:
            ラベルのリスト
        """
        labels = issue.get('labels', '')
        if not labels:
            return []

        # カンマ区切りのラベルを分割
        return [label.strip() for label in labels.split(',') if label.strip()]

    def format_issue_summary(self, issue: Dict) -> str:
        """
        イシューの要約を整形

        Args:
            issue: イシュー情報

        Returns:
            整形されたイシュー要約
        """
        number = issue.get('number', 'N/A')
        title = issue.get('title', 'No Title')
        state = issue.get('state', 'unknown')
        labels = self.get_label_list(issue)

        summary = f"イシュー#{number}: {title}"
        if state == 'closed':
            summary += " ✓"

        if labels:
            summary += f" [{', '.join(labels)}]"

        return summary
