"""
Phase Detector Module

イシューのラベル・マイルストーンからフェーズを自動検出するモジュール
"""

from typing import Dict, List
from datetime import datetime, timedelta
from collections import defaultdict


class PhaseDetector:
    """フェーズを自動検出するクラス"""

    # フェーズ検出のための閾値（月数）
    PHASE_1_DURATION = 3  # 最初の3ヶ月
    PHASE_2_DURATION = 6  # 3-6ヶ月

    # ラベルベースのフェーズマッピング
    LABEL_PHASE_MAP = {
        'architecture': 'アーキテクチャ設計',
        'design': 'アーキテクチャ設計',
        'feature': '機能拡張',
        'enhancement': '機能拡張',
        'refactor': '改善・最適化',
        'optimization': '改善・最適化',
        'performance': '改善・最適化',
        'ui': 'UI/UX刷新',
        'ux': 'UI/UX刷新',
    }

    def __init__(self, config: Dict = None):
        """
        Args:
            config: baseline_spec_config.json の内容（オプション）
        """
        self.config = config or {}

    def detect_phases(self, issues: List[Dict]) -> Dict[str, List[Dict]]:
        """
        イシューをフェーズに分類

        Args:
            issues: イシュー情報のリスト

        Returns:
            フェーズ名をキーとしたイシュー辞書
        """
        phases = defaultdict(list)

        # 明示的なフェーズラベルがある場合
        for issue in issues:
            labels = self._get_labels(issue)

            # phase-1, phase-2などのラベルをチェック
            phase_label = self._find_phase_label(labels)
            if phase_label:
                phases[phase_label].append(issue)
                continue

            # マイルストーンベース
            milestone = issue.get('milestone')
            if milestone:
                phases[milestone].append(issue)
                continue

            # ラベルベースのフェーズ検出
            phase_name = self._detect_phase_from_labels(labels)
            if phase_name:
                phases[phase_name].append(issue)
                continue

            # 時期ベースのフェーズ検出
            phase_name = self._detect_phase_from_date(issue, issues)
            phases[phase_name].append(issue)

        return dict(phases)

    def _get_labels(self, issue: Dict) -> List[str]:
        """
        イシューのラベルをリストで取得

        Args:
            issue: イシュー情報

        Returns:
            ラベルのリスト
        """
        labels = issue.get('labels', '')
        if not labels:
            return []

        return [label.strip().lower() for label in labels.split(',') if label.strip()]

    def _find_phase_label(self, labels: List[str]) -> str:
        """
        ラベルから明示的なフェーズラベルを検出

        Args:
            labels: ラベルのリスト

        Returns:
            フェーズ名、見つからない場合は空文字列
        """
        for label in labels:
            if label.startswith('phase-'):
                # phase-1 → フェーズ1
                phase_num = label.split('-')[1]
                return f"フェーズ{phase_num}"

        return ''

    def _detect_phase_from_labels(self, labels: List[str]) -> str:
        """
        ラベルの内容からフェーズを推定

        Args:
            labels: ラベルのリスト

        Returns:
            推定されたフェーズ名、見つからない場合は空文字列
        """
        for label in labels:
            if label in self.LABEL_PHASE_MAP:
                return self.LABEL_PHASE_MAP[label]

        return ''

    def _detect_phase_from_date(self, issue: Dict, all_issues: List[Dict]) -> str:
        """
        作成日時からフェーズを推定

        Args:
            issue: イシュー情報
            all_issues: 全イシューのリスト

        Returns:
            推定されたフェーズ名
        """
        # プロジェクト開始日を取得
        project_start = min(
            i.get('created_at_dt') or datetime.max
            for i in all_issues
        )

        created_at = issue.get('created_at_dt')
        if not created_at:
            return 'その他'

        # プロジェクト開始からの経過月数
        months_elapsed = (created_at.year - project_start.year) * 12 + \
                        (created_at.month - project_start.month)

        if months_elapsed < self.PHASE_1_DURATION:
            return '立ち上げ'
        elif months_elapsed < self.PHASE_2_DURATION:
            return '機能拡張'
        else:
            return '改善・最適化'

    def get_phase_summary(self, phases: Dict[str, List[Dict]]) -> Dict[str, Dict]:
        """
        フェーズのサマリー情報を取得

        Args:
            phases: フェーズ別のイシュー辞書

        Returns:
            フェーズサマリー情報
        """
        summary = {}

        for phase_name, issues in phases.items():
            if not issues:
                continue

            # 期間
            start_date = min(
                issue.get('created_at_dt') or datetime.max
                for issue in issues
            )
            end_date = max(
                issue.get('created_at_dt') or datetime.min
                for issue in issues
            )

            # イシュー数
            total_issues = len(issues)
            closed_issues = sum(
                1 for issue in issues
                if issue.get('state') == 'closed'
            )

            # 主要ラベル
            label_counts = defaultdict(int)
            for issue in issues:
                labels = self._get_labels(issue)
                for label in labels:
                    label_counts[label] += 1

            top_labels = sorted(
                label_counts.items(),
                key=lambda x: x[1],
                reverse=True
            )[:3]

            summary[phase_name] = {
                'start_date': start_date,
                'end_date': end_date,
                'total_issues': total_issues,
                'closed_issues': closed_issues,
                'top_labels': [label for label, _ in top_labels]
            }

        return summary

    def detect_phase_transitions(self, issues: List[Dict]) -> List[Dict]:
        """
        フェーズの変遷ポイントを検出

        Args:
            issues: イシュー情報のリスト

        Returns:
            フェーズ変遷情報のリスト
        """
        phases = self.detect_phases(issues)
        transitions = []

        # フェーズを日付順に並べる
        phase_dates = {}
        for phase_name, phase_issues in phases.items():
            if phase_issues:
                start_date = min(
                    issue.get('created_at_dt') or datetime.max
                    for issue in phase_issues
                )
                phase_dates[phase_name] = start_date

        # 日付順にソート
        sorted_phases = sorted(phase_dates.items(), key=lambda x: x[1])

        # 変遷情報を作成
        for i, (phase_name, start_date) in enumerate(sorted_phases):
            transition = {
                'phase': phase_name,
                'start_date': start_date,
                'index': i + 1
            }
            transitions.append(transition)

        return transitions
