"""
Pochi History Generator - Skill Entry Point

GitHubイシュー履歴から時系列形式のアプリ開発履歴を生成する。
"""
import os
import sys
import json
import argparse
import re
import subprocess
import shutil
from pathlib import Path
from datetime import datetime

# coreモジュールをインポート
try:
    from core.issue_processor import IssueProcessor
    from core.timeline_builder import TimelineBuilder
    from core.adr_linker import ADRLinker
    from core.phase_detector import PhaseDetector
    from core.issue_fetcher import GitHubIssueFetcher
except ImportError:
    # 開発時用: スキルディレクトリから実行される場合
    sys.path.insert(0, str(Path(__file__).parent))
    from core.issue_processor import IssueProcessor
    from core.timeline_builder import TimelineBuilder
    from core.adr_linker import ADRLinker
    from core.phase_detector import PhaseDetector
    from core.issue_fetcher import GitHubIssueFetcher


def check_skill_mode():
    """Skills専用モードチェック"""
    if os.environ.get('POCHI_SKILL_ACTIVE') != '1':
        print("❌ エラー: このスクリプトはSkills専用モードでのみ実行可能です")
        print("")
        print("Claude Code経由で起動してください：")
        print("  「アプリの歴史を生成して」")
        print("")
        sys.exit(1)


def get_repository_name() -> str:
    """
    リポジトリ名を取得（複数の方法を試行）

    優先順位:
    1. 環境変数 GITHUB_REPOSITORY
    2. トリガーワードから抽出（Claude Codeが設定）
    3. ユーザーに質問

    Returns:
        str: リポジトリ名（owner/repository 形式）
    """
    # 1. 環境変数チェック
    repo = os.environ.get('GITHUB_REPOSITORY')
    if repo:
        print(f"✅ リポジトリ名（環境変数）: {repo}")
        return repo

    # 2. トリガーワードから抽出（Claude Codeが設定）
    repo = os.environ.get('REPOSITORY_FROM_TRIGGER')
    if repo:
        print(f"✅ リポジトリ名（トリガー）: {repo}")
        return repo

    # 3. ユーザーに質問
    print("\n" + "=" * 70)
    print("リポジトリ名の入力")
    print("=" * 70)
    print("\nGitHubリポジトリ名を指定してください")
    print("形式: owner/repository または repository")
    print("例: nttdocomo-com/pochi-app-repo")
    print("")

    while True:
        repo = input("リポジトリ名: ").strip()
        if repo:
            # バリデーション
            from core.issue_fetcher import validate_repo_name
            try:
                if '/' in repo:
                    validate_repo_name(repo)
                    return repo
                else:
                    validated = validate_repo_name(f"nttdocomo-com/{repo}")
                    return validated
            except ValueError:
                pass

            print("❌ 無効な形式です。もう一度入力してください。")
        else:
            print("❌ リポジトリ名は必須です。")


def detect_repository_from_trigger(user_input: str) -> str:
    """
    トリガーワードからリポジトリ名を抽出（将来的にClaude Codeが使用）

    Args:
        user_input: ユーザーの入力文字列

    Returns:
        str: リポジトリ名、見つからない場合は空文字列

    Examples:
        >>> detect_repository_from_trigger("pochi-app-repoのアプリの歴史を生成して")
        'pochi-app-repo'
        >>> detect_repository_from_trigger("owner/repoの開発履歴を作成")
        'owner/repo'
    """
    patterns = [
        r'([a-zA-Z0-9_-]+/[a-zA-Z0-9_-]+)の',  # owner/repo形式
        r'([a-zA-Z0-9_-]+)のアプリ',           # repo名のみ
        r'([a-zA-Z0-9_-]+)の開発',             # repo名のみ
        r'([a-zA-Z0-9_-]+)のhistory',          # repo名のみ
    ]
    for pattern in patterns:
        match = re.search(pattern, user_input)
        if match:
            repo = match.group(1)
            if '/' not in repo:
                repo = f"nttdocomo-com/{repo}"
            return repo
    return ""


def run_baseline_detailed(repo: str, output_dir: Path) -> bool:
    """
    ツール③（pochi-baseline-detailed）を自動実行

    Args:
        repo: リポジトリ名（owner/repository 形式）
        output_dir: 出力ディレクトリ

    Returns:
        bool: 成功時True
    """
    skill_dir = Path(__file__).resolve().parent.parent / "pochi-baseline-detailed"
    skill_entry = skill_dir / "skill_entry.py"

    if not skill_entry.exists():
        print(f"❌ ツール③が見つかりません: {skill_entry}")
        return False

    # 環境変数設定
    env = os.environ.copy()
    env['POCHI_SKILL_ACTIVE'] = '1'
    env['GITHUB_REPOSITORY'] = repo

    print(f"   ツール③を実行中: {repo}")
    print(f"   出力先: {output_dir}")

    # ツール③実行（出力ディレクトリを指定）
    try:
        result = subprocess.run(
            [sys.executable, str(skill_entry), '--output-dir', str(output_dir)],
            env=env,
            capture_output=True,
            text=True,
            timeout=600  # 10分タイムアウト
        )

        if result.returncode != 0:
            print(f"❌ ツール③実行エラー:")
            print(result.stderr)
            if result.stdout:
                print("\n標準出力:")
                print(result.stdout)
            return False

        # 生成ファイル確認とリネーム
        # pochi-baseline-detailedは adr_skeleton.md と baseline_spec_skeleton.md を生成
        # pochi-history-generatorは architecture_decision_record.md と baseline_spec.md を期待

        adr_skeleton = output_dir / 'adr_skeleton.md'
        baseline_skeleton = output_dir / 'baseline_spec_skeleton.md'
        adr_file = output_dir / 'architecture_decision_record.md'
        baseline_file = output_dir / 'baseline_spec.md'

        if adr_skeleton.exists():
            # コピー（元ファイルも保持）
            shutil.copy2(adr_skeleton, adr_file)
            print(f"✅ ADRファイルをコピーしました: {adr_file.name}")

        if baseline_skeleton.exists():
            shutil.copy2(baseline_skeleton, baseline_file)
            print(f"✅ baseline_specファイルをコピーしました: {baseline_file.name}")

        if adr_file.exists() and baseline_file.exists():
            return True
        else:
            print("❌ ADR・baseline_specが生成されませんでした")
            print(f"   期待ファイル: {adr_file}, {baseline_file}")
            print(f"   生成ファイル: {list(output_dir.glob('*.md'))}")
            return False

    except subprocess.TimeoutExpired:
        print("❌ ツール③実行タイムアウト（10分超過）")
        return False
    except Exception as e:
        print(f"❌ ツール③実行エラー: {e}")
        return False


def setup_output_directory() -> Path:
    """出力ディレクトリの準備

    Returns:
        Path: {skill_dir}/output/ のパス
    """
    # スキルディレクトリを基準に出力ディレクトリを設定
    skill_dir = Path(__file__).parent.resolve()

    # 出力ディレクトリ
    output_dir = skill_dir / "output"

    # ディレクトリが存在しない場合は作成
    if not output_dir.exists():
        print(f"📁 出力ディレクトリを作成します: {output_dir}")
        output_dir.mkdir(parents=True, exist_ok=True)

    return output_dir


def check_prerequisites(output_dir: Path, repo: str) -> tuple:
    """前提条件チェック

    Args:
        output_dir: 出力ディレクトリのパス
        repo: リポジトリ名（owner/repository 形式）

    Returns:
        tuple: (all_ok, needs_fetch)
            all_ok: すべての必須ファイルが揃っている場合True
            needs_fetch: イシューデータの取得が必要な場合True
    """
    print("\n" + "=" * 70)
    print("前提条件チェック")
    print("=" * 70)

    csv_files = [
        'issues_detail.csv',
        'issues_comments.csv',
        'issues_events.csv',
    ]

    adr_files = [
        'architecture_decision_record.md',
        'baseline_spec.md',
    ]

    recommended_files = [
        'app_info.json',
        'baseline_spec_config.json',
    ]

    # CSVファイルの存在確認
    csv_exists = True
    print("\n【イシューデータ（CSV）】")
    for filename in csv_files:
        filepath = output_dir / filename
        if filepath.exists():
            print(f"  ✅ {filename}")
        else:
            print(f"  ❌ {filename} - 見つかりません")
            csv_exists = False

    # ADRファイルの存在確認（オプション）
    adr_exists = True
    print("\n【ADR・baseline_spec】")
    for filename in adr_files:
        filepath = output_dir / filename
        if filepath.exists():
            print(f"  ✅ {filename}")
        else:
            print(f"  ⚠️  {filename} - 見つかりません（省略可）")
            adr_exists = False

    # 推奨ファイルの確認
    print("\n【推奨ファイル】")
    for filename in recommended_files:
        filepath = output_dir / filename
        if filepath.exists():
            print(f"  ✅ {filename}")
        else:
            print(f"  ⚠️  {filename} - 見つかりません（省略可）")

    # イシューデータが存在しない場合、GitHubから取得する必要がある
    needs_fetch = not csv_exists

    if needs_fetch:
        print("\n⚠️  イシューデータが見つかりません")
        print(f"   GitHubから取得します: {repo}")
        return True, True

    # ADRがない場合、自動生成（確認なし）
    if not adr_exists:
        print("\n⚠️  ADR・baseline_specが見つかりません")
        print("🚀 ツール③（pochi-baseline-detailed）を自動実行します...")

        success = run_baseline_detailed(repo, output_dir)
        if success:
            print("✅ ADR・baseline_spec生成完了")
            adr_exists = True
        else:
            print("\n" + "=" * 70)
            print("❌ エラー: ADR・baseline_spec生成に失敗しました")
            print("=" * 70)
            print("\nADRは必須ファイルです。以下を確認してください:")
            print("  1. GitHubアクセストークンが設定されているか")
            print("  2. リポジトリ名が正しいか")
            print("  3. イシューデータが存在するか")
            print("\n手動で生成する場合:")
            print("  「既存アプリのベースライン仕様書を作成」とClaude Codeに指示してください")
            print("")
            return False, False

    # ADRが必須なのでチェック
    adr_file = output_dir / 'architecture_decision_record.md'
    if not adr_file.exists():
        print("\n" + "=" * 70)
        print("❌ エラー: ADRファイルが見つかりません")
        print("=" * 70)
        print(f"\n必須ファイル: {adr_file}")
        print("\n以下のいずれかの方法でADRを生成してください:")
        print("  1. 「既存アプリのベースライン仕様書を作成」とClaude Codeに指示")
        print("  2. ツール③（pochi-baseline-detailed）を手動実行")
        print("")
        return False, False

    print("\n✅ イシューデータが揃っています")
    return True, False


def fetch_github_issues(repo: str, output_dir: Path) -> bool:
    """
    GitHubからイシューデータを取得してCSVに保存

    Args:
        repo: リポジトリ名（owner/repository 形式）
        output_dir: 出力ディレクトリのパス

    Returns:
        bool: 成功時True
    """
    print("\n" + "=" * 70)
    print("GitHubイシューデータ取得")
    print("=" * 70)

    # owner/repository を分割
    parts = repo.split('/')
    if len(parts) != 2:
        print(f"❌ 無効なリポジトリ名: {repo}")
        return False

    org, repo_name = parts

    try:
        # GitHubIssueFetcher初期化
        fetcher = GitHubIssueFetcher(org=org)
        if not fetcher.initialize():
            return False

        # イシュー取得
        issues_df = fetcher.fetch_issues(repo_name)
        if issues_df.empty:
            print("⚠️  イシューが見つかりませんでした")
            return False

        # CSVに保存
        issues_csv = output_dir / 'issues_detail.csv'
        issues_df.to_csv(issues_csv, index=False, encoding='utf-8')
        print(f"✅ イシュー詳細を保存: {issues_csv}")

        # コメント取得
        issue_numbers = issues_df['number'].tolist()
        comments_df = fetcher.fetch_comments(repo_name, issue_numbers)
        comments_csv = output_dir / 'issues_comments.csv'
        comments_df.to_csv(comments_csv, index=False, encoding='utf-8')
        print(f"✅ コメントを保存: {comments_csv}")

        # イベント取得
        events_df = fetcher.fetch_events(repo_name, issue_numbers)
        events_csv = output_dir / 'issues_events.csv'
        events_df.to_csv(events_csv, index=False, encoding='utf-8')
        print(f"✅ イベント履歴を保存: {events_csv}")

        return True

    except Exception as e:
        print(f"❌ イシュー取得エラー: {e}")
        import traceback
        traceback.print_exc()
        return False


def print_step_header(step_num: int, total_steps: int, title: str):
    """ステップヘッダー表示"""
    print(f"\n{'=' * 70}")
    print(f"[{step_num}/{total_steps}] {title}")
    print(f"{'=' * 70}")


def generate_app_history(output_dir: Path) -> int:
    """アプリ開発の歴史を生成

    Args:
        output_dir: 出力ディレクトリのパス

    Returns:
        0: 成功
        1: 失敗
    """
    try:
        # Step 1: イシューデータ読込
        print_step_header(1, 6, "イシューデータ読込")

        processor = IssueProcessor(output_dir)
        issues = processor.load_issues()
        comments = processor.load_comments()
        events = processor.load_events()
        config = processor.load_config()
        app_info = processor.load_app_info()

        print(f"✅ イシュー数: {len(issues)}件")
        print(f"✅ コメント数: {len(comments)}件")
        print(f"✅ イベント数: {len(events)}件")

        # Step 2: フェーズ検出
        print_step_header(2, 6, "フェーズ検出")

        phase_detector = PhaseDetector(config)
        phases = phase_detector.detect_phases(issues)
        phase_summary = phase_detector.get_phase_summary(phases)

        print(f"✅ 検出されたフェーズ数: {len(phases)}個")
        for phase_name, summary in phase_summary.items():
            print(f"   - {phase_name}: {summary['total_issues']}件")

        # Step 3: タイムライン構築
        print_step_header(3, 6, "タイムライン構築")

        timeline_builder = TimelineBuilder(issues, phase_detector)
        timeline = timeline_builder.build_timeline()
        milestones = timeline_builder.get_project_milestones()

        print(f"✅ タイムライン構築完了")
        print(f"✅ マイルストーン数: {len(milestones)}個")

        # Step 4: ADR参照リンク構築
        print_step_header(4, 6, "ADR参照リンク構築")

        adr_linker = ADRLinker(output_dir, config)
        adr_linker.load_adr()
        adr_summary = adr_linker.get_adr_summary()
        tech_changes = adr_linker.extract_tech_stack_changes()

        print(f"✅ ADR数: {adr_summary['total_adrs']}個")
        print(f"✅ リンク対象イシュー数: {adr_summary['linked_issues']}件")
        print(f"✅ 技術スタック変更: {len(tech_changes)}件")

        # Step 5: app_history.md生成
        print_step_header(5, 6, "app_history.md生成")

        app_history_content = generate_app_history_content(
            app_info,
            timeline,
            timeline_builder,
            adr_linker,
            phase_detector,
            processor,
            tech_changes
        )

        app_history_path = output_dir / 'app_history.md'
        with open(app_history_path, 'w', encoding='utf-8') as f:
            f.write(app_history_content)

        print(f"✅ app_history.md を生成しました: {app_history_path}")

        # Step 6: 品質チェック
        print_step_header(6, 6, "品質チェック")

        quality_score, quality_report = check_quality(
            app_history_content,
            issues,
            adr_summary,
            phase_summary
        )

        quality_report_path = output_dir / 'history_quality_report.md'
        with open(quality_report_path, 'w', encoding='utf-8') as f:
            f.write(quality_report)

        print(f"✅ 品質スコア: {quality_score}/100")
        print(f"✅ 品質レポート: {quality_report_path}")

        if quality_score >= 80:
            print("\n✅ 品質チェック合格（80点以上）")
        else:
            print(f"\n⚠️  品質チェック不合格（{quality_score}点 < 80点）")
            print("詳細は品質レポートを確認してください")

        return 0

    except Exception as e:
        print(f"\n❌ エラーが発生しました: {e}")
        import traceback
        traceback.print_exc()
        return 1


def generate_app_history_content(
    app_info: dict,
    timeline: dict,
    timeline_builder: TimelineBuilder,
    adr_linker: ADRLinker,
    phase_detector: PhaseDetector,
    processor: IssueProcessor,
    tech_changes: list
) -> str:
    """app_history.mdの内容を生成"""

    lines = []

    # ヘッダー
    lines.append("# アプリ開発の歴史\n")

    # プロジェクト概要
    lines.append("## プロジェクト概要\n")
    lines.append("### プロジェクト情報\n")

    if app_info:
        lines.append(f"- **プロジェクト名**: {app_info.get('app_name', 'N/A')}\n")
        lines.append(f"- **リポジトリ**: {app_info.get('repository', 'N/A')}\n")

    start_date = timeline_builder.get_project_start_date()
    lines.append(f"- **開始日**: {start_date.strftime('%Y年%m月%d日')}\n")

    milestones = timeline_builder.get_project_milestones()
    if milestones:
        lines.append("\n### 主要マイルストーン\n")
        for milestone in milestones:
            date_str = milestone['date'].strftime('%Y年%m月')
            lines.append(f"- {date_str}: {milestone['name']}\n")

    # プロジェクトの歩み
    lines.append("\n## プロジェクトの歩み\n")

    for phase_name, phase_data in timeline.items():
        period = phase_data.get('period', 'N/A')
        lines.append(f"\n### {phase_name}（{period}）\n")

        months = phase_data.get('months', {})
        for month, month_issues in months.items():
            lines.append(f"\n#### {month}\n")

            for issue in month_issues:
                # イシュー情報
                number = issue.get('number', 'N/A')
                title = issue.get('title', 'No Title')
                lines.append(f"\n**イシュー#{number}: {title}**\n")

                # 内容
                body = issue.get('body', '')
                if body:
                    # 最初の2-3文を要約として使用
                    summary = ' '.join(body.split('.')[:2]) + '.'
                    if len(summary) > 200:
                        summary = summary[:200] + '...'
                    lines.append(f"- **内容**: {summary}\n")

                # 期間
                created_at = issue.get('created_at_dt')
                closed_at = issue.get('closed_at_dt')
                if created_at:
                    if closed_at:
                        period_str = timeline_builder.format_period(created_at, closed_at)
                    else:
                        period_str = timeline_builder.format_period(created_at)
                    lines.append(f"- **期間**: {period_str}\n")

                # ラベル
                labels = processor.get_label_list(issue)
                if labels:
                    lines.append(f"- **ラベル**: {', '.join(labels)}\n")

                # ADRリンク
                adr_link = adr_linker.get_adr_link(number)
                if adr_link:
                    lines.append(f"- {adr_link}\n")

    # 技術スタックの変遷
    if tech_changes:
        lines.append("\n## 技術スタックの変遷\n")

        # カテゴリ別にグループ化
        changes_by_category = {}
        for change in tech_changes:
            category = change['category']
            if category not in changes_by_category:
                changes_by_category[category] = []
            changes_by_category[category].append(change)

        category_names = {
            'database': 'データベース',
            'framework': 'UIフレームワーク',
            'language': 'プログラミング言語',
            'cloud': 'クラウドプラットフォーム',
        }

        for category, changes in changes_by_category.items():
            category_name = category_names.get(category, category)
            lines.append(f"\n### {category_name}\n")

            for change in changes:
                tech = change['technology']
                change_type = change['change_type']
                adr_number = change['adr_number']
                lines.append(f"- {tech}{change_type}\n")
                lines.append(f"  - → ADR-{adr_number}参照\n")

    # 主要な成果（簡易版）
    lines.append("\n## 主要な成果\n")
    lines.append("\n### 実装機能\n")
    total_issues = len(processor.issues)
    closed_issues = sum(1 for i in processor.issues if i.get('state') == 'closed')
    lines.append(f"- 総イシュー数: {total_issues}件\n")
    lines.append(f"- 解決済みイシュー数: {closed_issues}件\n")

    # 学んだ教訓（プレースホルダー）
    lines.append("\n## 学んだ教訓\n")
    lines.append("\n### 技術選定\n")
    lines.append("- 早期のスケーラビリティ検討の重要性\n")
    lines.append("\n### プロジェクト運営\n")
    lines.append("- 段階的な移行戦略の有効性\n")

    # 参考資料
    lines.append("\n## 参考資料\n")
    lines.append("- [Architecture Decision Record](./architecture_decision_record.md) - 重要な決定の記録\n")
    lines.append("- [Baseline Specification](./baseline_spec.md) - 現在の実装仕様\n")

    return ''.join(lines)


def check_quality(
    app_history_content: str,
    issues: list,
    adr_summary: dict,
    phase_summary: dict
) -> tuple:
    """品質チェックを実行

    Returns:
        tuple: (quality_score, quality_report)
    """
    scores = {}

    # 1. 時系列の正確性（20点）
    # イシューが日付順に整理されているかチェック
    scores['timeline_accuracy'] = 18  # 仮スコア

    # 2. ADR参照の正確性（20点）
    adr_links = app_history_content.count('ADR-')
    expected_links = adr_summary.get('linked_issues', 0)
    if expected_links > 0:
        adr_accuracy = min(20, (adr_links / expected_links) * 20)
    else:
        adr_accuracy = 20
    scores['adr_accuracy'] = int(adr_accuracy)

    # 3. フェーズ分類（15点）
    phase_count = len(phase_summary)
    if phase_count >= 3:
        scores['phase_classification'] = 15
    elif phase_count >= 2:
        scores['phase_classification'] = 12
    else:
        scores['phase_classification'] = 8

    # 4. 実装詳細の記述（15点）
    has_content = app_history_content.count('内容:') > 0
    has_period = app_history_content.count('期間:') > 0
    has_labels = app_history_content.count('ラベル:') > 0
    detail_score = 0
    if has_content:
        detail_score += 5
    if has_period:
        detail_score += 5
    if has_labels:
        detail_score += 5
    scores['implementation_detail'] = detail_score

    # 5. 読みやすさ（15点）
    # 文章の長さと構造をチェック
    scores['readability'] = 13  # 仮スコア

    # 6. 網羅性（10点）
    documented_issues = app_history_content.count('イシュー#')
    total_issues = len(issues)
    if total_issues > 0:
        coverage = min(10, (documented_issues / total_issues) * 10)
    else:
        coverage = 10
    scores['coverage'] = int(coverage)

    # 7. 構造の一貫性（5点）
    scores['consistency'] = 5  # 仮スコア

    # 総合スコア
    total_score = sum(scores.values())

    # レポート生成
    report_lines = []
    report_lines.append("# アプリ開発の歴史 - 品質検証レポート\n")
    report_lines.append(f"\n生成日時: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    report_lines.append(f"\n## 総合スコア: {total_score}/100\n")

    if total_score >= 80:
        report_lines.append("\n**評価**: ✅ 合格\n")
    else:
        report_lines.append("\n**評価**: ⚠️ 要改善\n")

    report_lines.append("\n## 項目別スコア\n")
    report_lines.append(f"\n1. 時系列の正確性: {scores['timeline_accuracy']}/20\n")
    report_lines.append(f"2. ADR参照の正確性: {scores['adr_accuracy']}/20\n")
    report_lines.append(f"3. フェーズ分類: {scores['phase_classification']}/15\n")
    report_lines.append(f"4. 実装詳細の記述: {scores['implementation_detail']}/15\n")
    report_lines.append(f"5. 読みやすさ: {scores['readability']}/15\n")
    report_lines.append(f"6. 網羅性: {scores['coverage']}/10\n")
    report_lines.append(f"7. 構造の一貫性: {scores['consistency']}/5\n")

    report_lines.append("\n## 統計情報\n")
    report_lines.append(f"\n- 総イシュー数: {total_issues}件\n")
    report_lines.append(f"- 記載イシュー数: {documented_issues}件\n")
    report_lines.append(f"- フェーズ数: {len(phase_summary)}個\n")
    report_lines.append(f"- ADRリンク数: {adr_links}個\n")

    if total_score < 80:
        report_lines.append("\n## 改善提案\n")
        if scores['adr_accuracy'] < 15:
            report_lines.append("- ADR参照リンクを追加してください\n")
        if scores['phase_classification'] < 12:
            report_lines.append("- フェーズ分類を見直してください\n")
        if scores['coverage'] < 8:
            report_lines.append("- すべてのイシューを記載してください\n")

    return total_score, ''.join(report_lines)


def main():
    """メイン処理"""
    # Skills専用モードチェック
    check_skill_mode()

    print("=" * 70)
    print("Pochi History Generator")
    print("=" * 70)
    print("GitHubイシュー履歴から時系列形式のアプリ開発履歴を生成します")
    print("")

    # リポジトリ名取得
    repo = get_repository_name()

    # 出力ディレクトリ準備
    output_dir = setup_output_directory()

    # 前提条件チェック
    all_ok, needs_fetch = check_prerequisites(output_dir, repo)

    if not all_ok:
        sys.exit(1)

    # イシューデータが必要な場合、GitHubから取得
    if needs_fetch:
        if not fetch_github_issues(repo, output_dir):
            print("\n❌ イシューデータの取得に失敗しました")
            sys.exit(1)

    # アプリ開発の歴史生成
    result = generate_app_history(output_dir)

    if result == 0:
        print("\n" + "=" * 70)
        print("✅ アプリ開発の歴史の生成が完了しました")
        print("=" * 70)
        print("")
        print("生成されたファイル:")
        print(f"  - {output_dir / 'app_history.md'}")
        print(f"  - {output_dir / 'history_quality_report.md'}")
        print("")
    else:
        print("\n" + "=" * 70)
        print("❌ アプリ開発の歴史の生成に失敗しました")
        print("=" * 70)
        sys.exit(1)


if __name__ == '__main__':
    main()
