#!/usr/bin/env python3
"""
Phase 1ワークフロー統合スクリプト

ベースライン仕様書作成の全プロセスを統合し、
複数のスクリプト実行を1回のコマンドで完了します。

使用例:
    # 基本的な使い方（全ステップ実行）
    python scripts/run_baseline_workflow.py
    
    # データ収集から開始
    python scripts/run_baseline_workflow.py --with-data-collection
    
    # 特定のステップから開始
    python scripts/run_baseline_workflow.py --start-from adr

出力:
    output/workflows/baseline/
    ├── step1_adr_classification.md        (Clineで実行)
    ├── step2_adr_generation.md            (Clineで実行)
    ├── step3_baseline_generation.md       (Clineで実行)
    ├── step4_history_generation.md        (Clineで実行)
    └── step5_quality_check.md             (Clineで実行)
"""

import sys
import argparse
import subprocess
from pathlib import Path
from typing import List, Dict, Optional
import shutil


class WorkflowStep:
    """ワークフローの各ステップを表すクラス"""
    
    def __init__(
        self,
        name: str,
        description: str,
        script: Optional[str] = None,
        args: Optional[List[str]] = None,
        output_file: Optional[str] = None,
        required_files: Optional[List[str]] = None,
        optional_files: Optional[List[str]] = None
    ):
        self.name = name
        self.description = description
        self.script = script
        self.args = args or []
        self.output_file = output_file
        self.required_files = required_files or []
        self.optional_files = optional_files or []
    
    def check_prerequisites(self, repo_root: Path) -> tuple[bool, List[str]]:
        """前提条件のチェック"""
        missing = []
        for req_file in self.required_files:
            if not (repo_root / req_file).exists():
                missing.append(req_file)
        return len(missing) == 0, missing
    
    def execute(self, repo_root: Path) -> bool:
        """ステップを実行"""
        if not self.script:
            return True
        
        cmd = ["python", self.script] + self.args
        print(f"\n🔧 実行中: {' '.join(cmd)}")
        print()  # 空行を追加して見やすく
        
        try:
            # リアルタイム出力を有効化（capture_output=Trueを削除）
            result = subprocess.run(
                cmd,
                cwd=repo_root,
                check=False  # エラーでも例外を発生させない
            )
            
            print()  # 空行を追加
            if result.returncode == 0:
                print("✅ 成功")
                return True
            else:
                print(f"❌ エラー（終了コード: {result.returncode}）")
                return False
                
        except Exception as e:
            print(f"❌ 実行エラー: {e}")
            return False


class BaselineWorkflow:
    """Phase 1ワークフロー管理クラス"""
    
    def __init__(
        self,
        repo_root: Path,
        repo_name: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ):
        self.repo_root = repo_root
        self.repo_name = repo_name
        self.start_date = start_date
        self.end_date = end_date
        self.output_dir = repo_root / "spec-driven-development" / "output"
        self.steps = self._define_steps()
    
    def _define_steps(self) -> List[WorkflowStep]:
        """ワークフローステップの定義"""
        # data_collectionステップの引数を構築
        data_collection_args = ["--repo", self.repo_name] if self.repo_name else []
        if self.start_date:
            data_collection_args.extend(["--start-date", self.start_date])
        if self.end_date:
            data_collection_args.extend(["--end-date", self.end_date])
        
        return [
            WorkflowStep(
                name="data_collection",
                description="イシューデータの取得",
                script="spec-driven-development/scripts/issue_detail_fetcher.py",
                args=data_collection_args,
                required_files=[]
            ),
            WorkflowStep(
                name="app_info",
                description="アプリケーション情報の抽出",
                script="spec-driven-development/scripts/extract_app_info.py",
                output_file="spec-driven-development/output/app_info.json",
                required_files=[]
            ),
            WorkflowStep(
                name="adr_classification",
                description="ADR候補分類プロンプトの生成",
                script="spec-driven-development/scripts/prepare_adr_prompt.py",
                output_file="spec-driven-development/output/classify_adr_issues_ready.md",
                required_files=[
                    "spec-driven-development/output/issues_detail.csv",
                    "spec-driven-development/output/app_info.json"
                ]
            ),
            WorkflowStep(
                name="skeleton_generation",
                description="骨格版仕様書の生成（DRY-RUN）",
                script="spec-driven-development/scripts/generate_baseline_spec.py",
                args=["--input-dir", "spec-driven-development/output", "--output-dir", "spec-driven-development/output"],
                required_files=[
                    "spec-driven-development/output/baseline_spec_config.json"
                ]
            ),
            WorkflowStep(
                name="adr_prompt",
                description="ADR生成プロンプトの準備",
                script="spec-driven-development/scripts/prepare_baseline_spec_prompt.py",
                args=["--mode", "adr", "--output", "spec-driven-development/output/adr_generation_ready.md"],
                output_file="spec-driven-development/output/adr_generation_ready.md",
                required_files=[
                    "spec-driven-development/output/architecture_decision_record.md",
                    "spec-driven-development/output/baseline_spec_config.json",
                    "spec-driven-development/output/app_info.json"
                ]
            ),
            WorkflowStep(
                name="baseline_prompt",
                description="baseline_spec生成プロンプトの準備",
                script="spec-driven-development/scripts/prepare_baseline_spec_prompt.py",
                args=["--mode", "baseline", "--output", "spec-driven-development/output/baseline_generation_ready.md"],
                output_file="spec-driven-development/output/baseline_generation_ready.md",
                required_files=[
                    "spec-driven-development/output/baseline_spec.md",
                    "spec-driven-development/output/architecture_decision_record.md",
                    "spec-driven-development/output/baseline_spec_config.json",
                    "spec-driven-development/output/app_info.json"
                ]
            ),
            WorkflowStep(
                name="history_prompt",
                description="開発の歴史生成プロンプトの準備",
                script="spec-driven-development/scripts/prepare_baseline_spec_prompt.py",
                args=["--mode", "history", "--output", "spec-driven-development/output/history_generation_ready.md"],
                output_file="spec-driven-development/output/history_generation_ready.md",
                required_files=[
                    "spec-driven-development/output/baseline_spec.md",
                    "spec-driven-development/output/architecture_decision_record.md",
                    "spec-driven-development/output/baseline_spec_config.json",
                    "spec-driven-development/output/app_info.json"
                ]
            )
        ]
    
    def check_all_prerequisites(self) -> tuple[bool, Dict[str, List[str]]]:
        """全ステップの前提条件をチェック"""
        all_ok = True
        missing_by_step = {}
        
        for step in self.steps:
            ok, missing = step.check_prerequisites(self.repo_root)
            if not ok:
                all_ok = False
                missing_by_step[step.name] = missing
        
        return all_ok, missing_by_step
    
    def run(
        self,
        start_from: Optional[str] = None
    ) -> bool:
        """ワークフローを実行"""
        print("\n" + "="*70)
        print("Phase 1: ベースライン仕様書作成ワークフロー")
        print("="*70)
        
        # 出力ディレクトリの準備
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # ステップの開始位置を決定
        start_index = 0
        if start_from:
            for i, step in enumerate(self.steps):
                if step.name == start_from:
                    start_index = i
                    break
        
        # Phase 1a（データ準備フェーズ）とPhase 1b（仕様書生成フェーズ）の境界
        phase_boundary = 3  # ステップ3（adr_classification）まで自動実行
        
        # ステップを順次実行
        for i, step in enumerate(self.steps[start_index:], start=start_index + 1):
            print(f"\n{'='*70}")
            print(f"ステップ{i}: {step.description}")
            print(f"{'='*70}")
            
            # 前提条件チェック
            if step.name != "data_collection":
                ok, missing = step.check_prerequisites(self.repo_root)
                if not ok:
                    print(f"\n⚠️  前提条件が満たされていません:")
                    for f in missing:
                        print(f"   - {f}")
                    
                    if step.name == "skeleton_generation":
                        print("\n💡 これは正常な動作です。")
                        print("   Phase 1aが完了しました。次はClineでプロンプトを実行してください。")
                    
                    # Phase境界での停止は正常終了
                    if i == phase_boundary + 1:
                        self._print_phase1a_completion()
                        return True
                    
                    print("\n❌ ワークフローを中断します")
                    return False
            
            # ステップ実行
            if step.script:
                success = step.execute(self.repo_root)
                if not success:
                    print(f"\n❌ ステップ{i}が失敗しました")
                    return False
            
            # skeleton_generation完了後は必ず停止（DRY-RUN → APPLY の手動実行が必要）
            if step.name == "skeleton_generation":
                self._print_skeleton_completion()
                return True
            
            # Phase 1aの最後のステップ完了後
            if i == phase_boundary and start_index == 0:
                self._print_phase1a_completion()
                return True
        
        # 全ステップ完了（Phase 1b完了）
        # 完了メッセージ
        self._print_completion_message()
        
        return True
    
    def _print_skeleton_completion(self):
        """skeleton_generation完了メッセージを表示"""
        print("\n" + "="*70)
        print("✅ Phase 1b-1: 骨格版仕様書の生成（DRY-RUN）完了！")
        print("="*70)
        
        print("\n📋 完了内容:")
        print("  - マージレポートを生成しました（差分検出のみ、ファイルは未更新）")
        
        merge_report = self.repo_root / "spec-driven-development" / "output" / "spec_merge_report_*.md"
        print(f"\n📄 マージレポート:")
        print(f"   spec-driven-development/output/spec_merge_report_YYYYMMDD.md")
        
        print("\n🎯 次のアクション: マージレポートを確認して--applyフラグで実行\n")
        
        print("【手順】")
        print("1. マージレポートを確認:")
        print("   cat spec-driven-development/output/spec_merge_report_*.md")
        print()
        print("2. 問題がなければ、--applyフラグで骨格版仕様書を生成:")
        print("   python spec-driven-development/scripts/generate_baseline_spec.py \\")
        print("     --config spec-driven-development/output/baseline_spec_config.json \\")
        print("     --input-dir spec-driven-development/output \\")
        print("     --output-dir spec-driven-development/output \\")
        print("     --apply")
        print()
        print("3. 生成されたファイルを確認:")
        print("   - baseline_spec.md（骨格版）")
        print("   - architecture_decision_record.md（骨格版）")
        print()
        print("4. 確認後、Phase 1b-2を続行（プロンプト準備）:")
        
        cmd_parts = [
            "python spec-driven-development/scripts/run_baseline_workflow.py",
            f"--repo {self.repo_name}",
        ]
        
        if self.start_date:
            cmd_parts.append(f"--start-date {self.start_date}")
        if self.end_date:
            cmd_parts.append(f"--end-date {self.end_date}")
        
        cmd_parts.append("--start-from adr_prompt")
        
        separator = ' \\\n     '
        print(f"   {separator.join(cmd_parts)}")
        
        print("\n💡 重要:")
        print("  - DRY-RUNモードではファイルは更新されません")
        print("  - 必ず--applyフラグで実行してファイルを生成してください")
        print("  - 生成されたファイルがないと、次のステップ（adr_prompt）が実行できません")
    
    def _print_phase1a_completion(self):
        """Phase 1a完了メッセージを表示"""
        print("\n" + "="*70)
        print("✅ Phase 1a: データ準備フェーズ完了！")
        print("="*70)
        
        print("\n📋 完了したステップ:")
        print("  1. ✅ イシューデータの取得")
        print("  2. ✅ アプリケーション情報の抽出")
        print("  3. ✅ ADR候補分類プロンプトの生成")
        
        print("\n🎯 次のアクション: Clineでプロンプトを実行してください\n")
        
        print("【手順】")
        print(f"1. 以下のファイルをClineに送信:")
        prompt_path = self.repo_root / "spec-driven-development" / "output" / "classify_adr_issues_ready.md"
        print(f"   📄 {prompt_path}")
        print()
        print("2. Clineが以下を自動生成します:")
        print("   - baseline_spec_config.json（イシュー分類結果）")
        print("   - architecture_decision_record.md（骨格版）")
        print()
        print("3. 生成完了後、以下のコマンドでPhase 1bを続行:")
        
        cmd_parts = [
            "python spec-driven-development/scripts/run_baseline_workflow.py",
            f"--repo {self.repo_name}",
        ]
        
        if self.start_date:
            cmd_parts.append(f"--start-date {self.start_date}")
        if self.end_date:
            cmd_parts.append(f"--end-date {self.end_date}")
        
        cmd_parts.append("--start-from skeleton_generation")
        
        separator = ' \\\n     '
        print(f"   {separator.join(cmd_parts)}")
        
        print("\n💡 ヒント:")
        print("  - Clineの実行には5-10分程度かかります")
        print("  - baseline_spec_config.jsonの内容は必要に応じて手動修正可能です")
        print("  - 問題があれば、プロンプトを修正して再実行できます")
    
    
    def _print_completion_message(self):
        """完了メッセージを表示"""
        print("\n" + "="*70)
        print("✅ Phase 1ワークフロー準備完了！")
        print("="*70)
        
        print("\n📋 生成されたファイル:\n")
        
        generated_files = [
            ("classify_adr_issues_ready.md", "ADR候補分類プロンプト"),
            ("adr_generation_ready.md", "ADR生成プロンプト"),
            ("baseline_generation_ready.md", "baseline_spec生成プロンプト"),
            ("history_generation_ready.md", "開発の歴史生成プロンプト"),
            ("baseline_spec.md", "ベースライン仕様書（骨格版）"),
            ("architecture_decision_record.md", "アーキテクチャ決定記録（骨格版）"),
        ]
        
        for i, (filename, desc) in enumerate(generated_files, 1):
            file_path = self.output_dir / filename
            if file_path.exists():
                print(f"  ✅ {desc}")
                print(f"     📄 {self.output_dir.relative_to(self.repo_root)}/{filename}")
            else:
                print(f"  ⚠️  {desc}")
                print(f"     📄 {self.output_dir.relative_to(self.repo_root)}/{filename} (未生成)")
        
        print("\n💡 次のステップ:")
        print("  1. 上記のプロンプトファイルをClineに送信して仕様書を完成させる")
        print("  2. 生成された仕様書をレビュー")
        print("  3. 必要に応じて品質チェックプロンプトで検証")
        
        print(f"\n 出力ディレクトリ: {self.output_dir.relative_to(self.repo_root)}")


def main():
    """メイン処理"""
    parser = argparse.ArgumentParser(
        description="Phase 1ベースライン仕様書作成の統合ワークフロー",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用例:
  # リポジトリ名を指定して実行（イシューデータ取得から全自動）
  python scripts/run_baseline_workflow.py --repo リポジトリ名
  
  # 例：pochi-d-pay-merchant-visualizer-repository
  python scripts/run_baseline_workflow.py --repo pochi-d-pay-merchant-visualizer-repository
  
  # 特定のステップから開始
  python scripts/run_baseline_workflow.py --repo リポジトリ名 --start-from adr_prompt
  
ステップ名:
  data_collection       - イシューデータの取得
  app_info              - アプリ情報抽出
  adr_classification    - ADR候補分類
  skeleton_generation   - 骨格版生成
  adr_prompt            - ADR生成プロンプト準備
  baseline_prompt       - baseline_spec生成プロンプト準備
  history_prompt        - 開発の歴史生成プロンプト準備
"""
    )
    
    parser.add_argument(
        "--repo",
        type=str,
        required=True,
        help="リポジトリ名（例: pochi-d-pay-merchant-visualizer-repository）"
    )
    
    parser.add_argument(
        "--start-date",
        type=str,
        help="イシュー取得の開始日（形式: YYYY-MM-DD、例: 2025-08-01）。省略時は全期間"
    )
    
    parser.add_argument(
        "--end-date",
        type=str,
        help="イシュー取得の終了日（形式: YYYY-MM-DD、例: 2025-11-30）。省略時は全期間"
    )
    
    parser.add_argument(
        "--start-from",
        choices=[
            "data_collection",
            "app_info",
            "adr_classification",
            "skeleton_generation",
            "adr_prompt",
            "baseline_prompt",
            "history_prompt"
        ],
        help="開始するステップを指定"
    )
    
    args = parser.parse_args()
    
    # リポジトリルートを取得
    repo_root = Path.cwd()
    
    # ワークフロー実行
    workflow = BaselineWorkflow(
        repo_root,
        repo_name=args.repo,
        start_date=args.start_date,
        end_date=args.end_date
    )
    
    try:
        success = workflow.run(
            start_from=args.start_from
        )
        
        if success:
            sys.exit(0)
        else:
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\n\n⚠️  ユーザーによって中断されました")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ エラーが発生しました: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
