"""
Orchestrator クラステンプレート

役割:
- パターン判定
- 前提ファイルの準備
- generation_context.json生成
- prompts_last_run.md生成
"""
from enum import Enum
from pathlib import Path
import subprocess
import json


class Pattern(Enum):
    """実行パターンの列挙型

    カスタマイズポイント:
    - パターンの追加・削除
    - パターン名の変更
    """

    PATTERN1_INITIAL = "pattern1_initial"  # 初回生成
    PATTERN2_UPDATE = "pattern2_update"  # 更新
    # 必要に応じてパターンを追加


class Orchestrator:
    """オーケストレーター

    責務:
    - パターン判定
    - 前提ファイルの準備
    - generation_context.json生成
    - prompts_last_run.md生成
    """

    def __init__(self, state):
        """初期化

        Args:
            state: SkillStateインスタンス
        """
        self.state = state
        self.logger = state.logger

    def determine_pattern(self) -> tuple[Pattern, dict]:
        """実行パターンを判定

        カスタマイズポイント:
        - パターン判定ロジックの実装
        - 判定条件の追加

        Returns:
            (Pattern, 詳細情報)
        """
        self.logger.info("パターン判定を開始")

        # パターン判定ロジックを実装
        # 例: ファイルの存在チェック、Git差分チェックなど

        # 例1: ファイルの存在チェック
        target_file = Path(self.state.repo_root) / "target_file.txt"
        if not target_file.exists():
            self.logger.info("パターン1: 初回生成")
            return Pattern.PATTERN1_INITIAL, {"reason": "ターゲットファイルなし"}

        # 例2: Git差分チェック
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only", "main...HEAD"],
                cwd=self.state.repo_root,
                capture_output=True,
                text=True,
                check=True,
            )
            changed_files = [f.strip() for f in result.stdout.split("\n") if f.strip()]

            if changed_files:
                self.logger.info("パターン2: 更新")
                return Pattern.PATTERN2_UPDATE, {
                    "reason": "ファイル変更あり",
                    "changed_files": changed_files,
                }
        except subprocess.CalledProcessError:
            self.logger.warning("Git差分取得失敗")

        # デフォルト: パターン1
        self.logger.info("パターン1: 初回生成（デフォルト）")
        return Pattern.PATTERN1_INITIAL, {"reason": "デフォルト"}

    def prepare_prerequisites(self, pattern: Pattern) -> bool:
        """前提ファイルを準備

        カスタマイズポイント:
        - 必要な前提ファイルの生成
        - パターンごとの処理の追加

        Args:
            pattern: 実行パターン

        Returns:
            成功したかどうか
        """
        self.logger.info(f"前提ファイルを準備: {pattern.value}")

        # 必要に応じて前提ファイルを生成
        # 例: app_structure.md, requirements.txt の解析など

        try:
            # 例: app_structure.md の生成
            structure_path = self.state.get_path("app_structure.md")
            structure_content = self._generate_app_structure()

            with open(structure_path, "w", encoding="utf-8") as f:
                f.write(structure_content)

            self.logger.info(f"前提ファイル生成: {structure_path}")
            return True

        except Exception as e:
            self.logger.error(f"前提ファイル生成失敗: {e}")
            return False

    def _generate_app_structure(self) -> str:
        """アプリケーション構造を生成

        カスタマイズポイント:
        - 実際のディレクトリ構造を解析して生成

        Returns:
            アプリケーション構造のMarkdown
        """
        # 実装例
        return """# アプリケーション構造

## ディレクトリ構成
```
src/
├── feature.py
└── utils.py

tests/
├── test_feature.py
└── test_utils.py
```
"""

    def prepare_context(self, pattern: Pattern, details: dict) -> dict:
        """generation_context.jsonを生成

        カスタマイズポイント:
        - パターンごとのコンテキスト情報の追加
        - 必要なファイルパスの追加

        Args:
            pattern: 実行パターン
            details: パターン判定の詳細情報

        Returns:
            コンテキスト辞書
        """
        self.logger.info("コンテキストを生成中")

        context = {
            "pattern": pattern.value,
            "pattern_details": details,
            "target_files": [],
            "prerequisite_files": {},
            "metadata": {
                "run_id": self.state.run_id,
                "timestamp": self.state.summary["timestamp"],
                "skill_version": "1.0.0",
            },
        }

        # パターンごとの情報追加
        if pattern == Pattern.PATTERN1_INITIAL:
            # 初回生成: すべての対象ファイルを追加
            src_dir = Path(self.state.repo_root) / "src"
            if src_dir.exists():
                context["target_files"] = [
                    str(f.resolve()) for f in src_dir.glob("**/*.py")
                ]

            # 前提ファイル
            context["prerequisite_files"] = {
                "spec": self.state.get_repo_path("docs/spec.md"),
                "app_structure": self.state.get_path("app_structure.md"),
            }

        elif pattern == Pattern.PATTERN2_UPDATE:
            # 更新: 変更されたファイルのみ
            context["target_files"] = [
                self.state.get_repo_path(f)
                for f in details.get("changed_files", [])
            ]

        # コンテキストファイルに書き込み
        context_path = self.state.get_path("generation_context.json")
        with open(context_path, "w", encoding="utf-8") as f:
            json.dump(context, f, ensure_ascii=False, indent=2)

        self.logger.info(f"コンテキスト生成: {context_path}")

        # トークン使用量をログ
        self.state.log_token_usage("context_generation", json.dumps(context))

        return context

    def generate_prompt(self, pattern: Pattern, context: dict) -> str:
        """prompts_last_run.mdを生成

        カスタマイズポイント:
        - パターンごとのプロンプトの作成
        - 必須要件の追加
        - 禁止事項の追加

        Args:
            pattern: 実行パターン
            context: コンテキスト情報

        Returns:
            プロンプト文字列
        """
        self.logger.info("プロンプトを生成中")

        # プロンプトテンプレートを読み込み（パターンごと）
        prompt_template_path = self.state.prompts_dir / f"{pattern.value}.md"

        if prompt_template_path.exists():
            # テンプレートファイルがある場合
            with open(prompt_template_path, "r", encoding="utf-8") as f:
                prompt = f.read()
        else:
            # デフォルトプロンプト
            prompt = self._generate_default_prompt(pattern, context)

        # プロンプトファイルに書き込み
        prompt_path = self.state.get_path("prompts_last_run.md")
        with open(prompt_path, "w", encoding="utf-8") as f:
            f.write(prompt)

        self.logger.info(f"プロンプト生成: {prompt_path}")

        # トークン使用量をログ
        self.state.log_token_usage("subagent_input", prompt)

        return prompt

    def _generate_default_prompt(self, pattern: Pattern, context: dict) -> str:
        """デフォルトプロンプトを生成

        カスタマイズポイント:
        - プロンプトの内容を実装

        Args:
            pattern: 実行パターン
            context: コンテキスト情報

        Returns:
            プロンプト文字列
        """
        prompt = f"""# [タスク名]指示

## パターン: {pattern.value}

## 対象ファイル
"""
        for file in context.get("target_files", []):
            prompt += f"- `{file}`\n"

        prompt += """
## 参照ファイル
- generation_context.json: 詳細なコンテキスト情報
"""

        for name, path in context.get("prerequisite_files", {}).items():
            prompt += f"- {name}: `{path}`\n"

        prompt += """
## 必須要件
1. [要件1]
2. [要件2]
3. [要件3]

## 禁止事項
- 実装ファイルの変更
- 問い返し（必ず厳格サマリを返却）

## 返却フォーマット
厳格サマリのみを返却してください。中間プロセスは破棄してください。

### 必須項目
1. 生成ファイル一覧（絶対パス、行数）
2. 品質指標
3. エラー・警告
4. 次のステップ

### 例
```
# [タスク名]結果サマリ

## 生成ファイル
- /home/user/repo/[ファイルパス] ([行数]行)

## 品質指標
- [指標1]: [値]
- [指標2]: [値]

## エラー・警告
なし

## 次のステップ
[次に実行すべきアクション]
```
"""

        return prompt


# カスタマイズポイント:
# 1. Pattern Enum: パターンの追加・削除
# 2. determine_pattern: パターン判定ロジックの実装
# 3. prepare_prerequisites: 前提ファイル生成の実装
# 4. prepare_context: コンテキスト情報の追加
# 5. generate_prompt: プロンプトの内容をカスタマイズ
