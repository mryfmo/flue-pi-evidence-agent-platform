"""
SkillState クラステンプレート

役割:
- 絶対パスの一元管理
- ロガーの設定
- サマリの読み書き
- バックアップの管理
"""
import os
import sys
import logging
from pathlib import Path
from datetime import datetime
import json
import hashlib


class SkillState:
    """Skillの状態管理クラス

    このクラスは、Skillの実行状態を管理します。

    主な責務:
    - 絶対パスの一元管理（相対パスは一切使用しない）
    - ロガーの設定（ファイル + コンソール）
    - サマリの読み書き（実行結果の記録）
    - バックアップの管理（ファイル変更時の安全性確保）
    """

    def __init__(self, repo_root: str = None):
        """初期化

        Args:
            repo_root: リポジトリのルートパス（省略時は環境変数から取得）

        Raises:
            ValueError: REPO_ROOT環境変数が設定されていない
            FileNotFoundError: Skillディレクトリが存在しない
        """
        # 1. リポジトリルートの決定
        if repo_root is None:
            repo_root = os.environ.get("REPO_ROOT")
            if not repo_root:
                raise ValueError("REPO_ROOT環境変数が設定されていません")

        # 2. 絶対パスに変換
        self.repo_root = Path(repo_root).resolve()

        # 3. Skillディレクトリ
        skill_name = os.environ.get("SKILL_NAME", "your-skill-name")
        self.skill_dir = self.repo_root / ".claude/skills" / skill_name

        if not self.skill_dir.exists():
            raise FileNotFoundError(
                f"Skillディレクトリが存在しません: {self.skill_dir}"
            )

        # 4. 主要ディレクトリ
        self.core_dir = self.skill_dir / "core"
        self.config_dir = self.skill_dir / "config"
        self.prompts_dir = self.skill_dir / "prompts"
        self.logs_dir = self.skill_dir / "logs"

        # 5. ログディレクトリ作成
        self.logs_dir.mkdir(parents=True, exist_ok=True)

        # 6. run_id生成（タイムスタンプ + ランダム文字列）
        self.run_id = self._generate_run_id()

        # 7. ロガー設定
        self.logger = self._setup_logger()

        # 8. パス辞書（よく使うパスをまとめる）
        self.paths = {
            "root": str(self.repo_root),
            "skill": str(self.skill_dir),
            "core": str(self.core_dir),
            "config": str(self.config_dir),
            "prompts": str(self.prompts_dir),
            "logs": str(self.logs_dir),
        }

        # 9. サマリ（実行結果を記録）
        self.summary = {
            "run_id": self.run_id,
            "timestamp": datetime.now().isoformat(),
            "repo_root": str(self.repo_root),
            "skill_name": skill_name,
            "status": "initialized",
            "token_usage": {
                "context_generation": 0,
                "subagent_input": 0,
                "subagent_output": 0,
                "total": 0,
            },
        }

        # ログ出力
        self.logger.info(f"SkillState初期化完了: {skill_name}")
        self.logger.info(f"Run ID: {self.run_id}")
        self.logger.info(f"Repository Root: {self.repo_root}")

    def _generate_run_id(self) -> str:
        """run_id生成

        run_idは、タイムスタンプとランダム文字列を組み合わせて生成します。
        これにより、各実行を一意に識別できます。

        Returns:
            run_id（例: 20260123_143022_abc123）
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        random_str = hashlib.md5(str(datetime.now()).encode()).hexdigest()[:6]
        return f"{timestamp}_{random_str}"

    def _setup_logger(self) -> logging.Logger:
        """ロガーのセットアップ

        ファイルハンドラ（ログファイルに出力）とコンソールハンドラ（標準出力）を設定します。

        Returns:
            設定済みロガー
        """
        logger = logging.getLogger(f"skill.{self.run_id}")
        logger.setLevel(logging.INFO)

        # ハンドラがすでに設定されている場合はスキップ
        if logger.handlers:
            return logger

        # ファイルハンドラ（DEBUGレベル）
        log_file = self.logs_dir / f"run_{self.run_id}.log"
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setLevel(logging.DEBUG)

        # コンソールハンドラ（INFOレベル）
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.INFO)

        # フォーマッター
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
        )
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)

        logger.addHandler(fh)
        logger.addHandler(ch)

        return logger

    def get_path(self, relative_path: str) -> str:
        """Skillディレクトリ基準の絶対パスを取得

        Args:
            relative_path: Skillディレクトリからの相対パス

        Returns:
            絶対パス（文字列）

        Example:
            >>> state.get_path("generation_context.json")
            '/home/user/repo/.claude/skills/your-skill-name/generation_context.json'
        """
        return str((self.skill_dir / relative_path).resolve())

    def get_repo_path(self, relative_path: str) -> str:
        """リポジトリルート基準の絶対パスを取得

        Args:
            relative_path: リポジトリルートからの相対パス

        Returns:
            絶対パス（文字列）

        Example:
            >>> state.get_repo_path("src/feature.py")
            '/home/user/repo/src/feature.py'
        """
        return str((self.repo_root / relative_path).resolve())

    def update_summary(self, updates: dict):
        """サマリを更新

        Args:
            updates: 更新する項目の辞書
        """
        self.summary.update(updates)
        self.logger.debug(f"サマリ更新: {updates}")

    def write_summary(self, filename: str = "summary_last_run.json"):
        """サマリをファイルに書き込み

        Args:
            filename: ファイル名（デフォルト: summary_last_run.json）
        """
        summary_path = self.get_path(filename)
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(self.summary, f, ensure_ascii=False, indent=2)
        self.logger.info(f"サマリを保存: {summary_path}")

    def create_backup(self, file_path: str) -> str:
        """ファイルのバックアップを作成

        Args:
            file_path: バックアップ対象ファイルの絶対パス

        Returns:
            バックアップファイルのパス（失敗時は空文字列）
        """
        import shutil

        if not Path(file_path).exists():
            self.logger.warning(f"バックアップ対象ファイルが存在しません: {file_path}")
            return ""

        backup_dir = self.logs_dir / "backups" / self.run_id
        backup_dir.mkdir(parents=True, exist_ok=True)

        file_name = Path(file_path).name
        backup_path = backup_dir / f"{file_name}.backup"

        try:
            shutil.copy2(file_path, backup_path)
            self.logger.info(f"バックアップ作成: {backup_path}")
            return str(backup_path)
        except Exception as e:
            self.logger.error(f"バックアップ作成失敗: {file_path}: {e}")
            return ""

    def estimate_tokens(self, text: str) -> int:
        """トークン数を概算

        1トークン ≈ 4文字として概算します。

        Args:
            text: テキスト

        Returns:
            推定トークン数
        """
        return len(text) // 4

    def log_token_usage(self, phase: str, text: str):
        """トークン使用量をログに記録

        Args:
            phase: フェーズ名（例: "context_generation", "subagent_input"）
            text: テキスト
        """
        tokens = self.estimate_tokens(text)
        self.summary["token_usage"][phase] = tokens
        self.summary["token_usage"]["total"] += tokens
        self.logger.info(f"トークン使用量 ({phase}): {tokens:,} トークン")


# カスタマイズポイント:
# 1. __init__: 必要なディレクトリやパスを追加
# 2. get_path / get_repo_path: 他のパス取得メソッドを追加
# 3. update_summary: サマリに記録する項目を追加
# 4. create_backup: バックアップ戦略をカスタマイズ
# 5. estimate_tokens: より正確なトークン推定ロジックに変更
