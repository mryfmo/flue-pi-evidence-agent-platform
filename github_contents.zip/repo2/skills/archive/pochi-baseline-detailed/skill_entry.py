"""
Pochi Baseline Detailed - Skill Entry Point

既存アプリのGitHubイシューからベースライン仕様書とADRの骨格版を生成する。
Phase 1: 骨格版生成（プレースホルダー入り）
Phase 2: LLM補完による詳細版生成
"""
import os
import sys
import json
import argparse
from pathlib import Path
from datetime import datetime

# coreモジュールをインポート
try:
    from core.issue_fetcher import GitHubIssueFetcher
    from core.adr_classifier import ADRClassifier
    from core.skeleton_generator import SkeletonGenerator
    from core.context_builder import ContextBuilder
    from core.quality_checker import QualityChecker
    from core.llm_completer import LLMCompleter
except ImportError:
    # 開発時用: スキルディレクトリから実行される場合
    sys.path.insert(0, str(Path(__file__).parent))
    from core.issue_fetcher import GitHubIssueFetcher
    from core.adr_classifier import ADRClassifier
    from core.skeleton_generator import SkeletonGenerator
    from core.context_builder import ContextBuilder
    from core.quality_checker import QualityChecker
    from core.llm_completer import LLMCompleter


def setup_output_directory() -> Path:
    """出力ディレクトリの準備

    Returns:
        Path: {skill_dir}/output/ のパス
    """
    # スキルディレクトリを基準に出力ディレクトリを設定
    skill_dir = Path(__file__).parent.resolve()

    # 出力ディレクトリ作成
    output_dir = skill_dir / "output"
    output_dir.mkdir(exist_ok=True)

    return output_dir


def print_step_header(step_num: int, total_steps: int, title: str):
    """ステップヘッダー表示"""
    print(f"\n{'=' * 70}")
    print(f"[{step_num}/{total_steps}] {title}")
    print(f"{'=' * 70}")


def run_phase2(output_dir: Path) -> int:
    """Phase 2: LLM補完による詳細版生成
    
    Args:
        output_dir: baseline-artifacts/ のパス
        
    Returns:
        0: 成功
        1: 失敗
    """
    print("=" * 70)
    print("Pochi Baseline Detailed - Phase 2")
    print("=" * 70)
    print("Phase: 2 (LLM補完による詳細版生成)")
    print("")
    
    try:
        # 必要なファイルの存在確認
        skeleton_path = output_dir / "baseline_spec_skeleton.md"
        context_path = output_dir / "generation_context.json"
        issues_path = output_dir / "issues_detail.json"
        
        if not skeleton_path.exists():
            print(f"❌ エラー: 骨格版ファイルが見つかりません: {skeleton_path}")
            print("Phase 1を先に実行してください")
            return 1
        
        if not context_path.exists():
            print(f"❌ エラー: コンテキストファイルが見つかりません: {context_path}")
            print("Phase 1を先に実行してください")
            return 1
        
        print("✅ 必要なファイルを確認しました")
        print(f"   骨格版: {skeleton_path}")
        print(f"   コンテキスト: {context_path}")
        print("")
        
        # Step 1: コンテキスト読み込み
        print_step_header(1, 3, "コンテキスト読み込み")
        
        with open(skeleton_path, 'r', encoding='utf-8') as f:
            skeleton_md = f.read()
        
        with open(context_path, 'r', encoding='utf-8') as f:
            generation_context = json.load(f)
        
        print(f"✅ コンテキスト読み込み完了")
        print(f"   プレースホルダー数: {len(generation_context.get('placeholders', []))}")
        print("")
        
        # Step 2: 補完プロンプト生成
        print_step_header(2, 3, "補完プロンプト生成")
        
        print("⚠️ 注意: API使用が制限されているため、プロンプト生成のみを行います")
        print("生成されたプロンプトを使用して手動で補完を行ってください")
        print("")
        
        # プロンプトファイルの生成
        prompts_dir = output_dir / "completion_prompts"
        prompts_dir.mkdir(exist_ok=True)
        
        generated_prompts = generate_completion_prompts(
            generation_context,
            skeleton_md,
            str(prompts_dir)
        )
        
        print(f"✅ プロンプト生成完了")
        print(f"   生成数: {len(generated_prompts)}個")
        print(f"   保存先: {prompts_dir}")
        print("")
        print("📝 次の手順:")
        print("  1. 各プロンプトファイルを確認")
        print("  2. Claudeに貼り付けて補完テキストを取得")
        print("  3. baseline_spec_skeleton.mdの該当プレースホルダーを置換")
        print("  4. 完成したファイルをbaseline_spec_detailed.mdとして保存")
        print("")
        
        # 詳細版のテンプレートを生成（手動補完用）
        detailed_md_path = str(output_dir / "baseline_spec_detailed.md")
        with open(detailed_md_path, 'w', encoding='utf-8') as f:
            f.write(skeleton_md)
        
        print(f"✅ 補完用テンプレート作成: {detailed_md_path}")
        print("   このファイルを編集してプレースホルダーを補完してください")
        print("")
        
        # Step 3: Phase 2品質チェック（スキップ可能）
        print_step_header(3, 3, "品質チェック準備")
        
        print("補完完了後、以下のコマンドで品質チェックを実行してください:")
        print("")
        print("  # 品質チェックスクリプト（作成予定）")
        print(f"  python -m skills.pochi-baseline-detailed.check_quality {detailed_md_path}")
        print("")
        print("または、以下のPythonコードで手動チェック:")
        print("")
        print("  from core.quality_checker import QualityChecker")
        print("  checker = QualityChecker()")
        print(f"  # 詳細版ファイルパス: {detailed_md_path}")
        print("  # ADRファイルパス: (必要に応じて)")
        print("")
        
        print("=" * 70)
        print("✅ Phase 2準備完了 - 手動補完モード")
        print("=" * 70)
        print("")
        print("📋 生成されたファイル:")
        print(f"  1. {prompts_dir}/ (補完プロンプト集)")
        print(f"  2. {detailed_md_path} (補完用テンプレート)")
        print("")
        print("📝 補完手順:")
        print("  1. completion_prompts/内の各プロンプトを確認")
        print("  2. Claudeに貼り付けて補完テキストを生成")
        print("  3. baseline_spec_detailed.mdの該当箇所を編集")
        print("  4. 全プレースホルダー補完後、品質チェックを実行")
        print("")
        print("⚠️ 注意: API使用制限のため、補完は手動で行ってください")
        
        print("")
        print("=" * 70)
        
        return 0
        
    except Exception as e:
        print(f"\n❌ エラーが発生しました: {e}")
        import traceback
        traceback.print_exc()
        return 1


def generate_completion_prompts(
    generation_context: dict,
    skeleton_md: str,
    output_dir: str
) -> list:
    """補完用プロンプトを生成
    
    Args:
        generation_context: コンテキスト情報
        skeleton_md: 骨格版マークダウン
        output_dir: 出力ディレクトリ
        
    Returns:
        生成されたプロンプトファイルのリスト
    """
    placeholders = generation_context.get('placeholders', [])
    generated_files = []
    
    # プレースホルダーを優先度順にソート
    placeholders_sorted = sorted(
        placeholders,
        key=lambda x: {'high': 0, 'medium': 1, 'low': 2}.get(x.get('priority', 'medium'), 1)
    )
    
    for i, ph in enumerate(placeholders_sorted, 1):
        ph_id = ph.get('id', f'UNKNOWN_{i}')
        section = ph.get('section', '不明')
        ph_type = ph.get('type', 'general')
        context = ph.get('context', {})
        mapped_issues = ph.get('mapped_issues', [])
        
        # プロンプト生成
        prompt = f"""# プレースホルダー補完タスク

## 対象プレースホルダー
`{{{{{ph_id}}}}}`

## セクション情報
- セクション: {section}
- 種別: {ph_type}
- 優先度: {ph.get('priority', 'medium')}

## 前後のコンテキスト
```markdown
{context.get('previous', '(なし)')}
[ここに内容を記述]
{context.get('next', '(なし)')}
```

## 関連イシュー情報
"""
        
        # イシュー情報を追加
        for issue in mapped_issues[:3]:  # 最大3件まで
            issue_body = issue.get('body', '(本文なし)')
            if len(issue_body) > 1000:
                issue_body = issue_body[:1000] + '...'
            
            prompt += f"""
### Issue #{issue.get('number')}: {issue.get('title', '(タイトルなし)')}

**本文**:
{issue_body}

"""
            
            # コメントを追加（最大2件）
            comments = issue.get('comments', [])
            if comments:
                prompt += "**主要コメント**:\n"
                for comment in comments[:2]:
                    comment_body = comment.get('body', '')
                    if len(comment_body) > 500:
                        comment_body = comment_body[:500] + '...'
                    prompt += f"- {comment_body}\n"
                prompt += "\n"
        
        # 補完指示を追加
        type_instructions = {
            'decision': '技術的な決定事項を具体的に記述してください。選択した技術やアプローチ、その理由を含めます。',
            'rationale': '決定の根拠や背景を詳しく説明してください。なぜその選択をしたのか、どのような要因を考慮したのかを含めます。',
            'technical_details': '技術的な詳細を記述してください。実装方法、使用するライブラリ、設定内容などを含めます。',
            'architecture': 'システムアーキテクチャの詳細を記述してください。コンポーネント構成、データフロー、インターフェースなどを含めます。',
            'context': 'コンテキストや背景情報を記述してください。プロジェクトの状況、制約条件、前提条件などを含めます。',
            'impact': '影響範囲や結果を記述してください。この決定によって何が変わるのか、どのような効果があるのかを含めます。',
            'general': '該当セクションに適切な内容を記述してください。'
        }
        
        instruction = type_instructions.get(ph_type, type_instructions['general'])
        
        prompt += f"""
## 補完指示

{instruction}

### 記述ガイドライン
- **具体的に**: 抽象的な表現は避け、具体的な技術名や数値を使用
- **イシュー参照**: 関連するイシュー番号（#XXX）を適宜参照
- **構造化**: 箇条書きや見出しを使って読みやすく
- **コード例**: 必要に応じてコードブロックを含める

## 出力形式

プレースホルダー `{{{{{ph_id}}}}}` を置き換える内容のみを出力してください。
マークダウン形式で記述してください。

---
*このプロンプトはPhase 2補完プロセスの一部として自動生成されました*
"""
        
        # プロンプトをファイルに保存
        safe_ph_id = ph_id.replace('{{', '').replace('}}', '').replace('PLACEHOLDER_', '')
        filename = f"{i:03d}_{safe_ph_id}.md"
        filepath = Path(output_dir) / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(prompt)
        
        generated_files.append(str(filepath))
        
        print(f"  生成: {filename}")
    
    return generated_files


def main():
    """メインエントリポイント
    
    Returns:
        0: 成功
        1: 失敗
    """
    # コマンドライン引数のパース
    parser = argparse.ArgumentParser(description='Pochi Baseline Detailed Skill')
    parser.add_argument('--phase2', action='store_true', 
                       help='Phase 2 (LLM補完) を実行')
    parser.add_argument('--output-dir', type=str, default=None,
                       help='出力ディレクトリのパス')
    args = parser.parse_args()
    
    # 環境変数チェック（デバッグモード以外）
    if os.environ.get("POCHI_SKILL_DEBUG") != "1":
        if os.environ.get("POCHI_SKILL_ACTIVE") != "1":
            print("❌ エラー: このスキルはClaude Code Skills経由でのみ実行可能です")
            print("トリガーフレーズ: '既存アプリのベースライン仕様書を作成'")
            return 1
    
    # 出力ディレクトリの準備
    if args.output_dir:
        output_dir = Path(args.output_dir)
    else:
        output_dir = setup_output_directory()
    
    # Phase 2の実行
    if args.phase2:
        return run_phase2(output_dir)
    
    # Phase 1の実行（従来のメイン処理）
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    print("=" * 70)
    print("Pochi Baseline Detailed - Skill Entry")
    print("=" * 70)
    print(f"Run ID: {run_id}")
    print(f"Phase: 1 (骨格版生成)")
    print("")
    
    try:
        # 出力ディレクトリ準備
        output_dir = setup_output_directory()
        print(f"✅ 出力ディレクトリ: {output_dir}")
        print("")
        
        # Step 1: GitHub認証とイシュー取得
        print_step_header(1, 6, "GitHub認証とイシュー取得")
        fetcher = GitHubIssueFetcher()
        
        print("GitHub認証を初期化中...")
        if not fetcher.initialize():
            print("❌ GitHub認証に失敗しました")
            print("解決策: `gh auth status` で認証状態を確認してください")
            return 1
        
        print("✅ GitHub認証成功")
        print("")
        
        # リポジトリ情報を取得（プロンプトまたは環境変数から）
        repo = os.environ.get("GITHUB_REPOSITORY")
        if not repo:
            print("リポジトリを指定してください（例: owner/repo）:")
            repo = input().strip()
        
        # リポジトリ名のバリデーション
        from core.issue_fetcher import validate_repo_name
        try:
            repo = validate_repo_name(repo)
        except ValueError as e:
            print(f"❌ {e}")
            return 1
        
        print(f"イシュー取得中: {repo}")
        issues_df = fetcher.fetch_issues(repo)

        # イシュー番号リストを取得
        issue_numbers = issues_df['number'].tolist() if not issues_df.empty else []

        comments_df = fetcher.fetch_comments(repo, issue_numbers)
        events_df = fetcher.fetch_events(repo, issue_numbers)
        
        # CSV保存
        issues_df.to_csv(output_dir / "issues_detail.csv", index=False)
        comments_df.to_csv(output_dir / "issues_comments.csv", index=False)
        events_df.to_csv(output_dir / "issues_events.csv", index=False)
        
        print(f"✅ イシュー取得完了: {len(issues_df)}件")
        print(f"   コメント: {len(comments_df)}件")
        print(f"   イベント: {len(events_df)}件")
        print("")
        
        # Step 2: ADR候補分類と設定ファイル生成
        print_step_header(2, 6, "ADR候補分類と設定ファイル生成")
        classifier = ADRClassifier()
        
        print("イシューをADR候補として分類中...")
        classification = classifier.classify_adr_candidates(issues_df, comments_df)
        
        # YAML設定ファイル生成
        yaml_path = str(output_dir / "baseline_spec_config.yaml")
        yaml_path = classifier.generate_config_yaml(classification, issues_df, yaml_path)
        
        high_count = len(classification.get('high_priority', []))
        medium_count = len(classification.get('medium_priority', []))
        low_count = len(classification.get('low_priority', []))
        exclude_count = len(classification.get('exclude', []))
        
        print(f"✅ ADR分類完了:")
        print(f"   High優先度: {high_count}件")
        print(f"   Medium優先度: {medium_count}件")
        print(f"   Low優先度: {low_count}件")
        print(f"   Exclude: {exclude_count}件")
        print(f"   設定ファイル: {yaml_path}")
        print("")
        
        # Step 3: 骨格版ドキュメント生成
        print_step_header(3, 6, "骨格版ドキュメント生成")
        generator = SkeletonGenerator()
        
        # プロジェクト名の取得
        project_name = "Unknown Project"
        if not issues_df.empty and 'url' in issues_df.columns:
            first_url = issues_df.iloc[0]['url']
            parts = first_url.split('/')
            if len(parts) >= 5:
                project_name = parts[4]
        
        # ADR対象イシュー番号のリスト（high+medium）
        adr_issue_numbers = (
            classification.get('high_priority', []) + 
            classification.get('medium_priority', [])
        )
        
        print("ベースライン仕様書の骨格版を生成中...")
        baseline_skeleton = generator.generate_baseline_skeleton(
            issues_df, 
            adr_issue_numbers,
            project_name
        )
        
        print("ADRの骨格版を生成中...")
        adr_skeleton = generator.generate_adr_skeleton(
            issues_df,
            comments_df,
            adr_issue_numbers
        )
        
        # ファイル保存
        baseline_path = str(output_dir / "baseline_spec_skeleton.md")
        adr_path = str(output_dir / "adr_skeleton.md")
        
        baseline_path, adr_path = generator.save_skeletons(
            baseline_skeleton,
            adr_skeleton,
            baseline_path,
            adr_path
        )
        
        skeleton_paths = {
            'baseline': baseline_path,
            'adr': adr_path
        }
        
        print(f"✅ 骨格版生成完了:")
        print(f"   ベースライン: {skeleton_paths['baseline']}")
        print(f"   ADR: {skeleton_paths['adr']}")
        print("")
        
        # Step 4: LLM補完用コンテキスト構築
        print_step_header(4, 6, "LLM補完用コンテキスト構築")
        builder = ContextBuilder()
        
        print("generation_context.jsonを構築中...")
        
        # config辞書を構築
        config = {
            'project': {
                'name': project_name,
                'total_issues': len(issues_df)
            },
            'adr_candidates': classification
        }
        
        context_path = builder.build_generation_context(
            config=config,
            issues_df=issues_df,
            comments_df=comments_df,
            events_df=events_df,
            baseline_skeleton_path=skeleton_paths['baseline'],
            adr_skeleton_path=skeleton_paths['adr'],
            output_dir=str(output_dir)
        )
        
        # イシューデータのJSON出力
        issues_json_path = str(output_dir / "issues_detail.json")
        issues_json_path = builder.prepare_issues_json(
            issues_df, 
            comments_df,
            issues_json_path
        )
        
        print(f"✅ コンテキスト構築完了:")
        print(f"   generation_context.json: {context_path}")
        print(f"   issues.json: {issues_json_path}")
        print("")
        
        # Step 5: ユーザー確認（対話型承認）
        print_step_header(5, 6, "ユーザー確認")
        print("骨格版ドキュメントを確認してください:")
        print(f"  - {skeleton_paths['baseline']}")
        print(f"  - {skeleton_paths['adr']}")
        print("")
        print("このまま品質チェックを実行しますか？ (y/n): ", end="")
        
        # デバッグモードまたは自動承認モード
        if os.environ.get("POCHI_SKILL_DEBUG") == "1" or os.environ.get("AUTO_APPROVE") == "1":
            print("y (自動承認)")
            user_input = "y"
        else:
            user_input = input().strip().lower()
        
        if user_input != "y":
            print("⚠️ ユーザーによりキャンセルされました")
            print(f"生成済みファイルは {output_dir} に保存されています")
            return 0
        
        print("")
        
        # Step 6: 品質チェックと完了
        print_step_header(6, 6, "品質チェックと完了")
        checker = QualityChecker()
        
        print("骨格版の品質をチェック中...")
        
        # 全イシュー番号のリストを取得
        all_issue_numbers = issues_df['number'].tolist() if not issues_df.empty else []
        
        quality_result = checker.check_quality(
            baseline_spec_path=skeleton_paths['baseline'],
            adr_path=skeleton_paths['adr'],
            all_issue_numbers=all_issue_numbers
        )
        
        # 品質レポート生成
        report_path = str(output_dir / "quality_report.md")
        report_path = checker.generate_report(quality_result, report_path)
        
        score = quality_result.get('overall', {}).get('score', 0)
        passed = quality_result.get('overall', {}).get('passed', False)
        
        print(f"✅ 品質チェック完了:")
        print(f"   総合スコア: {score}/100点")
        print(f"   判定: {'合格' if passed else '要改善'}")
        print(f"   レポート: {report_path}")
        print("")
        
        # 最終メッセージ
        print("=" * 70)
        print("✅ Phase 1完了 - 骨格版生成")
        print("=" * 70)
        print("")
        print("📋 生成されたファイル:")
        print(f"  1. {skeleton_paths['baseline']} (ベースライン骨格版)")
        print(f"  2. {skeleton_paths['adr']} (ADR骨格版)")
        print(f"  3. {output_dir / 'baseline_spec_config.yaml'} (設定ファイル)")
        print(f"  4. {output_dir / 'generation_context.json'} (LLM補完用)")
        print(f"  5. {report_path} (品質レポート)")
        print("")
        print("📝 次のステップ（Phase 2以降）:")
        print("  - LLMによるプレースホルダー補完")
        print("  - 詳細版ドキュメント生成")
        print("  - 最終品質チェック")
        print("")
        print(f"⚠️ Phase 2は別タスクで実施してください（コンテキストウィンドウ考慮）")
        print("")
        print("=" * 70)
        
        return 0
        
    except Exception as e:
        print(f"\n❌ エラーが発生しました: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
