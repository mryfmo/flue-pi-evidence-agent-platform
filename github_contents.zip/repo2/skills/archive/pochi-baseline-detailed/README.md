# Pochi Baseline Detailed

既存アプリのGitHubイシューからベースライン仕様書とADR（Architecture Decision Record）の骨格版を自動生成するツールです。

## 概要

このツールは、既存アプリケーションのGitHubリポジトリに蓄積されたイシュー情報を分析し、ベースライン仕様書とADRの骨格版を自動生成します。

### 主な機能（Phase 1）

1. **GitHub認証とイシュー取得**: `gh` CLI経由でイシュー、コメント、イベントを取得
2. **ADR候補分類**: イシューをADR候補として自動分類（high/medium/low/exclude）
3. **骨格版ドキュメント生成**: プレースホルダー入りのベースライン仕様書とADRを生成
4. **LLM補完用コンテキスト構築**: Phase 2以降で使用するgeneration_context.jsonを生成
5. **品質チェック**: 骨格版の構造と内容を自動検証

### Phase 1の位置づけ

**Phase 1（現在実装済み）**: 骨格版生成
- プレースホルダー入りドキュメントの自動生成
- イシュー情報の抽出と構造化
- 品質チェック（スコア60点以上で合格）

**Phase 2以降（今後実装予定）**: 詳細版生成
- LLMによるプレースホルダー補完
- 自然文の詳細記述
- 最終品質チェック

## クイックスタート

### ⚡ Claude Code Skills統合（最も簡単・推奨）

**前提条件**:
- GitHubリポジトリが存在すること
- `gh` CLIがインストールされ、認証済みであること（`gh auth login`実行済み）
- `skills/pochi-baseline-detailed/SKILL.md`が存在すること

**使い方**:
```
Claude Codeで以下のいずれかを入力：
- 「既存アプリのベースライン仕様書を作成」（推奨）
- 「Skillツールを使用して pochi-baseline-detailed を起動してください」（明示的）
- 「pochi-baseline-detailed を起動」
```

自動的に以下が実行されます：
1. GitHub認証とイシュー取得
2. ADR候補分類
3. 骨格版ドキュメント生成
4. コンテキスト構築
5. 品質チェック

詳細は **[SKILL.md](./SKILL.md)** を参照してください。

---

### スタンドアロン実行（環境変数付き）

単一コマンドでPhase 1を実行：

```bash
# Linux/Mac
POCHI_SKILL_ACTIVE=1 python skills/pochi-baseline-detailed/skill_entry.py

# Windows (cmd)
set POCHI_SKILL_ACTIVE=1 && python skills\pochi-baseline-detailed\skill_entry.py

# Windows (PowerShell)
$env:POCHI_SKILL_ACTIVE="1"; python skills\pochi-baseline-detailed\skill_entry.py
```

**実行内容**:
1. GitHub認証とイシュー取得（CSV形式で保存）
2. ADR候補分類（YAML設定ファイル生成）
3. 骨格版ドキュメント生成（マークダウン形式）
4. LLM補完用コンテキスト構築（JSON形式）
5. ユーザー確認（対話型）
6. 品質チェックと完了

**リポジトリ指定**:
実行時にプロンプトで入力：
```
owner/repository
```
例: `octocat/Hello-World`

または環境変数で事前設定：
```bash
export GITHUB_REPOSITORY=owner/repository
POCHI_SKILL_ACTIVE=1 python skills/pochi-baseline-detailed/skill_entry.py
```

**注記**: 
- 環境変数`POCHI_SKILL_ACTIVE=1`は必須（セキュリティガード）
- Windows環境では `python` の代わりに `py` または `python3` を使用する場合があります

## 前提条件

### 必須環境

1. **Python 3.x**
   ```bash
   python --version  # 3.7以上
   ```

2. **GitHub CLI (`gh`)**
   ```bash
   # インストール
   # Mac: brew install gh
   # Linux: apt install gh または yum install gh
   # Windows: choco install gh または scoop install gh
   
   # 認証
   gh auth login
   gh auth status  # 確認
   ```

3. **Python依存パッケージ**
   ```bash
   pip install pandas pyyaml requests
   ```

### オプション環境

- **デバッグモード**: `POCHI_SKILL_DEBUG=1`（ユーザー確認を自動承認）
- **自動承認モード**: `AUTO_APPROVE=1`（ユーザー確認をスキップ）

## ファイル構成

```
skills/pochi-baseline-detailed/
├── README.md                     # このファイル
├── SKILL.md                      # Claude Code Skills仕様
├── skill_entry.py                # メインエントリポイント
└── core/                         # コアモジュール
    ├── __init__.py
    ├── issue_fetcher.py          # GitHub API連携
    ├── adr_classifier.py         # ADR分類ロジック
    ├── skeleton_generator.py     # 骨格版生成
    ├── context_builder.py        # コンテキスト構築
    └── quality_checker.py        # 品質検証
```

## 生成物（標準配置）

すべての成果物は `baseline-artifacts/` ディレクトリに配置されます：

### 主要成果物
- `baseline_spec_skeleton.md` - **ベースライン仕様書の骨格版**（プレースホルダー入り）
- `architecture_decision_record_skeleton.md` - **ADRの骨格版**（プレースホルダー入り）

### データファイル
- `issues_detail.csv` - イシュー詳細データ
- `issues_comments.csv` - コメントデータ
- `issues_events.csv` - イベント履歴データ
- `issues.json` - イシューJSON形式（Phase 2用）

### 設定・コンテキスト
- `baseline_spec_config.yaml` - ADR分類設定ファイル
- `generation_context.json` - LLM補完用コンテキスト（Phase 2用）
- `prompts_last_run.md` - LLM補完用プロンプト（Phase 2用）

### レポート
- `quality_report.md` - **品質検証レポート**

### ディレクトリ構造例

```
baseline-artifacts/
├── issues_detail.csv                        # 50件のイシュー
├── issues_comments.csv                      # 200件のコメント
├── issues_events.csv                        # 300件のイベント
├── baseline_spec_config.yaml                # ADR分類設定
│   # high: 5件, medium: 10件, low: 30件, exclude: 5件
├── baseline_spec_skeleton.md                # 骨格版（10ページ相当）
├── architecture_decision_record_skeleton.md # 骨格版（5ページ相当）
├── generation_context.json                  # コンテキスト（Phase 2用）
├── issues.json                              # イシューJSON（Phase 2用）
├── prompts_last_run.md                      # プロンプト（Phase 2用）
└── quality_report.md                        # 品質レポート
    # スコア: 65/100点（合格）
```

## ADR分類基準

イシューは以下の基準でADR候補として自動分類されます：

### High優先度
- **ラベル**: `architecture`, `design`, `decision`を含む
- **コメント数**: 5件以上
- **リアクション数**: 3件以上（👍 など）

### Medium優先度
- **ラベル**: `enhancement`, `refactor`を含む
- **コメント数**: 3-4件

### Low優先度
- 上記以外のイシュー（バグ修正、小規模改善など）

### Exclude（除外）
- **ラベル**: `duplicate`, `invalid`, `wontfix`を含む
- **ステータス**: `open`かつ90日以上未更新

## 品質基準（Phase 1）

骨格版の品質は以下の基準で評価されます（100点満点、60点以上で合格）：

### 章立て（30点）
- 適切なセクション構造
- 論理的な階層化
- 必須セクションの存在

### イシュー引用（30点）
- 各セクションにイシュー番号を記載
- 参照の正確性
- ADR候補の適切な配置

### プレースホルダー（20点）
- `<!-- TODO: ... -->`形式で配置
- 補完すべき箇所が明確
- 過不足なく配置

### その他（20点）
- マークダウン文法の正確性
- ファイル構造の整合性
- メタデータの完全性

## トラブルシューティング

### Q: Skillが起動しない
A: 以下を確認してください：
```bash
# 1. ファイル配置確認
ls -la skills/pochi-baseline-detailed/SKILL.md

# 2. トリガーフレーズ確認
# ✅ 「既存アプリのベースライン仕様書を作成」
# ❌ 「仕様書を作って」（曖昧）
```

### Q: GitHub認証に失敗する
A: `gh` CLIの認証を確認してください：
```bash
gh auth status
# 未認証の場合
gh auth login
```

### Q: リポジトリが見つからない
A: リポジトリ名を`owner/repository`形式で正確に入力してください。
```
例: octocat/Hello-World
❌ Hello-World（ownerが欠落）
❌ https://github.com/octocat/Hello-World（URL形式は不可）
```

### Q: イシューが取得できない
A: 以下を確認してください：
- リポジトリが公開されているか、認証ユーザーがアクセス権を持っているか
- イシューが実際に存在するか（GitHub上で確認）
- ネットワーク接続が正常か

### Q: 品質チェックに不合格（60点未満）
A: `quality_report.md`を確認してください：
```bash
cat baseline-artifacts/quality_report.md
# 「改善指示」セクションで問題点を確認
# Phase 2で詳細化時に対応可能
```

### Q: プレースホルダーが多すぎる
A: **Phase 1では正常な動作です**。プレースホルダーはPhase 2でLLMが補完します。
```markdown
<!-- TODO: [LLM補完] イシュー#42の詳細をここに記述 -->
```

### Q: コンテキストウィンドウ不足エラー
A: Phase 1完了後、**別タスクでPhase 2を実施**してください。
```
Phase 1完了メッセージに「Phase 2は別タスクで実施してください」と表示されます。
```

## 実行例

### 例1: 小規模リポジトリ（イシュー50件）
```bash
$ POCHI_SKILL_ACTIVE=1 python skills/pochi-baseline-detailed/skill_entry.py

======================================================================
Pochi Baseline Detailed - Skill Entry
======================================================================
Run ID: 20260116_043530
Phase: 1 (骨格版生成)

✅ 出力ディレクトリ: /path/to/baseline-artifacts

======================================================================
[1/6] GitHub認証とイシュー取得
======================================================================
GitHub認証を初期化中...
✅ GitHub認証成功

リポジトリを指定してください（例: owner/repo）:
> octocat/Hello-World

イシュー取得中: octocat/Hello-World
✅ イシュー取得完了: 50件
   コメント: 200件
   イベント: 300件

======================================================================
[2/6] ADR候補分類と設定ファイル生成
======================================================================
イシューをADR候補として分類中...
✅ ADR分類完了:
   High優先度: 5件
   Medium優先度: 10件
   Low優先度: 30件
   Exclude: 5件
   設定ファイル: baseline-artifacts/baseline_spec_config.yaml

...（省略）...

======================================================================
✅ Phase 1完了 - 骨格版生成
======================================================================

📋 生成されたファイル:
  1. baseline-artifacts/baseline_spec_skeleton.md (ベースライン骨格版)
  2. baseline-artifacts/architecture_decision_record_skeleton.md (ADR骨格版)
  3. baseline-artifacts/baseline_spec_config.yaml (設定ファイル)
  4. baseline-artifacts/generation_context.json (LLM補完用)
  5. baseline-artifacts/quality_report.md (品質レポート)

📝 次のステップ（Phase 2以降）:
  - LLMによるプレースホルダー補完
  - 詳細版ドキュメント生成
  - 最終品質チェック

⚠️ Phase 2は別タスクで実施してください（コンテキストウィンドウ考慮）
```

### 例2: 大規模リポジトリ（イシュー500件）
```bash
イシュー取得中: kubernetes/kubernetes
✅ イシュー取得完了: 500件（最新500件のみ）
   コメント: 2000件
   イベント: 5000件

✅ ADR分類完了:
   High優先度: 50件
   Medium優先度: 150件
   Low優先度: 250件
   Exclude: 50件
```

## セキュリティ

### セキュリティ機能
- **環境変数チェック**: `POCHI_SKILL_ACTIVE=1`が必須
- **GitHubトークン保護**: ログに出力しない
- **ローカル処理**: イシューデータは外部送信しない（Phase 1）

### プライバシー考慮事項
- GitHubイシューに機密情報が含まれる場合は、手動で確認・編集してください
- 生成されたドキュメントを公開する前に、センシティブ情報をチェックしてください

## Phase 2以降の予定

Phase 1完了後、以下をPhase 2以降で実施します：

### Phase 2: Core機能詳細実装（6-8時間）
- LLMによるプレースホルダー補完
- 詳細な章立て自動生成
- イシュー情報の自然文化
- ラベルベース分類ロジック強化

### Phase 3: プロンプト整備（3-4時間）
- 専用プロンプトテンプレート作成
- 品質基準の詳細化
- テンプレート統合

### Phase 4: テスト・ドキュメント（4-5時間）
- 実機テスト実施
- VERIFICATION_GUIDE.md作成
- エラーハンドリング強化

## 関連ドキュメント

### Skill関連
- [SKILL.md](./SKILL.md): Claude Code Skills仕様
- [skills/pochi-test-orchestrator/](../pochi-test-orchestrator/): 参考実装

### Pochiプロセス関連
- ベースライン仕様書作成ガイド: pochi-spec-initializer/docs/WORKFLOW.md を参照

## テスト結果

Phase 4で実施した統合テストの結果：

### テスト1: ADR分類テスト ✅ 成功
- **精度**: 75% (8イシュー中6イシュー正確)
- **実施日**: 2026-01-16
- **結果**: 実運用可能レベル

**詳細**:
- High優先度: 2/2 正確 (100%)
- Medium優先度: 2/3 正確 (66%)
- Low優先度: 1/1 正確 (100%)
- Exclude: 1/2 正確 (50%)

**誤分類事例**:
- Issue #112: medium → high（スコア8.4点、境界値）

**評価**: 実運用では設定ファイルで調整可能なため問題なし

### テスト2: 骨格版生成テスト ✅ 成功
- **精度**: 100%（全検証項目合格）
- **実施日**: 2026-01-16
- **結果**: 期待値通りの出力

**検証項目**:
- ✅ セクション数: 12セクション（期待通り）
- ✅ プレースホルダー数: 50個（期待値：50±2個）
- ✅ ADRセクションの配置: 正しい順序
- ✅ Markdown構造: 適切

**生成内容**:
- High優先度ADR: 2件（各5プレースホルダー）
- Medium優先度ADR: 3件（各3プレースホルダー）
- Low優先度ADR: 1件（3プレースホルダー）
- 一般セクション: 28プレースホルダー

### テストデータ
- サンプルプロジェクト: pochi-voice-analysis
- イシュー数: 8件（high: 3, medium: 3, low: 1, exclude: 1）
- テストスクリプト: `test-data/baseline-detailed/`

詳細は [Phase 4 テスト計画書](../../docs/phase4-baseline-detailed-test-plan.md) を参照してください。

## バージョン・ライセンス

- **バージョン**: 1.0.0（Phase 1 - 骨格版生成）
- **テスト状況**: Phase 4統合テスト完了（2テスト成功）
- **作成者**: Pochi Development Team
- **ライセンス**: Internal Use Only

---

**🚀 このSkillを起動するには、「既存アプリのベースライン仕様書を作成」とClaude Codeに指示してください。**
