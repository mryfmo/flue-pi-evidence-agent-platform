---
skill_id: pochi-baseline-detailed
id: pochi-baseline-detailed
title: Pochi Baseline Detailed
name: Pochi Baseline Detailed
version: 1.0.0
description: 既存アプリのGitHubイシューからベースライン仕様書とADR（Architecture Decision Record）の骨格版を作成する際に使用。ユーザーが「既存アプリのベースライン仕様書を作成」「ADRの骨格版を作成」などと依頼した時に起動する。
entrypoint:
  type: prompt
  path: prompts/generate_detailed_spec.md
triggers:
  - 既存アプリのベースライン仕様書を作成
  - 既存アプリのベースライン仕様書を生成
  - GitHubイシューからベースライン仕様書を作成
  - GitHubイシューからベースライン仕様書を生成
  - ベースライン仕様書の骨格版を作成
  - ADRの骨格版を作成
  - pochi-baseline-detailed を起動
  - Skillツールを使用して pochi-baseline-detailed を起動してください
  - ベースライン仕様書作成
  - ベースライン仕様書生成
  - ADR作成
  - ADR生成
  - イシューから仕様書
  - イシューから仕様書作成
  - 骨格版作成
  - baseline skeleton
---

> [!CAUTION]
> **このスキルは廃止・使用禁止です。**
> 起動した場合でも**何も実行せずに即座に終了してください。**
> 後継スキル: `pochi-baseline-builder` — 「ベースライン仕様書を作成して」で起動

**このスキルは使用禁止です。絶対に実行しないでください。**

後継スキル **`pochi-baseline-builder` — 「ベースライン仕様書を作成して」で起動** を使用してください。


# Skill: Pochi Baseline Detailed

**このSkillは、既存アプリのGitHubイシューからベースライン仕様書とADR（Architecture Decision Record）の骨格版を自動生成します。**

## Trigger Phrases

### 推奨トリガー
- 既存アプリのベースライン仕様書を作成
- 既存アプリのベースライン仕様書を生成
- GitHubイシューからベースライン仕様書を作成
- GitHubイシューからベースライン仕様書を生成
- ベースライン仕様書の骨格版を作成
- ADRの骨格版を作成
- pochi-baseline-detailed を起動
- Skillツールを使用して pochi-baseline-detailed を起動してください

### 汎用トリガー
- ベースライン仕様書作成
- ベースライン仕様書生成
- ADR作成
- ADR生成
- イシューから仕様書
- イシューから仕様書作成
- 骨格版作成
- baseline skeleton

## When

### 起動条件
- 上記Trigger Phrasesのいずれかが発話された
- プロジェクトにGitHubリポジトリが存在する
- `gh` CLI がインストールされている（GitHub認証用）

### 前提条件
- GitHubの認証が設定済み（`gh auth login`済み）
- 対象リポジトリにイシューが存在する

### 起動しない条件（誤起動防止）
以下のような曖昧な表現では起動しないでください：
- ❌ 「仕様書を作って」（何の仕様書か不明）
- ❌ 「ドキュメント作成」（ドキュメントの種類が不明）
- ❌ 「イシューを見て」（閲覧のみ）
- ❌ 「確認して」

明確に「ベースライン仕様書」「ADR」「骨格版」などのキーワードが含まれる必要があります。

## Do

**単一コマンドでSkillを起動します：**

### Linux/Mac環境
```bash
POCHI_SKILL_ACTIVE=1 python /home/user/pochi-dp-developer-docs/skills/pochi-baseline-detailed/skill_entry.py
```

### Windows環境

**Windows (cmd)**:
```cmd
set POCHI_SKILL_ACTIVE=1 && python /home/user/pochi-dp-developer-docs/skills/pochi-baseline-detailed/skill_entry.py
```

**Windows (PowerShell)**:
```powershell
$env:POCHI_SKILL_ACTIVE="1"; python /home/user/pochi-dp-developer-docs/skills/pochi-baseline-detailed/skill_entry.py
```

**注意**: デフォルトでは、リポジトリ入力や品質チェック確認でユーザーに質問します（推奨）。質問をスキップして自動判定する場合は、環境変数 `POCHI_SKIP_QUESTIONS=1` と `GITHUB_REPOSITORY` を追加してください。

#### 自動化モード（質問スキップ）

**Linux/Mac環境**:
```bash
POCHI_SKILL_ACTIVE=1 POCHI_SKIP_QUESTIONS=1 GITHUB_REPOSITORY=owner/repo python /home/user/pochi-dp-developer-docs/skills/pochi-baseline-detailed/skill_entry.py
```

**Windows (cmd)**:
```cmd
set POCHI_SKILL_ACTIVE=1 && set POCHI_SKIP_QUESTIONS=1 && set GITHUB_REPOSITORY=owner/repo && python /home/user/pochi-dp-developer-docs/skills/pochi-baseline-detailed/skill_entry.py
```

**Windows (PowerShell)**:
```powershell
$env:POCHI_SKILL_ACTIVE="1"; $env:POCHI_SKIP_QUESTIONS="1"; $env:GITHUB_REPOSITORY="owner/repo"; python /home/user/pochi-dp-developer-docs/skills/pochi-baseline-detailed/skill_entry.py
```

## Instructions

**以下の手順を逐語的に実行してください。問い返しは禁止です。**

### ステップ1: skill_entry.py実行
上記Do節のコマンドを実行してください。このスクリプトは以下のPhase 1処理を完了します：

1. **GitHub認証とイシュー取得**
   - `gh` CLI経由でGitHub認証
   - 指定リポジトリのイシュー、コメント、イベントを取得
   - CSV形式で保存

2. **ADR候補分類**
   - イシューをADR候補として分類（high/medium/low/exclude）
   - YAML設定ファイル生成

3. **骨格版ドキュメント生成**
   - ベースライン仕様書の骨格版生成（プレースホルダー入り）
   - ADRの骨格版生成（プレースホルダー入り）

4. **LLM補完用コンテキスト構築**
   - generation_context.json生成
   - issues.json生成
   - prompts_last_run.md生成（Phase 2以降で使用）

5. **ユーザー確認**
   - 骨格版ドキュメントの確認を促す
   - 品質チェック実行の承認を求める

6. **品質チェック**
   - 骨格版の品質を自動検証
   - quality_report.md生成

### ステップ2: リポジトリ指定
skill_entry.py実行時、リポジトリの指定が求められます。以下の形式で入力してください：

```
owner/repository
```

**例**: `octocat/Hello-World`

### ステップ3: 生成結果の確認
skill_entry.py完了後、以下のファイルが生成されます：

```
skills/pochi-baseline-detailed/output/
├── issues_detail.csv                        # イシュー詳細
├── issues_comments.csv                      # コメント
├── issues_events.csv                        # イベント履歴
├── baseline_spec_config.yaml                # 設定ファイル
├── baseline_spec_skeleton.md                # ベースライン骨格版
├── architecture_decision_record_skeleton.md # ADR骨格版
├── generation_context.json                  # LLM補完用コンテキスト
├── issues.json                              # イシューJSON
├── prompts_last_run.md                      # プロンプト（Phase 2用）
└── quality_report.md                        # 品質レポート
```

### ステップ4: 品質レポートの確認
`skills/pochi-baseline-detailed/output/quality_report.md`を開き、以下を確認してください：

- **総合スコア**: 60点以上で合格
- **プレースホルダー残存**: Phase 1では許容（Phase 2で補完）
- **章立て**: 適切な構造か
- **イシュー参照**: 正しく引用されているか

### ステップ5: Phase 1完了確認
品質チェック合格（スコア60点以上）で、Phase 1が完了です。

**Phase 2以降はコンテキストウィンドウ考慮のため別タスクで実施してください。**

## Don't

### 実行禁止事項
- ❌ **環境変数なしでの直接実行は禁止**
  - セキュリティガードにより実行が拒否されます
  
- ❌ **リポジトリ全文の長文読込は禁止**
  - 必要な情報はイシューから取得します
  
- ❌ **問い返しは禁止**
  - リポジトリ指定時のみ入力を求めます
  - その他はすべて自動処理

- ❌ **Phase 2処理の実行は禁止**
  - Phase 1はプレースホルダー入り骨格版まで
  - LLM補完は別タスクで実施

### 品質基準の遵守
Phase 1（骨格版）の品質基準：

- ✅ **章立て**: 適切なセクション構造
- ✅ **イシュー引用**: 各セクションにイシュー番号を記載
- ✅ **プレースホルダー**: `<!-- TODO: ... -->`形式で配置
- ⚠️ **詳細記述**: Phase 2で補完（Phase 1では不要）

## Inputs

### 必須入力
- **GitHubリポジトリ名**: `owner/repository`形式
  - 実行時にプロンプトで入力
  - または環境変数`GITHUB_REPOSITORY`で指定

### オプション入力
- **期間フィルタ**: 特定期間のイシューのみ取得（Phase 2で実装予定）
- **ラベルフィルタ**: 特定ラベルのみ取得（Phase 2で実装予定）

### 自動取得される情報
- イシュー詳細（タイトル、本文、ラベル、作成日時など）
- コメント（コメント本文、作成者、作成日時など）
- イベント履歴（クローズ、ラベル追加など）

## Outputs

### 主要成果物（Phase 1）
- `baseline_spec_skeleton.md`
  - ベースライン仕様書の骨格版
  - プレースホルダー入り
  
- `architecture_decision_record_skeleton.md`
  - ADRの骨格版
  - 主要な意思決定を抽出

### 中間ファイル
- `issues_detail.csv`: イシュー詳細データ
- `issues_comments.csv`: コメントデータ
- `issues_events.csv`: イベント履歴データ
- `issues.json`: イシューJSON形式
- `baseline_spec_config.yaml`: 設定ファイル

### コンテキストファイル（Phase 2用）
- `generation_context.json`: LLM補完用コンテキスト
- `prompts_last_run.md`: LLM補完用プロンプト

### レポート
- `quality_report.md`: 品質検証レポート

## Phase 1実行フロー

```mermaid
graph TD
    A[Skill起動] --> B[GitHub認証]
    B --> C[イシュー取得]
    C --> D[ADR候補分類]
    D --> E[骨格版生成]
    E --> F[コンテキスト構築]
    F --> G[ユーザー確認]
    G --> H[品質チェック]
    H --> I{スコア60点以上?}
    I -->|Yes| J[Phase 1完了]
    I -->|No| K[要改善]
    J --> L[Phase 2へ]
```

## ADR分類基準

イシューは以下の基準でADR候補として分類されます：

### High優先度
- ラベル: `architecture`, `design`, `decision`
- コメント数: 5件以上
- リアクション数: 3件以上

### Medium優先度
- ラベル: `enhancement`, `refactor`
- コメント数: 3-4件

### Low優先度
- 上記以外のイシュー

### Exclude（除外）
- ラベル: `duplicate`, `invalid`, `wontfix`
- ステータス: `open`かつ古い（90日以上未更新）

## Troubleshooting

### Skillが起動しない場合

#### 1. SKILL.mdの配置を確認
```bash
# プロジェクトルートで以下が見えるか確認
ls -la skills/pochi-baseline-detailed/
```

**期待される状態**:
```
プロジェクトルート/
└── skills/
    └── pochi-baseline-detailed/
        ├── SKILL.md              # このファイル
        ├── skill_entry.py        # メインエントリ
        ├── core/                 # コアモジュール
        └── README.md
```

#### 2. トリガーワードを確認
- ✅ 「既存アプリのベースライン仕様書を作成」（推奨）
- ✅ 「pochi-baseline-detailed を起動」（明示的）
- ✅ 「ベースライン仕様書の骨格版を作成」
- ❌ 「仕様書を作って」（曖昧）

### 実行エラーが発生する場合

#### エラー: 「Skills専用モードでのみ実行可能」
**原因**: 環境変数が設定されていない  
**解決**: Claude Code経由で起動（自動で環境変数が設定されます）

#### エラー: 「GitHub認証に失敗しました」
**原因**: `gh` CLIの認証が未設定  
**解決**: 
```bash
gh auth login
gh auth status  # 認証状態確認
```

#### エラー: 「リポジトリが見つかりません」
**原因**: リポジトリ名が不正  
**解決**: `owner/repository`形式で正確に入力

#### 品質チェック不合格（スコア60点未満）
**原因**: 骨格版の構造に問題あり  
**解決**: 
1. `quality_report.md`を確認
2. 問題点を特定
3. Phase 2で詳細化時に対応

## 安全対策

### Skills専用モード
- **環境変数チェック**: `POCHI_SKILL_ACTIVE=1`が必須
- **直接実行の防止**: セキュリティリスク低減

### データ保護
- イシューデータはローカルのみ保存
- 外部APIへのデータ送信なし（Phase 1）

### プライバシー
- GitHubトークンはログに出力しない
- イシュー内の機密情報は手動で確認

## Phase 2以降の予定

Phase 1完了後、以下をPhase 2以降で実施します：

### Phase 2: 詳細化実装（6-8時間）
- LLMによるプレースホルダー補完
- 詳細な章立て自動生成
- イシュー情報の自然文化

### Phase 3: プロンプト整備（3-4時間）
- 専用プロンプトテンプレート作成
- 品質基準の詳細化

### Phase 4: テスト・検証（4-5時間）
- 実機テスト
- ドキュメント整備

## 使用例

### 例1: 初回実行
```
ユーザー: 「既存アプリのベースライン仕様書を作成」

実行フロー:
1. skill_entry.py起動
2. リポジトリ入力: octocat/Hello-World
3. イシュー取得: 50件
4. ADR分類: High 5件, Medium 10件, Low 30件, Exclude 5件
5. 骨格版生成完了
6. 品質チェック: 65点（合格）
7. Phase 1完了
```

### 例2: 大規模リポジトリ
```
ユーザー: 「GitHubイシューからベースライン仕様書を生成」

実行フロー:
1. リポジトリ入力: kubernetes/kubernetes
2. イシュー取得: 500件（最新500件のみ）
3. ADR分類: High 50件, Medium 150件
4. 骨格版生成（章が多い）
5. 品質チェック: 70点（合格）
6. Phase 2で詳細化推奨
```

## バージョン・ライセンス

- **バージョン**: 1.0.0（Phase 1 - 骨格版生成）
- **作成者**: Pochi Development Team
- **ライセンス**: Internal Use Only

## 参照ドキュメント

- [README.md](./README.md): 概要とクイックスタート
- ベースライン仕様書作成ガイド: pochi-spec-initializer/docs/WORKFLOW.md を参照

---

**🚀 このSkillを起動するには、「既存アプリのベースライン仕様書を作成」とClaude Codeに指示してください。**
