"""
Pochi Baseline Detailed Builder - Core Modules

既存アプリのGitHubイシュー履歴からベースライン仕様書を作成するためのコアモジュール群
"""

__version__ = "1.0.0"

from .issue_fetcher import GitHubIssueFetcher
from .adr_classifier import ADRClassifier, classify_issues_for_adr, save_classification_config
from .skeleton_generator import SkeletonGenerator, generate_baseline_and_adr_skeletons
from .context_builder import ContextBuilder
from .quality_checker import QualityChecker

__all__ = [
    "GitHubIssueFetcher",
    "ADRClassifier",
    "classify_issues_for_adr",
    "save_classification_config",
    "SkeletonGenerator",
    "generate_baseline_and_adr_skeletons",
    "ContextBuilder",
    "QualityChecker",
]
