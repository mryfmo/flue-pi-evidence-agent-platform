"""
ADR分類モジュール

取得したイシューの中から、ADR（Architecture Decision Record）として
記録すべき重要なイシューを分類する。
"""

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
import pandas as pd
import yaml


class ADRClassifier:
    """ADR候補イシューの分類クラス"""
    
    def __init__(self):
        """初期化"""
        self.classification_criteria = {
            'high_priority': {
                'labels': ['critical', 'important', 'architecture', 'breaking-change'],
                'min_comments': 5,
                'min_reactions': 3
            },
            'medium_priority': {
                'labels': ['enhancement', 'feature'],
                'min_comments': 3,
                'min_reactions': 1
            },
            'low_priority': {
                'labels': ['documentation', 'refactor'],
                'min_comments': 1,
                'min_reactions': 0
            }
        }
    
    def classify_adr_candidates(
        self,
        issues_df: pd.DataFrame,
        comments_df: pd.DataFrame
    ) -> Dict[str, List[int]]:
        """
        イシューをADR候補として分類
        
        Args:
            issues_df: イシュー情報のDataFrame
            comments_df: コメント情報のDataFrame
            
        Returns:
            優先度別のイシュー番号リスト
            例: {
                'high_priority': [1, 5, 10],
                'medium_priority': [2, 6],
                'low_priority': [3, 7],
                'exclude': [4, 8, 9]
            }
        """
        print("🔍 ADR候補イシューを分類中...")
        
        classified = {
            'high_priority': [],
            'medium_priority': [],
            'low_priority': [],
            'exclude': []
        }
        
        if issues_df.empty:
            print("   ⚠️ イシューデータが空です")
            return classified
        
        # 各イシューを分類
        for _, issue in issues_df.iterrows():
            priority = self._classify_single_issue(issue, comments_df)
            classified[priority].append(issue['number'])
        
        self._print_classification_summary(classified)
        
        return classified
    
    def _classify_single_issue(
        self,
        issue: pd.Series,
        comments_df: pd.DataFrame
    ) -> str:
        """
        単一イシューを分類
        
        Args:
            issue: イシューのSeries
            comments_df: コメント情報のDataFrame
            
        Returns:
            'high_priority', 'medium_priority', 'low_priority', 'exclude'のいずれか
        """
        # スコア計算
        score = self._calculate_priority_score(issue, comments_df)
        
        # ラベルによる調整
        label_priority = self._classify_by_labels(issue)
        
        # ステータスによる調整
        status_penalty = self._get_status_penalty(issue)
        
        # 最終スコア
        final_score = score + label_priority - status_penalty
        
        # 閾値による分類
        if final_score >= 8.0:
            return 'high_priority'
        elif final_score >= 5.0:
            return 'medium_priority'
        elif final_score >= 2.0:
            return 'low_priority'
        else:
            return 'exclude'
    
    def _calculate_priority_score(
        self,
        issue: pd.Series,
        comments_df: pd.DataFrame
    ) -> float:
        """
        コメント数・リアクション数からスコアを算出
        
        Args:
            issue: イシューのSeries
            comments_df: コメント情報のDataFrame
            
        Returns:
            優先度スコア（0-10）
        """
        # コメント数スコア（最大4点）
        comment_score = min(issue.get('comments_count', 0) * 0.5, 4.0)
        
        # リアクション数スコア（最大3点）
        reaction_score = min(issue.get('reactions_total', 0) * 0.3, 3.0)
        
        # イシュー本文の長さスコア（最大2点）
        body_length = len(issue.get('body', ''))
        length_score = min(body_length / 500, 2.0)
        
        # コメントの質スコア（最大1点）
        issue_comments = comments_df[
            comments_df['issue_number'] == issue['number']
        ] if not comments_df.empty else pd.DataFrame()
        
        quality_score = 0.0
        if not issue_comments.empty:
            # 複数のユニーク投稿者がいれば議論が活発
            unique_authors = issue_comments['author'].nunique()
            quality_score = min(unique_authors * 0.2, 1.0)
        
        return comment_score + reaction_score + length_score + quality_score
    
    def _classify_by_labels(self, issue: pd.Series) -> float:
        """
        ラベルによる優先度調整
        
        Args:
            issue: イシューのSeries
            
        Returns:
            調整値（-2.0 ~ +3.0）
        """
        labels = issue.get('labels', [])
        if not isinstance(labels, list):
            labels = []
        
        adjustment = 0.0
        
        # 高優先度ラベル
        high_priority_labels = [
            'critical', 'important', 'architecture', 
            'breaking-change', 'security'
        ]
        for label in labels:
            if any(hp in label.lower() for hp in high_priority_labels):
                adjustment += 3.0
                break
        
        # 中優先度ラベル
        medium_priority_labels = [
            'enhancement', 'feature', 'performance',
            'refactor', 'design'
        ]
        for label in labels:
            if any(mp in label.lower() for mp in medium_priority_labels):
                adjustment += 1.5
                break
        
        # 低優先度ラベル（マイナス調整）
        low_priority_labels = [
            'documentation', 'typo', 'good first issue',
            'help wanted', 'question'
        ]
        for label in labels:
            if any(lp in label.lower() for lp in low_priority_labels):
                adjustment -= 1.0
                break
        
        return adjustment
    
    def _get_status_penalty(self, issue: pd.Series) -> float:
        """
        イシューのステータスによるペナルティ
        
        Args:
            issue: イシューのSeries
            
        Returns:
            ペナルティ値（0.0 ~ 3.0）
        """
        penalty = 0.0
        
        # クローズ済みイシューはペナルティ
        if issue.get('state') == 'closed':
            state_reason = issue.get('state_reason', '')
            
            # not_plannedの場合は大きなペナルティ
            if state_reason == 'not_planned':
                penalty += 3.0
            elif state_reason == 'completed':
                # completedの場合は小さなペナルティ
                penalty += 0.5
            else:
                # state_reasonがない場合も軽めのペナルティ
                penalty += 0.5
        
        # 古いイシューにもペナルティ（軽減版）
        if pd.notna(issue.get('created_at')):
            from datetime import datetime, timedelta, timezone
            created_at = issue['created_at']
            if isinstance(created_at, str):
                created_at = pd.to_datetime(created_at)
            
            # タイムゾーンを考慮した現在時刻
            now = datetime.now(timezone.utc) if created_at.tzinfo else datetime.now()
            age_days = (now - created_at).days
            
            # 3ヶ月以上前のイシューはペナルティ（最大1.0点に軽減）
            if age_days > 90:
                penalty += min((age_days - 90) / 270, 1.0)
        
        return penalty
    
    def _print_classification_summary(self, classified: Dict[str, List[int]]):
        """分類結果のサマリーを表示"""
        print("   分類結果:")
        print(f"   - 高優先度: {len(classified['high_priority'])}件")
        print(f"   - 中優先度: {len(classified['medium_priority'])}件")
        print(f"   - 低優先度: {len(classified['low_priority'])}件")
        print(f"   - 除外: {len(classified['exclude'])}件")
    
    def generate_config_yaml(
        self,
        classified_issues: Dict[str, List[int]],
        issues_df: pd.DataFrame,
        output_path: str
    ) -> str:
        """
        分類結果をYAML設定ファイルとして出力
        
        Args:
            classified_issues: 分類済みイシューのDict
            issues_df: イシュー情報のDataFrame
            output_path: 出力先YAMLファイルパス
            
        Returns:
            出力したYAMLファイルのパス
        """
        print(f"📝 設定ファイルを生成中: {output_path}")
        
        # プロジェクト名の推定（リポジトリ名から）
        project_name = 'Unknown Project'
        if not issues_df.empty and 'url' in issues_df.columns:
            first_url = issues_df.iloc[0]['url']
            # https://github.com/org/repo/issues/1 から repo を抽出
            parts = first_url.split('/')
            if len(parts) >= 5:
                project_name = parts[4]
        
        # イシューのメタデータを含む詳細設定
        config = {
            'project': {
                'name': project_name,
                'total_issues': len(issues_df) if not issues_df.empty else 0,
                'classification_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            },
            'adr_candidates': {
                'high_priority': self._build_issue_metadata(
                    classified_issues.get('high_priority', []),
                    issues_df
                ),
                'medium_priority': self._build_issue_metadata(
                    classified_issues.get('medium_priority', []),
                    issues_df
                ),
                'low_priority': self._build_issue_metadata(
                    classified_issues.get('low_priority', []),
                    issues_df
                ),
                'excluded': self._build_issue_metadata(
                    classified_issues.get('exclude', []),
                    issues_df
                )
            },
            'statistics': {
                'high_count': len(classified_issues.get('high_priority', [])),
                'medium_count': len(classified_issues.get('medium_priority', [])),
                'low_count': len(classified_issues.get('low_priority', [])),
                'excluded_count': len(classified_issues.get('exclude', []))
            }
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            yaml.dump(config, f, allow_unicode=True, default_flow_style=False)
        
        print(f"   ✅ 設定ファイル生成完了")
        
        return output_path
    
    def _build_issue_metadata(
        self,
        issue_numbers: List[int],
        issues_df: pd.DataFrame
    ) -> List[Dict[str, Any]]:
        """
        イシュー番号リストから詳細メタデータを構築
        
        Args:
            issue_numbers: イシュー番号のリスト
            issues_df: イシュー情報のDataFrame
            
        Returns:
            メタデータのリスト
        """
        metadata_list = []
        
        for number in issue_numbers:
            issue_row = issues_df[issues_df['number'] == number]
            
            if issue_row.empty:
                continue
            
            issue = issue_row.iloc[0]
            
            metadata = {
                'number': int(number),
                'title': str(issue.get('title', '')),
                'state': str(issue.get('state', '')),
                'labels': issue.get('labels', []) if isinstance(issue.get('labels'), list) else [],
                'comments_count': int(issue.get('comments_count', 0)),
                'created_at': str(issue.get('created_at', ''))
            }
            
            metadata_list.append(metadata)
        
        return metadata_list
    
    def validate_classification(
        self,
        classified_issues: Dict[str, List[int]],
        issues_df: pd.DataFrame
    ) -> Tuple[bool, List[str]]:
        """
        分類結果の妥当性を検証
        
        Args:
            classified_issues: 分類済みイシューのDict
            issues_df: イシュー情報のDataFrame
            
        Returns:
            (検証結果, エラーメッセージリスト)
        """
        errors = []
        
        # TODO: Phase 2で詳細実装
        # - 全イシューが分類されているか
        # - 重複がないか
        # - 存在しないイシュー番号がないか
        
        all_classified = set()
        for priority_list in classified_issues.values():
            all_classified.update(priority_list)
        
        all_issues = set(issues_df['number'].tolist()) if not issues_df.empty else set()
        
        # 基本的な検証のみ実装
        if len(all_classified) != len(all_issues):
            errors.append(
                f"分類漏れまたは重複があります "
                f"(分類済み: {len(all_classified)}, 全体: {len(all_issues)})"
            )
        
        is_valid = len(errors) == 0
        
        if is_valid:
            print("   ✅ 分類結果の検証完了")
        else:
            print("   ⚠️  分類結果に問題があります")
            for error in errors:
                print(f"      - {error}")
        
        return is_valid, errors


# 便利関数

def classify_issues_for_adr(
    issues_df: pd.DataFrame,
    comments_df: pd.DataFrame
) -> Dict[str, List[int]]:
    """
    イシューをADR候補として分類（簡易版）
    
    Args:
        issues_df: イシュー情報のDataFrame
        comments_df: コメント情報のDataFrame
        
    Returns:
        優先度別のイシュー番号リスト
    """
    classifier = ADRClassifier()
    return classifier.classify_adr_candidates(issues_df, comments_df)


def save_classification_config(
    classified_issues: Dict[str, List[int]],
    issues_df: pd.DataFrame,
    output_path: str
) -> None:
    """
    分類結果を設定ファイルとして保存（簡易版）
    
    Args:
        classified_issues: 分類済みイシューのDict
        issues_df: イシュー情報のDataFrame
        output_path: 出力先YAMLファイルパス
    """
    classifier = ADRClassifier()
    classifier.generate_config_yaml(classified_issues, issues_df, output_path)
