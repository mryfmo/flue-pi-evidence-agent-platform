"""
品質チェックモジュール

生成されたベースライン仕様書とADRの品質を自動チェックする。
プレースホルダーの残存、具体性の欠如、参照の不備などを検出する。
"""

import re
from typing import Dict, List, Tuple, Any, Optional
from pathlib import Path


class QualityChecker:
    """仕様書品質チェッククラス"""
    
    def __init__(self):
        """初期化"""
        self.abstract_phrases = [
            '適切に', '必要に応じて', '場合によって', '状況に応じて',
            '適宜', '適当に', 'など', 'その他', '等'
        ]
        self.placeholder_patterns = [
            r'\[TODO:.*?\]',
            r'\[要確認\]',
            r'\[未定\]',
            r'XXX',
            r'TBD'
        ]
    
    def check_quality(
        self,
        baseline_spec_path: str,
        adr_path: str,
        all_issue_numbers: Optional[List[int]] = None
    ) -> Dict[str, Any]:
        """
        仕様書の品質を総合的にチェック
        
        Args:
            baseline_spec_path: ベースライン仕様書のパス
            adr_path: ADRのパス
            all_issue_numbers: 参照可能なイシュー番号のリスト
            
        Returns:
            品質チェック結果のDict
        """
        print("🔍 仕様書の品質チェックを実施中...")
        
        results = {
            'baseline': {},
            'adr': {},
            'overall': {}
        }
        
        # ベースライン仕様書のチェック
        if Path(baseline_spec_path).exists():
            with open(baseline_spec_path, 'r', encoding='utf-8') as f:
                baseline_content = f.read()
            
            results['baseline'] = self._check_document(
                baseline_content,
                'baseline',
                all_issue_numbers
            )
        
        # ADRのチェック
        if Path(adr_path).exists():
            with open(adr_path, 'r', encoding='utf-8') as f:
                adr_content = f.read()
            
            results['adr'] = self._check_document(
                adr_content,
                'adr',
                all_issue_numbers
            )
        
        # 総合評価
        results['overall'] = self._calculate_overall_score(results)
        
        self._print_summary(results)
        
        return results
    
    def _check_document(
        self,
        content: str,
        doc_type: str,
        all_issue_numbers: Optional[List[int]]
    ) -> Dict[str, Any]:
        """個別ドキュメントのチェック"""
        
        result = {
            'doc_type': doc_type,
            'placeholders': self._check_placeholder_remaining(content),
            'abstract_phrases': self._check_abstract_phrases(content),
            'issue_references': self._check_issue_references(
                content,
                all_issue_numbers
            ) if all_issue_numbers else [],
            'concreteness': self._check_concreteness(content),
            'completeness': self._check_completeness(content, doc_type)
        }
        
        return result
    
    def _check_placeholder_remaining(self, content: str) -> List[Dict[str, Any]]:
        """プレースホルダーの残存をチェック"""
        placeholders = []
        
        for pattern in self.placeholder_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                # 行番号を取得
                line_num = content[:match.start()].count('\n') + 1
                placeholders.append({
                    'type': 'placeholder',
                    'pattern': pattern,
                    'text': match.group(),
                    'line': line_num
                })
        
        return placeholders
    
    def _check_abstract_phrases(self, content: str) -> List[Dict[str, Any]]:
        """抽象的な表現をチェック"""
        abstract_found = []
        
        for phrase in self.abstract_phrases:
            # 完全一致ではなく部分一致で検索
            pattern = re.escape(phrase)
            matches = re.finditer(pattern, content)
            
            for match in matches:
                line_num = content[:match.start()].count('\n') + 1
                # コンテキストを取得（前後20文字）
                start = max(0, match.start() - 20)
                end = min(len(content), match.end() + 20)
                context = content[start:end]
                
                abstract_found.append({
                    'type': 'abstract_phrase',
                    'phrase': phrase,
                    'line': line_num,
                    'context': context.replace('\n', ' ')
                })
        
        return abstract_found
    
    def _check_issue_references(
        self,
        content: str,
        all_issue_numbers: List[int]
    ) -> List[Dict[str, Any]]:
        """イシュー参照の妥当性をチェック"""
        issues_found = []
        
        # #数字 パターンでイシュー参照を検出
        pattern = r'#(\d+)'
        matches = re.finditer(pattern, content)
        
        for match in matches:
            issue_num = int(match.group(1))
            line_num = content[:match.start()].count('\n') + 1
            
            # 存在しないイシュー番号を警告
            if issue_num not in all_issue_numbers:
                issues_found.append({
                    'type': 'invalid_reference',
                    'issue_number': issue_num,
                    'line': line_num,
                    'message': f'Issue #{issue_num} は存在しません'
                })
        
        return issues_found
    
    def check_specificity(self, content: str, issues_data: List[Dict] = None) -> Dict[str, Any]:
        """
        記述の具体性をチェック（Phase 2新規実装）
        
        チェック項目:
        - イシュー番号の参照数
        - 抽象的なフレーズの使用頻度
        - 技術用語の使用状況
        """
        # イシュー参照数をカウント
        issue_references = re.findall(r'#(\d+)', content)
        unique_issue_refs = len(set(issue_references))
        total_issue_refs = len(issue_references)
        
        # 抽象的フレーズのカウント
        abstract_phrase_matches = []
        for phrase in self.abstract_phrases:
            matches = len(re.findall(re.escape(phrase), content))
            if matches > 0:
                abstract_phrase_matches.append({
                    'phrase': phrase,
                    'count': matches
                })
        total_abstract_phrases = sum(m['count'] for m in abstract_phrase_matches)
        
        # 技術用語のカウント（一般的な技術用語リスト）
        technical_terms = [
            'API', 'データベース', 'サーバー', 'クライアント', 'アーキテクチャ',
            'フレームワーク', 'ライブラリ', 'インターフェース', 'プロトコル',
            'アルゴリズム', 'セキュリティ', 'パフォーマンス', '認証', '暗号化'
        ]
        tech_term_count = sum(
            len(re.findall(re.escape(term), content, re.IGNORECASE))
            for term in technical_terms
        )
        
        # コードブロックと数値
        code_blocks = len(re.findall(r'```', content)) // 2
        numbers = len(re.findall(r'\d+', content))
        
        # 具体性スコア算出（0-100点）
        # イシュー参照: 最大30点（10参照で満点）
        issue_score = min(30, unique_issue_refs * 3)
        
        # 技術用語: 最大30点（30用語で満点）
        tech_score = min(30, tech_term_count)
        
        # コードブロック: 最大20点（5ブロックで満点）
        code_score = min(20, code_blocks * 4)
        
        # 抽象フレーズ減点: 最大-20点（10フレーズで-20点）
        abstract_penalty = min(20, total_abstract_phrases * 2)
        
        specificity_score = max(0, issue_score + tech_score + code_score - abstract_penalty + 20)
        
        return {
            'score': round(specificity_score, 1),
            'issue_references': {
                'unique': unique_issue_refs,
                'total': total_issue_refs
            },
            'abstract_phrases': {
                'total': total_abstract_phrases,
                'details': abstract_phrase_matches
            },
            'technical_terms': tech_term_count,
            'code_blocks': code_blocks,
            'numbers_count': numbers
        }
    
    def check_consistency(self, detailed_md: str, adr_md: str = None) -> Dict[str, Any]:
        """
        ドキュメント間の一貫性をチェック（Phase 2新規実装）
        
        チェック項目:
        - ADRの参照が正しいか
        - 技術用語の使用が統一されているか
        - 矛盾する記述がないか
        """
        # ADR参照のチェック
        adr_references = re.findall(r'ADR-(\d{3})', detailed_md)
        unique_adr_refs = set(adr_references)
        
        # ADR文書が存在する場合、実際のADR番号と照合
        valid_adr_refs = []
        invalid_adr_refs = []
        
        if adr_md:
            actual_adrs = set(re.findall(r'ADR-(\d{3})', adr_md))
            for ref in unique_adr_refs:
                if ref in actual_adrs:
                    valid_adr_refs.append(ref)
                else:
                    invalid_adr_refs.append(ref)
        else:
            # ADR文書がない場合は全て有効と見なす
            valid_adr_refs = list(unique_adr_refs)
        
        # 技術用語の統一性チェック（同じ概念の異なる表記）
        term_variations = {
            'データベース': ['DB', 'database', 'データベース'],
            'API': ['API', 'api', 'インターフェース'],
            'サーバー': ['サーバ', 'サーバー', 'server'],
        }
        
        inconsistent_terms = []
        for concept, variations in term_variations.items():
            found_variations = [v for v in variations if v in detailed_md]
            if len(found_variations) > 1:
                inconsistent_terms.append({
                    'concept': concept,
                    'variations': found_variations
                })
        
        # 矛盾チェック（矛盾を示すキーワード）
        contradiction_patterns = [
            (r'使用する.*?使用しない', '使用有無の矛盾'),
            (r'必須.*?任意', '必須/任意の矛盾'),
            (r'推奨.*?非推奨', '推奨/非推奨の矛盾')
        ]
        
        potential_contradictions = []
        for pattern, description in contradiction_patterns:
            matches = re.finditer(pattern, detailed_md, re.DOTALL)
            for match in matches:
                potential_contradictions.append({
                    'description': description,
                    'text': match.group()[:100] + '...'
                })
        
        # 一貫性スコア算出（0-100点）
        # ADR参照: 無効な参照1つで-10点
        adr_penalty = len(invalid_adr_refs) * 10
        
        # 技術用語: 不統一1つで-5点
        term_penalty = len(inconsistent_terms) * 5
        
        # 矛盾: 1つで-15点
        contradiction_penalty = len(potential_contradictions) * 15
        
        consistency_score = max(0, 100 - adr_penalty - term_penalty - contradiction_penalty)
        
        return {
            'score': round(consistency_score, 1),
            'adr_references': {
                'total': len(adr_references),
                'unique': len(unique_adr_refs),
                'valid': valid_adr_refs,
                'invalid': invalid_adr_refs
            },
            'inconsistent_terms': inconsistent_terms,
            'potential_contradictions': potential_contradictions
        }
    
    def _check_completeness(
        self,
        content: str,
        doc_type: str
    ) -> Dict[str, Any]:
        """
        完成度をチェック（Phase 2強化版）
        
        チェック項目:
        - プレースホルダーが残っていないか
        - 必須セクションが存在するか
        - 最小文字数を満たしているか
        """
        # プレースホルダーパターン（Phase 2用）
        phase2_placeholder_pattern = r'\{\{PLACEHOLDER_[A-Z0-9_]+\}\}'
        remaining_placeholders = re.findall(phase2_placeholder_pattern, content)
        
        # 必須セクションの定義
        required_sections_baseline = [
            '概要', 'システム構成', '機能要件', 'データモデル',
            'アーキテクチャ決定記録'
        ]
        required_sections_adr = [
            'コンテキスト', '決定内容', '理由', '影響'
        ]
        
        required = (
            required_sections_baseline if doc_type == 'baseline'
            else required_sections_adr
        )
        
        missing_sections = []
        found_sections = []
        
        for section in required:
            if section in content:
                found_sections.append(section)
            else:
                missing_sections.append(section)
        
        # 最小文字数チェック
        min_chars = 5000 if doc_type == 'baseline' else 1000
        char_count = len(content)
        meets_min_chars = char_count >= min_chars
        
        # 完全性スコア算出（0-100点）
        placeholder_penalty = len(remaining_placeholders) * 20  # 1個で-20点
        section_score = (len(found_sections) / len(required) * 100) if required else 100
        char_score = min(100, (char_count / min_chars) * 100)
        
        # 重み付け: セクション60% + 文字数30% + プレースホルダー減点10%
        completeness_score = max(0, 
            section_score * 0.6 + 
            char_score * 0.3 - 
            placeholder_penalty * 0.1
        )
        
        return {
            'score': round(completeness_score, 1),
            'remaining_placeholders': remaining_placeholders,
            'placeholder_count': len(remaining_placeholders),
            'required_sections': required,
            'found_sections': found_sections,
            'missing_sections': missing_sections,
            'char_count': char_count,
            'min_chars': min_chars,
            'meets_min_chars': meets_min_chars,
            'completeness_rate': round(section_score, 1)
        }
    
    def calculate_overall_score(self, checks: Dict[str, Dict]) -> Dict[str, Any]:
        """
        各チェック結果から総合スコアを算出（Phase 2新規実装）
        
        重み付け:
        - 完全性: 30%
        - 具体性: 30%
        - 一貫性: 20%
        - その他: 20%
        """
        completeness_score = checks.get('completeness', {}).get('score', 0)
        specificity_score = checks.get('specificity', {}).get('score', 0)
        consistency_score = checks.get('consistency', {}).get('score', 0)
        
        # その他のスコア（従来の品質チェック）
        other_score = 100
        
        # プレースホルダー残存
        placeholders = checks.get('completeness', {}).get('placeholder_count', 0)
        other_score -= placeholders * 10
        
        # 抽象表現
        abstract_phrases = checks.get('specificity', {}).get('abstract_phrases', {}).get('total', 0)
        other_score -= abstract_phrases * 2
        
        other_score = max(0, other_score)
        
        # 総合スコア算出
        overall_score = (
            completeness_score * 0.3 +
            specificity_score * 0.3 +
            consistency_score * 0.2 +
            other_score * 0.2
        )
        
        # グレード判定
        if overall_score >= 90:
            grade = 'A'
            quality_level = '優良'
        elif overall_score >= 75:
            grade = 'B'
            quality_level = '良好'
        elif overall_score >= 60:
            grade = 'C'
            quality_level = '要改善'
        else:
            grade = 'D'
            quality_level = '不合格'
        
        # 合格判定（60点以上）
        passed = overall_score >= 60
        
        return {
            'overall_score': round(overall_score, 1),
            'grade': grade,
            'quality_level': quality_level,
            'pass': passed,
            'details': {
                'completeness': round(completeness_score, 1),
                'specificity': round(specificity_score, 1),
                'consistency': round(consistency_score, 1),
                'other': round(other_score, 1)
            },
            'weights': {
                'completeness': '30%',
                'specificity': '30%',
                'consistency': '20%',
                'other': '20%'
            }
        }
    
    def _check_concreteness(self, content: str) -> Dict[str, Any]:
        """具体性をチェック（従来版、互換性維持）"""
        total_chars = len(content)
        total_lines = content.count('\n') + 1
        
        # コードブロックの数
        code_blocks = len(re.findall(r'```', content)) // 2
        
        # 数値の出現回数
        numbers = len(re.findall(r'\d+', content))
        
        return {
            'total_chars': total_chars,
            'total_lines': total_lines,
            'code_blocks': code_blocks,
            'numbers_count': numbers,
            'avg_line_length': total_chars / total_lines if total_lines > 0 else 0
        }
    
    def _calculate_overall_score(
        self,
        results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """総合評価スコアを計算（従来の互換性維持）"""
        
        total_issues = 0
        critical_issues = 0
        warnings = 0
        
        for doc_key in ['baseline', 'adr']:
            if doc_key not in results or not results[doc_key]:
                continue
            
            doc_result = results[doc_key]
            
            # プレースホルダーの残存は重大な問題
            placeholders = doc_result.get('placeholders', [])
            critical_issues += len(placeholders)
            total_issues += len(placeholders)
            
            # 抽象表現は警告
            abstract = doc_result.get('abstract_phrases', [])
            warnings += len(abstract)
            total_issues += len(abstract)
            
            # 無効なイシュー参照は重大な問題
            invalid_refs = doc_result.get('issue_references', [])
            critical_issues += len(invalid_refs)
            total_issues += len(invalid_refs)
        
        # 総合スコア計算（100点満点）
        # 重大問題: -10点/件、警告: -2点/件
        score = max(0, 100 - (critical_issues * 10 + warnings * 2))
        
        # 品質判定
        if score >= 80:
            quality_level = '優良'
        elif score >= 60:
            quality_level = '良好'
        elif score >= 40:
            quality_level = '要改善'
        else:
            quality_level = '不合格'
        
        return {
            'score': score,
            'quality_level': quality_level,
            'total_issues': total_issues,
            'critical_issues': critical_issues,
            'warnings': warnings,
            'passed': score >= 60
        }
    
    def _print_summary(self, results: Dict[str, Any]):
        """チェック結果のサマリーを表示"""
        overall = results.get('overall', {})
        
        print("\n" + "=" * 60)
        print("品質チェック結果サマリー")
        print("=" * 60)
        print(f"総合スコア: {overall.get('score', 0)}/100")
        print(f"品質レベル: {overall.get('quality_level', 'N/A')}")
        print(f"重大な問題: {overall.get('critical_issues', 0)}件")
        print(f"警告: {overall.get('warnings', 0)}件")
        print("=" * 60)
        
        # 個別ドキュメントの結果
        for doc_key in ['baseline', 'adr']:
            if doc_key not in results or not results[doc_key]:
                continue
            
            doc_result = results[doc_key]
            doc_name = 'ベースライン仕様書' if doc_key == 'baseline' else 'ADR'
            
            print(f"\n【{doc_name}】")
            
            placeholders = doc_result.get('placeholders', [])
            if placeholders:
                print(f"  ⚠️  プレースホルダー残存: {len(placeholders)}件")
            
            abstract = doc_result.get('abstract_phrases', [])
            if abstract:
                print(f"  ⚠️  抽象表現: {len(abstract)}件")
            
            completeness = doc_result.get('completeness', {})
            rate = completeness.get('completeness_rate', 0)
            print(f"  📊 完成度: {rate:.1f}%")
        
        if overall.get('passed', False):
            print("\n✅ 品質チェック合格")
        else:
            print("\n❌ 品質チェック不合格 - 改善が必要です")
    
    def generate_report(
        self,
        results: Dict[str, Any],
        output_path: str
    ) -> str:
        """
        品質チェック結果をレポートとして出力
        
        Args:
            results: チェック結果のDict
            output_path: 出力先パス
            
        Returns:
            出力したレポートファイルのパス
        """
        print(f"📄 品質レポートを生成中: {output_path}")
        
        overall = results.get('overall', {})
        
        report = f"""# 品質チェックレポート

## 総合評価

- **スコア**: {overall.get('score', 0)}/100
- **品質レベル**: {overall.get('quality_level', 'N/A')}
- **判定**: {'✅ 合格' if overall.get('passed', False) else '❌ 不合格'}

## 問題サマリー

- 重大な問題: {overall.get('critical_issues', 0)}件
- 警告: {overall.get('warnings', 0)}件
- 合計: {overall.get('total_issues', 0)}件

"""
        
        # 個別ドキュメントの詳細
        for doc_key in ['baseline', 'adr']:
            if doc_key not in results or not results[doc_key]:
                continue
            
            doc_result = results[doc_key]
            doc_name = 'ベースライン仕様書' if doc_key == 'baseline' else 'ADR'
            
            report += f"\n## {doc_name}\n\n"
            
            # プレースホルダー
            placeholders = doc_result.get('placeholders', [])
            if placeholders:
                report += f"### ⚠️ プレースホルダー残存 ({len(placeholders)}件)\n\n"
                for ph in placeholders[:10]:  # 最初の10件のみ
                    report += f"- 行{ph['line']}: `{ph['text']}`\n"
                if len(placeholders) > 10:
                    report += f"\n（他 {len(placeholders) - 10} 件）\n"
                report += "\n"
            
            # 抽象表現
            abstract = doc_result.get('abstract_phrases', [])
            if abstract:
                report += f"### ⚠️ 抽象表現 ({len(abstract)}件)\n\n"
                for ab in abstract[:10]:
                    report += f"- 行{ab['line']}: `{ab['phrase']}` - {ab['context']}\n"
                if len(abstract) > 10:
                    report += f"\n（他 {len(abstract) - 10} 件）\n"
                report += "\n"
            
            # 完成度
            completeness = doc_result.get('completeness', {})
            report += f"### 📊 完成度: {completeness.get('completeness_rate', 0):.1f}%\n\n"
            
            missing = completeness.get('missing_sections', [])
            if missing:
                report += "**不足セクション**:\n"
                for section in missing:
                    report += f"- {section}\n"
                report += "\n"
        
        report += """
## 推奨事項

1. すべてのプレースホルダーを具体的な内容で置換してください
2. 抽象的な表現を避け、具体的な実装詳細を記述してください
3. 不足しているセクションを追加してください
4. イシュー参照を適切に行ってください

---
*自動生成レポート*
"""
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"   ✅ レポート生成完了")
        
        return output_path


# 便利関数

def check_spec_quality(
    baseline_spec_path: str,
    adr_path: str,
    all_issue_numbers: Optional[List[int]] = None
) -> Dict[str, Any]:
    """
    仕様書の品質をチェック（簡易版）
    
    Args:
        baseline_spec_path: ベースライン仕様書のパス
        adr_path: ADRのパス
        all_issue_numbers: 参照可能なイシュー番号のリスト
        
    Returns:
        品質チェック結果のDict
    """
    checker = QualityChecker()
    return checker.check_quality(baseline_spec_path, adr_path, all_issue_numbers)
