"""
GitHub Issues取得モジュール

既存アプリのイシュー履歴から詳細情報を取得し、pandas DataFrameで返却する。
"""

import re
import subprocess
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry


def validate_repo_name(repo: str) -> str:
    """リポジトリ名をバリデーション

    Args:
        repo: リポジトリ名（owner/repo形式またはrepo名のみ）

    Returns:
        バリデーション済みのリポジトリ名

    Raises:
        ValueError: 無効なリポジトリ名の場合
    """
    if '/' in repo:
        parts = repo.split('/')
        if len(parts) != 2:
            raise ValueError(f"無効なリポジトリ名: {repo}")
        org, name = parts
    else:
        org, name = None, repo

    pattern = r'^[a-zA-Z0-9._-]+$'
    if org and not re.match(pattern, org):
        raise ValueError(f"無効な組織名: {org}")
    if not re.match(pattern, name):
        raise ValueError(f"無効なリポジトリ名: {name}")
    return repo


def validate_issue_number(issue_number) -> int:
    """イシュー番号を整数バリデーション

    Args:
        issue_number: イシュー番号

    Returns:
        バリデーション済みの正の整数

    Raises:
        ValueError: 無効なイシュー番号の場合
    """
    try:
        num = int(issue_number)
        if num <= 0:
            raise ValueError
        return num
    except (ValueError, TypeError):
        raise ValueError(f"無効なイシュー番号: {issue_number}")


class GitHubIssueFetcher:
    """GitHub Issues取得クラス"""
    
    def __init__(self, org: str = 'nttdocomo-com'):
        """
        初期化
        
        Args:
            org: GitHub組織名（デフォルト: nttdocomo-com）
        """
        self.org = org
        self.token = None
        self.session = None
        
    def _get_github_token(self) -> Optional[str]:
        """
        `gh` CLIを使って認証済みトークンを安全に取得
        
        Returns:
            GitHubトークン、取得できない場合はNone
        """
        try:
            result = subprocess.run(
                ['gh', 'auth', 'token'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=10
            )
            if result.returncode == 0:
                return result.stdout.decode('utf-8').strip()
                    
        except subprocess.TimeoutExpired:
            print("⚠️  GitHub認証トークン取得がタイムアウトしました")
        except FileNotFoundError:
            print("⚠️  'gh' CLIが見つかりません。インストールしてください。")
        except Exception as e:
            print(f"⚠️  GitHub認証トークンの取得に失敗: {e}")
            
        return None
    
    def _create_session(self) -> requests.Session:
        """
        リトライ機能付きのHTTPセッションを作成
        
        Returns:
            設定済みのrequests.Session
        """
        session = requests.Session()
        retries = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504]
        )
        session.mount('https://', HTTPAdapter(max_retries=retries))
        return session
    
    def initialize(self) -> bool:
        """
        認証とセッションの初期化
        
        Returns:
            初期化成功時True、失敗時False
        """
        print("🔐 GitHub認証トークンを取得中...")
        self.token = self._get_github_token()
        
        if not self.token:
            print("❌ GitHub認証トークンが取得できませんでした")
            print("   'gh auth login' を実行して認証してください")
            return False
        
        self.session = self._create_session()
        print("✅ GitHub認証成功")
        return True
    
    def fetch_issues(
        self,
        repo: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        per_page: int = 100
    ) -> pd.DataFrame:
        """
        指定リポジトリのイシュー一覧を取得
        
        Args:
            repo: リポジトリ名
            start_date: 取得開始日（省略時は全期間）
            end_date: 取得終了日（省略時は全期間）
            per_page: ページあたりのイシュー数
            
        Returns:
            イシュー情報のDataFrame
            
        Raises:
            RuntimeError: 初期化されていない場合
            requests.RequestException: API呼び出しエラー
        """
        if not self.session or not self.token:
            raise RuntimeError("initialize()を先に呼び出してください")
        
        headers = {
            'Authorization': f'token {self.token}',
            'Accept': 'application/vnd.github.v3+json'
        }

        # repoが既にowner/repo形式かチェック
        if '/' in repo:
            full_repo = validate_repo_name(repo)
        else:
            full_repo = validate_repo_name(f"{self.org}/{repo}")

        print(f"📥 {full_repo} からイシューを取得中...")

        page = 1
        all_issues = []

        while True:
            url = f"https://api.github.com/repos/{full_repo}/issues"
            params = {
                'state': 'all',
                'page': page,
                'per_page': per_page
            }
            
            try:
                response = self.session.get(url, headers=headers, params=params, timeout=30)
                response.raise_for_status()
                page_issues = response.json()
                
                # APIレスポンスの型検証
                if not isinstance(page_issues, list):
                    print(f"⚠️  予期しないAPIレスポンス形式 (page {page}): スキップします")
                    break
                
                # PRを除外
                page_issues = [
                    issue for issue in page_issues
                    if isinstance(issue, dict) and 'pull_request' not in issue
                ]
                
                all_issues.extend(page_issues)
                
                if len(response.json()) < per_page:
                    break
                    
                page += 1
                time.sleep(0.1)  # API Rate Limit対策
                
            except requests.Timeout:
                print(f"⚠️  タイムアウト (page {page}): スキップします")
                break
            except requests.RequestException as e:
                print(f"⚠️  イシュー取得エラー (page {page}): {e}")
                break
        
        print(f"   取得完了: {len(all_issues)}件")
        
        # 期間フィルタリング
        if start_date or end_date:
            filtered_issues = self._filter_by_date(all_issues, start_date, end_date)
            print(f"   期間フィルタ後: {len(filtered_issues)}件")
            all_issues = filtered_issues
        
        # DataFrameに変換
        return self._issues_to_dataframe(all_issues)
    
    def _filter_by_date(
        self,
        issues: List[Dict],
        start_date: Optional[datetime],
        end_date: Optional[datetime]
    ) -> List[Dict]:
        """イシューを作成日時でフィルタリング"""
        filtered = []
        
        for issue in issues:
            created_at = datetime.strptime(
                issue['created_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )
            
            if start_date and created_at < start_date:
                continue
            if end_date and created_at > end_date:
                continue
                
            filtered.append(issue)
        
        return filtered
    
    def _issues_to_dataframe(self, issues: List[Dict]) -> pd.DataFrame:
        """イシューリストをDataFrameに変換"""
        records = []
        
        for issue in issues:
            created_at = datetime.strptime(
                issue['created_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )
            updated_at = datetime.strptime(
                issue['updated_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )
            
            closed_at = None
            if issue.get('closed_at'):
                closed_at = datetime.strptime(
                    issue['closed_at'],
                    "%Y-%m-%dT%H:%M:%SZ"
                )
            
            body = issue.get('body') or ''
            labels = [label['name'] for label in issue.get('labels', [])]
            assignees = [user['login'] for user in issue.get('assignees', [])]
            milestone = issue['milestone']['title'] if issue.get('milestone') else None
            
            records.append({
                'number': issue['number'],
                'title': issue['title'],
                'body': body,
                'created_at': created_at,
                'updated_at': updated_at,
                'closed_at': closed_at,
                'state': issue['state'],
                'state_reason': issue.get('state_reason'),
                'creator': issue['user']['login'],
                'author_association': issue.get('author_association'),
                'assignees': assignees,
                'labels': labels,
                'milestone': milestone,
                'comments_count': issue.get('comments', 0),
                'reactions_total': issue.get('reactions', {}).get('total_count', 0),
                'url': issue['html_url']
            })
        
        df = pd.DataFrame(records)
        
        # 作成日時でソート
        if not df.empty:
            df = df.sort_values('created_at').reset_index(drop=True)
        
        return df
    
    def fetch_comments(
        self,
        repo: str,
        issue_numbers: List[int]
    ) -> pd.DataFrame:
        """
        複数イシューのコメントを一括取得
        
        Args:
            repo: リポジトリ名
            issue_numbers: イシュー番号のリスト
            
        Returns:
            コメント情報のDataFrame
        """
        if not self.session or not self.token:
            raise RuntimeError("initialize()を先に呼び出してください")
        
        headers = {
            'Authorization': f'token {self.token}',
            'Accept': 'application/vnd.github.v3+json'
        }

        # repoが既にowner/repo形式かチェック
        if '/' in repo:
            full_repo = validate_repo_name(repo)
        else:
            full_repo = validate_repo_name(f"{self.org}/{repo}")

        print(f"💬 コメントを取得中... (対象: {len(issue_numbers)}件)")

        all_comments = []

        for i, issue_number in enumerate(issue_numbers, 1):
            validated_issue_number = validate_issue_number(issue_number)
            if i % 10 == 0:
                print(f"   進捗: {i}/{len(issue_numbers)}")

            url = f"https://api.github.com/repos/{full_repo}/issues/{validated_issue_number}/comments"
            
            try:
                response = self.session.get(url, headers=headers, timeout=30)
                response.raise_for_status()
                comments = response.json()
                
                # APIレスポンスの型検証
                if not isinstance(comments, list):
                    print(f"⚠️  Issue #{validated_issue_number} のコメント: 予期しないレスポンス形式")
                    continue
                
                for comment in comments:
                    comment['issue_number'] = issue_number
                    all_comments.append(comment)
                
                time.sleep(0.1)  # API Rate Limit対策
                
            except requests.RequestException as e:
                print(f"⚠️  Issue #{issue_number} のコメント取得エラー: {e}")
                continue
        
        print(f"   取得完了: {len(all_comments)}件")
        
        return self._comments_to_dataframe(all_comments)
    
    def _comments_to_dataframe(self, comments: List[Dict]) -> pd.DataFrame:
        """コメントリストをDataFrameに変換"""
        if not comments:
            return pd.DataFrame()
        
        records = []
        
        for comment in comments:
            created_at = datetime.strptime(
                comment['created_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )
            updated_at = datetime.strptime(
                comment['updated_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )
            
            records.append({
                'issue_number': comment['issue_number'],
                'comment_id': comment['id'],
                'author': comment['user']['login'],
                'author_association': comment.get('author_association'),
                'created_at': created_at,
                'updated_at': updated_at,
                'body': comment['body'],
                'reactions_total': comment.get('reactions', {}).get('total_count', 0)
            })
        
        return pd.DataFrame(records)
    
    def fetch_events(
        self,
        repo: str,
        issue_numbers: List[int]
    ) -> pd.DataFrame:
        """
        複数イシューのイベント履歴を一括取得
        
        Args:
            repo: リポジトリ名
            issue_numbers: イシュー番号のリスト
            
        Returns:
            イベント情報のDataFrame
        """
        if not self.session or not self.token:
            raise RuntimeError("initialize()を先に呼び出してください")
        
        headers = {
            'Authorization': f'token {self.token}',
            'Accept': 'application/vnd.github.v3+json'
        }

        # repoが既にowner/repo形式かチェック
        if '/' in repo:
            full_repo = validate_repo_name(repo)
        else:
            full_repo = validate_repo_name(f"{self.org}/{repo}")

        print(f"📋 イベント履歴を取得中... (対象: {len(issue_numbers)}件)")

        all_events = []

        for i, issue_number in enumerate(issue_numbers, 1):
            validated_issue_number = validate_issue_number(issue_number)
            if i % 10 == 0:
                print(f"   進捗: {i}/{len(issue_numbers)}")

            url = f"https://api.github.com/repos/{full_repo}/issues/{validated_issue_number}/events"
            
            try:
                response = self.session.get(url, headers=headers, timeout=30)
                response.raise_for_status()
                events = response.json()
                
                # APIレスポンスの型検証
                if not isinstance(events, list):
                    print(f"⚠️  Issue #{validated_issue_number} のイベント: 予期しないレスポンス形式")
                    continue
                
                for event in events:
                    event['issue_number'] = issue_number
                    all_events.append(event)
                
                time.sleep(0.1)  # API Rate Limit対策
                
            except requests.RequestException as e:
                print(f"⚠️  Issue #{issue_number} のイベント取得エラー: {e}")
                continue
        
        print(f"   取得完了: {len(all_events)}件")
        
        return self._events_to_dataframe(all_events)
    
    def _events_to_dataframe(self, events: List[Dict]) -> pd.DataFrame:
        """イベントリストをDataFrameに変換"""
        if not events:
            return pd.DataFrame()
        
        records = []
        
        for event in events:
            created_at = datetime.strptime(
                event['created_at'],
                "%Y-%m-%dT%H:%M:%SZ"
            )
            
            # イベントタイプに応じた情報を取得
            label_name = ''
            if event['event'] in ['labeled', 'unlabeled'] and event.get('label'):
                label_name = event['label'].get('name', '')
            
            milestone_title = ''
            if event['event'] in ['milestoned', 'demilestoned'] and event.get('milestone'):
                milestone_title = event['milestone'].get('title', '')
            
            assignee = ''
            if event['event'] in ['assigned', 'unassigned'] and event.get('assignee'):
                assignee = event['assignee'].get('login', '')
            
            actor_login = ''
            if event.get('actor'):
                actor_login = event['actor'].get('login', '')
            
            records.append({
                'issue_number': event['issue_number'],
                'event_id': event['id'],
                'event_type': event['event'],
                'actor': actor_login,
                'created_at': created_at,
                'label_name': label_name,
                'milestone_title': milestone_title,
                'assignee': assignee
            })
        
        return pd.DataFrame(records)


# 便利関数（後方互換性のため）

def get_github_token() -> Optional[str]:
    """
    GitHub認証トークンを取得（後方互換性のため）
    
    Returns:
        GitHubトークン、取得できない場合はNone
    """
    fetcher = GitHubIssueFetcher()
    return fetcher._get_github_token()


def fetch_github_issues(
    repo: str,
    org: str = 'nttdocomo-com',
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None
) -> pd.DataFrame:
    """
    GitHubイシューを取得（簡易版）
    
    Args:
        repo: リポジトリ名
        org: 組織名
        start_date: 取得開始日
        end_date: 取得終了日
        
    Returns:
        イシュー情報のDataFrame
    """
    fetcher = GitHubIssueFetcher(org=org)
    if not fetcher.initialize():
        raise RuntimeError("GitHub認証に失敗しました")
    
    return fetcher.fetch_issues(repo, start_date, end_date)


def fetch_issue_comments(
    org: str,
    repo: str,
    issue_numbers: List[int]
) -> pd.DataFrame:
    """
    イシューコメントを取得（簡易版）
    
    Args:
        org: 組織名
        repo: リポジトリ名
        issue_numbers: イシュー番号のリスト
        
    Returns:
        コメント情報のDataFrame
    """
    fetcher = GitHubIssueFetcher(org=org)
    if not fetcher.initialize():
        raise RuntimeError("GitHub認証に失敗しました")
    
    return fetcher.fetch_comments(repo, issue_numbers)


def fetch_issue_events(
    org: str,
    repo: str,
    issue_numbers: List[int]
) -> pd.DataFrame:
    """
    イシューイベントを取得（簡易版）
    
    Args:
        org: 組織名
        repo: リポジトリ名
        issue_numbers: イシュー番号のリスト
        
    Returns:
        イベント情報のDataFrame
    """
    fetcher = GitHubIssueFetcher(org=org)
    if not fetcher.initialize():
        raise RuntimeError("GitHub認証に失敗しました")
    
    return fetcher.fetch_events(repo, issue_numbers)
