"""
コンテキスト構築モジュール

LLMでの詳細補完に必要なコンテキスト情報（generation_context.json）を構築する。
pochi-test-orchestratorパターンに従った構造化されたコンテキストを生成する。
"""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
import pandas as pd


class ContextBuilder:
    """LLM補完用コンテキスト構築クラス"""
    
    def __init__(self):
        """初期化"""
        self.context_template = None
        self.placeholder_pattern = re.compile(r'\{\{PLACEHOLDER_([A-Z0-9_]+)\}\}')
    
    def build_generation_context(
        self,
        config: Dict[str, Any],
        issues_df: pd.DataFrame,
        comments_df: pd.DataFrame,
        events_df: pd.DataFrame,
        baseline_skeleton_path: str,
        adr_skeleton_path: str,
        output_dir: str
    ) -> str:
        """
        LLM補完用のgeneration_context.jsonを生成
        
        Args:
            config: 設定情報（YAML読み込み結果）
            issues_df: イシュー情報のDataFrame
            comments_df: コメント情報のDataFrame
            events_df: イベント情報のDataFrame
            baseline_skeleton_path: ベースライン仕様書骨格版のパス
            adr_skeleton_path: ADR骨格版のパス
            output_dir: 出力先ディレクトリ
            
        Returns:
            generation_context.jsonのパス
        """
        print("🔨 LLM補完用コンテキストを構築中...")
        
        # プレースホルダー抽出
        placeholders = self.extract_placeholders(baseline_skeleton_path)
        print(f"   📍 プレースホルダー抽出: {len(placeholders)}個")
        
        # イシュー情報をマッピング
        mapped_placeholders = self.map_issues_to_placeholders(
            placeholders,
            issues_df,
            comments_df,
            config
        )
        print(f"   🔗 イシューマッピング完了")
        
        # コンテキスト構造を構築
        context = self._build_enhanced_context(
            config,
            issues_df,
            comments_df,
            events_df,
            baseline_skeleton_path,
            adr_skeleton_path,
            mapped_placeholders
        )
        
        # トークン数最適化
        context = self.optimize_token_usage(context)
        print(f"   🎯 トークン数最適化完了")
        
        # JSONとして保存
        output_path = Path(output_dir) / "generation_context.json"
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(context, f, ensure_ascii=False, indent=2, default=str)
        
        print(f"   ✅ コンテキストファイル生成: {output_path}")
        
        return str(output_path)
    
    def extract_placeholders(
        self,
        skeleton_md_path: str
    ) -> List[Dict[str, Any]]:
        """
        骨格版マークダウンからプレースホルダーを抽出
        
        Args:
            skeleton_md_path: 骨格版マークダウンファイルのパス
            
        Returns:
            プレースホルダー情報のリスト
        """
        placeholders = []
        
        with open(skeleton_md_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        lines = content.split('\n')
        current_section = "Unknown"
        current_subsection = None
        
        for i, line in enumerate(lines):
            # セクションの追跡
            if line.startswith('## '):
                current_section = line.replace('##', '').strip()
                current_subsection = None
            elif line.startswith('### '):
                current_subsection = line.replace('###', '').strip()
            elif line.startswith('#### '):
                current_subsection = line.replace('####', '').strip()
            
            # プレースホルダーを検出
            matches = self.placeholder_pattern.finditer(line)
            for match in matches:
                placeholder_id = match.group(1)
                full_placeholder = match.group(0)
                
                # コンテキストを取得（前後3行）
                start_idx = max(0, i - 3)
                end_idx = min(len(lines), i + 4)
                context_lines = lines[start_idx:end_idx]
                
                # 関連イシュー番号を抽出
                related_issues = self._extract_issue_numbers_from_context(context_lines)
                
                # 優先度を推定
                priority = self._estimate_priority(placeholder_id, current_section)
                
                # プレースホルダー種別を判定
                placeholder_type = self._determine_placeholder_type(placeholder_id)
                
                placeholders.append({
                    "id": placeholder_id,
                    "full_text": full_placeholder,
                    "section": current_section,
                    "subsection": current_subsection,
                    "line_number": i + 1,
                    "context": {
                        "previous": '\n'.join(lines[start_idx:i]),
                        "next": '\n'.join(lines[i+1:end_idx])
                    },
                    "related_issues": related_issues,
                    "priority": priority,
                    "type": placeholder_type
                })
        
        return placeholders
    
    def map_issues_to_placeholders(
        self,
        placeholders: List[Dict],
        issues_df: pd.DataFrame,
        comments_df: pd.DataFrame,
        config: Dict
    ) -> List[Dict[str, Any]]:
        """
        プレースホルダーに関連するイシュー情報をマッピング
        
        Args:
            placeholders: プレースホルダー情報のリスト
            issues_df: イシュー情報のDataFrame
            comments_df: コメント情報のDataFrame
            config: 設定情報
            
        Returns:
            イシュー情報がマッピングされたプレースホルダーリスト
        """
        mapped_placeholders = []
        adr_candidates = config.get('adr_candidates', {})
        
        for placeholder in placeholders:
            # ADR番号を抽出
            adr_match = re.search(r'ADR(\d+)', placeholder['id'])
            
            mapped_issues = []
            if adr_match:
                adr_number = f"ADR{adr_match.group(1)}"
                # 設定ファイルからADRに対応するイシューを取得
                if adr_number in adr_candidates:
                    adr_info = adr_candidates[adr_number]
                    issue_numbers = adr_info.get('issue_numbers', [])
                    
                    for issue_num in issue_numbers:
                        issue_data = self._get_issue_data(
                            issue_num,
                            issues_df,
                            comments_df
                        )
                        if issue_data:
                            mapped_issues.append(issue_data)
            else:
                # 一般的なプレースホルダーの場合、関連イシューから情報を取得
                for issue_num in placeholder.get('related_issues', []):
                    issue_data = self._get_issue_data(
                        issue_num,
                        issues_df,
                        comments_df
                    )
                    if issue_data:
                        mapped_issues.append(issue_data)
            
            # トークン数を推定
            total_tokens = sum(
                self._estimate_tokens(issue.get('body', '') + 
                                     '\n'.join([c.get('body', '') for c in issue.get('comments', [])]))
                for issue in mapped_issues
            )
            
            mapped_placeholders.append({
                **placeholder,
                "mapped_issues": mapped_issues,
                "total_tokens": total_tokens
            })
        
        return mapped_placeholders
    
    def _build_enhanced_context(
        self,
        config: Dict[str, Any],
        issues_df: pd.DataFrame,
        comments_df: pd.DataFrame,
        events_df: pd.DataFrame,
        baseline_skeleton_path: str,
        adr_skeleton_path: str,
        mapped_placeholders: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """強化されたコンテキスト構造を構築"""
        
        now = datetime.now()
        
        # イシューデータをJSON形式に変換
        issues_json = self._dataframe_to_json(issues_df) if not issues_df.empty else []
        
        context = {
            "metadata": {
                "generated_at": now.isoformat(),
                "generator": "pochi-baseline-detailed",
                "version": "2.0.0",
                "phase": "skeleton_to_detailed"
            },
            "project": {
                "name": config.get('project', {}).get('name', 'Unknown'),
                "repo": config.get('project', {}).get('repo', 'Unknown'),
                "total_issues": len(issues_df) if not issues_df.empty else 0
            },
            "input_files": {
                "baseline_skeleton": baseline_skeleton_path,
                "adr_skeleton": adr_skeleton_path
            },
            "placeholders": mapped_placeholders,
            "adr_candidates": config.get('adr_candidates', {}),
            "token_budget": {
                "total_available": 150000,
                "used_by_context": sum(p.get('total_tokens', 0) for p in mapped_placeholders),
                "available_for_generation": 150000 - sum(p.get('total_tokens', 0) for p in mapped_placeholders)
            },
            "instructions": {
                "task": "骨格版ドキュメントのプレースホルダーを詳細な内容で補完してください",
                "requirements": [
                    "イシュー情報を元に具体的な内容を記述",
                    "抽象的な表現を避け、具体的な説明を記載",
                    "{{PLACEHOLDER_XXX}}を完全に置換",
                    "イシュー番号（#XXX）を適切に参照",
                    "マークダウン形式で記述",
                    "技術的詳細を含める"
                ]
            }
        }
        
        return context
    
    def _dataframe_to_json(self, df: pd.DataFrame) -> List[Dict]:
        """DataFrameをJSONシリアライズ可能な形式に変換"""
        if df.empty:
            return []
        
        # datetimeカラムを文字列に変換
        df_copy = df.copy()
        for col in df_copy.columns:
            if pd.api.types.is_datetime64_any_dtype(df_copy[col]):
                df_copy[col] = df_copy[col].astype(str)
        
        return df_copy.to_dict('records')
    
    def prepare_issues_json(
        self,
        issues_df: pd.DataFrame,
        comments_df: pd.DataFrame,
        output_path: str
    ) -> str:
        """
        イシュー情報をJSON形式で出力
        
        Args:
            issues_df: イシュー情報のDataFrame
            comments_df: コメント情報のDataFrame
            output_path: 出力先JSONファイルパス
            
        Returns:
            出力したJSONファイルのパス
        """
        print(f"📦 イシューデータをJSON形式で出力中: {output_path}")
        
        # イシューとコメントを結合
        issues_with_comments = []
        
        for _, issue in issues_df.iterrows():
            issue_dict = issue.to_dict()
            
            # 該当イシューのコメントを取得
            issue_comments = comments_df[
                comments_df['issue_number'] == issue['number']
            ] if not comments_df.empty else pd.DataFrame()
            
            issue_dict['comments_list'] = []
            if not issue_comments.empty:
                for _, comment in issue_comments.iterrows():
                    issue_dict['comments_list'].append({
                        'author': comment['author'],
                        'created_at': str(comment['created_at']),
                        'body': comment['body']
                    })
            
            # datetime型を文字列に変換
            for key, value in issue_dict.items():
                # リストや辞書はスキップ
                if isinstance(value, (list, dict)):
                    continue
                # スカラー値のみチェック
                try:
                    if pd.isna(value):
                        issue_dict[key] = None
                    elif isinstance(value, (pd.Timestamp, datetime)):
                        issue_dict[key] = str(value)
                except (ValueError, TypeError):
                    # pd.isna()が配列を返す場合など
                    if isinstance(value, (pd.Timestamp, datetime)):
                        issue_dict[key] = str(value)
            
            issues_with_comments.append(issue_dict)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(issues_with_comments, f, ensure_ascii=False, indent=2)
        
        print(f"   ✅ イシューデータ出力完了: {len(issues_with_comments)}件")
        
        return output_path
    
    def build_prompt_file(
        self,
        context: Dict[str, Any],
        prompt_template_path: str,
        output_path: str
    ) -> str:
        """
        プロンプトファイルを生成
        
        Args:
            context: コンテキスト情報
            prompt_template_path: プロンプトテンプレートのパス
            output_path: 出力先プロンプトファイルパス
            
        Returns:
            出力したプロンプトファイルのパス
        """
        print(f"📝 プロンプトファイルを生成中: {output_path}")
        
        # TODO: Phase 2で詳細実装
        # - テンプレートの読み込み
        # - コンテキスト情報の埋め込み
        # - プロンプトの最適化
        
        # 仮実装: 基本的なプロンプトを生成
        prompt = f"""# ベースライン仕様書詳細補完タスク

## タスク概要
GitHubイシュー履歴から生成された骨格版ドキュメントの詳細補完を行ってください。

## 対象ドキュメント
- ベースライン仕様書骨格版
- ADR骨格版

## イシュー情報
- 総イシュー数: {context.get('project', {}).get('total_issues', 0)}件
- データファイル: generation_context.json

## 補完要件
1. すべての[TODO:...]プレースホルダーを具体的な内容で置換
2. イシュー情報を元に詳細な説明を記述
3. 抽象的な表現を避け、具体的な実装内容を記載
4. 適切なイシュー番号を参照

## 出力形式
Markdown形式で出力してください。
"""
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(prompt)
        
        print(f"   ✅ プロンプトファイル生成完了")
        
        return output_path
    
    def optimize_token_usage(
        self,
        context: Dict[str, Any],
        max_tokens: int = 150000
    ) -> Dict[str, Any]:
        """
        コンテキストサイズを最適化
        
        Args:
            context: コンテキスト情報
            max_tokens: 最大トークン数
            
        Returns:
            最適化されたコンテキスト
        """
        # 現在のトークン数を確認
        current_tokens = context.get('token_budget', {}).get('used_by_context', 0)
        
        if current_tokens <= max_tokens * 0.8:
            # 余裕がある場合はそのまま返す
            return context
        
        # プレースホルダーの優先度順に削減
        placeholders = context.get('placeholders', [])
        
        for placeholder in placeholders:
            if placeholder.get('priority') == 'low':
                # Low優先度のイシューコメントを削減
                mapped_issues = placeholder.get('mapped_issues', [])
                for issue in mapped_issues:
                    if len(issue.get('comments', [])) > 3:
                        issue['comments'] = issue['comments'][:3]
        
        # トークン数を再計算
        total_tokens = sum(
            p.get('total_tokens', 0) for p in placeholders
        )
        
        context['token_budget']['used_by_context'] = total_tokens
        context['token_budget']['available_for_generation'] = max_tokens - total_tokens
        
        return context
    
    def validate_context(
        self,
        context_path: str
    ) -> tuple[bool, List[str]]:
        """
        生成したコンテキストの妥当性を検証
        
        Args:
            context_path: generation_context.jsonのパス
            
        Returns:
            (検証結果, エラーメッセージリスト)
        """
        errors = []
        
        try:
            with open(context_path, 'r', encoding='utf-8') as f:
                context = json.load(f)
            
            # 必須フィールドの確認
            required_fields = ['metadata', 'project', 'placeholders', 'token_budget']
            for field in required_fields:
                if field not in context:
                    errors.append(f"必須フィールド '{field}' が見つかりません")
            
            # プレースホルダーの確認
            if 'placeholders' in context:
                if not isinstance(context['placeholders'], list):
                    errors.append("placeholdersはリストである必要があります")
                elif len(context['placeholders']) == 0:
                    errors.append("プレースホルダーが1つも見つかりません")
            
            # トークン数の確認
            if 'token_budget' in context:
                budget = context['token_budget']
                if budget.get('used_by_context', 0) > budget.get('total_available', 0):
                    errors.append("トークン使用量が予算を超過しています")
            
        except json.JSONDecodeError as e:
            errors.append(f"JSONパースエラー: {e}")
        except Exception as e:
            errors.append(f"検証エラー: {e}")
        
        is_valid = len(errors) == 0
        
        if is_valid:
            print("   ✅ コンテキストの検証完了")
        else:
            print("   ⚠️  コンテキストに問題があります")
            for error in errors:
                print(f"      - {error}")
        
        return is_valid, errors
    
    # ヘルパーメソッド
    
    def _extract_issue_numbers_from_context(
        self,
        context_lines: List[str]
    ) -> List[int]:
        """コンテキスト内からイシュー番号を抽出"""
        issue_numbers = []
        issue_pattern = re.compile(r'#(\d+)')
        
        for line in context_lines:
            matches = issue_pattern.findall(line)
            issue_numbers.extend([int(num) for num in matches])
        
        return list(set(issue_numbers))  # 重複除去
    
    def _estimate_priority(
        self,
        placeholder_id: str,
        section: str
    ) -> str:
        """プレースホルダーの優先度を推定"""
        # ADR番号から優先度を判定
        adr_match = re.search(r'ADR(\d+)', placeholder_id)
        if adr_match:
            adr_num = int(adr_match.group(1))
            if adr_num <= 2:
                return 'high'
            elif adr_num <= 5:
                return 'medium'
            else:
                return 'low'
        
        # セクション名から推定
        high_sections = ['プロジェクト概要', 'システムアーキテクチャ', 'アーキテクチャ決定']
        if any(hs in section for hs in high_sections):
            return 'high'
        
        return 'medium'
    
    def _determine_placeholder_type(
        self,
        placeholder_id: str
    ) -> str:
        """プレースホルダーの種別を判定"""
        if 'DECISION' in placeholder_id:
            return 'decision'
        elif 'RATIONALE' in placeholder_id:
            return 'rationale'
        elif 'TECHNICAL' in placeholder_id:
            return 'technical_details'
        elif 'IMPLEMENTATION' in placeholder_id:
            return 'implementation'
        elif 'PURPOSE' in placeholder_id or 'SCOPE' in placeholder_id:
            return 'overview'
        else:
            return 'general'
    
    def _get_issue_data(
        self,
        issue_number: int,
        issues_df: pd.DataFrame,
        comments_df: pd.DataFrame
    ) -> Optional[Dict[str, Any]]:
        """イシュー番号からイシューデータを取得"""
        if issues_df.empty:
            return None
        
        issue_rows = issues_df[issues_df['number'] == issue_number]
        if issue_rows.empty:
            return None
        
        issue = issue_rows.iloc[0].to_dict()
        
        # コメントを取得
        comments = []
        if not comments_df.empty:
            issue_comments = comments_df[comments_df['issue_number'] == issue_number]
            for _, comment in issue_comments.iterrows():
                comments.append({
                    'author': comment.get('author', 'Unknown'),
                    'created_at': str(comment.get('created_at', '')),
                    'body': comment.get('body', '')
                })
        
        # datetime型を文字列に変換
        for key, value in issue.items():
            if pd.isna(value):
                issue[key] = None
            elif isinstance(value, (pd.Timestamp, datetime)):
                issue[key] = str(value)
        
        issue['comments'] = comments
        
        return issue
    
    def _estimate_tokens(
        self,
        text: str
    ) -> int:
        """テキストのトークン数を推定（簡易版）"""
        # 簡易的な推定: 1トークン = 約4文字
        return len(text) // 4


# 便利関数

def build_llm_context(
    config: Dict[str, Any],
    issues_df: pd.DataFrame,
    comments_df: pd.DataFrame,
    events_df: pd.DataFrame,
    baseline_skeleton_path: str,
    adr_skeleton_path: str,
    output_dir: str
) -> str:
    """
    LLM補完用コンテキストを構築（簡易版）
    
    Args:
        config: 設定情報
        issues_df: イシュー情報のDataFrame
        comments_df: コメント情報のDataFrame
        events_df: イベント情報のDataFrame
        baseline_skeleton_path: ベースライン仕様書骨格版のパス
        adr_skeleton_path: ADR骨格版のパス
        output_dir: 出力先ディレクトリ
        
    Returns:
        generation_context.jsonのパス
    """
    builder = ContextBuilder()
    return builder.build_generation_context(
        config,
        issues_df,
        comments_df,
        events_df,
        baseline_skeleton_path,
        adr_skeleton_path,
        output_dir
    )
