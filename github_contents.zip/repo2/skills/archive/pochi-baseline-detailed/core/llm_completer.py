"""
LLM補完モジュール

骨格版ドキュメントのプレースホルダーをLLMを使用して詳細な内容で補完する。
Anthropic Claude APIを使用してバッチ処理で効率的に補完を行う。
"""

import json
import re
import time
from pathlib import Path
from typing import Dict, List, Optional, Any
import anthropic


class LLMCompleter:
    """LLMによるプレースホルダー補完クラス"""
    
    def __init__(
        self,
        api_key: str,
        model: str = "claude-3-5-sonnet-20241022",
        max_retries: int = 3
    ):
        """
        初期化
        
        Args:
            api_key: Anthropic APIキー
            model: 使用するモデル
            max_retries: 最大リトライ回数
        """
        self.api_key = api_key
        self.model = model
        self.max_retries = max_retries
        self.client = anthropic.Anthropic(api_key=api_key)
        self.placeholder_pattern = re.compile(r'\{\{PLACEHOLDER_([A-Z0-9_]+)\}\}')
    
    def complete_placeholders(
        self,
        skeleton_md_path: str,
        generation_context_path: str,
        output_path: str,
        batch_size: int = 1
    ) -> str:
        """
        骨格版のプレースホルダーを補完して詳細版を生成
        
        Args:
            skeleton_md_path: 骨格版マークダウンのパス
            generation_context_path: generation_context.jsonのパス
            output_path: 出力先パス
            batch_size: バッチサイズ（High優先度は1推奨）
            
        Returns:
            詳細版マークダウンのパス
        """
        print("🤖 LLMによるプレースホルダー補完を開始...")
        
        # 骨格版とコンテキストを読み込み
        with open(skeleton_md_path, 'r', encoding='utf-8') as f:
            skeleton_content = f.read()
        
        with open(generation_context_path, 'r', encoding='utf-8') as f:
            context = json.load(f)
        
        placeholders = context.get('placeholders', [])
        print(f"   📝 補完対象: {len(placeholders)}個のプレースホルダー")
        
        # 優先度順にソート
        sorted_placeholders = sorted(
            placeholders,
            key=lambda p: self._get_priority_score(p.get('priority', 'medium'))
        )
        
        # プレースホルダーを段階的に補完
        detailed_content = skeleton_content
        completed_count = 0
        
        for i, placeholder in enumerate(sorted_placeholders):
            print(f"   [{i+1}/{len(sorted_placeholders)}] {placeholder['id']} を補完中...")
            
            try:
                # 補完テキストを生成
                completion = self.complete_single_placeholder(
                    placeholder,
                    context
                )
                
                # プレースホルダーを置換
                pattern = re.escape(placeholder['full_text'])
                detailed_content = re.sub(
                    pattern,
                    completion,
                    detailed_content,
                    count=1
                )
                
                completed_count += 1
                
                # レート制限対策（少し待機）
                if i < len(sorted_placeholders) - 1:
                    time.sleep(0.5)
                
            except Exception as e:
                print(f"      ⚠️  エラー: {e}")
                # エラーの場合はプレースホルダーをそのまま残す
                continue
        
        # 詳細版を保存
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(detailed_content)
        
        print(f"   ✅ 補完完了: {completed_count}/{len(sorted_placeholders)}個")
        print(f"   📄 詳細版生成: {output_path}")
        
        return output_path
    
    def complete_single_placeholder(
        self,
        placeholder_info: Dict[str, Any],
        context: Dict[str, Any]
    ) -> str:
        """
        単一のプレースホルダーを補完
        
        Args:
            placeholder_info: プレースホルダー情報
            context: 全体のコンテキスト情報
            
        Returns:
            補完されたテキスト
        """
        # プロンプトを構築
        prompt = self.build_completion_prompt(placeholder_info, context)
        
        # LLM APIを呼び出し
        completion = self._call_llm_api(prompt)
        
        return completion
    
    def build_completion_prompt(
        self,
        placeholder_info: Dict[str, Any],
        context: Dict[str, Any]
    ) -> str:
        """
        プレースホルダー補完用のプロンプトを生成
        
        Args:
            placeholder_info: プレースホルダー情報
            context: 全体のコンテキスト情報
            
        Returns:
            プロンプト文字列
        """
        placeholder_id = placeholder_info.get('id', 'UNKNOWN')
        placeholder_type = placeholder_info.get('type', 'general')
        section = placeholder_info.get('section', 'Unknown')
        subsection = placeholder_info.get('subsection', '')
        
        # 関連イシュー情報を取得
        mapped_issues = placeholder_info.get('mapped_issues', [])
        
        # イシュー情報を整形
        issues_text = self._format_issues_for_prompt(mapped_issues)
        
        # コンテキスト情報を取得
        prev_context = placeholder_info.get('context', {}).get('previous', '')
        next_context = placeholder_info.get('context', {}).get('next', '')
        
        # プレースホルダー種別に応じた指示
        type_instructions = self._get_type_specific_instructions(placeholder_type)
        
        # プロンプトを構築
        prompt = f"""# プレースホルダー補完タスク

## 対象プレースホルダー
{{{{{placeholder_id}}}}}

## セクション情報
- メインセクション: {section}
- サブセクション: {subsection or 'なし'}
- プレースホルダー種別: {placeholder_type}

## 前後のコンテキスト

### 前のコンテキスト
```
{prev_context[-500:] if len(prev_context) > 500 else prev_context}
```

### 後のコンテキスト
```
{next_context[:500] if len(next_context) > 500 else next_context}
```

## 関連イシュー情報
{issues_text}

## 補完要件
{type_instructions}

### 共通要件
- マークダウン形式で記述してください
- イシュー情報を元に具体的な内容を記述してください
- 抽象的な表現を避け、技術的詳細を含めてください
- 該当イシューがあれば #XXX 形式で参照してください
- プレースホルダー自体（{{{{PLACEHOLDER_XXX}}}}）は出力に含めないでください
- 見出し記号（#, ##, ###）は含めないでください（前後のコンテキストに含まれているため）

## 出力形式
プレースホルダーを置換する具体的な内容のみを出力してください。
"""
        
        return prompt
    
    def _call_llm_api(
        self,
        prompt: str,
        max_tokens: int = 2000,
        retry_count: int = 0
    ) -> str:
        """
        Anthropic APIを呼び出し
        
        Args:
            prompt: プロンプト
            max_tokens: 最大トークン数
            retry_count: 現在のリトライ回数
            
        Returns:
            LLMの応答テキスト
        """
        try:
            message = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            return message.content[0].text
            
        except anthropic.RateLimitError as e:
            if retry_count < self.max_retries:
                wait_time = 2 ** retry_count
                print(f"      ⏳ レート制限: {wait_time}秒待機...")
                time.sleep(wait_time)
                return self._call_llm_api(prompt, max_tokens, retry_count + 1)
            else:
                raise Exception(f"レート制限エラー（最大リトライ回数超過）: {e}")
        
        except anthropic.APITimeoutError as e:
            if retry_count < self.max_retries:
                print(f"      ⏳ タイムアウト: リトライ中...")
                time.sleep(2)
                return self._call_llm_api(prompt, max_tokens, retry_count + 1)
            else:
                raise Exception(f"APIタイムアウト（最大リトライ回数超過）: {e}")
        
        except Exception as e:
            raise Exception(f"API呼び出しエラー: {e}")
    
    def _get_priority_score(self, priority: str) -> int:
        """優先度をスコアに変換（降順ソート用）"""
        priority_map = {
            'high': 0,
            'medium': 1,
            'low': 2
        }
        return priority_map.get(priority, 1)
    
    def _format_issues_for_prompt(
        self,
        issues: List[Dict[str, Any]]
    ) -> str:
        """イシュー情報をプロンプト用に整形"""
        if not issues:
            return "関連イシューなし"
        
        formatted = []
        for issue in issues[:3]:  # 最大3件まで
            title = issue.get('title', 'No Title')
            number = issue.get('number', 0)
            body = issue.get('body', '')
            
            # 本文を適度な長さに制限
            if len(body) > 1000:
                body = body[:1000] + "..."
            
            formatted.append(f"""### Issue #{number}: {title}

**本文**:
{body}
""")
            
            # コメント要約（最初の2つのみ）
            comments = issue.get('comments', [])
            if comments:
                formatted.append("**主要なコメント**:")
                for comment in comments[:2]:
                    comment_body = comment.get('body', '')
                    if len(comment_body) > 300:
                        comment_body = comment_body[:300] + "..."
                    formatted.append(f"- {comment.get('author', 'Unknown')}: {comment_body}")
        
        return '\n'.join(formatted)
    
    def _get_type_specific_instructions(
        self,
        placeholder_type: str
    ) -> str:
        """プレースホルダー種別に応じた補完指示を取得"""
        instructions = {
            'decision': """
- アーキテクチャ上の決定内容を明確に記述
- 選択した技術やアプローチを具体的に示す
- 200-400文字程度で簡潔に
""",
            'rationale': """
- 決定の理由を論理的に説明
- メリット・デメリットを含める
- 代替案との比較があれば記載
- 300-500文字程度
""",
            'technical_details': """
- 技術的な詳細を具体的に記述
- 実装方法、設定値、構成などを含める
- コード例やコマンド例があれば記載
- 400-600文字程度
""",
            'implementation': """
- 実装ガイドラインを具体的に記述
- ベストプラクティス、注意点を含める
- ステップバイステップで説明
- 300-500文字程度
""",
            'overview': """
- プロジェクトの概要を分かりやすく説明
- 目的、スコープ、主要機能を含める
- 200-400文字程度
""",
            'general': """
- イシュー情報を元に適切な内容を記述
- セクションの文脈に合わせた記述
- 200-400文字程度
"""
        }
        
        return instructions.get(placeholder_type, instructions['general'])


# 便利関数

def complete_baseline_detailed(
    skeleton_md_path: str,
    generation_context_path: str,
    output_path: str,
    api_key: str,
    model: str = "claude-3-5-sonnet-20241022"
) -> str:
    """
    ベースライン仕様書詳細版を生成（簡易版）
    
    Args:
        skeleton_md_path: 骨格版マークダウンのパス
        generation_context_path: generation_context.jsonのパス
        output_path: 出力先パス
        api_key: Anthropic APIキー
        model: 使用するモデル
        
    Returns:
        詳細版マークダウンのパス
    """
    completer = LLMCompleter(api_key=api_key, model=model)
    return completer.complete_placeholders(
        skeleton_md_path,
        generation_context_path,
        output_path
    )
