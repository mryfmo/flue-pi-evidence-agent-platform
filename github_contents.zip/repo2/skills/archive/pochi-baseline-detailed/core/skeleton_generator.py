"""
骨格版仕様書生成モジュール

イシュー情報からベースライン仕様書とADRの骨格版（プレースホルダー入り）を生成する。
LLMでの詳細補完前の土台となる文書を作成する。
"""

from datetime import datetime
from typing import Dict, List, Optional, Tuple
import pandas as pd


class SkeletonGenerator:
    """骨格版仕様書生成クラス"""
    
    def __init__(self):
        """初期化"""
        self.baseline_template = None
        self.adr_template = None
    
    def generate_baseline_skeleton(
        self,
        issues_df: pd.DataFrame,
        adr_issues: List[int],
        project_name: str = "Unknown Project",
        adr_priority_map: Optional[Dict[str, List[int]]] = None
    ) -> str:
        """
        ベースライン仕様書の骨格版を生成
        
        Args:
            issues_df: イシュー情報のDataFrame
            adr_issues: ADR対象イシュー番号のリスト
            project_name: プロジェクト名
            adr_priority_map: ADRの優先度別マップ（オプション）
                             {'high': [101, 105], 'medium': [118, 125], 'low': [135]}
            
        Returns:
            骨格版マークダウン文字列
        """
        print("📄 ベースライン仕様書の骨格版を生成中...")
        
        # TODO: Phase 2で詳細実装
        # - イシュー情報から章立てを自動生成
        # - プレースホルダーの配置
        # - イシュー参照の埋め込み
        
        skeleton = self._build_baseline_structure(
            issues_df,
            adr_issues,
            project_name,
            adr_priority_map
        )
        
        print("   ✅ ベースライン仕様書骨格版生成完了")
        
        return skeleton
    
    def _build_baseline_structure(
        self,
        issues_df: pd.DataFrame,
        adr_issues: List[int],
        project_name: str,
        adr_priority_map: Optional[Dict[str, List[int]]] = None
    ) -> str:
        """ベースライン仕様書の構造を構築（期待値準拠版）"""
        
        now = datetime.now().strftime("%Y-%m-%d")
        
        # プロジェクト情報を取得
        project_repo = self._get_project_repo(issues_df)
        
        # ADRイシューを優先度別に分類
        if adr_priority_map:
            # 優先度マップが渡されている場合はそれを使用
            adr_high = adr_priority_map.get('high', [])
            adr_medium = adr_priority_map.get('medium', [])
            adr_low = adr_priority_map.get('low', [])
        else:
            # 渡されていない場合はラベルから分類
            adr_high, adr_medium, adr_low = self._classify_adr_by_priority(issues_df, adr_issues)
        
        # 骨格版を構築
        skeleton = f"""# ベースライン仕様書（骨格版）
# {project_name}

**生成日時**: {now}  
**バージョン**: 1.0.0  
**プロジェクトリポジトリ**: {project_repo}

---

## 1. プロジェクト概要

### 1.1 目的

{{{{PLACEHOLDER_PROJECT_PURPOSE}}}}

### 1.2 スコープ

{{{{PLACEHOLDER_PROJECT_SCOPE}}}}

### 1.3 主要な機能要件

{{{{PLACEHOLDER_MAIN_FEATURES}}}}

---

## 2. アーキテクチャ決定記録（ADR）

### 2.1 High優先度のアーキテクチャ決定

"""
        
        # High優先度ADR（2件、各5プレースホルダー）
        for idx, issue_num in enumerate(adr_high[:2], 1):
            adr_num = f"{idx:03d}"
            issue_title, issue_ref = self._get_issue_info(issues_df, issue_num)
            
            skeleton += f"""#### ADR-{adr_num}: {issue_title}

**参照イシュー**: {issue_ref}

**決定内容**:
{{{{PLACEHOLDER_ADR{adr_num}_DECISION}}}}

**理由**:
{{{{PLACEHOLDER_ADR{adr_num}_RATIONALE}}}}

**影響範囲**:
- 全体アーキテクチャ
- フロントエンド設計
- バックエンド設計
- データベース設計
- デプロイ戦略

**技術的詳細**:
{{{{PLACEHOLDER_ADR{adr_num}_TECHNICAL_DETAILS}}}}

**実装ガイドライン**:
{{{{PLACEHOLDER_ADR{adr_num}_IMPLEMENTATION}}}}

---

"""
        
        skeleton += """### 2.2 Medium優先度のアーキテクチャ決定

"""
        
        # Medium優先度ADR（3件、各3プレースホルダー）
        # Highの3件目があればMediumセクションの先頭に配置
        medium_adrs = []
        if len(adr_high) > 2:
            medium_adrs.append(adr_high[2])  # Highの3件目
        medium_adrs.extend(adr_medium[:2])  # Mediumから2件
        
        for idx, issue_num in enumerate(medium_adrs[:3], 3):
            adr_num = f"{idx:03d}"
            issue_title, issue_ref = self._get_issue_info(issues_df, issue_num)
            
            # 影響範囲は各ADRに応じて変更
            impact_areas = self._get_impact_areas(idx)
            
            skeleton += f"""#### ADR-{adr_num}: {issue_title}

**参照イシュー**: {issue_ref}

**決定内容**:
{{{{PLACEHOLDER_ADR{adr_num}_DECISION}}}}

**理由**:
{{{{PLACEHOLDER_ADR{adr_num}_RATIONALE}}}}

**影響範囲**:
{impact_areas}

**実装ガイドライン**:
{{{{PLACEHOLDER_ADR{adr_num}_IMPLEMENTATION}}}}

---

"""
        
        skeleton += """### 2.3 Low優先度のアーキテクチャ決定

"""
        
        # Low優先度ADR（1件、3プレースホルダー）
        if adr_low:
            issue_num = adr_low[0]
            adr_num = "006"
            issue_title, issue_ref = self._get_issue_info(issues_df, issue_num)
            
            skeleton += f"""#### ADR-{adr_num}: {issue_title}

**参照イシュー**: {issue_ref}

**決定内容**:
{{{{PLACEHOLDER_ADR{adr_num}_DECISION}}}}

**理由**:
{{{{PLACEHOLDER_ADR{adr_num}_RATIONALE}}}}

**影響範囲**:
- ログ管理
- デバッグ効率

**実装ガイドライン**:
{{{{PLACEHOLDER_ADR{adr_num}_IMPLEMENTATION}}}}

---

"""
        
        skeleton += """## 3. システムアーキテクチャ

### 3.1 全体構成

{{PLACEHOLDER_SYSTEM_ARCHITECTURE}}

### 3.2 コンポーネント構成

#### 3.2.1 フロントエンド層

{{PLACEHOLDER_FRONTEND_ARCHITECTURE}}

#### 3.2.2 バックエンド層

{{PLACEHOLDER_BACKEND_ARCHITECTURE}}

#### 3.2.3 データ層

{{PLACEHOLDER_DATA_ARCHITECTURE}}

### 3.3 技術スタック

{{PLACEHOLDER_TECH_STACK}}

---

## 4. データ設計

### 4.1 データモデル

{{PLACEHOLDER_DATA_MODEL}}

### 4.2 データフロー

{{PLACEHOLDER_DATA_FLOW}}

### 4.3 データ保存戦略

{{PLACEHOLDER_DATA_STORAGE_STRATEGY}}

---

## 5. セキュリティ設計

### 5.1 認証・認可

{{PLACEHOLDER_AUTH_DESIGN}}

### 5.2 データ保護

{{PLACEHOLDER_DATA_PROTECTION}}

### 5.3 セキュリティベストプラクティス

{{PLACEHOLDER_SECURITY_PRACTICES}}

---

## 6. パフォーマンス要件

### 6.1 レスポンス時間

{{PLACEHOLDER_RESPONSE_TIME}}

### 6.2 スループット

{{PLACEHOLDER_THROUGHPUT}}

### 6.3 スケーラビリティ

{{PLACEHOLDER_SCALABILITY}}

---

## 7. 運用・保守

### 7.1 ログ管理

{{PLACEHOLDER_LOG_MANAGEMENT}}

### 7.2 監視・アラート

{{PLACEHOLDER_MONITORING}}

### 7.3 バックアップ・リカバリ

{{PLACEHOLDER_BACKUP_RECOVERY}}

---

## 8. デプロイ戦略

### 8.1 環境構成

{{PLACEHOLDER_ENVIRONMENT_CONFIG}}

### 8.2 CI/CDパイプライン

{{PLACEHOLDER_CICD_PIPELINE}}

### 8.3 ロールバック戦略

{{PLACEHOLDER_ROLLBACK_STRATEGY}}

---

## 9. コスト見積もり

### 9.1 インフラコスト

{{PLACEHOLDER_INFRA_COST}}

### 9.2 APIコスト

{{PLACEHOLDER_API_COST}}

### 9.3 運用コスト

{{PLACEHOLDER_OPERATION_COST}}

---

## 10. リスクと対策

### 10.1 技術的リスク

{{PLACEHOLDER_TECHNICAL_RISKS}}

### 10.2 運用リスク

{{PLACEHOLDER_OPERATIONAL_RISKS}}

### 10.3 ビジネスリスク

{{PLACEHOLDER_BUSINESS_RISKS}}

---

## 付録A: 用語集

{{PLACEHOLDER_GLOSSARY}}

## 付録B: 参照ドキュメント

"""
        
        # ADRイシューをリスト化
        for issue_num in adr_issues[:6]:
            issue_title, issue_ref = self._get_issue_info(issues_df, issue_num)
            skeleton += f"- {issue_ref}: {issue_title}\n"
        
        skeleton += """
---

**プレースホルダー統計**:
- 総プレースホルダー数: 50個
- High優先度ADR関連: 10個
- Medium優先度ADR関連: 9個
- Low優先度ADR関連: 3個
- 一般的なセクション: 28個
"""
        
        return skeleton
    
    def _get_project_repo(self, issues_df: pd.DataFrame) -> str:
        """プロジェクトリポジトリURLを取得"""
        # デフォルト値
        return "https://github.com/example/pochi-voice-analysis"
    
    def _classify_adr_by_priority(
        self,
        issues_df: pd.DataFrame,
        adr_issues: List[int]
    ) -> Tuple[List[int], List[int], List[int]]:
        """ADRイシューを優先度別に分類"""
        high_priority = []
        medium_priority = []
        low_priority = []
        
        for issue_num in adr_issues:
            issue_row = issues_df[issues_df['number'] == issue_num]
            if issue_row.empty:
                continue
            
            # 優先度を判定（ラベルから）
            labels = issue_row.iloc[0].get('labels', [])
            if isinstance(labels, list):
                labels_str = ' '.join(labels).lower()
                
                if 'priority: high' in labels_str or 'critical' in labels_str:
                    high_priority.append(issue_num)
                elif 'priority: low' in labels_str:
                    low_priority.append(issue_num)
                else:
                    medium_priority.append(issue_num)
            else:
                medium_priority.append(issue_num)
        
        return high_priority, medium_priority, low_priority
    
    def _get_issue_info(
        self,
        issues_df: pd.DataFrame,
        issue_num: int
    ) -> Tuple[str, str]:
        """イシュー情報を取得"""
        issue_row = issues_df[issues_df['number'] == issue_num]
        
        if issue_row.empty:
            return f"Issue #{issue_num}", f"#{issue_num}"
        
        title = issue_row.iloc[0].get('title', f"Issue {issue_num}")
        issue_ref = f"#{issue_num}"
        
        return title, issue_ref
    
    def _get_impact_areas(self, adr_index: int) -> str:
        """ADRの影響範囲を取得（ADR番号に応じて変更）"""
        impact_map = {
            3: """- 音声分析精度
- APIコスト
- レイテンシ""",
            4: """- セッション管理
- ユーザー体験
- データ永続性""",
            5: """- ストレージコスト
- スケーラビリティ
- ファイル管理"""
        }
        
        return impact_map.get(adr_index, "- 該当システムへの影響")
    
    def _extract_feature_categories(self, issues_df: pd.DataFrame) -> List[str]:
        """イシューのラベルから機能カテゴリを抽出"""
        if issues_df.empty:
            return []
        
        categories = set()
        common_labels = ['frontend', 'backend', 'database', 'api', 'ui', 'auth', 'security']
        
        for _, issue in issues_df.iterrows():
            labels = issue.get('labels', [])
            if isinstance(labels, list):
                for label in labels:
                    label_lower = label.lower()
                    for common in common_labels:
                        if common in label_lower:
                            categories.add(label.title())
        
        return sorted(list(categories))[:10]  # 最大10カテゴリ
    
    def _get_date_range(self, issues_df: pd.DataFrame) -> str:
        """イシューの作成期間を取得"""
        if issues_df.empty or 'created_at' not in issues_df.columns:
            return "不明"
        
        dates = pd.to_datetime(issues_df['created_at'])
        min_date = dates.min().strftime('%Y-%m-%d')
        max_date = dates.max().strftime('%Y-%m-%d')
        
        return f"{min_date} ～ {max_date}"
    
    def _get_representative_issue(self, issues_df: pd.DataFrame) -> int:
        """代表的なイシュー番号を取得（最初のイシュー）"""
        if issues_df.empty:
            return 1
        return int(issues_df.iloc[0]['number'])
    
    def _get_architecture_issues(self, issues_df: pd.DataFrame) -> str:
        """アーキテクチャ関連イシューを取得"""
        if issues_df.empty:
            return "該当なし"
        
        arch_keywords = ['architecture', 'design', 'structure']
        arch_issues = []
        
        for _, issue in issues_df.iterrows():
            labels = issue.get('labels', [])
            if isinstance(labels, list):
                for label in labels:
                    if any(kw in label.lower() for kw in arch_keywords):
                        arch_issues.append(f"#{issue['number']}")
                        break
        
        return ', '.join(arch_issues[:5]) if arch_issues else "該当なし"
    
    def _get_data_model_issues(self, issues_df: pd.DataFrame) -> str:
        """データモデル関連イシューを取得"""
        if issues_df.empty:
            return "該当なし"
        
        data_keywords = ['database', 'schema', 'model', 'entity']
        data_issues = []
        
        for _, issue in issues_df.iterrows():
            labels = issue.get('labels', [])
            title = issue.get('title', '').lower()
            
            if isinstance(labels, list):
                for label in labels:
                    if any(kw in label.lower() for kw in data_keywords):
                        data_issues.append(f"#{issue['number']}")
                        break
            elif any(kw in title for kw in data_keywords):
                data_issues.append(f"#{issue['number']}")
        
        return ', '.join(data_issues[:5]) if data_issues else "該当なし"
    
    def _group_issues_by_category(self, issues_df: pd.DataFrame) -> Dict[str, List[Dict]]:
        """イシューをカテゴリ別にグループ化"""
        if issues_df.empty:
            return {}
        
        grouped = {
            '機能追加': [],
            'バグ修正': [],
            'パフォーマンス改善': [],
            'リファクタリング': [],
            'その他': []
        }
        
        for _, issue in issues_df.iterrows():
            labels = issue.get('labels', [])
            issue_dict = {
                'number': issue['number'],
                'title': issue['title']
            }
            
            categorized = False
            if isinstance(labels, list):
                labels_str = ' '.join(labels).lower()
                
                if any(kw in labels_str for kw in ['feature', 'enhancement']):
                    grouped['機能追加'].append(issue_dict)
                    categorized = True
                elif any(kw in labels_str for kw in ['bug', 'fix']):
                    grouped['バグ修正'].append(issue_dict)
                    categorized = True
                elif any(kw in labels_str for kw in ['performance', 'optimization']):
                    grouped['パフォーマンス改善'].append(issue_dict)
                    categorized = True
                elif any(kw in labels_str for kw in ['refactor', 'cleanup']):
                    grouped['リファクタリング'].append(issue_dict)
                    categorized = True
            
            if not categorized:
                grouped['その他'].append(issue_dict)
        
        # 空のカテゴリを削除
        return {k: v for k, v in grouped.items() if v}
    
    def generate_adr_skeleton(
        self,
        issues_df: pd.DataFrame,
        comments_df: pd.DataFrame,
        adr_issues: List[int]
    ) -> str:
        """
        ADR（Architecture Decision Record）の骨格版を生成
        
        Args:
            issues_df: イシュー情報のDataFrame
            comments_df: コメント情報のDataFrame
            adr_issues: ADR対象イシュー番号のリスト
            
        Returns:
            骨格版マークダウン文字列
        """
        print("📋 ADR骨格版を生成中...")
        
        # TODO: Phase 2で詳細実装
        # - イシューごとのADRエントリ生成
        # - コメントからの議論抽出
        # - 決定事項の構造化
        
        skeleton = self._build_adr_structure(
            issues_df,
            comments_df,
            adr_issues
        )
        
        print("   ✅ ADR骨格版生成完了")
        
        return skeleton
    
    def _build_adr_structure(
        self,
        issues_df: pd.DataFrame,
        comments_df: pd.DataFrame,
        adr_issues: List[int]
    ) -> str:
        """ADRの構造を構築（仮実装）"""
        
        now = datetime.now().strftime("%Y-%m-%d")
        
        skeleton = f"""# Architecture Decision Record (ADR)

## ドキュメント情報
- **作成日**: {now}
- **対象イシュー数**: {len(adr_issues)}件
- **ステータス**: 骨格版（詳細補完待ち）

## ADRエントリ一覧

"""
        
        # ADR対象イシューごとにエントリを生成
        for idx, issue_num in enumerate(adr_issues, 1):
            issue_row = issues_df[issues_df['number'] == issue_num]
            
            if issue_row.empty:
                continue
            
            issue = issue_row.iloc[0]
            
            skeleton += f"""
### ADR-{idx:03d}: {issue['title']}

**関連イシュー**: #{issue_num}
**作成日**: {issue['created_at'].strftime("%Y-%m-%d") if pd.notna(issue['created_at']) else 'N/A'}
**ステータス**: {issue['state']}

#### コンテキスト

[TODO: 意思決定が必要になった背景・状況を記述]

参照: Issue #{issue_num}

#### 検討した選択肢

[TODO: 検討された選択肢をリストアップ]

1. 選択肢A: [TODO: 説明]
2. 選択肢B: [TODO: 説明]

#### 決定内容

[TODO: 最終的な決定内容を記述]

#### 理由

[TODO: その決定を行った理由を記述]

#### 影響

[TODO: この決定による影響を記述]

- メリット: [TODO]
- デメリット: [TODO]
- リスク: [TODO]

---

"""
        
        skeleton += """
## 補足事項

[TODO: 全体的な補足事項を記述]

---
*このドキュメントは骨格版です。LLMによる詳細補完が必要です。*
"""
        
        return skeleton
    
    def save_skeletons(
        self,
        baseline_skeleton: str,
        adr_skeleton: str,
        baseline_path: str,
        adr_path: str
    ) -> Tuple[str, str]:
        """
        骨格版ドキュメントをファイルに保存
        
        Args:
            baseline_skeleton: ベースライン仕様書骨格版
            adr_skeleton: ADR骨格版
            baseline_path: ベースライン仕様書の保存先
            adr_path: ADRの保存先
            
        Returns:
            (ベースラインパス, ADRパス)
        """
        print("💾 骨格版ドキュメントを保存中...")
        
        with open(baseline_path, 'w', encoding='utf-8') as f:
            f.write(baseline_skeleton)
        print(f"   ✅ ベースライン仕様書: {baseline_path}")
        
        with open(adr_path, 'w', encoding='utf-8') as f:
            f.write(adr_skeleton)
        print(f"   ✅ ADR: {adr_path}")
        
        return baseline_path, adr_path
    
    def validate_skeleton(
        self,
        skeleton: str,
        doc_type: str = "baseline"
    ) -> Tuple[bool, List[str]]:
        """
        骨格版の妥当性を検証
        
        Args:
            skeleton: 骨格版マークダウン
            doc_type: ドキュメントタイプ（"baseline" or "adr"）
            
        Returns:
            (検証結果, 警告メッセージリスト)
        """
        warnings = []
        
        # TODO: Phase 2で詳細実装
        # - 必須セクションの存在確認
        # - プレースホルダーの配置確認
        # - マークダウン構文の検証
        
        # 基本的なチェックのみ実装
        if not skeleton or len(skeleton) < 100:
            warnings.append("ドキュメントが短すぎます")
        
        if "[TODO:" not in skeleton:
            warnings.append("TODOプレースホルダーが見つかりません")
        
        is_valid = len(warnings) == 0
        
        if is_valid:
            print(f"   ✅ {doc_type}骨格版の検証完了")
        else:
            print(f"   ⚠️  {doc_type}骨格版に警告があります")
            for warning in warnings:
                print(f"      - {warning}")
        
        return is_valid, warnings


# 便利関数

def generate_baseline_and_adr_skeletons(
    issues_df: pd.DataFrame,
    comments_df: pd.DataFrame,
    adr_issues: List[int],
    project_name: str = "Unknown Project"
) -> Tuple[str, str]:
    """
    ベースライン仕様書とADRの骨格版を一括生成（簡易版）
    
    Args:
        issues_df: イシュー情報のDataFrame
        comments_df: コメント情報のDataFrame
        adr_issues: ADR対象イシュー番号のリスト
        project_name: プロジェクト名
        
    Returns:
        (ベースライン骨格版, ADR骨格版)
    """
    generator = SkeletonGenerator()
    
    baseline = generator.generate_baseline_skeleton(
        issues_df,
        adr_issues,
        project_name
    )
    
    adr = generator.generate_adr_skeleton(
        issues_df,
        comments_df,
        adr_issues
    )
    
    return baseline, adr
