"""
Pochi Feature Builder - Core Module

このモジュールは、既存のcore/services/feature_spec.pyを利用します。
"""

# このファイルは主にパッケージマーカーとして機能します
# 実際のロジックはcore/services/feature_spec.pyに実装されています
