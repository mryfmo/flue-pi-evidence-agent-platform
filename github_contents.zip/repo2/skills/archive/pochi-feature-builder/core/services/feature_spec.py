"""
FeatureSpecService - GitHubイシューから機能仕様書生成プロンプトを作成するサービス

GitHub CLI（gh）を使用してイシュー情報を取得し、
prompts/issue_to_feature.md テンプレートに基づいたプロンプトファイルを生成する。
"""
import json
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


def validate_repo_name(repo: str) -> str:
    """リポジトリ名をバリデーション"""
    if '/' in repo:
        parts = repo.split('/')
        if len(parts) != 2:
            raise ValueError(f"無効なリポジトリ名: {repo}")
        org, name = parts
    else:
        org, name = None, repo

    pattern = r'^[a-zA-Z0-9._-]+$'
    if org and not re.match(pattern, org):
        raise ValueError(f"無効な組織名: {org}")
    if not re.match(pattern, name):
        raise ValueError(f"無効なリポジトリ名: {name}")
    return repo


def validate_issue_number(issue_number) -> int:
    """イシュー番号を整数バリデーション"""
    try:
        num = int(issue_number)
        if num <= 0:
            raise ValueError
        return num
    except (ValueError, TypeError):
        raise ValueError(f"無効なイシュー番号: {issue_number}")


class FeatureSpecService:
    """GitHubイシューから機能仕様書生成プロンプトを生成するサービス"""

    def __init__(self, config: dict):
        """初期化

        Args:
            config: 設定辞書
                - default_repo: デフォルトのリポジトリ名
                - default_org: デフォルトの組織名
        """
        self.config = config
        self.skill_dir = Path(__file__).resolve().parent.parent.parent
        self.prompt_template_path = self.skill_dir / "prompts" / "issue_to_feature.md"

    def generate(
        self,
        issue_number: str,
        repo: str,
        org: str,
        related_files: Optional[list] = None,
        output_path: Optional[str] = None,
        include_comments: bool = False,
    ) -> Path:
        """機能仕様書生成用プロンプトファイルを生成する

        Args:
            issue_number: GitHubイシュー番号
            repo: リポジトリ名
            org: 組織名
            related_files: 関連ファイルパスのリスト
            output_path: 出力先パス（Noneの場合は自動決定）
            include_comments: イシューのコメントも取得するか

        Returns:
            生成されたプロンプトファイルのパス

        Raises:
            RuntimeError: GitHub APIアクセス失敗時
        """
        print(f"📡 GitHubからイシュー情報を取得中: {org}/{repo}#{issue_number}")

        # イシュー情報を取得
        issue_data = self._fetch_issue(issue_number, repo, org)
        print(f"✅ イシュー取得完了: #{issue_number} - {issue_data.get('title', 'N/A')}")

        # コメント取得（オプション）
        comments_data = []
        if include_comments:
            print("📡 コメントを取得中...")
            comments_data = self._fetch_comments(issue_number, repo, org)
            print(f"✅ コメント取得完了: {len(comments_data)}件")

        # イシューJSONファイルを保存
        issue_json_path = self._save_issue_json(issue_number, issue_data, comments_data)
        print(f"✅ イシューデータを保存: {issue_json_path}")

        # プロンプトファイルの出力先を決定
        resolved_output_path = self._resolve_output_path(output_path, issue_number, issue_data)

        # プロンプトファイルを生成
        prompt_path = self._generate_prompt(
            issue_json_path=issue_json_path,
            issue_data=issue_data,
            related_files=related_files or [],
            output_path=resolved_output_path,
        )
        print(f"✅ プロンプトファイルを生成: {prompt_path}")

        return prompt_path

    def _fetch_issue(self, issue_number: str, repo: str, org: str) -> dict:
        """GitHub CLIでイシュー情報を取得する

        Args:
            issue_number: イシュー番号
            repo: リポジトリ名
            org: 組織名

        Returns:
            イシュー情報の辞書

        Raises:
            RuntimeError: gh コマンド失敗時
        """
        full_repo = validate_repo_name(f"{org}/{repo}")
        validated_issue_number = validate_issue_number(issue_number)
        fields = "number,title,body,state,labels,assignees,milestone,createdAt,updatedAt,closedAt,url,author"

        try:
            result = subprocess.run(
                ["gh", "issue", "view", str(validated_issue_number), "--repo", full_repo, "--json", fields],
                capture_output=True,
                text=True,
                timeout=30,
            )
        except FileNotFoundError:
            raise RuntimeError(
                "GitHub CLI（gh）が見つかりません。\n"
                "インストール: https://cli.github.com/\n"
                "認証: gh auth login"
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"GitHub API タイムアウト（30秒）: #{validated_issue_number}")

        if result.returncode != 0:
            # stderrの内容をサニタイズ（トークンやURLパラメータをマスク）
            error_msg = result.stderr.strip()
            sanitized_msg = re.sub(r'(token|bearer|auth)\s*[=:]\s*\S+', r'\1=***', error_msg, flags=re.IGNORECASE)
            raise RuntimeError(
                f"GitHub APIエラー（リポジトリ: {full_repo}, イシュー: #{validated_issue_number}）\n"
                f"詳細: {sanitized_msg}"
            )

        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"GitHub APIレスポンスのパース失敗: {e}")

    def _fetch_comments(self, issue_number: str, repo: str, org: str) -> list:
        """GitHub CLIでイシューコメントを取得する

        Args:
            issue_number: イシュー番号
            repo: リポジトリ名
            org: 組織名

        Returns:
            コメントのリスト（取得失敗時は空リスト）
        """
        full_repo = validate_repo_name(f"{org}/{repo}")
        validated_issue_number = validate_issue_number(issue_number)

        try:
            result = subprocess.run(
                ["gh", "issue", "view", str(validated_issue_number), "--repo", full_repo,
                 "--json", "comments"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                return data.get("comments", [])
        except Exception as e:
            print(f"⚠️ コメント取得失敗（スキップ）: {e}", file=sys.stderr)

        return []

    def _save_issue_json(self, issue_number: str, issue_data: dict, comments_data: list) -> Path:
        """イシュー情報をJSONファイルとして保存する

        Args:
            issue_number: イシュー番号
            issue_data: イシュー情報
            comments_data: コメントリスト

        Returns:
            保存したJSONファイルのパス
        """
        output_dir = self.skill_dir / "output" / "issues"
        output_dir.mkdir(parents=True, exist_ok=True)

        # コメントをイシューデータに統合
        if comments_data:
            issue_data["comments"] = comments_data

        # issue_numberをバリデーションしてパストラバーサルを防止
        safe_issue_number = validate_issue_number(issue_number)
        issue_json_path = output_dir / f"issue_{safe_issue_number}.json"
        with open(issue_json_path, "w", encoding="utf-8") as f:
            json.dump(issue_data, f, ensure_ascii=False, indent=2)

        return issue_json_path

    def _resolve_output_path(
        self, output_path: Optional[str], issue_number: str, issue_data: dict
    ) -> str:
        """プロンプトファイルの出力先パスを決定する

        Args:
            output_path: 指定された出力先パス（Noneの場合は自動生成）
            issue_number: イシュー番号
            issue_data: イシュー情報

        Returns:
            出力先パス文字列
        """
        if output_path:
            return output_path

        # タイトルからスラッグを生成
        title = issue_data.get("title", "feature")
        slug = self._title_to_slug(title)

        # issue_numberをバリデーションしてパストラバーサルを防止
        safe_issue_number = validate_issue_number(issue_number)
        return f"pochi-artifacts/features/issue_{safe_issue_number}_{slug}.md"

    def _title_to_slug(self, title: str) -> str:
        """タイトルをファイル名スラッグに変換する

        Args:
            title: イシュータイトル

        Returns:
            スラッグ文字列（最大30文字）
        """
        import re
        # 日本語・英数字・ハイフン・アンダースコア以外を除去
        slug = re.sub(r"[^\w\u3040-\u309f\u30a0-\u30ff\u4e00-\u9fff-]", "_", title)
        # 連続するアンダースコアを単一に
        slug = re.sub(r"_+", "_", slug).strip("_")
        return slug[:30].lower() if slug else "feature"

    def _generate_prompt(
        self,
        issue_json_path: Path,
        issue_data: dict,
        related_files: list,
        output_path: str,
    ) -> Path:
        """プロンプトファイルを生成する

        Args:
            issue_json_path: イシューJSONファイルのパス
            issue_data: イシュー情報
            related_files: 関連ファイルのリスト
            output_path: 仕様書の出力先パス

        Returns:
            生成されたプロンプトファイルのパス
        """
        # 関連ファイルのMarkdownリストを生成
        if related_files:
            related_files_text = "\n".join(f"- {f}" for f in related_files)
        else:
            related_files_text = "（関連ファイルなし）"

        # プロンプト本文を生成
        issue_title = issue_data.get("title", "N/A")
        issue_number = issue_data.get("number", "N/A")
        labels = [label.get("name", "") for label in issue_data.get("labels", [])]
        labels_text = ", ".join(labels) if labels else "なし"

        prompt_content = f"""# 機能仕様書生成プロンプト

生成日時: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
イシュー: #{issue_number} - {issue_title}
ラベル: {labels_text}

---

以下のGitHubイシュー情報から、実装仕様書を生成してください。

【イシュー情報】
ファイル: `{issue_json_path}` を読み込んで内容を確認してください。

【タスク】
このイシューの要件を分析し、実装可能な仕様書を作成してください。

【既存コード分析】
以下のファイルを分析して、実装方針を決定してください：
{related_files_text}

【品質目標】
- **全10項目で9.0点以上を取得できる内容を生成してください**
- 各項目の品質基準（チェックポイント）を全て満たしてください
- 抽象的な表現（「適切な」「必要に応じて」等）を避け、具体的な数値・事例を記載してください
- 実装者が仕様書だけで開発できる詳細度を確保してください

【仕様書の構成】

以下の10項目について、それぞれ詳細に記述してください。

## 1. 目的と背景（目的の明確性）

**品質基準（9.0点以上を取るために必須）**:
- [ ] 機能を追加・変更する理由が明確に説明されている
- [ ] ビジネス上の価値や解決する課題が記載されている
- [ ] ユーザーにとってのメリットが明確である
- [ ] 背景情報が十分に提供されている

### 1.1 背景
### 1.2 目的
### 1.3 対象ユーザー

## 2. 要件定義（要件の網羅性）

**品質基準（9.0点以上を取るために必須）**:
- [ ] すべての機能要件が明確に定義されている
- [ ] 非機能要件（性能、セキュリティ等）が考慮されている
- [ ] エッジケースや例外処理が記載されている
- [ ] 制約事項や前提条件が明記されている

### 2.1 機能要件
### 2.2 非機能要件
### 2.3 制約事項
### 2.4 エッジケース・例外処理

## 3. 技術仕様（技術的詳細度）

**品質基準（9.0点以上を取るために必須）**:
- [ ] 使用する技術スタックが明確である
- [ ] データ構造やスキーマが定義されている
- [ ] API仕様やインターフェースが明確である
- [ ] 技術的な制約や依存関係が記載されている

### 3.1 アーキテクチャ
### 3.2 UI仕様
### 3.3 データ仕様
### 3.4 API・インターフェース仕様
### 3.5 処理フロー

## 4. 実装計画（実装可能性）

**品質基準（9.0点以上を取るために必須）**:
- [ ] 実装手順が具体的に記載されている
- [ ] 必要なコンポーネントや関数が特定されている
- [ ] 既存コードとの統合方法が明確である
- [ ] 実装の優先順位や段階が示されている

### 4.1 変更が必要なファイル
### 4.2 具体的なコード変更例
### 4.3 実装手順
### 4.4 依存関係

## 5. テスト仕様（テスト容易性）

**品質基準（9.0点以上を取るために必須）**:
- [ ] テストケースが具体的に定義されている
- [ ] 正常系・異常系のテストが網羅されている
- [ ] テストデータや期待結果が明確である
- [ ] テスト環境や前提条件が記載されている

### 5.1 機能テスト
### 5.2 非機能テスト
### 5.3 テストデータ
### 5.4 自動テスト

## 6. 保守性設計（保守性への配慮）

**品質基準（9.0点以上を取るために必須）**:
- [ ] コードの可読性を考慮した設計である
- [ ] 将来の拡張性が考慮されている
- [ ] 適切なモジュール化や抽象化が行われている
- [ ] ドキュメント化の方針が明確である

### 6.1 コード設計
### 6.2 拡張性
### 6.3 可読性

## 7. セキュリティ設計（セキュリティ考慮）

**品質基準（9.0点以上を取るために必須）**:
- [ ] 認証・認可の要件が明確である
- [ ] データ保護の方針が定義されている
- [ ] 入力検証やサニタイゼーションが考慮されている
- [ ] セキュリティリスクと対策が記載されている

### 7.1 認証・認可
### 7.2 データ保護
### 7.3 セキュリティリスク
### 7.4 監査・ログ

## 8. パフォーマンス設計（パフォーマンス考慮）

**品質基準（9.0点以上を取るために必須）**:
- [ ] 性能要件（応答時間、スループット等）が定義されている
- [ ] パフォーマンスのボトルネックが特定されている
- [ ] 最適化の方針や手法が記載されている
- [ ] スケーラビリティが考慮されている

### 8.1 性能要件
### 8.2 最適化方針
### 8.3 スケーラビリティ
### 8.4 パフォーマンス測定

## 9. ドキュメント（ドキュメント品質）

**品質基準（9.0点以上を取るために必須）**:
- [ ] 論理的な構成で情報が整理されている
- [ ] 図表やコード例が適切に使用されている
- [ ] 専門用語が適切に説明されている
- [ ] 誤字脱字や表記の不統一がない

### 9.1 構成
### 9.2 表現
### 9.3 品質

## 10. 既存仕様との整合性（一貫性）

**品質基準（9.0点以上を取るために必須）**:
- [ ] ベースライン仕様との整合性が取れている
- [ ] 既存の設計パターンに従っている
- [ ] 命名規則やコーディング規約が統一されている
- [ ] アーキテクチャの方針と矛盾がない

### 10.1 ベースライン仕様との整合性
### 10.2 コーディング規約
### 10.3 既存機能との統合
### 10.4 参照ドキュメント

【出力先】
`{output_path}`

【注意事項】
- Pochiガイドラインに準拠すること
- 既存機能への影響を最小限にすること
- 実装者が仕様書だけで開発できる詳細度にすること
- コード例は具体的で実行可能なものにすること
- Mermaid図を活用して視覚的に分かりやすくすること
"""

        # プロンプトファイルの保存先
        prompt_output_dir = self.skill_dir / "output" / "prompts"
        prompt_output_dir.mkdir(parents=True, exist_ok=True)

        prompt_filename = f"feature_prompt_{issue_number}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        prompt_file_path = prompt_output_dir / prompt_filename

        with open(prompt_file_path, "w", encoding="utf-8") as f:
            f.write(prompt_content)

        return prompt_file_path
