---
skill_id: pochi-feature-builder
id: pochi-feature-builder
title: 機能仕様書作成ツール（イシュー情報インプット版）
name: 機能仕様書作成ツール（イシュー情報インプット版）
version: 1.0.0
description: GitHubイシューから機能仕様書を作成する際に使用。ユーザーが「イシューから機能仕様書を作成」「機能仕様書を生成」「feature specを作成」などと依頼した時に起動する。イシュー専用で、議事録からの生成はpochi-baseline-builderを使用。
entrypoint:
  type: prompt
  path: prompts/issue_to_feature.md
triggers:
  - イシューから機能仕様書を作成して
  - GitHubイシューから機能仕様書を生成
  - イシューから仕様書作成
  - issue to feature spec
  - issue to feature
  - イシューからPochiフィーチャー作成
  - 機能仕様書を作成して
  - 機能仕様書を生成
  - feature specを生成
  - feature specを作成
  - 詳細仕様作成
  - Skillツールを使用して pochi-feature-builder を起動してください
  - pochi-feature-builder を起動
  - pochi-feature-builder 起動
  - generate feature spec from issue
  - create feature spec from GitHub issue
  - build feature from issue
  - GitHub issue to spec
---

> [!CAUTION]
> **このスキルは廃止・使用禁止です。**
> 起動した場合でも**何も実行せずに即座に終了してください。**
> 後継スキル: `pochi-spec-initializer` — 「仕様駆動開発を開始」で起動

**このスキルは使用禁止です。絶対に実行しないでください。**

後継スキル **`pochi-spec-initializer` — 「仕様駆動開発を開始」で起動** を使用してください。


# Skill: 機能仕様書作成ツール（イシュー情報インプット版）

**このSkillは、GitHubイシューから機能仕様書を自動生成します。**

## Trigger Phrases

**⚠️ このSkillは「GitHubイシュー」専用です。ヒアリング議事録からの生成は pochi-baseline-builder を使用してください。**

### Pochi固有トリガー（推奨・イシュー明示）
- イシューから機能仕様書を作成して
- GitHubイシューから機能仕様書を生成
- イシューから仕様書作成
- issue to feature spec
- issue to feature
- イシューからPochiフィーチャー作成

### 汎用トリガー（イシュー前提）
- 機能仕様書を作成して
- 機能仕様書を生成
- feature specを生成
- feature specを作成
- 詳細仕様作成

### Skill直接起動
- Skillツールを使用して pochi-feature-builder を起動してください
- pochi-feature-builder を起動
- pochi-feature-builder 起動

### 英語トリガー
- generate feature spec from issue
- create feature spec from GitHub issue
- issue to feature spec
- build feature from issue
- GitHub issue to spec

## When

### 起動条件
上記TriggerPhrasesのいずれかが発話されたら、直ちにこのSkillを起動してください。

### 前提条件
- GitHubイシュー情報が利用可能（JSON形式）
- プロンプトテンプレート `prompts/issue_to_feature.md` が存在する
- ベースライン仕様書が存在する（推奨）

### 起動しない条件（誤起動防止）
以下のような曖昧な表現では起動しないでください：
- ❌ 「仕様を作りたい」
- ❌ 「ドキュメントを作成」
- ❌ 「イシューを確認して」
- ❌ 「議事録から機能仕様書を作成」（→ pochi-baseline-builder を使用）

定義されたトリガーワードとの明確な一致が必要です。

**インプット種別の明確化:**
- ✅ イシュー → 機能仕様書: **このSkill (pochi-feature-builder)**
- ✅ 議事録 → ベースライン仕様書: **pochi-baseline-builder**
- ❌ 議事録 → 機能仕様書: 未対応（通常はベースライン仕様書を作成）

## Do

**このスキルは2つの実行方法をサポートします：**

### 方法A: スクリプト実行（推奨）

skill_entry.pyを使用して自動的にプロンプトを生成します。

#### Linux/Mac環境
```bash
POCHI_SKILL_ACTIVE=1 python /home/user/pochi-dp-developer-docs/skills/pochi-feature-builder/skill_entry.py
```

#### Windows環境

**Windows (cmd)**:
```cmd
set POCHI_SKILL_ACTIVE=1 && python /home/user/pochi-dp-developer-docs/skills/pochi-feature-builder/skill_entry.py
```

**Windows (PowerShell)**:
```powershell
$env:POCHI_SKILL_ACTIVE="1"; python /home/user/pochi-dp-developer-docs/skills/pochi-feature-builder/skill_entry.py
```

**注意**: デフォルトでは、イシュー番号や関連ファイルについてユーザーに質問します（推奨）。質問をスキップして環境変数から取得する場合は、`POCHI_SKIP_QUESTIONS=1`を追加してください。

#### 自動化モード（質問スキップ）

**Linux/Mac環境**:
```bash
POCHI_SKILL_ACTIVE=1 POCHI_SKIP_QUESTIONS=1 GITHUB_ISSUE_NUMBER=123 python /home/user/pochi-dp-developer-docs/skills/pochi-feature-builder/skill_entry.py
```

**Windows (cmd)**:
```cmd
set POCHI_SKILL_ACTIVE=1 && set POCHI_SKIP_QUESTIONS=1 && set GITHUB_ISSUE_NUMBER=123 && python /home/user/pochi-dp-developer-docs/skills/pochi-feature-builder/skill_entry.py
```

**Windows (PowerShell)**:
```powershell
$env:POCHI_SKILL_ACTIVE="1"; $env:POCHI_SKIP_QUESTIONS="1"; $env:GITHUB_ISSUE_NUMBER="123"; python /home/user/pochi-dp-developer-docs/skills/pochi-feature-builder/skill_entry.py
```

### 方法B: 手動実行（4ステップ）

**シンプルな4ステップで実行します：**

### ステップ1: イシュー情報の確認
ユーザーにイシュー番号または情報を確認してください：
```
「GitHubイシュー番号を教えてください（例: #280）」
```

または、イシュー情報のJSONファイルパスを確認：
```
「イシュー情報のJSONファイルパスを教えてください」
```

### ステップ2: 関連ファイルの特定（オプション）
影響を受けるファイルを確認：
```
「この機能に関連するファイルがあれば教えてください（オプション）」
```

### ステップ3: プロンプトテンプレートの読み込み
以下のプロンプトテンプレートを読み込んでください：
```
prompts/issue_to_feature.md
```

### ステップ4: 機能仕様書の生成
プロンプトテンプレートに従って、機能仕様書を生成してください：

1. **イシュー情報を読み込む**
2. **ベースライン仕様書を参照**（存在する場合）
3. **関連ファイルを確認**（指定された場合）
4. **機能仕様書を生成**（10項目、品質目標9.0/10以上）
5. **出力ファイルに保存**
   - デフォルト: `skills/pochi-feature-builder/output/feature_issue_{issue_number}.md`

## Instructions

### 詳細な実行手順

#### 1. 入力確認
```markdown
【確認】
- イシュー番号: #{issue_number}
- ベースライン仕様書: {baseline_path} (存在する場合)
- 関連ファイル: {related_files} (オプション)
- 出力先: {output_path} (デフォルト: skills/pochi-feature-builder/output/feature_issue_{issue_number}.md)

この設定で生成を開始しますか？
```

#### 2. プロンプトテンプレート適用
`prompts/issue_to_feature.md`のfront-matterを参照：
- schema: feature_spec_v1
- quality_threshold: 9.0
- 必須項目: 10項目

#### 3. 機能仕様書生成
以下の10項目を生成：

1. **機能概要**
   - 機能名
   - 目的
   - 背景

2. **ユーザーストーリー**
   - ユーザー視点の要求
   - 受け入れ基準

3. **機能詳細**
   - 具体的な動作
   - 入力・出力

4. **UI仕様**
   - 画面設計
   - 操作フロー
   - Pochiガイドライン準拠

5. **API仕様**
   - エンドポイント
   - リクエスト/レスポンス

6. **データモデル**
   - 必要なデータ構造
   - セッションステート

7. **ビジネスロジック**
   - 処理フロー
   - バリデーション

8. **エッジケース・例外処理**
   - 境界値
   - エラーハンドリング

9. **セキュリティ考慮事項**
   - 認証・認可
   - データ保護

10. **性能要件**
    - レスポンスタイム
    - スケーラビリティ

11. **テスト戦略**
    - テストケース概要
    - カバレッジ目標

12. **依存関係**
    - 前提条件
    - 他機能との関係

#### 4. 品質確認
生成後、以下を自己チェック：
- [ ] 10項目すべてが含まれているか
- [ ] ユーザーストーリーが明確か
- [ ] 受け入れ基準が具体的か
- [ ] エッジケースが網羅されているか
- [ ] 品質スコア9.0/10以上を達成しているか

## Don't

### 実行禁止事項
- ❌ **イシュー情報を読まずに生成しない**
  - 必ずイシュー内容に基づいて生成してください

- ❌ **不完全な仕様書を生成しない**
  - 10項目すべてを含めてください

- ❌ **曖昧な受け入れ基準を記載しない**
  - テスト可能な具体的な基準を記載してください

- ❌ **ベースライン仕様書との整合性を無視しない**
  - 技術スタック、UI原則、データ構造を踏襲してください

## Inputs

### 必須入力
- **GitHubイシュー情報**
  - 形式: JSON
  - パス例: `skills/pochi-feature-builder/input/issue_280.json`
  - 内容: イシュータイトル、本文、ラベル等

### オプション入力
- **ベースライン仕様書**
  - パス例: `skills/pochi-baseline-builder/output/baseline_spec.md`
  - 目的: 技術スタックとUI原則の踏襲

- **関連ファイル**
  - パス例: `app/lib/merchant_map.py`
  - 目的: 既存実装の理解

### 参照ドキュメント（自動参照）
- `prompts/issue_to_feature.md`: プロンプトテンプレート
- `prompts/_schema/feature_spec_v1.yaml`: スキーマ定義

## Outputs

### 主要成果物
- **feature_issue_{issue_number}.md**
  - 機能仕様書（10項目）
  - 形式: Markdown
  - 保存先: `skills/pochi-feature-builder/output/feature_issue_{issue_number}.md`
  - 品質目標: 9.0/10以上

### 生成内容の構成
```markdown
# 機能仕様書: [機能名]

## 1. 機能概要
...

## 2. ユーザーストーリー
...

## 3. 機能詳細
...

## 4. UI仕様
...

## 5. API仕様
...

## 6. データモデル
...

## 7. ビジネスロジック
...

## 8. エッジケース・例外処理
...

## 9. セキュリティ考慮事項
...

## 10. 性能要件
...

## 11. テスト戦略
...

## 12. 依存関係
...
```

## Troubleshooting

### Skillが起動しない場合

#### 1. トリガーワードを確認
- ✅ 「機能仕様書を作成して」（推奨）
- ✅ 「feature specを生成」
- ❌ 「仕様を作りたい」（トリガーに未登録）

#### 2. SKILL.mdの配置を確認
```bash
# 以下のファイルが存在するか確認
ls -la skills/pochi-feature-builder/SKILL.md
```

### 生成エラーが発生する場合

#### エラー: 「イシュー情報が見つかりません」
**原因**: イシューJSONファイルが存在しない  
**解決**: イシューJSONを準備するか、GitHubから取得してください

#### エラー: 「プロンプトテンプレートが見つかりません」
**原因**: prompts/issue_to_feature.mdが存在しない
**解決**: プロンプトテンプレートの配置を確認してください

### 品質が低い場合

#### 受け入れ基準が曖昧
**原因**: イシュー情報が不足  
**解決**: イシューに具体的な要求を追加してください

#### エッジケースが不足
**原因**: プロンプトテンプレートの指示が不十分  
**解決**: エッジケースセクションを充実させてください

## 使用例

### 例1: 基本的な使用（推奨トリガー）
```
ユーザー: 「イシューから機能仕様書を作成して、#280で」

エージェント: 
1. イシュー#280の情報を取得
2. ベースライン仕様書を参照
3. プロンプトテンプレートに従って10項目生成
4. skills/pochi-feature-builder/output/feature_issue_280.mdに保存
5. 「機能仕様書を生成しました（品質スコア: 9.2/10）」
```

### 例2: イシューJSONファイル指定
```
ユーザー: 「skills/pochi-feature-builder/input/issue_280.json から機能仕様書を生成して」

エージェント:
1. 指定されたJSONファイルを読み込み
2. ベースライン仕様書を参照
3. 10項目の機能仕様書を生成
4. デフォルト出力先に保存
5. 完了報告
```

### 例3: 関連ファイル指定
```
ユーザー: 「issue to feature spec、#280、関連ファイルはapp/lib/merchant_map.py」

エージェント:
1. イシュー#280の情報取得
2. merchant_map.pyの内容確認
3. 既存実装を踏まえた仕様書生成
4. 完了報告
```

## バージョン・ライセンス

- **バージョン**: 1.0.0
- **作成者**: Pochi Development Team
- **ライセンス**: Internal Use Only

## 参照ドキュメント

- [README.md](./README.md): 概要とクイックスタート
- [統一CLI README](../../pochi-cli/README.md): 統一CLIドキュメント
- [prompts/issue_to_feature.md](prompts/issue_to_feature.md): プロンプトテンプレート
- [prompts/_schema/feature_spec_v1.yaml](prompts/_schema/feature_spec_v1.yaml): スキーマ定義

**注意**: このSkillは統一CLI (`pochi feature`) と同じ機能を提供します。新規開発では統一CLIの使用を推奨します。

---

**🚀 このSkillを起動するには、「機能仕様書を作成して」とClaude Codeに指示してください。**
