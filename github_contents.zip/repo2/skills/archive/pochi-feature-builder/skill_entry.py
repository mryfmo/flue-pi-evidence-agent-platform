"""
Pochi Feature Builder - Skill Entry Point

GitHubイシューから機能仕様書生成用のプロンプトを生成する
"""
import os
import sys
import argparse
from pathlib import Path
from datetime import datetime

# core.servicesモジュールをインポート
skill_dir = Path(__file__).parent.resolve()
sys.path.insert(0, str(skill_dir))
try:
    from core.services.feature_spec import FeatureSpecService
except ImportError:
    FeatureSpecService = None


def print_header():
    """ヘッダー表示"""
    print("=" * 70)
    print("Pochi Feature Builder - Skill Entry")
    print("=" * 70)
    print("GitHubイシューから機能仕様書生成プロンプトを作成します")
    print("")


def print_step_header(step_num: int, total_steps: int, title: str):
    """ステップヘッダー表示"""
    print(f"\n{'=' * 70}")
    print(f"[{step_num}/{total_steps}] {title}")
    print(f"{'=' * 70}")


def get_user_input_or_env(prompt: str, env_var: str, default: str = None) -> str:
    """ユーザー入力または環境変数から値を取得
    
    Args:
        prompt: ユーザーへの入力プロンプト
        env_var: 環境変数名
        default: デフォルト値
        
    Returns:
        入力された値またはデフォルト値
    """
    # 環境変数をチェック
    value = os.environ.get(env_var)
    if value:
        print(f"{prompt}: {value} (環境変数から取得)")
        return value
    
    # デバッグモードまたは自動承認モード
    if os.environ.get("POCHI_SKILL_DEBUG") == "1" or os.environ.get("AUTO_APPROVE") == "1":
        if default:
            print(f"{prompt}: {default} (デフォルト値)")
            return default
    
    # ユーザーに入力を求める
    if default:
        user_input = input(f"{prompt} (デフォルト: {default}): ").strip()
        return user_input if user_input else default
    else:
        while True:
            user_input = input(f"{prompt}: ").strip()
            if user_input:
                return user_input
            print("この項目は必須です。値を入力してください。")


def get_related_files() -> list:
    """関連ファイルのリストを取得
    
    Returns:
        関連ファイルのリスト
    """
    print("\n関連ファイルを指定しますか？ (y/n): ", end="")
    
    # デバッグモードまたは自動承認モード
    if os.environ.get("POCHI_SKILL_DEBUG") == "1" or os.environ.get("AUTO_APPROVE") == "1":
        print("n (スキップ)")
        return []
    
    response = input().strip().lower()
    if response != "y":
        return []
    
    print("\n関連ファイルのパスを1行ずつ入力してください（空行で終了）:")
    files = []
    while True:
        file_path = input("> ").strip()
        if not file_path:
            break
        files.append(file_path)
    
    return files


def main():
    """メインエントリポイント
    
    Returns:
        0: 成功
        1: 失敗
    """
    # コマンドライン引数のパース
    parser = argparse.ArgumentParser(description='Pochi Feature Builder Skill')
    parser.add_argument('--issue', type=str, help='イシュー番号')
    parser.add_argument('--repo', type=str, help='リポジトリ名')
    parser.add_argument('--org', type=str, help='組織名')
    parser.add_argument('--include-comments', action='store_true', 
                       help='イシューのコメントも取得')
    parser.add_argument('--related-files', nargs='+', help='関連ファイルのリスト')
    parser.add_argument('--output', type=str, help='出力先パス')
    args = parser.parse_args()
    
    # 環境変数チェック（デバッグモード以外）
    if os.environ.get("POCHI_SKILL_DEBUG") != "1":
        if os.environ.get("POCHI_SKILL_ACTIVE") != "1":
            print("❌ エラー: このスキルはClaude Code Skills経由でのみ実行可能です")
            print("トリガーフレーズ: '機能仕様書を作成して' または 'イシューから機能仕様書を作成'")
            return 1
    
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # ヘッダー表示
    print_header()
    print(f"Run ID: {run_id}")
    print("")
    
    try:
        # Step 1: 入力情報の収集
        print_step_header(1, 3, "入力情報の収集")
        
        # イシュー番号
        issue_number = args.issue or get_user_input_or_env(
            "イシュー番号 (例: 280)",
            "GITHUB_ISSUE_NUMBER"
        )
        
        # リポジトリ情報
        default_repo = "pochi-d-pay-merchant-visualizer-repository"
        default_org = "nttdocomo-com"
        
        repo = args.repo or get_user_input_or_env(
            "リポジトリ名",
            "GITHUB_REPO",
            default_repo
        )
        
        org = args.org or get_user_input_or_env(
            "組織名",
            "GITHUB_ORG",
            default_org
        )
        
        # コメント取得オプション
        include_comments = args.include_comments
        if not include_comments and os.environ.get("POCHI_SKILL_DEBUG") != "1":
            print("\nイシューのコメントも取得しますか？ (y/n): ", end="")
            response = input().strip().lower()
            include_comments = (response == "y")
        
        # 関連ファイル
        related_files = args.related_files
        if not related_files:
            related_files = get_related_files()
        
        # 出力先パス
        output_path = args.output
        
        print("\n✅ 入力情報を収集しました:")
        print(f"   イシュー番号: #{issue_number}")
        print(f"   リポジトリ: {org}/{repo}")
        print(f"   コメント取得: {'有効' if include_comments else '無効'}")
        if related_files:
            print(f"   関連ファイル: {len(related_files)}件")
            for f in related_files[:3]:
                print(f"     - {f}")
            if len(related_files) > 3:
                print(f"     ... 他{len(related_files) - 3}件")
        print("")
        
        # Step 2: サービス初期化と実行
        print_step_header(2, 3, "機能仕様書プロンプト生成")
        
        if FeatureSpecService is None:
            print("❌ エラー: core/services/feature_spec.py が見つかりません")
            print("   このskillのcore/services/ディレクトリが欠落しています")
            return 1
        print("FeatureSpecServiceを初期化中...")
        service = FeatureSpecService({
            'default_repo': repo,
            'default_org': org
        })
        
        print("✅ サービス初期化完了")
        print("")
        
        print("プロンプト生成を開始します...")
        print("")
        
        # プロンプト生成実行
        prompt_path = service.generate(
            issue_number=issue_number,
            repo=repo,
            org=org,
            related_files=related_files if related_files else None,
            output_path=output_path,
            include_comments=include_comments
        )
        
        # Step 3: 完了報告
        print_step_header(3, 3, "完了")
        
        print("=" * 70)
        print("✅ 機能仕様書生成プロンプトの準備が完了しました")
        print("=" * 70)
        print("")
        print(f"📝 生成されたプロンプトファイル:")
        print(f"   {prompt_path}")
        print("")
        print("📋 次のステップ:")
        print("  1. 生成されたプロンプトファイルを確認")
        print("  2. Claude Codeに以下のコマンドでプロンプトを送信:")
        print(f"     @{prompt_path}")
        print("  3. Claude Codeが機能仕様書を生成します")
        print("")
        print("💡 ヒント:")
        print("  - プロンプトには以下が含まれています:")
        print("    • イシュー情報（タイトル、本文、ラベル等）")
        if include_comments:
            print("    • イシューのコメント")
        if related_files:
            print(f"    • 関連ファイル情報 ({len(related_files)}件)")
        print("    • 仕様書生成のガイドライン")
        print("    • 品質基準（9.0/10以上）")
        print("")
        print("=" * 70)
        
        return 0
        
    except FileNotFoundError as e:
        print(f"\n❌ ファイルが見つかりません: {e}")
        print("\n解決策:")
        print("  - 必要なスクリプトが存在するか確認してください")
        print("  - プロジェクトルートから実行していることを確認してください")
        return 1
        
    except RuntimeError as e:
        print(f"\n❌ 実行エラー: {e}")
        print("\n解決策:")
        print("  - GitHub認証を確認してください: gh auth status")
        print("  - リポジトリ名と組織名が正しいか確認してください")
        print("  - イシュー番号が存在するか確認してください")
        return 1
        
    except Exception as e:
        print(f"\n❌ 予期しないエラーが発生しました: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
