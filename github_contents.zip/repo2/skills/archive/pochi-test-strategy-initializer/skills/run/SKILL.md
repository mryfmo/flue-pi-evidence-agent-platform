---
name: pochi-test-strategy-initializer
description: >-
  テスト戦略（モック方針・品質目標・Layer比率）をヒアリングで確定し、
  test-strategy-config.json と conftest.py を生成するスキル。
  pochi-unit-test-generator / pochi-integration-test-designer / pochi-e2e-test-designer の前に実行する。
  「テスト戦略を初期化して」「モック方針を決めて」「test-strategy-config を生成して」と言われたときに使用する。
---

# pochi-test-strategy-initializer Skill

## スキル概要

テスト戦略を「最初に人間が決める」ために起動するスキル。
このスキルを先に実行することで、後続の各テスト生成スキルが
一貫したモック方針・品質目標・Layer比率で動作する。

**生成対象**:
- `{app_path}/tests/.onboarding/test-strategy-config.json`（mock_strategy セクションを含む完全版）
- `{app_path}/tests/conftest.py`（mock_strategy から自動生成）

> ⚠️ **絶対必須・直接実行禁止**
>
> このスキルのサブエージェント起動ステップは、Agentツールで指定のカスタムサブエージェントを
> 起動して実行すること。Claude Code（あなた自身）が直接テストコードを生成することは**厳禁**。

---

## STEP 1: ユーザーからの情報収集

AskUserQuestionツールで以下を確認する（**最大2回の質問で完結させること**）。

**1回目の質問（必須）**:
- **`app_path`**: 対象アプリのリポジトリルートパス（例: `/home/user/my-pochi-app`）
- **品質目標のカバレッジ**: 60% / 70% / 80% / カスタム（デフォルト: 60%）

**2回目の質問（モック方針）**:
以下のパッケージ分類をユーザーに確認する（T0 解析前のため候補は仮置き）：
- 「常にモック」候補（Snowflake, pochilib 等の外部サービス依存）→ always_mock
- 「本物を使う」候補（whoosh, sqlalchemy 等のロジック依存）→ never_mock
- 「Layer別に切り替え」候補（geopy, folium 等）→ layer_conditional

T0 解析が未実施の場合は候補を自動提示できないため、
「T0 解析後に自動検出します」と伝えてデフォルト設定で進むことも可能。

---

## STEP 2: T0 解析（依存パッケージの自動検出）

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-test-onboarding:pochi-t0-legacy-analyzer"`）を起動すること

```
Agentツールで pochi-t0-legacy-analyzer カスタムサブエージェントを起動し、
以下を実行させてください：
- {app_path} 配下の既存コードを静的解析する
- 出力先: {app_path}/tests/.onboarding/draft-contracts/（ドラフト契約ファイル群）
- 出力先: {app_path}/tests/.onboarding/module-inventory.json（モジュール一覧）
  ※ framework フィールドを必ず出力すること（"streamlit" / "flask" / "cli" 等）
```

T0 の出力から以下を抽出する：
- `module-inventory.json` の `external_dependencies` フィールド
- インストール済みパッケージとの差分:
  - インストール済み → `never_mock` 候補
  - 未インストール → `always_mock` 候補

### エラー時の対応（STEP 2）
- サブエージェントがエラー終了した場合: エラーメッセージをユーザーに提示し、続行/中止/リトライを確認する
- T0 完了後は STEP 3 に進む

---

## STEP 3: mock_strategy の確定と提示

STEP 1-2 の情報を統合し、以下の分類をユーザーに提示して確認を求める：

```
📋 モック戦略（確認してください）

always_mock（常にモック）:
  - pochilib, pochilib.snowflake, pochilib.llm
  - streamlit_antd_components, streamlit_folium
  - folium, jageocoder, shapely, geopy
  - pyinstrument, kaleido, playwright
  （T0解析で未インストールと判定されたパッケージを追加）

never_mock（本物を使用）:
  - whoosh, whoosh.qparser, whoosh.query
  - sqlalchemy
  - pandas, numpy
  （T0解析でインストール済みと判定されたパッケージを追加）

layer_conditional（Layer別に切り替え）:
  （例）geopy: L1/L2 はモック、L3 は本物

[A] この設定で確定する
[B] 変更してから確定する
```

ユーザーが [B] を選択した場合は変更内容を受け取り、設定を更新して確定する。

---

## STEP 4: test-strategy-config.json の生成

既存ファイルが存在する場合は上書き確認をしてから書き込む。

出力先: `{app_path}/tests/.onboarding/test-strategy-config.json`

```json
{
  "$schema": "test-strategy-config-v1",
  "project": {
    "name": "{app_path のディレクトリ名から自動設定}",
    "type": "streamlit-data-analysis",
    "app_path": "{app_path}",
    "test_path": "tests/"
  },
  "layers": {
    "L1_data_contracts": {
      "ratio": 40,
      "directory": "tests/contracts/",
      "framework": "pytest",
      "contracts_source": "tests/contracts/data-contracts.json"
    },
    "L2_logic": {
      "ratio": 40,
      "directory": "tests/unit/",
      "framework": "pytest",
      "business_rules_source": "tests/contracts/business-rules.json"
    },
    "L3_integration": {
      "ratio": 15,
      "directory": "tests/integration/",
      "framework": "pytest+unittest.mock",
      "mock_strategy": "patch_external_only"
    },
    "L4_e2e": {
      "ratio": 5,
      "directory": "tests/e2e/",
      "framework": "playwright-firefox",
      "scope": "critical_paths_only",
      "critical_paths": []
    }
  },
  "mock_strategy": {
    "always_mock": ["{STEP3で確定したalways_mockリスト}"],
    "never_mock": ["{STEP3で確定したnever_mockリスト}"],
    "layer_conditional": {}
  },
  "quality_targets": {
    "coverage_minimum": {STEP1で確定したカバレッジ目標（数値）},
    "l1_l2_combined_minimum": 80,
    "max_flaky_tests": 0,
    "max_test_execution_seconds": 120
  },
  "skill_preferences": {
    "preferred_scenario": "unit-test-generator",
    "auto_coverage_fix": true,
    "e2e_enabled": false
  }
}
```

> 💡 `e2e_enabled: false` がデフォルト。E2E テストが必要な場合はファイルを手動で編集して `true` に変更してください。

---

## STEP 5: conftest.py の生成

> ⚠️ **必須**: Agentツール（`subagent_type: "pochi-test-onboarding:pochi-t2-tdd-workflow"`）を起動すること

```
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow のサブエージェント
test-author を起動し、以下を実行させてください：

【conftest.py 生成専用モード】

■ フレームワーク検出（T0の出力を参照）
  - {app_path}/tests/.onboarding/module-inventory.json の framework フィールドを確認する
  - framework に応じてモック戦略を切り替える：
    - framework: "streamlit"
        → _passthrough_decorator を定義し st.cache_data / st.cache_resource に割り当てる
        → _MOCK_MODULES リストを test-strategy-config.json の mock_strategy.always_mock から生成する
        → mock_strategy.never_mock に含まれるパッケージは _MOCK_MODULES から除外する
        → {app_path}/tests/.onboarding/module-inventory.json から _PRELOAD_MODULES を自動生成する
    - framework: "flask"
        → app.test_client() ファクトリパターンを conftest.py に組み込む
    - framework: "cli" / その他
        → モック不要。直接 import できるよう sys.path のみ設定する

■ conftest.py の共通設定
  - sys.path に {app_path}/app/ を追加する
  - {app_path}/tests/conftest.py を生成する（既存の場合は差分のみ更新する）

■ 収集エラー確認（生成後に必ず実行）
  以下のコマンドを実行し、エラーがなくなるまで conftest.py を修正する
  （最大3回のリトライ）：
    cd {app_path} && python -m pytest --collect-only --tb=line -q 2>&1 \
      | grep -E "ERROR|ModuleNotFoundError|is not a package|ImportError" | head -20
  リトライ後もエラーが残る場合は、残存エラーをユーザーに提示して判断を仰ぐ。
```

### エラー時の対応（STEP 5）
- サブエージェントがエラー終了した場合: エラーメッセージをユーザーに提示し、続行/中止/リトライを確認する
- `--collect-only` のエラーが3回リトライ後も解消しない場合: 残存エラーを提示し、手動対応を促した上でユーザー判断で続行/中止を選択させる

---

## STEP 6: 完了レポート

```
✅ pochi-test-strategy-initializer 完了

📋 確定した戦略:
  カバレッジ目標: X%
  always_mock: N パッケージ
  never_mock: M パッケージ

📁 生成ファイル:
  - {app_path}/tests/.onboarding/test-strategy-config.json
  - {app_path}/tests/conftest.py

🚀 次のステップ:
  「単体テストを生成して」→ pochi-unit-test-generator
  ※ T0/T1 解析は pochi-unit-test-generator 内で実行されます（T0 は既に完了済み）

  > 💡 テスト実行結果の追跡は `pytest tests/ -q` の出力で確認してください。
  > test-progress.json は使用しません。
```

---

## 注意事項

- **test-progress.json は生成しない**（廃止済み）
- **既存の test-strategy-config.json が存在する場合**は上書き確認をする
- **conftest.py が既存の場合**は mock_strategy との差分のみ更新する
- **mock_strategy の never_mock が conftest.py の _MOCK_MODULES から除外されている**ことを必ず検証する
  （never_mock に含まれるパッケージをモック化すると isinstance() 等の型チェックが失敗する）
