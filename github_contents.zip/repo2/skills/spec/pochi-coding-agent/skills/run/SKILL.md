---
name: pochi-coding-agent
description: >-
  仕様駆動開発フレームワークのCoding Agent(実装フェーズ専用エージェント)として動作し、spec.json/plan.jsonのみを参照して実装を自動化します。
  「Coding Agentを起動」「実装を開始」「plan.jsonを実行」「pochi-coding-agent を起動」などと依頼した時に使用する。
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---

# Skill: pochi-coding-agent

## Metadata

- **skill_id**: pochi-coding-agent
- **version**: 1.0.0
- **status**: active
- **category**: implementation
- **author**: Pochi Development Team
- **created**: 2026-01-27
- **updated**: 2026-01-27

## Description

仕様駆動開発フレームワークのCoding Agent（実装フェーズ専用エージェント）として動作し、spec.json/plan.jsonのみを参照して実装を自動化します。

このSkillは、以下の成果物を生成します：

1. **実装コード** - plan.jsonのartifactsに記載されたファイル
2. **task_result.json** - 各タスクの実行結果レポート
3. **spec_mismatch_report.md** - 仕様と実装の不一致が検出された場合のレポート

**注意**: テストコードの生成・実行は行いません。ユーザーが手動で実施してください。

## Key Features

- **セッション分離**: 新セッションで起動し、spec.json/plan.jsonのみを参照（会話履歴の持ち込み禁止）
- **spec/plan の厳格な参照**: spec.jsonとplan.jsonを改変せず、実装のみに集中
- **TDD対応**: `tests/.onboarding/test-mapping.json` が存在する場合、タスクごとにRED確認→実装→GREEN確認→回帰テストのサイクルを実行
- **後方互換**: `test-mapping.json` がない場合は従来通りテスト実行なし（通常モード）で動作
- **ガードレール**: 仕様外の実装を検出してエスカレーション
- **ブロック状態管理**: 実装不可能な場合はblocked状態で停止

## Triggers

このSkillは以下のフレーズで起動します：

- 「Coding Agentを起動」
- 「execute plan」
- 「run plan」
- 「実装を開始」
- 「plan.jsonを実行」
- start coding phase
- launch coding agent
- execute implementation plan

## Entry Point

`prompts/coding_agent.md`

## ⚠️ CRITICAL: Skill Activation Protocol

**このスキルを起動する際は、以下の手順を厳守してください。**

### 起動時の必須手順

1. **新セッション宣言**
   ```
   「新セッションでCoding Agentを起動しています。
   このセッションでは、spec.json と plan.json のみを参照します。
   過去の会話履歴は参照しません。」
   ```

2. **spec.json と plan.json の読み込み**
   - FEATURE-IDを確認
   - `{app_path}/spec/features/[FEATURE-ID]/spec.json` を読み込む
   - `{app_path}/spec/plans/[FEATURE-ID].json` を読み込む
   - これらのファイル以外は参照禁止

3. **ツール制約の宣言**
   ```
   「Coding Agent モードで動作しています。
   使用可能なツール:
   - Read: ファイル読み込み
   - Write: ファイル書き込み
   - Edit: ファイル編集
   - Bash: テスト実行、ビルド、検証コマンド実行
   - Glob/Grep: ファイル検索、コンテンツ検索

   使用禁止のツール:
   - AskUserQuestion: ユーザーへの質問（仕様は凍結済み）
   - Task: サブエージェント起動

   制約:
   - spec.json/plan.json の改変は禁止
   - 仕様外の実装は禁止（検出時はエスカレーション）
   - blocked状態では停止してユーザーに報告」
   ```

4. **動作開始の確認**
   - plan.jsonのtasksからstatus: "pending"のタスクを選択
   - 依存関係（dependsOn）を確認
   - 実装開始前にタスク内容を確認

### 起動時のチェックリスト

スキル起動後、以下を確認してください:

- [ ] 新セッションが宣言されている
- [ ] spec.json が読み込まれている
- [ ] plan.json が読み込まれている
- [ ] ツール制約が宣言されている
- [ ] 実装対象タスクが選択されている
- [ ] AskUserQuestion を使用していない
- [ ] spec.json/plan.json を編集しようとしていない

### 禁止事項

**以下の行為は絶対に禁止です:**

- ❌ 会話履歴を参照する
- ❌ spec.json/plan.json を改変する
- ❌ AskUserQuestion で仕様を質問する（仕様は凍結済み）
- ❌ plan.jsonに記載されていないファイルを作成する
- ❌ 仕様との不一致を無視して実装を続ける
- ❌ blocked状態でも実装を続ける

## Workflow

### Task Select（タスク選択）

1. plan.json を読み込む
2. 実行可能なタスクを検索:
   - status が "pending" または未設定
   - dependsOn が空、または依存タスクが全て completed
3. 優先度順（priority: P0 > P1 > P2）でタスクを選択
4. タスクの内容を確認:
   - name, owner, artifacts
   - references: 参照する要件・受入基準・非機能要件
   - verification: テストコマンドと合格基準
   - status: 現在のステータス
5. **plan.jsonのstatus更新**:
   - Edit ツールで選択したタスクのstatusを "in_progress" に更新
   - **重要**: statusフィールドのみ更新、他のフィールドは一切変更禁止

### TDDモード判定（起動時・一度だけ実行）

Glob で `tests/.onboarding/test-mapping.json` を検索する。

- **存在する → TDDモード**: test-mapping.json を Read して保持
- **存在しない → 通常モード**: テスト実行なし（従来動作）

### Gather Context（コンテキスト収集）

1. **spec.json の参照**
   - references.requirements に対応する要件を読み込む
   - references.acceptance_criteria に対応する受入基準を読み込む
   - references.non_functional に対応する非機能要件を読み込む

2. **既存コードの読み込み**（必要な場合のみ）
   - artifacts に記載されたファイルが既存の場合、Read で読み込む
   - 依存するファイル（import元等）を Glob/Grep で検索して読み込む
   - **重要**: 過剰な読み込みは避け、タスクに必要な最小限のファイルのみ読み込む

3. **対応テストの特定**（TDDモードのみ）
   - test-mapping.json の `tests[].implementation_hint` からタスクの artifacts に対応するエントリを検索
   - 対応する `tests[].test_file` を対応テストとして記録
   - マッチしない場合はファイル名パターンで Glob フォールバック

4. **実装方針の決定**
   - spec.json の要件に従う
   - 既存のコードスタイルを踏襲
   - TDDモードの場合は対応テストが通るように実装

### Run Tests / RED確認（TDDモード・対応テスト特定済みのみ）

実装前に対応テストを実行して RED を確認する:
```bash
pytest {対応テストファイル} -q 2>&1 | head -30
```
期待結果: `ImportError` / `ModuleNotFoundError`

### Take Action（実装）

1. **ファイル作成/編集**
   - artifacts に記載されたファイルを Write または Edit で実装
   - spec.json の要件と受入基準を満たす
   - コメントやドキュメントは必要最小限にとどめる

2. **テストコードの実装**（該当する場合）
   - verification.test_command に対応するテストを実装
   - テストは success_criteria を満たすように記述

### Verify Work（検証）

**TDDモードの場合:**

1. **GREEN確認**: `pytest {対応テストファイル} -q`
   - 全PASS → 回帰テストへ
   - 失敗あり → 修正ループ（最大3回）→ 3回でGREENにならない場合はエスカレーション

2. **回帰テスト**: `pytest tests/unit/ tests/contracts/ -q`
   - 全PASS → タスク完了
   - 失敗 → 修正（最大1回）→ 解消しない場合はエスカレーション

**通常モードの場合:**

1. **テスト実行なし**（artifacts の作成/編集完了をもって検証完了）
2. verification.test_command を task_result.json に記録するのみ

**manual タスクの場合（verification_type: "manual"）:**

- `verification_type: "manual"` のタスクはテストコマンドを実行しない
- `verification.test_command` が `true` または `bash scripts/noop.sh` の場合もスキップする
- 目視確認が必要な旨を Report フェーズで記録する（→ manual_verification_summary.md）

**共通:**

3. **仕様との整合性チェック**
   - 実装が references で参照された要件を満たしているか確認
   - 受入基準を満たしているか確認
   - 非機能要件を満たしているか確認

4. **不一致の検出**
   - 仕様と実装が不一致の場合、spec_mismatch_report.md を生成
   - タスクを blocked 状態に設定
   - ユーザーにエスカレーション

### Report（報告）

1. **task_result.json の生成**
   - タスクの実行結果を記録
   - 検証結果を記録
   - artifacts_created のリストを記録

2. **plan.jsonのstatus更新**
   - 成功時: Edit ツールで該当タスクのstatusを "completed" に更新
   - 失敗時: Edit ツールで該当タスクのstatusを "blocked" に更新
   - **重要**: statusフィールドのみ更新、他のフィールドは一切変更禁止
   - **重要**: plan.json の **最後のタスク**（リスト末尾）も省略せず必ず status を更新すること

3. **manual タスクの記録**（verification_type: "manual" の場合）
   - `verification_type: "manual"` のタスクが完了した場合、以下を spec_mismatch_report.md に追記する：

   ```markdown
   ## ⚠️ 目視確認必要タスク

   | タスクID | タスク名 | 確認内容 |
   |---------|--------|--------|
   | [TASK-ID] | [タスク名] | [verification.success_criteria の内容] |

   > これらのタスクは自動テストで検証できません。
   > コードレビューおよびマージ前に目視確認を実施してください。
   ```

   出力先: `{app_path}/spec/features/[FEATURE-ID]/task_results/manual_verification_summary.md`
   （既存ファイルがある場合は追記する。新規の場合はヘッダー付きで作成する）

4. **次のタスクへ**
   - タスクが completed の場合、次のタスクを選択
   - blocked の場合、停止してユーザーに報告

## Outputs

### ファイルパス

- **実装コード**: plan.json の artifacts に記載されたパス
- **task_result.json**: `{app_path}/spec/features/[FEATURE-ID]/task_results/[TASK-ID].json`
- **test_output.txt**: `{app_path}/spec/features/[FEATURE-ID]/task_results/[TASK-ID]_test_output.txt`
- **spec_mismatch_report.md**: `{app_path}/spec/features/[FEATURE-ID]/task_results/[TASK-ID]_mismatch_report.md`

## Tool Constraints

### 許可されるツール

- **Read**: ファイル読み込み
- **Write**: ファイル書き込み
- **Edit**: ファイル編集
- **Bash**: テスト実行、ビルド、検証コマンド実行
- **Glob**: ファイル検索
- **Grep**: コンテンツ検索

### 禁止されるツール

- **AskUserQuestion**: ユーザーへの質問（仕様は凍結済み）
- **Task**: サブエージェント起動
- **EnterPlanMode**: Plan Mode への遷移
- その他、実装以外のツール

## Important Principles

1. **セッション分離の厳守**
   - 新セッションで起動
   - spec.json/plan.json のみを参照
   - 会話履歴は参照しない

2. **spec.json が正（Source of Truth）**
   - spec.json は改変禁止
   - plan.json の更新は statusフィールドのみ許可
   - その他のフィールド（artifacts, references, verification等）は改変禁止
   - 仕様との不一致は実装側を修正

3. **自動検証の徹底**
   - 各タスク完了後、必ず verification.test_command を実行
   - テストが通らない場合は blocked 状態で停止

4. **ガードレールの遵守**
   - 仕様外の実装を検出したらエスカレーション
   - blocked 状態では実装を続けない

## Error Handling & Escalation

### エスカレーション条件

以下の場合、blocked 状態でユーザーにエスカレーションします：

1. **仕様と実装の不一致**
   - spec.json の要件を満たせない
   - 受入基準を満たせない
   - 非機能要件を満たせない

2. **テスト失敗**
   - verification.test_command が失敗する
   - success_criteria を満たせない

3. **技術的な問題**
   - 必要なライブラリがインストールできない
   - ビルドエラーが解消できない
   - 既存コードとの互換性問題

4. **plan.json の不備**
   - artifacts のパスが不正
   - 依存関係が循環している
   - verification.test_command が実行できない

5. **plan.json更新失敗**
   - statusフィールドの更新に失敗
   - Edit ツールでのplan.json更新エラー
   - この場合、task_result.jsonに "plan_update_failed": true を記録
   - spec_mismatch_report.mdを生成してユーザーにエスカレーション

### エスカレーション手順

1. spec_mismatch_report.md を生成
2. task_result.json に status: "blocked" を記録
3. ユーザーに報告:
   ```
   ❌ エラー停止
   分類: [ユーザー入力の問題 / ファイル不在 / Skill内部の問題] ← 該当するものを選択
   タスク: [TASK-ID]
   詳細: [理由]
   参照:
     - task_result.json: [パス]
     - spec_mismatch_report.md: [パス]

   次のアクションを選択してください:
   1. spec.json/plan.json を修正して再実行
   2. 実装方針を変更して再試行
   3. タスクをスキップ
   ```

   **分類ラベルの選び方**:
   - `[ユーザー入力の問題]`: spec.json/plan.json の記載不備、artifacts のパス不正 等
   - `[ファイル不在]`: artifacts のパスにファイルが存在しない、依存モジュールが未インストール 等
   - `[Skill内部の問題]`: plan.json 書き戻し失敗、予期しない実行エラー 等

## Prerequisites（前提条件）

Coding Agentが正常に動作するためには、以下の前提条件が必要です：

1. **開発環境**
   - Node.js / Python / その他の必要なランタイムがインストール済み
   - パッケージマネージャ（npm, pip等）が利用可能

2. **テストランナー**
   - ユニットテスト: Jest, pytest 等
   - E2Eテスト: Playwright, Cypress 等
   - 負荷テスト: k6 等

3. **spec.json/plan.json の品質**
   - スキーマ検証が通っている
   - カバレッジゲート条件を満たしている（gate_status: "pass"）
   - 依存関係がDAGを形成している

4. **Initializerの完了**
   - spec.json が frozen 状態
   - plan.json が生成済み
   - coverage_summary.json が gate_status: "pass"

## References

- [pochi-spec-initializer/docs/README_spec_driven_dev.md](../pochi-spec-initializer/docs/README_spec_driven_dev.md) - 全体説明
- [docs/WORKFLOW.md](docs/WORKFLOW.md) - ワークフロー詳細
- [docs/GUARDRAILS.md](docs/GUARDRAILS.md) - ガードレール（落とし穴）

## Templates

- `templates/task_result.template.json` - タスク実行結果テンプレート
- `templates/spec_mismatch_report.template.md` - 仕様不一致レポートテンプレート

## Usage Examples

### ✅ 正しい使用例

#### 例1: FEATURE-ID自動検出（推奨）

```
ユーザー: 「Coding Agentを起動」

Claude:
1. 新セッション宣言
2. Skillツールで pochi-coding-agent を起動
3. prompts/coding_agent.md を Read
4. ツール制約を宣言
5. FEATURE-ID自動検出:
   - Glob で {app_path}/spec/features/*/spec.json を検索
   - 各ファイルを Read して status="frozen" を確認
   - 候補が1つ: FEAT-EXAMPLE-001 を検出
   - 「FEATURE-ID を自動検出しました: FEAT-EXAMPLE-001 - 機能実装計画のタイトル」
6. {app_path}/spec/features/FEAT-EXAMPLE-001/spec.json を読み込む
7. {app_path}/spec/plans/FEAT-EXAMPLE-001.json を読み込む
8. 実行可能なタスクを選択
9. タスクの実装を開始
```

#### 例2: FEATURE-ID明示的指定

```
ユーザー: 「Coding Agentを起動して、FEAT-EXAMPLE-001を実装してください」

Claude:
1. 新セッション宣言
2. Skillツールで pochi-coding-agent を起動
3. prompts/coding_agent.md を Read
4. ツール制約を宣言
5. FEATURE-ID抽出:
   - ユーザー入力から "FEAT-EXAMPLE-001" を検出
   - 「指定されたFEATURE-ID: FEAT-EXAMPLE-001」
6. {app_path}/spec/features/FEAT-EXAMPLE-001/spec.json を読み込む
7. {app_path}/spec/plans/FEAT-EXAMPLE-001.json を読み込む
8. 実行可能なタスクを選択
9. タスクの実装を開始
```

#### 例3: 複数候補がある場合

```
ユーザー: 「Coding Agentを起動」

Claude:
1-4. (同上)
5. FEATURE-ID自動検出:
   - Glob で {app_path}/spec/features/*/spec.json を検索
   - 候補が2つ見つかる:
     1. FEAT-EXAMPLE-001 (v1.0.0) - 機能実装計画のタイトル
     2. FEAT-DASHBOARD-002 (v1.0.0) - ダッシュボード機能
   - 「複数のfrozen状態のspec.jsonが見つかりました。
     FEATURE-IDを指定して再実行してください:

     候補:
     1. FEAT-EXAMPLE-001 (v1.0.0) - 機能実装計画のタイトル
        最終更新: 2026-01-27 10:00:00

     2. FEAT-DASHBOARD-002 (v1.0.0) - ダッシュボード機能
        最終更新: 2026-01-26 15:30:00

     実行例:
     「Coding Agentを起動して、FEAT-EXAMPLE-001を実装してください」」
6. エージェント停止

ユーザー: 「Coding Agentを起動して、FEAT-DASHBOARD-002を実装してください」

Claude:
(例2と同様に実行)
```

### ❌ 誤った使用例

```
ユーザー: 「Coding Agentを起動して」

Claude（誤った動作）:
1. spec.json/plan.json を読み込まない
2. ユーザーに質問を開始 ← ❌ AskUserQuestion は禁止
3. 会話履歴を参照 ← ❌ セッション分離違反
4. spec.json を編集 ← ❌ 改変禁止
5. テストを実行せずに次のタスクへ ← ❌ 検証漏れ
```

**問題点:**
- spec.json/plan.json を読み込んでいない
- AskUserQuestion を使用している
- セッション分離を守っていない
- spec.json を改変している
- 検証をスキップしている

## ログ出力の方針

Coding Agentは、以下の方針でユーザーにメッセージを出力します：

### タイミングと内容

| タイミング | 出力内容 | 詳細参照先 |
|-----------|---------|-----------|
| 起動時 | 新セッション宣言、ツール制約、事前準備チェックのリマインダー | README.md 114-134行 |
| FEATURE-ID検出時 | 検出結果、spec/planパス、frozen状態確認 | README.md 122-128行 |
| テスト実行前 | ポリシー適用状況、使用するプロファイル | README.md 47-81行 |
| テスト生成前 | ポリシーチェック結果、check_test_generation.py経由の確認 | README.md 92-112行 |
| エラー時 | 原因、トラブルシューティングのヒント、README.md参照リンク | README.md 135-156行 |
| blocked時 | 理由、次のアクション選択肢、レポートファイルパス | README.md エスカレーション（260-313行） |

### メッセージの設計原則

1. **簡潔性**: 必要最低限の情報のみを出力
2. **階層化**: 概要 → 詳細（README.md参照）の構造
3. **アクション指向**: 次に何をすべきかを明確に提示
4. **視覚的**: 絵文字や記号で重要度を表現

### README.md参照の統一フォーマット

```
詳細: README.md {セクション名}（{行番号}）を参照
```

例:
- `詳細: README.md テスト実行の基本ルール（47-81行）を参照`
- `詳細: README.md トラブルシューティング（135-156行）を参照`

## Version History

- **1.0.0** (2026-01-27): 初版作成
