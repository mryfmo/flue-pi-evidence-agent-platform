# pochi-coding-agent

Coding Agent（実装フェーズ専用エージェント）は、仕様駆動開発フレームワークのPhase 3（実装フェーズ）を担当するSkillです。

## このドキュメントの役割

このREADME.mdは、Coding Agentの**詳細リファレンス**です。

- **Skill起動中**: 簡潔なログメッセージが表示されます
- **詳細確認時**: このREADME.mdで詳細情報を確認できます
- **トラブル時**: トラブルシューティングセクション（135-156行）を参照

## 概要

Coding Agentは、Initializer（pochi-spec-initializer）が生成したspec.json/plan.jsonのみを参照し、実装を自動化します。

### 主な特徴

- **セッション分離**: 新セッションで起動し、spec.json/plan.jsonのみを参照
- **spec/planの厳格な参照**: spec.jsonとplan.jsonを改変せず、実装のみに集中
- **テスト抑止**: テストコードの自動生成・実行は行わない（ユーザーが手動実施）
- **ガードレール**: 仕様外の実装を検出してエスカレーション
- **ブロック状態管理**: 実装不可能な場合はblocked状態で停止

## 事前準備チェックリスト（起動前の確認事項）

**参照タイミング**: Skill起動前

Coding Agentを起動する前に、以下を確認してください。

### 必須の準備

#### Initializer完了の確認

- [ ] spec.json が frozen 状態である（`pochi-spec-initializer/specs/features/[FEATURE-ID]/spec.json`）
- [ ] plan.json が生成済みである（`pochi-spec-initializer/plans/[FEATURE-ID].json`）
- [ ] coverage_summary.json の gate_status が "pass"（`pochi-spec-initializer/specs/features/[FEATURE-ID]/coverage_summary.json`）
- [ ] quality_report.json が生成済みである（`pochi-spec-initializer/specs/features/[FEATURE-ID]/quality_report.json`）

#### 開発環境の確認

- [ ] 必要なランタイムがインストール済み（Node.js, Python等）
- [ ] 依存パッケージがインストール済み

### テスト方針の理解

**参照タイミング**: Skill起動前

Coding Agentでは、テストコードの自動生成・実行は行いません。

#### 基本方針

- **テストコードの生成**: 禁止（ユーザーが手動で作成）
- **テストの実行**: 禁止（ユーザーが手動で実行）
- **verification.test_command**: plan.jsonに記載されていても自動実行しない

#### plan.jsonでのverification指定例

```json
{
  "verification": {
    "test_command": "npm test -- path/to/test.spec.ts",
    "success_criteria": "全ユニットテストがパスし、カバレッジ>80%",
    "verification_type": "unit"
  }
}
```

このtest_commandは、Coding Agentでは実行されません。
ユーザーが実装後に手動で実行するための参考情報として記載されます。

### Coding Agent起動時の注意事項

**参照タイミング**: Skill起動時

#### 新セッションで起動

- Coding Agentは **新しいセッション** で起動してください
- 会話履歴は参照されません
- spec.json/plan.jsonのみを参照します

#### FEATURE-IDの指定方法

- frozen状態のspec.jsonが1つのみ → 自動検出
- 複数ある場合 → FEATURE-IDを明示的に指定
  ```
  「Coding Agentを起動して、FEAT-EXAMPLE-001を実装してください」
  ```

#### spec.json/plan.jsonは改変禁止

- Coding Agent起動後、これらのファイルは Read-only として扱われます
- 仕様変更が必要な場合、Coding Agentを停止してInitializerから再実行してください

#### テストは手動実施

- Coding Agentはテストコードを生成しません
- Coding Agentはテストを実行しません
- 実装完了後、ユーザー自身でテストを作成・実行してください

## 起動方法

### 1. 起動コマンド

以下のいずれかのフレーズでCoding Agentを起動します：

```
「Coding Agentを起動」
「execute plan」
「run plan」
「実装を開始」
「plan.jsonを実行」
```

### 2. FEATURE-IDの指定

起動後、FEATURE-IDを指定します：

```
ユーザー: 「FEAT-EXAMPLE-001を実装してください」
```

## ワークフロー

### 1. Task Select（タスク選択）

plan.jsonから実行可能なタスクを選択します：

- status が "pending" または未設定
- dependsOn が空、または依存タスクが全て completed
- 優先度順（P0 > P1 > P2）で選択

### 2. Gather Context（コンテキスト収集）

spec.jsonから要件を読み込みます：

- references.requirements に対応する要件
- references.acceptance_criteria に対応する受入基準
- references.non_functional に対応する非機能要件

### 3. Take Action（実装）

plan.jsonのartifactsに記載されたファイルを実装します：

- 新規ファイルの作成
- 既存ファイルの編集
- テストコードの実装

### 4. Verify Work（検証）

実装内容をコードレビューで検証します：

- 仕様との整合性チェック（コードレビューレベル）
- テストは自動実行しません
- ユーザーが手動でテストを実施する必要があります

### 5. Report（報告）

task_result.jsonを生成して報告します：

- タスクの実行結果
- 検証結果
- 生成されたartifacts

## 出力ファイル

### task_result.json

各タスクの実行結果を記録します。

**パス**: `pochi-spec-initializer/specs/features/[FEATURE-ID]/task_results/[TASK-ID].json`

**例**:
```json
{
  "task_id": "T-EX-001",
  "status": "completed",
  "passed": true,
  "started_at": "2026-01-27T10:00:00Z",
  "completed_at": "2026-01-27T10:15:00Z",
  "verification": {
    "test_command": "npm test -- server/config/__tests__/featureFlags.test.ts",
    "auto_execution": false,
    "note": "Test execution is disabled. User must run tests manually."
  },
  "artifacts_created": [
    "server/config/featureFlags.ts",
    "web/config/featureFlags.ts"
  ],
  "references_verified": {
    "requirements": ["R-001"],
    "acceptance_criteria": ["AC-07"],
    "non_functional": []
  },
  "notes": "Feature flag implementation completed. Tests must be run manually by user.",
  "retry_count": 0
}
```

### test_output.txt

テスト実行の出力を保存します。

**パス**: `pochi-spec-initializer/specs/features/[FEATURE-ID]/task_results/[TASK-ID]_test_output.txt`

### spec_mismatch_report.md

仕様と実装の不一致が検出された場合に生成されます。

**パス**: `pochi-spec-initializer/specs/features/[FEATURE-ID]/task_results/[TASK-ID]_mismatch_report.md`

## エラー処理とエスカレーション

### エスカレーション条件

以下の場合、blocked状態でユーザーにエスカレーションします：

1. **仕様と実装の不一致**
   - spec.jsonの要件を満たせない
   - 受入基準を満たせない
   - 非機能要件を満たせない

2. **テスト関連タスクの検出**
   - タスクがテストコード生成を含む場合
   - テストファイルがartifactsに含まれる場合

3. **技術的な問題**
   - 必要なライブラリがインストールできない
   - ビルドエラーが解消できない
   - 既存コードとの互換性問題

4. **plan.jsonの不備**
   - artifactsのパスが不正
   - 依存関係が循環している
   - verification.test_commandが実行できない

### エスカレーション時の対応

spec_mismatch_report.mdを確認し、以下のいずれかを選択します：

1. **spec.json/plan.jsonを修正して再実行**
   - Initializerを再実行
   - coverage_summary.jsonとquality_report.jsonを再生成
   - Coding Agentを再起動

2. **実装方針を変更して再試行**
   - Coding Agentに再試行を指示
   - 別のアプローチを試す

3. **タスクをスキップ**
   - タスクをスキップして次のタスクへ
   - 後で手動で実装

4. **Coding Agentを停止**
   - 実装を停止
   - 手動で対応

## テスト方針

### 基本方針

Coding Agentでは、テストコードの自動生成・実行を行いません。

### テスト生成

- **禁止**: テストファイル（test_*.py, *.test.ts等）の自動生成は行いません
- **理由**: テストはユーザーが要件を理解した上で作成すべきため
- **対応**: テストコードはユーザーが手動で作成してください

### テスト実行

- **禁止**: verification.test_commandが記載されていても自動実行しません
- **理由**: テスト環境の多様性とタイミングのコントロールのため
- **対応**: 実装完了後、ユーザーが手動でテストを実行してください

### plan.jsonのverificationセクション

```json
{
  "verification": {
    "test_command": "npm test -- path/to/test.spec.ts",
    "success_criteria": "全ユニットテストがパスし、カバレッジ>80%",
    "verification_type": "unit"
  }
}
```

このtest_commandは、ユーザーが手動でテストを実行する際の参考情報として記載されます。
Coding Agentでは自動実行されません。

### テスト関連タスクの扱い

テスト関連のタスク（artifactsにテストファイルが含まれる等）が検出された場合：

1. 即座にblocked状態でエスカレーション
2. ユーザーに以下の選択肢を提示：
   - テストコードは手動で作成
   - タスクをスキップ
   - Coding Agentを停止

## ツール制約

### 許可されるツール

- **Read**: ファイル読み込み
- **Write**: ファイル書き込み
- **Edit**: ファイル編集
- **Bash**: テスト実行、ビルド、検証コマンド実行
- **Glob**: ファイル検索
- **Grep**: コンテンツ検索

### 禁止されるツール

- **AskUserQuestion**: ユーザーへの質問（仕様は凍結済み）
- **Task**: サブエージェント起動
- **EnterPlanMode**: Plan Modeへの遷移
- その他、実装以外のツール

## 重要な原則

1. **セッション分離の厳守**
   - spec.json/plan.jsonのみを参照
   - 会話履歴は参照しない

2. **spec.jsonが正（Source of Truth）**
   - spec.jsonとplan.jsonは改変禁止
   - 仕様との不一致は実装側を修正

3. **自動検証の徹底**
   - 各タスク完了後、必ずverification.test_commandを実行
   - テストが通らない場合はblocked状態で停止

4. **ガードレールの遵守**
   - 仕様外の実装を検出したらエスカレーション
   - blocked状態では実装を続けない

## 関連ドキュメント

- [SKILL.md](SKILL.md) - Skill定義
- [prompts/coding_agent.md](prompts/coding_agent.md) - 詳細プロンプト
- [templates/task_result.template.json](templates/task_result.template.json) - タスク結果テンプレート
- [templates/spec_mismatch_report.template.md](templates/spec_mismatch_report.template.md) - 仕様不一致レポートテンプレート

## バージョン履歴

- **1.0.0** (2026-01-27): 初版作成
