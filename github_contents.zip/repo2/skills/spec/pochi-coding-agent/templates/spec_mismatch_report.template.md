# Spec Mismatch Report

## Task Information

- **Task ID**: T-XX-XXX
- **Task Name**: Task name here
- **Status**: blocked
- **Generated At**: 2026-01-27T10:00:00Z

## Issues

### Issue 1: [Category]

**Severity**: error | warning

**Description**:
[Detailed description of the mismatch between spec and implementation]

**Spec Requirement**:
[Quote from spec.json showing what was required]

**Current Implementation**:
[Description of what was implemented]

**Impact**:
[Impact of this mismatch on the system]

### Issue 2: [Category]

...

### Issue: Test Policy Violation

**Severity**: error

**Description**:
テスト生成または実行がポリシーでブロックされました（Test Policy Phase 1）。

**Policy Profile**: [strict | unit-only]

**Blocked Reason**:
[ポリシーチェックの出力内容をここに記載]

**Violation Type**:
- [ ] テスト生成がブロックされた（check_test_generation.py が exit_code != 0）
- [ ] テスト実行コマンドがポリシー違反（pytest直接実行など）
- [ ] 禁止パターンを含むテストが検出された（ネットワーク、DB等）
- [ ] 危険なpytestオプションが検出された（--lf, --pdb, --trace）

**Current Command**:
```
[実行しようとしたコマンドまたは生成しようとしたテストファイル]
```

**Required Command Format**:
- **テスト実行**: `scripts/run_tests.py --profile [profile] --level [level]`
- **テスト生成**: `scripts/check_test_generation.py --test-file [file] --test-type [type]`
- **テスト実行スキップ**: `scripts/noop.sh`

**Impact**:
- テストの実行または生成が完全にブロックされています
- タスクは blocked 状態となり、ユーザーの介入が必要です
- プロファイルを変更するか、plan.jsonのverification.test_commandを修正する必要があります

## Root Cause Analysis

[Analysis of why the mismatch occurred]

Possible causes:
1. Spec.json requirement is ambiguous
2. Plan.json task is incomplete
3. Technical limitation preventing implementation
4. Dependency issue with existing code

## Recommended Actions

1. **Option 1: Update spec.json/plan.json**
   - Modify spec.json to align with implementation constraints
   - Update plan.json to add missing tasks or dependencies
   - Re-run Initializer to regenerate coverage and quality reports

2. **Option 2: Modify implementation**
   - Adjust implementation to meet spec requirements
   - Add necessary libraries or dependencies
   - Refactor existing code to support new requirements

3. **Option 3: Split task**
   - Break task into smaller sub-tasks
   - Add intermediate tasks to plan.json
   - Address dependencies separately

## Escalation Required

This task requires manual intervention. Please:

1. Review this report
2. Choose one of the recommended actions
3. Update spec.json/plan.json if necessary
4. Instruct Coding Agent to retry or skip this task

## Related Files

- **spec.json**: `pochi-spec-initializer/specs/features/FEAT-XXX/spec.json`
- **plan.json**: `pochi-spec-initializer/plans/FEAT-XXX.json`
- **task_result.json**: `pochi-spec-initializer/specs/features/FEAT-XXX/task_results/T-XX-XXX.json`
- **test_output.txt**: `pochi-spec-initializer/specs/features/FEAT-XXX/task_results/T-XX-XXX_test_output.txt`
