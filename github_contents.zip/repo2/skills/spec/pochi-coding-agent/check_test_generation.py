#!/usr/bin/env python3
"""
check_test_generation.py - SDD Test Policy Phase 1 テスト生成チェックスクリプト

Claude Code仕様駆動開発におけるテスト生成を制御するチェックスクリプト。
ポリシーファイル（.pochi/test_policy.yaml）に基づいてテストコード生成の可否を判定します。

使用例:
    # ユニットテスト生成前のチェック（許可される）
    python scripts/check_test_generation.py --test-file tests/unit/test_calculator.py --test-type unit

    # 結合テスト生成前のチェック（strictプロファイルではブロックされる）
    python scripts/check_test_generation.py --test-file tests/integration/test_api.py --test-type integration

    # ポリシーを表示
    python scripts/check_test_generation.py --show-policy --profile strict
"""

import sys
import os
import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional

# PyYAMLが利用可能かチェック
try:
    import yaml
    HAS_PYYAML = True
except ImportError:
    HAS_PYYAML = False


def simple_yaml_parse(content: str) -> Dict[str, Any]:
    """
    簡易YAMLパーサー（PyYAML未インストール時のフォールバック）
    Phase 1のポリシーファイルで必要な基本的な構造のみサポート。

    サポート内容:
    - key: value 形式
    - リスト（- item）
    - ネストした辞書（インデントベース）
    - コメント（#で始まる行）

    Args:
        content: YAMLファイルの内容

    Returns:
        パースされた辞書
    """
    result = {}
    current_dict = result
    dict_stack = [result]
    current_key = None
    current_list = None
    base_indent = 0

    lines = content.split('\n')

    for line_num, line in enumerate(lines, 1):
        # コメントと空行をスキップ
        stripped = line.lstrip()
        if not stripped or stripped.startswith('#'):
            continue

        # インデントレベルを計算
        indent = len(line) - len(stripped)

        # リスト項目
        if stripped.startswith('- '):
            value = stripped[2:].strip()
            if current_list is not None:
                # 値の型変換
                if value.lower() == 'true':
                    current_list.append(True)
                elif value.lower() == 'false':
                    current_list.append(False)
                elif value.isdigit():
                    current_list.append(int(value))
                else:
                    # クォート除去
                    if (value.startswith('"') and value.endswith('"')) or \
                       (value.startswith("'") and value.endswith("'")):
                        value = value[1:-1]
                    current_list.append(value)
            continue

        # key: value 形式
        if ':' in stripped:
            parts = stripped.split(':', 1)
            key = parts[0].strip()
            value = parts[1].strip() if len(parts) > 1 else ''

            # インデントレベルに応じて辞書スタックを調整
            while len(dict_stack) > 1 and indent <= base_indent:
                dict_stack.pop()
                base_indent -= 2

            current_dict = dict_stack[-1]

            if not value:
                # 空の値 = ネストした辞書またはリストの開始
                current_dict[key] = {}
                dict_stack.append(current_dict[key])
                base_indent = indent
                current_key = key
                current_list = None
            elif value.startswith('[') and value.endswith(']'):
                # インラインリスト [item1, item2]
                items = [item.strip().strip('"').strip("'") for item in value[1:-1].split(',')]
                current_dict[key] = items
                current_list = None
            else:
                # 通常の値
                # 型変換
                if value.lower() == 'true':
                    current_dict[key] = True
                elif value.lower() == 'false':
                    current_dict[key] = False
                elif value.isdigit():
                    current_dict[key] = int(value)
                else:
                    # クォート除去
                    if (value.startswith('"') and value.endswith('"')) or \
                       (value.startswith("'") and value.endswith("'")):
                        value = value[1:-1]
                    current_dict[key] = value

                # リストの開始をチェック（次の行が - で始まる場合）
                if line_num < len(lines):
                    next_line = lines[line_num].lstrip() if line_num < len(lines) else ''
                    if next_line.startswith('- '):
                        current_dict[key] = []
                        current_list = current_dict[key]

    return result


def load_policy(policy_path: str = '.pochi/test_policy.yaml') -> Dict[str, Any]:
    """
    ポリシーファイルを読み込む。

    Args:
        policy_path: ポリシーファイルのパス

    Returns:
        パースされたポリシー辞書

    Raises:
        FileNotFoundError: ポリシーファイルが見つからない
        Exception: パースエラー
    """
    policy_file = Path(policy_path)

    if not policy_file.exists():
        raise FileNotFoundError(
            f"ポリシーファイルが見つかりません: {policy_path}\n"
            f".pochi/test_policy.yaml を作成してください。"
        )

    content = policy_file.read_text(encoding='utf-8')

    if HAS_PYYAML:
        try:
            policy = yaml.safe_load(content)
            return policy
        except yaml.YAMLError as e:
            raise Exception(f"YAMLパースエラー: {e}")
    else:
        # 簡易YAMLパーサーを使用
        try:
            policy = simple_yaml_parse(content)
            return policy
        except Exception as e:
            raise Exception(f"YAMLパースエラー（簡易パーサー）: {e}")


def get_effective_policy(policy: Dict[str, Any], profile_name: str) -> Dict[str, Any]:
    """
    プロファイルを適用した実効ポリシーを取得。

    Args:
        policy: ポリシー辞書
        profile_name: プロファイル名

    Returns:
        実効ポリシー辞書

    Raises:
        ValueError: プロファイルが見つからない
    """
    profiles = policy.get('profiles', {})

    if profile_name not in profiles:
        available = ', '.join(profiles.keys())
        raise ValueError(
            f"プロファイル '{profile_name}' が見つかりません。\n"
            f"利用可能なプロファイル: {available}"
        )

    profile = profiles[profile_name]

    # ベースポリシーとプロファイルをマージ
    effective = {
        'profile_name': profile_name,
        'description': profile.get('description', ''),
        'test_generation': profile.get('test_generation', {}),
    }

    return effective


def detect_forbidden_patterns(test_content: str, forbidden_patterns: List[str]) -> List[str]:
    """
    禁止パターンを検出。

    Args:
        test_content: テストファイルの内容
        forbidden_patterns: 禁止パターンのリスト

    Returns:
        検出された禁止パターンのリスト
    """
    detected = []

    # パターンと検出キーワードのマッピング
    pattern_keywords = {
        'network_access': ['requests.', 'urllib.', 'httpx.', 'aiohttp.', 'socket.'],
        'database_access': ['sqlalchemy', 'psycopg2', 'pymongo', 'mysql.connector', 'sqlite3.'],
        'file_system_write': ['open(', '.write(', 'shutil.copy', 'shutil.move', 'os.remove', 'os.unlink'],
        'external_api_call': ['api.', 'API.', 'requests.post', 'requests.get', 'requests.put'],
    }

    for pattern in forbidden_patterns:
        if pattern in pattern_keywords:
            keywords = pattern_keywords[pattern]
            for keyword in keywords:
                if keyword in test_content:
                    detected.append(pattern)
                    break

    return detected


def validate_test_generation(
    effective_policy: Dict[str, Any],
    test_file: str,
    test_type: str
) -> Tuple[bool, str]:
    """
    テスト生成の可否を判定。

    Args:
        effective_policy: 実効ポリシー
        test_file: テストファイルパス
        test_type: テストタイプ（unit/integration/e2e）

    Returns:
        (許可フラグ, 理由メッセージ)
    """
    test_gen_config = effective_policy.get('test_generation', {})

    # テスト生成が許可されているか
    if not test_gen_config.get('allow_test_generation', False):
        return False, f"プロファイル '{effective_policy['profile_name']}' はテスト生成を許可していません"

    # テストタイプが許可されているか
    allowed_types = test_gen_config.get('allowed_test_types', [])
    if test_type and test_type not in allowed_types:
        return False, f"テストタイプ '{test_type}' は許可されていません（許可: {', '.join(allowed_types)}）"

    # テストファイルが存在する場合、禁止パターンをチェック
    test_path = Path(test_file)
    if test_path.exists():
        content = test_path.read_text(encoding='utf-8')
        forbidden_patterns = test_gen_config.get('forbidden_patterns', [])
        detected = detect_forbidden_patterns(content, forbidden_patterns)

        if detected:
            return False, f"禁止パターンが検出されました: {', '.join(detected)}"

    return True, "OK"


def main():
    """メイン処理"""
    parser = argparse.ArgumentParser(
        description='SDD Test Policy Phase 1 - テスト生成チェックスクリプト',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用例:
  # ユニットテスト生成前のチェック
  %(prog)s --test-file tests/unit/test_example.py --test-type unit

  # 結合テスト生成前のチェック（strictプロファイルではブロックされる）
  %(prog)s --test-file tests/integration/test_api.py --test-type integration

  # ポリシーを表示
  %(prog)s --show-policy --profile strict
        """
    )

    parser.add_argument(
        '--test-file',
        help='生成するテストファイルのパス'
    )

    parser.add_argument(
        '--test-type',
        choices=['unit', 'integration', 'e2e'],
        help='テストタイプ'
    )

    parser.add_argument(
        '--profile',
        default=None,
        help='使用するプロファイル（デフォルト: ポリシーファイルのdefault_profile）'
    )

    parser.add_argument(
        '--check-only',
        action='store_true',
        help='チェックのみ（ブロックしない、常に終了コード0を返す）'
    )

    parser.add_argument(
        '--show-policy',
        action='store_true',
        help='実効ポリシー（test_generation設定）を表示'
    )

    parser.add_argument(
        '--policy-file',
        default='.pochi/test_policy.yaml',
        help='ポリシーファイルのパス（デフォルト: .pochi/test_policy.yaml）'
    )

    args = parser.parse_args()

    # ポリシーファイルを読み込み
    try:
        policy = load_policy(args.policy_file)
    except FileNotFoundError as e:
        print(f"❌ エラー: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"❌ ポリシーファイルの読み込みに失敗しました: {e}", file=sys.stderr)
        return 1

    # プロファイルを決定（優先順位: CLI引数 > 環境変数 > default_profile）
    profile_name = args.profile or os.environ.get('TEST_POLICY_PROFILE') or policy.get('default_profile', 'strict')

    # 実効ポリシーを取得
    try:
        effective_policy = get_effective_policy(policy, profile_name)
    except ValueError as e:
        print(f"❌ エラー: {e}", file=sys.stderr)
        return 1

    # ポリシー表示モード
    if args.show_policy:
        print(f"📋 実効ポリシー - test_generation設定（プロファイル: {profile_name}）\n")
        test_gen_config = effective_policy.get('test_generation', {})
        print(json.dumps(test_gen_config, ensure_ascii=False, indent=2))
        return 0

    # テストファイルとテストタイプが必要
    if not args.test_file or not args.test_type:
        print("❌ エラー: --test-file と --test-type は必須です（--show-policyを除く）", file=sys.stderr)
        parser.print_help()
        return 1

    # テスト生成の可否を判定
    allowed, reason = validate_test_generation(effective_policy, args.test_file, args.test_type)

    if not allowed:
        if args.check_only:
            print(f"⚠️  警告: テスト生成がブロックされました: {reason}")
            print(f"   (--check-only モードのため、終了コード0を返します)")
            return 0
        else:
            print(f"🚫 テスト生成をブロックしました: {reason}")
            return 1

    # 生成が許可された場合
    print(f"✅ テスト生成が許可されました")
    print(f"   ファイル: {args.test_file}")
    print(f"   タイプ: {args.test_type}")
    print(f"   プロファイル: {profile_name}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
