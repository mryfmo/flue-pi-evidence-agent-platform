# 仕様駆動開発ワークフロー

このドキュメントでは、Initializer → 凍結 → Coding Agent への移行プロセスを詳しく説明します。

---

## 全体フロー

```
1. Initializer フェーズ（仕様策定）
   ↓
2. 凍結（Freeze）
   ↓
3. Coding Agent フェーズ（実装）
   ↓
4. テスト・検証
   ↓
5. ロールアウト
```

---

## フェーズ1: Initializer（仕様策定）

### 目的

機能の要件を明確化し、spec.json/spec.md/plan.json を生成します。

### 手順

#### 1-1. Claude Code で Initializer を起動

1. Claude Code を開きます
2. `templates/initializer_kickoff_prompt.md` の内容を貼り付けます
3. Initializer が起動し、質問を開始します

#### 1-2. インプットの準備

Initializer は以下のインプットを受け付けます：

**優先度1: 正式ドキュメント**
- PRD/BRD（目的・スコープ・非対象・成功指標）
- アーキテクチャ原則、コーディング規約、API スタイルガイド
- セキュリティ基準（データ分類、PII取り扱い、暗号化、監査要件）
- SLO/SLA、パフォーマンス目標、レート制限ポリシー

**優先度2: 技術的な"事実"ソース**
- OpenAPI/GraphQL schema、イベントスキーマ、型定義
- DB スキーマ、マイグレーション、ER 図
- 既存コードベース/README/Feature flag 設定、RBAC ポリシー
- 実データのサンプル（匿名化）、テレメトリ/ログ例

**優先度3: 意思決定の記録/検討材料**
- 議事録、決定事項（ADR）、課題/チケット（Jira等）、バックログ
- デザイン（Figma、ワイヤー）、スタイルガイド
- ユーザー調査、ペルソナ、ジョブストーリー

**優先度4: 補助情報**
- 過去の類似機能の仕様・回顧録（成功/失敗要因）
- 運用 Runbook、アラート設計、容量/コスト制約

#### 1-3. 資料の読み込み（推奨）

資料がある場合は、Initializer に読み込ませます：

```
以下のファイルを読み込んで、要件を抽出してください：

1. docs/inputs/prd.md（PRD）
2. docs/inputs/minutes-20260115.md（議事録）
3. docs/inputs/openapi.yaml（API 仕様）
4. db/schema.sql（DB スキーマ）
5. ops/rbac.yaml（RBAC 設定）

資料の優先度は以下の通りです：
PRD > セキュリティ方針 > アーキテクチャ原則 > OpenAPI/DB スキーマ > 議事録

矛盾がある場合は、優先度の高い資料を優先し、不明点は質問してください。
```

#### 1-4. 質問への回答

Initializer は**最大5問ずつ**質問を提示します（状況に応じて1-5問で調整）。

質問のカテゴリ：
- スコープ/目的/非目的
- ユーザー/ロール
- UI/UX
- API/データモデル
- パフォーマンス/キャッシュ
- セキュリティ/バリデーション
- Feature Flag/ロールアウト
- テレメトリ/監視
- 受入基準
- 依存関係/リスク

詳細は `templates/specification_questions.md` を参照してください。

#### 1-5. 合意形成

全ての不明点が解消されたら、以下のように返答します：

```
CONFIRM: READY TO FREEZE
```

#### 1-6. ファイル生成

Initializer が以下のファイルを生成します：

1. **spec.json**（正）: `pochi-spec-initializer/specs/features/[FEATURE-ID]/spec.json`
2. **spec.md**（spec.jsonから自動生成）: `pochi-spec-initializer/specs/features/[FEATURE-ID]/spec.md`
3. **plan.json**（実装計画）: `pochi-spec-initializer/plans/[FEATURE-ID].json`

---

## フェーズ2: 凍結（Freeze）

### 目的

生成された仕様と計画をバリデーションし、Git で版管理します。

### 手順

#### 2-1. バリデーション

```bash
# spec.json のバリデーション
python Ph1/scripts/validate_spec.py pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/spec.json

# plan.json のバリデーション
python Ph1/scripts/validate_plan.py pochi-spec-initializer/plans/FEAT-EXAMPLE-001.json

# ドリフト検知（オプション）
python Ph1/scripts/check_consistency.py pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001
```

#### 2-2. レビュー

生成されたファイルを手動でレビューします：

- **spec.md**: 人間可読な仕様書として内容を確認
- **plan.json**: タスクの分解と依存関係を確認
- **spec.json**: 機械可読な仕様として整合性を確認

#### 2-3. Git コミット

```bash
# ステージング
git add pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/ pochi-spec-initializer/plans/FEAT-EXAMPLE-001.json

# コミット
git commit -m "feat(FEAT-EXAMPLE-001): freeze spec and plan (v1.0.0)

- spec.json: 機能仕様を凍結
- spec.md: spec.json から自動生成
- plan.json: 実装計画を策定

Co-Authored-By: Claude <noreply@anthropic.com>"

# タグ付け（オプション）
git tag FEAT-EXAMPLE-001-v1.0.0
```

---

## フェーズ3: Coding Agent（実装）

### 目的

凍結された仕様と計画に基づいて、機能を実装します。

### 重要な原則

1. **セッション分離**: Initializer フェーズの Q&A は新セッションに持ち込まない
2. **spec/plan のみを参照**: spec.json と plan.json のみを読み込む（改変禁止）
3. **自動検証**: 各タスク完了後、verification.test_command を自動実行
4. **ガードレール**: 仕様外の実装を検出してエスカレーション

### 手順

#### 3-1. 新しい Claude Code セッションを開始

- **新規セッション**を開始します（Initializer フェーズの会話履歴を持ち込まない）

#### 3-2. Coding Agent を起動

以下のコマンドでCoding Agentを起動します：

**パターンA: FEATURE-ID自動検出（推奨）**
```
「Coding Agentを起動」
```

frozen状態のspec.jsonが1つのみの場合、自動的にそのFEATURE-IDが検出され実装が開始されます。

複数ある場合は候補リストが表示されるので、FEATURE-IDを指定して再実行してください：

**パターンB: FEATURE-ID明示的指定**
```
「Coding Agentを起動して、FEAT-EXAMPLE-001を実装してください」
```

または

```
「FEAT-EXAMPLE-001を実装」
```

Coding Agent が自動的に以下を実施します：

1. **新セッション宣言**
   - セッション分離の宣言
   - ツール制約の宣言

2. **spec.json/plan.json の読み込み**
   - `pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/spec.json` を読み込む
   - `pochi-spec-initializer/plans/FEAT-EXAMPLE-001.json` を読み込む
   - **重要**: これらのファイルは改変禁止

3. **タスク選択**
   - plan.json から実行可能なタスクを選択
   - 優先度順（P0 > P1 > P2）で選択
   - 依存関係（dependsOn）を確認

#### 3-3. タスクの自動実装

Coding Agent が各タスクを自動的に実装します：

1. **Gather Context（コンテキスト収集）**
   - references.requirements に対応する要件を spec.json から読み込む
   - references.acceptance_criteria に対応する受入基準を読み込む
   - references.non_functional に対応する非機能要件を読み込む
   - 必要な既存コードを読み込む

2. **Take Action（実装）**
   - plan.json の artifacts に記載されたファイルを実装
   - spec.json の要件を満たす実装を記述
   - テストコードを実装（該当する場合）

3. **Verify Work（検証）**
   - verification.test_command を自動実行
   - exit_code が 0 であることを確認
   - 仕様との整合性をチェック

4. **Report（報告）**
   - task_result.json を生成
   - test_output.txt を保存
   - 次のタスクへ進む

#### 3-4. エスカレーション処理

以下の場合、Coding Agent は blocked 状態でユーザーにエスカレーションします：

- **仕様と実装の不一致**: spec.json の要件を満たせない
- **テスト失敗**: verification.test_command が失敗する
- **技術的な問題**: ライブラリのインストール失敗、ビルドエラー等
- **plan.json の不備**: artifacts のパスが不正、依存関係が循環等

**エスカレーション時の対応**:

1. **spec_mismatch_report.md を確認**
   - 不一致の詳細を確認
   - 原因を分析
   - 対応案を検討

2. **対応方法を選択**
   - spec.json/plan.json を修正して再実行
   - 実装方針を変更して再試行
   - タスクをスキップ
   - Coding Agent を停止

#### 3-5. 出力ファイル

Coding Agent は以下のファイルを生成します：

- **実装コード**: plan.json の artifacts に記載されたパス
- **task_result.json**: `pochi-spec-initializer/specs/features/[FEATURE-ID]/task_results/[TASK-ID].json`
- **test_output.txt**: `pochi-spec-initializer/specs/features/[FEATURE-ID]/task_results/[TASK-ID]_test_output.txt`
- **spec_mismatch_report.md**: `pochi-spec-initializer/specs/features/[FEATURE-ID]/task_results/[TASK-ID]_mismatch_report.md`（blocked時のみ）

#### 3-6. 受入基準の検証

各タスク完了後、verification.test_command が自動実行され、以下を検証します：

- **requirements**: タスクが参照する要件を満たしているか
- **acceptance_criteria**: タスクが参照する受入基準を満たしているか
- **non_functional**: タスクが参照する非機能要件を満たしているか

詳細は spec.json の `requirements`, `acceptanceCriteria`, `non_functional` セクションを参照してください。

---

## フェーズ4: テスト・検証

### 目的

全ての受入基準が満たされていることを確認します。

### 手順

#### 4-1. ユニットテスト

```bash
# バックエンドテスト
npm test -- server/tests/

# フロントエンドテスト
npm test -- web/src/
```

#### 4-2. E2E テスト

```bash
# E2E テスト実行
npm run test:e2e
```

#### 4-3. 負荷テスト

```bash
# k6 負荷テスト
k6 run tests/load/k6_example.js
```

#### 4-4. アクセシビリティテスト

- WCAG AA 準拠チェック
- キーボード操作テスト
- スクリーンリーダーテスト

---

## フェーズ5: ロールアウト

### 目的

Feature Flag を使用して、段階的にロールアウトします。

### 手順

#### 5-1. ステージング検証

```bash
# ステージング環境にデプロイ
npm run deploy:staging

# E2E テスト実行（ステージング）
npm run test:e2e:staging
```

#### 5-2. 本番環境ロールアウト

**Phase 1: 社内10%**

```bash
# Feature flag を 10% に設定
npm run ff:set -- feature_name_v1 --percentage 10 --audience internal
```

**Phase 2: 50%**

```bash
# Feature flag を 50% に設定
npm run ff:set -- feature_name_v1 --percentage 50
```

**Phase 3: 100%**

```bash
# Feature flag を 100% に設定
npm run ff:set -- feature_name_v1 --percentage 100
```

#### 5-3. 監視

ダッシュボードで以下の指標を監視：

- エラー率 < 1%
- API P95応答時間 < 500ms
- Telemetry イベントの記録状況

#### 5-4. ロールバック（必要に応じて）

閾値超過時は、Feature Flag を OFF にしてロールバック：

```bash
# Kill switch を発動
npm run ff:set -- feature_name_v1 --enabled false
```

---

## 仕様の更新

機能の仕様を更新する場合は、以下の手順に従います：

1. **Initializer で spec.json を更新**
   - 新しい Initializer セッションを開始
   - 既存の spec.json を読み込み、変更箇所を質問で確定
   - 更新された spec.json を生成

2. **spec.md を再生成**
   ```bash
   python Ph1/scripts/render_spec_md.py pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/spec.json
   ```

3. **plan.json を更新**
   - 必要に応じて、タスクを追加・変更

4. **バリデーションと凍結**
   ```bash
   python Ph1/scripts/validate_spec.py pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/spec.json
   python Ph1/scripts/validate_plan.py pochi-spec-initializer/plans/FEAT-EXAMPLE-001.json
   git add pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/ pochi-spec-initializer/plans/FEAT-EXAMPLE-001.json
   git commit -m "feat(FEAT-EXAMPLE-001): update spec (v1.1.0)"
   git tag FEAT-EXAMPLE-001-v1.1.0
   ```

5. **新セッションで再実装**
   - 新しい Coding Agent セッションを開始
   - 更新された spec.md/plan.json を読み込み
   - 変更箇所を実装

---

## まとめ

- **Initializer**: 質問と仕様/計画の生成のみ
- **凍結**: バリデーションと Git 版管理
- **Coding Agent**: spec.md/plan.json のみを参照して実装
- **会話履歴の持ち込み禁止**: 確定した情報だけで実装

このワークフローにより、仕様のドリフトを防ぎ、一貫性のある開発が可能になります。
