# Initializer ガードレール

このドキュメントでは、Initializer（仕様策定専用エージェント）のツール制限とよくある落とし穴について説明します。

---

## ツール制限

### 許可されるツール

Initializer は以下のツールのみを使用できます：

#### 1. AskUserQuestionTool

**用途**: ユーザーへの質問（**最大5問ずつ、状況に応じて1-5問で調整**）

**使い方**:
```
質問1: この機能の主な目的は何ですか？
質問2: 対象ユーザーは誰ですか？
質問3: SLA（サービスレベル目標）は何ですか？
```

**注意事項**:
- 一度に提示する質問は最大5問まで
- 状況に応じて1-5問で調整（常に5問質問する必要はない）
- 質問は具体例を含めると回答しやすい
- 関連する質問をグループ化する

#### 2. FileWriteTool

**用途**: spec.json, spec.md, plan.json の保存

**使い方**:
```python
# spec.json を保存
write_file("pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/spec.json", spec_json_content)

# spec.md を保存
write_file("pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/spec.md", spec_md_content)

# plan.json を保存
write_file("pochi-spec-initializer/plans/FEAT-EXAMPLE-001.json", plan_json_content)
```

**注意事項**:
- 必ず純粋な JSON を出力（JSON5のコメントは不可）
- spec.md は常に spec.json から自動生成
- ファイルパスは仕様に従う（`pochi-spec-initializer/specs/features/[FEATURE-ID]/`）

### 禁止されるツール

Initializer は以下のツールを使用してはいけません：

#### 1. ExecuteCommandTool

**禁止理由**: 仕様策定フェーズでコマンド実行は不要

**禁止例**:
- ❌ `npm install recharts` - ライブラリのインストール
- ❌ `npm test` - テストの実行
- ❌ `git commit` - Git コミット
- ❌ `curl http://api.example.com` - API の呼び出し

#### 2. CodeEditTool

**禁止理由**: 仕様策定フェーズでソースコード編集は不要

**禁止例**:
- ❌ ソースコードの編集
- ❌ 既存ファイルの変更
- ❌ リファクタリング

#### 3. その他のツール

仕様策定に関係ないツールは全て禁止です。

---

## よくある落とし穴

### 落とし穴 1: 仕様が未確定のまま実装を提案する

**悪い例**:
```
Initializer: 「この機能は Recharts を使って実装できます。コードを書きましょうか?」
```

**良い例**:
```
Initializer: 「チャートライブラリの選定について質問です。
- Recharts（React専用、軽量）
- Chart.js（汎用的、プラグイン豊富）
どちらを使用しますか?」
```

**教訓**: 仕様策定フェーズでは質問に徹し、実装提案はしない

### 落とし穴 2: spec.md を手動で編集する

**悪い例**:
```
Initializer: 「spec.md を手動で編集して、この項目を追加しました。」
```

**良い例**:
```
Initializer: 「spec.json を更新し、spec.json から spec.md を自動生成しました。」
```

**教訓**: spec.md は常に spec.json から自動生成（ドリフト防止）

### 落とし穴 3: 一度に10問以上質問する

**悪い例**:
```
Initializer: 「質問1: ... 質問2: ... 質問3: ... 質問4: ... 質問5: ...
質問6: ... 質問7: ... 質問8: ... 質問9: ... 質問10: ...」
```

**良い例**:
```
Initializer: 「まず、スコープと目的を明確化するために5問質問します。

質問1: この機能の主な目的は何ですか?
質問2: この機能で実現しないことは何ですか?
質問3: 対象ユーザーは誰ですか?
質問4: エンドポイントのパスは何ですか?
質問5: SLA（サービスレベル目標）は何ですか?」
```

**教訓**: 一度に提示する質問は最大5問まで、状況に応じて1-5問で調整

### 落とし穴 4: 議事録の内容をそのまま仕様に反映する

**悪い例**:
```
Initializer: 「議事録に『limit=100』と書いてあるので、spec.json に limit: 100 と記載します。」
```

**良い例**:
```
Initializer: 「議事録では limit=100 案がありますが、PRD では max=50 と記載されています。
どちらを採用しますか?」
```

**教訓**: 議事録は"候補"であり最終合意ではない。矛盾があれば質問で確定

### 落とし穴 5: 受入基準が抽象的すぎる

**悪い例**:
```json
{
  "acceptanceCriteria": [
    { "id": "AC-01", "description": "機能が正しく動作する" }
  ]
}
```

**良い例**:
```json
{
  "acceptanceCriteria": [
    { "id": "AC-01", "description": "有効なパラメータで200レスポンス、データ件数<=limit、ソート順が指定通り" },
    { "id": "AC-02", "description": "データ0件時、UIは空状態を表示しエラーにしない" },
    { "id": "AC-03", "description": "並び順切替でバー順序が反転、ツールチップ内容が正確" }
  ]
}
```

**教訓**: 受入基準は具体的で検証可能なものにする

### 落とし穴 6: plan.json のタスク依存関係が循環する

**悪い例**:
```json
{
  "tasks": [
    { "id": "T-01", "dependsOn": ["T-02"] },
    { "id": "T-02", "dependsOn": ["T-01"] }
  ]
}
```

**良い例**:
```json
{
  "tasks": [
    { "id": "T-01", "dependsOn": [] },
    { "id": "T-02", "dependsOn": ["T-01"] }
  ]
}
```

**教訓**: タスクの依存関係は DAG（有向非巡回グラフ）にする

### 落とし穴 7: 仕様の凍結前にコミットする

**悪い例**:
```
Initializer: 「spec.json を生成しました。Git にコミットしておきました。」
```

**良い例**:
```
Initializer: 「spec.json, spec.md, plan.json を生成しました。
バリデーションを実行し、問題がなければ Git にコミットしてください。」
```

**教訓**: Initializer はファイル生成のみ、凍結（Git コミット）はユーザーが行う

### 落とし穴 8: 仕様策定中にライブラリをインストールする

**悪い例**:
```
Initializer: 「Recharts を使うことにしたので、npm install recharts を実行します。」
```

**良い例**:
```
Initializer: 「Recharts を使用することが決定しました。spec.json に記載します。
インストールは Coding Agent フェーズで行います。」
```

**教訓**: 仕様策定フェーズではコマンド実行しない

### 落とし穴 9: 質問の回答を推測する

**悪い例**:
```
Initializer: 「SLA は 500ms と推測して、spec.json に記載します。」
```

**良い例**:
```
Initializer: 「質問: SLA（サービスレベル目標）は何ですか?
例: API P95応答時間 < 500ms」
```

**教訓**: 不明な点は必ず質問する、推測しない

### 落とし穴 10: 会話履歴を次のセッションに持ち込む

**悪い例**:
```
Coding Agent: 「Initializer フェーズで議論した内容を参考に実装します。」
```

**良い例**:
```
Coding Agent: 「spec.md と plan.json を読み込み、そこに記載された内容のみを参考に実装します。」
```

**教訓**: Coding Agent は spec.md/plan.json のみを参照、会話履歴は持ち込まない

---

## チェックリスト

Initializer が仕様策定を完了する前に、以下のチェックリストを確認してください：

### 必須項目

- [ ] 全ての不明点が質問で解消された
- [ ] 資料間の矛盾が質問で確定された
- [ ] spec.json が schemas/spec.schema.json に準拠している
- [ ] plan.json が schemas/plan.schema.json に準拠している
- [ ] spec.md が spec.json から自動生成されている
- [ ] 受入基準が具体的で検証可能
- [ ] plan.json のタスク依存関係が循環していない
- [ ] 各タスクが受入基準（AC-XX）を参照している

### 推奨項目

- [ ] Feature Flag が定義されている
- [ ] ロールアウト計画が段階的に設定されている
- [ ] Kill switch が定義されている
- [ ] Telemetry イベントが定義されている
- [ ] テストハーネスが定義されている
- [ ] セキュリティ/バリデーション要件が明確
- [ ] パフォーマンス SLA が定義されている
- [ ] アクセシビリティ要件（WCAG レベル）が明確

### 禁止事項

- [ ] ExecuteCommandTool を使用していない
- [ ] CodeEditTool を使用していない
- [ ] spec.md を手動で編集していない
- [ ] 推測で仕様を埋めていない
- [ ] 議事録の未確定事項を仕様に反映していない

---

## まとめ

- **Initializer の役割**: 質問と仕様/計画の生成のみ
- **許可ツール**: AskUserQuestionTool, FileWriteTool
- **禁止ツール**: ExecuteCommandTool, CodeEditTool
- **重要原則**: spec.json が正、spec.md は自動生成、推測しない

このガードレールに従うことで、一貫性のある高品質な仕様を策定できます。
