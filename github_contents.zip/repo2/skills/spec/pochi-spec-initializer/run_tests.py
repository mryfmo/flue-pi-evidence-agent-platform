#!/usr/bin/env python3
"""
run_tests.py - SDD Test Policy Phase 1 メインラッパー

Claude Code仕様駆動開発におけるテスト実行を制御するラッパースクリプト。
ポリシーファイル（.pochi/test_policy.yaml）に基づいてpytestの実行を制御します。

使用例:
    # ポリシーを表示
    python scripts/run_tests.py --show-policy --profile strict

    # dry-run（実行せずコマンドを表示）
    python scripts/run_tests.py --dry-run --profile unit-only --level unit

    # ユニットテストを実行
    python scripts/run_tests.py --profile unit-only --level unit
"""

import sys
import os
import argparse
import subprocess
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Any, Optional

# PyYAMLが利用可能かチェック
try:
    import yaml
    HAS_PYYAML = True
except ImportError:
    HAS_PYYAML = False


def simple_yaml_parse(content: str) -> Dict[str, Any]:
    """
    簡易YAMLパーサー（PyYAML未インストール時のフォールバック）
    Phase 1のポリシーファイルで必要な基本的な構造のみサポート。

    サポート内容:
    - key: value 形式
    - リスト（- item）
    - ネストした辞書（インデントベース）
    - コメント（#で始まる行）

    Args:
        content: YAMLファイルの内容

    Returns:
        パースされた辞書
    """
    result = {}
    current_dict = result
    dict_stack = [result]
    current_key = None
    current_list = None
    base_indent = 0

    lines = content.split('\n')

    for line_num, line in enumerate(lines, 1):
        # コメントと空行をスキップ
        stripped = line.lstrip()
        if not stripped or stripped.startswith('#'):
            continue

        # インデントレベルを計算
        indent = len(line) - len(stripped)

        # リスト項目
        if stripped.startswith('- '):
            value = stripped[2:].strip()
            if current_list is not None:
                # 値の型変換
                if value.lower() == 'true':
                    current_list.append(True)
                elif value.lower() == 'false':
                    current_list.append(False)
                elif value.isdigit():
                    current_list.append(int(value))
                else:
                    # クォート除去
                    if (value.startswith('"') and value.endswith('"')) or \
                       (value.startswith("'") and value.endswith("'")):
                        value = value[1:-1]
                    current_list.append(value)
            continue

        # key: value 形式
        if ':' in stripped:
            parts = stripped.split(':', 1)
            key = parts[0].strip()
            value = parts[1].strip() if len(parts) > 1 else ''

            # インデントレベルに応じて辞書スタックを調整
            while len(dict_stack) > 1 and indent <= base_indent:
                dict_stack.pop()
                base_indent -= 2

            current_dict = dict_stack[-1]

            if not value:
                # 空の値 = ネストした辞書またはリストの開始
                current_dict[key] = {}
                dict_stack.append(current_dict[key])
                base_indent = indent
                current_key = key
                current_list = None
            elif value.startswith('[') and value.endswith(']'):
                # インラインリスト [item1, item2]
                items = [item.strip().strip('"').strip("'") for item in value[1:-1].split(',')]
                current_dict[key] = items
                current_list = None
            else:
                # 通常の値
                # 型変換
                if value.lower() == 'true':
                    current_dict[key] = True
                elif value.lower() == 'false':
                    current_dict[key] = False
                elif value.isdigit():
                    current_dict[key] = int(value)
                else:
                    # クォート除去
                    if (value.startswith('"') and value.endswith('"')) or \
                       (value.startswith("'") and value.endswith("'")):
                        value = value[1:-1]
                    current_dict[key] = value

                # リストの開始をチェック（次の行が - で始まる場合）
                if line_num < len(lines):
                    next_line = lines[line_num].lstrip() if line_num < len(lines) else ''
                    if next_line.startswith('- '):
                        current_dict[key] = []
                        current_list = current_dict[key]

    return result


def load_policy(policy_path: str = '.pochi/test_policy.yaml') -> Dict[str, Any]:
    """
    ポリシーファイルを読み込む。

    Args:
        policy_path: ポリシーファイルのパス

    Returns:
        パースされたポリシー辞書

    Raises:
        FileNotFoundError: ポリシーファイルが見つからない
        Exception: パースエラー
    """
    policy_file = Path(policy_path)

    if not policy_file.exists():
        raise FileNotFoundError(
            f"ポリシーファイルが見つかりません: {policy_path}\n"
            f".pochi/test_policy.yaml を作成してください。"
        )

    content = policy_file.read_text(encoding='utf-8')

    if HAS_PYYAML:
        try:
            policy = yaml.safe_load(content)
            return policy
        except yaml.YAMLError as e:
            raise Exception(f"YAMLパースエラー: {e}")
    else:
        # 簡易YAMLパーサーを使用
        try:
            policy = simple_yaml_parse(content)
            return policy
        except Exception as e:
            raise Exception(f"YAMLパースエラー（簡易パーサー）: {e}")


def get_effective_policy(policy: Dict[str, Any], profile_name: str) -> Dict[str, Any]:
    """
    プロファイルを適用した実効ポリシーを取得。

    Args:
        policy: ポリシー辞書
        profile_name: プロファイル名

    Returns:
        実効ポリシー辞書

    Raises:
        ValueError: プロファイルが見つからない
    """
    profiles = policy.get('profiles', {})

    if profile_name not in profiles:
        available = ', '.join(profiles.keys())
        raise ValueError(
            f"プロファイル '{profile_name}' が見つかりません。\n"
            f"利用可能なプロファイル: {available}"
        )

    profile = profiles[profile_name]

    # ベースポリシーとプロファイルをマージ
    effective = {
        'profile_name': profile_name,
        'description': profile.get('description', ''),
        'allow_execution': profile.get('allow_execution', False),
        'allowed_levels': profile.get('allowed_levels', []),
        'pytest_options': profile.get('pytest_options', {}),
        'markers_to_exclude': profile.get('markers_to_exclude', []),
        'test_directory': profile.get('test_directory', 'tests'),
        'command_whitelist': profile.get('command_whitelist', []),
        'test_generation': profile.get('test_generation', {}),  # Phase 1拡張
        'safety': policy.get('safety', {}),
        'pytest_defaults': policy.get('pytest_defaults', {}),
    }

    return effective


def validate_execution(effective_policy: Dict[str, Any], level: str) -> Tuple[bool, str]:
    """
    実行可否を判定。

    Args:
        effective_policy: 実効ポリシー
        level: テストレベル（unit/integration/e2e）

    Returns:
        (許可フラグ, 理由メッセージ)
    """
    if not effective_policy.get('allow_execution', False):
        return False, f"プロファイル '{effective_policy['profile_name']}' はテスト実行を許可していません"

    allowed_levels = effective_policy.get('allowed_levels', [])
    if level and level not in allowed_levels:
        return False, f"レベル '{level}' は許可されていません（許可: {', '.join(allowed_levels)}）"

    return True, "OK"


def build_pytest_command(effective_policy: Dict[str, Any], level: str, extra_args: List[str]) -> List[str]:
    """
    pytestコマンドを構築。

    Args:
        effective_policy: 実効ポリシー
        level: テストレベル
        extra_args: 追加引数

    Returns:
        コマンドリスト
    """
    cmd = ['pytest']

    # テストディレクトリ
    test_dir = effective_policy.get('test_directory', 'tests')
    if level == 'unit':
        test_dir = os.path.join(test_dir, 'unit') if os.path.isdir(os.path.join(test_dir, 'unit')) else test_dir

    # pytest_options
    pytest_options = effective_policy.get('pytest_options', {})

    if pytest_options.get('maxfail'):
        cmd.append(f"--maxfail={pytest_options['maxfail']}")

    if pytest_options.get('verbose'):
        cmd.append('-v')

    if pytest_options.get('warnings') == 'ignore':
        cmd.append('-W ignore')

    if pytest_options.get('capture') == 'no':
        cmd.append('-s')

    # マーカー除外
    markers_to_exclude = effective_policy.get('markers_to_exclude', [])
    if markers_to_exclude:
        marker_expr = ' and '.join([f'not {m}' for m in markers_to_exclude])
        cmd.append(f'-m "{marker_expr}"')

    # レベル指定
    if level:
        cmd.append(f'-m {level}')

    # テストディレクトリ
    cmd.append(test_dir)

    # 追加引数
    if extra_args:
        cmd.extend(extra_args)

    return cmd


def set_safety_env(effective_policy: Dict[str, Any]) -> Dict[str, str]:
    """
    安全用の環境変数を設定。

    Args:
        effective_policy: 実効ポリシー

    Returns:
        設定する環境変数の辞書
    """
    safety = effective_policy.get('safety', {})
    required_env_vars = safety.get('required_env_vars', {})

    env = os.environ.copy()
    env.update(required_env_vars)

    return env


def save_execution_log(
    log_dir: str,
    profile_name: str,
    level: str,
    command: List[str],
    returncode: int,
    stdout: str,
    stderr: str
) -> None:
    """
    実行ログを保存。

    Args:
        log_dir: ログディレクトリ
        profile_name: プロファイル名
        level: テストレベル
        command: 実行コマンド
        returncode: 終了コード
        stdout: 標準出力
        stderr: 標準エラー出力
    """
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = log_path / f'test_execution_{timestamp}.json'

    log_data = {
        'timestamp': timestamp,
        'profile': profile_name,
        'level': level,
        'command': ' '.join(command),
        'returncode': returncode,
        'stdout': stdout,
        'stderr': stderr,
    }

    with open(log_file, 'w', encoding='utf-8') as f:
        json.dump(log_data, f, ensure_ascii=False, indent=2)

    print(f"ℹ️  実行ログを保存しました: {log_file}")


def main():
    """メイン処理"""
    parser = argparse.ArgumentParser(
        description='SDD Test Policy Phase 1 - テスト実行ラッパー',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用例:
  # ポリシーを表示
  %(prog)s --show-policy --profile strict

  # dry-run
  %(prog)s --dry-run --profile unit-only --level unit

  # ユニットテストを実行
  %(prog)s --profile unit-only --level unit
        """
    )

    parser.add_argument(
        '--profile',
        default=None,
        help='使用するプロファイル（デフォルト: ポリシーファイルのdefault_profile）'
    )

    parser.add_argument(
        '--level',
        choices=['unit', 'integration', 'e2e'],
        default=None,
        help='テストレベル'
    )

    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='実行せずコマンドを表示'
    )

    parser.add_argument(
        '--show-policy',
        action='store_true',
        help='実効ポリシーを表示'
    )

    parser.add_argument(
        '--policy-file',
        default='.pochi/test_policy.yaml',
        help='ポリシーファイルのパス（デフォルト: .pochi/test_policy.yaml）'
    )

    parser.add_argument(
        'pytest_args',
        nargs='*',
        help='pytestに渡す追加引数'
    )

    args = parser.parse_args()

    # ポリシーファイルを読み込み
    try:
        policy = load_policy(args.policy_file)
    except FileNotFoundError as e:
        print(f"❌ エラー: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"❌ ポリシーファイルの読み込みに失敗しました: {e}", file=sys.stderr)
        return 1

    # プロファイルを決定（優先順位: CLI引数 > 環境変数 > default_profile）
    profile_name = args.profile or os.environ.get('TEST_POLICY_PROFILE') or policy.get('default_profile', 'strict')

    # 実効ポリシーを取得
    try:
        effective_policy = get_effective_policy(policy, profile_name)
    except ValueError as e:
        print(f"❌ エラー: {e}", file=sys.stderr)
        return 1

    # ポリシー表示モード
    if args.show_policy:
        print(f"📋 実効ポリシー（プロファイル: {profile_name}）\n")
        print(json.dumps(effective_policy, ensure_ascii=False, indent=2))
        return 0

    # 実行可否を判定
    allowed, reason = validate_execution(effective_policy, args.level)

    if not allowed:
        print(f"⏭️  テスト実行をスキップしました: {reason}")
        return 0

    # pytestコマンドを構築
    command = build_pytest_command(effective_policy, args.level, args.pytest_args)

    # dry-runモード
    if args.dry_run:
        print(f"🔍 dry-run モード: 以下のコマンドを実行します\n")
        print(' '.join(command))
        return 0

    # pytestの存在確認
    try:
        subprocess.run(['pytest', '--version'], capture_output=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("❌ エラー: pytest が見つかりません", file=sys.stderr)
        print("   pytest をインストールしてください: pip install pytest", file=sys.stderr)
        return 1

    # 安全環境変数を設定
    env = set_safety_env(effective_policy)

    # pytest実行
    print(f"🧪 テスト実行中（プロファイル: {profile_name}, レベル: {args.level or 'all'}）\n")

    result = subprocess.run(
        command,
        env=env,
        capture_output=False,  # リアルタイム出力
        text=True
    )

    # 実行ログを保存（簡易版）
    safety = effective_policy.get('safety', {})
    log_dir = safety.get('log_directory', '.pochi/test_logs')

    try:
        save_execution_log(
            log_dir=log_dir,
            profile_name=profile_name,
            level=args.level or 'all',
            command=command,
            returncode=result.returncode,
            stdout='',  # リアルタイム出力のためキャプチャなし
            stderr=''
        )
    except Exception as e:
        print(f"⚠️  警告: ログ保存に失敗しました: {e}", file=sys.stderr)

    return result.returncode


if __name__ == '__main__':
    sys.exit(main())
