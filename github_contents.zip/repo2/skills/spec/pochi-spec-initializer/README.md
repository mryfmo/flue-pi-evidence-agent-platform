# pochi-spec-initializer Skill

## 概要

**pochi-spec-initializer** は、仕様駆動開発フレームワークのInitializer（仕様策定専用エージェント）として動作するSkillです。

このSkillを使用すると、質問ベースで以下の成果物を生成できます：

1. **spec.json** - 機械可読な仕様書（Source of Truth）
2. **spec.md** - spec.jsonから自動生成される人間可読ドキュメント
3. **plan.json** - タスク分解・依存関係・受入基準との紐付けを含む実装計画

## 特徴

### 厳格な仕様駆動開発

- **spec.jsonが正（Source of Truth）**: spec.mdは常にspec.jsonから自動生成され、手動編集は禁止
- **会話履歴の持ち込み禁止**: Coding Agentは新セッションでspec.md/plan.jsonのみを参照
- **受入基準との紐付け**: plan.jsonの各タスクはspec.jsonの受入基準IDを参照

### ツール制限

このSkillは以下のツールのみ使用します：

- **許可**: AskUserQuestion（質問）、Write（ファイル書き込み）、Read（資料読み込み）
- **禁止**: Bash（コマンド実行）、Edit（コード編集）

これにより、仕様策定フェーズで実装を行わず、純粋に仕様の合意形成に集中できます。

## 使い方

### 1. Skillの起動

以下のいずれかのフレーズでSkillを起動します：

```
仕様駆動開発を開始
```

または

```
spec.jsonを作成
```

その他のトリガーフレーズ：
- 「Initializerを起動」
- 「仕様策定を開始」
- 「spec-driven-devを開始」
- 「仕様ベース開発を開始」
- "start spec-driven development"
- "launch initializer"
- "create spec.json"

### 2. 資料の提供

Skillが起動したら、以下のいずれかを提供します：

- **議事録**: `pochi-spec-initializer/input-document/`に格納されたファイルパスを指定
- **PRD（Product Requirements Document）**: 製品要求仕様書のパスを指定
- **設計書**: 既存の設計ドキュメントのパスを指定
- **機能概要**: テキストで直接説明

### 3. 質問への回答

Initializerは、仕様を明確化するために質問を提示します（**1回あたり最大5問**）。

質問カテゴリ：
- スコープ/目的/非目的
- ユーザー/ロール
- UI/UX
- API/データモデル
- パフォーマンス/キャッシュ
- セキュリティ/バリデーション
- テレメトリ/監視
- 受入基準
- 依存関係/リスク

**重要**: 質問に対して具体的に回答してください。不明な点があれば、その旨を伝えてください。

### 4. 仕様の凍結

全ての不明点が解消されたら、以下のメッセージを送信します：

```
CONFIRM: READY TO FREEZE
```

これにより、Initializerは以下のファイルを生成します：

- `pochi-spec-initializer/specs/features/[FEATURE-ID]/spec.json`
- `pochi-spec-initializer/specs/features/[FEATURE-ID]/spec.md`
- `pochi-spec-initializer/plans/[FEATURE-ID].json`

（[FEATURE-ID]は、例: FEAT-BARCHART-001）

### 5. バリデーション

生成されたファイルをバリデーションします：

```bash
# spec.jsonのスキーマ検証
python pochi-spec-initializer/scripts/validate_spec.py pochi-spec-initializer/specs/features/FEAT-XXX/spec.json

# plan.jsonの依存関係検証
python pochi-spec-initializer/scripts/validate_plan.py pochi-spec-initializer/plans/FEAT-XXX.json

# ドリフト検知（spec.jsonとspec.mdの一貫性確認）
python pochi-spec-initializer/scripts/check_coverage.py pochi-spec-initializer/specs/features/FEAT-XXX
```

全てのバリデーションがパスしたら、仕様が正しく生成されています。

### 6. 次のステップ: Coding Agent起動

仕様が凍結されたら、**新しいセッション**でCoding Agentを起動します。

**重要**: 会話履歴は持ち込まず、spec.md/plan.jsonのみを読み込ませてください。

新セッションでの開始方法：

```
以下の仕様に基づいて実装を開始してください：

- 仕様書: pochi-spec-initializer/specs/features/FEAT-XXX/spec.md
- 実装計画: pochi-spec-initializer/plans/FEAT-XXX.json

plan.jsonのタスクに従って、順次実装を進めてください。
```

Coding Agentは、plan.jsonのタスク依存関係に従って実装を進めます。

---

## Migration Mode（マイグレーションモード）

**Migration Mode** は、ライブラリアップグレード等の既存コード改修に特化した動作モードです。

### Migration Modeの特徴

- **migration.jsonから情報を自動抽出**: 質問を最小化（最大3問まで）
- **spec.template.migration.json / plan.template.migration.json を使用**: migration専用テンプレート
- **autoFixableタスクを自動識別**: 自動修正可能なタスクと手動対応が必要なタスクを区別
- **ロールバック手順を含む**: 各タスクにロールバックスクリプトを記載

### Migration Modeの起動

以下のいずれかのフレーズでMigration Modeを起動します：

```
migration.jsonから仕様書を生成
```

または

```
マイグレーション仕様を作成
```

その他のトリガーフレーズ：
- 「ライブラリアップグレードの計画を生成」
- 「migration-modeで起動」
- 「migration仕様書を作成」
- 「pochilibアップグレード仕様を作成」

### Migration Modeの使い方

#### 1. migration.json の準備

まず、`migration-converter.py` を使って migration.json を生成します：

```bash
# migration-tasks.json → migration.json に変換
python pochi-spec-initializer/scripts/migration-converter.py \
  migration-tasks.json \
  --output migration.json \
  --validate
```

migration.jsonの構造:
```json
{
  "version": "1.0.0",
  "migrationInfo": {
    "sourceVersion": "1.0.0",
    "targetVersion": "2.0.0",
    "library": "pochilib"
  },
  "summary": {
    "totalTasks": 10,
    "autoFixableTasks": 7,
    "manualTasks": 3,
    "affectedApps": ["app-dashboard", "app-analytics"]
  },
  "tasks": [ ... ]
}
```

#### 2. Skill起動とmigration.jsonの提供

```
migration.jsonから仕様書を生成してください。
ファイルパス: /path/to/migration.json
```

#### 3. 最小限の質問（0-3問）

Migration Modeでは、migration.jsonから自動抽出できる情報については**質問しません**。

質問が必要なケース:
- 段階的ロールアウトの優先順位（複数アプリの場合）
- 特殊な制約事項やリスク（手動対応タスクが多い場合）
- 追加の受入基準（大規模マイグレーションの場合）

多くの場合、質問なしで仕様を生成できます。

#### 4. 仕様の自動生成

migration.jsonに十分な情報がある場合、質問なしで以下が生成されます：

- `pochi-spec-initializer/specs/migrations/[MIGRATION-ID]/spec.json`
- `pochi-spec-initializer/specs/migrations/[MIGRATION-ID]/spec.md`
- `pochi-spec-initializer/plans/[MIGRATION-ID].json`

（[MIGRATION-ID]は、例: MIG-POCHILIB-V2-001）

#### 5. 生成されるspec.jsonの特徴

Migration専用のspec.jsonには以下のフィールドが含まれます：

```json
{
  "isMigration": true,
  "migrationSourceVersion": "pochilib v1.0.0",
  "migrationTargetVersion": "pochilib v2.0.0",
  "migrationTasks": [ ... ],
  "migrationContext": {
    "breakingChanges": [ ... ],
    "deprecatedAPIs": [ ... ],
    "newFeatures": [ ... ]
  },
  "migrationScope": {
    "autoFixable": { ... },
    "manualRequired": { ... }
  },
  "migrationRisks": { ... },
  "migrationRollback": { ... }
}
```

#### 6. 生成されるplan.jsonの特徴

Migration専用のplan.jsonには以下のフィールドが含まれます：

```json
{
  "tasks": [
    {
      "id": "T-MIG-001",
      "name": "影響調査とバックアップ作成",
      "appScope": ["app-dashboard", "app-analytics"],
      "autoFixable": false,
      "migrationTaskRef": "MIG-001",
      "rollbackScript": "tar -xzf backups/pre-migration.tar.gz",
      ...
    }
  ]
}
```

### Migration Modeの使用例

```
ユーザー: migration.jsonから仕様書を生成してください。
       ファイルパス: /home/user/projects/migration.json

Initializer: [migration.jsonを読み込み、情報を自動抽出]

           migration.jsonによると、以下の情報が抽出されました：
           - 対象ライブラリ: pochilib 1.0.0 → 2.0.0
           - 影響するアプリ: 5個のアプリケーション
           - 総タスク数: 12
           - 自動修正可能: 8タスク
           - 手動対応必要: 4タスク

           [質問が必要な場合のみ質問を提示]
           または
           [質問不要の場合]
           migration.jsonから必要な情報をすべて抽出できました。
           質問なしでspec.jsonとplan.jsonを生成します。

           「CONFIRM: READY TO FREEZE」と返答してください。

ユーザー: CONFIRM: READY TO FREEZE

Initializer: [spec.json、spec.md、plan.jsonを生成]
```

### Migration Modeと通常モードの違い

| 項目 | 通常モード | Migration Mode |
|------|----------|----------------|
| インプット | 議事録/PRD/設計書 | migration.json |
| 質問数 | 最大5問 | 最大3問（多くは0問） |
| テンプレート | spec.template.json | spec.template.migration.json |
| 出力ディレクトリ | pochi-spec-initializer/specs/features/ | pochi-spec-initializer/specs/migrations/ |
| 特殊フィールド | なし | appScope, autoFixable, rollbackScript 等 |

### Migration Modeのバリデーション

生成後、migration専用のバリデーションを実行します：

```bash
# migration.jsonのバリデーション
python pochi-spec-initializer/scripts/validate-migration.py migration.json

# spec.jsonのスキーマ検証
python pochi-spec-initializer/scripts/validate_spec.py pochi-spec-initializer/specs/migrations/MIG-XXX/spec.json

# plan.jsonの依存関係検証
python pochi-spec-initializer/scripts/validate_plan.py pochi-spec-initializer/plans/MIG-XXX.json
```

### Migration Mode詳細ドキュメント

Migration Modeの詳細については、以下を参照してください：

- [docs/MIGRATION.md](docs/MIGRATION.md) - Migration機能ガイド
- [templates/migration-questions.md](templates/migration-questions.md) - Migration専用質問テンプレート

---

## 利点

### 既存Skillとの違い

| 項目 | pochi-baseline-builder | pochi-feature-builder | **pochi-spec-initializer** |
|------|------------------------|----------------------|----------------------------|
| インプット | 議事録/イシュー | GitHub イシュー | 議事録/PRD/設計書/任意の資料 |
| 出力形式 | Markdown仕様書 | Markdown仕様書 | spec.json + spec.md + plan.json |
| 正（SoT） | Markdown | Markdown | **spec.json**（spec.mdは自動生成） |
| ツール制限 | 比較的緩い | 比較的緩い | **厳格（質問とファイル出力のみ）** |
| 実装計画 | なし | なし | **plan.json（タスク依存関係管理）** |
| バリデーション | なし | なし | **Pythonスクリプトによる自動検証** |

### なぜspec.jsonが正（Source of Truth）なのか

- **機械可読**: パーサーやバリデーターで自動処理可能
- **一貫性**: spec.mdは常にspec.jsonから生成されるため、ドリフトが発生しない
- **バージョン管理**: JSONの差分管理が容易
- **ツール連携**: CI/CD、テスト生成、API生成などのツールと連携しやすい

### plan.jsonによるタスク管理

- **依存関係の明確化**: どのタスクがどのタスクに依存するかを明示
- **並列実行の最適化**: 依存関係のないタスクは並列実行可能
- **受入基準との紐付け**: 各タスクがどの受入基準を満たすかを明示
- **進捗管理**: タスクの完了状況を追跡可能

## 使用例

### 例1: 新機能の仕様策定

```
ユーザー: 仕様駆動開発を開始

Initializer: 承知しました。機能の概要を教えてください。または、既存資料のファイルパスを提示してください。

ユーザー: pochi-spec-initializer/input-document/barchart_feature.md

Initializer: [資料を読み込み、質問を提示]
1. この機能の主な目的は何ですか？
2. 対象ユーザーは誰ですか？
3. APIエンドポイントのパスは何ですか？
...

ユーザー: [回答]

Initializer: [追加質問]

ユーザー: CONFIRM: READY TO FREEZE

Initializer: [spec.json、spec.md、plan.jsonを生成]
```

### 例2: 既存機能の改修

```
ユーザー: spec.jsonを作成

Initializer: 承知しました。改修する機能の概要を教えてください。

ユーザー: 既存の売上ダッシュボードに、製品カテゴリ別の棒グラフを追加します。

Initializer: [質問を提示]
1. 既存の売上ダッシュボードのファイルパスを教えてください。
2. 棒グラフで表示するメトリクスは何ですか？
...

ユーザー: [回答]

ユーザー: CONFIRM: READY TO FREEZE

Initializer: [spec.json、spec.md、plan.jsonを生成]
```

## 参照ドキュメント

### フレームワークドキュメント

- [docs/README_spec_driven_dev.md](docs/README_spec_driven_dev.md) - 仕様駆動開発フレームワーク全体説明
- [docs/WORKFLOW.md](docs/WORKFLOW.md) - ワークフロー詳細
- [docs/GUARDRAILS.md](docs/GUARDRAILS.md) - ガードレール（落とし穴と対策）
- [docs/TOOLCHAIN.md](docs/TOOLCHAIN.md) - スクリプト使用方法

### スキーマ

- [schemas/spec.schema.json](schemas/spec.schema.json) - spec.jsonスキーマ
- [schemas/plan.schema.json](schemas/plan.schema.json) - plan.jsonスキーマ

### テンプレート

- [templates/spec.template.json](templates/spec.template.json) - spec.jsonテンプレート
- [templates/plan.template.json](templates/plan.template.json) - plan.jsonテンプレート
- [templates/specification_questions.md](templates/specification_questions.md) - 質問チェックリスト

## トラブルシューティング

### Q1: バリデーションでエラーが出た

**A1**: エラーメッセージを確認し、spec.jsonまたはplan.jsonを修正してください。修正後、再度バリデーションを実行してください。

よくあるエラー：
- 必須フィールドの欠落
- 日付形式の誤り（ISO8601形式で記載）
- タスク依存関係の循環

### Q2: spec.mdを手動で編集したい

**A2**: spec.mdは手動編集禁止です。spec.jsonを編集し、以下のコマンドで再生成してください：

```bash
python pochi-spec-initializer/scripts/render_spec_md.py pochi-spec-initializer/specs/features/FEAT-XXX/spec.json
```

### Q3: 質問が多すぎる

**A3**: Initializerは1回あたり最大5問までしか質問しません。すべての質問に答える必要があります。不明な点があれば、その旨を伝えてください。

### Q4: 生成されたplan.jsonのタスクが多すぎる/少なすぎる

**A4**: Initializerを再実行し、質問への回答を調整してください。または、plan.jsonを手動で編集してください（ただし、スキーマに準拠する必要があります）。

### Q5: Coding Agentが会話履歴を参照してしまう

**A5**: 新しいセッションでCoding Agentを起動してください。既存のセッションを継続すると、会話履歴が持ち込まれてしまいます。

## ベストプラクティス

1. **資料を事前に準備**: 議事録、PRD、設計書などを`pochi-spec-initializer/input-document/`に格納しておく
2. **質問に具体的に回答**: 曖昧な回答は避け、具体的な値や例を提供する
3. **バリデーションを必ず実行**: 仕様凍結後、バリデーションスクリプトを実行して一貫性を確認する
4. **新セッションで実装開始**: Coding Agentは必ず新セッションで起動し、spec.md/plan.jsonのみを参照する
5. **ドリフト検知を定期実行**: 実装中にドリフト検知スクリプトを実行し、仕様と実装の乖離を検出する

## まとめ

**pochi-spec-initializer** Skillは、仕様駆動開発のInitializerフェーズを自動化し、以下を実現します：

- ✅ 質問ベースで仕様を明確化
- ✅ spec.json（機械可読）とspec.md（人間可読）を生成
- ✅ plan.json（実装計画）を生成し、タスク依存関係を管理
- ✅ バリデーションスクリプトで一貫性を検証
- ✅ 会話履歴を持ち込まず、新セッションで実装開始

このSkillを活用することで、仕様と実装の乖離を防ぎ、品質の高いソフトウェア開発を実現できます。
