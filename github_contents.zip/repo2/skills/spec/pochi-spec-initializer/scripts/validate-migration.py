#!/usr/bin/env python3
"""
migration.json のバリデーションスクリプト

Usage:
    python scripts/validate-migration.py <migration.json> [--check-apps]

Example:
    python scripts/validate-migration.py migration.json --check-apps
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Set
import argparse


def load_migration_json(input_path: Path) -> Dict[str, Any]:
    """migration.json を読み込む"""
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    with open(input_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def validate_schema(migration: Dict[str, Any]) -> List[str]:
    """スキーマの基本検証"""
    errors = []

    # 必須フィールドのチェック
    required_top_level = ['version', 'migrationInfo', 'tasks', 'summary']
    for field in required_top_level:
        if field not in migration:
            errors.append(f"Missing required top-level field: {field}")

    # migrationInfo の必須フィールド
    if 'migrationInfo' in migration:
        required_migration_info = ['sourceVersion', 'targetVersion']
        for field in required_migration_info:
            if field not in migration['migrationInfo']:
                errors.append(f"Missing required migrationInfo field: {field}")

    # tasks の検証
    if 'tasks' in migration:
        for i, task in enumerate(migration['tasks']):
            required_task_fields = ['id', 'name', 'description', 'autoFixable']
            for field in required_task_fields:
                if field not in task:
                    errors.append(f"Task #{i} ({task.get('id', 'unknown')}): Missing required field '{field}'")

    return errors


def detect_circular_dependencies(tasks: List[Dict[str, Any]]) -> List[str]:
    """循環依存を検出"""
    errors = []

    # タスクIDのセットを作成
    task_ids = {t['id'] for t in tasks}

    # 依存関係グラフを構築
    dependencies = {
        task['id']: set(task.get('dependsOn', []))
        for task in tasks
    }

    # 各タスクについて循環依存をチェック
    def has_cycle(task_id: str, visited: Set[str], path: Set[str]) -> bool:
        """DFSによる循環検出"""
        if task_id in path:
            return True

        if task_id in visited:
            return False

        visited.add(task_id)
        path.add(task_id)

        for dep_id in dependencies.get(task_id, set()):
            if dep_id not in task_ids:
                continue  # 存在しない依存先は別途チェック

            if has_cycle(dep_id, visited, path):
                return True

        path.remove(task_id)
        return False

    # 全タスクについてチェック
    for task in tasks:
        task_id = task['id']
        visited = set()
        path = set()

        if has_cycle(task_id, visited, path):
            errors.append(f"Circular dependency detected involving task: {task_id}")

    return errors


def validate_dependencies(tasks: List[Dict[str, Any]]) -> List[str]:
    """依存関係の検証"""
    errors = []

    task_ids = {t['id'] for t in tasks}

    for task in tasks:
        task_id = task['id']
        depends_on = task.get('dependsOn', [])

        # 自己依存のチェック
        if task_id in depends_on:
            errors.append(f"Task {task_id} has self-dependency")

        # 存在しない依存先のチェック
        for dep_id in depends_on:
            if dep_id not in task_ids:
                errors.append(f"Task {task_id} depends on non-existent task: {dep_id}")

    return errors


def validate_app_scope(migration: Dict[str, Any], check_apps: bool = False) -> List[str]:
    """appScope の検証"""
    errors = []
    warnings = []

    tasks = migration.get('tasks', [])
    app_groups = migration.get('appGroups', {})

    # appScope が空のタスクをチェック
    for task in tasks:
        task_id = task['id']
        app_scope = task.get('appScope', [])

        if not app_scope:
            warnings.append(f"Task {task_id} has empty appScope")

    # appGroups との整合性チェック
    for app, task_ids in app_groups.items():
        for task_id in task_ids:
            # タスクが存在するかチェック
            task = next((t for t in tasks if t['id'] == task_id), None)
            if not task:
                errors.append(f"appGroups[{app}] references non-existent task: {task_id}")
                continue

            # タスクの appScope に app が含まれているかチェック
            if app not in task.get('appScope', []):
                errors.append(f"Task {task_id} in appGroups[{app}] but {app} not in appScope")

    # オプション: 実際のアプリディレクトリの存在確認
    if check_apps:
        for app in app_groups.keys():
            # ここでは簡易チェックのみ実施
            # 実際のアプリパスチェックは環境依存のため警告のみ
            warnings.append(f"App existence check for '{app}' - manual verification recommended")

    return errors, warnings


def validate_auto_fixable(tasks: List[Dict[str, Any]]) -> List[str]:
    """autoFixable の妥当性チェック"""
    warnings = []

    for task in tasks:
        task_id = task['id']
        auto_fixable = task.get('autoFixable', False)
        category = task.get('category', '').lower()
        description = task.get('description', '').lower()

        # 危険なカテゴリで autoFixable が true の場合は警告
        dangerous_categories = ['db', 'database', 'schema', 'breaking']
        for dc in dangerous_categories:
            if dc in category and auto_fixable:
                warnings.append(
                    f"Task {task_id} has dangerous category '{category}' but marked as autoFixable"
                )

        # 危険なキーワードで autoFixable が true の場合は警告
        dangerous_keywords = ['breaking change', 'manual', 'careful']
        for dk in dangerous_keywords:
            if dk in description and auto_fixable:
                warnings.append(
                    f"Task {task_id} contains '{dk}' in description but marked as autoFixable"
                )

    return warnings


def validate_summary_consistency(migration: Dict[str, Any]) -> List[str]:
    """summary セクションの整合性チェック"""
    errors = []

    summary = migration.get('summary', {})
    tasks = migration.get('tasks', [])

    # タスク数の整合性
    if 'totalTasks' in summary:
        actual_total = len(tasks)
        claimed_total = summary['totalTasks']
        if actual_total != claimed_total:
            errors.append(
                f"summary.totalTasks ({claimed_total}) does not match actual task count ({actual_total})"
            )

    # auto-fixable カウントの整合性
    if 'autoFixableTasks' in summary:
        actual_auto = sum(1 for t in tasks if t.get('autoFixable', False))
        claimed_auto = summary['autoFixableTasks']
        if actual_auto != claimed_auto:
            errors.append(
                f"summary.autoFixableTasks ({claimed_auto}) does not match actual count ({actual_auto})"
            )

    # manual カウントの整合性
    if 'manualTasks' in summary:
        actual_manual = sum(1 for t in tasks if not t.get('autoFixable', False))
        claimed_manual = summary['manualTasks']
        if actual_manual != claimed_manual:
            errors.append(
                f"summary.manualTasks ({claimed_manual}) does not match actual count ({actual_manual})"
            )

    return errors


def main():
    parser = argparse.ArgumentParser(
        description='Validate migration.json format and consistency'
    )
    parser.add_argument(
        'input',
        type=Path,
        help='Path to migration.json'
    )
    parser.add_argument(
        '--check-apps',
        action='store_true',
        help='Check if affected apps exist in the filesystem'
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Verbose output'
    )

    args = parser.parse_args()

    print(f"Validating {args.input}...")
    print()

    try:
        # migration.json を読み込み
        migration = load_migration_json(args.input)

        all_errors = []
        all_warnings = []

        # 1. スキーマ検証
        if args.verbose:
            print("Running schema validation...")
        schema_errors = validate_schema(migration)
        all_errors.extend(schema_errors)

        # 2. 依存関係検証
        if args.verbose:
            print("Validating dependencies...")
        tasks = migration.get('tasks', [])
        dep_errors = validate_dependencies(tasks)
        all_errors.extend(dep_errors)

        # 3. 循環依存検出
        if args.verbose:
            print("Detecting circular dependencies...")
        cycle_errors = detect_circular_dependencies(tasks)
        all_errors.extend(cycle_errors)

        # 4. appScope 検証
        if args.verbose:
            print("Validating appScope...")
        app_errors, app_warnings = validate_app_scope(migration, args.check_apps)
        all_errors.extend(app_errors)
        all_warnings.extend(app_warnings)

        # 5. autoFixable 妥当性チェック
        if args.verbose:
            print("Checking autoFixable settings...")
        fixable_warnings = validate_auto_fixable(tasks)
        all_warnings.extend(fixable_warnings)

        # 6. summary 整合性チェック
        if args.verbose:
            print("Validating summary consistency...")
        summary_errors = validate_summary_consistency(migration)
        all_errors.extend(summary_errors)

        # 結果の表示
        print()
        if all_errors:
            print("❌ Validation FAILED")
            print()
            print(f"Found {len(all_errors)} error(s):")
            for error in all_errors:
                print(f"  - {error}")
            print()
        else:
            print("✅ Validation PASSED")
            print()

        if all_warnings:
            print(f"⚠️  Found {len(all_warnings)} warning(s):")
            for warning in all_warnings:
                print(f"  - {warning}")
            print()

        # サマリー表示
        if not all_errors:
            summary = migration.get('summary', {})
            print("Migration Summary:")
            print(f"  Total tasks: {summary.get('totalTasks', 0)}")
            print(f"  Auto-fixable: {summary.get('autoFixableTasks', 0)}")
            print(f"  Manual: {summary.get('manualTasks', 0)}")
            print(f"  Affected apps: {summary.get('appCount', 0)}")
            print()

        # エラーがある場合は終了コード1
        if all_errors:
            sys.exit(1)
        else:
            print("✅ All validation checks passed!")
            sys.exit(0)

    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
