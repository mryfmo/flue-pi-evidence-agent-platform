#!/usr/bin/env python3
"""
spec.json のスキーマ検証と論理チェック

Usage:
    python scripts/validate_spec.py <spec.json>

Example:
    python scripts/validate_spec.py pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

try:
    import jsonschema
except ImportError:
    print("Error: jsonschema is not installed. Please run: pip install jsonschema", file=sys.stderr)
    sys.exit(1)


def validate_schema(spec: Dict[str, Any], schema_path: Path) -> List[str]:
    """スキーマ検証"""
    errors = []

    if not schema_path.exists():
        errors.append(f"Schema file not found: {schema_path}")
        return errors

    with open(schema_path, 'r', encoding='utf-8') as f:
        schema = json.load(f)

    try:
        jsonschema.validate(instance=spec, schema=schema)
    except jsonschema.ValidationError as e:
        errors.append(f"Schema validation error: {e.message}")
        errors.append(f"  Path: {' -> '.join(str(p) for p in e.path)}")
    except jsonschema.SchemaError as e:
        errors.append(f"Invalid schema: {e.message}")

    return errors


def validate_logic(spec: Dict[str, Any]) -> List[str]:
    """論理チェック"""
    errors = []
    warnings = []

    # 1. status のチェック
    status = spec.get('status', '')
    if status not in ['draft', 'frozen', 'deprecated']:
        errors.append(f"Invalid status: {status}")

    # 2. 受入基準のIDが一意かチェック
    ac_ids = [ac['id'] for ac in spec.get('acceptanceCriteria', [])]
    if len(ac_ids) != len(set(ac_ids)):
        duplicates = [ac_id for ac_id in ac_ids if ac_ids.count(ac_id) > 1]
        errors.append(f"Duplicate acceptance criteria IDs: {set(duplicates)}")

    # 3. 受入基準が空でないかチェック
    if not spec.get('acceptanceCriteria'):
        warnings.append("No acceptance criteria defined")

    # 4. API仕様の必須フィールドチェック
    if spec.get('apiSpec'):
        api = spec['apiSpec']
        if not api.get('endpoint'):
            errors.append("API endpoint is missing")
        if not api.get('queryParams'):
            warnings.append("No query parameters defined in API spec")
        if not api.get('responses'):
            errors.append("API responses are missing")

    # 5. 技術スタックのチェック
    if spec.get('techStack'):
        ts = spec['techStack']
        if not ts.get('featureFlag'):
            warnings.append("No feature flag defined in techStack")

    # 6. ロールアウト計画のチェック
    if spec.get('rolloutPlan'):
        rp = spec['rolloutPlan']
        if not rp.get('phases'):
            warnings.append("No rollout phases defined")
        if not rp.get('killSwitch'):
            warnings.append("No kill switch defined in rollout plan")

    # 7. テストハーネスのチェック
    if not spec.get('testHarness'):
        warnings.append("No test harness defined")

    # 8. 変更履歴のチェック
    if not spec.get('changeLog'):
        warnings.append("No change log defined")

    return errors, warnings


def main():
    if len(sys.argv) < 2:
        print("Usage: python scripts/validate_spec.py <spec.json>", file=sys.stderr)
        sys.exit(1)

    input_path = Path(sys.argv[1])

    if not input_path.exists():
        print(f"Error: {input_path} does not exist", file=sys.stderr)
        sys.exit(1)

    # spec.json を読み込み
    with open(input_path, 'r', encoding='utf-8') as f:
        spec = json.load(f)

    # スキーマファイルのパスを解決
    script_dir = Path(__file__).parent
    schema_path = script_dir.parent / 'schemas' / 'spec.schema.json'

    print(f"Validating {input_path}...")
    print(f"Using schema: {schema_path}")
    print()

    # スキーマ検証
    schema_errors = validate_schema(spec, schema_path)

    # 論理チェック
    logic_errors, warnings = validate_logic(spec)

    # 結果の表示
    all_errors = schema_errors + logic_errors

    if all_errors:
        print("❌ Validation FAILED")
        print()
        print("Errors:")
        for error in all_errors:
            print(f"  - {error}")
        print()
    else:
        print("✅ Schema validation PASSED")
        print()

    if warnings:
        print("⚠️  Warnings:")
        for warning in warnings:
            print(f"  - {warning}")
        print()

    # エラーがある場合は終了コード1
    if all_errors:
        sys.exit(1)
    else:
        print("✅ All checks passed!")
        sys.exit(0)


if __name__ == '__main__':
    main()
