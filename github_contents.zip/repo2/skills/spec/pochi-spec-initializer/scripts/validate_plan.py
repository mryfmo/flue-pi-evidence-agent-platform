#!/usr/bin/env python3
"""
plan.json のスキーマ検証と依存関係チェック

Usage:
    python scripts/validate_plan.py <plan.json>

Example:
    python scripts/validate_plan.py pochi-spec-initializer/plans/FEAT-BARCHART-001.json
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Set

try:
    import jsonschema
except ImportError:
    print("Error: jsonschema is not installed. Please run: pip install jsonschema", file=sys.stderr)
    sys.exit(1)


def validate_schema(plan: Dict[str, Any], schema_path: Path) -> List[str]:
    """スキーマ検証"""
    errors = []

    if not schema_path.exists():
        errors.append(f"Schema file not found: {schema_path}")
        return errors

    with open(schema_path, 'r', encoding='utf-8') as f:
        schema = json.load(f)

    try:
        jsonschema.validate(instance=plan, schema=schema)
    except jsonschema.ValidationError as e:
        errors.append(f"Schema validation error: {e.message}")
        errors.append(f"  Path: {' -> '.join(str(p) for p in e.path)}")
    except jsonschema.SchemaError as e:
        errors.append(f"Invalid schema: {e.message}")

    return errors


def detect_circular_dependencies(tasks: List[Dict[str, Any]]) -> List[str]:
    """依存関係の循環を検出"""
    errors = []

    # タスクIDのセットを作成
    task_ids = {task['id'] for task in tasks}

    # 依存関係グラフを作成
    graph = {task['id']: task.get('dependsOn', []) for task in tasks}

    def has_cycle(node: str, visited: Set[str], rec_stack: Set[str]) -> bool:
        """DFSで循環を検出"""
        visited.add(node)
        rec_stack.add(node)

        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                if has_cycle(neighbor, visited, rec_stack):
                    return True
            elif neighbor in rec_stack:
                return True

        rec_stack.remove(node)
        return False

    # 各ノードから循環を検出
    visited = set()
    for task_id in task_ids:
        if task_id not in visited:
            if has_cycle(task_id, visited, set()):
                errors.append(f"Circular dependency detected involving task: {task_id}")

    return errors


def validate_dependencies(tasks: List[Dict[str, Any]]) -> List[str]:
    """依存関係の妥当性チェック"""
    errors = []
    warnings = []

    # タスクIDのセットを作成
    task_ids = {task['id'] for task in tasks}

    for task in tasks:
        task_id = task['id']
        depends_on = task.get('dependsOn', [])

        # 依存先のタスクが存在するかチェック
        for dep_id in depends_on:
            if dep_id not in task_ids:
                errors.append(f"Task {task_id} depends on non-existent task: {dep_id}")

        # 自己依存のチェック
        if task_id in depends_on:
            errors.append(f"Task {task_id} depends on itself")

    return errors, warnings


def validate_logic(plan: Dict[str, Any]) -> List[str]:
    """論理チェック"""
    errors = []
    warnings = []

    # 1. status のチェック
    status = plan.get('status', '')
    if status not in ['planned', 'in_progress', 'done', 'blocked']:
        errors.append(f"Invalid status: {status}")

    # 2. タスクが空でないかチェック
    tasks = plan.get('tasks', [])
    if not tasks:
        errors.append("No tasks defined in plan")
        return errors, warnings

    # 3. タスクIDが一意かチェック
    task_ids = [task['id'] for task in tasks]
    if len(task_ids) != len(set(task_ids)):
        duplicates = [tid for tid in task_ids if task_ids.count(tid) > 1]
        errors.append(f"Duplicate task IDs: {set(duplicates)}")

    # 4. 依存関係のチェック
    dep_errors, dep_warnings = validate_dependencies(tasks)
    errors.extend(dep_errors)
    warnings.extend(dep_warnings)

    # 5. 循環依存のチェック
    circular_errors = detect_circular_dependencies(tasks)
    errors.extend(circular_errors)

    # 6. 受入基準の参照チェック（オプション）
    all_ac_refs = []
    for task in tasks:
        all_ac_refs.extend(task.get('acceptanceCriteria', []))

    if not all_ac_refs:
        warnings.append("No tasks reference acceptance criteria")

    # 7. ロールアウト計画のチェック
    if plan.get('rollout'):
        rollout = plan['rollout']
        if not rollout.get('phases'):
            warnings.append("No rollout phases defined")
    else:
        warnings.append("No rollout plan defined")

    return errors, warnings


def main():
    if len(sys.argv) < 2:
        print("Usage: python scripts/validate_plan.py <plan.json>", file=sys.stderr)
        sys.exit(1)

    input_path = Path(sys.argv[1])

    if not input_path.exists():
        print(f"Error: {input_path} does not exist", file=sys.stderr)
        sys.exit(1)

    # plan.json を読み込み
    with open(input_path, 'r', encoding='utf-8') as f:
        plan = json.load(f)

    # スキーマファイルのパスを解決
    script_dir = Path(__file__).parent
    schema_path = script_dir.parent / 'schemas' / 'plan.schema.json'

    print(f"Validating {input_path}...")
    print(f"Using schema: {schema_path}")
    print()

    # スキーマ検証
    schema_errors = validate_schema(plan, schema_path)

    # 論理チェック
    logic_errors, warnings = validate_logic(plan)

    # 結果の表示
    all_errors = schema_errors + logic_errors

    if all_errors:
        print("❌ Validation FAILED")
        print()
        print("Errors:")
        for error in all_errors:
            print(f"  - {error}")
        print()
    else:
        print("✅ Schema validation PASSED")
        print()

    if warnings:
        print("⚠️  Warnings:")
        for warning in warnings:
            print(f"  - {warning}")
        print()

    # エラーがある場合は終了コード1
    if all_errors:
        sys.exit(1)
    else:
        print("✅ All checks passed!")
        sys.exit(0)


if __name__ == '__main__':
    main()
