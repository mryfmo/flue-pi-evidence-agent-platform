#!/bin/bash
# Phase1 セットアップスクリプト

set -e

echo "========================================="
echo " Phase1: 仕様駆動開発フレームワーク"
echo " セットアップスクリプト"
echo "========================================="
echo ""

# 現在のディレクトリを確認
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PH1_DIR="$(dirname "$SCRIPT_DIR")"
ROOT_DIR="$(dirname "$(dirname "$(dirname "$PH1_DIR")")")"

echo "Phase1 directory: $PH1_DIR"
echo "Root directory: $ROOT_DIR"
echo ""

# 必要なディレクトリを作成
echo "1. Creating directories..."
mkdir -p "$ROOT_DIR/pochi-spec-initializer/specs/features"
mkdir -p "$ROOT_DIR/pochi-spec-initializer/plans"
echo "   ✅ Directories created"
echo ""

# Python 依存関係のチェック
echo "2. Checking Python dependencies..."
if ! python3 -c "import jsonschema" 2>/dev/null; then
    echo "   ⚠️  jsonschema is not installed"
    echo "   Installing jsonschema..."
    pip3 install jsonschema
    echo "   ✅ jsonschema installed"
else
    echo "   ✅ jsonschema is already installed"
fi
echo ""

# スクリプトに実行権限を付与
echo "3. Setting execute permissions on scripts..."
chmod +x "$PH1_DIR/scripts/render_spec_md.py"
chmod +x "$PH1_DIR/scripts/validate_spec.py"
chmod +x "$PH1_DIR/scripts/validate_plan.py"
chmod +x "$PH1_DIR/scripts/check_coverage.py"
echo "   ✅ Execute permissions set"
echo ""

# セットアップ完了
echo "========================================="
echo " ✅ Phase1 setup completed!"
echo "========================================="
echo ""
echo "Next steps:"
echo "1. Read the documentation:"
echo "   - $PH1_DIR/docs/README.md"
echo "   - $PH1_DIR/docs/WORKFLOW.md"
echo "   - $PH1_DIR/docs/GUARDRAILS.md"
echo ""
echo "2. Start an Initializer session:"
echo "   - Open Claude Code"
echo "   - Paste the content of: $PH1_DIR/templates/initializer_kickoff_prompt.md"
echo ""
echo "3. Validate your spec and plan:"
echo "   python3 $PH1_DIR/scripts/validate_spec.py pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/spec.json"
echo "   python3 $PH1_DIR/scripts/validate_plan.py pochi-spec-initializer/plans/FEAT-EXAMPLE-001.json"
echo ""
