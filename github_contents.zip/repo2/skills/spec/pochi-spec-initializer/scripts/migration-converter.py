#!/usr/bin/env python3
"""
migration-tasks.json を migration.json に変換するスクリプト

Usage:
    python scripts/migration-converter.py <migration-tasks.json> [--output <output.json>]

Example:
    python scripts/migration-converter.py migration-tasks.json --output migration.json
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Set
import argparse
from datetime import datetime

try:
    import jsonschema
except ImportError:
    print("Error: jsonschema is not installed. Please run: pip install jsonschema", file=sys.stderr)
    sys.exit(1)


def load_migration_tasks(input_path: Path) -> Dict[str, Any]:
    """migration-tasks.json を読み込む"""
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    with open(input_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def analyze_task_dependencies(tasks: List[Dict[str, Any]]) -> Dict[str, Set[str]]:
    """タスク間の依存関係を解析"""
    dependencies = {}

    for task in tasks:
        task_id = task.get('id', task.get('taskId', ''))
        depends_on = task.get('dependsOn', task.get('dependencies', []))

        if task_id:
            dependencies[task_id] = set(depends_on) if isinstance(depends_on, list) else set()

    return dependencies


def classify_auto_fixable(task: Dict[str, Any]) -> bool:
    """タスクが自動修正可能かどうかを判定"""
    # autoFixable フィールドが明示的に指定されている場合はそれを使用
    if 'autoFixable' in task:
        return task['autoFixable']

    # ヒューリスティックな判定
    category = task.get('category', '').lower()
    description = task.get('description', '').lower()

    # 自動修正が難しいカテゴリ
    manual_categories = [
        'db', 'database', 'schema', 'migration',
        'breaking', 'manual', 'complex'
    ]

    # 自動修正が難しいキーワード
    manual_keywords = [
        'manual', 'complex', 'careful', 'review required',
        'database', 'schema', 'breaking change'
    ]

    # カテゴリチェック
    for mc in manual_categories:
        if mc in category:
            return False

    # キーワードチェック
    for mk in manual_keywords:
        if mk in description:
            return False

    # デフォルトは自動修正可能と判定（保守的に変更する場合は False に）
    return True


def group_by_app(tasks: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    """アプリごとにタスクをグループ化"""
    app_tasks = {}

    for task in tasks:
        apps = task.get('affectedApps', task.get('appScope', []))

        if not apps:
            # アプリが指定されていない場合は 'unknown' グループに
            apps = ['unknown']

        for app in apps:
            if app not in app_tasks:
                app_tasks[app] = []
            app_tasks[app].append(task)

    return app_tasks


def convert_to_migration_json(migration_tasks: Dict[str, Any]) -> Dict[str, Any]:
    """migration-tasks.json を migration.json 形式に変換"""

    # 入力データの構造を確認
    tasks = migration_tasks.get('tasks', [])
    metadata = migration_tasks.get('metadata', {})

    # 依存関係を解析
    dependencies = analyze_task_dependencies(tasks)

    # アプリごとにグループ化
    app_groups = group_by_app(tasks)

    # タスクを処理
    processed_tasks = []
    for task in tasks:
        task_id = task.get('id', task.get('taskId', f"TASK-{len(processed_tasks)+1}"))

        processed_task = {
            'id': task_id,
            'name': task.get('name', task.get('title', '')),
            'description': task.get('description', ''),
            'category': task.get('category', 'unknown'),
            'autoFixable': classify_auto_fixable(task),
            'appScope': task.get('affectedApps', task.get('appScope', [])),
            'priority': task.get('priority', 'P1'),
            'dependsOn': list(dependencies.get(task_id, set())),
            'estimateHours': task.get('estimateHours', task.get('estimate', 2)),
            'migrationTaskRef': task_id,
            'rollbackScript': task.get('rollbackScript', task.get('rollback', ''))
        }

        processed_tasks.append(processed_task)

    # migration.json 構造を生成
    migration_json = {
        'version': '1.0.0',
        'generatedAt': datetime.now().isoformat(),
        'sourceFile': str(metadata.get('sourceFile', 'migration-tasks.json')),
        'migrationInfo': {
            'sourceVersion': metadata.get('sourceVersion', metadata.get('fromVersion', 'unknown')),
            'targetVersion': metadata.get('targetVersion', metadata.get('toVersion', 'unknown')),
            'library': metadata.get('library', 'pochilib'),
            'migrationDate': metadata.get('migrationDate', datetime.now().strftime('%Y-%m-%d'))
        },
        'summary': {
            'totalTasks': len(processed_tasks),
            'autoFixableTasks': sum(1 for t in processed_tasks if t['autoFixable']),
            'manualTasks': sum(1 for t in processed_tasks if not t['autoFixable']),
            'affectedApps': list(app_groups.keys()),
            'appCount': len(app_groups)
        },
        'tasks': processed_tasks,
        'appGroups': {
            app: [t['id'] for t in tasks_list]
            for app, tasks_list in app_groups.items()
        },
        'specTemplateRecommendation': {
            'isMigration': True,
            'migrationSourceVersion': metadata.get('sourceVersion', metadata.get('fromVersion', 'unknown')),
            'migrationTargetVersion': metadata.get('targetVersion', metadata.get('toVersion', 'unknown')),
            'title': f"Migration from {metadata.get('sourceVersion', 'v1')} to {metadata.get('targetVersion', 'v2')}",
            'overview': f"Automated migration plan for upgrading from {metadata.get('sourceVersion', 'v1')} to {metadata.get('targetVersion', 'v2')}"
        }
    }

    return migration_json


def validate_migration_json(migration_json: Dict[str, Any]) -> List[str]:
    """migration.json の基本的なバリデーション"""
    errors = []

    # 必須フィールドのチェック
    required_fields = ['version', 'migrationInfo', 'tasks']
    for field in required_fields:
        if field not in migration_json:
            errors.append(f"Missing required field: {field}")

    # タスクの循環依存チェック
    tasks = migration_json.get('tasks', [])
    task_ids = {t['id'] for t in tasks}

    for task in tasks:
        task_id = task['id']
        depends_on = set(task.get('dependsOn', []))

        # 依存先のタスクが存在するかチェック
        for dep_id in depends_on:
            if dep_id not in task_ids:
                errors.append(f"Task {task_id} depends on non-existent task: {dep_id}")

    # 循環依存の簡易チェック（完全なチェックは validate-migration.py で実施）
    for task in tasks:
        task_id = task['id']
        depends_on = set(task.get('dependsOn', []))

        if task_id in depends_on:
            errors.append(f"Task {task_id} has self-dependency")

    return errors


def main():
    parser = argparse.ArgumentParser(
        description='Convert migration-tasks.json to migration.json format'
    )
    parser.add_argument(
        'input',
        type=Path,
        help='Path to migration-tasks.json'
    )
    parser.add_argument(
        '--output', '-o',
        type=Path,
        default=None,
        help='Path to output migration.json (default: migration.json)'
    )
    parser.add_argument(
        '--validate',
        action='store_true',
        help='Validate the output migration.json'
    )

    args = parser.parse_args()

    # 出力パスのデフォルト設定
    if args.output is None:
        args.output = args.input.parent / 'migration.json'

    print(f"Converting {args.input} to {args.output}...")
    print()

    try:
        # migration-tasks.json を読み込み
        migration_tasks = load_migration_tasks(args.input)

        # migration.json に変換
        migration_json = convert_to_migration_json(migration_tasks)

        # バリデーション
        if args.validate:
            errors = validate_migration_json(migration_json)
            if errors:
                print("❌ Validation FAILED")
                print()
                print("Errors:")
                for error in errors:
                    print(f"  - {error}")
                print()
                sys.exit(1)
            else:
                print("✅ Validation PASSED")
                print()

        # 出力
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(migration_json, f, indent=2, ensure_ascii=False)

        print(f"✅ Successfully converted to {args.output}")
        print()
        print("Summary:")
        print(f"  Total tasks: {migration_json['summary']['totalTasks']}")
        print(f"  Auto-fixable: {migration_json['summary']['autoFixableTasks']}")
        print(f"  Manual: {migration_json['summary']['manualTasks']}")
        print(f"  Affected apps: {len(migration_json['summary']['affectedApps'])}")
        print()

        # 次のステップの提案
        print("Next steps:")
        print(f"  1. Review the generated migration.json")
        print(f"  2. Run: python scripts/validate-migration.py {args.output}")
        print(f"  3. Use pochi-spec-initializer with migration-mode")
        print()

        sys.exit(0)

    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
