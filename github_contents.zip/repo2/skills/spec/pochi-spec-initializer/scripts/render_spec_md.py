#!/usr/bin/env python3
"""
spec.json から spec.md を自動生成するスクリプト

Usage:
    python scripts/render_spec_md.py <spec.json> [output.md]

Example:
    python scripts/render_spec_md.py pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json
    python scripts/render_spec_md.py pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json /tmp/spec.md
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional


def h(s: Optional[str] = None) -> str:
    """文字列のヘルパー関数: None を空文字列に変換し、前後の空白を削除"""
    return (s or "").strip()


def render_spec_md(spec: Dict[str, Any]) -> str:
    """spec.json から spec.md を生成"""
    md = ""

    # ヘッダー
    md += f"# spec.md — {h(spec.get('id'))} {h(spec.get('title'))}\n"
    md += f"version: {h(spec.get('version'))}\n"
    md += f"date: {h(spec.get('date'))}\n"
    md += f"authors: {', '.join(spec.get('authors', []))}\n"
    md += f"approvers: {', '.join(spec.get('approvers', []))}\n"
    md += f"status: {h(spec.get('status'))}\n\n"

    # 1. 概要
    md += f"## 1. 概要\n{h(spec.get('overview'))}\n\n"

    # 2. 背景/目的
    if spec.get('background') or spec.get('purpose') or spec.get('nonGoals'):
        md += "## 2. 背景/目的\n"
        if spec.get('background'):
            md += f"- 背景: {h(spec.get('background'))}\n"
        if spec.get('purpose'):
            md += f"- 目的: {h(spec.get('purpose'))}\n"
        if spec.get('nonGoals'):
            md += f"- 非目的: {'、'.join(spec['nonGoals'])}\n"
        md += "\n"

    # 3. 想定利用シナリオ
    if spec.get('useCases'):
        md += "## 3. 想定利用シナリオ\n"
        for u in spec['useCases']:
            md += f"- {h(u.get('role'))}: {h(u.get('description'))}\n"
        md += "\n"

    # 4. 対象ユーザー
    if spec.get('users'):
        md += "## 4. 対象ユーザー\n"
        users = spec['users']
        if users.get('internalRoles'):
            md += f"- 社内ロール: {', '.join(users['internalRoles'])}（RBACで制御）\n"
        if users.get('externalUsers'):
            md += f"- 外部ユーザー: {h(users['externalUsers'])}\n\n"

    # 5. UI/UX仕様
    if spec.get('uiUx'):
        md += "## 5. UI/UX仕様\n"
        uiux = spec['uiUx']
        if uiux.get('componentName'):
            md += f"- コンポーネント: <{uiux['componentName']} />\n"
        if uiux.get('layout'):
            md += f"  - レイアウト: {'、'.join(uiux['layout'])}\n"
        if uiux.get('interactions'):
            md += "  - インタラクション:\n"
            for k, v in uiux['interactions'].items():
                if isinstance(v, list):
                    value = '/'.join([str(x) for x in v])
                else:
                    value = str(v)
                md += f"    - {k}: {value}\n"
        if uiux.get('responsive'):
            md += "  - レスポンシブ:\n"
            for k, v in uiux['responsive'].items():
                details = '、'.join([f"{kk}={vv}" for kk, vv in v.items()])
                md += f"    - {k}: {details}\n"
        if uiux.get('accessibility'):
            md += "  - アクセシビリティ:\n"
            acc = uiux['accessibility']
            if acc.get('colorPalette'):
                md += f"    - カラーパレット: {acc['colorPalette']}\n"
            if acc.get('ariaRoles'):
                md += f"    - ARIAロール: {', '.join(acc['ariaRoles'])}\n"
            if acc.get('keyboard'):
                kb_details = '、'.join([f"{kk}={vv}" for kk, vv in acc['keyboard'].items()])
                md += f"    - キーボード操作: {kb_details}\n"
        if uiux.get('emptyErrorStates'):
            md += "  - エンプティ/エラー状態:\n"
            ees = uiux['emptyErrorStates']
            if ees.get('empty'):
                md += f"    - データ0件: {ees['empty']}\n"
            if ees.get('error'):
                md += f"    - エラー: {ees['error']}\n"
        md += "\n"

    # 6. API仕様
    if spec.get('apiSpec'):
        md += "## 6. API仕様（Single Source of Truth）\n"
        api = spec['apiSpec']
        md += f"- Endpoint: {api.get('endpoint')}\n"
        md += "- Query params:\n"
        for k, v in api.get('queryParams', {}).items():
            md += f"  - {k}: {json.dumps(v, ensure_ascii=False)}\n"
        if api.get('exampleRequest'):
            md += f"- 例:\n  - {api['exampleRequest']}\n"
        if api.get('responses', {}).get('example'):
            md += "- Response: 200\n```json\n"
            md += json.dumps(api['responses']['example'], indent=2, ensure_ascii=False)
            md += "\n```\n"
        if api.get('responses', {}).get('errors'):
            md += "- Error responses:\n"
            for e in api['responses']['errors']:
                md += f"  - {e['code']} {e['type']}（{e['description']}）\n"
        if api.get('securityValidation'):
            md += "- セキュリティ/バリデーション:\n"
            for s in api['securityValidation']:
                md += f"  - {s}\n"
        md += "\n"

    # 7. データモデル/集計ロジック
    if spec.get('dataModel'):
        md += "## 7. データモデル/集計ロジック\n"
        dm = spec['dataModel']
        if dm.get('sources'):
            md += f"- データソース: {'、'.join(dm['sources'])}\n"
        if dm.get('aggregationExamples'):
            md += "- 集計例：\n"
            for a in dm['aggregationExamples']:
                md += f"  - {a.get('metric')} × {a.get('groupBy')}:\n    ```sql\n{a.get('sql')}\n    ```\n"
        if dm.get('indexes'):
            md += "- インデックス追加（必要に応じて）:\n"
            for i in dm['indexes']:
                md += f"  - {i}\n"
        if dm.get('units'):
            md += "- 単位:\n"
            for k, v in dm['units'].items():
                md += f"  - {k} → {v}\n"
        md += "\n"

    # 8. 権限・露出制御
    if spec.get('permissionsExposure'):
        md += "## 8. 権限・露出制御\n"
        pe = spec['permissionsExposure']
        if pe.get('rbac', {}).get('allowedRoles'):
            md += f"- RBAC: {', '.join(pe['rbac']['allowedRoles'])}のみアクセス可\n"
        if pe.get('featureFlag'):
            md += f"- Feature flag: {pe['featureFlag']} オン時のみUI/APIを露出\n"
        if pe.get('rateLimit'):
            md += f"- Rate limit: {pe['rateLimit']}\n\n"

    # 9. パフォーマンス/キャッシュ
    if spec.get('performanceCache'):
        md += "## 9. パフォーマンス/キャッシュ\n"
        pc = spec['performanceCache']
        if pc.get('sla'):
            sla_details = '、'.join([f"{k}={v}" for k, v in pc['sla'].items()])
            md += f"- SLA: {sla_details}\n"
        if pc.get('serverCache'):
            md += f"- キャッシュ(サーバ): {json.dumps(pc['serverCache'], ensure_ascii=False)}\n"
        if pc.get('clientCache'):
            md += f"- キャッシュ(クライアント): {json.dumps(pc['clientCache'], ensure_ascii=False)}\n"
        if pc.get('pagination') is False:
            md += "- ページネーション: 非対応\n\n"

    # 10. 計測/監視
    if spec.get('telemetryMonitoring'):
        md += "## 10. 計測/監視\n"
        tm = spec['telemetryMonitoring']
        if tm.get('events'):
            md += "- Telemetry（OpenTelemetry）：\n"
            for e in tm['events']:
                fields = ', '.join(e.get('fields', []))
                md += f"  - event: {e.get('name')}（{fields}）\n"
        if tm.get('logging'):
            md += f"- ログ: {tm['logging']}\n"
        if tm.get('monitoringTargets'):
            details = '、'.join([f"{k} {v}" for k, v in tm['monitoringTargets'].items()])
            md += f"- ダッシュボード監視項目: {details}\n"
        md += "\n"

    # 11. アクセシビリティ/I18N
    if spec.get('accessibilityI18n'):
        md += "## 11. アクセシビリティ/I18N\n"
        for k, v in spec['accessibilityI18n'].items():
            md += f"- {k}: {v}\n"
        md += "\n"

    # 12. 受入基準
    if spec.get('acceptanceCriteria'):
        md += "## 12. 受入基準（Acceptance Criteria）\n"
        for ac in spec['acceptanceCriteria']:
            md += f"- {ac['id']}: {ac['description']}\n"
        md += "\n"

    # 13. ロールアウト計画
    if spec.get('rolloutPlan'):
        md += "## 13. ロールアウト計画\n"
        rp = spec['rolloutPlan']
        if rp.get('phases'):
            for p in rp['phases']:
                phase_num = p.get('phase', '')
                details = '、'.join([f"{k}={v}" for k, v in p.items() if k != 'phase'])
                md += f"- Phase {phase_num}: {details}\n"
        if rp.get('killSwitch'):
            md += f"- Kill switch: {rp['killSwitch']}\n\n"

    # 14. リスク/制約
    if spec.get('risksConstraints'):
        md += "## 14. リスク/制約\n"
        rc = spec['risksConstraints']
        if rc.get('risks'):
            for r in rc['risks']:
                md += f"- {r}\n"
        if rc.get('constraints'):
            md += "\n"

    # 15. 非対象（Out of Scope）
    if spec.get('outOfScope'):
        md += "## 15. 非対象（Out of Scope）\n"
        for o in spec['outOfScope']:
            md += f"- {o}\n"
        md += "\n"

    # 16. 依存関係
    if spec.get('dependencies'):
        md += "## 16. 依存関係\n"
        for d in spec['dependencies']:
            md += f"- {d}\n"
        md += "\n"

    # 17. 移行/変更
    if spec.get('migrationChanges'):
        md += "## 17. 移行/変更\n"
        for m in spec['migrationChanges']:
            md += f"- {m}\n"
        md += "\n"

    # 18. テストハーネス
    if spec.get('testHarness'):
        md += "## 18. テストハーネス\n"
        for k, v in spec['testHarness'].items():
            md += f"- {k}: {v}\n"
        md += "\n"

    # 19. 変更履歴
    if spec.get('changeLog'):
        md += "## 19. 変更履歴\n"
        for c in spec['changeLog']:
            notes = c.get('notes', '')
            md += f"- {c['version']} ({c['date']}): {notes}\n"
        md += "\n"

    return md


def main():
    if len(sys.argv) < 2:
        print("Usage: python scripts/render_spec_md.py <spec.json> [output.md]", file=sys.stderr)
        sys.exit(1)

    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2]) if len(sys.argv) > 2 else input_path.with_suffix('.md')

    if not input_path.exists():
        print(f"Error: {input_path} does not exist", file=sys.stderr)
        sys.exit(1)

    # spec.json を読み込み
    with open(input_path, 'r', encoding='utf-8') as f:
        spec = json.load(f)

    # spec.md を生成
    md_content = render_spec_md(spec)

    # spec.md を保存
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(md_content)

    print(f"Wrote {output_path}")


if __name__ == '__main__':
    main()
