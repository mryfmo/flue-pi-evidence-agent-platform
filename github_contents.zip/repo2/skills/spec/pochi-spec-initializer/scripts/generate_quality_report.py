#!/usr/bin/env python3
"""
品質レポート生成スクリプト

spec.json と plan.json のスキーマ検証、依存関係DAG検査、
カバレッジチェックを実施し、quality_report.json を出力する。

Usage:
    python generate_quality_report.py FEAT-EXAMPLE-001 [--app-path /home/user/my-app]
"""

import json
import sys
import argparse
import subprocess
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Set, Tuple, Optional
from collections import defaultdict


def load_json(file_path: Path) -> Dict:
    """JSONファイルを読み込む"""
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def validate_schema(feature_id: str, app_path: Optional[Path] = None) -> List[Dict]:
    """
    スキーマ検証を実行する

    Returns:
        issues リスト
    """
    issues = []
    scripts_dir = Path(__file__).parent

    # spec.json のスキーマ検証
    spec_validator = scripts_dir / "validate_spec.py"
    if app_path:
        spec_path = app_path / "spec" / "features" / feature_id / "spec.json"
    else:
        spec_path = scripts_dir.parent / "specs" / "features" / feature_id / "spec.json"

    if spec_validator.exists() and spec_path.exists():
        try:
            result = subprocess.run(
                [sys.executable, str(spec_validator), str(spec_path)],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode != 0:
                issues.append({
                    "severity": "error",
                    "category": "schema_validation",
                    "message": f"spec.json schema validation failed: {result.stderr}"
                })
        except subprocess.TimeoutExpired:
            issues.append({
                "severity": "error",
                "category": "schema_validation",
                "message": "spec.json schema validation timed out"
            })
        except Exception as e:
            issues.append({
                "severity": "warning",
                "category": "schema_validation",
                "message": f"Could not validate spec.json: {str(e)}"
            })

    # plan.json のスキーマ検証
    plan_validator = scripts_dir / "validate_plan.py"
    if app_path:
        plan_path = app_path / "spec" / "plans" / f"{feature_id}.json"
    else:
        plan_path = scripts_dir.parent / "plans" / f"{feature_id}.json"

    if plan_validator.exists() and plan_path.exists():
        try:
            result = subprocess.run(
                [sys.executable, str(plan_validator), str(plan_path)],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode != 0:
                issues.append({
                    "severity": "error",
                    "category": "schema_validation",
                    "message": f"plan.json schema validation failed: {result.stderr}"
                })
        except subprocess.TimeoutExpired:
            issues.append({
                "severity": "error",
                "category": "schema_validation",
                "message": "plan.json schema validation timed out"
            })
        except Exception as e:
            issues.append({
                "severity": "warning",
                "category": "schema_validation",
                "message": f"Could not validate plan.json: {str(e)}"
            })

    return issues


def check_dag_dependencies(plan: Dict) -> List[Dict]:
    """
    タスクの依存関係がDAG（有向非巡回グラフ）を形成しているかチェック

    Returns:
        issues リスト
    """
    issues = []
    tasks = plan.get("tasks", [])
    task_ids = {task["id"] for task in tasks}

    # 依存関係グラフを構築
    dependencies = defaultdict(list)
    for task in tasks:
        task_id = task["id"]
        for dep_id in task.get("dependsOn", []):
            dependencies[task_id].append(dep_id)

            # 存在しないタスクへの依存
            if dep_id not in task_ids:
                issues.append({
                    "severity": "error",
                    "category": "dependencies",
                    "message": f"Task {task_id} depends on non-existent task {dep_id}"
                })

    # 循環依存の検出（DFS）
    def has_cycle(node: str, visited: Set[str], rec_stack: Set[str]) -> bool:
        visited.add(node)
        rec_stack.add(node)

        for neighbor in dependencies.get(node, []):
            if neighbor not in visited:
                if has_cycle(neighbor, visited, rec_stack):
                    return True
            elif neighbor in rec_stack:
                return True

        rec_stack.remove(node)
        return False

    visited = set()
    for task_id in task_ids:
        if task_id not in visited:
            if has_cycle(task_id, visited, set()):
                issues.append({
                    "severity": "error",
                    "category": "dependencies",
                    "message": f"Circular dependency detected involving task {task_id}"
                })
                break

    return issues


def evaluate_verification_quality(plan: Dict) -> Tuple[int, List[Dict]]:
    """
    verification記述の質を評価する

    Returns:
        (score, issues)
        score: 0-100
    """
    issues = []
    tasks = plan.get("tasks", [])

    if not tasks:
        return 0, issues

    total_tasks = len(tasks)
    good_verifications = 0

    for task in tasks:
        task_id = task.get("id", "")
        verification = task.get("verification", {})

        test_command = verification.get("test_command", "")
        success_criteria = verification.get("success_criteria", "")
        verification_type = verification.get("verification_type", "")

        # 実行可能なコマンドかチェック（簡易）
        has_command = bool(test_command and len(test_command) > 5)
        has_criteria = bool(success_criteria and len(success_criteria) > 10)
        has_type = verification_type in ["unit", "integration", "e2e", "load"]

        if has_command and has_criteria and has_type:
            good_verifications += 1
        else:
            if not has_command:
                issues.append({
                    "severity": "warning",
                    "category": "verification_quality",
                    "message": f"Task {task_id} has insufficient test_command"
                })
            if not has_criteria:
                issues.append({
                    "severity": "warning",
                    "category": "verification_quality",
                    "message": f"Task {task_id} has insufficient success_criteria"
                })
            if not has_type:
                issues.append({
                    "severity": "error",
                    "category": "verification_quality",
                    "message": f"Task {task_id} has invalid verification_type"
                })

    score = int((good_verifications / total_tasks) * 100) if total_tasks > 0 else 0
    return score, issues


def run_coverage_check(feature_id: str, app_path: Optional[Path] = None) -> Tuple[Dict, List[Dict]]:
    """
    カバレッジチェックを実行する

    Returns:
        (coverage_summary, issues)
    """
    issues = []
    scripts_dir = Path(__file__).parent
    coverage_script = scripts_dir / "check_coverage.py"

    cmd = [sys.executable, str(coverage_script), feature_id]
    if app_path:
        cmd += ["--app-path", str(app_path)]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60
        )

        # coverage_summary.json を読み込む
        if app_path:
            coverage_path = app_path / "spec" / "features" / feature_id / "coverage_summary.json"
        else:
            coverage_path = scripts_dir.parent / "specs" / "features" / feature_id / "coverage_summary.json"

        if coverage_path.exists():
            coverage_summary = load_json(coverage_path)

            # カバレッジ不足の警告
            if coverage_summary.get("gate_status") == "fail":
                gate_details = coverage_summary.get("gate_details", {})
                if not gate_details.get("p0_p1_coverage_100"):
                    issues.append({
                        "severity": "error",
                        "category": "coverage",
                        "message": "P0/P1 requirements are not 100% covered"
                    })
                if not gate_details.get("ac_coverage_100"):
                    issues.append({
                        "severity": "error",
                        "category": "coverage",
                        "message": "Acceptance criteria are not 100% covered"
                    })
                if not gate_details.get("nf_has_verification"):
                    issues.append({
                        "severity": "warning",
                        "category": "coverage",
                        "message": "Non-functional requirements have no verification"
                    })
                if not gate_details.get("no_orphans"):
                    orphans = coverage_summary.get("orphan_tasks", [])
                    issues.append({
                        "severity": "warning",
                        "category": "coverage",
                        "message": f"Orphan tasks detected: {', '.join(orphans)}"
                    })

            return coverage_summary, issues

        else:
            issues.append({
                "severity": "error",
                "category": "coverage",
                "message": "Coverage summary not generated"
            })
            return {}, issues

    except subprocess.TimeoutExpired:
        issues.append({
            "severity": "error",
            "category": "coverage",
            "message": "Coverage check timed out"
        })
        return {}, issues
    except Exception as e:
        issues.append({
            "severity": "error",
            "category": "coverage",
            "message": f"Coverage check failed: {str(e)}"
        })
        return {}, issues


def calculate_scores(coverage_summary: Dict, verification_score: int) -> Dict:
    """
    スコアを計算する

    Returns:
        scores dict
    """
    # 要件カバレッジスコア (0-100)
    req_coverage_ratio = coverage_summary.get("coverage", {}).get("requirement_coverage_ratio", 0)
    ac_coverage_ratio = coverage_summary.get("coverage", {}).get("ac_coverage_ratio", 0)
    requirement_coverage_score = int((req_coverage_ratio + ac_coverage_ratio) / 2 * 100)

    # テスト検証可能性スコア
    test_verifiability_score = verification_score

    # 総合品質スコア
    overall_quality_score = int((requirement_coverage_score + test_verifiability_score) / 2)

    return {
        "requirement_coverage": requirement_coverage_score,
        "test_verifiability": test_verifiability_score,
        "overall_quality": overall_quality_score
    }


def generate_recommendations(issues: List[Dict], coverage_summary: Dict) -> List[str]:
    """
    改善推奨事項を生成する
    """
    recommendations = []

    # エラーベースの推奨
    error_count = sum(1 for issue in issues if issue["severity"] == "error")
    if error_count > 0:
        recommendations.append(f"Fix {error_count} critical errors before proceeding")

    # カバレッジベースの推奨
    uncovered = coverage_summary.get("uncovered", {})
    if uncovered.get("requirements"):
        recommendations.append(
            f"Add tasks to cover uncovered requirements: {', '.join(uncovered['requirements'][:3])}"
        )
    if uncovered.get("acceptance_criteria"):
        recommendations.append(
            f"Add tasks to cover uncovered acceptance criteria: {', '.join(uncovered['acceptance_criteria'][:3])}"
        )

    # orphanタスクの推奨
    orphan_tasks = coverage_summary.get("orphan_tasks", [])
    if orphan_tasks:
        recommendations.append(
            f"Link orphan tasks to requirements or remove them: {', '.join(orphan_tasks[:3])}"
        )

    # 検証品質の推奨
    verification_issues = [i for i in issues if i["category"] == "verification_quality"]
    if len(verification_issues) > 5:
        recommendations.append(
            "Improve verification quality by adding detailed test commands and success criteria"
        )

    return recommendations


def generate_quality_report(feature_id: str, app_path: Optional[Path] = None) -> Dict:
    """
    quality_report.json を生成する
    """
    issues = []

    # スキーマ検証
    schema_issues = validate_schema(feature_id, app_path)
    issues.extend(schema_issues)

    # plan.json 読み込み
    if app_path:
        plan_path = app_path / "spec" / "plans" / f"{feature_id}.json"
    else:
        plan_path = Path(__file__).parent.parent / "plans" / f"{feature_id}.json"
    plan = load_json(plan_path)

    # 依存関係チェック
    dag_issues = check_dag_dependencies(plan)
    issues.extend(dag_issues)

    # 検証品質評価
    verification_score, verification_issues = evaluate_verification_quality(plan)
    issues.extend(verification_issues)

    # カバレッジチェック
    coverage_summary, coverage_issues = run_coverage_check(feature_id, app_path)
    issues.extend(coverage_issues)

    # スコア計算
    scores = calculate_scores(coverage_summary, verification_score)

    # 推奨事項生成
    recommendations = generate_recommendations(issues, coverage_summary)

    # レポート生成
    report = {
        "feature_id": feature_id,
        "version": plan.get("version", "unknown"),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "scores": scores,
        "issues": issues,
        "recommendations": recommendations
    }

    return report


def save_quality_report(feature_id: str, report: Dict, app_path: Optional[Path] = None):
    """quality_report.json を保存する"""
    if app_path:
        output_dir = app_path / "spec" / "features" / feature_id
    else:
        output_dir = Path(__file__).parent.parent / "specs" / "features" / feature_id
    output_dir.mkdir(parents=True, exist_ok=True)

    output_path = output_dir / "quality_report.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"Quality report saved to: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="品質レポート生成スクリプト")
    parser.add_argument("feature_id", help="FEATURE-ID (例: FEAT-SALES-DASHBOARD-001)")
    parser.add_argument(
        "--app-path",
        help="実装対象アプリのリポジトリルートパス (例: /home/user/my-app)",
        default=None
    )
    args = parser.parse_args()

    feature_id = args.feature_id
    app_path = Path(args.app_path) if args.app_path else None

    try:
        report = generate_quality_report(feature_id, app_path)
        save_quality_report(feature_id, report, app_path)

        # 結果表示
        print("\n=== Quality Report ===")
        print(f"Feature ID: {report['feature_id']}")
        print(f"Version: {report['version']}")
        print(f"\nScores:")
        print(f"  Requirement Coverage: {report['scores']['requirement_coverage']}/100")
        print(f"  Test Verifiability: {report['scores']['test_verifiability']}/100")
        print(f"  Overall Quality: {report['scores']['overall_quality']}/100")

        # 重大度別の問題数
        errors = [i for i in report['issues'] if i['severity'] == 'error']
        warnings = [i for i in report['issues'] if i['severity'] == 'warning']

        print(f"\nIssues:")
        print(f"  Errors: {len(errors)}")
        print(f"  Warnings: {len(warnings)}")

        if errors:
            print(f"\nCritical Errors:")
            for error in errors[:5]:  # 最初の5件のみ表示
                print(f"  - [{error['category']}] {error['message']}")

        if report['recommendations']:
            print(f"\nRecommendations:")
            for rec in report['recommendations'][:5]:  # 最初の5件のみ表示
                print(f"  - {rec}")

        # エラーがある場合は終了コード1
        if errors:
            sys.exit(1)

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
