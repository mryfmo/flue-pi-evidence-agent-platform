#!/usr/bin/env python3
"""
自動網羅性チェックスクリプト

spec.json の要件・受入基準・非機能要件が plan.json のタスクで
どの程度カバーされているかを分析し、coverage_summary.json を出力する。

Usage:
    python check_coverage.py FEAT-EXAMPLE-001 [--app-path /home/user/my-app]
"""

import json
import sys
import argparse
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Set, Tuple, Optional


def load_spec(feature_id: str, app_path: Optional[Path] = None) -> Dict:
    """spec.json を読み込む"""
    if app_path:
        spec_path = app_path / "spec" / "features" / feature_id / "spec.json"
    else:
        spec_path = Path(__file__).parent.parent / "specs" / "features" / feature_id / "spec.json"
    if not spec_path.exists():
        raise FileNotFoundError(f"Spec file not found: {spec_path}")
    with open(spec_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_plan(feature_id: str, app_path: Optional[Path] = None) -> Dict:
    """plan.json を読み込む"""
    if app_path:
        plan_path = app_path / "spec" / "plans" / f"{feature_id}.json"
    else:
        plan_path = Path(__file__).parent.parent / "plans" / f"{feature_id}.json"
    if not plan_path.exists():
        raise FileNotFoundError(f"Plan file not found: {plan_path}")
    with open(plan_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def extract_spec_ids(spec: Dict) -> Tuple[Set[str], Set[str], Set[str], Dict[str, str]]:
    """
    spec.json から要件ID、受入基準ID、非機能要件IDを抽出する

    Returns:
        (requirement_ids, ac_ids, nf_ids, priority_map)
        priority_map は {id: priority} の形式
    """
    requirement_ids = set()
    ac_ids = set()
    nf_ids = set()
    priority_map = {}

    # 要件
    for req in spec.get("requirements", []):
        req_id = req.get("id")
        if req_id:
            requirement_ids.add(req_id)
            priority_map[req_id] = req.get("priority", "P2")

    # 受入基準
    for ac in spec.get("acceptanceCriteria", []):
        ac_id = ac.get("id")
        if ac_id:
            ac_ids.add(ac_id)
            # ACは全てP0として扱う
            priority_map[ac_id] = "P0"

    # 非機能要件
    for nf in spec.get("non_functional", []):
        nf_id = nf.get("id")
        if nf_id:
            nf_ids.add(nf_id)
            priority_map[nf_id] = nf.get("priority", "P2")

    return requirement_ids, ac_ids, nf_ids, priority_map


def extract_plan_references(plan: Dict) -> Tuple[Set[str], Set[str], Set[str], Set[str]]:
    """
    plan.json からタスクが参照している要件ID等を抽出する

    Returns:
        (covered_requirements, covered_acs, covered_nfs, all_task_ids)
    """
    covered_requirements = set()
    covered_acs = set()
    covered_nfs = set()
    all_task_ids = set()

    for task in plan.get("tasks", []):
        task_id = task.get("id", "")
        all_task_ids.add(task_id)

        references = task.get("references", {})

        # 要件
        for req_id in references.get("requirements", []):
            covered_requirements.add(req_id)

        # 受入基準
        for ac_id in references.get("acceptance_criteria", []):
            covered_acs.add(ac_id)

        # 非機能要件
        for nf_id in references.get("non_functional", []):
            covered_nfs.add(nf_id)

    return covered_requirements, covered_acs, covered_nfs, all_task_ids


def find_orphan_tasks(plan: Dict, spec: Dict) -> List[str]:
    """
    どの要件・受入基準・非機能要件も参照していないタスクを検出する
    """
    orphans = []

    for task in plan.get("tasks", []):
        task_id = task.get("id", "")
        references = task.get("references", {})

        # 全ての参照配列が空の場合、orphanとする
        has_any_reference = (
            len(references.get("requirements", [])) > 0 or
            len(references.get("acceptance_criteria", [])) > 0 or
            len(references.get("non_functional", [])) > 0
        )

        if not has_any_reference:
            orphans.append(task_id)

    return orphans


def calculate_coverage(
    spec_ids: Set[str],
    covered_ids: Set[str],
    priority_map: Dict[str, str],
    priority_filter: Set[str] = None
) -> Tuple[float, str]:
    """
    カバレッジ比率と件数を計算する

    Args:
        spec_ids: spec内の全ID
        covered_ids: planでカバーされたID
        priority_map: ID -> priority のマップ
        priority_filter: 指定された優先度のみを対象とする (e.g., {"P0", "P1"})

    Returns:
        (coverage_ratio, coverage_count_str)
    """
    if priority_filter:
        filtered_spec_ids = {id for id in spec_ids if priority_map.get(id) in priority_filter}
    else:
        filtered_spec_ids = spec_ids

    if not filtered_spec_ids:
        return 1.0, "0/0"

    covered_count = len(covered_ids & filtered_spec_ids)
    total_count = len(filtered_spec_ids)
    ratio = covered_count / total_count if total_count > 0 else 0.0

    return ratio, f"{covered_count}/{total_count}"


def check_gate_conditions(
    req_coverage_p0_p1: Tuple[float, str],
    ac_coverage: Tuple[float, str],
    nf_ids: Set[str],
    covered_nfs: Set[str],
    orphans: List[str]
) -> Tuple[str, Dict]:
    """
    ゲート条件をチェックする

    Must要件:
    - P0/P1要件は100%カバー
    - 全受入基準は100%カバー
    - 定義された非機能要件は最低1タスクで検証
    - orphanタスクがないこと

    Returns:
        (gate_status, gate_details)
    """
    p0_p1_coverage_100 = req_coverage_p0_p1[0] >= 1.0
    ac_coverage_100 = ac_coverage[0] >= 1.0
    nf_has_verification = len(nf_ids) == 0 or len(covered_nfs) > 0
    no_orphans = len(orphans) == 0

    all_pass = p0_p1_coverage_100 and ac_coverage_100 and nf_has_verification and no_orphans

    gate_details = {
        "p0_p1_coverage_100": p0_p1_coverage_100,
        "ac_coverage_100": ac_coverage_100,
        "nf_has_verification": nf_has_verification,
        "no_orphans": no_orphans
    }

    gate_status = "pass" if all_pass else "fail"

    return gate_status, gate_details


def generate_coverage_summary(feature_id: str, app_path: Optional[Path] = None) -> Dict:
    """
    coverage_summary.json を生成する
    """
    spec = load_spec(feature_id, app_path)
    plan = load_plan(feature_id, app_path)

    # spec から ID 抽出
    requirement_ids, ac_ids, nf_ids, priority_map = extract_spec_ids(spec)

    # plan から参照 ID 抽出
    covered_requirements, covered_acs, covered_nfs, all_task_ids = extract_plan_references(plan)

    # カバレッジ計算
    # 要件: P0/P1のみを対象
    req_coverage_p0_p1 = calculate_coverage(
        requirement_ids, covered_requirements, priority_map, {"P0", "P1"}
    )

    # 受入基準: 全て対象
    ac_coverage = calculate_coverage(ac_ids, covered_acs, priority_map)

    # 非機能要件: 定義されたものの中でカバーされた比率
    nf_coverage = calculate_coverage(nf_ids, covered_nfs, priority_map)

    # 未カバー項目
    uncovered_requirements = sorted(requirement_ids - covered_requirements)
    uncovered_acs = sorted(ac_ids - covered_acs)
    uncovered_nfs = sorted(nf_ids - covered_nfs)

    # orphanタスク
    orphans = find_orphan_tasks(plan, spec)

    # ゲート条件チェック
    gate_status, gate_details = check_gate_conditions(
        req_coverage_p0_p1, ac_coverage, nf_ids, covered_nfs, orphans
    )

    # サマリ生成
    summary = {
        "feature_id": feature_id,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "coverage": {
            "requirement_coverage_ratio": round(req_coverage_p0_p1[0], 3),
            "requirement_coverage_count": f"{req_coverage_p0_p1[1]} (P0/P1)",
            "ac_coverage_ratio": round(ac_coverage[0], 3),
            "ac_coverage_count": ac_coverage[1],
            "nf_coverage_ratio": round(nf_coverage[0], 3),
            "nf_coverage_count": nf_coverage[1]
        },
        "uncovered": {
            "requirements": uncovered_requirements,
            "acceptance_criteria": uncovered_acs,
            "non_functional": uncovered_nfs
        },
        "orphan_tasks": sorted(orphans),
        "gate_status": gate_status,
        "gate_details": gate_details
    }

    return summary


def save_coverage_summary(feature_id: str, summary: Dict, app_path: Optional[Path] = None):
    """coverage_summary.json を保存する"""
    if app_path:
        output_dir = app_path / "spec" / "features" / feature_id
    else:
        output_dir = Path(__file__).parent.parent / "specs" / "features" / feature_id
    output_dir.mkdir(parents=True, exist_ok=True)

    output_path = output_dir / "coverage_summary.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print(f"Coverage summary saved to: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="自動網羅性チェックスクリプト")
    parser.add_argument("feature_id", help="FEATURE-ID (例: FEAT-SALES-DASHBOARD-001)")
    parser.add_argument(
        "--app-path",
        help="実装対象アプリのリポジトリルートパス (例: /home/user/my-app)",
        default=None
    )
    args = parser.parse_args()

    feature_id = args.feature_id
    app_path = Path(args.app_path) if args.app_path else None

    try:
        summary = generate_coverage_summary(feature_id, app_path)
        save_coverage_summary(feature_id, summary, app_path)

        # 結果表示
        print("\n=== Coverage Summary ===")
        print(f"Feature ID: {summary['feature_id']}")
        print(f"Gate Status: {summary['gate_status'].upper()}")
        print(f"\nCoverage:")
        print(f"  Requirements (P0/P1): {summary['coverage']['requirement_coverage_count']} ({summary['coverage']['requirement_coverage_ratio']*100:.1f}%)")
        print(f"  Acceptance Criteria: {summary['coverage']['ac_coverage_count']} ({summary['coverage']['ac_coverage_ratio']*100:.1f}%)")
        print(f"  Non-functional: {summary['coverage']['nf_coverage_count']} ({summary['coverage']['nf_coverage_ratio']*100:.1f}%)")

        if summary['uncovered']['requirements']:
            print(f"\nUncovered Requirements: {', '.join(summary['uncovered']['requirements'])}")
        if summary['uncovered']['acceptance_criteria']:
            print(f"Uncovered Acceptance Criteria: {', '.join(summary['uncovered']['acceptance_criteria'])}")
        if summary['uncovered']['non_functional']:
            print(f"Uncovered Non-functional: {', '.join(summary['uncovered']['non_functional'])}")
        if summary['orphan_tasks']:
            print(f"\nOrphan Tasks: {', '.join(summary['orphan_tasks'])}")

        # ゲート条件の詳細
        print(f"\nGate Conditions:")
        for condition, passed in summary['gate_details'].items():
            status = "✓" if passed else "✗"
            print(f"  {status} {condition}")

        if summary['gate_status'] == 'fail':
            sys.exit(1)

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
