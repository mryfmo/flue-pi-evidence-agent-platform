#!/bin/bash
# noop.sh - テスト実行スキップ用スクリプト
# SDD Test Policy Phase 1
#
# このスクリプトは、テスト実行が不要な場合に使用します。
# plan.jsonのverification.test_commandで以下のように指定します:
#   "test_command": "scripts/noop.sh"

echo "ℹ️  テスト実行をスキップしました（noop）"
echo "   このタスクにはテスト検証が不要です。"
exit 0
