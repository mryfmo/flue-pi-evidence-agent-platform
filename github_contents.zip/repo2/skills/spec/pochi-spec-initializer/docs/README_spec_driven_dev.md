# Phase1: 仕様駆動開発フレームワーク

## 概要

このフレームワークは、「仕様ベース開発」を実装したものです。

**主な原則**:

1. **仕様と実装の分離**: Initializer（質問とファイル出力のみ）と Coding Agent（実装とテスト）を明確に分離
2. **spec.json を正（Source of Truth）とする**: spec.md は spec.json から自動生成（ドリフト防止）
3. **会話履歴の持ち込み禁止**: 新セッションでは spec.md/plan.json のみを参照（コンテキスト汚染防止）
4. **構造化された計画**: plan.json でタスク分解・依存関係・受入基準を管理

---

## クイックスタート（5分で理解）

### Step 1: Initializer で仕様を策定

1. Claude Code を開き、`pochi-spec-initializer/templates/initializer_kickoff_prompt.md` の内容を貼り付けます
2. 機能の概要を説明するか、既存資料（議事録、PRD等）を読み込ませます
3. Initializer からの質問（最大5問ずつ）に回答します
4. 全ての不明点が解消されたら、「**CONFIRM: READY TO FREEZE**」と返答します
5. Initializer が以下のファイルを自動生成します：
   - `pochi-spec-initializer/specs/features/[FEATURE-ID]/spec.json`（正）
   - `pochi-spec-initializer/specs/features/[FEATURE-ID]/spec.md`（spec.jsonから自動生成）
   - `pochi-spec-initializer/plans/[FEATURE-ID].json`（実装計画）

### Step 2: 仕様の検証と品質チェック

```bash
# スキーマバリデーション
python pochi-spec-initializer/scripts/validate_spec.py pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/spec.json
python pochi-spec-initializer/scripts/validate_plan.py pochi-spec-initializer/plans/FEAT-EXAMPLE-001.json

# 網羅性チェック（自動実行済み、確認用）
python pochi-spec-initializer/scripts/check_coverage.py FEAT-EXAMPLE-001

# 品質レポート確認（自動生成済み、確認用）
python pochi-spec-initializer/scripts/generate_quality_report.py FEAT-EXAMPLE-001

# Git コミット（凍結）
git add pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/ pochi-spec-initializer/plans/FEAT-EXAMPLE-001.json
git commit -m "feat(FEAT-EXAMPLE-001): freeze spec and plan (v1.0.0)"
git tag FEAT-EXAMPLE-001-v1.0.0
```

**自動生成されるファイル**:
- `pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/coverage_summary.json` - カバレッジレポート
- `pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/quality_report.json` - 品質レポート

### Step 3: Coding Agent で実装

1. **新しい Claude Code セッションを開始**（会話履歴を持ち込まない）
2. Coding Agent を起動:
   ```
   「Coding Agentを起動して、FEAT-EXAMPLE-001を実装してください」
   ```
3. Coding Agent が自動的に以下を実施:
   - spec.json と plan.json を読み込む
   - 実行可能なタスクを選択
   - タスクに従って実装
   - verification.test_command を実行して検証
   - task_result.json を生成
4. 各タスク完了後、自動的に次のタスクへ進む
5. blocked 状態の場合、spec_mismatch_report.md を確認して対応

---

## ディレクトリ構造

```
pochi-spec-initializer/
├── SKILL.md              # Skill定義
├── prompts/              # Initialiizer / Coding Agentプロンプト
│   └── initializer.md
├── schemas/              # JSON スキーマ
│   ├── spec.schema.json
│   └── plan.schema.json
├── templates/            # テンプレートとプロンプト
│   ├── spec.template.json
│   ├── plan.template.json
│   ├── spec.template.migration.json
│   ├── plan.template.migration.json
│   ├── initializer_kickoff_prompt.md
│   ├── migration-questions.md
│   └── specification_questions.md
├── scripts/              # 自動化スクリプト
│   ├── render_spec_md.py
│   ├── validate_spec.py
│   ├── validate_plan.py
│   ├── check_coverage.py
│   ├── generate_quality_report.py
│   ├── migration-converter.py
│   ├── validate-migration.py
│   └── init_phase1_setup.sh
├── docs/                 # ドキュメント
│   ├── README_spec_driven_dev.md (このファイル)
│   ├── WORKFLOW.md
│   ├── GUARDRAILS.md
│   ├── TOOLCHAIN.md
│   └── MIGRATION.md
└── input-document/       # 入力資料（議事録、PRD等）
    └── meeting_notes.md  # サンプル議事録
```

---

## 主要ファイル

### スキーマ

- **`schemas/spec.schema.json`**: spec.json のバリデーションスキーマ
- **`schemas/plan.schema.json`**: plan.json のバリデーションスキーマ

### テンプレート

- **`templates/spec.template.json`**: spec.json のテンプレート
- **`templates/plan.template.json`**: plan.json のテンプレート
- **`templates/initializer_kickoff_prompt.md`**: Initializer 起動プロンプト
- **`templates/specification_questions.md`**: 質問チェックリスト（カテゴリ別、具体例豊富）

### スクリプト

- **`scripts/render_spec_md.py`**: spec.json → spec.md 自動生成（Python実装）
- **`scripts/validate_spec.py`**: spec.json のスキーマ・論理検証（Python + jsonschema）
- **`scripts/validate_plan.py`**: plan.json のスキーマ・依存関係検証（Python + jsonschema）
- **`scripts/check_coverage.py`**: 要件・受入基準・非機能要件のカバレッジチェック
- **`scripts/generate_quality_report.py`**: 品質レポート生成（スキーマ検証、DAG検査、カバレッジ分析）
- **`scripts/migration-converter.py`**: migration-tasks.json → migration.json 変換
- **`scripts/validate-migration.py`**: migration.json のバリデーション
- **`scripts/init_phase1_setup.sh`**: 初期化スクリプト（Bash）

---

## よくある質問

### Q1: なぜ spec.json と spec.md の両方が必要なのですか？

**A**: spec.json は機械可読（バリデーション、自動処理に最適）、spec.md は人間可読（レビュー、理解に最適）です。spec.md を手動で編集するとドリフトが発生するため、常に spec.json から自動生成します。

### Q2: Initializer フェーズの会話履歴を持ち込まないのはなぜですか？

**A**: コンテキストの汚染を防ぐためです。40問以上の Q&A を新セッションに持ち込むと、不確実な情報や未確定の議論が混入します。spec.md/plan.json のみを参照することで、確定した情報だけで実装できます。

### Q3: 質問は毎回5問必要ですか？

**A**: いいえ。Initializer は状況に応じて1-5問で質問数を調整します。不明点が少なければ1-2問で十分です。重要なのは、全ての不明点を解消してから凍結することです。

### Q4: 既存資料（議事録、PRD等）を読み込ませる方法は？

**A**: `pochi-spec-initializer/input-document` ディレクトリに資料を格納してください。Initializer 起動時に、このディレクトリ内のファイルパスを明示して「これらのファイルを読み込んで要件抽出して」と指示します。詳しくは `docs/WORKFLOW.md` を参照してください。

### Q5: 仕様を更新したい場合はどうすればよいですか？

**A**: Initializer で spec.json を更新 → spec.md を再生成 → plan.json を更新 → Git コミット → 新セッションで再実装します。

### Q6: 資料はないが要件があり開発したい場合はどうすればよいですか？

**A**: `pochi-spec-initializer/input-document` ディレクトリに要件メモ（テキストファイル、Markdown等）を作成して格納してください。Initializer 起動時にこのファイルを参照することで、要件ベースの仕様策定を開始できます。

### Q7: 開発が終わったあとのspec.jsonとspec.mdはどうすればよいですか？

**A**: `pochi-spec-initializer/specs/features/[FEATURE-ID]/` ディレクトリをそのままアーカイブとして保持してください。将来の仕様更新や機能拡張時の参照資料として活用できます。

---

## 関連ドキュメント

- **[WORKFLOW.md](WORKFLOW.md)**: Initializer → 凍結 → Coding の詳細フロー
- **[GUARDRAILS.md](GUARDRAILS.md)**: Initializer のツール制限・よくある落とし穴
- **[TOOLCHAIN.md](TOOLCHAIN.md)**: スクリプトの詳細説明
- **[MIGRATION.md](MIGRATION.md)**: Migration機能のガイド

---

## 期待される効果

1. **一貫性**: 全プロジェクトで同じ仕様策定プロセス
2. **品質向上**: バリデーションとテストの自動化
3. **コンテキスト効率**: 会話履歴不要で新セッション開始
4. **ドリフト防止**: spec.json が常に正、spec.md は自動生成
5. **明確な責任分離**: Initializer（仕様）と Coding Agent（実装）

---

## サポート

質問や問題がある場合は、プロジェクトの Issues セクションで報告してください。
