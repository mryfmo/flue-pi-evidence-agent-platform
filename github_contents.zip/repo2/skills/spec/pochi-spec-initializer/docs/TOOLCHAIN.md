# スクリプト詳細説明

このドキュメントでは、Phase1 で提供されるスクリプトの詳細な使い方を説明します。

---

## 概要

Phase1 のスクリプトは全て Python で実装されています（一部 Bash）。依存ライブラリは `jsonschema` のみです。

---

## 1. render_spec_md.py

### 用途

spec.json から spec.md を自動生成します。

### 使い方

```bash
python pochi-spec-initializer/scripts/render_spec_md.py <spec.json> [output.md]
```

### 例

```bash
# spec.json と同じディレクトリに spec.md を生成
python pochi-spec-initializer/scripts/render_spec_md.py pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json

# 出力先を指定
python pochi-spec-initializer/scripts/render_spec_md.py pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json /tmp/spec.md
```

### 出力

```
Wrote pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.md
```

### 注意事項

- spec.md は常に spec.json から自動生成してください
- 人手で spec.md を編集すると、ドリフトが発生します
- 出力先を省略すると、spec.json と同じディレクトリに spec.md が生成されます

---

## 2. validate_spec.py

### 用途

spec.json のスキーマ検証と論理チェックを行います。

### 使い方

```bash
python pochi-spec-initializer/scripts/validate_spec.py <spec.json>
```

### 例

```bash
python pochi-spec-initializer/scripts/validate_spec.py pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json
```

### 出力（成功時）

```
Validating pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json...
Using schema: pochi-spec-initializer/schemas/spec.schema.json

✅ Schema validation PASSED

✅ All checks passed!
```

### 出力（エラー時）

```
Validating pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json...
Using schema: pochi-spec-initializer/schemas/spec.schema.json

❌ Validation FAILED

Errors:
  - Invalid status: invalid
  - Duplicate acceptance criteria IDs: {'AC-01'}

⚠️  Warnings:
  - No feature flag defined in techStack
  - No kill switch defined in rollout plan
```

### チェック項目

#### スキーマ検証
- spec.json が schemas/spec.schema.json に準拠しているか
- 必須フィールドが存在するか
- データ型が正しいか

#### 論理チェック
- status が "draft", "frozen", "deprecated" のいずれかか
- 受入基準のIDが一意か
- 受入基準が定義されているか（警告）
- API仕様の必須フィールドが存在するか
- Feature Flag が定義されているか（警告）
- ロールアウト計画が定義されているか（警告）

---

## 3. validate_plan.py

### 用途

plan.json のスキーマ検証と依存関係チェックを行います。

### 使い方

```bash
python pochi-spec-initializer/scripts/validate_plan.py <plan.json>
```

### 例

```bash
python pochi-spec-initializer/scripts/validate_plan.py pochi-spec-initializer/plans/FEAT-BARCHART-001.json
```

### 出力（成功時）

```
Validating pochi-spec-initializer/plans/FEAT-BARCHART-001.json...
Using schema: pochi-spec-initializer/schemas/plan.schema.json

✅ Schema validation PASSED

✅ All checks passed!
```

### 出力（エラー時）

```
Validating pochi-spec-initializer/plans/FEAT-BARCHART-001.json...
Using schema: pochi-spec-initializer/schemas/plan.schema.json

❌ Validation FAILED

Errors:
  - Task T-BC-008 depends on non-existent task: T-BC-999
  - Circular dependency detected involving task: T-BC-001
  - Task T-BC-010 references non-existent acceptance criteria: AC-99

⚠️  Warnings:
  - Unreferenced acceptance criteria: {'AC-10'}
```

### チェック項目

#### スキーマ検証
- plan.json が schemas/plan.schema.json に準拠しているか
- 必須フィールドが存在するか
- データ型が正しいか

#### 論理チェック
- status が "planned", "in_progress", "done", "blocked" のいずれかか
- タスクが定義されているか
- タスクIDが一意か
- 依存先のタスクが存在するか
- 自己依存していないか
- 循環依存していないか（DFSアルゴリズムで検出）
- 受入基準の参照が正しいか（警告）

---

## 4. check_coverage.py

### 用途

spec.json/spec.md/plan.json のドリフトと一貫性をチェックします。

### 使い方

```bash
python pochi-spec-initializer/scripts/check_coverage.py <feature_dir>
```

### 例

```bash
python pochi-spec-initializer/scripts/check_coverage.py pochi-spec-initializer/specs/features/FEAT-BARCHART-001
```

### 出力（成功時）

```
Checking consistency for FEAT-BARCHART-001...

1. Checking spec.json <-> spec.md drift...
   ✅ No drift detected

2. Checking plan.json <-> spec.json consistency...
   ✅ Consistent

✅ All consistency checks passed!
```

### 出力（エラー時）

```
Checking consistency for FEAT-BARCHART-001...

1. Checking spec.json <-> spec.md drift...
   ❌ Drift detected:
      - spec.md does not contain spec version: 1.1.0
      - spec.md does not contain acceptance criteria ID: AC-11

2. Checking plan.json <-> spec.json consistency...
   ❌ Inconsistencies detected:
      - plan.json version (1.0.0) does not match spec.json version (1.1.0)
      - Task T-BC-010 references non-existent acceptance criteria: AC-99

❌ Consistency checks FAILED

Recommendations:
  - Regenerate spec.md from spec.json:
    python pochi-spec-initializer/scripts/render_spec_md.py pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json
  - Review and update plan.json to match spec.json
```

### チェック項目

#### spec.json ↔ spec.md ドリフト
- spec.md に spec.json の基本情報（ID, タイトル, バージョン, 日付, ステータス）が含まれているか
- spec.md に全ての受入基準IDが含まれているか

#### plan.json ↔ spec.json 一貫性
- plan.json と spec.json の ID が一致しているか
- plan.json と spec.json のバージョンが一致しているか
- plan.json のタスクが参照する受入基準が spec.json に存在するか
- spec.json の受入基準が plan.json のタスクで参照されているか（警告）

---

## 5. init_phase1_setup.sh

### 用途

Phase1 の初期セットアップを行います。

### 使い方

```bash
bash pochi-spec-initializer/scripts/init_phase1_setup.sh
```

### 実行内容

1. **ディレクトリ作成**
   - `pochi-spec-initializer/specs/features/`
   - `pochi-spec-initializer/plans/`

2. **Python 依存関係のインストール**
   - `jsonschema` をインストール（未インストールの場合）

3. **スクリプトに実行権限を付与**
   - `render_spec_md.py`
   - `validate_spec.py`
   - `validate_plan.py`
   - `check_coverage.py`

### 出力

```
=========================================
 Phase1: 仕様駆動開発フレームワーク
 セットアップスクリプト
=========================================

Phase1 directory: /home/user/pochi-dp-developer-docs/pochi-spec-initializer
Root directory: /home/user/pochi-dp-developer-docs

1. Creating directories...
   ✅ Directories created

2. Checking Python dependencies...
   ✅ jsonschema is already installed

3. Setting execute permissions on scripts...
   ✅ Execute permissions set

=========================================
 ✅ Phase1 setup completed!
=========================================

Next steps:
1. Read the documentation:
   - /home/user/pochi-dp-developer-docs/pochi-spec-initializer/docs/README_spec_driven_dev.md
   - /home/user/pochi-dp-developer-docs/pochi-spec-initializer/docs/WORKFLOW.md
   - /home/user/pochi-dp-developer-docs/pochi-spec-initializer/docs/GUARDRAILS.md

2. Start an Initializer session:
   - Open Claude Code
   - Paste the content of: /home/user/pochi-dp-developer-docs/pochi-spec-initializer/templates/initializer_kickoff_prompt.md

3. Validate your spec and plan:
   python3 /home/user/pochi-dp-developer-docs/pochi-spec-initializer/scripts/validate_spec.py pochi-spec-initializer/specs/features/FEAT-EXAMPLE-001/spec.json
   python3 /home/user/pochi-dp-developer-docs/pochi-spec-initializer/scripts/validate_plan.py pochi-spec-initializer/plans/FEAT-EXAMPLE-001.json
```

---

## 依存関係

### Python

- **Python 3.7+** が必要です
- `jsonschema` ライブラリが必要です

### インストール

```bash
# jsonschema のインストール
pip3 install jsonschema

# または、セットアップスクリプトで自動インストール
bash pochi-spec-initializer/scripts/init_phase1_setup.sh
```

---

## トラブルシューティング

### Q1: "jsonschema is not installed" エラーが出る

**A**: 以下のコマンドで jsonschema をインストールしてください：

```bash
pip3 install jsonschema
```

### Q2: "Permission denied" エラーが出る

**A**: スクリプトに実行権限を付与してください：

```bash
chmod +x pochi-spec-initializer/scripts/render_spec_md.py
chmod +x pochi-spec-initializer/scripts/validate_spec.py
chmod +x pochi-spec-initializer/scripts/validate_plan.py
chmod +x pochi-spec-initializer/scripts/check_coverage.py
```

または、セットアップスクリプトを実行してください：

```bash
bash pochi-spec-initializer/scripts/init_phase1_setup.sh
```

### Q3: "Schema file not found" エラーが出る

**A**: スクリプトを実行する際は、リポジトリのルートディレクトリから実行してください：

```bash
# 正しい実行方法
cd /home/user/pochi-dp-developer-docs
python pochi-spec-initializer/scripts/validate_spec.py pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json

# 誤った実行方法
cd pochi-spec-initializer/scripts
python validate_spec.py ../../pochi-spec-initializer/specs/features/FEAT-BARCHART-001/spec.json
```

---

## まとめ

- **render_spec_md.py**: spec.json → spec.md 自動生成（ドリフト防止）
- **validate_spec.py**: spec.json のスキーマ・論理検証
- **validate_plan.py**: plan.json のスキーマ・依存関係検証
- **check_coverage.py**: spec.json/spec.md/plan.json のドリフト検知
- **init_phase1_setup.sh**: 初期セットアップ自動化

これらのスクリプトを活用することで、仕様のドリフトを防ぎ、一貫性のある開発が可能になります。
