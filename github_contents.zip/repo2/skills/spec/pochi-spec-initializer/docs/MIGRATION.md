# Migration 機能ガイド

## 概要

このドキュメントでは、仕様駆動開発フレームワークのMigration機能について説明します。Migration機能は、pochilib等の共通ライブラリのアップグレードに伴う複数アプリケーションの改修を自動化するためのツールセットです。

## 目次

- [背景と目的](#背景と目的)
- [全体フロー](#全体フロー)
- [ツール構成](#ツール構成)
- [使い方](#使い方)
- [実践例](#実践例)
- [トラブルシューティング](#トラブルシューティング)

## 背景と目的

### 課題

- pochilib等の共通ライブラリ更新時、複数アプリの影響調査と改修が手作業
- 既存のspec-initializer/coding-agentは単一アプリの新規開発向け
- migration-tasks.json（改修タスクリスト）から仕様書への変換機能なし

### 目標

- migration-tasks.json を入力として spec.json/plan.json を自動生成
- 既存フレームワークの後方互換性を維持
- 自動修正可能/手動修正が必要なタスクを区別

## 全体フロー

```
pochilib-migration-generator (既存)
  ↓
migration-tasks.json（改修タスクリスト）
  ↓
migration-converter.py（新規）
  ↓
migration.json（構造化改修指示）
  ↓
validate-migration.py（新規）
  ↓
Initializer（migration-mode）（将来）
  ↓
spec.json/plan.json（migration専用）
  ↓
Coding Agent × N（各アプリで実行）
  ↓
複数アプリの改修完了
```

## ツール構成

### 1. migration-converter.py

**目的**: migration-tasks.json を migration.json に変換

**場所**: `pochi-spec-initializer/scripts/migration-converter.py`

**入力**: migration-tasks.json（pochilib-migration-generator 出力）

**出力**: migration.json（構造化改修指示）

**機能**:
- migration-tasks.json のスキーマ検証
- タスクの自動分類（autoFixable/manual）
- 依存関係の解析
- 各アプリごとのタスク分類
- spec/plan テンプレートの自動生成提案

### 2. validate-migration.py

**目的**: migration.json のバリデーション

**場所**: `pochi-spec-initializer/scripts/validate-migration.py`

**入力**: migration.json

**チェック項目**:
- スキーマ検証
- 循環依存検出
- 対象アプリの存在確認（オプション）
- autoFixable の妥当性チェック
- summary セクションの整合性

### 3. テンプレート

**spec.template.migration.json**
- 場所: `pochi-spec-initializer/templates/spec.template.migration.json`
- 用途: migration仕様の雛形

**plan.template.migration.json**
- 場所: `pochi-spec-initializer/templates/plan.template.migration.json`
- 用途: migration計画の雛形

## 使い方

### Step 1: migration-tasks.json の取得

まず、`pochilib-migration-generator` を使って migration-tasks.json を生成します。

```bash
# pochilib-migration-generator の実行（既存ツール）
python scripts/generate-migration-tasks.py \
  --source-version 1.0.0 \
  --target-version 2.0.0 \
  --output migration-tasks.json
```

### Step 2: migration.json への変換

`migration-converter.py` を使って migration-tasks.json を migration.json に変換します。

```bash
# 基本的な使い方
python pochi-spec-initializer/scripts/migration-converter.py \
  migration-tasks.json \
  --output migration.json

# バリデーション付き変換
python pochi-spec-initializer/scripts/migration-converter.py \
  migration-tasks.json \
  --output migration.json \
  --validate
```

**出力例**:

```
Converting migration-tasks.json to migration.json...

✅ Successfully converted to migration.json

Summary:
  Total tasks: 10
  Auto-fixable: 7
  Manual: 3
  Affected apps: 5

Next steps:
  1. Review the generated migration.json
  2. Run: python pochi-spec-initializer/scripts/validate-migration.py migration.json
  3. Use pochi-spec-initializer with migration-mode
```

### Step 3: migration.json のバリデーション

`validate-migration.py` を使って migration.json の整合性を検証します。

```bash
# 基本的なバリデーション
python pochi-spec-initializer/scripts/validate-migration.py migration.json

# アプリ存在確認付き
python pochi-spec-initializer/scripts/validate-migration.py migration.json --check-apps

# 詳細モード
python pochi-spec-initializer/scripts/validate-migration.py migration.json --verbose
```

**出力例**:

```
Validating migration.json...

✅ Validation PASSED

Migration Summary:
  Total tasks: 10
  Auto-fixable: 7
  Manual: 3
  Affected apps: 5

✅ All validation checks passed!
```

### Step 4: spec.json/plan.json の生成（手動）

現時点では、migration.json を参考に手動で spec.json/plan.json を作成します。テンプレートを利用してください。

```bash
# テンプレートをコピー
cp pochi-spec-initializer/templates/spec.template.migration.json \
   pochi-spec-initializer/specs/migrations/MIG-001/spec.json

cp pochi-spec-initializer/templates/plan.template.migration.json \
   pochi-spec-initializer/specs/migrations/MIG-001/plan.json

# エディタで編集
vim pochi-spec-initializer/specs/migrations/MIG-001/spec.json
vim pochi-spec-initializer/specs/migrations/MIG-001/plan.json
```

**将来**: `pochi-spec-initializer` に migration-mode を追加し、migration.json から自動生成できるようにする予定です。

### Step 5: Coding Agent で実装

通常の仕様駆動開発フローと同様に、Coding Agent を使って実装します。

```bash
# pochi-coding-agent を起動
# （詳細は pochi-coding-agent のドキュメントを参照）
```

## 実践例

### 例1: pochilib v1.0 → v2.0 のマイグレーション

#### 1. migration-tasks.json の取得

```bash
python scripts/generate-migration-tasks.py \
  --source-version 1.0.0 \
  --target-version 2.0.0 \
  --output migration-tasks.json
```

#### 2. migration.json への変換

```bash
python pochi-spec-initializer/scripts/migration-converter.py \
  migration-tasks.json \
  --output migration.json \
  --validate
```

#### 3. バリデーション

```bash
python pochi-spec-initializer/scripts/validate-migration.py \
  migration.json \
  --check-apps \
  --verbose
```

#### 4. 結果の確認

```json
{
  "version": "1.0.0",
  "generatedAt": "2026-02-12T10:00:00",
  "sourceFile": "migration-tasks.json",
  "migrationInfo": {
    "sourceVersion": "1.0.0",
    "targetVersion": "2.0.0",
    "library": "pochilib",
    "migrationDate": "2026-02-15"
  },
  "summary": {
    "totalTasks": 10,
    "autoFixableTasks": 7,
    "manualTasks": 3,
    "affectedApps": ["app-dashboard", "app-analytics", "app-reporting"],
    "appCount": 3
  },
  "tasks": [
    {
      "id": "MIG-001",
      "name": "API名変更: getUser() → getUserProfile()",
      "category": "API変更",
      "autoFixable": true,
      "appScope": ["app-dashboard", "app-admin"],
      ...
    }
  ]
}
```

#### 5. spec.json/plan.json の作成

テンプレートを基に編集:

```bash
cp pochi-spec-initializer/templates/spec.template.migration.json \
   pochi-spec-initializer/specs/migrations/MIG-POCHILIB-V2-001/spec.json

# migration.json の内容を参考に編集
vim pochi-spec-initializer/specs/migrations/MIG-POCHILIB-V2-001/spec.json
```

#### 6. 実装

Coding Agent で各タスクを実装します。

## migration.json の構造

### トップレベル

```json
{
  "version": "1.0.0",
  "generatedAt": "ISO8601 datetime",
  "sourceFile": "migration-tasks.json",
  "migrationInfo": { ... },
  "summary": { ... },
  "tasks": [ ... ],
  "appGroups": { ... },
  "specTemplateRecommendation": { ... }
}
```

### migrationInfo

```json
{
  "sourceVersion": "1.0.0",
  "targetVersion": "2.0.0",
  "library": "pochilib",
  "migrationDate": "2026-02-15"
}
```

### summary

```json
{
  "totalTasks": 10,
  "autoFixableTasks": 7,
  "manualTasks": 3,
  "affectedApps": ["app-dashboard", "app-analytics"],
  "appCount": 2
}
```

### tasks

```json
{
  "id": "MIG-001",
  "name": "タスク名",
  "description": "詳細説明",
  "category": "API変更",
  "autoFixable": true,
  "appScope": ["app-dashboard"],
  "priority": "P0",
  "dependsOn": ["MIG-000"],
  "estimateHours": 2,
  "migrationTaskRef": "MIG-001",
  "rollbackScript": "git checkout -- app-dashboard/src"
}
```

### appGroups

```json
{
  "app-dashboard": ["MIG-001", "MIG-002"],
  "app-analytics": ["MIG-003", "MIG-004"]
}
```

## スキーマ拡張

### spec.schema.json の拡張フィールド

```json
{
  "isMigration": false,
  "migrationSourceVersion": "1.0.0",
  "migrationTargetVersion": "2.0.0",
  "migrationTasks": [
    {
      "taskId": "MIG-001",
      "category": "API変更",
      "description": "説明"
    }
  ]
}
```

### plan.schema.json の拡張フィールド（タスクレベル）

```json
{
  "appScope": ["app-dashboard", "app-analytics"],
  "autoFixable": true,
  "migrationTaskRef": "MIG-001",
  "rollbackScript": "git checkout -- app-dashboard/src"
}
```

## トラブルシューティング

### エラー: "Missing required field: version"

**原因**: migration-tasks.json の構造が不正

**解決策**: migration-tasks.json が正しい形式であることを確認してください。

```json
{
  "metadata": {
    "sourceVersion": "1.0.0",
    "targetVersion": "2.0.0"
  },
  "tasks": [ ... ]
}
```

### エラー: "Circular dependency detected involving task: MIG-003"

**原因**: タスク間の依存関係に循環参照がある

**解決策**: migration-tasks.json の `dependsOn` フィールドを見直し、循環依存を解消してください。

```bash
# 循環依存の検出
python pochi-spec-initializer/scripts/validate-migration.py migration.json --verbose
```

### 警告: "Task MIG-002 has dangerous category 'db' but marked as autoFixable"

**原因**: データベース変更など、自動修正すべきでないタスクが autoFixable=true になっている

**解決策**: migration-tasks.json で該当タスクの `autoFixable` を `false` に変更してください。

### エラー: "Task MIG-005 depends on non-existent task: MIG-999"

**原因**: 存在しないタスクIDへの依存関係が定義されている

**解決策**: migration-tasks.json の `dependsOn` フィールドを確認し、正しいタスクIDを指定してください。

### migration-converter.py が見つからない

**原因**: スクリプトのパスが間違っている

**解決策**: リポジトリルートから実行してください。

```bash
# 正しいパス
python pochi-spec-initializer/scripts/migration-converter.py migration-tasks.json

# 間違ったパス（scripts/ ディレクトリから実行）
python migration-converter.py migration-tasks.json  # NG
```

## よくある質問（FAQ）

### Q1: migration-mode は現在使えますか？

A: 現在は未実装です。Phase 3（将来）で `pochi-spec-initializer` に migration-mode を追加する予定です。現時点では、migration.json を参考にして手動で spec.json/plan.json を作成してください。

### Q2: autoFixable の判定基準は？

A: 以下のヒューリスティックで判定されます:

**自動修正が難しいカテゴリ**:
- `db`, `database`, `schema`, `migration`, `breaking`, `manual`, `complex`

**自動修正が難しいキーワード**:
- `manual`, `complex`, `careful`, `review required`, `database`, `schema`, `breaking change`

これらに該当しない場合は `autoFixable=true` と判定されます（保守的に変更する場合は `false` に）。

### Q3: 既存のspec/planフローへの影響は？

A: 後方互換性が100%維持されています。migration関連のフィールドはすべてオプショナルなので、既存のワークフローには一切影響しません。

### Q4: 複数リポジトリにまたがるマイグレーションは？

A: 現在のスコープ外です。外部オーケストレーション層で対応してください。各リポジトリごとに migration.json を生成し、個別に実装してください。

### Q5: ロールバック方法は？

A: 各タスクの `rollbackScript` フィールドにロールバック手順が記載されています。通常は以下のいずれかです:

- `git revert <commit-hash>`
- `git checkout -- <file-path>`
- `sed` コマンドによる差し戻し
- カスタムロールバックスクリプト

## 今後の拡張予定

### Phase 1: 基盤整備（完了）

- [x] スキーマ拡張（plan.schema.json, spec.schema.json）
- [x] migration-converter.py 実装
- [x] validate-migration.py 実装
- [x] テンプレート作成（spec.template.migration.json, plan.template.migration.json）

### Phase 2: Initializer 拡張（将来）

- [ ] `pochi-spec-initializer` に migration-mode 追加
- [ ] migration.json から spec.json/plan.json を自動生成
- [ ] 対話フロー設計（migration-questions.md）

### Phase 3: 本運用試行

- [ ] 実際の pochilib アップグレードで試験
- [ ] フィードバック収集・改善

## 参考資料

- [仕様駆動開発フレームワーク全体ドキュメント](./WORKFLOW.md)
- [pochi-spec-initializer ドキュメント](../SKILL.md)
- [pochi-coding-agent ドキュメント](../../pochi-coding-agent/SKILL.md)

## 貢献

Migration機能の改善提案やバグ報告は、GitHubのIssueで受け付けています。

## ライセンス

このドキュメントと関連ツールは、プロジェクトのライセンスに従います。
