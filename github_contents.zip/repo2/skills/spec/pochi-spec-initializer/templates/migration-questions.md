# Migration Mode 質問テンプレート

このドキュメントは、Initializer の Migration Mode で使用する質問テンプレートを定義します。

## 質問の原則

### 最小限の質問

migration.json から自動抽出できる情報については**質問しない**でください。

**自動抽出可能な情報**:
- sourceVersion, targetVersion（migrationInfo から）
- 影響するアプリケーション（summary.affectedApps から）
- タスクの総数、自動修正可能数（summary から）
- 各タスクの詳細（tasks から）
- 依存関係（tasks.dependsOn から）

**質問が必要な情報**:
- 段階的ロールアウトの優先順位
- 特殊な制約事項やリスク
- 追加の受入基準
- ロールバック時の特殊手順

### 質問数の制限

- **最大3問まで**
- 状況に応じて0-3問で調整
- migration.json に十分な情報がある場合は質問不要

---

## 質問カテゴリ

### 1. ロールアウト優先順位

**質問するタイミング**:
- migration.json に複数のアプリが含まれている場合
- appGroups に3つ以上のアプリがある場合

**質問テンプレート**:

```
migration.json によると、以下の{appCount}個のアプリケーションが影響を受けます：

{affectedAppsList}

段階的にマイグレーションを実施する場合、どのアプリから優先的に実施しますか？
```

**回答パターン**:
- パターン1: 「app-dashboard から開始」
- パターン2: 「すべて同時に実施」
- パターン3: 「テスト環境で app-test-1 → 本番で app-dashboard → 残り」

**デフォルト値**（ユーザーが回答しない場合）:
- 最初のアプリから順番に実施
- rolloutPlan.phases に反映

---

### 2. 特殊な制約事項とリスク

**質問するタイミング**:
- migration.json の tasks に "manual" または "breaking" カテゴリが含まれている場合
- autoFixable=false のタスクが3つ以上ある場合

**質問テンプレート**:

```
migration.json によると、以下の手動対応タスクがあります：

{manualTasksList}

これらのタスクに関して、特殊な制約事項やリスクはありますか？
（例: ダウンタイム要件、特定の時間帯での実施制限、依存サービスへの影響等）
```

**回答パターン**:
- パターン1: 「ダウンタイムなしで実施する必要がある」
- パターン2: 「深夜メンテナンス時間帯のみ実施可能」
- パターン3: 「特になし」

**デフォルト値**（ユーザーが回答しない場合）:
- ダウンタイム: 0分
- 実施時間帯: 制限なし
- risksConstraints.constraints に反映

---

### 3. 追加の受入基準

**質問するタイミング**:
- migration.json のタスク数が10以上の大規模マイグレーションの場合
- 破壊的変更が含まれている場合

**質問テンプレート**:

```
以下の基本的な受入基準を設定します：

- AC-MIG-01: すべてのアプリで新バージョンが正しくインポートされる
- AC-MIG-02: 既存のユニットテストが100%パスする
- AC-MIG-03: 既存のE2Eテストが100%パスする
- AC-MIG-04: 非推奨APIの使用が0件になる
- AC-MIG-05: ロールバックが5分以内に完了する

追加で必要な受入基準はありますか？
（例: パフォーマンス基準、互換性チェック、データ整合性確認等）
```

**回答パターン**:
- パターン1: 「パフォーマンス劣化が5%以内」
- パターン2: 「データマイグレーションの整合性確認」
- パターン3: 「特になし」

**デフォルト値**（ユーザーが回答しない場合）:
- 基本的な受入基準のみを使用
- acceptanceCriteria に反映

---

### 4. ロールバック時の特殊手順

**質問するタイミング**:
- migration.json の tasks に rollbackScript が "manual" または空の場合
- データベーススキーマ変更が含まれている場合

**質問テンプレート**:

```
以下のタスクについて、ロールバック手順が明確ではありません：

{tasksWithoutRollback}

ロールバック時の特殊な手順はありますか？
（例: データベースバックアップのリストア、設定ファイルの戻し方等）
```

**回答パターン**:
- パターン1: 「データベースバックアップから復元」
- パターン2: 「git revert で自動ロールバック可能」
- パターン3: 「特殊手順なし」

**デフォルト値**（ユーザーが回答しない場合）:
- ロールバック方法: `git revert <commit-hash>`
- rollbackScript に反映

---

## 質問フローの例

### 例1: 小規模マイグレーション（質問0問）

**入力**:
- migration.json: 1アプリ、5タスク、すべて autoFixable=true

**判定**:
- アプリ数が1つ → ロールアウト優先順位の質問不要
- autoFixable タスクのみ → 制約事項の質問不要
- タスク数が10未満 → 追加受入基準の質問不要
- rollbackScript がすべて記載済み → ロールバック手順の質問不要

**アクション**:
- 質問なしで spec.json/plan.json を自動生成
- ユーザーに「CONFIRM: READY TO FREEZE」を求める

---

### 例2: 中規模マイグレーション（質問1-2問）

**入力**:
- migration.json: 3アプリ、12タスク、autoFixable=false が2タスク

**判定**:
- アプリ数が3つ → ロールアウト優先順位の質問必要 ✅
- autoFixable=false タスクあり → 制約事項の質問必要 ✅
- タスク数が12 → 追加受入基準の質問必要 ✅
- rollbackScript 記載済み → ロールバック手順の質問不要

**アクション**:
- 質問1: ロールアウト優先順位
- 質問2: 制約事項とリスク
- （質問3: 追加受入基準は省略可能 - 最大3問制限）

---

### 例3: 大規模マイグレーション（質問3問）

**入力**:
- migration.json: 5アプリ、25タスク、autoFixable=false が8タスク、rollbackScript が一部未記載

**判定**:
- アプリ数が5つ → ロールアウト優先順位の質問必要 ✅
- autoFixable=false タスクが多数 → 制約事項の質問必要 ✅
- タスク数が25 → 追加受入基準の質問必要 ✅
- rollbackScript 未記載あり → ロールバック手順の質問必要 ✅

**アクション**:
- 質問1: ロールアウト優先順位
- 質問2: 制約事項とリスク
- 質問3: 追加受入基準
- （質問4: ロールバック手順は最大3問制限のため省略、デフォルト値を使用）

---

## 自動補完ルール

### migration.json から自動補完できる情報

以下の情報は migration.json から抽出し、**質問せずに自動的に spec.json/plan.json に反映**します：

#### spec.json への自動補完

```json
{
  "isMigration": true,
  "migrationSourceVersion": "{migrationInfo.sourceVersion}",
  "migrationTargetVersion": "{migrationInfo.targetVersion}",
  "title": "{library} {sourceVersion} → {targetVersion} マイグレーション仕様書",
  "overview": "{library}のバージョンアップグレード（{sourceVersion} → {targetVersion}）に伴う既存アプリケーションの改修仕様",
  "background": "{library}が{targetVersion}にアップグレードされ、{totalTasks}個の改修タスクが必要",
  "migrationTasks": [
    {
      "taskId": "{task.id}",
      "category": "{task.category}",
      "description": "{task.description}"
    }
  ]
}
```

#### plan.json への自動補完

```json
{
  "id": "{migration.json ファイル名から抽出}",
  "title": "{library} {sourceVersion} → {targetVersion} マイグレーション実装計画",
  "tasks": [
    {
      "id": "{task.id}",
      "name": "{task.name}",
      "appScope": "{task.appScope}",
      "autoFixable": "{task.autoFixable}",
      "migrationTaskRef": "{task.id}",
      "rollbackScript": "{task.rollbackScript}",
      "dependsOn": "{task.dependsOn}",
      "estimateHours": "{task.estimateHours}",
      "priority": "{task.priority}"
    }
  ]
}
```

---

## 質問を省略する条件

以下の条件を**すべて満たす**場合、質問を完全に省略できます：

1. ✅ migration.json に migrationInfo, summary, tasks, appGroups がすべて含まれている
2. ✅ すべてのタスクに rollbackScript が記載されている
3. ✅ 影響するアプリが1つのみ、または rolloutPlan が migration.json に含まれている
4. ✅ autoFixable=false のタスクが3つ未満
5. ✅ 総タスク数が10未満

上記を満たす場合、ユーザーに以下を提示：

```
migration.json から必要な情報をすべて抽出できました。
質問なしで spec.json と plan.json を生成します。

「CONFIRM: READY TO FREEZE」と返答してください。
```

---

## 実装ガイドライン

### Initializer での実装方法

1. **migration.json の読み込み**
   ```python
   # Read ツールで migration.json を読み込み
   migration_data = Read("path/to/migration.json")
   ```

2. **情報の抽出と判定**
   ```python
   # 必要な情報を抽出
   app_count = len(migration_data["summary"]["affectedApps"])
   manual_tasks = [t for t in migration_data["tasks"] if not t["autoFixable"]]
   total_tasks = migration_data["summary"]["totalTasks"]

   # 質問が必要か判定
   needs_rollout_question = app_count >= 3
   needs_risk_question = len(manual_tasks) >= 3
   needs_ac_question = total_tasks >= 10
   ```

3. **質問の生成（必要な場合のみ）**
   ```python
   # AskUserQuestion ツールで質問
   questions = []
   if needs_rollout_question:
       questions.append({
           "question": "段階的マイグレーションの優先順位は？",
           "header": "Rollout",
           "options": [...],
           "multiSelect": False
       })

   # 最大3問まで
   if len(questions) > 3:
       questions = questions[:3]
   ```

4. **spec.json/plan.json の生成**
   ```python
   # テンプレートを読み込み
   spec_template = Read("templates/spec.template.migration.json")
   plan_template = Read("templates/plan.template.migration.json")

   # migration.json の情報で置換
   spec_json = fill_template(spec_template, migration_data, user_answers)
   plan_json = fill_template(plan_template, migration_data, user_answers)

   # Write ツールで保存
   Write("pochi-spec-initializer/specs/migrations/{id}/spec.json", spec_json)
   Write("pochi-spec-initializer/plans/{id}.json", plan_json)
   ```

---

## まとめ

- **質問は最大3問まで**、migration.json に十分な情報があれば0問
- **自動抽出可能な情報は質問しない**
- **デフォルト値を積極的に使用**して、ユーザーの負担を最小化
- **spec.template.migration.json と plan.template.migration.json**をベースに自動生成
