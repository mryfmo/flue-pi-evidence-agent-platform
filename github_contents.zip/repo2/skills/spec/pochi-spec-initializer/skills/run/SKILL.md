---
name: pochi-spec-initializer
description: >-
  仕様駆動開発フレームワークのInitializer(仕様策定専用エージェント)として動作し、質問ベースで仕様書と実装計画を生成します。
  「仕様駆動開発を開始」「spec.jsonを作成」「Initializerを起動」「仕様策定を開始」「pochi-spec-initializer を起動」などと依頼した時に使用する。
allowed-tools: Read, Write, Glob, Grep, AskUserQuestion
---

# Skill: pochi-spec-initializer

## Metadata

- **skill_id**: pochi-spec-initializer
- **version**: 1.4.0
- **status**: active
- **category**: specification
- **author**: Pochi Development Team
- **created**: 2026-01-23
- **updated**: 2026-05-26

## Description

仕様駆動開発フレームワークのInitializer（仕様策定専用エージェント）として動作し、質問ベースで仕様書と実装計画を生成します。

このSkillは、**2つの動作モード**をサポートします：

### 通常モード（Normal Mode）
新機能追加や改修の仕様策定を行います。質問ベースでユーザーと対話し、仕様を明確化します。

### マイグレーションモード（Migration Mode）
ライブラリアップグレード等の既存コード改修の仕様策定を行います。migration.jsonから情報を自動抽出し、質問を最小化します。

このSkillは、以下の成果物を生成します：

1. **spec.json** - 機械可読な仕様書（Source of Truth）
2. **spec.md** - spec.jsonから自動生成される人間可読ドキュメント
3. **plan.json** - タスク分解・依存関係・受入基準との紐付けを含む実装計画
4. **coverage_summary.json** - 要件・受入基準・非機能要件のカバレッジレポート
5. **quality_report.json** - スキーマ検証・依存関係・カバレッジを含む品質レポート

## Key Features

- **厳格なツール制限**: 質問（AskUserQuestionTool）とファイル書き込み（FileWriteTool）のみ許可
- **spec.jsonが正（Source of Truth）**: spec.mdは常にspec.jsonから自動生成
- **会話履歴の持ち込み禁止**: Coding Agentは新セッションでspec.md/plan.jsonのみを参照
- **受入基準との紐付け**: plan.jsonの各タスクはspec.jsonの受入基準IDを参照
- **バリデーション**: Pythonスクリプトによるスキーマ検証とドリフト検知
- **テスト実装タスク禁止**: plan.json には機能実装タスクのみを含める。`tests/` 以下のファイルを生成するテスト実装タスクは禁止。テスト生成は `pochi-unit-test-generator` / `pochi-integration-test-generator` / `pochi-e2e-test-generator` が担当する

## Triggers

このSkillは以下のフレーズで起動します：

### 通常モード（Normal Mode）
- 「仕様駆動開発を開始」
- 「spec.jsonを作成」
- 「Initializerを起動」
- 「仕様策定を開始」
- 「spec-driven-devを開始」
- 「仕様ベース開発を開始」
- start spec-driven development
- launch initializer
- create spec.json

### マイグレーションモード（Migration Mode）
- 「migration.jsonから仕様書を生成」
- 「マイグレーション仕様を作成」
- 「ライブラリアップグレードの計画を生成」
- 「migration-modeで起動」
- 「migration仕様書を作成」
- 「pochilibアップグレード仕様を作成」

## Entry Point

`prompts/initializer.md`

## ⚠️ CRITICAL: Skill Activation Protocol

**このスキルを起動する際は、以下の手順を厳守してください。順序を守らないと実装を誤って開始する危険があります。**

### 起動時の必須手順

1. **Plan Modeの確認と解除**
   - Plan Modeがアクティブな場合は、必ず `ExitPlanMode` で終了してからこのスキルを起動してください
   - Plan Modeとこのスキルのワークフローは**完全に独立**しています
   - **絶対に Plan Mode のワークフロー（探索→計画→実装）と混同しないでください**

2. **Initializerプロンプトの明示的な読み込み**
   ```
   スキル起動直後に以下を実行:
   - Read tool で prompts/initializer.md を読み込む
   - initializer.md の全指示を確認する
   - 「最初のアクション」セクションに従って動作を開始する
   ```

3. **ツール制約の厳守宣言**
   ```
   起動直後に以下を宣言:

   「現在 Initializer モードで動作しています。
   使用可能なツール:
   - AskUserQuestion: ユーザーへの質問
   - Write: spec.json/spec.md/plan.json の保存
   - Read: 既存資料の読み込み
   - Glob: ファイル検索
   - Grep: コンテンツ検索

   使用禁止のツール:
   - Bash: コマンド実行
   - Edit: ソースコード編集
   - Task: 実装エージェント起動
   - NotebookEdit: ノートブック編集
   - その他すべての実装関連ツール

   このスキルでは、spec.json/spec.md/plan.json の生成のみを行います。
   実装は一切行いません。」
   ```

4. **動作開始の確認**
   - 質問ベースでの仕様収集を開始しているか確認
   - 実装ファイル（.py, .ts, .tsx等）の読み込みや編集を行っていないか確認
   - 「CONFIRM: READY TO FREEZE」の返答を待っているか確認

### 起動時のチェックリスト

スキル起動後、以下を確認してください:

- [ ] Plan Modeが解除されている
- [ ] prompts/initializer.md が読み込まれている
- [ ] ツール制約が宣言されている
- [ ] 質問を提示している（または資料読み込みを開始している）
- [ ] Edit/Bash/Task などの実装ツールを使用していない
- [ ] 実装ファイルの編集を開始していない

### 禁止事項

**以下の行為は絶対に禁止です:**

- ❌ Plan Mode のワークフローで実装を開始する
- ❌ spec.json/spec.md/plan.json を生成する前に実装ファイルを編集する
- ❌ 「CONFIRM: READY TO FREEZE」を受け取る前に仕様を凍結する
- ❌ Edit/Bash/Task などの実装ツールを使用する
- ❌ prompts/initializer.md を読まずに独自の判断で動作する

## Workflow

### フェーズ1: 要件収集と質問

1. 既存資料の読み込み（議事録、PRD、設計書等）
2. 不明点を洗い出し、**最大5問まで**の質問を提示
3. ユーザーからの回答を受け取り、必要に応じて追加質問
4. 「CONFIRM: READY TO FREEZE」で次フェーズへ

### フェーズ2: 仕様の凍結と出力

1. spec.json生成（status: "frozen"、requirements/non_functional/quality_requirements含む）
   - **spec.json フィールド命名**: 全トップレベルフィールドを **snake_case** で統一する
     （例: `acceptanceCriteria` → `acceptance_criteria`, `nonGoals` → `non_goals`）
   - **UI改修時の定型NFR**: 変更対象に Streamlit UI コンポーネントが含まれる場合、
     `non_functional` に「Streamlitアンチパターン制約」（セッション状態誤用禁止 等）を必ず追加する
   - **quality_requirements の生成（必須）**: `non_functional` の直後に `quality_requirements` フィールドを必ず生成する。
     Pochi標準テンプレート（CLAUDE.mdの「Pochi標準 quality_requirements」セクション参照）をベースとし、
     機能の性質・技術スタック・リスクに応じて priority と criteria を調整する。
     全4特性（maintainability / reliability / security / functional_suitability）を必ず含めること。
2. spec.md生成（spec.jsonから自動生成）
3. plan.json生成（タスク分解、依存関係、references/verification必須）
   - **verificationセクション**（デフォルト値を使用、ユーザーへの質問不要）:
     - test_command: `run_tests.py --profile unit-only --level unit`（ユニットテスト）または `true`（目視確認・テスト不要）
     - success_criteria: テストタイプに応じた合格条件
     - verification_type: `unit`（デフォルト）、`integration`、`e2e`、`load`、`manual`
     - **注意**: `verification_type: "manual"` の場合は `test_command: "true"` を使用すること（`noop.sh` は使用禁止）
   - **重要**: Coding Agentではtest_commandは自動実行されません
   - **テスト方針**: `.pochi/test_policy.yaml`に従い、デフォルトは`unit-only`プロファイルを使用
4. **自動網羅性チェック**（check_coverage.py実行）
   - P0/P1要件の100%カバレッジを確認
   - 全受入基準の100%カバレッジを確認
   - 非機能要件の検証を確認
   - orphanタスクがないことを確認
5. **不足タスク提案**（gate_status="fail"の場合）
   - 未カバー項目を特定
   - タスク雛形を自動生成
   - ユーザー承認後、plan.json更新
   - 再チェック（gate_status="pass"まで反復）
6. **品質レポート生成**（generate_quality_report.py実行）
   - スキーマ検証、DAG検査、カバレッジ分析
   - スコア計算と推奨事項提示

### フェーズ3: 完了メッセージとCoding Agent起動指示

仕様書生成完了後、ユーザーに以下を伝える：

1. **完了通知**
   - spec.json/spec.md/plan.json の生成完了を報告
   - ファイルパスを明示
   - タスク概要をテーブル形式で表示

2. **新規セッション起動の指示**（**最重要**）
   - **「現在のセッションを終了してください」**
   - **「新しいClaude Codeセッションを開始してください」**
   - **「新セッションで以下のコマンドを実行してください」**:
     - `/home/user/pochi-dp-developer-docs/skills/pochi-coding-agent/SKILL.md を起動して、FEAT-[FEATURE-ID]を実装してください`

3. **会話履歴分離の説明**
   - Initializerの会話履歴は新セッションに持ち込まない
   - Coding Agentは spec.md/plan.json のみを参照
   - 仕様書が唯一の真実（Source of Truth）として機能

## Outputs

### ファイルパス

- **spec.json**: `{app_path}/spec/features/[FEATURE-ID]/spec.json`
- **spec.md**: `{app_path}/spec/features/[FEATURE-ID]/spec.md`
- **plan.json**: `{app_path}/spec/plans/[FEATURE-ID].json`
  - 各タスクには `verification` セクションを必ず含む
  - `verification` には以下のフィールドを含む:
    - `test_command`: テストコマンド（デフォルト: `run_tests.py --profile unit-only --level unit`）
    - `success_criteria`: 合格条件の説明（デフォルト: 「全ユニットテストがパスし、カバレッジ>80%」）
    - `verification_type`: "unit"（デフォルト） | "integration" | "e2e" | "load" | "manual"
  - **重要**: Coding Agentではtest_commandは自動実行されません
  - **デフォルト値使用**: テスト方法について質問せず、デフォルト値を使用してください
- **coverage_summary.json**: `{app_path}/spec/features/[FEATURE-ID]/coverage_summary.json`（自動生成）
- **quality_report.json**: `{app_path}/spec/features/[FEATURE-ID]/quality_report.json`（自動生成）

（[FEATURE-ID]は例: FEAT-BARCHART-001、{app_path}は実装対象アプリのリポジトリルートパス）

### バリデーション

生成後、以下のスクリプトで自動検証（`{APP_PATH}` は実装対象アプリのリポジトリルートパス）：

```bash
# スキーマ検証
python pochi-spec-initializer/scripts/validate_spec.py {APP_PATH}/spec/features/FEAT-XXX/spec.json
python pochi-spec-initializer/scripts/validate_plan.py {APP_PATH}/spec/plans/FEAT-XXX.json

# 網羅性チェック（自動実行）
python pochi-spec-initializer/scripts/check_coverage.py FEAT-XXX --app-path {APP_PATH}

# 品質レポート生成（自動実行）
python pochi-spec-initializer/scripts/generate_quality_report.py FEAT-XXX --app-path {APP_PATH}
```

## Tool Constraints

### 許可されるツール

- **AskUserQuestionTool**: ユーザーへの質問（1回あたり最大5問、状況に応じて1-5問で調整）
- **FileWriteTool**: spec.json/spec.md/plan.jsonの保存

### 禁止されるツール

- **ExecuteCommandTool**: コマンド実行
- **CodeEditTool**: ソースコード編集
- その他、仕様策定以外のツール

## Important Principles

1. **spec.jsonが正（Source of Truth）**
   - spec.mdは常にspec.jsonから自動生成
   - 人手でspec.mdを編集することは禁止

2. **会話履歴の持ち込み禁止**
   - このフェーズのQ&Aは新セッションに持ち込まない
   - Coding Agentはspec.md/plan.jsonのみを読み込む

3. **受入基準との紐付け**
   - plan.jsonの各タスクはacceptanceCriteria IDを参照
   - 実装後は対応するACのテストが必須

4. **テスト方針のデフォルト値使用**
   - テスト方法について**ユーザーに質問しない**
   - `test_command`のデフォルト: `run_tests.py --profile unit-only --level unit`
   - `verification_type`のデフォルト: `unit`
   - 目視確認タスク（`verification_type: "manual"`）の `test_command`: `true`
     - `noop.sh` は使用しない（CI環境でのスクリプト不在エラーを防ぐため）
   - 詳細は`.pochi/test_policy.yaml`とCLAUDE.mdの「テスト方針」を参照

## Difference from Other Skills

| 項目 | pochi-baseline-builder | pochi-feature-builder | **pochi-spec-initializer** |
|------|------------------------|----------------------|----------------------------|
| インプット | 議事録/イシュー | GitHub イシュー | 議事録/PRD/設計書/任意の資料 |
| 出力形式 | Markdown仕様書 | Markdown仕様書 | spec.json + spec.md + plan.json |
| 正（SoT） | Markdown | Markdown | **spec.json**（spec.mdは自動生成） |
| ツール制限 | 比較的緩い | 比較的緩い | **厳格（質問とファイル出力のみ）** |
| 実装計画 | なし | なし | **plan.json（タスク依存関係管理）** |
| バリデーション | なし | なし | **Pythonスクリプトによる自動検証** |

## References

- [docs/README_spec_driven_dev.md](docs/README_spec_driven_dev.md) - 全体説明
- [docs/WORKFLOW.md](docs/WORKFLOW.md) - ワークフロー詳細
- [docs/GUARDRAILS.md](docs/GUARDRAILS.md) - ガードレール（落とし穴）
- [docs/TOOLCHAIN.md](docs/TOOLCHAIN.md) - スクリプト使用方法

## Templates

### 通常モード用
- `templates/spec.template.json` - spec.jsonテンプレート
- `templates/plan.template.json` - plan.jsonテンプレート
- `templates/specification_questions.md` - 質問チェックリスト

### マイグレーションモード用
- `templates/spec.template.migration.json` - migration専用spec.jsonテンプレート
- `templates/plan.template.migration.json` - migration専用plan.jsonテンプレート
- `templates/migration-questions.md` - migration専用質問チェックリスト

## Usage Examples

### ✅ 正しい使用例

```
ユーザー: 「Initializerを起動して、spec.jsonを作成してください」

Claude:
1. Plan Modeが解除されていることを確認
2. Skillツールで pochi-spec-initializer を起動
3. prompts/initializer.md を Read
4. ツール制約を宣言:
   「Initializer モードで動作しています。
   使用可能なツール: AskUserQuestion, Write, Read, Glob, Grep
   使用禁止のツール: Bash, Edit, Task, NotebookEdit, その他実装ツール」
5. 質問ベースで仕様収集を開始
```

### ❌ 誤った使用例（今回のケース）

```
ユーザー: 「Initializerを起動して」

Claude（誤った動作）:
1. Plan Mode がアクティブなまま起動
2. prompts/initializer.md を読まずに動作開始
3. Plan Mode のワークフローで実装を開始
4. app/lib/merchant_map.py の編集を開始 ← ❌ 実装ツールを使用
5. spec.json/spec.md/plan.json を生成せず
```

**問題点:**
- Plan Modeを解除していない
- prompts/initializer.md を読み込んでいない
- ツール制約を無視して Edit を使用
- 仕様書生成ではなく実装を開始

## Version History

- **1.3.0** (2026-05-26): DESIGN.md照合ステップを削除
- **1.2.0** (2026-01-27): 自動網羅性チェック機能追加、references/verification必須化、品質レポート生成、不足タスク提案フロー追加
- **1.1.0** (2026-01-23): Skill Activation Protocolを追加（Plan Modeとの衝突防止、ツール制約の明示化）
- **1.0.0** (2026-01-23): 初版作成
