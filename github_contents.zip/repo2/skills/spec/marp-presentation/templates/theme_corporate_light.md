# Corporate Light テーマ定義

このファイルは `marp-presentation` Skill で使用するMarp frontmatterテーマの定義です。
スライド生成時はこのfrontmatterを `.md` ファイルの先頭に適用してください。

---

## Marp Frontmatter テンプレート

```markdown
---
marp: true
theme: default
paginate: true
size: 16:9
backgroundColor: #ffffff
color: #333333
footer: '{タイトル} | {日付}'
style: |
  section {
    font-family: 'Noto Sans JP', 'Segoe UI', sans-serif;
    background-color: #ffffff;
    color: #333333;
    padding: 60px 50px;
  }
  h1 { color: #1a56db; border-bottom: 3px solid #1a56db; font-size: 2.2em; }
  h2 { color: #1e429f; border-left: 4px solid #1e429f; padding-left: 15px; }
  h3 { color: #2563eb; }
  strong { color: #1a56db; font-weight: 600; }
  table th { background-color: #1a56db; color: white; }
  table td { border-bottom: 1px solid #e2e8f0; }
  .columns { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; }
  section.title { justify-content: center; text-align: center; background: linear-gradient(135deg, #ffffff 0%, #f0f7ff 100%); }
  section.title h1 { border: none; font-size: 2.8em; }
  section.title p { color: #6b7280; font-size: 1.1em; }
  section.agenda ol { font-size: 1.1em; line-height: 2.2; }
  section.section-break { background-color: #1a56db; color: white; justify-content: center; text-align: center; }
  section.section-break h2 { color: white; border-left: 4px solid rgba(255,255,255,0.6); }
  section.section-break blockquote { color: rgba(255,255,255,0.85); border-left: none; font-size: 1.1em; }
  footer { color: #9ca3af; font-size: 0.75em; }
  section::after { color: #9ca3af; font-size: 0.75em; }
---
```

---

## カラーパレット

| 要素 | カラーコード | 用途 |
|------|-------------|------|
| メインカラー | `#1a56db` | h1・強調テキスト・テーブルヘッダー・section-break背景 |
| サブカラー | `#1e429f` | h2・左ボーダー |
| アクセントカラー | `#2563eb` | h3・リンク |
| 背景（白） | `#ffffff` | 標準スライド背景 |
| 背景（薄青） | `#f0f7ff` | タイトルスライドグラデーション終端 |
| テキスト（本文） | `#333333` | 標準本文テキスト |
| テキスト（補足） | `#6b7280` | サブタイトル・補足情報 |
| テキスト（フッター） | `#9ca3af` | フッター・ページ番号 |
| テーブル罫線 | `#e2e8f0` | テーブル行区切り |

---

## デザイン原則

- **白基調**: 清潔感・可読性を重視した白背景
- **青アクセント**: コーポレートブルー系で信頼感・プロ感を演出
- **フォント**: 日本語対応の `Noto Sans JP` を優先し、英語環境では `Segoe UI` にフォールバック
- **余白**: 上下60px・左右50pxのゆったりした余白で認知負荷を最小化
- **1スライド1メッセージ**: 情報を詰め込まず、1枚のスライドに1つの主張を明確に
