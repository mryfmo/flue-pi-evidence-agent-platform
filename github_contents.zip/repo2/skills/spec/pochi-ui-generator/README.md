# Pochi UI Generator Skill

**Claude Code Skillとして、議事録から3パターンのStreamlitモックアプリを自動生成します。**

## 🎯 概要

このSkillは、ヒアリング議事録などの粗い要件から、以下の3パターンのStreamlitモックアプリを自動生成します：

1. **Pattern 1: Simple** - シンプル型（1画面、基本機能のみ）
2. **Pattern 2: Standard** - 標準型（2画面、推奨構成）← **推奨**
3. **Pattern 3: Advanced** - 高機能型（2画面、高度機能搭載）

## 🚀 使い方

### 基本的な使い方

Claude Codeのチャットで以下のように指示してください：

```
モックアプリを生成して
```

または

```
pochi-ui-generator/input/meeting_notes.md からStreamlitアプリを生成して
```

### トリガーワード一覧

以下のいずれかの表現でSkillが起動します：

- モックアプリを生成して
- UIモックを作成して
- Streamlitアプリを生成して
- 議事録からモックアプリを作成
- ヒアリングからUIモックを生成
- 3パターンのモックアプリを作成
- generate ui mock
- create streamlit app

詳細は [SKILL.md](./SKILL.md) を参照してください。

## 📋 前提条件

### 必須ファイル

1. **議事録ファイル**
   - 場所: `pochi-ui-generator/input/`
   - 形式: Markdown
   - 内容: 顧客とのヒアリング内容、UI要望、データ項目等

2. **プロンプトテンプレート**
   - 場所: `pochi-ui-generator/prompts/all_in_one_generation_prompt.md`
   - 内容: 3パターン生成のための詳細指示

### 環境要件

- Python 3.10
- Poetry（依存関係管理）
- Streamlit 1.40+

## 📤 生成されるもの

### ディレクトリ構成

```
pochi-ui-generator/output/mock_ui/
├── pattern1_simple/           # Pattern 1: Simple
│   ├── main.py               # 1画面のみ
│   ├── lib/
│   │   ├── data_loader.py   # モックデータ生成
│   │   └── utils.py
│   ├── .streamlit/
│   │   └── config.toml      # Pochiカラースキーム
│   ├── pyproject.toml       # Poetry設定
│   └── README.md
├── pattern2_standard/         # Pattern 2: Standard（推奨）
│   ├── main.py               # st.navigation
│   ├── app_pages/
│   │   ├── dashboard.py     # ダッシュボード
│   │   └── data_list.py     # データ一覧
│   ├── lib/
│   │   ├── data_loader.py   # モックデータ生成
│   │   ├── visualizer.py    # グラフ描画
│   │   └── export.py        # CSV出力
│   ├── .streamlit/
│   │   └── config.toml      # Pochiカラースキーム
│   ├── pyproject.toml       # Poetry設定
│   └── README.md
└── pattern3_advanced/         # Pattern 3: Advanced
    ├── main.py               # st.navigation
    ├── app_pages/
    │   ├── dashboard.py     # ダッシュボード
    │   └── analysis.py      # 詳細分析
    ├── lib/
    │   ├── data_loader.py   # モックデータ生成
    │   ├── visualizer.py    # グラフ描画
    │   └── export.py        # CSV + Excel出力
    ├── .streamlit/
    │   └── config.toml      # Pochiカラースキーム
    ├── pyproject.toml       # Poetry設定（openpyxl追加）
    └── README.md
```

## 🎬 生成後の起動方法

### Pattern 1: Simple

```bash
cd pochi-ui-generator/output/mock_ui/pattern1_simple
poetry install
poetry run streamlit run main.py --server.port 8501
# ブラウザで http://localhost:8501 を開く
```

### Pattern 2: Standard（推奨）

```bash
cd pochi-ui-generator/output/mock_ui/pattern2_standard
poetry install
poetry run streamlit run main.py --server.port 8502
# ブラウザで http://localhost:8502 を開く
```

### Pattern 3: Advanced

```bash
cd pochi-ui-generator/output/mock_ui/pattern3_advanced
poetry install
poetry run streamlit run main.py --server.port 8503
# ブラウザで http://localhost:8503 を開く
```

## 📝 各パターンの特徴

### Pattern 1: Simple（シンプル型）

**対象**: 素早く基本確認をしたいユーザー

- 画面数: **1画面**（ダッシュボードのみ）
- グラフ: st.line_chart, st.bar_chart等の簡易グラフ
- フィルター: 最小限（2-3項目）
- エクスポート: なし
- 実装時間: 最短

### Pattern 2: Standard（標準型）← **推奨**

**対象**: 通常業務で使う標準的なユーザー

- 画面数: **2画面**（ダッシュボード + データ一覧）
- グラフ: st.plotly_chart（インタラクティブ）
- フィルター: 標準的（5-7項目）
- エクスポート: CSV（st.download_button）
- 実装時間: 中程度

### Pattern 3: Advanced（高機能型）

**対象**: データアナリスト、パワーユーザー

- 画面数: **2画面**（ダッシュボード + 詳細分析）
- グラフ: plotly詳細設定、複数グラフの連携
- フィルター: 詳細（8-12項目）
- エクスポート: CSV + Excel
- 実装時間: 長め

## 🔧 技術仕様

### 共通技術スタック

- **Python**: 3.10
- **Streamlit**: 1.40+
- **pandas**: 2.0+
- **plotly**: 5.22+
- **Poetry**: 依存関係管理
- **Pochiカラースキーム**: UIガイドライン準拠

### Pochiカラースキーム

すべてのパターンで以下のカラースキームを適用：

```toml
[theme]
primaryColor = "#1E88E5"      # 青
backgroundColor = "#FFFFFF"
secondaryBackgroundColor = "#F0F2F6"
textColor = "#262730"
font = "sans serif"
```

## 💡 使用例

### 例1: 基本的な使い方

```
ユーザー: 「モックアプリを生成して」

↓ Skillが自動で実行

1. 議事録ファイルのパスを確認
2. プロンプトテンプレート読み込み
3. 3パターンのモックアプリ生成
4. 起動方法を案内
```

### 例2: ファイル指定

```
ユーザー: 「pochi-ui-generator/input/ヒアリング-20260108_170025.md からStreamlitアプリを生成して」

↓ Skillが自動で実行

1. 指定されたパスのファイルを読み込み
2. 3パターンのモックアプリ生成
3. 完了報告と起動コマンド案内
```

## 🐛 トラブルシューティング

### Skillが起動しない

**原因**: トリガーワードが認識されていない  
**解決**: 明確なトリガーワードを使用してください

✅ 正しい例:
- 「モックアプリを生成して」
- 「Streamlitアプリを生成」

❌ 間違った例:
- 「アプリを作りたい」（曖昧）
- 「画面を見せて」（別の用途）

### 議事録が見つからない

**原因**: ファイルパスが正しくない  
**解決**: `pochi-ui-generator/input/` にファイルがあるか確認

```bash
ls -la pochi-ui-generator/input/
```

### 生成されたアプリが起動しない

**原因**: 依存関係がインストールされていない  
**解決**:

```bash
cd pochi-ui-generator/output/mock_ui/pattern2_standard
poetry install
```

### ポートが使用中

**原因**: 別のStreamlitアプリが同じポートで起動中  
**解決**: 別のポートを指定

```bash
poetry run streamlit run main.py --server.port 8504
```

## 📚 参照ドキュメント

- [SKILL.md](./SKILL.md) - Skill詳細仕様
- [pochi-ui-generator/prompts/all_in_one_generation_prompt.md](./prompts/all_in_one_generation_prompt.md) - プロンプトテンプレート
- [PochiアプリUIガイドライン](../../../pochi-document-for-developers-v2-repository/pochi_document/docs/manuals/PochiアプリUIガイドライン/) - UIガイドライン

## 🔗 関連Skills

- **pochi-baseline-builder（機能仕様書作成ツール（議事録インプット版））**: ヒアリング議事録からベースライン仕様書を生成
- **pochi-feature-builder（機能仕様書作成ツール（イシュー情報インプット版））**: GitHubイシューから機能仕様書を生成
- **pochi-test-orchestrator**: テストケース生成を統括

## 📅 バージョン情報

- **バージョン**: 1.0.0
- **作成日**: 2026-01-16
- **作成者**: Pochi Development Team
- **ライセンス**: Internal Use Only

---

**🚀 さあ、「モックアプリを生成して」とClaude Codeに指示して、3パターンのStreamlitアプリを自動生成しましょう！**
