---
skill_id: pochi-ui-generator
id: pochi-ui-generator
title: Pochi UI Generator
name: Pochi UI Generator
version: 1.0.0
description: 議事録から3パターン（Simple/Standard/Advanced）のStreamlitモックアプリを作成する際に使用。ユーザーが「モックアプリを生成」「Streamlitアプリを生成」「UIモックを作成」などと依頼した時に起動する。
entrypoint:
  type: prompt
  path: prompts/all_in_one_generation_prompt.md
triggers:
  - モックアプリを生成して
  - UIモックを作成して
  - Streamlitアプリを生成して
  - 議事録からモックアプリを作成
  - ヒアリングからUIモックを生成
  - 3パターンのモックアプリを作成
  - モックUIを生成して
  - generate ui mock
  - create mock ui
  - generate streamlit app
  - UIを生成して
  - アプリのモックを作成
  - プロトタイプを生成
  - mock app作成
  - streamlit prototype
  - Skillツールを使用して pochi-ui-generator を起動してください
  - pochi-ui-generator を起動
  - pochi-ui-generator 起動
  - generate ui mock from hearing
  - create streamlit prototype
  - build mock ui from requirements
  - generate 3 pattern ui
---

# Skill: Pochi UI Generator

**このSkillは、議事録などの粗い要件から3パターン（Simple/Standard/Advanced）のStreamlitモックアプリを自動生成します。**

## Trigger Phrases

**💡 このSkillは、議事録やヒアリング内容から実行可能なStreamlitモックアプリを生成します。**

### Pochi固有トリガー（推奨・明示的）
- モックアプリを生成して
- UIモックを作成して
- Streamlitアプリを生成して
- 議事録からモックアプリを作成
- ヒアリングからUIモックを生成
- 3パターンのモックアプリを作成
- モックUIを生成して
- generate ui mock
- create mock ui
- generate streamlit app

### 汎用トリガー
- UIを生成して
- アプリのモックを作成
- プロトタイプを生成
- mock app作成
- streamlit prototype

### Skill直接起動
- Skillツールを使用して pochi-ui-generator を起動してください
- pochi-ui-generator を起動
- pochi-ui-generator 起動

### 英語トリガー
- generate ui mock from hearing
- create streamlit prototype
- build mock ui from requirements
- generate 3 pattern ui

## When

### 起動条件
上記TriggerPhrasesのいずれかが発話されたら、直ちにこのSkillを起動してください。

### 前提条件
- 議事録ファイルが `skills/pochi-ui-generator/input/` に存在する（Markdown形式）
- プロンプトテンプレート `prompts/all_in_one_generation_prompt.md` が存在する

### 起動しない条件（誤起動防止）
以下のような曖昧な表現では起動しないでください：
- ❌ 「アプリを作りたい」（本番実装と区別が必要）
- ❌ 「画面を見せて」（既存UIの表示）
- ❌ 「UI設計して」（設計のみ、モック生成ではない）

定義されたトリガーワードとの明確な一致が必要です。

## Do

**シンプルな4ステップで実行します：**

### ステップ1: 議事録ファイルの確認
ユーザーに議事録ファイルのパスを確認してください：
```
「議事録ファイルのパスを教えてください
（例: skills/pochi-ui-generator/input/meeting_notes.md）

または、skills/pochi-ui-generator/input/ 内のファイル一覧から選択してください。」
```

ユーザーが既にパスを指定している場合は、このステップをスキップしてください。

**自動検出**:
- `skills/pochi-ui-generator/input/` 内のMarkdownファイルを自動検出
- ファイルが1つのみの場合は自動選択
- 複数ある場合はユーザーに選択を促す

### ステップ2: プロンプトテンプレートの読み込み
以下のプロンプトテンプレートを読み込んでください：
```
prompts/all_in_one_generation_prompt.md
```

このテンプレートには、3パターン（Simple/Standard/Advanced）のStreamlitアプリ生成のための詳細な指示が含まれています。

### ステップ3: 3パターンのモックアプリを生成
プロンプトテンプレートに従って、以下の作業を実行してください：

1. **議事録ファイルを読み込む**
   - ユーザーが指定したパスのファイルを読み込み

2. **Pattern 1: Simple（シンプル型）を生成**
   - 画面数: 1画面（ダッシュボードのみ）
   - グラフ: st.line_chart, st.bar_chart等の簡易グラフ
   - フィルター: 最小限（2-3項目）
   - 出力先: `skills/pochi-ui-generator/output/mock_ui/pattern1_simple/`
   - 以下のファイルを生成:
     - `main.py` - エントリーポイント
     - `lib/data_loader.py` - モックデータ生成
     - `lib/utils.py` - ユーティリティ
     - `.streamlit/config.toml` - ミニマル設定
     - `pyproject.toml` - Poetry設定
     - `run_app.sh` - 起動スクリプト
     - `deployment_config.json` - GCP Cloud Run設定
     - `README.md` - 実行手順

3. **Pattern 2: Standard（標準型）を生成** ← **推奨**
   - 画面数: 2画面（ダッシュボード + データ一覧）
   - グラフ: st.plotly_chart（インタラクティブ）
   - フィルター: 標準的（5-7項目）
   - エクスポート: CSV（st.download_button）
   - 出力先: `skills/pochi-ui-generator/output/mock_ui/pattern2_standard/`
   - 以下のファイルを生成:
     - `main.py` - エントリーポイント（st.navigation）
     - `app_pages/dashboard.py` - ダッシュボード
     - `app_pages/data_list.py` - データ一覧
     - `lib/data_loader.py` - モックデータ生成
     - `lib/visualizer.py` - グラフ描画
     - `lib/export.py` - CSV出力機能
     - `.streamlit/config.toml` - ミニマル設定
     - `pyproject.toml` - Poetry設定
     - `run_app.sh` - 起動スクリプト
     - `deployment_config.json` - GCP Cloud Run設定
     - `README.md` - 実行手順

4. **Pattern 3: Advanced（高機能型）を生成**
   - 画面数: 2画面（ダッシュボード + 詳細分析）
   - グラフ: plotly詳細設定、複数グラフの連携
   - フィルター: 詳細（8-12項目）
   - エクスポート: CSV + Excel
   - 出力先: `skills/pochi-ui-generator/output/mock_ui/pattern3_advanced/`
   - 以下のファイルを生成:
     - `main.py` - エントリーポイント（st.navigation）
     - `app_pages/dashboard.py` - ダッシュボード
     - `app_pages/analysis.py` - 詳細分析
     - `lib/data_loader.py` - モックデータ生成
     - `lib/visualizer.py` - グラフ描画
     - `lib/export.py` - CSV + Excel出力機能
     - `.streamlit/config.toml` - ミニマル設定
     - `pyproject.toml` - Poetry設定（openpyxl追加）
     - `run_app.sh` - 起動スクリプト
     - `deployment_config.json` - GCP Cloud Run設定
     - `README.md` - 実行手順

### ステップ4: 完了報告と起動方法の案内
生成完了後、以下を報告：
```
「3パターンのモックUIを生成しました。

【Pattern 1: Simple】
- 出力先: skills/pochi-ui-generator/output/mock_ui/pattern1_simple/
- 画面数: 1画面
- 起動: cd skills/pochi-ui-generator/output/mock_ui/pattern1_simple && ./run_app.sh

【Pattern 2: Standard】← 推奨
- 出力先: skills/pochi-ui-generator/output/mock_ui/pattern2_standard/
- 画面数: 2画面（ダッシュボード + データ一覧）
- 起動: cd skills/pochi-ui-generator/output/mock_ui/pattern2_standard && ./run_app.sh

【Pattern 3: Advanced】
- 出力先: skills/pochi-ui-generator/output/mock_ui/pattern3_advanced/
- 画面数: 2画面（ダッシュボード + 詳細分析）
- 起動: cd skills/pochi-ui-generator/output/mock_ui/pattern3_advanced && ./run_app.sh

各パターンを起動後、ブラウザで http://localhost:8501 を開いてください。

オプション:
- `./run_app.sh --no-bandit`: banditチェックをスキップ
- `./run_app.sh --no-poetry-update`: poetry環境構築をスキップ」
```

## Instructions

### 詳細な実行手順

#### 1. 入力確認
```markdown
【確認】
- 議事録ファイル: {hearing_file_path}
- 出力先: skills/pochi-ui-generator/output/mock_ui/
  - pattern1_simple/
  - pattern2_standard/
  - pattern3_advanced/

この設定で3パターンのモックアプリを生成しますか？
```

#### 2. プロンプトテンプレート適用
`prompts/all_in_one_generation_prompt.md`に従って生成：
- 技術スタック: Python 3.10, Streamlit 1.40+, pandas 2.0+, plotly 5.22+
- 依存関係管理: Poetry
- Pochiカラースキーム: .streamlit/config.toml

#### 3. 共通実装ポイント

##### モックデータ生成（lib/data_loader.py）
```python
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_mock_data(n_records: int = 100) -> pd.DataFrame:
    """議事録の要件に基づいたリアルなサンプルデータを生成"""
    # 議事録から抽出した項目に基づいてデータ生成
    ...
```

##### Pochiカラースキーム（.streamlit/config.toml）
```toml
[theme]
primaryColor = "#1E88E5"
backgroundColor = "#FFFFFF"
secondaryBackgroundColor = "#F0F2F6"
textColor = "#262730"
font = "sans serif"
```

##### Poetry設定（pyproject.toml）
```toml
[tool.poetry]
name = "pochi-{pattern-name}-mock-ui"
version = "0.1.0"
description = "PochiモックUI - {Pattern Name}"
package-mode = false

[tool.poetry.dependencies]
python = "~3.10"
streamlit = "^1.40.0"
pandas = "^2.0.0"
plotly = "^5.22.0"
numpy = "^1.24.0"
# Pattern 3のみ: openpyxl = "^3.1.0"
```

#### 4. 品質確認
生成後、以下を自己チェック：
- [ ] 3パターンすべてが生成されているか
- [ ] 各パターンに必須ファイルが含まれているか
- [ ] Pochiカラースキームが適用されているか
- [ ] モックデータ生成ロジックが議事録の要件を反映しているか
- [ ] 実行可能なコードとして完成しているか

## Don't

### 実行禁止事項
- ❌ **議事録を読まずに生成しない**
  - 必ず議事録内容に基づいてモックデータとUI要素を決定してください

- ❌ **不完全なアプリを生成しない**
  - 各パターンは独立して実行可能でなければなりません

- ❌ **本番用コードを生成しない**
  - これはモックアプリです。Snowflake接続等の本番機能は含めません

- ❌ **Pochiガイドラインを無視しない**
  - UIカラー、レイアウトはPochiガイドラインに準拠してください

- ❌ **ハードコードされた値を使わない**
  - モックデータは`lib/data_loader.py`で動的に生成してください

## Inputs

### 必須入力
- **議事録ファイル**
  - 形式: Markdown
  - パス例: `skills/pochi-ui-generator/input/meeting_notes.md`
  - 内容: 顧客とのヒアリング内容、UI要望、データ項目等

### 参照ドキュメント（自動参照）
- `prompts/all_in_one_generation_prompt.md`: プロンプトテンプレート
- `pochi-document-for-developers-v2-repository/pochi_document/docs/manuals/PochiアプリUIガイドライン/`: UIガイドライン

## Outputs

### 主要成果物

#### Pattern 1: Simple
```
pattern1_simple/
├── main.py                    # 1画面のみ
├── lib/
│   ├── data_loader.py        # モックデータ生成
│   └── utils.py              # ユーティリティ
├── .streamlit/
│   └── config.toml           # Pochiカラースキーム
├── pyproject.toml            # Poetry設定
└── README.md                 # 実行手順
```

#### Pattern 2: Standard（推奨）
```
pattern2_standard/
├── main.py                    # st.navigation
├── app_pages/
│   ├── dashboard.py          # ダッシュボード
│   └── data_list.py          # データ一覧
├── lib/
│   ├── data_loader.py        # モックデータ生成
│   ├── visualizer.py         # グラフ描画
│   └── export.py             # CSV出力
├── .streamlit/
│   └── config.toml           # Pochiカラースキーム
├── pyproject.toml            # Poetry設定
└── README.md                 # 実行手順
```

#### Pattern 3: Advanced
```
pattern3_advanced/
├── main.py                    # st.navigation
├── app_pages/
│   ├── dashboard.py          # ダッシュボード
│   └── analysis.py           # 詳細分析
├── lib/
│   ├── data_loader.py        # モックデータ生成
│   ├── visualizer.py         # グラフ描画
│   └── export.py             # CSV + Excel出力
├── .streamlit/
│   └── config.toml           # Pochiカラースキーム
├── pyproject.toml            # Poetry設定（openpyxl追加）
└── README.md                 # 実行手順
```

## Troubleshooting

### Skillが起動しない場合

#### 1. トリガーワードを確認
- ✅ 「モックアプリを生成して」（推奨）
- ✅ 「Streamlitアプリを生成」
- ❌ 「アプリを作りたい」（トリガーに未登録）

#### 2. SKILL.mdの配置を確認
```bash
ls -la skills/pochi-ui-generator/SKILL.md
```

### 生成エラーが発生する場合

#### エラー: 「議事録が見つかりません」
**原因**: ファイルパスが正しくない  
**解決**: `skills/pochi-ui-generator/input/` 内のファイルを確認してください

#### エラー: 「プロンプトテンプレートが見つかりません」
**原因**: prompts/all_in_one_generation_prompt.mdが存在しない  
**解決**: プロンプトテンプレートの配置を確認してください

### 生成されたアプリが起動しない場合

#### エラー: 「Permission denied」（run_app.sh実行時）
**原因**: 実行権限が付与されていない
**解決**:
```bash
cd skills/pochi-ui-generator/output/mock_ui/pattern2_standard
chmod +x run_app.sh
./run_app.sh
```

#### エラー: 「jq: command not found」
**原因**: jqコマンドがインストールされていない
**解決**:
```bash
# macOS
brew install jq

# Ubuntu/Debian
sudo apt-get install jq
```

#### エラー: 「bandit: command not found」
**原因**: banditがインストールされていない
**解決**: banditチェックをスキップするか、インストール
```bash
# スキップする場合
./run_app.sh --no-bandit

# インストールする場合
pipx install bandit
```

#### エラー: 「モジュールが見つかりません」
**原因**: 依存関係がインストールされていない
**解決**: poetry環境構築を実行
```bash
cd skills/pochi-ui-generator/output/mock_ui/pattern2_standard
./run_app.sh  # poetry installも自動実行されます
```

#### エラー: 「ポートが使用中」
**原因**: 別のStreamlitアプリが同じポートで起動中
**解決**: 環境変数でポートを変更
```bash
STREAMLIT_SERVER_PORT=8504 ./run_app.sh
```

## 使用例

### 例1: 基本的な使い方
```
ユーザー: 「モックアプリを生成して」

エージェント: 「議事録ファイルのパスを教えてください」

ユーザー: 「skills/pochi-ui-generator/input/meeting_notes.md」

エージェント:
1. meeting_notes.mdを読み込み
2. プロンプトテンプレートに従って3パターン生成
   - Pattern 1: Simple
   - Pattern 2: Standard（推奨）
   - Pattern 3: Advanced
3. 各パターンにrun_app.shとdeployment_config.jsonを含めて完成
4. 起動方法を案内:
   cd skills/pochi-ui-generator/output/mock_ui/pattern2_standard && ./run_app.sh
```

### 例2: 起動オプションの使用
```bash
# 初回起動（banditチェック込み）
cd skills/pochi-ui-generator/output/mock_ui/pattern2_standard
./run_app.sh

# 2回目以降（高速起動）
./run_app.sh --no-bandit --no-poetry-update

# カスタムポート
STREAMLIT_SERVER_PORT=8504 ./run_app.sh
```

## Notes

- 本番アプリと同じrun_app.shを使用するため、起動方法が統一されています
- deployment_config.jsonはモックアプリ用のデフォルト値（use_cloud_storage_fuse: false）を設定
- .streamlit/config.tomlはミニマル設定（本番アプリと同等）
- 3パターンすべてが独立したアプリとして実行可能です
