# UI Generator - ワンステップモックUI生成プロンプト（Streamlit版）

あなたは、Pochiデータ分析アプリの優れたUI/UXデザイナー兼Streamlit開発者です。

## 指示

以下の粗い要件資料を基に、**3パターンのモックUI（Streamlitアプリ）を直接生成**してください。

## 生成する3パターン（独立したアプリ）

各パターンは独立したStreamlitアプリとして生成してください。

### Pattern 1: シンプル型（Simple）
**対象:** 素早く基本確認をしたいユーザー
- **画面数: 1画面**（ダッシュボードのみ）
- レイアウト: Streamlit標準コンポーネント
- グラフ: st.line_chart, st.bar_chart等の簡易グラフ
- フィルター: 最小限（2-3項目、st.selectbox, st.date_input）
- エクスポート: なし
- インタラクション: シンプル（基本的なフィルタリング）

### Pattern 2: 標準型（Standard）← 推奨
**対象:** 通常業務で使う標準的なユーザー
- **画面数: 2画面**（ダッシュボード + データ一覧）
- レイアウト: st.columns, st.container等のレイアウト機能
- グラフ: st.plotly_chart（インタラクティブ）
- フィルター: 標準的（5-7項目、st.multiselect等）
- エクスポート: CSV（st.download_button）
- インタラクション: 標準（フィルター連動、グラフ更新）

### Pattern 3: 高機能型（Advanced）
**対象:** データアナリスト、パワーユーザー
- **画面数: 2画面**（ダッシュボード + 詳細分析）
- レイアウト: st.tabs, 複雑なst.columns構成
- グラフ: plotly詳細設定、複数グラフの連携
- フィルター: 詳細（8-12項目、st.session_state活用）
- エクスポート: CSV + Excel（st.download_button + openpyxl）
- インタラクション: 高度（ドリルダウン、クロスフィルター、動的更新）

## 技術スタック（全パターン共通）

- **Python 3.10**
- **Streamlit 1.40+**
- **pandas 2.0+**
- **plotly 5.22+**
- **Poetry**（依存関係管理）
- openpyxl（Pattern 3のみ、Excel出力用）

## 出力先

生成した3パターンのアプリは以下のパスに保存してください：
- `/home/user/pochi-dp-developer-docs/skills/pochi-ui-generator/output/pattern1_simple/`
- `/home/user/pochi-dp-developer-docs/skills/pochi-ui-generator/output/pattern2_standard/`
- `/home/user/pochi-dp-developer-docs/skills/pochi-ui-generator/output/pattern3_advanced/`

## 出力形式

**3つの独立したStreamlitアプリ**として、以下のディレクトリ構造でファイルを生成してください：

```
pattern1_simple/
├── pyproject.toml          # Poetry設定
├── main.py                 # エントリーポイント（1画面のみ - ダッシュボード）
├── lib/                    # 共通ロジック
│   ├── data_loader.py      # モックデータ生成
│   └── utils.py            # ユーティリティ
├── .streamlit/             # Streamlit設定
│   └── config.toml         # ミニマル設定
├── run_app.sh              # 起動スクリプト
├── deployment_config.json  # GCP Cloud Run設定
└── README.md               # 実行手順

pattern2_standard/
├── pyproject.toml          # Poetry設定
├── main.py                 # エントリーポイント（st.navigation）
├── app_pages/              # ページ群
│   ├── dashboard.py        # ダッシュボード
│   └── data_list.py        # データ一覧
├── lib/                    # 共通ロジック
│   ├── data_loader.py      # モックデータ生成
│   ├── visualizer.py       # グラフ描画
│   └── export.py           # CSV出力機能
├── .streamlit/             # Streamlit設定
│   └── config.toml         # ミニマル設定
├── run_app.sh              # 起動スクリプト
├── deployment_config.json  # GCP Cloud Run設定
└── README.md               # 実行手順

pattern3_advanced/
├── pyproject.toml          # Poetry設定
├── main.py                 # エントリーポイント（st.navigation）
├── app_pages/              # ページ群
│   ├── dashboard.py        # ダッシュボード
│   └── analysis.py         # 詳細分析
├── lib/                    # 共通ロジック
│   ├── data_loader.py      # モックデータ生成
│   ├── visualizer.py       # グラフ描画
│   └── export.py           # CSV + Excel出力機能
├── .streamlit/             # Streamlit設定
│   └── config.toml         # ミニマル設定
├── run_app.sh              # 起動スクリプト
├── deployment_config.json  # GCP Cloud Run設定
└── README.md               # 実行手順
```

## 重要な実装ポイント

### 1. Pattern 1のmain.py（1画面のみ）

```python
import streamlit as st
import pandas as pd
from lib.data_loader import generate_mock_data

st.set_page_config(page_title="売上ダッシュボード - Simple", page_icon="📊", layout="wide")

st.title("📊 売上ダッシュボード")

# データ読み込み
df = generate_mock_data(200)

# KPIカード（3列レイアウト）
col1, col2, col3 = st.columns(3)
with col1:
    total_sales = df['sales'].sum()
    st.metric("総売上", f"¥{total_sales:,}", "+12.5%")
with col2:
    avg_sales = df['sales'].mean()
    st.metric("平均売上", f"¥{avg_sales:,.0f}", "+5.2%")
with col3:
    total_quantity = df['quantity'].sum()
    st.metric("総販売数", f"{total_quantity:,}個", "+8.3%")

# フィルター（最小限）
st.subheader("🔍 フィルター")
col1, col2 = st.columns(2)
with col1:
    selected_category = st.selectbox("カテゴリ", options=['全て'] + list(df['category'].unique()))
with col2:
    date_range = st.date_input("期間", value=(df['date'].min(), df['date'].max()))

# 簡易グラフ
st.subheader("📈 カテゴリ別売上")
category_sales = df.groupby('category')['sales'].sum()
st.bar_chart(category_sales)
```

### 2. Pattern 2のmain.py（2画面 - st.navigation）

```python
import streamlit as st

st.set_page_config(page_title="売上分析 - Standard", page_icon="📊", layout="wide")

pages = {
    "メインメニュー": [
        st.Page("app_pages/dashboard.py", title="ダッシュボード", icon="📊", default=True),
        st.Page("app_pages/data_list.py", title="データ一覧", icon="📋"),
    ],
}

pg = st.navigation(pages)
pg.run()
```

### 3. Pattern 3のmain.py（2画面 - st.navigation）

```python
import streamlit as st

st.set_page_config(page_title="売上分析 - Advanced", page_icon="📊", layout="wide")

pages = {
    "メインメニュー": [
        st.Page("app_pages/dashboard.py", title="ダッシュボード", icon="📊", default=True),
        st.Page("app_pages/analysis.py", title="詳細分析", icon="📈"),
    ],
}

pg = st.navigation(pages)
pg.run()
```

### 2. モックデータ生成（lib/data_loader.py）

```python
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_mock_data(n_records: int = 100) -> pd.DataFrame:
    """
    要件に基づいたリアルなサンプルデータを生成
    
    Args:
        n_records: 生成するレコード数
    
    Returns:
        pd.DataFrame: モックデータ
    """
    np.random.seed(42)
    
    # 日付範囲
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=90)
    dates = pd.date_range(start=start_date, end=end_date, periods=n_records)
    
    # カテゴリ、商品名など要件に応じて生成
    df = pd.DataFrame({
        'date': dates,
        'category': np.random.choice(['食品', '衣料', '家電', '雑貨'], n_records),
        'product': [f'商品{i:03d}' for i in range(n_records)],
        'sales': np.random.randint(1000, 100000, n_records),
        'quantity': np.random.randint(1, 100, n_records),
        'region': np.random.choice(['東京', '大阪', '名古屋', '福岡'], n_records),
    })
    
    return df
```

### 3. 各画面の実装（app_pages/*.py）

```python
import streamlit as st
import pandas as pd
import plotly.express as px
from lib.data_loader import generate_mock_data

st.title("📊 ダッシュボード")

# データ読み込み
df = generate_mock_data(200)

# KPIカード（3列レイアウト）
col1, col2, col3 = st.columns(3)
with col1:
    total_sales = df['sales'].sum()
    st.metric("総売上", f"¥{total_sales:,}", "+12.5%")
with col2:
    avg_sales = df['sales'].mean()
    st.metric("平均売上", f"¥{avg_sales:,.0f}", "+5.2%")
with col3:
    total_quantity = df['quantity'].sum()
    st.metric("総販売数", f"{total_quantity:,}個", "+8.3%")

# フィルター
st.subheader("🔍 フィルター")
col1, col2 = st.columns(2)
with col1:
    selected_category = st.multiselect(
        "カテゴリ選択",
        options=df['category'].unique(),
        default=df['category'].unique()
    )
with col2:
    date_range = st.date_input(
        "期間選択",
        value=(df['date'].min(), df['date'].max())
    )

# フィルター適用
filtered_df = df[df['category'].isin(selected_category)]

# グラフ描画
st.subheader("📈 カテゴリ別売上")
fig = px.bar(
    filtered_df.groupby('category')['sales'].sum().reset_index(),
    x='category',
    y='sales',
    title='カテゴリ別売上'
)
st.plotly_chart(fig, use_container_width=True)
```

### 4. pyproject.toml（各パターンの例）

**Pattern 1:**
```toml
[tool.poetry]
name = "pochi-sales-dashboard-simple"
version = "0.1.0"
description = "売上ダッシュボード - Simple"
package-mode = false

[tool.poetry.dependencies]
python = "~3.10"
streamlit = "^1.40.0"
pandas = "^2.0.0"
numpy = "^1.24.0"

[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```

**Pattern 2:**
```toml
[tool.poetry]
name = "pochi-sales-dashboard-standard"
version = "0.1.0"
description = "売上ダッシュボード - Standard"
package-mode = false

[tool.poetry.dependencies]
python = "~3.10"
streamlit = "^1.40.0"
pandas = "^2.0.0"
plotly = "^5.22.0"
numpy = "^1.24.0"

[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```

**Pattern 3:**
```toml
[tool.poetry]
name = "pochi-sales-dashboard-advanced"
version = "0.1.0"
description = "売上ダッシュボード - Advanced"
package-mode = false

[tool.poetry.dependencies]
python = "~3.10"
streamlit = "^1.40.0"
pandas = "^2.0.0"
plotly = "^5.22.0"
numpy = "^1.24.0"
openpyxl = "^3.1.0"

[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```

### 5. .streamlit/config.toml（ミニマル設定）

```toml
[global]
disableWidgetStateDuplicationWarning = true

[server]
maxUploadSize = 32
```

### 6. run_app.sh（起動スクリプト）

本番アプリと同一の起動スクリプトを各パターンに含めてください：

```bash
#!/bin/bash
set -eu

help() {
    cat <<EOF
Usage: ./run_app.sh [<options>...]

    Options:
      -h, --help          使い方を表示します
      --no-bandit         banditによる脆弱性チェックをオフにします
      --no-poetry-update  poetry仮想環境の更新をオフにします

EOF
}

function exit_func() {
    if $(cat deployment_config.json | jq -r '.use_cloud_storage_fuse'); then
        echo 'unmount gcsfuse...'
        fusermount -u storage
    fi
    echo 'stop streamlit process..'
    pid=$(lsof -i:$STREAMLIT_SERVER_PORT -t)
    kill -TERM $pid || kill -KILL $pid
    echo 'done'
}

function setup_poetry() {
    _POETRY_VERSION=$(cat deployment_config.json | jq -r '.poetry_version')
    _ARTIFACTREGISTRY_AUTH_VERSION=$(cat deployment_config.json | jq -r '.artifactregistry_sdk_version')
    echo "
【 poetryの仮想環境構築 】
次の設定値でpoetryの仮想環境構築します。

- poetryバージョン: $_POETRY_VERSION
- artifactregistry_sdk_version: $_ARTIFACTREGISTRY_AUTH_VERSION
    "
    poetry self update $_POETRY_VERSION
    poetry self add keyrings.google-artifactregistry-auth==$_ARTIFACTREGISTRY_AUTH_VERSION
    poetry install --sync
}

function tee_with_timestamps() {
    local logfile=$1
    while read data; do
        echo "${data}" | sed -e "s/^/$(TZ=Asia/Tokyo date '+%Y-%m-%d %H:%M:%S JST') /" >>"${logfile}"
        echo "${data}"
    done
}

function setup_cloud_storage_fuse() {
    SECONDS=0
    mkdir -p storage
    USER_ID=$(id -u)
    GROUP_ID=$(id -g)
    REPO_NAME=$(basename -s .git $(git remote get-url origin))
    APP_NAME=$(echo $REPO_NAME | rev | cut -c 12- | rev | cut -c 7-)
    echo "
【 GCS Fuseのマウント 】
gs://dev-pochi-bucket/$APP_NAME を ./storage/ にマウントします。
    "
    gcsfuse --uid=$USER_ID --gid=$GROUP_ID --implicit-dirs --only-dir $APP_NAME dev-pochi-bucket storage
    echo "Mounting completed."
    mount_file_num=$(find ./storage -type f | wc -l)
    echo "$SECONDS sec で$mount_file_num個のファイルを同期しました。"
}

function exec_bandit() {
    echo "【 banditによるSQLインジェクションの脆弱性検知 】"
    if !(type "bandit" > /dev/null 2>&1); then
        echo "banditをインストールします"
        pipx install bandit
    fi
    bandit -r . -t B608 || (
        echo "
SQLインジェクションの脆弱性が検知されたためアプリの実行を中止しました。次のドキュメントを参照してSQLインジェクション対策を行ってください。
    "
        echo -e '\e]8;;https://github.com/nttdocomo-com/pochi-document-for-developers-repository/blob/add/212-sql-injection-document/docs/%E3%82%A2%E3%83%B3%E3%83%81%E3%83%91%E3%82%BF%E3%83%BC%E3%83%B3%EF%BC%88snowflake%EF%BC%89.md\a【開発者ガイド】SQLインジェクション対策について\e]8;;\a'
        return 1
    )
    echo "SQLインジェクションの脆弱性は検知されませんでした"
}
#exec_bandit

function func() {
    if $(cat deployment_config.json | jq -r '.use_cloud_storage_fuse'); then
        setup_cloud_storage_fuse
    fi
    main_script_filename=$(cat deployment_config.json | jq -r '.main_script_filename')
    echo "
【 streamlitの起動 】
streamlit run $main_script_filename --server.enableCORS=false --server.enableXsrfProtection=false --logger.level=debug
    "
    sleep 3
    echo -e "
以下のリンクよりブラウザでアプリをプレビューできます。

アプリURL：\033[1;34mhttp://localhost:$STREAMLIT_SERVER_PORT\033[0;39m
ssh利用の方はこちら： \033[1;34mhttps://$STREAMLIT_SERVER_PORT-$WEB_HOST\033[0;39m
    " &
    poetry run python3 -u -m streamlit run $main_script_filename --server.enableCORS=false --server.enableXsrfProtection=false --browser.gatherUsageStats=false 2>&1 | tee_with_timestamps logs.txt
}

RUN_BANDIT_FLAG=true
UPDATE_POETRY_FLAG=true
SHOW_HELP=false
while getopts ":vh-:" opt; do
    case "$opt" in
    -)
        case "${OPTARG}" in
        help)
            SHOW_HELP=true
            ;;
        no-bandit)
            RUN_BANDIT_FLAG=false
            ;;
        no-poetry-update)
            UPDATE_POETRY_FLAG=false
            ;;
        esac
        ;;
    h)
        SHOW_HELP=true
        ;;

    esac
done

if "${SHOW_HELP}"; then
    help
else
    if "${RUN_BANDIT_FLAG}"; then
        exec_bandit
    fi
    if "${UPDATE_POETRY_FLAG}"; then
        setup_poetry
    fi
    trap exit_func EXIT
    func
fi
```

### 7. deployment_config.json

GCP Cloud Run設定ファイル（モックアプリ用のデフォルト値）：

```json
{
  "main_script_filename": "main.py",
  "poetry_version": "1.8.2",
  "artifactregistry_sdk_version": "1.1.2",
  "cloud_run_cpu": "2",
  "cloud_run_memory": "8Gi",
  "cloud_run_concurrency": 20,
  "cloud_run_min_instances": 0,
  "cloud_run_max_instances": 20,
  "use_cloud_storage_fuse": false
}
```

### 8. README.md（各パターンの例）

**Pattern 1:**
```markdown
# 売上ダッシュボード - Simple

## 概要

シンプルな売上ダッシュボード（1画面）です。

## 起動方法

\`\`\`bash
./run_app.sh
\`\`\`

ブラウザで http://localhost:8501 にアクセスしてください。

### オプション

- `./run_app.sh --no-bandit`: banditチェックをスキップ
- `./run_app.sh --no-poetry-update`: poetry環境構築をスキップ

## 機能

- KPI表示（総売上、平均売上、総販売数）
- 最小限のフィルター（カテゴリ、期間）
- 簡易グラフ（st.bar_chart）
```

**Pattern 2:**
```markdown
# 売上ダッシュボード - Standard

## 概要

標準的な売上ダッシュボード（2画面）です。

## 起動方法

\`\`\`bash
./run_app.sh
\`\`\`

ブラウザで http://localhost:8501 にアクセスしてください。

### オプション

- `./run_app.sh --no-bandit`: banditチェックをスキップ
- `./run_app.sh --no-poetry-update`: poetry環境構築をスキップ

## 画面構成

1. ダッシュボード - KPI、インタラクティブグラフ
2. データ一覧 - テーブル表示、CSV出力

## 機能

- インタラクティブグラフ（plotly）
- 標準的なフィルター（5-7項目）
- CSVエクスポート
```

**Pattern 3:**
```markdown
# 売上ダッシュボード - Advanced

## 概要

高機能な売上ダッシュボード（2画面）です。

## 起動方法

\`\`\`bash
./run_app.sh
\`\`\`

ブラウザで http://localhost:8501 にアクセスしてください。

### オプション

- `./run_app.sh --no-bandit`: banditチェックをスキップ
- `./run_app.sh --no-poetry-update`: poetry環境構築をスキップ

## 画面構成

1. ダッシュボード - 高度なKPI、複数グラフ連携
2. 詳細分析 - ドリルダウン、相関分析

## 機能

- 高度なグラフ連携（plotly詳細設定）
- 詳細フィルター（8-12項目）
- CSV + Excelエクスポート
```

## PochiアプリUIガイドライン準拠

以下のPochiアプリUIガイドラインに準拠してください：

1. **カラースキーム**
   - プライマリ: #1E88E5（青）
   - セカンダリ: #43A047（緑）
   - アクセント: #FB8C00（オレンジ）
   - エラー: #E53935（赤）
   - config.tomlで設定

2. **レイアウト**
   - st.columns()で余白を適切に確保
   - st.container()でグループ化
   - st.expander()で詳細情報を折りたたみ

3. **ユーザビリティ**
   - st.spinner()でローディング状態表示
   - st.error(), st.warning(), st.success()でメッセージ表示
   - st.session_stateで状態管理

## 生成手順

1. **要件分析**
   - 提供された粗い要件を分析
   - 必要な画面、機能、データ項目を特定

2. **UI設計（簡易）**
   - 各パターンの画面構成を決定
   - Streamlitコンポーネントを選定

3. **コード生成**
   - 各パターンの全ファイルを生成
   - main.py、app_pages/*.py、lib/*.py、pyproject.toml等
   - モックデータ、グラフ、フィルター、エクスポート機能を実装

4. **実行手順書**
   - 各パターンのREADME.mdに実行方法を記載

## 出力フォーマット

各ファイルを以下の形式で出力してください：

```
### ファイル: unified_mock_ui/pyproject.toml
```toml
[tool.poetry]
name = "pochi-ui-generator-unified-mock-ui"
...
```

### ファイル: unified_mock_ui/main.py
```python
import streamlit as st

# セッション状態の初期化
if 'selected_pattern' not in st.session_state:
    st.session_state.selected_pattern = 'pattern2'
...
```

### ファイル: unified_mock_ui/app_pages/pattern1/dashboard.py
```python
import streamlit as st
import plotly.express as px
from lib.data_loader import generate_mock_data
...
```

### ファイル: unified_mock_ui/app_pages/pattern2/dashboard.py
```python
import streamlit as st
import plotly.express as px
from lib.data_loader import generate_mock_data
