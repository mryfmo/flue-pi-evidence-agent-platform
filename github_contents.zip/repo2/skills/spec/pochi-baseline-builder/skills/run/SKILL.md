---
skill_id: pochi-baseline-builder
id: pochi-baseline-builder
title: 機能仕様書作成ツール（議事録インプット版）
name: 機能仕様書作成ツール（議事録インプット版）
version: 1.0.0
description: ヒアリング議事録やGitHubイシューからPochiアプリのベースライン仕様書を作成する際に使用。ユーザーが「議事録から機能仕様書を生成」「イシューから機能仕様書を作成」「機能仕様書を作成して」「仕様書を作成して」などと依頼した時に起動する。
entrypoint:
  type: prompt
  path: prompts/hearing_to_baseline.md
triggers:
  - 議事録から機能仕様書を作成して
  - ヒアリングから機能仕様書を生成
  - イシューから機能仕様書を作成して
  - 議事録から機能仕様書を生成
  - 機能仕様書を作成して
  - 機能仕様書を生成
  - 仕様書を作成して
  - 仕様書を生成
  - hearing to baseline spec
  - hearing to baseline
  - issue to baseline spec
  - ヒアリングからPochi仕様書作成
  - baseline specを生成
  - baseline specを作成
  - Pochi仕様書作成
  - Skillツールを使用して pochi-baseline-builder を起動してください
  - pochi-baseline-builder を起動
  - pochi-baseline-builder 起動
  - generate baseline spec from hearing
  - create baseline spec from minutes
  - hearing minutes to baseline
  - build baseline from interview
---

# Skill: 機能仕様書作成ツール（議事録インプット版）

**このSkillは、ヒアリング議事録からPochiアプリのベースライン仕様書を自動生成します。**

## Trigger Phrases

**💡 このSkillは、ヒアリング議事録またはGitHubイシューからベースライン仕様書を生成します。**

### Pochi固有トリガー（推奨・明示的）
- 議事録から機能仕様書を作成して
- ヒアリングから機能仕様書を生成
- イシューから機能仕様書を作成して
- 議事録から機能仕様書を生成
- hearing to baseline spec
- hearing to baseline
- issue to baseline spec
- ヒアリングからPochi仕様書作成

### 汎用トリガー（インプット種別は後で選択）
- 機能仕様書を作成して
- 機能仕様書を生成
- 仕様書を作成して
- 仕様書を生成
- baseline specを生成
- baseline specを作成
- Pochi仕様書作成

### Skill直接起動
- Skillツールを使用して pochi-baseline-builder を起動してください
- pochi-baseline-builder を起動
- pochi-baseline-builder 起動

### 英語トリガー
- generate baseline spec from hearing
- create baseline spec from minutes
- hearing minutes to baseline
- build baseline from interview

## When

### 起動条件
上記TriggerPhrasesのいずれかが発話されたら、直ちにこのSkillを起動してください。

### 前提条件
- ヒアリング議事録ファイルが存在する（Markdown形式）
- プロンプトテンプレート `prompts/hearing_to_baseline.md` が存在する

### 起動しない条件（誤起動防止）
以下のような曖昧な表現では起動しないでください：
- ❌ 「仕様を作りたい」
- ❌ 「ドキュメントを作成」
- ❌ 「レビューして」

定義されたトリガーワードとの明確な一致が必要です。

**インプット種別のサポート:**
- ✅ 議事録 → ベースライン仕様書: **このSkill（推奨）**
- ✅ イシュー → ベースライン仕様書: **このSkill（対応可能）**
- ℹ️ イシュー → 機能仕様書: **pochi-feature-builder**

**注意:** 通常、ベースライン仕様書はヒアリング議事録から作成するのが一般的です。イシューから作成する場合は、アプリ全体に関わる大きな変更を扱う場合に限定されます。

## Do

**シンプルな4ステップで実行します：**

### ステップ1: インプット種別の確認
ユーザーがインプット種別を明示していない場合、確認してください：
```
「どちらから生成しますか？
1. ヒアリング議事録から生成（推奨）
2. GitHubイシューから生成」
```

**推奨事項:**
- 通常はヒアリング議事録を推奨してください
- イシューを選択する場合は、「アプリ全体に影響する大きな変更の場合のみ推奨」と案内

### ステップ1-A: ヒアリング議事録の確認（議事録を選択した場合）
ユーザーにヒアリング議事録のパスを確認してください：
```
「ヒアリング議事録のファイルパスを教えてください（例: skills/pochi-baseline-builder/input/meeting_notes.md）」
```

### ステップ1-B: イシュー情報の確認（イシューを選択した場合）
ユーザーにイシュー番号または情報を確認してください：
```
「GitHubイシュー番号を教えてください（例: #280）」
```

または、イシュー情報のJSONファイルパスを確認：
```
「イシュー情報のJSONファイルパスを教えてください」
```

ユーザーが既にパスや番号を指定している場合は、このステップをスキップしてください。

### ステップ2: プロンプトテンプレートの読み込み
以下のプロンプトテンプレートを読み込んでください：
```
prompts/hearing_to_baseline.md
```

このテンプレートには、ベースライン仕様書生成のための詳細な指示が含まれています。

### ステップ3: ベースライン仕様書の生成
プロンプトテンプレートに従って、以下の作業を実行してください：

1. **インプットファイルを読み込む**
   - 議事録の場合: ユーザーが指定したパスのファイルを読み込み
   - イシューの場合: イシュー情報（JSONまたはGitHub API経由）を読み込み

2. **ベースライン仕様書を生成**
   - プロンプトテンプレートの指示に従って8セクションを作成
   - 品質目標8.0/10以上を目指す
   - イシューから生成する場合は、イシューの内容をヒアリング情報として扱う

3. **出力ファイルに保存**
   - デフォルト: `skills/pochi-baseline-builder/output/baseline_spec.md`
   - ユーザーが別のパスを指定した場合はそれに従う

### ステップ4: 完了報告と推奨事項
生成完了後、以下を報告：
```
「ベースライン仕様書を生成しました。
- 出力先: {output_path}
- 品質スコア: {quality_score}/10

【次のステップ】
機能詳細の仕様が必要な場合は、pochi-feature-builderを使用して
個別の機能仕様書を生成してください。」
```

## Instructions

### 詳細な実行手順

#### 1. 入力確認
```markdown
【確認】
- ヒアリング議事録: {hearing_file_path}
- 出力先: {output_path} (デフォルト: skills/pochi-baseline-builder/output/baseline_spec.md)

この設定で生成を開始しますか？
```

#### 2. プロンプトテンプレート適用
`prompts/hearing_to_baseline.md`のfront-matterを参照：
- schema: baseline_spec_v1
- quality_threshold: 8.0
- 必須セクション: 8セクション

#### 3. ベースライン仕様書生成
以下の8セクションを生成：

1. **アプリケーション概要**
   - 目的と背景
   - 対象ユーザー
   - 主要機能

2. **機能要件**
   - 必須機能リスト
   - ユーザーストーリー

3. **非機能要件**
   - 性能要件
   - 可用性要件
   - ユーザビリティ要件

4. **技術仕様**
   - 技術スタック
   - アーキテクチャ概要
   - データフロー

5. **UI/UX仕様**
   - 画面構成
   - 操作フロー
   - デザイン原則（Pochiガイドライン準拠）

6. **データ仕様**
   - データモデル
   - セッションステート
   - 外部データ連携

7. **制約事項**
   - 技術的制約
   - ビジネス制約

8. **開発・運用方針**
   - 開発プロセス
   - テスト方針
   - デプロイ方針

#### 4. 品質確認
生成後、以下を自己チェック：
- [ ] 8セクションすべてが含まれているか
- [ ] 各セクションに具体的な内容が記載されているか
- [ ] 曖昧な表現（「適切に」等）が少ないか
- [ ] Pochiガイドラインに準拠しているか

## Don't

### 実行禁止事項
- ❌ **ヒアリング議事録を読まずに生成しない**
  - 必ずヒアリング内容に基づいて生成してください

- ❌ **不完全な仕様書を生成しない**
  - 8セクションすべてを含めてください

- ❌ **曖昧な表現を多用しない**
  - 「適切に」「必要に応じて」等の表現を避ける

- ❌ **Pochiガイドラインを無視しない**
  - UI設計はPochiガイドラインに準拠してください

## Inputs

### 必須入力
- **ヒアリング議事録**
  - 形式: Markdown
  - パス例: `skills/pochi-baseline-builder/input/meeting_notes.md`
  - 内容: 顧客とのヒアリング内容、要件、UI要望等

### オプション入力
- **出力先パス**
  - デフォルト: `skills/pochi-baseline-builder/output/baseline_spec.md`
  - カスタム指定可能

### 参照ドキュメント（自動参照）
- `prompts/hearing_to_baseline.md`: プロンプトテンプレート
- `prompts/_schema/baseline_spec_v1.yaml`: スキーマ定義

## Outputs

### 主要成果物
- **baseline_spec.md**
  - ベースライン仕様書（8セクション）
  - 形式: Markdown
  - 品質目標: 8.0/10以上

### 生成内容の構成
```markdown
# [アプリケーション名] ベースライン仕様書

## 1. アプリケーション概要
...

## 2. 機能要件
...

## 3. 非機能要件
...

## 4. 技術仕様
...

## 5. UI/UX仕様
...

## 6. データ仕様
...

## 7. 制約事項
...

## 8. 開発・運用方針
...
```

## Troubleshooting

### Skillが起動しない場合

#### 1. トリガーワードを確認
- ✅ 「機能仕様書を作成して」（推奨）
- ✅ 「仕様書を作成して」（推奨）
- ✅ 「baseline specを生成」
- ❌ 「仕様を作りたい」（トリガーに未登録）

#### 2. SKILL.mdの配置を確認
```bash
# 以下のファイルが存在するか確認
ls -la skills/pochi-baseline-builder/SKILL.md
```

### 生成エラーが発生する場合

#### エラー: 「ヒアリング議事録が見つかりません」
**原因**: ファイルパスが正しくない  
**解決**: ファイルパスを再確認してください

#### エラー: 「プロンプトテンプレートが見つかりません」
**原因**: prompts/hearing_to_baseline.mdが存在しない
**解決**: プロンプトテンプレートの配置を確認してください

### 品質が低い場合

#### 生成内容が曖昧
**原因**: ヒアリング議事録の情報が不足  
**解決**: ヒアリング議事録に具体的な要件を追加してください

#### セクションが不完全
**原因**: プロンプトテンプレートの指示が不十分  
**解決**: プロンプトテンプレートを確認し、8セクションすべてを生成してください

## 使用例

### 例1: 汎用トリガー使用（インプット種別選択）
```
ユーザー: 「機能仕様書を作成して」

エージェント: 「どちらから生成しますか？
1. ヒアリング議事録から生成（推奨）
2. GitHubイシューから生成」

ユーザー: 「1」

エージェント: 「ヒアリング議事録のファイルパスを教えてください」

ユーザー: 「skills/pochi-baseline-builder/input/meeting_notes.md」

エージェント:
1. meeting_notes.mdを読み込み
2. プロンプトテンプレートに従って8セクション生成
3. skills/pochi-baseline-builder/output/baseline_spec.mdに保存
4. 「ベースライン仕様書を生成しました」
```

### 例2: 議事録を明示したトリガー
```
ユーザー: 「議事録から機能仕様書を作成して」

エージェント: 「ヒアリング議事録のファイルパスを教えてください」

ユーザー: 「skills/pochi-baseline-builder/input/ヒアリング-20260108_170025.md」

エージェント:
1. 指定されたパスのファイルを読み込み
2. 8セクション生成
3. デフォルト出力先に保存
4. 完了報告
```

### 例3: イシューを明示したトリガー
```
ユーザー: 「イシューから機能仕様書を作成、#500で」

エージェント: 
1. イシュー#500の情報を取得
2. イシュー内容をヒアリング情報として扱い8セクション生成
3. skills/pochi-baseline-builder/output/baseline_spec.mdに保存
4. 「ベースライン仕様書を生成しました
   
   【推奨】個別機能の詳細仕様が必要な場合は、
   pochi-feature-builderで機能仕様書を生成してください。」
```

### 例4: パス指定を含む起動
```
ユーザー: 「skills/pochi-baseline-builder/input/ヒアリング-20260108_170025.md から機能仕様書を生成して」

エージェント:
1. 指定されたパスのファイルを読み込み（インプット種別選択をスキップ）
2. 8セクション生成
3. デフォルト出力先に保存
4. 完了報告
```

## バージョン・ライセンス

- **バージョン**: 1.0.0
- **作成者**: Pochi Development Team
- **ライセンス**: Internal Use Only

## 参照ドキュメント

- [README.md](./README.md): 概要とクイックスタート
- [統一CLI README](../../pochi-cli/README.md): 統一CLIドキュメント
- [prompts/hearing_to_baseline.md](prompts/hearing_to_baseline.md): プロンプトテンプレート
- [prompts/_schema/baseline_spec_v1.yaml](prompts/_schema/baseline_spec_v1.yaml): スキーマ定義

**注意**: このSkillは統一CLI (`pochi baseline`) と同じ機能を提供します。新規開発では統一CLIの使用を推奨します。

---

**🚀 このSkillを起動するには、「機能仕様書を作成して」または「仕様書を作成して」とClaude Codeに指示してください。**
