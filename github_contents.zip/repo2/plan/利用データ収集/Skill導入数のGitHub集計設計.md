# Skill導入数のGitHub集計設計

## 背景・目的

2026-05-12の会議（project/20260512.md）で以下が合意された。

> 「Skill導入数はGitHubからとろう ★これはとれるから早く仕組み化しておきたい」

### 会議で確認された方針

| 項目 | 合意内容 |
|---|---|
| 導入単位 | **プロジェクト（リポジトリ）単位**（ユーザー個人単位は推奨しない） |
| 取得元 | GitHub API（コミッター情報・スキルファイル検索） |
| 利用しない情報 | enabledPlugins / settings.json / plugins/cache/ 等のプラグイン系ファイル |
| 目的 | 死蔵スキルの廃止判断・人気スキルの改善優先度設定・社内展開状況の可視化 |

### KPIの位置づけ（会議より）

「リポジトリでの利用状況、コミッター数、リポジトリあたりの開発者数の減少などをアウトカムとして追及する」（YA）

Skill導入数はこのアウトカムへのブレイクダウン指標として活用する。

---

## 「Skill導入済みリポジトリ」の定義と検出方法（3案）

### 案A: スキルファイルがリポジトリに存在するか（YT・YOS案①）

**定義**: リポジトリの `.claude/settings.json` や `CLAUDE.md` に特定Skillへの参照・設定が含まれていること。

**検出方法**:
```bash
# GitHub Search API でSkill名をコード検索
gh api "search/code?q=pochi-spec-initializer+in:file+org:{org}" \
  --jq '.items[].repository.full_name' | sort -u
```

**出力例**:
```
org/app-repo-a
org/app-repo-b
org/app-repo-c
```

| 評価軸 | 評価 |
|---|---|
| Skill個別の把握 | ✅ Skill名で絞り込める |
| 自動化 | ✅ GitHub Search API で完全自動 |
| 精度 | ○ ファイルに記載 = 導入済みとみなす |
| 課題 | Skillが固有ファイルを生成しない場合は検出できない |
| PAT | 必要（`repo` スコープ） |

---

### 案B: Claude Codeがコミッターとして履歴にいるか（YT・YOS案②）

**定義**: リポジトリのコミット履歴に `Co-Authored-By: Claude` が含まれていること。

**検出方法**:
```bash
# GitHub Search API でコミットメッセージを検索
gh api "search/commits?q=Co-Authored-By+Claude+repo:{owner}/{repo}" \
  --header "Accept: application/vnd.github.cloak-preview" \
  --jq '.total_count'

# 組織全体を対象にする場合
gh api "search/commits?q=Co-Authored-By+Claude+org:{org}" \
  --header "Accept: application/vnd.github.cloak-preview" \
  --jq '[.items[].repository.full_name] | unique | length'
```

| 評価軸 | 評価 |
|---|---|
| Skill個別の把握 | ❌ Claude Code全体の利用指標（Skill特定不可） |
| 自動化 | ✅ GitHub API で自動取得可能 |
| 精度 | △ Skillを使わず会話だけでコミットした場合も含む |
| 課題 | 「Claude Codeを使ったか」の指標であり、「Skillを使ったか」とは異なる |
| PAT | 必要（`repo` スコープ） |

---

### 案C: GitHub APIのコントリビューター数を定期取得（YA案）

**定義**: このリポジトリ（pochi-dp-developer-docs）へのコントリビューター数・コミット数をKPIとして追跡する。

**検出方法**:
```bash
# コントリビューター数
gh api "repos/{owner}/{repo}/stats/contributors" \
  --jq 'length'

# クローン数（過去14日）← 定期実行が必須
gh api "repos/{owner}/{repo}/traffic/clones" \
  --jq '{uniques: .uniques, count: .count}'

# 閲覧者数（過去14日）
gh api "repos/{owner}/{repo}/traffic/views" \
  --jq '{uniques: .uniques, count: .count}'
```

**出力例**（`analytics/github-stats-202621.json`）:
```json
{
  "week": "2026-W21",
  "collected_at": "2026-05-13",
  "contributors": 13,
  "total_commits": 1489,
  "traffic_clones_14d": { "uniques": 8, "count": 24 },
  "traffic_views_14d": { "uniques": 15, "count": 102 }
}
```

| 評価軸 | 評価 |
|---|---|
| Skill個別の把握 | ❌ リポジトリ全体の粗い数値 |
| 自動化 | ✅ GitHub Actions で完全自動化可能 |
| 精度 | ○ リポジトリ全体の利用広がりを正確に追跡 |
| 課題 | Traffic APIは**過去14日分のみ**保持。定期実行しないとデータが消える |
| PAT | 必要（`repo` スコープ） |

---

## 3案の比較

| 案 | 何を測るか | Skill個別 | 自動化 | 課題 |
|---|---|:---:|:---:|---|
| A: スキルファイル検索 | Skill導入済みリポジトリ数 | ✅ | ✅ | 成果物を生成しないSkillは検出不可 |
| B: CCコミッター検索 | CC利用リポジトリ数・人数 | ❌ | ✅ | Skill特定不可 |
| C: コントリビューター数 | リポジトリ全体の利用広がり | ❌ | ✅ | 14日制限・定期実行必須 |

---

## 推奨構成（段階的実装）

### フェーズ1（即日〜1週間）: 案B + 案C

「早く仕組み化したい」を最優先に、すぐ動かせる構成を先行させる。

```
定期スクリプト（週次・ローカル実行でもよい）
  ↓
① gh api でコントリビューター数・Traffic を取得（案C）
② gh search commits で CC利用リポジトリ数を取得（案B）
③ analytics/github-stats-{YYYYWW}.json に追記・コミット
```

**実装コスト**: PAT発行 + スクリプト1本（約1〜2時間）

### フェーズ2（1ヶ月後）: 案Aを追加

Skill個別の導入状況を把握できるようにする。

```
定期スクリプト（月次）
  ↓
① GitHub Search API でSkill名をコード検索（案A）
② Skill別「導入済みリポジトリ数」を集計
③ analytics/skill-adoption-{YYYYMM}.json に保存・コミット
```

**実装コスト**: 検索クエリの設計 + スクリプト拡張（約半日）

---

## データフローと保存先

```
pochi-dp-developer-docs/
└── analytics/
    ├── github-stats-{YYYYWW}.json    ← 週次（案B + 案C）
    └── skill-adoption-{YYYYMM}.json  ← 月次（案A）
```

`analytics/` は `.gitignore` に含めず GitHub 上で管理する。

---

## 実装タスクリスト

### フェーズ1

| # | 作業 | 担当 | 工数 |
|---|---|---|---|
| 1 | GitHub PAT を発行（`repo` スコープ） | 管理者 | 10分 |
| 2 | `scripts/collect-github-stats.sh` を作成 | 管理者 | 1〜2時間 |
| 3 | `analytics/` ディレクトリを作成 | 管理者 | 5分 |
| 4 | 週次での手動実行を開始（→ 後でcron/Actions化） | 管理者 | 随時 |

### フェーズ2

| # | 作業 | 担当 | 工数 |
|---|---|---|---|
| 5 | Skill別の検索クエリを設計（案A） | RS・YOS | 半日 |
| 6 | `scripts/collect-skill-adoption.sh` を作成 | 管理者 | 半日 |
| 7 | GitHub Actions で自動化（PAT を Secrets に登録） | 管理者 | 1〜2時間 |

---

## 未決事項

| 項目 | 選択肢 | 状態 |
|---|---|---|
| PAT の管理方法 | 個人PAT / GitHub Apps / Organization-level PAT | 未決（6月ミーティングで協議） |
| 自動実行の方法 | ローカルcron / GitHub Actions | フェーズ1はローカルで先行 |
| 案Aの検索クエリ設計 | CLAUDE.md / settings.json のどのキーワードで検索するか | 未決 |
| Skill利用数の追跡 | 三宅チーム・矢野チームとの連携方法 | 継続協議（会議合意） |

---

## 参考

- 会議議事録: `/home/user/project-management/03_meetings/project/20260512.md`
- 関連設計書: `手動収集設計.md`（起動回数の収集フロー）
- 関連設計書: `利用データ収集まとめ.md`（全体方針）
- 次回ミーティング: 2026年6月上旬（KPI・計測方法の継続協議）
