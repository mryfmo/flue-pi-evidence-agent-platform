# SKILL.md スキルの起動回数を収集するアーキテクチャ

## SKILL.md の特性と計測の難しさ

SKILL.md は実行可能コードではなく**マークダウンのプロンプト指示書**です。そのためMCPプラグインとは異なり、コード内にテレメトリを埋め込む従来手法が使えません。

```
  MCP プラグイン              SKILL.md
  ─────────────             ─────────
  実行可能コード              マークダウン（テキスト）
  → SDK埋め込み可能           → コード埋め込み不可
  → Hooks で tool_call 検知   → tool_call イベントが発生しない
  → Proxy で傍受可能          → プロセスが存在しない
```

---

## 5つの収集手法

```
┌────────────────────────────────────────────────────────────────┐
│  収集手法の全体マップ                                            │
│                                                                │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────────────┐ │
│  │ 手法 1   │  │ 手法 2   │  │ 手法 3   │  │ 手法 4         │ │
│  │ SKILL.md │  │ 計測用   │  │ セッション│  │ Hooks +        │ │
│  │ 内に計測 │  │ MCP      │  │ ログ解析 │  │ Prompt 解析    │ │
│  │ 指示埋込 │  │ サーバー │  │          │  │                │ │
│  └──────────┘  └──────────┘  └──────────┘  └────────────────┘ │
│  自動+手動     自動+手動     自動+手動      自動+手動           │
│  ★★★          ★★★          ★★☆           ★★☆                │
│                                                                │
│                ┌──────────────────┐                             │
│                │ 手法 5           │                             │
│                │ Git Commit 解析  │                             │
│                │ (事後分析)       │                             │
│                └──────────────────┘                             │
│                自動+手動                                        │
│                ★☆☆                                             │
└────────────────────────────────────────────────────────────────┘
```

---

## 手法 1：SKILL.md 内にトラッキング指示を埋め込む（推奨）

**最もシンプルで確実な方法。** スキルの指示文自体に「使ったら記録せよ」と書く。

### SKILL.md テンプレート

```markdown
# Skill: API エンドポイント作成

<tracking>
このスキルを実行する際は、最初のステップとして必ず
`record_skill_usage` ツールを以下の引数で呼び出してください：
- skill_id: "create-api-endpoint"
- skill_version: "1.2.0"
- trigger: "manual" または "auto"（どちらで起動されたか）
トラッキング呼び出しが失敗してもスキルの実行は継続してください。
</tracking>

## 概要
REST API エンドポイントを社内標準に沿って作成するスキル。

## 手順

1. `record_skill_usage` を呼び出す（上記 tracking 参照）

2. 対象のルーターファイルを確認する
   ...

3. エンドポイントを追加する
   ...

4. テストを作成する
   ...
```

### 対応する MCP トラッキングサーバー

```typescript
// @yourorg/skill-tracker-mcp/src/index.ts

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { createHash } from "crypto";

const server = new McpServer({
  name: "skill-tracker",
  version: "1.0.0",
});

// ── バッファ ──
let buffer: SkillEvent[] = [];
const FLUSH_INTERVAL = 60_000;
const FLUSH_SIZE = 50;

interface SkillEvent {
  eventId: string;
  skillId: string;
  skillVersion: string;
  trigger: "manual" | "auto" | "unknown";
  entityId: string;
  timestamp: string;
  workspaceHash: string;
}

// ── ツール定義 ──
server.tool(
  "record_skill_usage",
  "SKILL.md スキルの起動を記録する。スキル実行開始時に呼び出す。",
  {
    skill_id: z.string().describe("スキルの一意識別子"),
    skill_version: z.string().optional().describe("スキルのバージョン"),
    trigger: z.enum(["manual", "auto", "unknown"]).optional()
      .describe("手動起動か自動起動か"),
    context: z.string().optional()
      .describe("起動コンテキスト（ファイル種別など、機密情報は含めない）"),
  },
  async ({ skill_id, skill_version, trigger, context }) => {
    const event: SkillEvent = {
      eventId: crypto.randomUUID(),
      skillId: skill_id,
      skillVersion: skill_version ?? "unknown",
      trigger: trigger ?? "unknown",
      entityId: anonymize(process.env.USER ?? "unknown"),
      timestamp: new Date().toISOString(),
      workspaceHash: anonymize(process.cwd()),
    };

    buffer.push(event);

    if (buffer.length >= FLUSH_SIZE) {
      await flush();
    }

    return {
      content: [
        {
          type: "text",
          text: `✓ Recorded: ${skill_id} v${skill_version ?? "?"}`,
        },
      ],
    };
  },
);

// ── 送信 ──
async function flush() {
  if (buffer.length === 0) return;
  const batch = buffer.splice(0);

  try {
    await fetch("https://telemetry.internal.yourcompany.com/v1/skill-events", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ events: batch }),
      signal: AbortSignal.timeout(5_000),
    });
  } catch {
    // ローカル退避
    const fs = await import("fs/promises");
    const dir = `${process.env.HOME}/.claude/skill-telemetry-cache`;
    await fs.mkdir(dir, { recursive: true });
    await fs.writeFile(`${dir}/${Date.now()}.json`, JSON.stringify(batch));
  }
}

setInterval(flush, FLUSH_INTERVAL);
process.on("beforeExit", () => flush());

function anonymize(input: string): string {
  const salt = new Date().toISOString().split("T")[0];
  return createHash("sha256")
    .update(`${input}:${salt}`)
    .digest("hex")
    .slice(0, 16);
}

// ── 起動 ──
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}
main();
```

### Claude Code 設定

```json
// ~/.claude/settings.json (組織配布)
{
  "mcpServers": {
    "skill-tracker": {
      "command": "npx",
      "args": ["@yourorg/skill-tracker-mcp"]
    }
  }
}
```

### 動作フロー

```
ユーザー: 「APIエンドポイントを作って」
    │
    ▼
Claude Code: SKILL.md を参照
    │
    ▼
Claude Code: <tracking> 指示に従い record_skill_usage を呼出
    │         skill_id: "create-api-endpoint"
    │         trigger: "auto"
    ▼
skill-tracker MCP: イベントをバッファ → 社内 API へ送信
    │
    ▼
Claude Code: スキルの実際の手順を実行
```

---

## 手法 2：スキルローダー MCP サーバー方式

SKILL.md を直接読ませるのではなく、**MCP ツール経由でスキルを読み込ませる**ことで自動的に計測する。

```typescript
// @yourorg/skill-loader-mcp/src/index.ts

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { readdir, readFile } from "fs/promises";
import { join } from "path";

const server = new McpServer({
  name: "skill-loader",
  version: "1.0.0",
});

const SKILLS_DIR = join(process.cwd(), ".claude", "skills");

// ── スキル一覧ツール ──
server.tool(
  "list_skills",
  "利用可能なスキル一覧を返す",
  {},
  async () => {
    const files = await readdir(SKILLS_DIR).catch(() => []);
    const skills = files
      .filter((f) => f.endsWith(".md"))
      .map((f) => f.replace(/\.md$/, ""));

    return {
      content: [{ type: "text", text: JSON.stringify(skills, null, 2) }],
    };
  },
);

// ── スキル読み込みツール（＝計測ポイント） ──
server.tool(
  "load_skill",
  "指定されたスキルの内容を読み込んで返す。スキルを実行する前に必ずこのツールで読み込むこと。",
  {
    skill_name: z.string().describe("スキル名（ファイル名から .md を除いたもの）"),
    trigger: z.enum(["manual", "auto"]).optional(),
  },
  async ({ skill_name, trigger }) => {

    // ★ ここが計測ポイント
    await recordUsage({
      skillId: skill_name,
      trigger: trigger ?? "unknown",
      timestamp: new Date().toISOString(),
    });

    const content = await readFile(
      join(SKILLS_DIR, `${skill_name}.md`),
      "utf-8",
    );

    return {
      content: [{ type: "text", text: content }],
    };
  },
);

// ── スキル実行完了報告ツール ──
server.tool(
  "complete_skill",
  "スキルの実行が完了したら呼び出す",
  {
    skill_name: z.string(),
    success: z.boolean(),
    steps_completed: z.number().optional(),
  },
  async ({ skill_name, success, steps_completed }) => {

    await recordUsage({
      skillId: skill_name,
      eventType: "completed",
      success,
      stepsCompleted: steps_completed,
      timestamp: new Date().toISOString(),
    });

    return {
      content: [{ type: "text", text: `✓ ${skill_name} 完了記録済み` }],
    };
  },
);
```

```
ユーザー: 「テスト作成スキルを使って」
    │
    ▼
Claude Code: load_skill("create-tests", trigger="manual") を呼出
    │                    ↑ ここで起動回数 +1
    ▼
skill-loader MCP: SKILL.md の内容を返却 + 計測イベント送信
    │
    ▼
Claude Code: 返却されたスキル内容に従って作業実行
    │
    ▼
Claude Code: complete_skill("create-tests", success=true) を呼出
                             ↑ ここで完了回数 +1
```

---

## 手法 3：セッションログ解析（受動的収集）

Claude Code のセッションデータを解析して、どのスキルが参照されたかを事後的に把握する。

```python
# skill_usage_analyzer.py

import json
import re
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime

SESSIONS_DIR = Path.home() / ".claude" / "projects"

def analyze_skill_usage(since_date: str = None):
    """全セッションログからスキル参照を抽出"""

    skill_usage = defaultdict(lambda: {
        "total_invocations": 0,
        "manual_triggers": 0,
        "auto_triggers": 0,
        "sessions": set(),
        "dates": Counter(),
    })

    for project_dir in SESSIONS_DIR.iterdir():
        if not project_dir.is_dir():
            continue

        for session_file in project_dir.rglob("*.jsonl"):
            analyze_session(session_file, skill_usage, since_date)

    return format_report(skill_usage)


def analyze_session(session_file: Path, usage: dict, since_date: str):
    """1セッションファイルを解析"""

    with open(session_file) as f:
        for line in f:
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            # タイムスタンプフィルタ
            ts = entry.get("timestamp", "")
            if since_date and ts < since_date:
                continue

            # パターン1: SKILL.md ファイルの読み込みを検出
            if is_skill_file_read(entry):
                skill_name = extract_skill_name(entry)
                if skill_name:
                    usage[skill_name]["total_invocations"] += 1
                    usage[skill_name]["sessions"].add(str(session_file))
                    usage[skill_name]["dates"][ts[:10]] += 1

            # パターン2: skill-tracker MCP 呼び出しを検出
            if is_skill_tracker_call(entry):
                data = extract_tracker_data(entry)
                if data:
                    skill_name = data["skill_id"]
                    usage[skill_name]["total_invocations"] += 1
                    trigger = data.get("trigger", "unknown")
                    if trigger == "manual":
                        usage[skill_name]["manual_triggers"] += 1
                    elif trigger == "auto":
                        usage[skill_name]["auto_triggers"] += 1

            # パターン3: アシスタントメッセージ内のスキル言及を検出
            if is_skill_mention(entry):
                skill_name = extract_mentioned_skill(entry)
                if skill_name:
                    usage[skill_name]["total_invocations"] += 1


def is_skill_file_read(entry: dict) -> bool:
    """Read ツールで .claude/skills/ 配下のファイルが読まれたか"""
    if entry.get("type") != "tool_use":
        return False
    tool_name = entry.get("tool", {}).get("name", "")
    if tool_name not in ("Read", "ReadFile"):
        return False
    file_path = entry.get("tool", {}).get("input", {}).get("file_path", "")
    return ".claude/skills/" in file_path and file_path.endswith(".md")


def extract_skill_name(entry: dict) -> str:
    """ファイルパスからスキル名を抽出"""
    file_path = entry.get("tool", {}).get("input", {}).get("file_path", "")
    match = re.search(r"skills/(.+)\.md$", file_path)
    return match.group(1) if match else None


def is_skill_tracker_call(entry: dict) -> bool:
    """record_skill_usage ツール呼び出しか"""
    if entry.get("type") != "tool_use":
        return False
    return entry.get("tool", {}).get("name") == "record_skill_usage"


def is_skill_mention(entry: dict) -> bool:
    """アシスタントメッセージ内でスキル参照が言及されているか"""
    if entry.get("type") != "assistant":
        return False
    text = entry.get("content", "")
    return "SKILL.md" in text or "skills/" in text


def format_report(usage: dict) -> str:
    """レポート出力"""
    lines = ["# Skill Usage Report", f"Generated: {datetime.now().isoformat()}", ""]

    sorted_skills = sorted(
        usage.items(),
        key=lambda x: x[1]["total_invocations"],
        reverse=True,
    )

    lines.append(f"| Skill | Total | Manual | Auto | Unique Sessions |")
    lines.append(f"|-------|-------|--------|------|-----------------|")

    for name, data in sorted_skills:
        lines.append(
            f"| {name} | {data['total_invocations']} "
            f"| {data['manual_triggers']} "
            f"| {data['auto_triggers']} "
            f"| {len(data['sessions'])} |"
        )

    return "\n".join(lines)


if __name__ == "__main__":
    print(analyze_skill_usage(since_date="2025-07-01"))
```

### cron で定期実行

```bash
# 毎日深夜に集計 → 社内 API に送信
0 2 * * * python3 /opt/scripts/skill_usage_analyzer.py \
  --since "$(date -d 'yesterday' +%Y-%m-%d)" \
  --output json \
  | curl -s -X POST https://telemetry.internal.yourcompany.com/v1/skill-report \
    -H "Content-Type: application/json" \
    -d @-
```

---

## 手法 4：Claude Code Hooks でスキル参照を検知

```bash
#!/bin/bash
# .claude/hooks/post_tool_use.sh

INPUT=$(cat)
TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // empty')
TOOL_INPUT=$(echo "$INPUT" | jq -r '.tool_input // empty')

# Read ツールで skills/ ディレクトリのファイルが読まれた場合
if [ "$TOOL_NAME" = "Read" ] || [ "$TOOL_NAME" = "ReadFile" ]; then
  FILE_PATH=$(echo "$TOOL_INPUT" | jq -r '.file_path // empty')

  if echo "$FILE_PATH" | grep -q '\.claude/skills/.*\.md$'; then
    # スキル名を抽出
    SKILL_NAME=$(echo "$FILE_PATH" | sed 's|.*skills/||; s|\.md$||')

    # 非同期で記録
    curl -s -X POST \
      "https://telemetry.internal.yourcompany.com/v1/skill-events" \
      -H "Content-Type: application/json" \
      -d "{
        \"eventType\": \"skill.loaded\",
        \"skillId\": \"${SKILL_NAME}\",
        \"trigger\": \"detected_via_hook\",
        \"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",
        \"entityId\": \"$(echo -n "${USER}:$(date +%Y-%m-%d)" | shasum -a 256 | cut -c1-16)\"
      }" &>/dev/null &
  fi
fi

# record_skill_usage ツール呼び出しも捕捉（手法1との併用）
if [ "$TOOL_NAME" = "record_skill_usage" ]; then
  SKILL_ID=$(echo "$TOOL_INPUT" | jq -r '.skill_id // empty')
  TRIGGER=$(echo "$TOOL_INPUT" | jq -r '.trigger // "unknown"')

  curl -s -X POST \
    "https://telemetry.internal.yourcompany.com/v1/skill-events" \
    -H "Content-Type: application/json" \
    -d "{
      \"eventType\": \"skill.invoked\",
      \"skillId\": \"${SKILL_ID}\",
      \"trigger\": \"${TRIGGER}\",
      \"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",
      \"entityId\": \"$(echo -n "${USER}:$(date +%Y-%m-%d)" | shasum -a 256 | cut -c1-16)\"
    }" &>/dev/null &
fi

echo '{"decision": "approve"}'
```

---

## 手法比較と推奨組み合わせ

```
┌──────────────┬──────────┬──────────┬──────────┬──────────┬──────────┐
│              │ 手法 1   │ 手法 2   │ 手法 3   │ 手法 4   │ 手法 5   │
│              │ 埋込指示 │ Loader   │ ログ解析 │ Hooks    │ Git解析  │
├──────────────┼──────────┼──────────┼──────────┼──────────┼──────────┤
│ 自動起動検知 │ ✅       │ ✅       │ ✅       │ ✅       │ △       │
│ 手動起動検知 │ ✅       │ ✅       │ ✅       │ ✅       │ △       │
│ リアルタイム │ ✅       │ ✅       │ ❌ 事後  │ ✅       │ ❌ 事後  │
│ 手動/自動判別│ ✅       │ ✅       │ △       │ △       │ ❌       │
│ 完了率計測   │ △       │ ✅       │ △       │ △       │ ❌       │
│ 既存スキル   │ 要修正   │ 要修正   │ 変更不要 │ 変更不要 │ 変更不要 │
│  変更の有無  │          │          │          │          │          │
│ 信頼性      │ ★★☆     │ ★★★     │ ★★☆     │ ★★☆     │ ★☆☆     │
│ 導入コスト   │ 低       │ 中       │ 低       │ 低       │ 低       │
└──────────────┴──────────┴──────────┴──────────┴──────────┴──────────┘

 ★★☆ の理由:
   手法1 → Claude が指示を無視する可能性がゼロではない
   手法3 → ログ形式の変更に弱い
   手法4 → Read ツール以外でスキルが参照される場合を見逃す可能性
```

---

## 推奨：多層防御的な組み合わせ

```
┌─────────────────────────────────────────────────────────────────┐
│  推奨構成：手法 1 + 手法 4 + 手法 3                               │
│                                                                 │
│  ┌─── Primary（リアルタイム）───────────────────────────────────┐ │
│  │                                                             │ │
│  │  手法 1: SKILL.md 内のトラッキング指示                        │ │
│  │    → Claude が record_skill_usage を呼ぶ                    │ │
│  │    → 手動/自動の判別が最も正確                                │ │
│  │                                                             │ │
│  │  手法 4: Hooks で Read ツールの skills/ アクセスを検知         │ │
│  │    → 手法1 が呼ばれなかった場合の補完                         │ │
│  │    → 既存スキル（未改修）のカバー                              │ │
│  │                                                             │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌─── Secondary（バッチ・検証用）───────────────────────────────┐ │
│  │                                                             │ │
│  │  手法 3: セッションログの定期解析                              │ │
│  │    → Primary で漏れたイベントの補完                           │ │
│  │    → 週次レポート / 月次集計に活用                             │ │
│  │    → Primary との差分で計測漏れを検出                         │ │
│  │                                                             │ │
│  └─────────────────────────────────────────────────────────────┘ │
│                                                                 │
│              ┌──────────────────────────────┐                   │
│              │  重複排除ロジック（サーバー側） │                   │
│              │                              │                   │
│              │  同一セッション + 同一スキル   │                   │
│              │  + 5秒以内 → 1回とカウント    │                   │
│              └──────────────────────────────┘                   │
└─────────────────────────────────────────────────────────────────┘
```

### 重複排除の実装

```python
# server-side deduplication
from datetime import datetime, timedelta
from hashlib import sha256

class SkillEventDeduplicator:
    """手法1, 4, 3 から同一起動が複数報告される場合の重複排除"""

    def __init__(self, window_seconds: int = 10):
        self.window = timedelta(seconds=window_seconds)
        self.seen: dict[str, datetime] = {}

    def is_duplicate(self, event: dict) -> bool:
        key = sha256(
            f"{event['entityId']}:{event['skillId']}:{event.get('sessionId', '')}".encode()
        ).hexdigest()[:32]

        ts = datetime.fromisoformat(event["timestamp"])
        last_seen = self.seen.get(key)

        if last_seen and (ts - last_seen) < self.window:
            return True

        self.seen[key] = ts
        return False

    def process(self, event: dict) -> dict | None:
        if self.is_duplicate(event):
            return None

        # ソースの優先順位: 手法1 > 手法4 > 手法3
        SOURCE_PRIORITY = {
            "skill_md_instruction": 1,   # 手法1
            "hook_detection": 2,         # 手法4
            "log_analysis": 3,           # 手法3
        }
        event["source_priority"] = SOURCE_PRIORITY.get(
            event.get("source"), 99
        )
        return event
```

---

## 最終的なダッシュボード設計

```sql
-- 日次スキル利用サマリー
SELECT
    skill_id,
    COUNT(*) AS total_invocations,
    COUNT(CASE WHEN trigger = 'manual' THEN 1 END) AS manual,
    COUNT(CASE WHEN trigger = 'auto'   THEN 1 END) AS auto,
    COUNT(DISTINCT entity_id)                       AS unique_users,
    COUNT(DISTINCT DATE(timestamp))                 AS active_days,
    MIN(timestamp)                                  AS first_seen,
    MAX(timestamp)                                  AS last_seen
FROM skill_events
WHERE timestamp >= CURRENT_DATE - INTERVAL '30 days'
  AND is_duplicate = false
GROUP BY skill_id
ORDER BY total_invocations DESC;
```

```
┌──────────────────────────────────────────────────────────┐
│  Skill Usage Dashboard                                   │
│                                                          │
│  Top Skills (30d)            Trigger Distribution        │
│  ┌──────────────────────┐    ┌────────────────────────┐  │
│  │ 1. create-api   342  │    │  ██████████ auto  68%  │  │
│  │ 2. write-test   289  │    │  ████       manual 32% │  │
│  │ 3. review-pr    201  │    └────────────────────────┘  │
│  │ 4. refactor     156  │                                │
│  │ 5. add-logging   98  │    Daily Trend                 │
│  └──────────────────────┘    ┌────────────────────────┐  │
│                              │    ╱╲   ╱╲             │  │
│  Unique Users: 47            │ ╱╱  ╲╱╱  ╲╲           │  │
│  Skills Available: 23        │╱          ╲╲╱╲        │  │
│  Avg/user/day: 3.2           └────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
```

---

## 段階的な導入順序

```
Week 1:   手法 4（Hooks）を全社配布
          → 変更不要、設定ファイル配布のみで即日稼働

Week 2:   手法 1（埋込指示）の SKILL.md テンプレートを整備
          → 新規スキルから適用、既存スキルは順次改修

Week 3:   手法 3（ログ解析）スクリプトを cron 設定
          → 漏れの検出と週次レポート自動生成

Month 2:  重複排除ロジックとダッシュボード構築
          → 3手法の統合ビュー
```