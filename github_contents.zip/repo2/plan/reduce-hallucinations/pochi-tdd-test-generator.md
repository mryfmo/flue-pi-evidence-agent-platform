# pochi-tdd-test-generator 幻覚対策改修計画

**作成日**: 2026-05-11  
**調査対象**: `reduce-hallucinations.md`（公式ガイドライン）vs `pochi-tdd-test-generator` ロジック  
**ステータス**: 実装完了

---

## 概要

公式ガイドライン「幻覚を減らす」の7戦略と `pochi-tdd-test-generator` の実装を突合調査した結果、
**3件の改修が必要**と判定した。

本スキルは他2スキルと異なり「実装コードが存在しない」TDD先行フェーズを対象とするため、
幻覚リスクのプロファイルが固有である。`pochi-unit-test-generator` が「コードから根拠を取る」のに対し、
本スキルは「仕様書から根拠を取る」ことになるが、仕様書が不完全な場合は命名規則による推測に
フォールバックしており、**推測した関数シグネチャが `test-mapping.json` 経由で
`pochi-coding-agent` に誤った実装方針を与える連鎖リスク**がある。

---

## 7戦略の適合評価

| # | 戦略 | 評価 | 実装状況の根拠 |
|---|------|------|---------------|
| ① | わかりません許可 | ⚠️ 部分的 | スキル開始時・STEP 2 の入力検証で中断ルールあり。**STEP 6 の関数シグネチャ予測フォールバックが「不確かでも推測して続行」している** |
| ② | 直接引用から作業 | ✅ 実装済み | 全STEP で `<documents>` タグ経由で spec.json / plan.json を直接参照。Layer1 は `data-contracts.json` から直接生成 |
| ③ | 引用で検証 | ⚠️ 部分的 | Layer1 に `# RISK: {リスクID}` 仕様参照コメントあり。**Layer2 テストに仕様参照コメントの指示なし。business-rules.json の各エントリが spec.json のどのパスから来たか追跡不可** |
| ④ | CoT検証 | ⚠️ 部分的 | STEP 6（設計書生成）→ STEP 7（実装）の2段階あり。**関数シグネチャ予測の根拠を設計書に記載させる指示なし** |
| ⑤ | N検証 | ❌ 未実装 | 複数回生成・比較の仕組みなし |
| ⑥ | 反復改善 | ⚠️ 部分的 | STEP 4/8 の SyntaxError リトライあり（最大3回）。**STEP 7 後の包括的品質チェック（pochi-unit-test-generator の STEP 8.5 相当）が存在しない** |
| ⑦ | 外部知識制限 | ⚠️ 部分的 | Layer1: spec.json で制限済み。**STEP 6 フォールバック時に「命名規則ヒューリスティック」という外部知識に依存して関数シグネチャを推測する** |

---

## 改修一覧（優先度順）

| # | 優先度 | 改修ID | 対象ファイル | 改修種別 |
|---|--------|--------|-------------|---------|
| 1 | 🔴 高 | FIX-TDD-01 | `skills/run/SKILL.md`（STEP 6） | 関数シグネチャ推測フォールバックの制限 |
| 2 | 🟡 中 | FIX-TDD-02 | `skills/run/SKILL.md`（STEP 7） | Layer2 テストへの仕様参照コメント付与指示追加 |
| 3 | 🟡 中 | FIX-TDD-03 | `skills/run/SKILL.md`（STEP 7 と STEP 8 の間） | STEP 7.5（RED テスト品質チェック）追加 |

---

## 他2スキルとの比較

| 幻覚リスク | pochi-test-orchestrator | pochi-unit-test-generator | pochi-tdd-test-generator |
|---|---|---|---|
| 架空の関数名 | ❌ 制限なし | ✅ Grep実在確認 | ⚠️ function_signatures必須時のみ制限 |
| 架空のインポートパス | ❌ 制限なし | ✅ STEP 8.5検証あり | ⚠️ plan.json制限のみ |
| 不確実時の中断 | ❌ 「推測して続行」 | ✅ T0/T2でエラー停止 | ✅ 入力検証で停止（ただしSTEP 6では推測続行） |
| Layer2 後品質チェック | ✅ 10チェックポイントあり | ✅ STEP 8.5（6チェック） | ❌ なし |
| テスト仕様トレーサビリティ | ⚠️ UIラベルのみ | ⚠️ business-rules未引用 | ⚠️ Layer1のみ（Layer2なし） |
| test-mapping.json誤誘導リスク | 該当なし | 該当なし | **本スキル固有リスク** |

---

## FIX-TDD-01: STEP 6 の関数シグネチャ予測フォールバック制限

**対応する幻覚戦略**: ① わかりません許可 + ⑦ 外部知識制限  
**公式ガイドライン違反箇所**:

> ① **「Claude に「わかりません」と言うことを許可する」**
> Claude に不確実性を認める許可を明示的に与えます。この単純な技術は、誤った情報を大幅に減らすことができます。

`function_signatures` が存在しない場合に「不確実だ」と報告せず、ヒューリスティックで推測して続行させていることが、この原則に違反している。

> ④ **「外部知識の制限」**
> Claude に提供されたドキュメントからの情報のみを使用し、一般的な知識を使用しないよう明示的に指示します。

`"parser"` を含む → 入力処理関数、`"calc"` → 計算関数という命名規則の推測は、spec.json / plan.json 外の**命名慣例という一般的な知識（外部知識）**に依存しており、この原則に違反している。

**問題**: `plan.json` に `function_signatures` フィールドがない場合、現在は以下の命名規則ヒューリスティックで関数シグネチャを推測する：

```
- type: "module" かつ名前に "parser" / "reader" 等を含む → 入力処理関数
- type: "module" かつ名前に "calc" / "analyze" 等を含む → 計算・分析関数
- business_rules の各ルール → バリデーション関数
```

この命名規則推測は「外部知識（命名慣例）」に依存した幻覚であり、特に以下の連鎖リスクがある：
- 推測された架空の関数名が `test-mapping.json` の `implementation_hint` に記録される
- `pochi-coding-agent` がその `implementation_hint` を信頼して誤った関数名で実装してしまう
- 結果、テストと実装が異なる関数名で生成され、テストが意味をなさなくなる

**根拠**: SKILL.md STEP 6「■ 関数シグネチャの予測ルール（function_signatures が存在しない場合のフォールバック）」セクションに命名規則ヒューリスティックが記述されている。

---

### FIX-TDD-01: STEP 6 の関数シグネチャ予測フォールバック指示を変更

**ファイル**: `skills/test/pochi-tdd-test-generator/skills/run/SKILL.md`  
**変更箇所**: STEP 6「■ 関数シグネチャの予測ルール（function_signatures が存在しない場合のフォールバック）」セクション

**変更前**:

```markdown
■ 関数シグネチャの予測ルール（function_signatures が存在しない場合のフォールバック）
  plan.json の artifacts から各モジュールの責務を推定し、以下の観点で関数を予測する：
  - type: "module" かつ名前に "parser" / "reader" 等を含む → 入力処理関数
  - type: "module" かつ名前に "calc" / "analyze" 等を含む → 計算・分析関数
  - business_rules の各ルール → バリデーション関数

<examples label="関数シグネチャ予測例">
  <example label="入力処理関数（parser系モジュール）">
    def parse_csv(file_path: str) -> list[dict]: ...
  </example>
  <example label="バリデーション関数（business_rules由来）">
    def validate_amount(amount: float) -> bool: ...
  </example>
</examples>
```

**変更後**:

```markdown
■ 関数シグネチャの取得ルール（function_signatures が存在しない場合のフォールバック）

  plan.json に `function_signatures` が存在しない場合、以下の**優先順位**で対応する：

  **ルール A（推奨）: plan.json の description / artifacts から明示的に読み取れる場合**
  - artifacts の `description` フィールドに関数名・引数が記載されている場合のみ採用する
  - 記載がないモジュールはルール B へ

  **ルール B: business_rules からバリデーション関数を導出**
  - spec.json の `business_rules` の各ルールに対して、バリデーション関数を1つ導出する
  - ルール例: `"店舗コードは5桁の数字"` → `def validate_store_code(store_code: str) -> bool`
  - 根拠: business_rules は spec.json に明示された仕様のため、導出は推測ではなく仕様準拠

  **ルール C（フォールバック時の報告義務）: 上記で解決できないモジュール**
  - 命名規則ヒューリスティック（"parser" 含む → 入力処理関数 等）は**使用禁止**
  - 代わりに、以下の形式で「シグネチャ未定義リスト」を `unit-test-design.md` の冒頭に記載する：

  ```markdown
  ## ⚠️ 関数シグネチャ未定義（ユーザー確認必須）

  以下のモジュールは plan.json に function_signatures が定義されておらず、
  仕様書からシグネチャを特定できませんでした。
  pochi-coding-agent による実装前に、plan.json へ function_signatures を追記してください。

  | モジュール | 追記が必要な理由 |
  |---|---|
  | app/lib/store_reader.py | artifacts.description にシグネチャ情報なし |
  | app/lib/calc_monthly.py | artifacts.description にシグネチャ情報なし |

  ### function_signatures 追記例（plan.json）:
  \`\`\`json
  {
    "artifacts": [...],
    "function_signatures": [
      {
        "module": "app/lib/store_reader.py",
        "functions": [
          { "name": "read_stores", "signature": "(file_path: str) -> pd.DataFrame" }
        ]
      }
    ]
  }
  \`\`\`
  ```

  シグネチャ未定義モジュールの Layer2 テストは、ルール B（business_rules 由来）のテストのみ生成し、
  シグネチャ依存テストは「TODO: function_signatures 追記後に生成」コメントで保留する。

  **目的**: 推測された架空の関数名が test-mapping.json に混入し、
  pochi-coding-agent が誤った関数名で実装するリスクを防ぐ。
```

---

## FIX-TDD-02: Layer2 テストへの仕様参照コメント付与指示追加

**対応する幻覚戦略**: ③ 引用で検証  
**公式ガイドライン違反箇所**:

> ③ **「引用で検証する」**
> Claude の応答を監査可能にするために、各主張について引用と出典を引用させます。Claude に応答を生成した後、各主張を検証するために支持する引用を見つけさせることもできます。引用が見つからない場合は、主張を撤回する必要があります。

Layer1 テストには `# RISK: {リスクID}` で仕様の引用元を示す指示があるが、Layer2 テスト（STEP 7）には同等の指示がない。生成されたテスト関数が `data_contracts` / `business_rules` / `scenarios` のどのエントリを根拠にしているか追跡できず、**生成物が監査不能な状態**になっていることがこの原則に違反している。

**問題**: Layer1 テストには `# RISK: {リスクID}` コメントの付与が STEP 5 で指示されているが、
Layer2 テストに同等の仕様参照コメントが STEP 7 で指示されていない。
Layer2 テストがどの仕様項目（data_contracts, business_rules, scenarios）から生成されたか追跡できず、
仕様変更時の影響範囲特定が困難になる。また、test-mapping.json の `spec_reference` フィールドが
Layer2 テストに対して適切に埋められない。

**根拠**: STEP 5 に `# RISK: {リスクID}` 指示あり（Layer1 のみ）。STEP 7 に同等の指示なし。

---

### FIX-TDD-02: STEP 7 の「Layer2 実装専用モード」プロンプトに仕様参照コメントルール追加

**ファイル**: `skills/test/pochi-tdd-test-generator/skills/run/SKILL.md`  
**挿入位置**: STEP 7 の Agent 起動プロンプト内「- AAAパターン・命名規則を遵守する」の直後

**追加するテキスト**:

```markdown
- 各テスト関数には仕様参照コメントを付与する（Layer1 の `# RISK:` と同様のトレーサビリティを確保する）：

  **コメント形式**:
  ```python
  # SPEC: data_contracts[N] (entity: {entity名})  ← データ契約テスト由来
  # BR: {ルールID} ({ルール概要})                  ← business_rules テスト由来
  # PRED: plan.json artifacts[N] (module: {モジュール名})  ← シグネチャ予測由来
  ```

  **付与例**:
  ```python
  def test_parse_csv_valid_input():
      # SPEC: data_contracts[0] (entity: SalesRecord)
      # フィクスチャから有効CSVを読み込み、正しい列数・型が返るか検証する
      result = parse_csv(fixtures["valid"]["sales_input.csv"])
      assert isinstance(result, list)
      assert len(result) == len(pd.read_csv(fixtures["valid"]["sales_input.csv"]))

  def test_validate_store_code_invalid():
      # BR: BR-001 (店舗コードは5桁の数字)
      result = validate_store_code("ABC12")
      assert result is False
  ```

  **重要**: PRED コメントは FIX-TDD-01 でシグネチャが推測由来の場合にのみ付与する。
  function_signatures が明示定義された場合は SPEC または BR コメントを使用する。
```

---

## FIX-TDD-03: STEP 7.5（RED テスト品質チェック）追加

**対応する幻覚戦略**: ⑥ 反復改善  
**公式ガイドライン違反箇所**:

> ⑥ **「反復的な改善」**
> Claude の出力を後続のプロンプトの入力として使用し、前の陳述を検証または拡張するよう依頼します。これにより、矛盾を検出して修正できます。

STEP 7 でテストを生成した後、STEP 8 では `--collect-only`（構文エラー検出のみ）に留まっており、アサーション品質・仕様参照コメント欠落・インライン定義などを**後続プロンプトで検証・修正するループが存在しない**。`pochi-unit-test-generator` の STEP 8.5 相当の品質チェックがないことがこの原則に違反している。

**問題**: STEP 7 の Layer2 テスト生成後、STEP 8 で `--collect-only` のみが実行される。
`pochi-unit-test-generator` の STEP 8.5 に相当するアサーション品質チェックが存在しない。
TDD 先行テストでも以下のアンチパターンが混入するリスクがある：
- 型チェックのみのアサーション（`assert isinstance(result, list)` のみ）
- `assert result is not None` のみ
- `try/except pass` パターン
- テストデータのインライン重複定義（`tests/fixtures/` を使わずにインラインでデータ定義）
- FIX-TDD-02 で指示した仕様参照コメントの欠落

**根拠**: STEP 7 と STEP 8 の間に品質チェックがない。STEP 8 は `--collect-only` のみで
アサーション内容の検証は行わない。

---

### FIX-TDD-03: STEP 7 と STEP 8 の間に STEP 7.5 を追加

**ファイル**: `skills/test/pochi-tdd-test-generator/skills/run/SKILL.md`  
**挿入位置**: STEP 7 のブロック末尾（`---` の直前）と STEP 8 の見出し（`## STEP 8:`）の間

**追加するテキスト**:

```markdown
---

## STEP 7.5: RED テスト品質チェック

Layer2 テストの生成後、以下の品質チェックを実行する。
**RED テストは実行不可でも構わないが、アサーション品質基準は守る必要がある。**

以下のコマンドを順番に実行し、結果を集計する：

```bash
# チェック1: 型チェックのみアサーション（単独 isinstance）
grep -rn "assert isinstance" tests/unit/ tests/contracts/

# チェック2: is not None のみ
grep -rn "assert.*is not None" tests/unit/ tests/contracts/

# チェック3: try/except pass
grep -A 3 "try:" tests/unit/ tests/contracts/ | grep -A 1 "except" | grep "pass"

# チェック4: インラインデータ重複（fixtures を使わずにデータを直接定義している行）
grep -rn "pd\.DataFrame(\[" tests/unit/ tests/contracts/

# チェック5: 仕様参照コメント欠落（def test_ 行の直後に # SPEC: / # BR: / # PRED: がない）
grep -n "def test_" tests/unit/*.py | head -20
```

### 品質基準

| チェック | 合格基準 | 超過時の対応 |
|---|---|---|
| チェック1: 型チェックのみ | 具体値アサーションと**併用**している場合のみ可 | 単独 isinstance は FAIL → 再生成 |
| チェック2: is not None のみ | 0件 | FAIL → 再生成（最大1回） |
| チェック3: try/except pass | 0件 | FAIL → 再生成（最大1回） |
| チェック4: インライン重複 | 0件推奨（警告扱い） | ⚠️ 警告のみ。修正推奨 |
| チェック5: 仕様参照コメント欠落 | 全 `def test_` の90%以上にコメントあり | ⚠️ 警告のみ。修正推奨 |

FAIL が検出された場合は、対象テスト関数を特定して修正し（最大1回）、その後 STEP 8 へ進む。

> 💡 **RED テスト固有の注意**: 具体値アサーションに `fixtures` の値を使う場合、
> fixtures が存在しない状態で `--collect-only` を実行すると `FileNotFoundError` が
> 発生する場合がある。これは ImportError と同様に想定内なので修正不要。
> チェック4は「テストコード内にデータをインライン定義している」場合のみ対象とすること。
```

---

## 実装順序ガイド

```
Step 1: FIX-TDD-01（STEP 6 フォールバック変更）
         → 影響大だが変更はプロンプトのみ。plan.json に function_signatures なしのケースで
           test-mapping.json の信頼性が最も向上する。

Step 2: FIX-TDD-02（STEP 7 コメント付与指示追加）
         → FIX-TDD-01 と連携（PRED コメントは FIX-TDD-01 と連動）。
           test-mapping.json の spec_reference フィールドの品質が向上する。

Step 3: FIX-TDD-03（STEP 7.5 品質チェック追加）
         → FIX-TDD-02 完了後に実施（チェック5は FIX-TDD-02 のコメント付与を前提）。
```

---

## 変更しないもの（スコープ外）

| 戦略 | 判定 | 理由 |
|------|------|------|
| ②直接引用から作業 | 対象外 | 全STEPで `<documents>` タグ経由の直接参照が実装済み。spec.json / plan.json が唯一の情報源として機能している |
| ⑤N検証 | 対象外 | STEP 8 の SyntaxError リトライ + FIX-TDD-03 で STEP 7.5 を追加することで実質的な品質検証ループが機能する。並列生成比較は過剰 |

---

## 参考: 既実装の幻覚対策（改修不要）

本スキルには以下の幻覚対策が既に実装されている：

| 幻覚対策 | 実装箇所 | 内容 |
|---|---|---|
| 入力ファイル不存在時の中断 | STEP 1（Glob自動検索） | spec.json / plan.json が0件の場合にスキル終了。「pochi-spec-initializerで先に仕様書を生成してください」と案内 |
| spec.json フォーマット検証 | STEP 2冒頭 `<validation_rules>` | `data_contracts` / `business_rules` フィールドなしで中断（両フィールドなしは処理停止）|
| Layer1 仕様参照コメント | STEP 5 | `# RISK: {リスクID}` により Layer1 テストが risk-catalog.md とトレーサブル |
| conftest.py収集エラー検証 | STEP 4 | `--collect-only` + grep で SyntaxError / NameError を最大3回リトライで修正 |
| 設計書→実装の2段階 | STEP 6 → STEP 7 | unit-test-design.md を経由することで関数設計と実装を分離（CoT相当） |
| importパスの制限 | STEP 4/7 | `plan.json の artifacts から推定した正式パスを使用する` で外部知識によるパス推測を制限 |
| fixtures 参照ルール | STEP 5/7 の constraints | `fixtures の活用` 制約でインライン重複定義を禁止（STEP 7.5 チェック4と補完） |
| ImportError は正常扱い | STEP 8 `<constraints>` | `import-error-ok` 制約でコード不在時の ImportError を修正対象から除外する |
| Layer3 スコープ外明示 | `<constraints>` `no-layer3` | Layer3（結合テスト）は明示的にスコープ外として誤生成を防ぐ |
