# pochi-test-orchestrator 幻覚対策改修計画

**作成日**: 2026-05-11  
**調査対象**: `reduce-hallucinations.md`（公式ガイドライン）vs `pochi-test-orchestrator` ロジック  
**ステータス**: 実装完了（2026-05-11）

---

## 概要

公式ガイドライン「幻覚を減らす」の7戦略と `pochi-test-orchestrator` の実装を突合調査した結果、
**5件の改修が必要**と判定した。本ドキュメントは各改修を即座に実行可能な粒度で整理したものである。

---

## 改修一覧（優先度順）

| # | 優先度 | 改修ID | 対象ファイル | 改修種別 |
|---|--------|--------|-------------|---------|
| 1 | 🔴 高 | FIX-01 | `quality_gate.py` + `test-case-specialist.md` | 新規チェック追加 |
| 2 | 🔴 高 | FIX-02 | `prompts/patterns/pattern_full.md` | セクション追加 |
| 3 | 🟡 中 | FIX-03 | `prompts/generate_test_cases_prompt.md` | ルール追記 |
| 4 | 🟡 中 | FIX-04 | `core/orchestrator.py` | テキスト変更 |
| 5 | 🟢 低 | FIX-05 | `prompts/core/checkpoint_rules.md` | チェック項目追加 |

---

## FIX-01: シナリオ名・機能名の実在性突合チェック追加

**対応する幻覚戦略**: ③引用で検証  
**公式ガイドライン違反箇所**:

> ③ **「引用で検証する」**
> Claude の応答を監査可能にするために、各主張について引用と出典を引用させます。Claude に応答を生成した後、各主張を検証するために支持する引用を見つけさせることもできます。引用が見つからない場合は、主張を撤回する必要があります。

`quality_gate.py` の突合チェックが UI ラベル文字列のみを対象としており、シナリオ名・機能名・「関連機能」列に `app_structure.md` 未記載の名称が混入しても検出されない。生成されたシナリオが `app_structure.md` のどの記述を根拠にしているか**監査できない状態**になっていることがこの原則に違反している。

**問題**: `quality_gate.py` の UI 要素突合チェックはラベル文字列のみが対象。シナリオ名・機能名・関連機能欄に `app_structure.md` に存在しない架空名称が混入しても品質ゲートが通過する。  
**根拠**: `quality_gate.py` の `extract_ui_elements()` と `check_ui_coverage()` は UI ラベルのみ検証（L413-L465）。シナリオ一覧テーブルの「関連機能」列はチェック対象外。

---

### FIX-01-A: `quality_gate.py` への突合関数追加

**ファイル**: `skills/test/pochi-test-orchestrator/core/quality_gate.py`  
**挿入位置**: `check_ambiguous_terms()` 関数の直前（`def check_ambiguous_terms` の前の行）

**追加するコード**:

```python
def check_scenario_traceability(
    test_cases_content: str,
    app_structure_content: str
) -> Tuple[int, List[str]]:
    """シナリオ一覧の「関連機能」列の値が app_structure.md に実在するかを確認する。

    架空の機能名・業務フロー名が混入していないかを検出する。

    Args:
        test_cases_content: test_cases.md の内容
        app_structure_content: app_structure.md の内容

    Returns:
        (実在しない機能名の件数, 実在しない機能名のリスト)
    """
    # シナリオ一覧テーブルの行から「関連機能」列を抽出
    # | SC-001 | シナリオ名 | 業務フロー | 関連機能 | 優先度 | 形式に対応
    scenario_rows = re.findall(
        r'^\|\s*SC-\d+\s*\|[^|]+\|[^|]+\|\s*([^|]+?)\s*\|',
        test_cases_content,
        re.MULTILINE
    )

    if not scenario_rows or not app_structure_content:
        return 0, []

    unverifiable = []
    for feature_cell in scenario_rows:
        feature = feature_cell.strip()
        # ヘッダー行・区切り行・空セルをスキップ
        if not feature or feature in ("関連機能", "---", "-"):
            continue
        # app_structure.md に部分一致するか確認（完全一致は厳しすぎるため部分一致）
        if feature not in app_structure_content:
            unverifiable.append(feature)

    return len(unverifiable), unverifiable
```

---

### FIX-01-B: `run_quality_gate_core()` 内でのチェック呼び出し追加

**ファイル**: `skills/test/pochi-test-orchestrator/core/quality_gate.py`  
**挿入位置**: `run_quality_gate_core()` 内の `check_ambiguous_terms()` 呼び出し直後

**追加するコード（呼び出し部分）**:

```python
    # シナリオ機能名の実在性突合チェック
    if app_structure_content:
        unverifiable_count, unverifiable_features = check_scenario_traceability(
            content, app_structure_content
        )
        if unverifiable_count > 0:
            report.add_warning(
                f"シナリオの「関連機能」欄に app_structure.md 未記載の名称が "
                f"{unverifiable_count} 件あります: {unverifiable_features[:5]}"
            )
```

---

### FIX-01-C: `test-case-specialist.md` の厳格サマリに根拠列追加

**ファイル**: `skills/test/pochi-test-orchestrator/agents/test-case-specialist.md`  
**対象箇所**: `## 2. 必須10項目チェック結果` セクションのフォーマット部分

**変更前**:
```markdown
1. **画面間インターフェース確認**: ✅ 実装あり（X件） / ❌ N/A（理由: XXX）
2. **トランザクション整合性確認**: ✅ 実装あり（X件） / ❌ N/A（理由: XXX）
```

**変更後**:
```markdown
1. **画面間インターフェース確認**: ✅ 実装あり（X件）（根拠: ファイル名 L行番号） / ❌ N/A（理由: XXX）
2. **トランザクション整合性確認**: ✅ 実装あり（X件）（根拠: ファイル名 L行番号） / ❌ N/A（理由: XXX）
```

全10項目について同様に `（根拠: ファイル名 L行番号）` を追記する。

---

## FIX-02: 引用抽出フェーズ（Phase 0）の追加

**対応する幻覚戦略**: ②直接引用から作業  
**公式ガイドライン違反箇所**:

> ② **「直接引用を事実の根拠として使用する」**
> 長いドキュメント（>20k トークン）に関連するタスクの場合、Claude にタスクを実行する前に、まず逐語的な引用を抽出するよう依頼します。これにより、その応答が実際のテキストに根拠づけられ、幻覚が減少します。

`pattern_full.md` のステップ1は `app_structure.md` の「分析」を指示しているが、生成**前**に UI 要素・機能名を逐語的に列挙させるフェーズが存在しない。大規模アプリで `app_structure.md` が長大になるほど、把握されないまま後半の機能が幻覚で補完されるリスクがあり、この原則に違反している。

**問題**: `pattern_full.md` のステップ1は「app_structure.md の分析」だが、分析結果を明示的に列挙させないため、LLM が全UI要素・機能名を把握しないまま生成に入る。大規模アプリほど後半の機能が幻覚で埋められるリスクがある。  
**根拠**: `pattern_full.md` L1-L20 のステップ定義に引用先行抽出フェーズが存在しない。

---

### FIX-02: `pattern_full.md` への Phase 0 挿入

**ファイル**: `skills/test/pochi-test-orchestrator/prompts/patterns/pattern_full.md`  
**挿入位置**: `### 実行手順` と `#### 1. app_structure.mdの分析` の間

**追加するテキスト**:

```markdown
#### 0. 引用抽出フェーズ（テストケース生成前に必ず実施）

**目的**: 生成対象の範囲を確定し、存在しない機能・UIラベルへの幻覚を防ぐ。

テストケースの生成を開始する**前**に、以下を `app_structure.md` から逐語的に列挙すること。

**0-1. UI要素リストの列挙**

`app_structure.md` の「🎨 UI要素詳細」セクションから全要素名を抽出し、以下の形式で列挙する:

```
UI要素一覧（XX件）:
- 「この条件で検索を実行する」ボタン (st.button)
- 「店舗を選択してください」セレクトボックス (st.selectbox)
...（全件記載）
```

**0-2. 機能名リストの列挙**

`app_structure.md` の「主要機能」「機能一覧」などのセクションから全機能名を抽出し、以下の形式で列挙する:

```
機能一覧（YY件）:
- 店舗検索機能
- CSV一括アップロード
...（全件記載）
```

**制約（必須）**:
- 0-1 で列挙したリストにないUIラベル・ボタン名をテストケースで使用しないこと
- 0-2 で列挙したリストにない機能名・シナリオ名をテストケースで使用しないこと
- リストにない名称を使いたい場合は `app_structure.md` を再確認し、存在する名称に言い換えること
```

---

## FIX-03: 機能名・シナリオ名への外部知識補完禁止ルール追加

**対応する幻覚戦略**: ⑦外部知識の制限  
**公式ガイドライン違反箇所**:

> ④ **「外部知識の制限」**
> Claude に提供されたドキュメントからの情報のみを使用し、一般的な知識を使用しないよう明示的に指示します。

`generate_test_cases_prompt.md` には UI ラベルの「推測・省略禁止」が記載されているが、シナリオ名・機能説明・業務フロー名への制限がない。一般的な ERP・小売業の知識からフローを補完すること（外部知識の利用）を明示的に禁じる記述がなく、この原則に違反している。

**問題**: `generate_test_cases_prompt.md` にはUIラベルの「推測・省略禁止」は明示されているが、シナリオ名・機能説明・業務フロー名に対する外部知識補完禁止の記述がない。LLM が一般的なERP・小売業の知識からフローを補完するリスクがある。  
**根拠**: `generate_test_cases_prompt.md` L351, L377 は UI ラベルのみ対象。機能名・シナリオ名への制限なし。

---

### FIX-03: `generate_test_cases_prompt.md` への禁止ルール追記

**ファイル**: `skills/test/pochi-test-orchestrator/prompts/generate_test_cases_prompt.md`  
**挿入位置**: `## テストケース生成時の判定基準` セクションの直後（判定基準3つの直後）

**追加するテキスト**:

```markdown
## テストケース生成時の外部知識補完禁止ルール

シナリオ名・機能名・業務フロー名の記述において、以下のルールを**厳守**すること。

### 禁止事項

- ❌ `app_structure.md` に存在しない機能名をシナリオ名・関連機能欄に記載する
  - 例: 「月次集計機能」が `app_structure.md` に存在しなければ使用不可
- ❌ `app_structure.md` に存在しないページ名・画面名を操作フローに含める
- ❌ 一般的な業務知識（小売業、ERP等）から機能・フローを補完する

### 許可事項

- ✅ `app_structure.md` の「主要機能」「🎨 UI要素詳細」等に記載された名称をそのまま使用する
- ✅ `app_structure.md` に記載のある機能を組み合わせてシナリオを構成する

### チェック方法

シナリオ名・機能名を記述する前に、その名称が `app_structure.md` のどのセクション・行に存在するかを確認すること。
見つからない場合は、`app_structure.md` の実在する機能名に言い換えるか、記述を省略すること。
```

---

## FIX-04: 「推測して続行」から「根拠不明フラグ付与」への変更

**対応する幻覚戦略**: ①不確実性を認める許可  
**公式ガイドライン違反箇所**:

> ① **「Claude に「わかりません」と言うことを許可する」**
> Claude に不確実性を認める許可を明示的に与えます。この単純な技術は、誤った情報を大幅に減らすことができます。

`core/orchestrator.py` L663 に `「不明な点があっても推測して実装を進める」` という記述があり、`app_structure.md` が空・不完全な状態でも架空のテストケース生成を続けるよう**幻覚を積極的に奨励している**。公式ガイドラインが求める「不確実なら認める」という原則と真逆の動作をさせる指示であり、この原則に直接違反している。

**問題**: `orchestrator.py` の「問い返し禁止ルール」に `「不明な点があっても推測して実装を進める」` という記述があり、app_structure.md が空・不完全な状態でも架空テストケース生成を続けるよう指示している。幻覚を積極的に奨励する記述になっている。  
**根拠**: `core/orchestrator.py` L663 `「不明な点があっても推測して実装を進める」`

---

### FIX-04: `orchestrator.py` の問い返し禁止ルール修正

**ファイル**: `skills/test/pochi-test-orchestrator/core/orchestrator.py`

**変更前**（L658-L666 相当のテキスト文字列内）:

```
## 5. 問い返し禁止ルール

- 参照ファイルが欠落している場合でもエラーを出さず、利用可能な情報で継続
- 不明な点があっても推測して実装を進める
- 完全な情報が揃わなくても、ベストエフォートで生成を完了する
```

**変更後**:

```
## 5. 問い返し禁止ルール

- 参照ファイルが欠落している場合でもエラーを出さず、利用可能な情報で継続
- **app_structure.md の UI 要素が 3 件未満、または機能一覧が空の場合**:
  - 架空の機能名・UI 要素名を補完することを禁止する
  - 根拠が app_structure.md にないテストケースには `【要確認: 根拠なし】` フラグを付与する
  - 厳格サマリに「根拠不明件数: X 件」を記録する
- 完全な情報が揃わなくても、ベストエフォートで生成を完了する（ただし根拠不明フラグを付与すること）
```

---

## FIX-05: CP5（生成根拠の記録チェック）の追加

**対応する幻覚戦略**: ④思考の連鎖検証  
**公式ガイドライン違反箇所**:

> **「思考の連鎖検証」**
> Claude に最終的な答えを与える前に、段階的に推論を説明するよう依頼します。これにより、欠陥のあるロジックまたは仮定を明らかにすることができます。

CP1〜CP4 は曖昧表現・観点比率・UI カバレッジ・具体値の定量チェックのみで、「このテストケースはなぜこのシナリオ名・機能名なのか」という**設計根拠の推論プロセスを説明させるチェックがない**。10件ごとのチェックポイントで根拠確認なしに生成を続行させていることがこの原則に違反している。

**問題**: CP1〜CP4 は曖昧表現・観点比率・UI カバレッジ・具体値の数値チェックのみ。各テストケースの設計根拠（どの記述から設計したか）を確認するチェックがないため、幻覚が埋め込まれていても10件ごとのチェックで検出できない。  
**根拠**: `prompts/core/checkpoint_rules.md` の CP1〜CP4 は全て定量的数値チェック。定性的根拠確認なし。

---

### FIX-05: `checkpoint_rules.md` への CP5 追記

**ファイル**: `skills/test/pochi-test-orchestrator/prompts/core/checkpoint_rules.md`  
**挿入位置**: `## チェックポイント通過基準` セクションの直前

**追加するテキスト**:

```markdown
### CP5: 生成根拠の記録（10件ごと）

**目的**: 幻覚テストケースの混入を防ぐため、設計根拠を確認する

**実施手順**:
直前10件から任意の3件を選び、それぞれについて以下を確認する:

1. このテストケースのシナリオ名・機能名は `app_structure.md` のどの記述に基づいているか？
   - ✅ 根拠あり: 「app_structure.md の『検索機能』セクション記載内容より」
   - ❌ 根拠なし: テストケースに `【要確認: 根拠なし】` フラグを付与する

2. 期待結果に記載した具体値（件数・メッセージ文字列等）はどこから取得したか？
   - ✅ 根拠あり: 「app_structure.md の『エラーメッセージ一覧』記載の文字列より」
   - ⚠️ 推測値: 具体値の前に `【推定値】` を明示する

**合格基準**: 3件中2件以上で根拠が確認できること  
根拠不明が2件以上の場合: 当該テストケースを `app_structure.md` で再確認してから次の10件に進む
```

**`## チェックポイント通過基準` の `継続条件` に項目追加**:

```markdown
### 継続条件（次の10件に進む）
以下の条件をすべて満たす場合、次の10件の生成に進みます：

1. **曖昧表現**: 0件
2. **観点比率**: 目標範囲内 または 調整計画あり
3. **UI要素カバレッジ**: 目標進捗ライン上（±5%以内）
4. **具体値**: すべてのテストケースに含まれている
5. **生成根拠 (CP5)**: 3件中2件以上で根拠確認済み  ← 追加
```

---

## 実装順序ガイド

改修は以下の順序で実施することを推奨する。各ステップは独立して動作確認可能。

```
Step 1: FIX-04（orchestrator.py テキスト変更）
         → 最小変更・即日適用可能。幻覚奨励文言の除去。

Step 2: FIX-03（generate_test_cases_prompt.md ルール追記）
         → プロンプト追記のみ。LLM への入力制約を明示。

Step 3: FIX-02（pattern_full.md Phase 0 追加）
         → プロンプト追記。引用抽出フェーズで生成前の根拠確定。

Step 4: FIX-05（checkpoint_rules.md CP5 追加）
         → プロンプト追記。生成中のリアルタイム検出強化。

Step 5: FIX-01（quality_gate.py + test-case-specialist.md 機能名突合）
         → Pythonコード追加。品質ゲートでの事後検出強化。
         → FIX-01-A → FIX-01-B → FIX-01-C の順で実施。
```

---

## 変更しないもの（スコープ外）

以下は調査したが改修対象外と判定した:

| 戦略 | 判定 | 理由 |
|------|------|------|
| プリフィル（Assistant ターン先頭強調） | 対象外 | 公式ガイドライン自体が Sonnet 4.6 はプリフィル非対応と明記 |
| N検証（複数回生成比較） | 対象外 | コスト・レイテンシが大幅増加する割に、品質ゲート修正ループで実質カバー済み |
| ポスト処理フィルタ（プロンプトリーク） | 対象外 | 開発者ツールのため機密保護の必要性が低い（別 issue: reduce-prompt-leak.md 対応）|

---

## 参考: 調査で確認した既実装の幻覚対策

改修不要と判定した対策（すでに適切に実装されている）:

- **UIラベルの突合チェック**: `quality_gate.py` の `extract_ui_elements()` + `check_ui_coverage()` で実装済み
- **「推測・省略禁止」指示**: `generate_test_cases_prompt.md` L351, L377 で UIラベルに限定して実装済み
- **反復改善ループ**: `SKILL.md` の品質ゲート→修正（最大3回）ループで実装済み
- **具体値必須チェック（CP1/CP4）**: `checkpoint_rules.md` + `quality_gate.py` で実装済み
