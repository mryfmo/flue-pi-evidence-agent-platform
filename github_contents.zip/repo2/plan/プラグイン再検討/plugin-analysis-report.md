# プラグイン配布方式 再検討レポート

**作成日**: 2026-05-12  
**対象リポジトリ**: `/home/user/pochi-dp-developer-docs`  
**配布名**: `pochi-internal-skills`

---

## 1. 調査概要

`pochi-dp-developer-docs` リポジトリは、Pochiアプリ開発を効率化するClaude Code Skills集として、社内向けにプラグイン配布を行っている。本レポートでは、現在の配布方式がプラグインシステムの本来のメリットをどの程度享受できているかを分析する。

---

## 2. 現在の配布方式

### セットアップ手順（現状）

```bash
# ステップ1: リポジトリをクローン（必須）
git clone -b feature/claude-marketplace https://github.com/nttdocomo-com/pochi-dp-developer-docs.git /home/user/pochi-dp-developer-docs

# ステップ2: マーケットプレイスをローカルパスで登録
/plugin marketplace add /home/user/pochi-dp-developer-docs

# ステップ3: 各Skillをインストール（24個）
/plugin install pochi-spec-initializer@pochi-internal-skills
/plugin install pochi-coding-agent@pochi-internal-skills
# ...（以下同様）
```

### 構成ファイル

| ファイル | 役割 |
|---|---|
| `.claude-plugin/marketplace.json` | マーケットプレイスカタログ（24スキル登録） |
| `.claude/skills.json` | スキル定義（27エントリ） |
| `skills/<category>/<name>/plugin.json` | 各スキルのroot plugin.json |
| `skills/<category>/<name>/.claude-plugin/plugin.json` | プラグインシステムが読むplugin.json |

---

## 3. スキル構成の現状

### アクティブSkill（24個）

| カテゴリ | 件数 | 代表Skill |
|---|---|---|
| spec/ | 6 | pochi-spec-initializer, pochi-coding-agent, marp-presentation 他 |
| test/ | 4 | pochi-unit-test-generator, pochi-tdd-test-generator 他 |
| infra/ | 6 | pochilib-update-analyst（統合）+ 子Skill群 |
| ops/ | 6 | hypothesis-generator, ux-review 他 |
| tools/ | 2 | pochi-skill-generator, pochi-skill-navigator |

### 廃止済み（archive/）: 16個

---

## 4. プラグインメリットの享受状況

### 4.1 メリット一覧と評価

| # | メリット | 状態 | 詳細 |
|---|---|:---:|---|
| M1 | git clone不要のワンステップインストール | ❌ | ローカルパス方式のため事前に `git clone` が必須 |
| M2 | 特定バージョン/ブランチの指定インストール | ❌ | ローカルパス方式ではタグ・ブランチ指定が不可 |
| M3 | Project scopeによる全コラボレーター自動展開 | ❌ | 絶対パス (`/home/user/...`) 依存で他環境では動作しない |
| M4 | バージョン更新によるキャッシュ自動再生成 | ⚠️ | `.claude-plugin/plugin.json` と root `plugin.json` でバージョン乖離（4Skill） |
| M5 | Discoverタブでの検索・発見 | ⚠️ | 全Skillの `keywords` が空のため検索にヒットしない |
| M6 | 全Skillの一括配布 | ⚠️ | 3Skillが `marketplace.json` に未登録（`/plugin install` 不可） |
| M7 | チーム共有の仕組み | ✅ | `/plugin install <name>@pochi-internal-skills` フローは整備済み |
| M8 | 名前空間による競合防止 | ✅ | `pochi-internal-skills` 名前空間が機能している |
| M9 | キャッシュによる独立動作 | ✅ | `~/.claude/plugins/cache/` にコピーされて動作する |

---

## 5. 問題の根本原因

### 問題A: 配布方式がローカルパス方式（M1〜M3 の根本原因）

現在 `/plugin marketplace add` に渡しているのは **ローカルの絶対パス** `(/home/user/pochi-dp-developer-docs)` である。公式ドキュメントでは以下の形式がサポートされている。

| 形式 | 例 | git clone不要か |
|---|---|:---:|
| ローカルパス（現在） | `/home/user/pochi-dp-developer-docs` | ❌ |
| GitHubリポジトリ | `nttdocomo-com/pochi-dp-developer-docs` | ✅ |
| Git URL | `https://gitlab.com/...` | ✅ |
| リモートURL | `https://example.com/marketplace.json` | ✅ |

**影響**:
- `git clone` がセットアップの必須前提になり、プラグイン配布の最大メリットが消える
- 絶対パスが環境固有のため、Project scopeに保存しても他ユーザーには機能しない
- バージョン/タグ指定によるSkillの固定インストールが不可能

### 問題B: 設定ファイルの管理不備（M4〜M6 の原因）

**バージョン乖離（M4）**: `.claude-plugin/plugin.json`（プラグインシステムが読む）と root `plugin.json` で バージョンが異なるSkillが4つ存在する。プラグインシステムはバージョン変更を検知してキャッシュを再生成するため、乖離があるとユーザーに古いバージョンが使われ続ける。

| Skill | `.claude-plugin/plugin.json` | root `plugin.json` |
|---|---|---|
| `pochi-spec-initializer` | 1.0.0 | **1.2.0** |
| `pochi-coding-agent` | 1.0.0 | **1.1.0** |
| `pochi-test-orchestrator` | 1.0.0 | **1.2.0** |
| `pochilib-update-analyst` | 1.0.0 | **1.4.1** |

**marketplace.json 未登録（M6）**: skills.jsonには登録されているが marketplace.jsonに存在しないSkillが3つある。これらは `/plugin install` できない。

| 未登録Skill |
|---|
| `column-mapping-initializer` |
| `column-matching-verifier` |
| `column-query-generator` |

**keywords空（M5）**: アクティブSkill全24個の `plugin.json` で `keywords: []` が空。Discoverタブでの検索性ゼロ。

---

## 6. スタンドアロン方式との実質比較

プラグイン配布の本来のメリットが得られていない現状を踏まえ、リポジトリをクローンして `.claude/skills` として使う**スタンドアロン方式**と実質的に比較する。

| 比較点 | 現在のプラグイン方式 | スタンドアロン方式 |
|---|---|---|
| セットアップ手順数 | **3ステップ**（clone → marketplace add → install × n） | **1ステップ**（clone のみ） |
| git clone 必要か | ✅ 必要 | ✅ 必要 |
| キャッシュ独立 | ✅ リポジトリ削除後も動く | ❌ リポジトリが消えると使えない |
| 個別インストール選択 | ✅ スキルを選べる | ❌ 全部か無し |
| バージョン記録 | ✅ plugin.jsonで記録される | ❌ なし |
| スキル名の呼び出し | `pochi-internal-skills:skill-name`（長い） | `/skill-name`（短い） |
| 更新の反映 | `/reload-plugins` 必要 | リポジトリ変更が即反映 |
| セットアップ複雑さ | **高い** | **低い** |

**結論**: 現在はプラグイン方式のセットアップコストがスタンドアロンより高い一方、得られる上乗せ価値は「キャッシュ独立」「個別インストール選択」「バージョン記録」の3点のみであり、**コストとリターンが見合っていない状態**。

---

## 7. 改善方針

### 方針A: 配布方式をGitHub形式に変更（根本解決）

```bash
# 変更後のセットアップ（git clone不要）
/plugin marketplace add nttdocomo-com/pochi-dp-developer-docs#feature/claude-marketplace
/plugin install pochi-spec-initializer@pochi-internal-skills
```

これにより M1〜M3 が全て解決し、プラグイン配布の本来のメリットが得られる。  
**前提**: リポジトリがGitHub上でアクセス可能であること（社内GitHubの場合はドメイン確認が必要）。

### 方針B: 設定ファイルの修正（設定修正のみ）

配布方式を変えない場合でも、以下の設定修正で M4〜M6 は改善できる。

| 優先度 | 対応 | 対象 |
|---|---|---|
| 🔴 高 | `.claude-plugin/plugin.json` のバージョンをroot `plugin.json` に合わせる | 4Skill |
| 🔴 高 | `marketplace.json` に3Skillを追加 | column-mapping-initializer 他2つ |
| 🟡 中 | 各Skillの `keywords` にキーワードを追加 | 全24Skill |

---

## 8. 推奨アクション

1. **社内GitHubへのアクセス方式を確認し、方針Aの実現可否を判断する**（最優先）
2. 方針Aが困難な場合、方針Bの設定修正を実施してスタンドアロン方式への切り替えを検討する
3. 方針Aが実現できる場合、READMEのセットアップ手順を書き直す

---

## 参照

- 公式ドキュメント: [claude-code-guide/official/plugin.md](../../claude-code-guide/official/plugin.md)
- 公式ドキュメント: [claude-code-guide/official/plugin-marketplace.md](../../claude-code-guide/official/plugin-marketplace.md)
- 配布設定: [.claude-plugin/marketplace.json](../../.claude-plugin/marketplace.json)
- スキル定義: [.claude/skills.json](../../.claude/skills.json)

---

## 9. 検証記録（2026-05-12 追記）

レポート作成後に行った調査・検証の記録。

---

### 9.1 GitHub形式への変更で解決する課題・しない課題

**Q: GitHub形式への変更で複数の課題が解決するか？**

解決する課題（M1〜M3）と解決しない課題（M4〜M6）は以下の通り。

| 課題 | GitHub形式で解決するか | 理由 |
|---|:---:|---|
| M1: git clone不要 | ✅ | Claude Codeが内部でフェッチするため |
| M2: バージョン/ブランチ指定 | ✅ | `#feature/claude-marketplace` 形式が使える |
| M3: Project scope展開 | ✅ | URLは環境非依存のため他ユーザー環境でも機能する |
| M4: バージョン乖離 | ❌ | 配布方式と無関係。設定ファイルの手動修正が必要 |
| M5: keywords空 | ❌ | 配布方式と無関係。plugin.jsonへの手動追加が必要 |
| M6: marketplace未登録 | ❌ | 配布方式と無関係。marketplace.jsonへの手動追加が必要 |

---

### 9.2 社内リポジトリの実態確認

当初「社内GitHub Enterprise（専用ドメイン）」と想定していたが、実際のURLを確認したところ **`github.com`** であった。

```
https://github.com/nttdocomo-com/pochi-dp-developer-docs.git
```

これにより：
- `owner/repo` 短縮形式（`nttdocomo-com/pochi-dp-developer-docs`）が使える
- GitHub Enterprise専用ドメインへの対応は不要

---

### 9.3 /plugin marketplace add コマンドの実行場所と認証条件

**実行場所**: ターミナルではなく **Claude Codeのチャット欄**（`/` から始まるコマンド）

**認証条件**: Claude Codeが内部でgit操作を行う際にユーザーのgit認証情報を利用する。以下のいずれかが設定されていれば動作する。

| 認証方法 | 条件 |
|---|---|
| `gh auth git-credential` | `gh auth setup-git` または `gh auth login` 実行済み |
| SSHキー | `~/.ssh/` にGitHub用の鍵が設定済み |
| credential store | 過去にHTTPSでcloneしてトークン保存済み |

**注意**: 公式ドキュメントにはプライベートリポジトリの認証挙動の明記はなく、実際に試して確認する必要がある。

---

### 9.4 方針Aの実証（2026-05-12 検証済み）

Claude Codeのチャット欄で以下を実行し、**成功を確認**した：

```
/plugin marketplace add nttdocomo-com/pochi-dp-developer-docs#feature/claude-marketplace
→ Successfully added marketplace: pochi-internal-skills
```

事前に `git ls-remote` でブランチ一覧の取得も確認済み：

```bash
git ls-remote https://github.com/nttdocomo-com/pochi-dp-developer-docs.git
# → feature/claude-marketplace ブランチを含む全ブランチ一覧が返った
```

**方針A（GitHub形式への切り替え）は実現可能と実証された。**

---

### 9.5 認証が通った理由

`~/.gitconfig` に以下が設定されていたことが原因：

```
credential.https://github.com.helper = !/usr/bin/gh auth git-credential
```

これは環境プロビジョニング時に自動設定されたものと推測される（意識的に設定した覚えなし）。

---

### 9.6 他ユーザーへの展開可否

**前提条件**: 他のユーザーも同じコンテナ環境で同じプロビジョニングを受けていれば、同様の `gh auth git-credential` 設定が入っているはず。ただし個人のGitHubトークンが `gh` に保存されていることが必要。

**事前確認コマンド**（READMEに追加推奨）:

```bash
# ターミナルで実行して認証が通るか確認
git ls-remote https://github.com/nttdocomo-com/pochi-dp-developer-docs.git

# → ブランチ一覧が返れば /plugin marketplace add を試せる
# → 認証エラーの場合は従来のローカルパス方式にフォールバック
```

**認証が通る場合のセットアップ（新方式）**:

```
# Claude Codeのチャット欄で実行
/plugin marketplace add nttdocomo-com/pochi-dp-developer-docs#feature/claude-marketplace
/plugin install pochi-spec-initializer@pochi-internal-skills
# ...（必要なSkillだけ選択）
```

`git clone` が不要になり、セットアップ手順が3ステップ→2ステップに削減される。

---

### 9.7 更新後の推奨アクション（再整理）

| 優先度 | アクション | 備考 |
|---|---|---|
| 🔴 1 | READMEのセットアップ手順をGitHub形式に更新 | 方針Aが実証済みのため |
| 🔴 2 | `.claude-plugin/plugin.json` のバージョンをroot `plugin.json` に合わせる | 4Skill対象 |
| 🔴 3 | `marketplace.json` に3Skillを追加 | column-mapping-initializer 他2つ |
| 🟡 4 | 各Skillの `keywords` にキーワードを追加 | 全24Skill対象 |

---

### 9.8 GitHub形式変更後の更新運用の変化

**Q: GitHub形式に切り替えた後、リモートに更新が入った場合の各ユーザーの運用はどう変わるか？**

#### 現在（ローカルパス方式）の更新フロー

```
リモートにpush
  ↓
各ユーザーが手動で git pull（ターミナル）
  ↓
Claude Codeのチャット欄で /reload-plugins
```

- `git pull` はターミナル作業のため、Claude Code外の操作が必要
- 更新通知の仕組みがなく、ユーザーが自分で気づく必要がある

#### GitHub形式変更後：パターン①　自動更新（opt-in）

```
リモートにpush
  ↓
次回 Claude Code 起動時に自動フェッチ（git pull不要）
  ↓
「プラグインが更新されました。/reload-plugins を実行してください」と通知
  ↓
ユーザーが /reload-plugins を実行
```

- `/plugin` → **Marketplaces** タブ → **Enable auto-update** で有効化
- **サードパーティマーケットプレイスはデフォルトでOFF**（公式AnthropicマーケットプレイスのみデフォルトON）のため、ユーザーが明示的に有効にする必要がある

#### GitHub形式変更後：パターン②　手動更新

```
リモートにpush
  ↓
ユーザーが Claude Codeチャット欄で実行：
/plugin marketplace update pochi-internal-skills
  ↓
/reload-plugins
```

#### 比較表

| 操作 | 現在（ローカルパス） | GitHub形式 |
|---|---|---|
| 更新の取得 | ターミナルで `git pull` | Claude Code内で完結（自動 or `/plugin marketplace update`） |
| 更新の検知 | ユーザーが自分で気づく必要あり | 自動更新ONなら起動時に通知あり |
| `/reload-plugins` | 必要 | 必要（変わらず） |
| git clone の維持 | 必要 | 不要（キャッシュで独立動作） |

**重要な注意点**:

1. **`/reload-plugins` は引き続き必要** — GitHub形式でも更新後のリロードは省略できない
2. **自動更新はデフォルトOFF** — ユーザーごとに `/plugin` → Marketplaces → Enable auto-update を設定してもらう必要がある。READMEのセットアップ手順への追記を推奨
3. **M4（バージョン乖離）との依存関係** — 自動更新の検知は `plugin.json` のバージョン変更を基準にする。`.claude-plugin/plugin.json` のバージョンがroot `plugin.json` と一致していないと更新が正しく検知されないため、GitHub形式移行前にM4対応が必須
4. **Project scope活用の可能性** — GitHub形式になれば `.claude/settings.json` の `extraKnownMarketplaces` にリポジトリURLを設定でき、リポジトリを信頼した時点でインストールを促すプロンプトが出る。チームへの展開をさらに簡略化できる

---

### 9.9 `enabledPlugins` がsettings.jsonに追加されるタイミングと格納先

**Q: `/plugin install` や `/plugin marketplace add` を実行すると、ユーザーの `~/.claude/settings.json` に `enabledPlugins` フィールドが追加されるが、GitHub形式に変更しても同じか？**

`enabledPlugins` は `/plugin install` を実行した際に、**インストールスコープに応じた settings.json に Claude Code が自動書き込み**する。

| スコープ | 書き込み先 | git管理 | 影響範囲 |
|---|---|:---:|---|
| User（デフォルト） | `~/.claude/settings.json` | ❌ | 自分のみ（全プロジェクト共通） |
| Project | `.claude/settings.json`（リポジトリ内） | ✅ | チーム全員 |
| Local | `.claude/settings.local.json`（リポジトリ内） | ❌ | 自分のみ（そのリポジトリのみ） |

記録形式は `"plugin-name@marketplace-name": true` であり、ソースURLは含まれない。

```json
// ~/.claude/settings.json（User scope の実例）
"enabledPlugins": {
    "pochi-spec-initializer@pochi-internal-skills": true,
    "pochi-coding-agent@pochi-internal-skills": true
    ...
}
```

マーケットプレイスのソース情報（ローカルパスかGitHubかの区別）は `extraKnownMarketplaces` に別途記録される。

```json
// GitHub形式変更後の extraKnownMarketplaces
"extraKnownMarketplaces": {
    "pochi-internal-skills": {
        "source": {
            "source": "github",
            "repo": "nttdocomo-com/pochi-dp-developer-docs",
            "ref": "feature/claude-marketplace"
        },
        "autoUpdate": true
    }
}
```

**GitHub形式に切り替えても `enabledPlugins` のキー（`@pochi-internal-skills`）はマーケットプレイス名から決まるため変わらない。** 変わるのは `extraKnownMarketplaces` の `source` フィールドだけであり、既存ユーザーのプラグインの再インストールは不要。

---

### 9.10 `enabledPlugins` の自動書き込みに負の影響はないか

**Q: プラグインインストール時に自動で settings.json に書き込まれるが、何かしらの負の影響はないか？**

**基本的には負の影響なし。** `enabledPlugins` は `"plugin-name@marketplace-name": true` という有効フラグを記録するだけで、実行コードやファイルパスは含まれない。マーケットプレイスが未登録・削除された場合でも、Claude Code は該当エントリをスキップするだけで動作に支障はない。

**唯一の注意点：Project scope でインストールした場合**

デフォルトのUser scopeでは `~/.claude/settings.json`（git管理外）に書き込まれるため問題ないが、`--scope project` オプション等でProject scopeを選択すると `.claude/settings.json`（リポジトリ内・git管理対象）に書き込まれる。このファイルがリモートにプッシュされると、マーケットプレイスを未登録の他メンバー環境でも「有効化済み」として記録される。

現在の運用（User scopeがデフォルト）では実質的に問題なし。GitHub形式への切り替えでもこの挙動は変わらない。
