# ソフトウェア品質特性をAIDDのガードレールとして組み込む計画

## 背景・目的

現在のAIDDは「速くコードを生成する」ことに最適化されているが、品質が偶発的になっている。
MinoDriven氏の指摘の通り、**品質特性を中心に置き、AIをその達成手段として使う**構造に転換する。

> 「ソフトウェア開発とは品質特性の作り込みである。品質を置き去りにして速くしても持続困難」

---

## アイデアの核心

品質特性を **「ガードレール」** として仕様に記述し、CC（Claude Code）はその制約の中でのみコーディング・テストを行う。

```
【Before】
「実装して」→ CCが"なんとなく良さそうな"コードを生成 → 品質は偶発的

【After】
Pochi標準 quality_requirements を組織として一度定義する（~/.claude/CLAUDE.md）
  → pochi-spec-initializer がそれをデフォルトとして spec.json に自動埋め込む
    （例外的な調整のみ、最後にオーバーライドヒアリングを実施）
  → pochi-coding-agent が quality_requirements を参照して実装
  → pochi-unit/tdd-test-generator が品質特性ごとに必要なテストを追加生成
  → github-pr-reviewer が品質ガードレール達成を確認して初めてPRが通る
```

---

## 品質特性と現在のスキルのギャップ

| 品質特性 | 現在のカバー | ギャップ |
|---|---|---|
| 機能適合性 | ★★★ spec-initializer, unit-test-generator | ほぼ対応済み |
| 保守性 | ★★☆ pr-reviewer, ruff | テスト容易性（試験性）の担保が弱い |
| 使用性 | ★★☆ ux-review, ui-generator | 評価はできるがガードレールとして機能していない |
| セキュリティ | ★★☆ pochilib-update-analyst | 実装後のチェックが手動・事後的 |
| 信頼性 | ★☆☆ e2e-test-generator（一部） | 異常系・障害ケーステストが体系的でない |
| 性能効率性 | ★☆☆ | Snowflakeクエリ性能の観点がほぼ未対応 |
| 互換性 | ★☆☆ | pochilib更新時の後方互換確認が手動 |
| 移植性 | ★☆☆ | Pochiアプリの性質上、優先度は低くてよい |

→ Pochiアプリとして特に重要なのは **保守性・セキュリティ・信頼性** のギャップを埋めること。
性能効率性（Snowflakeクエリ）・互換性（pochilib更新）は中期的に対応。

---

## 実装計画（3フェーズ）

---

### Phase 1：仕様定義への組み込み（今すぐ着手可能）

**目的**: 開発フローの起点で品質特性を定義させる。ここを変えれば後続フロー全体が品質特性駆動になる。

**対象スキル**: `pochi-spec-initializer`

#### 1-1. spec.json に quality_requirements フィールドを追加

```json
"quality_requirements": {
  "maintainability": {
    "priority": "high",
    "criteria": [
      "テストカバレッジ80%以上",
      "循環的複雑度10以下",
      "関数は単一責任（1関数1役割）"
    ]
  },
  "security": {
    "priority": "high",
    "criteria": [
      "ユーザー入力は全てバリデーション必須",
      "Snowflakeクエリはパラメータバインド必須（SQLインジェクション対策）",
      "機密情報（APIキー等）はst.secrets経由のみ許可"
    ]
  },
  "reliability": {
    "priority": "medium",
    "criteria": [
      "Snowflake接続エラーは必ずハンドリング",
      "LLM呼び出しはタイムアウト・リトライ処理必須",
      "異常系テストケースを正常系と同数以上生成"
    ]
  },
  "performance_efficiency": {
    "priority": "low",
    "criteria": [
      "Snowflakeクエリ実行時間3秒以内を目標",
      "st.cache_data を適切に使用"
    ]
  },
  "usability": {
    "priority": "medium",
    "criteria": [
      "UIガイドライン（DESIGN.md）に準拠",
      "エラーメッセージはユーザー向けの日本語で表示"
    ]
  }
}
```

#### 1-2. Pochi標準 quality_requirements の事前定義と適用方針

Pochiアプリは全て「Streamlit + Snowflake + pochilib」「社内向け」「業務データ」「長期運用前提」という共通条件を持つ。
これらの答えは毎回ヒアリングしなくても決まっているため、**組織として品質特性を一度定義し、全アプリに適用する**。

##### 定義場所

```
~/.claude/CLAUDE.md（全プロジェクト共通）
```

Pochi標準 quality_requirements を以下の形式で記述する。`pochi-spec-initializer` はこれをデフォルト値として読み込み、`spec.json` の `quality_requirements` に自動埋め込む。

##### Pochi標準 quality_requirements（組織共通定義）

```json
"pochi_standard_quality_requirements": {
  "maintainability": {
    "priority": "high",
    "criteria": [
      "テストカバレッジ80%以上",
      "循環的複雑度10以下",
      "関数は単一責任（1関数1役割）",
      "型ヒントを全関数に付与"
    ]
  },
  "security": {
    "priority": "high",
    "criteria": [
      "ユーザー入力は全てバリデーション必須",
      "Snowflakeクエリはパラメータバインド必須（SQLインジェクション対策）",
      "機密情報（APIキー等）はst.secrets経由のみ許可"
    ]
  },
  "reliability": {
    "priority": "medium",
    "criteria": [
      "Snowflake接続エラーは必ずハンドリング",
      "LLM呼び出しはタイムアウト・リトライ処理必須",
      "異常系テストケースを正常系と同数以上生成"
    ]
  },
  "performance_efficiency": {
    "priority": "low",
    "criteria": [
      "Snowflakeクエリ実行時間3秒以内を目標",
      "st.cache_data を適切に使用"
    ]
  },
  "usability": {
    "priority": "medium",
    "criteria": [
      "UIガイドライン（DESIGN.md）に準拠",
      "エラーメッセージはユーザー向けの日本語で表示"
    ]
  },
  "compatibility": {
    "priority": "medium",
    "criteria": [
      "pochilib更新時に既存APIシグネチャを破壊しない",
      "既存の公開関数・モジュールの後方互換を維持"
    ]
  },
  "portability": {
    "priority": "low",
    "criteria": [
      "Streamlit/Snowflake依存は許容（Pochiアプリの性質上、移植性は優先しない）"
    ]
  }
}
```

##### オーバーライドヒアリング（例外対応）

標準定義を適用した後、`pochi-spec-initializer` は最後に1問だけ確認する：

```
Q: このアプリで標準と異なる品質優先度にしたい項目はありますか？
   （例: 性能効率性を high にしたい、信頼性を特に強化したい）
   → なし: 標準定義をそのまま spec.json に埋め込む
   → あり: 指定された特性のみオーバーライドして spec.json に埋め込む
```

これにより、**誰がいつ開発しても同じ品質基準が適用される**ことを保証しつつ、特殊事情への対応も可能にする。

#### 1-3. CLAUDE.md への品質特性ガードレールの宣言追加

`pochi-spec-initializer` 実行後に生成される CLAUDE.md（アプリ固有）に品質特性を埋め込む。
以降のすべてのCC操作でガードレールが自動参照される：

```markdown
## 品質ガードレール（このアプリの必達要件）

### 保守性（priority: high）
- テストカバレッジ80%以上を維持すること
- 循環的複雑度10以下になるよう設計すること

### セキュリティ（priority: high）
- ユーザー入力は必ずバリデーションを行うこと
- Snowflakeクエリはパラメータバインドを使用すること

### 信頼性（priority: medium）
- Snowflake接続・LLM呼び出しには必ずエラーハンドリングを実装すること
```

---

### Phase 2：後続スキルへの品質特性の伝播（2Q）

**目的**: spec.json の `quality_requirements` を後続スキルが読んで、動作を品質特性に合わせて変える。

#### 2-1. pochi-coding-agent への組み込み

spec.json 読み込み時に quality_requirements を確認し、実装時の制約として使用：

| quality_requirements の内容 | coding-agent の動作変化 |
|---|---|
| security: high | SQLインジェクション対策・入力バリデーションを必ず実装 |
| reliability: high/medium | try-except によるエラーハンドリングを全外部呼び出しに追加 |
| maintainability: high | 関数を小さく分割、型ヒントを必ず付与 |
| performance: medium以上 | st.cache_data の使用・Snowflakeクエリのフィルタ最適化を意識 |

#### 2-2. pochi-unit-test-generator / pochi-tdd-test-generator への組み込み

quality_requirements を参照してテスト生成戦略を変える：

| 品質特性 | priority | テスト生成への影響 |
|---|---|---|
| 信頼性 | high | 異常系テスト（Snowflake接続失敗・LLMタイムアウト等）を正常系と同数以上生成 |
| セキュリティ | high | SQLインジェクション・不正入力に対するテストケースを追加 |
| 保守性 | high | カバレッジ計測とレポート出力を必ず実行 |
| 性能効率性 | medium以上 | Snowflakeクエリの実行時間アサーション（3秒以内）を追加 |

#### 2-3. github-pr-reviewer への組み込み

PRレビュー時に quality_requirements を参照し、チェックリスト形式でレビューコメントを生成：

```markdown
## 品質ガードレールチェック

### セキュリティ（priority: high） ✅/❌
- [ ] ユーザー入力のバリデーションが実装されているか
- [ ] SQLインジェクション対策（パラメータバインド）が使われているか
- [ ] 機密情報がハードコードされていないか

### 保守性（priority: high） ✅/❌
- [ ] テストカバレッジが80%以上か
- [ ] 循環的複雑度が10以下か
- [ ] 型ヒントが付与されているか

→ ❌ が1つでもあればマージ不可とする（レビュアーへの通知）
```

#### 2-4. 各スキルの SKILL.md フロントマターに quality_focus を追加

どのスキルがどの品質特性を担当しているかを明示する：

```yaml
---
name: pochi-unit-test-generator
quality_focus:
  - functional_suitability   # L1・L2テストで機能正確性を検証
  - maintainability          # テスト容易性（試験性）を向上
  - reliability              # 異常系テストを追加生成（priority: medium以上の場合）
  - security                 # 不正入力テストを追加生成（priority: high の場合）
---
```

これにより `pochi-skill-navigator` が「セキュリティのテストが必要」→ 「unit-test-generator を使って」と正しく案内できるようになる。

---

### Phase 3：品質スコアの可視化（3Q以降）

**目的**: 各アプリの品質特性スコアを定量的に算出・通知し、開発者が品質状況を常に把握できる状態を作る。MinoDriven氏の「Modifius CI」に相当するPochiネイティブな仕組み。

#### 3-1. 品質スコアの算出方法

| 品質特性 | 計測方法 | ツール |
|---|---|---|
| 保守性 | テストカバレッジ・循環的複雑度 | pytest-cov, ruff |
| 使用性 | ux-review のスコア | ux-review スキル |
| セキュリティ | OWASP項目の充足率 | github-pr-reviewer の結果集計 |
| 信頼性 | 異常系テストカバレッジ | pytest マーカー集計 |
| 性能効率性 | クエリ実行時間テストの通過率 | pytest アサーション結果 |

#### 3-2. 通知タイミング

- **PRマージ時**: 品質スコアをPRコメントに自動投稿
- **定期バッチ（週次）**: アプリ全体の品質スコアをSlackに通知
- **品質劣化検知時**: スコアが前回比で閾値を下回った場合にアラート

#### 3-3. 品質スコアのイメージ

```
【Pochi品質レポート】 2026-06-01 / app: hoge-analysis-tool

  機能適合性  ████████░░ 80%  ← テストカバレッジ
  保守性      ██████░░░░ 60%  ← 循環的複雑度・試験性
  セキュリティ ████████░░ 80%  ← OWASP項目充足率
  信頼性      ████░░░░░░ 40%  ⚠ 異常系テストが不足
  使用性      ██████░░░░ 60%  ← ux-review スコア

  → 信頼性が priority: medium に対してスコア40%。異常系テストの追加を推奨。
```

---

## 優先度と着手順序まとめ

| フェーズ | 時期 | 工数感 | 対象スキル | 効果 |
|---|---|---|---|---|
| Phase 1 | 今すぐ | 小 | pochi-spec-initializer + ~/.claude/CLAUDE.md | Pochi標準 quality_requirements を定義・適用し、全開発フローの起点が品質特性駆動になる |
| Phase 2-1 | 2Q前半 | 中 | pochi-coding-agent | 実装がガードレールを満たすコードになる |
| Phase 2-2 | 2Q前半 | 中 | unit/tdd-test-generator | 品質特性に応じたテストが自動追加される |
| Phase 2-3 | 2Q後半 | 中 | github-pr-reviewer | PRが品質ガードレールを通過しないとマージできなくなる |
| Phase 2-4 | 2Q後半 | 小 | 全37スキル | スキルナビゲーターが品質特性ベースで案内できる |
| Phase 3 | 3Q〜 | 大 | 新規スキル | 品質の可視化・継続的モニタリング |

---

## この計画が解決すること

1. **曖昧な指示からの脱却**
   「良いコードにして」ではなく、spec.json に定義された具体的な品質基準をCCが参照して動く。

2. **品質の偶発性の排除**
   ガードレールが先にあり、CCはその制約の中でしか実装・テスト生成・レビューを行えない。

3. **品質基準の組織統一**
   Pochi標準 quality_requirements を一度定義することで、開発者・タイミング・アプリを問わず常に同じ品質水準が適用される。ヒアリングが不要になるため、品質定義コストもゼロになる。

4. **品質ギャップの可視化**
   どの品質特性が未対応かがスキルのタグから一目でわかり、次に何を強化すべきかが明確になる。

5. **AI駆動開発の主従関係の正常化**
   「品質特性が主、AIが従」という正しい構造が、spec.json とガードレールの仕組みとして担保される。

6. **開発者の品質意識の向上**
   仕様定義フェーズで品質を問われることで、実装前に「何の品質を作り込むか」を意識する習慣が生まれる。
