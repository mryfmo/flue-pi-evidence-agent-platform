# pochi-spec-initializer 改修案：データ定義確認ステップの追加

作成日: 2026-05-28
更新日: 2026-05-29
対象スキル: `skills/spec/pochi-spec-initializer/skills/run/SKILL.md`
優先度: P0（即実施可能・SKILL.md追記のみ）

> **2026-05-29 更新**: 社内データナレッジスキルは
> `/home/user/docomo-data-analytics-cc-skills/.agents/skills/` 配下に8スキル（7ドメイン + use-cases）が実在。
> カラム定義・SQLパターン・コード値まで含む実用レベルの内容であり、
> SKILL.md追記のみで即効性のある改善が可能であることを確認した。

---

## 背景

現在の`pochi-spec-initializer`は機能要件・受入基準・quality_requirementsを生成するが、
`data_contracts`を書く前にSnowflakeビューの実カラム定義を確認するステップが存在しない。

この欠如により、仕様書と実データの乖離（型・NULL制約・コード値のずれ）がテスト生成・実装フェーズまで発見されず、手戻りコストが発生している。

---

## 改修内容

### 追加するフェーズ：「データ定義確認フェーズ」

現在のヒアリングフェーズと仕様凍結（spec.json生成）の間に挿入する。

```
フェーズ1：要件収集・ヒアリング（現状通り）
    ↓
【新】フェーズ1.5：データ定義確認
    ├─ Alation metaでカラム定義を確認（原因C対策）
    └─ 社内ナレッジスキルでビジネスルールを確認（原因B対策）
    ↓
フェーズ2：仕様凍結・spec.json生成（現状通り）
```

---

## SKILL.mdへの追記内容（案）

`pochi-spec-initializer/skills/run/SKILL.md`の仕様策定フェーズ説明部分に以下を追記する。

---

### 追記箇所：ヒアリング完了後・spec.json生成前

```markdown
### データ定義確認フェーズ（必須）

ヒアリングで機能要件が固まった後、`spec.json`の`data_contracts`と`business_rules`を
記載する**前に**以下を実施すること。

#### A. Snowflakeビューのカラム定義確認（Alation meta参照）

アプリが参照するSnowflakeビューを特定し、実際のカラム定義を確認する。

**ビュー特定の方法（優先順位順）**:

| 優先度 | 方法 | 適用条件 |
|---|---|---|
| 1 | アプリコード静的解析 | `app/*.py`等が存在する場合 |
| 2 | ユーザーへの確認 | 「どのビューを使いますか？」と質問 |
| 3 | 既存docs/db-context.md | 過去ヒアリングで生成済みの場合 |

**カラム定義の取得コマンド**:

```bash
uv run /home/user/pochi-dp-developer-docs/plan/ALADIN-DWH/altion-meta-import/alation_meta_cli.py \
  join --view <ビュー名>
```

取得した情報から以下を`data_contracts`に反映する：
- 物理カラム名 → `name`フィールド
- データ型（STRING/INTEGER/FLOAT/DATE等）→ `type`フィールド
- NULL可否 → `nullable`フィールド
- コード値定義（CODE_VALUE列）→ `description`または`enum`フィールド
- 日本語論理名（COLUMN_LOGICAL_NAME列）→ `description`フィールド

**db-context.mdの生成**:

取得したカラム情報を`docs/features/{FEATURE-ID}/db-context.md`として保存する。
pochi-coding-agentが実装時にカラム定義を参照できるようにするため。

```markdown
# db-context.md テンプレート

## 参照ビュー: {ビュー名}

| カラム名（物理） | 論理名 | 型 | NULL可否 | 説明・コード値 |
|---|---|---|---|---|
| ACCTID | 契約ID | STRING | NOT NULL | 顧客の一意識別子 |
| SALES_AMT | 売上金額 | FLOAT | NULLABLE | 単位：円 |
...

抽出日: {YYYY-MM-DD}
ソース: VW_ALATION_COLUMN_INFO
```

#### B. ビジネスルールのナレッジ確認（社内データナレッジスキル参照）

`business_rules`を書く前に、分析対象ドメインの業務定義をナレッジスキルで確認する。

**スキルの場所**: `/home/user/docomo-data-analytics-cc-skills/.agents/skills/`

**まず `use-cases` でナビゲーション（任意・効率化）**:

`use-cases/INDEX.md` にキーワード→ユースケース→使用スキルのマッピングが39件分整備されている。
分析の概要が決まっている場合はここから始めると該当ドメインスキルを素早く特定できる。

**ドメイン別スキルの選択**:

| 分析ドメイン | 参照スキル | 主なリファレンスファイル |
|---|---|---|
| 顧客キー体系・ID変換・DWH層構造 | `docomo-data-foundation` | `references/customer_key_overview.md`（キー選択）、`references/customer_id_conversion.md`（変換SQL）、`references/naming_conventions.md`（命名規約） |
| dポイント会員プロファイル・デモグラ | `docomo-data-customer-profile` | `references/customer_profile.md`（概要・View選択）→日次/月次に応じてカラム定義書 |
| 契約・料金プラン・サービス・請求 | `docomo-data-contract-service` | `references/INDEX.md`で領域特定→該当md。SQL実装時は`references/sql_patterns/`参照 |
| 決済・ARPU | `docomo-data-settlement` | `references/settlement_integration_view.md`（統合ビュー構造）→`settlement_business_rules.md`（SQL前に必須）→`settlement_sql_patterns.md` |
| ドコモショップ・端末販売 | `docomo-data-shop-device` | `references/INDEX.md`でチャネル（実店舗/商品販売/オンライン）判定→該当md |
| メルマガ・Push配信・キャンペーン | `docomo-data-marketing` | `references/mail_marketing_basics.md`（許諾・基本概念）から段階的に参照 |
| NW品質・VOC・AI | `docomo-data-nw-voc-ai` | `references/nw_analysis_scenarios.md`（シナリオA〜E判定）→`nw_log_sql_filters.md`（代表SQL） |

> **注意**: `docomo-data-knowledge`は廃止済みスキル。上記7スキルを使うこと。
> X（旧Twitter）の声データは契約上の制約により使用禁止（`docomo-data-nw-voc-ai`）。

**各スキルでのリファレンス参照手順**:

1. 対象スキルの`SKILL.md`を読み、「リファレンスガイド」テーブルで必要なリファレンスを特定
2. 該当リファレンスファイル（`references/*.md`）のみを読み込む（全件読み禁止・コンテキスト節約）
3. 質問に関連するセクションの要点だけを抽出する

**確認すべき内容**:
- コード値の定義（料金プランコード、サービスコード、`gender_code`・`nendai_code`等の実コード体系）
- 集計軸の定義（月初・月末・期間の区切り方）
- 顧客キーの選択ルール（ACCTID vs COMNID vs BASCID と事業区分コード）
- ビュー名の命名規則・推奨ビュー（`docomo-data-foundation`の`naming_conventions.md`参照）
- カラム型情報（ナレッジスキルがカラム定義まで含む場合はAlation参照と統合する）

確認した内容はそのまま`business_rules`の各ルールに反映する。

#### データ定義確認のチェックリスト

spec.json生成前に以下を全て確認する：

```
□ 使用するSnowflakeビュー名を特定できた
□ alation_meta_cli.py で対象ビューのカラム定義を取得した
□ 取得したカラム名・型・NULL可否がdata_contractsに反映されている
□ コード値定義（コード体系）をdescriptionまたはenumに記載した
□ db-context.md をdocs/features/{FEATURE-ID}/に保存した
□ 分析ドメインに対応するナレッジスキルを参照した
□ 集計軸・期間定義・顧客キー選択ルールをbusiness_rulesに明示した
```
```

---

## 期待効果

### Before（現状）

```
spec.json生成（data_contractsは開発者の記憶・推測で記載）
    ↓
テスト生成
    → 「float想定なのにSnowflakeはSTRINGで返ってくる」と発覚
    → spec.json修正 → テスト再生成（手戻り）
```

### After（改修後）

```
Alation metaでカラム定義確認 → 型・NULL可否を確認してからdata_contracts記載
    ↓
spec.json生成（実データと一致したdata_contracts）
    ↓
テスト生成
    → Layer1テストが実際のビュー仕様に基づいて生成される
    → 型不整合は実装時に即検出
```

---

## 実装コスト見積もり

| 変更内容 | 工数 | 備考 |
|---|---|---|
| SKILL.mdへの追記（Step 1・2） | 小（半日以内） | なし（プロンプト追加のみ）。**今すぐ実施可能** |
| alation_meta_cli.pyの呼び出し組み込み（Step 3） | 中（1〜2日） | CLIパスのハードコードが必要 |
| db-context.md自動生成（Step 3） | 中（1〜2日） | docs/構造整備が前提 |
| チェックリスト組み込み（Step 4） | 小 | Step 1・2完了後に実施 |

**Step 1・2**（SKILL.mdへの追記のみ）は即実施可能であり、最小コストで最大の効果を得られる。

### 効果の再評価（2026-05-28）

社内データナレッジスキル（`/home/user/docomo-data-analytics-cc-skills/.agents/skills/`）が
カラム定義・コード値・SQLパターンを含む実用レベルで整備済みであることを確認。
当初「前提スキルが未整備」と懸念していたが、**Step 2も即実施可能**である。

- `docomo-data-settlement` の `settlement_integration.md` は `comnid: String(12)`・`pay_money_amount_total: Numeric` 等の実カラム定義を含む
- `docomo-data-foundation` の `customer_key_overview.md` は ACCTID/COMNID/BASCID の選択基準を事業区分コード込みで整理済み
- これらはspec.jsonの`data_contracts`・`business_rules`の精度を直接改善できる

---

## 関連ファイル

- 改修対象: `skills/spec/pochi-spec-initializer/skills/run/SKILL.md`
- CLI ツール: `plan/ALADIN-DWH/altion-meta-import/alation_meta_cli.py`
- 上位戦略: `plan/data-definition-quality/戦略概要.md`
- EaC統合先: `plan/new-dev/Pochi-AI駆動開発プロセス統合計画書.md`（施策2・AI-072対応）
