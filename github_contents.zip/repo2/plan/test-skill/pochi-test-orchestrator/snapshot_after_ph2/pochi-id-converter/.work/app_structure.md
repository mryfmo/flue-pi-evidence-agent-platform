# アプリケーション構造分析レポート

**分析日時**: 2026-05-08T00:31:52.323470  
**対象ディレクトリ**: `/home/user/pochi-id-converter-repository`

---

## 📊 統計情報

- **総ファイル数**: 23
- **画面数**: 5
- **libファイル数**: 17
- **推定テストケース数（最小）**: 55件
- **推定テストケース数（推奨）**: 75件
- **推定テストケース数（最大）**: 95件

---

## 📁 ファイル構造

### app/ 直下
- `app/main.py`


### app_pages/ 配下
- `app/app_pages/01_IDを変換する.py`
- `app/app_pages/02_使い方がわからないときは.py`
- `app/app_pages/03_このアプリについて.py`
- `app/app_pages/04_データソースについて.py`
- `app/app_pages/routing.py`


### lib/ 配下
- `app/lib/definition.py`
- `app/lib/dogharness.py`
- `app/lib/information.py`
- `app/lib/old_query_collect.py`
- `app/lib/queries/get_statement.py`
- `app/lib/queries/sa_models/base.py`
- `app/lib/queries/sa_models/temporary_table.py`
- `app/lib/queries/sa_models/vw_adm_dncl_comnid_integration.py`
- `app/lib/queries/sa_models/vw_dmc_dncl_line_friend_list.py`
- `app/lib/queries/sa_models/vw_dmc_dncl_line_user_id_coordination_datas.py`
- `app/lib/utility/__init__.py`
- `app/lib/utility/_error_message.py`
- `app/lib/utility/_get_pstorage.py`
- `app/lib/utility/_set_page_config.py`
- `app/lib/utility/_utils.py`
- `app/lib/view_input_data.py`
- `app/lib/view_output_data.py`


### data関連フォルダ
- （なし）


### function関連フォルダ
- （なし）


---

## 🖥️ 画面一覧

| 画面ファイル | パス | 関数数 | クラス数 |
|-------------|------|--------|---------|
| `01_IDを変換する.py` | `app/app_pages/01_IDを変換する.py` | 1 | 0 |
| `02_使い方がわからないときは.py` | `app/app_pages/02_使い方がわからないときは.py` | 1 | 0 |
| `03_このアプリについて.py` | `app/app_pages/03_このアプリについて.py` | 2 | 0 |
| `04_データソースについて.py` | `app/app_pages/04_データソースについて.py` | 4 | 0 |
| `routing.py` | `app/app_pages/routing.py` | 1 | 0 |


---

## 🔧 主要機能

抽出された関数・クラス数: **38個**

### 関数・クラス一覧（上位50件）
- クラス: `input_datas` (`app/lib/definition.py`)
- 関数: `add_header` (`app/lib/view_input_data.py`)
- 関数: `init_convert` (`app/lib/view_input_data.py`)
- 関数: `view_id_input_widgets` (`app/lib/view_input_data.py`)
- 関数: `view_input_data` (`app/lib/view_input_data.py`)
- 関数: `view_dog_harness` (`app/lib/dogharness.py`)
- 関数: `init_convert` (`app/lib/view_output_data.py`)
- 関数: `get_streamlit_session_id` (`app/lib/view_output_data.py`)
- 関数: `load_input_dict` (`app/lib/view_output_data.py`)
- 関数: `make_input_df` (`app/lib/view_output_data.py`)
- 関数: `left_merge_df` (`app/lib/view_output_data.py`)
- 関数: `view_output_data` (`app/lib/view_output_data.py`)
- 関数: `view_home_information` (`app/lib/information.py`)
- 関数: `view_id_converter_information` (`app/lib/information.py`)
- 関数: `execute_orm_query` (`app/lib/queries/get_statement.py`)
- 関数: `convert_to_acctid` (`app/lib/queries/get_statement.py`)
- 関数: `convert_from_acctid` (`app/lib/queries/get_statement.py`)
- 関数: `merge_results` (`app/lib/queries/get_statement.py`)
- クラス: `UploadTargetList` (`app/lib/queries/sa_models/temporary_table.py`)
- クラス: `ComnidIntegration` (`app/lib/queries/sa_models/vw_adm_dncl_comnid_integration.py`)
- クラス: `LineFriendList` (`app/lib/queries/sa_models/vw_dmc_dncl_line_friend_list.py`)
- クラス: `LineUserIdCoordinattionData` (`app/lib/queries/sa_models/vw_dmc_dncl_line_user_id_coordination_datas.py`)
- クラス: `Base` (`app/lib/queries/sa_models/base.py`)
- クラス: `ErrorMessage` (`app/lib/utility/_error_message.py`)
- 関数: `memory_error` (`app/lib/utility/_error_message.py`)
- 関数: `unexpected_error` (`app/lib/utility/_error_message.py`)
- 関数: `file_lock_error` (`app/lib/utility/_error_message.py`)
- 関数: `decode_error` (`app/lib/utility/_error_message.py`)
- 関数: `acctid_input_error` (`app/lib/utility/_error_message.py`)
- 関数: `comnid_input_error` (`app/lib/utility/_error_message.py`)
- 関数: `bascid_input_error` (`app/lib/utility/_error_message.py`)
- 関数: `set_page_config` (`app/lib/utility/_set_page_config.py`)
- 関数: `get_pstorage` (`app/lib/utility/_get_pstorage.py`)
- 関数: `get_pstorage_user` (`app/lib/utility/_get_pstorage.py`)
- クラス: `ValidationError` (`app/lib/utility/_utils.py`)
- 関数: `check_input_data` (`app/lib/utility/_utils.py`)
- 関数: `df_to_xlsx` (`app/lib/utility/_utils.py`)
- 関数: `check_input_file` (`app/lib/utility/_utils.py`)


---

## 💾 データソース

### Snowflake
- `app/app_pages/01_IDを変換する.py`
- `app/lib/old_query_collect.py`
- `app/lib/queries/get_statement.py`


### GCS
- `app/app_pages/01_IDを変換する.py`
- `app/lib/view_input_data.py`
- `app/lib/view_output_data.py`


### BigQuery
- （なし）


### LLM API
- （なし）


---

## 🎨 UI要素

### 01_IDを変換する.py

- UI要素タイプ: `st.dataframe`, `st.title`

### 02_使い方がわからないときは.py

- UI要素タイプ: `st.button`, `st.header`, `st.title`

### 03_このアプリについて.py

- UI要素タイプ: `st.subheader`, `st.title`

### 04_データソースについて.py

- UI要素タイプ: `st.subheader`, `st.title`


---

## 📌 定数・固定値

### `app/app_pages/03_このアプリについて.py`

- **PAGE_TITLE** = "📜このアプリについて" (行14)
- **SEC_TITLE** = "想定ユースケース" (行15)

### `app/app_pages/04_データソースについて.py`

- **PAGE_TITLE** = "📁データソースについて" (行14)
- **SEC_1_TITLE** = "1. データソース" (行15)
- **SEC_2_TITLE** = "2. 試験項目" (行16)
- **SEC_3_TITLE** = "3. クエリ実行時の消費クレジット目安" (行17)


---

## 🎨 UI要素詳細

### 02_使い方がわからないときは.py

#### ボタン (4個)

1. **使い方を動画で確認する** (行60)
2. **使い方を動画で確認する** (行85)
3. **閉じる** (行63)
4. **閉じる** (行88)


---

## ✅ バリデーションルール

### `app/lib/view_output_data.py`

1. **バリデーション** (行69)
   - 条件: `gcs_path != ''`
   - メッセージ: "基本契約番号へ変換する場合はチェックボックスを最低1つ選択してください。"

2. **バリデーション** (行73)
   - 条件: `check_input_data(select_source, select_df)`
   - メッセージ: "基本契約番号へ変換する場合はチェックボックスを最低1つ選択してください。"

3. **バリデーション** (行154)
   - 条件: `st.session_state['convert']`
   - メッセージ: "基本契約番号へ変換する場合はチェックボックスを最低1つ選択してください。"

4. **バリデーション** (行164)
   - 条件: `convert_flg`
   - メッセージ: "基本契約番号へ変換する場合はチェックボックスを最低1つ選択してください。"


---

## 📝 Clineへの指示

このレポートを参照して、以下の調査を実施してください：

### 必須調査項目
- [ ] すべての画面ファイル（5個）の詳細確認
- [ ] 主要な関数・クラス（上位50個）の詳細確認
- [ ] データソース連携部分の詳細確認
- [ ] UI要素の実際の表示テキスト確認

### 調査完了基準
- [ ] 調査ファイル数：20個以上
- [ ] 特定した主要機能：50個以上
- [ ] 全画面（5画面）の機能を把握
- [ ] データフローを理解

### 期待されるテストケース数
- **最小**: 55件
- **推奨**: 75件
- **最大**: 95件

**重要**: テストケース生成時は、**推奨値**（75件）を目標としてください。
- 初回作成時: 推奨値 ± 10%（67～82件）
- 機能追加時: 推奨値の20～40%（15～30件）
- バグ修正時: 推奨値の10～20%（7～15件）
