# アプリケーション構造分析レポート

**分析日時**: 2026-05-07T01:19:50.527838  
**対象ディレクトリ**: `/home/user/pochi-d-pay-merchant-visualizer-repository/app`

---

## 📊 統計情報

- **総ファイル数**: 63
- **画面数**: 5
- **libファイル数**: 46
- **推定テストケース数（最小）**: 55件
- **推定テストケース数（推奨）**: 75件
- **推定テストケース数（最大）**: 95件

---

## 📁 ファイル構造

### app/ 直下
- `_初期表示.py`
- `main.py`


### app_pages/ 配下
- `app_pages/about_this_app.py`
- `app_pages/app_designer.py`
- `app_pages/data_sources.py`
- `app_pages/how_to_use.py`
- `app_pages/visualization_tool.py`


### lib/ 配下
- `lib/address.py`
- `lib/app_designer/__init__.py`
- `lib/app_designer/export_handler.py`
- `lib/app_designer/session_state.py`
- `lib/app_designer/solution_engine.py`
- `lib/app_designer_catalogs/__init__.py`
- `lib/app_designer_catalogs/catalogs/loader.py`
- `lib/const.py`
- `lib/data_loader/__init__.py`
- `lib/data_loader/_address.py`
- `lib/data_loader/_base.py`
- `lib/data_loader/_graph_data.py`
- `lib/data_loader/_map_data.py`
- `lib/data_loader/_merchant_store.py`
- `lib/data_loader/_settlement_integration_jenre.py`
- `lib/data_loader/_store_information_management.py`
- `lib/data_loader/_user_list_data.py`
- `lib/data_loader/const.py`
- `lib/data_loader/data_models/__init__.py`
- `lib/data_loader/data_models/merchant_key.py`
- `lib/data_loader/intermediate_data_builder/merchant_keys.py`
- `lib/data_loader/intermediate_data_builder/settlement.py`
- `lib/data_loader/sa_models/__init__.py`
- `lib/data_loader/sa_models/base.py`
- `lib/data_loader/sa_models/pj_ml_geocoding_address_mst.py`
- `lib/data_loader/sa_models/pj_ml_geocoding_dbarai_mst.py`
- `lib/data_loader/sa_models/vw_adw_dncl_store_information_management_master.py`
- `lib/data_loader/sa_models/vw_dic_dnhd_settlement_integration.py`
- `lib/data_loader/sa_models/vw_hmd_mjcd_integration_genre_master.py`
- `lib/data_loader/utils/fuzzy_search.py`
- `lib/folium_utils.py`
- `lib/generate_analysis_result_data.py`
- `lib/generate_user_list.py`
- `lib/graph_visualizer.py`
- `lib/merchant_keyword_search.py`
- `lib/merchant_map.py`
- `lib/models.py`
- `lib/patch/__init__.py`
- `lib/patch/_execute_patch.py`
- `lib/patch/_streamlit_antd_components/__init__.py`
- `lib/patch/_streamlit_antd_components/component_func.py`
- `lib/profiling_util.py`
- `lib/session_manager/__init__.py`
- `lib/session_manager/snowflake_sqlalchemy.py`
- `lib/store_search.py`
- `lib/utils.py`


### data関連フォルダ
- `lib/data_loader/const.py`
- `lib/data_loader/_store_information_management.py`
- `lib/data_loader/_graph_data.py`
- `lib/data_loader/_map_data.py`
- `lib/data_loader/_address.py`
- `lib/data_loader/_user_list_data.py`
- `lib/data_loader/_settlement_integration_jenre.py`
- `lib/data_loader/_merchant_store.py`
- `lib/data_loader/__init__.py`
- `lib/data_loader/_base.py`
- `lib/data_loader/data_models/merchant_key.py`
- `lib/data_loader/data_models/__init__.py`
- `lib/data_loader/intermediate_data_builder/settlement.py`
- `lib/data_loader/intermediate_data_builder/merchant_keys.py`


### function関連フォルダ
- `reporting_function/_reporting_page.py`
- `reporting_function/_check.py`
- `reporting_function/_address_input_form.py`
- `reporting_function/_query_params.py`
- `reporting_function/__init__.py`
- `reporting_function/_utils.py`


---

## 🖥️ 画面一覧

| 画面ファイル | パス | 関数数 | クラス数 |
|-------------|------|--------|---------|
| `about_this_app.py` | `app_pages/about_this_app.py` | 4 | 0 |
| `app_designer.py` | `app_pages/app_designer.py` | 5 | 0 |
| `data_sources.py` | `app_pages/data_sources.py` | 7 | 0 |
| `how_to_use.py` | `app_pages/how_to_use.py` | 3 | 0 |
| `visualization_tool.py` | `app_pages/visualization_tool.py` | 18 | 2 |


---

## 🔧 主要機能

抽出された関数・クラス数: **114個**

### 関数・クラス一覧（上位50件）
- 関数: `get_usage_dates` (`lib/utils.py`)
- 関数: `json_serial` (`lib/utils.py`)
- 関数: `to_json` (`lib/utils.py`)
- 関数: `get_streamlit_session_id` (`lib/utils.py`)
- クラス: `stProfiler` (`lib/profiling_util.py`)
- クラス: `FasterMarkerCluster` (`lib/folium_utils.py`)
- クラス: `FastCircleMarker` (`lib/folium_utils.py`)
- クラス: `BindColormap` (`lib/folium_utils.py`)
- 関数: `get_east_asian_width_count` (`lib/generate_analysis_result_data.py`)
- 関数: `show_xlsx_file_download_link` (`lib/generate_analysis_result_data.py`)
- 関数: `show_csv_zip_file_download_link` (`lib/generate_analysis_result_data.py`)
- 関数: `show_dialog_download_analysis_data` (`lib/generate_analysis_result_data.py`)
- 関数: `components_download_analysis_data` (`lib/generate_analysis_result_data.py`)
- 関数: `remove_none_and_list_keys` (`lib/address.py`)
- 関数: `get_regions_and_prefectures` (`lib/address.py`)
- 関数: `get_prefectures` (`lib/address.py`)
- 関数: `get_pref_code` (`lib/address.py`)
- 関数: `get_address_master_with_name` (`lib/address.py`)
- 関数: `get_address_master_with_code` (`lib/address.py`)
- 関数: `get_concat_address` (`lib/address.py`)
- 関数: `components_address_input` (`lib/address.py`)
- クラス: `InputConditions` (`lib/models.py`)
- クラス: `RenderOptions` (`lib/models.py`)
- 関数: `check` (`lib/models.py`)
- 関数: `hash_md5` (`lib/models.py`)
- クラス: `EmptyClass` (`lib/merchant_map.py`)
- 関数: `get_unique_payment_method_list` (`lib/merchant_map.py`)
- 関数: `get_marker_cluster_obj` (`lib/merchant_map.py`)
- 関数: `get_merchant_map_figure` (`lib/merchant_map.py`)
- 関数: `get_map_hidden_merchant_df` (`lib/merchant_map.py`)
- 関数: `components_draw_merchant_map` (`lib/merchant_map.py`)
- 関数: `components_store_search` (`lib/store_search.py`)
- 関数: `create_map` (`lib/merchant_keyword_search.py`)
- 関数: `components_merchant_keyword_search` (`lib/merchant_keyword_search.py`)
- 関数: `components_draw_statistics` (`lib/graph_visualizer.py`)
- 関数: `components_draw_merchant_data_graph_without_statistics` (`lib/graph_visualizer.py`)
- 関数: `components_draw_merchant_data_graph` (`lib/graph_visualizer.py`)
- 関数: `calc_change` (`lib/graph_visualizer.py`)
- 関数: `calc_change_rate` (`lib/graph_visualizer.py`)
- 関数: `style_change_row` (`lib/graph_visualizer.py`)
- 関数: `get_style_for_value` (`lib/graph_visualizer.py`)
- 関数: `highlight_change_row` (`lib/graph_visualizer.py`)
- 関数: `show_user_list_download_link` (`lib/generate_user_list.py`)
- 関数: `show_dialog_user_acctid_list` (`lib/generate_user_list.py`)
- 関数: `components_download_user_acctid_list` (`lib/generate_user_list.py`)
- 関数: `execute_patch` (`lib/patch/_execute_patch.py`)
- 関数: `execute_monkey_patch` (`lib/patch/_streamlit_antd_components/__init__.py`)
- 関数: `convert_session_value` (`lib/patch/_streamlit_antd_components/component_func.py`)
- 関数: `component` (`lib/patch/_streamlit_antd_components/component_func.py`)
- クラス: `CatalogLoader` (`lib/app_designer_catalogs/catalogs/loader.py`)

...他64件（詳細はソースコードを参照）


---

## 💾 データソース

### Snowflake
- `app_pages/app_designer.py`
- `app_pages/visualization_tool.py`
- `lib/data_loader/_address.py`
- `lib/data_loader/_graph_data.py`
- `lib/data_loader/_map_data.py`
- `lib/data_loader/_merchant_store.py`
- `lib/data_loader/_settlement_integration_jenre.py`
- `lib/data_loader/_store_information_management.py`
- `lib/data_loader/_user_list_data.py`
- `lib/data_loader/intermediate_data_builder/merchant_keys.py`
- `lib/session_manager/__init__.py`
- `lib/session_manager/snowflake_sqlalchemy.py`
- `reporting_function/_address_input_form.py`
- `reporting_function/_reporting_page.py`


### GCS
- `lib/const.py`
- `lib/generate_analysis_result_data.py`
- `lib/generate_user_list.py`


### BigQuery
- （なし）


### LLM API
- （なし）


---

## 🎨 UI要素

### about_this_app.py

- UI要素タイプ: `st.subheader`, `st.title`

### app_designer.py

- UI要素タイプ: `st.button`, `st.checkbox`, `st.metric`, `st.multiselect`, `st.radio`, `st.selectbox`, `st.subheader`, `st.table`, `st.tabs`, `st.text_area`, `st.title`

### data_sources.py

- UI要素タイプ: `st.subheader`, `st.title`

### how_to_use.py

- UI要素タイプ: `st.subheader`, `st.title`

### visualization_tool.py

- UI要素タイプ: `st.checkbox`, `st.header`, `st.title`


---

## 📌 定数・固定値

### `app_pages/about_this_app.py`

- **PAGE_TITLE** = "📜このアプリについて" (行10)
- **SEC_1_TITLE** = "1. 想定ユースケース" (行11)
- **SEC_2_TITLE** = "2. 業務適用実績のあるユースケース" (行12)
- **SEC_3_TITLE** = "3. 注意事項" (行13)

### `app_pages/app_designer.py`

- **PAGE_TITLE** = "🎨 App Designer" (行17)

### `app_pages/data_sources.py`

- **PAGE_TITLE** = "📜データソースについて" (行10)
- **SEC_1_TITLE** = "1. データソース" (行11)
- **SEC_2_TITLE** = "2. 処理ロジック" (行12)
- **SEC_3_TITLE** = "2. 試験項目" (行13)
- **SEC_4_TITLE** = "3. クエリ実行時の消費クレジット目安" (行14)

### `lib/const.py`

- **APP_NAME** = "d-pay-merchant-visualizer" (行3)
- **APP_NAME_JA** = "d払い決済状況見える化ツール" (行4)
- **APP_FAVICON** = ":dog2:" (行5)
- **MAX_SELECTED_CITY_COUNT** = 15 (行7)
- **MAX_STORE_SEARCH_COUNT** = 15 (行9)
- **MAP_DEFAULT_MAX_ROWS** = 5000 (行11)
- **MAP_MOREOVER_MAX_ROWS** = 50000 (行13)
- **DOWNLOAD_EXCEL_FILE_MERCHANT_LIMIT** = 50000 (行15)
- **KEYWORD_SEARCH_LIMIT** = 50000 (行17)
- **MAX_USER_LIST_SIZE** = 1000000 (行19)
- **GENDER_CODE_MAP** = {None: '選択しない', '1': '男性', '2': '女性'} (行21)
- **NENDAI_CODE_MAP** = {'00': '10代未満', '01': '10代', '02': '20代', '03': '30代', '04': '40代', '05': '50代', '06': '60代', '07': ... (行28)
- **PAYMENT_METHOD_LIST** = ['Cloud Pay(MPM)', 'JPQR(MPM)', 'MQPay(MPM)', 'TakeMe Pay(MPM)', 'メルペイ(MPM)', 'かながわPay(MPM)', 'AirPA... (行41)
- **PAYMENT_METHOD_LIST_SM** = ['Cloud Pay(MPM)', 'JPQR(MPM)', 'MQPay(MPM)', 'TakeMe Pay(MPM)', 'メルペイ(MPM)', 'かながわPay(MPM)', 'AirPA... (行53)
- **USER_DOWNLOAD_GCS_DIR** = "download_file_store" (行63)

### `lib/generate_analysis_result_data.py`

- **__MERCHANT_DF_JA_MAPPER** = {'company': '企業', 'store': '店舗', 'settlement_integration_genre_large_classification': '業態_大分類', 'set... (行33)
- **__FORMAT** = "zip" (行404)

### `lib/merchant_map.py`

- **COL_MAP** = {'company': '企業名', 'store': '店舗名', '決済方式': '決済方式', '決済合計金額': '決済合計金額', '決済回数': '決済回数', 'ユニークユーザー数': ... (行318)

### `lib/patch/__init__.py`

- **_RELEASE** = True (行4)

### `lib/session_manager/snowflake_sqlalchemy.py`

- **__KEYS_DICT** = {'X-Small': 'snowflake_sqlalchemy_session_xs', 'Medium': 'snowflake_sqlalchemy_session_medium', 'Lar... (行14)

### `lib/data_loader/const.py`

- **INSERT_BATCH_SIZE** = 100000 (行2)

### `reporting_function/_reporting_page.py`

- **JA_MAPPER** = {'site_id_cpid': 'サイトID・CPID', 'company_code': '企業コード', 'store_code': '店舗コード', 'company': '企業名', 'st... (行395)

### `reporting_function/_address_input_form.py`

- **__KEY_PREFIX** = "addr_input" (行15)


---

## 🎨 UI要素詳細

### app_designer.py

#### テキストエリア (2個)

1. **具体的にどんな場面で困っていますか？** (行144)
2. **どうなったら嬉しいですか？** (行379)

#### ボタン (4個)

1. **💡 解決策を提案してもらう** (行431)
2. **🔄 最初からやり直す** (行36)
3. **（ラベルなし）** (行192)
4. **この解決策を選ぶ** (行474)

#### ラジオボタン (1個)

1. **最優先の困りごと** (行160)

#### チェックボックス (3個)

1. **（ラベルなし）** (行129)
2. **（ラベルなし）** (行335)
3. **（ラベルなし）** (行366)

#### マルチセレクト (2個)

1. **当てはまるものを選択** (行216)
2. **当てはまるものを選択** (行258)

#### セレクトボックス (4個)

1. **この業務はどれくらいの頻度で行いますか？** (行226)
   - 選択肢: ['毎日', '週に数回', '週1回', '月1回', '不定期']
2. **何人くらいが使うことを想定していますか？** (行241)
   - 選択肢: ['1人（自分だけ）', '2-5人', '6-10人', '11人以上']
3. **1回の作業にどれくらい時間がかかりますか？** (行268)
   - 選択肢: ['10分未満', '10-30分', '30分-1時間', '1-3時間', '3時間以上']
4. **使う人のITスキルレベルは？** (行285)
   - 選択肢: ['beginner', 'intermediate', 'advanced']

### visualization_tool.py

#### チェックボックス (6個)

1. **全て選択** (行80)
2. **全て選択** (行137)
3. **全て選択** (行420)
4. **（ラベルなし）** (行107)
5. **（ラベルなし）** (行165)
6. **（ラベルなし）** (行448)

#### 数値入力 (1個)

1. **検索範囲（半径）km** (行194)
   - 範囲: 0.1～50.0, デフォルト: 未指定


---

## ✅ バリデーションルール

### `app_pages/visualization_tool.py`

1. **バリデーション** (行972)
   - 条件: `conditions is None or not conditions.check or render_options is None`
   - メッセージ: "
            予期せぬエラーが発生しました。ページをリロードして再度実行してください。  
            エラーが継続して発生する場合には、お問い合わせください。
            "

2. **バリデーション** (行275)
   - 条件: `not (122.0 <= current_lng <= 154.0 and 20.0 <= current_lat <= 46.0)`
   - メッセージ: "選択された地点が日本国内の範囲外です。日本国内の地点を選択してください。"

3. **バリデーション** (行311)
   - 条件: `address not in ('住所の取得に失敗しました。', False)`
   - メッセージ: "選択された地点が日本国内の範囲外です。日本国内の地点を選択してください。"

4. **バリデーション** (行313)
   - 条件: `first_part != '日本'`
   - メッセージ: "選択された地点が日本国内の範囲外です。日本国内の地点を選択してください。"

5. **バリデーション** (行323)
   - 条件: `address is False`
   - メッセージ: "住所の取得に失敗しました。選択された地点が日本国内の範囲外か、住所情報が存在しない可能性があります。"

6. **バリデーション** (行1019)
   - 条件: `e.errno == 630 or re.search(timeout_pattern, str(e))`
   - メッセージ: "処理がタイムアウトしました。混雑している可能性がありますので、時間をおいて再度お試しください。"

### `app_pages/app_designer.py`

1. **バリデーション** (行392)
   - 条件: `not session.is_ready_for_solution()`
   - メッセージ: "⚠️ 解決策を提案するには、STEP1-3で最低限の情報を入力してください。"

### `lib/generate_analysis_result_data.py`

1. **バリデーション** (行523)
   - 条件: `include_no_payment_merchants`
   - メッセージ: "
            **指定された期間内で決済が発生していない加盟店**を「加盟店一覧シート」に含めます。  
            情報はｄ払い(街)加盟店マスタに登録されている情報であり、あくまで**参考データ**としてご活用ください。
        "

2. **バリデーション** (行286)
   - 条件: `bytesio_excel is None`
   - メッセージ: "ダウンロード可能なデータはありません"

3. **バリデーション** (行434)
   - 条件: `bytesio_zip is None`
   - メッセージ: "ダウンロード可能なデータはありません"

### `lib/merchant_map.py`

1. **バリデーション** (行493)
   - 条件: `hidden_merchant_df is not None`
   - メッセージ: "加盟店の情報を修正する場合には、「修正URL」列にあるリンクを3回クリックしてください。"

2. **バリデーション** (行399)
   - 条件: `show_stores_without_payment`
   - メッセージ: "指定された期間に決済がない店舗は、地図上のピンの色が赤色で表示されます。表示される店舗は、加盟店マスタに登録されている店舗となります。"

3. **バリデーション** (行413)
   - 条件: `ignore_upper_limit_draw_map_pin`
   - メッセージ: "マップに描画される加盟店数が多い場合、マップの描画に時間がかかる可能性があります。"

4. **バリデーション** (行452)
   - 条件: `len(selected_payment_method) == 0`
   - メッセージ: "決済方式が1つも選択されていない場合には、フィルターは無効となります"

### `lib/store_search.py`

1. **バリデーション** (行71)
   - 条件: `stores_df.empty`
   - メッセージ: "該当する店舗が見つかりませんでした。"

2. **バリデーション** (行118)
   - 条件: `latitude is None or longitude is None`
   - メッセージ: "選択された店舗の位置情報が正しく取得できませんでした。"

### `lib/merchant_keyword_search.py`

1. **バリデーション** (行168)
   - 条件: `show_method == 'リスト形式で表示する'`
   - メッセージ: "マップに表示できるデータがありませんでした。「リスト形式で表示する」をご利用ください。"

2. **バリデーション** (行195)
   - 条件: `m_html is None`
   - メッセージ: "マップに表示できるデータがありませんでした。「リスト形式で表示する」をご利用ください。"

### `reporting_function/_reporting_page.py`

1. **バリデーション** (行86)
   - 条件: `origin_df.empty`
   - メッセージ: "
            該当する加盟店が見つかりませんでした。URLに誤りがある可能性があります。  
            一度ページを閉じ、地図上の「情報を修正する」をクリックしてください。  
        "

2. **バリデーション** (行94)
   - 条件: `len(origin_df) > 1`
   - メッセージ: "
            同一名、同一地点の加盟店が複数存在します。  
            そのまま次へ進むと、すべての加盟店の情報が一括して修正されます。必要に応じて「この地点を修正する」チェックを外してください。
            "

3. **バリデーション** (行142)
   - 条件: `len(origin_df) > 1`
   - メッセージ: "現在表示されている情報を元に地点情報の修正を行います"

4. **バリデーション** (行168)
   - 条件: `origin_df['modify_flg'].sum() == 0`
   - メッセージ: "**修正する地点が選択されていません。最低1つは選択してください。**"


---

## 📝 Clineへの指示

このレポートを参照して、以下の調査を実施してください：

### 必須調査項目
- [ ] すべての画面ファイル（5個）の詳細確認
- [ ] 主要な関数・クラス（上位50個）の詳細確認
- [ ] データソース連携部分の詳細確認
- [ ] UI要素の実際の表示テキスト確認

### 調査完了基準
- [ ] 調査ファイル数：20個以上
- [ ] 特定した主要機能：50個以上
- [ ] 全画面（5画面）の機能を把握
- [ ] データフローを理解

### 期待されるテストケース数
- **最小**: 55件
- **推奨**: 75件
- **最大**: 95件

**重要**: テストケース生成時は、**推奨値**（75件）を目標としてください。
- 初回作成時: 推奨値 ± 10%（67～82件）
- 機能追加時: 推奨値の20～40%（15～30件）
- バグ修正時: 推奨値の10～20%（7～15件）
