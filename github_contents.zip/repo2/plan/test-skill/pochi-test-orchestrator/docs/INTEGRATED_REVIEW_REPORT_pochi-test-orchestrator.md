# pochi-test-orchestrator 統合レビューレポート

**作成日**: 2026-04-27  
**対象スキル**: `skills/test/pochi-test-orchestrator/`  
**統合元レポート**:
- `TECH_REVIEW_REPORT_pochi-test-orchestrator.md`（技術レビュー・Skillエンジニア観点）
- `UX_REVIEW_REPORT_pochi-test-orchestrator_ux-designer.md`（UXレビュー・UXデザイナー観点）

**参照ドキュメント**:
- `claude-code-guide/official/skill-best-practice.md`
- `claude-code-guide/guides/everything-claude-code活用事例.md`
- `claude-code-guide/guides/Everything Claude Code を眺める.md`

---

## エグゼクティブサマリー

`pochi-test-orchestrator` は、Pochiアプリのテストケースを4パターンで自動生成する意欲的な Skill であり、オーケストレーター＋専門サブエージェント（`test-case-specialist`）の分離アーキテクチャ・security.py による入力検証・SkillState による絶対パス一元管理など、ECC のベストプラクティスに沿った設計上の強みを持つ。

しかし **技術・UX 両視点から全社公開の Go 条件を満たさない Critical 課題が 4 件**、品質向上に関わる Major 課題が 6 件存在する。

**統合判定: ❌ No-Go（Critical 4 件の解消が公開条件）**

| 判定基準 | 現状 | 必要条件 | 審査結果 |
|---------|------|---------|---------|
| SKILL.md 行数 | **586行** | 500行以下 | ❌ |
| `input()` 対話ブロック | `core/orchestrator.py` に残存 | 非対話実行可能 | ❌ |
| entrypoint 型整合性 | 3箇所の定義が不整合 | 一元管理 | ❌ |
| 品質ゲート | 任意実行（手動のみ） | 自動検証 | ❌ |
| scripts/ と core/ | 二重実装が存在 | 単一実装（技術要件） | ❌ |
| requirements.txt | 存在しない | 依存定義が必要 | ⚠️ |
| test/ ディレクトリ | 空（自動テスト不在） | 最低限のスモークテスト | ⚠️ |

---

## 総合評価スコアカード

| 評価軸 | スコア | 主要根拠 |
|--------|--------|---------|
| トリガー発見性 | ★★★☆☆ | triggers は適切だが description が三人称未遵守（C-1-d / M-1） |
| SKILL.md の簡潔性 | ★★☆☆☆ | 586行（500行上限 +86行超過）、Step4 テンプレートがインライン（C-1 / TC-2） |
| 実行フロー明確性 | ★★☆☆☆ | entrypoint 3重不整合、手動テンプレート組み立て要求（C-5 / TC-4） |
| エラーリカバリ体験 | ★★★☆☆ | バックアップ機能は良好。サブエージェント再試行ループ未定義（M-3） |
| サブエージェント設計 | ★★★★☆ | ECC Tier1 パターン準拠。コンテキスト圧縮設計良好 |
| セキュリティ設計 | ★★★★☆ | security.py 実装済み（shell=False/入力検証/パストラバーサル対策）|
| Python コード品質 | ★★★★☆ | core/ 系統は良好。scripts/ 系統は except Exception 多用（TC-5） |
| テスタビリティ | ★☆☆☆☆ | test/ ディレクトリが空、pass@k 測定不在（TM-2） |
| 依存管理・保守性 | ★★★☆☆ | requirements.txt 不在、バージョン3重不整合（TM-1 / TM-3） |
| **総合** | **★★★☆☆** | **条件付き保留（Critical 解消後に公開可）** |

---

## 第1章: Critical 課題（全社公開前の必須対応）

### C-1. 【重複】SKILL.md 586行 — 500行上限超過（TC-2 / UX C-1）

**両視点からの指摘**:
- **技術（TC-2）**: 86行の超過は約 2,000〜2,500 トークンの余剰消費（1行 ≒ 25〜30 トークン概算）。Step4 にインライン埋め込みされたサブエージェント向けテンプレート（約100行）が主因。`prompts/generate_test_cases_prompt.md` との二重格納で DRY 原則違反
- **UX（C-1）**: コンテキスト過消費・認知負荷増大。Step4 到達前に情報過多になるユーザージャーニー上の問題

**行数削減の具体的手順（付録Aの詳細手順を参照）**:

| 対象箇所 | 現状行数 | 対応後行数 | 方法 |
|---------|---------|----------|------|
| フロントマタートリガー | 50個超 | 代表10個 | 代表トリガーに絞り込み |
| Step4 サブエージェントテンプレート | ~100行 | 参照1行 | `prompts/subagent_call_template.md` に外部化 |
| When/Don't 節 | 過多 | 簡潔化 | 使用例 → README、Troubleshooting → docs/ |
| 安全対策・バージョン節 | 記載あり | 削除 | README に移動、plugin.json に一元化 |

**目標構成（200行以内）**:
```
フロントマター        : ~20行（triggers 10個）
Trigger Phrases節    : ~15行
When節               : ~15行
Do節                 : ~20行
Instructions節       : ~80行（3ステップ）
Don't節              : ~15行
Inputs/Outputs節     : ~25行
4パターン概要         : ~10行（詳細は README 参照）
合計                 : ~200行
```

**優先度**: P1（C-3・C-5 対応後に実施推奨）

> **対応メリット**:
> - 📉 SKILL.md 読み込み時のコンテキスト消費量が約 30% 削減され、後半ステップでの指示欠落リスクが低下する
> - 🎯 Progressive Disclosure により Claude が必要なプロンプトのみをロードするため、Step4 の実行精度が向上する
> - 🔧 単一ファイルへの情報集中が解消され、スキル改修時のメンテナンスコストが大幅に下がる

---

### C-2. 【重複】`input()` 対話ブロック — EOFError / ハングリスク（TC-3 / UX C-3）

**問題の詳細**:
- `core/orchestrator.py` L69-86 の `ask_user_for_pattern()` が `input()` を4箇所使用
- 環境変数 `POCHI_PATTERN_SELECTION` / `POCHI_TEST_TYPE_SELECTION` が未設定時に呼び出される
- **技術的追加発見（TC-3）**: Claude が `subprocess` でスクリプト実行する場合、`stdin` は `/dev/null` 相当になり `input()` は即座に `EOFError` を送出。`skill_entry.py` に `except EOFError` ハンドリングがなく、**サイレントクラッシュ**のリスクがある

**修正案（付録Bに実装コード掲載）**:

`detect_pattern()` のフローを変更し、環境変数をプライマリとする:
```python
def detect_pattern(state: SkillState) -> Tuple[Pattern, Dict]:
    # 優先順位1: 環境変数（プライマリ）
    pattern = get_pattern_from_env(state)
    if pattern:
        return pattern, {"selection_method": "environment_variable", ...}
    
    # 優先順位2: 自動判定（input() は使わない）
    pattern, auto_details = auto_detect_pattern(state)
    state.logger.info("別パターンを指定する場合は POCHI_PATTERN_SELECTION 環境変数を設定してください")
    return pattern, {"selection_method": "auto_detection", ...}
```

SKILL.md の Do 節をエージェント側事前質問方式に変更:
```markdown
## Do
**起動前にユーザーにパターンを確認してください：**
1. スコープ: 全機能（full）/ 特定範囲（partial）
2. テストタイプ: 結合テスト（integration）/ シナリオテスト（scenario）

確認後、以下を実行：
```bash
POCHI_SKILL_ACTIVE=1 \
POCHI_PATTERN_SELECTION={判定されたパターン} \
python skills/test/pochi-test-orchestrator/skill_entry.py
```
```

**優先度**: P0（最優先・公開ブロック解除の第一歩）

> **対応メリット**:
> - ⚡ 環境変数プライマリ化により、Claude Code 環境での `input()` サイレントクラッシュが排除され、スキルが確実に起動できるようになる
> - 🤖 CI/CD パイプラインや自動化環境でも環境変数経由で安定実行でき、運用の幅が広がる
> - 🧭 自動判定結果と環境変数指定のログが明示されるため、ユーザーが意図通りのパターンで実行されているかを確認しやすくなる

---

### C-3. 【重複】品質ゲートが任意実行のみ（TC TM-6 / UX C-4）

**問題**:
- **現状（Step5 末尾の記述）**: 「品質ゲート（`quality_gate.py`）は実行しません。品質チェックが必要な場合は、ユーザーが手動で実行してください。」
- **技術的確認（TC）**: `quality_gate.py` は品質レポート生成・合否判定・終了コード設定が完全実装済み。自動実行しない理由が設計文書に存在しない
- **UX（C-4）**: ECC のチェックポイント型検証ループと真逆の設計。全社公開後に低品質テストケースが無検証で承認されるリスク

**修正案**:
Step5 で `quality_gate.py` を自動実行し、終了コード1時にエラー通知するフローに変更:
```markdown
### ステップ5: 品質ゲート実行（自動）
skill_entry.py が品質ゲートを自動実行します。
- 合格: 完了レポートを表示
- 不合格: エラーメッセージと改善箇所をユーザーに通知
```

**優先度**: P0

> **対応メリット**:
> - 🏆 低品質なテストケースが無検証のまま完了するリスクを排除し、全社展開後のテスト品質の底上げが実現できる
> - 🔄 ECC の Checkpoint-Based パターンに準拠した自動リトライフローにより、品質基準未達時の対処が自動化される
> - 📊 品質ゲートの合否ログが蓄積されることで、スキルの初回合格率などの改善指標を追跡できるようになる

---

### C-4. 【重複】entrypoint 3重不整合（TC-4 / UX C-5）

**3箇所の不整合**:

| 出所 | 定義内容 |
|------|---------|
| SKILL.md フロントマター | `type: prompt` / `path: prompts/generate_test_cases_prompt.md` |
| SKILL.md Do 節 | `python skill_entry.py` （Python スクリプト実行を要求） |
| skills.json | `entrypoint_type: "prompt"`（prompt 型と宣言） |

実態は Python スクリプト型であるため、正しい定義は `entrypoint_type: "python"`。この不整合により利用者が起動方法を誤解し、トラブルシュートが困難になる。

**修正案**:
```
1. skills.json の entrypoint_type を "python" に変更
2. SKILL.md フロントマターの entrypoint フィールドを削除（非標準フィールド）
3. Do 節の Python 実行指示を維持（これが唯一の正式実行方法）
```

**優先度**: P0（工数: ~30分）

> **対応メリット**:
> - 💡 スキルの起動方法が一箇所（`entrypoint_type: "python"`）に集約され、ユーザーが誤解なく実行できるようになる
> - 🔧 `skills.json` の定義が実態と一致することで、プラグインシステムが正しくスキルを認識できるようになる
> - 🧭 トラブルシュート時に「どこを見れば起動方法が分かるか」が明確になり、開発者の調査コストが下がる

---

## 第2章: Major 課題（全社公開前の強く推奨する対応）

### M-1. 【重複】description 三人称未遵守（TM-4 / UX M-1）

**現状の description**:
```yaml
description: Pochiアプリのテストケースを4パターンで自動生成・更新する際に使用。
             ユーザーが「Pochiのテストケースを生成」「テストケース更新」「品質チェック」
             などと依頼した時に起動する。
```

**問題**: skill-best-practice.md「常に三人称で書いてください」に違反。「使用」「起動する」は三人称ではなく、Skill が提供する価値ではなく起動条件の説明になっている。

**改善案（両視点で同一）**:
```yaml
description: >-
  Pochiアプリのテストケースを FullIntegration / FullScenario /
  PartialIntegration / PartialScenario の 4 パターンで自動生成・更新する。
  「Pochiのテストケースを生成して」「テストケース更新」「品質チェック」
  「pochi-test-orchestratorを起動」と言われた場合に使用する。
```

**優先度**: P1

> **対応メリット**:
> - 🎯 Claude がスキルを正しくトリガー判定できるようになり、「起動し損ね」「誤起動」が減少する
> - 💡 description の冒頭に 4 パターンの具体名を明示することで、ユーザーが何を生成できるかを即座に理解できる

---

### M-2. 【重複】Step4 テンプレートのインラインハードコード（TC / UX M-2）

**問題**:
- **技術（TC）**: `prompts/generate_test_cases_prompt.md` との二重格納（DRY 原則違反）。変数置換は `orchestrator.py` の `prepare_generation_context()` が `generation_context.json` を生成する際に自動化できる設計なのに、SKILL.md は手動組み立てを指示しており設計とドキュメントが矛盾
- **UX（M-2）**: 100行超のテンプレートを手動コピー＆カスタマイズさせることで、変数の置き換え漏れリスクと「問い返し禁止」制約との矛盾が発生

**推奨する根本解決（ECC 推奨アプローチ）**:
`core/orchestrator.py` の `prepare_generation_context()` に `subagent_prompt` 自動生成を追加（付録C 参照）。
これにより SKILL.md の Step4 を以下の1行に簡素化できる:
```markdown
### ステップ3: サブエージェント呼び出し
generation_context.json の `subagent_prompt_file` を読み込み、
その内容をそのまま @test-case-specialist に渡してください。
手動でのテンプレート組み立ては不要です。
```

**優先度**: P1

> **対応メリット**:
> - 🧹 SKILL.md から 100 行超のテンプレートが排除され、変数の置き換え漏れによる誤ったテストケース生成を防止できる
> - 🔗 `PromptBuilder` による自動生成が有効化され、SKILL.md の設計とコードの実装が一致した状態になる
> - ⏩ 「手動テンプレート組み立て」という認知負荷の高い作業が不要になり、ユーザーの操作ステップが削減される

---

### M-3. サブエージェント再試行ループ未定義（UX M-3）

**問題**: Step4-3 の確認項目（件数が目標範囲内か等）は列挙されているが、**確認失敗時の再試行フローが定義されていない**。品質指標が基準未満でも Skill が「完了」と判定される。

ECC「反復的取得パターン」: ループは最大3回に制限して無限ループを防ぐ。

**改善案**:
```markdown
#### 4-3: サブエージェントからの返却確認（Checkpoint-Based）
確認項目が基準未満の場合:
→ test-case-specialist を再起動（最大3回）
→ 3回後も基準未達の場合: 不合格サマリーをユーザーに提示し確認を取ってから完了
```

**優先度**: P2（Phase 3 対応）

> **対応メリット**:
> - 🏆 品質基準未満のテストケースが「完了」として処理されるリスクを排除でき、全社展開後の成果物の品質が安定する
> - 🔄 ECC の反復的取得パターンに準拠することで、サブエージェントが生成に失敗した際も最大3回まで自動リカバリされる
> - 📊 3回再試行後も未達の場合にユーザー承認を取得する設計により、最終判断が透明化される

---

### M-4. 【重複】バージョン番号の3重不整合（TM-3 / UX M-4）

| 出所 | バージョン値 |
|------|------------|
| SKILL.md フロントマター `version:` | `1.0.0` |
| `plugin.json` | `1.0.0` |
| SKILL.md 本文 `## バージョン・ライセンス` | **`3.0.0`** |

**修正案**: Pochi CLAUDE.md ガイドライン通り `plugin.json` で一元管理し、SKILL.md 本文の `## バージョン・ライセンス` セクションを削除する。

**優先度**: P1（工数: 極小）

> **対応メリット**:
> - 🔧 バージョンの参照先が `plugin.json` に一本化され、「どのバージョンが正しいか」という混乱を排除できる
> - ✅ スキルのバージョン管理フローが CLAUDE.md ガイドラインと整合し、他のスキルと運用方法を統一できる

---

### M-5. 【技術独自】scripts/ と core/ の二重実装（TC-5 — Critical）

**最も深刻な技術的課題**:

| ファイル | scripts/ 系統（旧） | core/ 系統（新） |
|---------|-------------------|----------------|
| オーケストレーター | `scripts/orchestrator.py` | `core/orchestrator.py` |
| 環境チェック | `scripts/precheck.py` | `core/precheck.py` |
| 差分生成 | `scripts/diff_generator.py` | `core/diff.py` |
| 品質ゲート | `scripts/quality_gate.py` | `core/quality_gate.py` |

`skill_entry.py` は `core/` を import して実行しており、`scripts/` は `skill_smoke_test.sh` からのみ間接参照。  
`scripts/precheck.py` は対話プロンプトを持つが `core/precheck.py` は非対話版と実装が異なる。  
`scripts/` 系統では `except Exception` が20箇所以上使用されており、エラーのサイレント隠蔽リスクがある。

**修正案**: `scripts/` を `archive/` に移動または削除し `core/` に一本化。`skill_smoke_test.sh` は `core/` ベースのテストに置き換える。

**優先度**: P0（TC-5 — Critical として技術レビューで指定）

> **対応メリット**:
> - 🛡️ `except Exception` が 20 箇所以上存在する `scripts/` 系統が排除され、エラーのサイレント隠蔽リスクが解消される
> - 🔧 `core/` に一本化することでコードベースが半減し、将来の改修コストと不具合混入リスクが大幅に低下する
> - ✅ `from core import ...` のみで動作する一貫した実装になり、新規参加の開発者が構造を理解しやすくなる

---

### M-6. 【技術独自】requirements.txt の不在（TM-1）

`skill_entry.py` は Python エントリポイントとして機能しているが、依存ライブラリ定義がない。現状は標準ライブラリのみ（`pathlib`, `subprocess`, `re`, `json` 等）だが、以下の理由で作成が推奨される:
1. 全社配布後に第三者が Python 依存を追加した場合の手順が不明確
2. `docs/INSTALLATION.md` に Python バージョン要件（3.8+）の記載はあるが依存管理の標準的方法がない
3. 将来の CI/CD 自動テスト実装時に環境構築が困難

**修正案**: 現時点では標準ライブラリのみのため最小構成の `requirements.txt` を作成:
```
# pochi-test-orchestrator Python dependencies
# Currently uses only standard library (Python 3.8+)
```

**優先度**: P2

> **対応メリット**:
> - 📖 全社配布後に第三者が Python 依存を追加する際の標準的な手順が明確になり、依存管理の属人化を防げる
> - 🤖 将来の CI/CD 自動テスト実装時に環境構築が `pip install -r requirements.txt` で完結し、オンボーディングコストが下がる

---

## 第3章: 統合優先度マトリクス

### P0（全社公開前・必須対応）

| ID | 課題 | 視点 | 工数 | 依存 |
|----|------|------|------|------|
| C-2 / TC-3 | `input()` → 環境変数プライマリ化（+EOFError 対策） | 技術・UX | 小（~1h） | なし |
| C-3 / TM-6 | 品質ゲートを Step5 で自動実行 | 技術・UX | 小（~1h） | なし |
| C-4 / TC-4 | entrypoint 3重不整合を解消（skills.json を "python" に変更） | 技術・UX | 極小（~30min） | なし |
| M-5 / TC-5 | scripts/ を archive/ に移動し core/ に一本化 | 技術 | 中（~2h） | C-2 解消後推奨 |

> **P0 各課題の対応メリット**:
> - ⚡ **C-2 input() 廃止**: Claude Code 環境でのサイレントクラッシュが完全に排除され、スキルが任意の環境で安定起動できるようになる
> - 🏆 **C-3 品質ゲート自動化**: 生成されたテストケースの品質が自動検証されるようになり、低品質の成果物が無検証で完了するリスクがなくなる
> - 💡 **C-4 entrypoint 一元化**: 起動方法の誤解によるトラブルシュートが不要になり、初回ユーザーの導入摩擦が大幅に下がる
> - 🛡️ **M-5 scripts/ 一本化**: エラーを隠蔽する `except Exception` が 20 箇所以上排除され、本番での予期しない動作リスクが解消される

### P1（全社公開前・強く推奨する対応）

| ID | 課題 | 視点 | 工数 |
|----|------|------|------|
| C-1 / TC-2 | SKILL.md を 500行以内に圧縮（Step4 テンプレート外部化） | 技術・UX | 大 |
| M-1 / TM-4 | description を三人称・具体的トリガー含む形式に改訂 | 技術・UX | 極小 |
| M-2 / TM-5 | generation_context.json に subagent_prompt を自動格納し Step4 を簡素化 | 技術・UX | 中 |
| M-4 / TM-3 | バージョンを plugin.json で一元管理（SKILL.md 3.0.0 記述を削除） | 技術・UX | 極小 |

> **P1 各課題の対応メリット**:
> - 📉 **C-1 SKILL.md 圧縮**: コンテキスト消費が削減されて Step4 到達前の情報過多が解消され、各ステップの実行精度が上がる
> - 🎯 **M-1 description 改訂**: トリガー判定精度が上がり「起動し損ね」が減少し、4 パターンの具体名明示でユーザーの期待値ミスマッチが防止される
> - ⏩ **M-2 subagent_prompt 自動生成**: 100 行超のテンプレート手動組み立てが不要になり、変数置き換え漏れリスクが排除される
> - 🔧 **M-4 バージョン一元管理**: 参照先が `plugin.json` に集約されてバージョン混乱がなくなり、リリース管理が標準化される

### P2（展開後・公開後対応可）

| ID | 課題 | 視点 | 工数 |
|----|------|------|------|
| M-3 | サブエージェント再試行ループ（最大3回）実装 | UX | 中 |
| M-6 / TM-1 | requirements.txt 作成（最小構成） | 技術 | 極小 |
| TM-2 | test/ にスモークテストを追加（test_orchestrator.py 等） | 技術 | 中 |
| m-1 / Tm-1 | model を `claude-3-5-sonnet` → 最新モデル名に更新 | 技術・UX | 極小 |
| Tm-2 | `POCHI_SKILL_DEBUG=1` バイパスを docs/ADVANCED.md に注記 | 技術 | 極小 |
| Tm-4 | docs/ 各ファイルを SKILL.md の適切なステップからリンク | 技術 | 小 |
| Tm-5 | SKILL.md フロントマターから非標準フィールド（skill_id, id, title 等）を削除 | 技術 | 小 |
| m-3 | フロントマタートリガーと `## Trigger Phrases` セクションの重複を削除 | UX | 小 |
| m-4 | オーケストレーター側の allowedTools 定義 | UX・セキュリティ | 小 |

> **P2 各課題の対応メリット**:
> - 🔄 **M-3 再試行ループ**: サブエージェントが品質基準未満の場合も最大3回自動リカバリされ、全社展開後の成果物品質が安定する
> - 📖 **M-6 requirements.txt**: 全社配布後の依存管理が標準化され、新規参加者が環境構築に迷わなくなる
> - 🏆 **TM-2 スモークテスト**: 4パターン判定・品質ゲートなどのコアロジックが自動検証され、コード改修時のデグレを即座に検知できる
> - 💰 **m-1 モデル名更新**: 最新モデルへの切り替えにより、生成品質の向上とコスト最適化の恩恵を継続的に受けられる
> - 🛡️ **Tm-2 デバッグバイパス注記**: `POCHI_SKILL_DEBUG=1` の存在が明示され、意図しない本番バイパスのインシデントリスクが低下する
> - 🧭 **Tm-4 docs/ リンク整備**: 各ステップから関連ドキュメントへ直接ジャンプできるようになり、ユーザーの自己解決率が上がる
> - 🧹 **Tm-5 非標準フィールド削除**: フロントマターがスキーマに準拠し、プラグインシステムのバリデーションエラーリスクが排除される
> - 📉 **m-3 トリガー重複削除**: SKILL.md の重複行が削減され、行数圧縮目標（~200行）の達成に貢献する
> - 🔒 **m-4 allowedTools 定義**: オーケストレーター側の権限が最小限に絞られ、ECC の AgentShield 推奨に準拠したセキュリティ設計になる

### 対応済み（前回レビュー由来）

| 内容 | 対応日 |
|------|------|
| skills.json と SKILL.md フロントマター triggers の同期 | 2026-04-24 |
| パス不整合の修正（絶対パス → 相対パス） | 2026-04-24 |
| Windows 固有コマンドの削除 | 2026-04-24 |

---

## 第4章: ユーザージャーニー分析（現状 vs 理想）

### 現状のユーザージャーニー（全社公開ユーザー視点）

```
【新規ユーザー】 「Pochiのテストケースを生成して」
    │
    ├─ 1. SKILL.md 読み込み（586行）
    │        └─ 🔴 コンテキスト大量消費。Step4 到達前に情報過多
    │
    ├─ 2. Do 節のコマンド実行 → skill_entry.py 起動
    │        ├─ 環境変数未設定の場合: input() でユーザーに質問
    │        │     └─ 🔴 Claude Code 環境でハング or サイレントクラッシュ
    │        └─ 環境変数設定済みの場合: 正常進行
    │
    ├─ 3. generation_context.json 読み込み（Step2）
    │
    ├─ 4. reference_files[] を順次読み込み（Step3）
    │        └─ 🟡 ファイル数が多い（5〜8ファイル）
    │
    ├─ 5. Step4: サブエージェント呼び出しテンプレートを手動組み立て
    │        └─ 🔴 100行超のテンプレートを変数置換しながら組み立て
    │              └─ 変数の置き換え漏れリスク大
    │
    ├─ 6. test-case-specialist が test_cases.md 生成
    │        └─ 不合格でも検証なし（Step5 で品質ゲートスキップ）
    │              └─ 🔴 低品質テストケースが無検証で完了
    │
    └─ 7. 完了（品質保証なし）
```

### 全社公開に向けた理想のユーザージャーニー（P0 + P1 対応後）

```
【新規ユーザー】 「Pochiのテストケースを生成して」
    │
    ├─ 1. SKILL.md 読み込み（200行以内）
    │
    ├─ 2. Claude エージェントがユーザーにパターン選択を事前質問
    │
    ├─ 3. skill_entry.py 実行
    │        └─ generation_context.json に完成済みサブエージェントプロンプトを格納
    │
    ├─ 4. generation_context.json 読み込み（完成済みプロンプト含む）
    │
    ├─ 5. test-case-specialist を Agent ツールで呼び出し（プロンプト自動使用）
    │        └─ 不十分な場合は最大3回再試行（反復的取得パターン）
    │
    ├─ 6. 品質ゲート自動実行
    │        ├─ 合格: 完了レポートを表示
    │        └─ 不合格: エラーメッセージと改善箇所をユーザーに通知
    │
    └─ 7. 完了（品質保証済み）
```

---

## 第5章: セキュリティ評価

### 5-1. 強みとして評価できる実装

| 項目 | 評価 | 根拠 |
|------|------|------|
| subprocess の shell=False | ✅ 安全 | `core/diff.py`, `core/orchestrator.py` で確認済み |
| Git リファレンスの入力検証 | ✅ 実装済み | `scripts/security.py:validate_git_ref()` が正規表現で危険パターンを拒否 |
| パストラバーサル対策 | ✅ 実装済み | `scripts/security.py:validate_path_in_artifacts()` が artifact ルート外アクセスを拒否 |
| コマンド引数サニタイズ | ✅ 実装済み | `scripts/security.py:sanitize_command_args()` が危険文字を検出 |
| タイムアウト設定 | ✅ 実装済み | `app_structure_analyzer.py` 実行に 300 秒タイムアウト設定 |
| 環境変数ガード | ✅ 実装済み | `POCHI_SKILL_ACTIVE=1` による誤実行防止 |
| サブエージェントの tools 制限 | ✅ 最小権限 | `test-case-specialist.md` が `Read/Write/Glob/Grep` のみに制限 |

### 5-2. セキュリティ上の改善点

#### デバッグバイパスの本番混入リスク（Minor）
```python
# scripts/security.py L31-33
if os.environ.get("POCHI_SKILL_DEBUG") == "1":
    logger.warning("⚠️  デバッグモード: Skills専用チェックをバイパスしました")
    return
```
`POCHI_SKILL_DEBUG=1` により `POCHI_SKILL_ACTIVE` チェックを完全バイパスできる。README 等に存在が明示されていないため、意図しない利用を防ぐ注記が必要。

#### オーケストレーター側の allowedTools 未定義（Minor）
`test-case-specialist.md` のサブエージェント tools 制限は適切だが、親 Claude エージェント（オーケストレーター）側の `allowedTools` 制限が SKILL.md に定義されていない。ECC の AgentShield（Slide 21）ではオーケストレーター側にも最小権限を設けることを推奨している。

#### except Exception の広域ハンドリング（Minor）
`scripts/` 系統のコードで `except Exception as e:` が20箇所以上確認される。`scripts/` を `core/` に一本化（M-5 対応）することで自然に解消される。

---

## 第6章: アーキテクチャ評価

### 6-1. 設計上の強み

| 設計要素 | 評価 | ECC 対応 |
|---------|------|---------|
| サブエージェント分離（test-case-specialist） | ✅ 優良 | ECC Tier1 サブエージェントパターン準拠 |
| 厳格サマリ返却（80-100K→3-5K tokens 圧縮） | ✅ 優良 | ECC 活用事例2 コンテキスト削減設計 |
| SkillState による一元的パス管理 | ✅ 優良 | 絶対パス使用・ロガー重複対策済み |
| security.py による入力検証 | ✅ 優良 | OWASP インジェクション対策 |
| run_id による実行履歴管理 | ✅ 良好 | 運用トレーサビリティ確保 |
| 4パターン体系（Full/Partial × Integration/Scenario） | ✅ 良好 | 直交した分類でユーザーに理解しやすい |
| 自動バックアップ（.bak ファイル生成） | ✅ 良好 | データ安全性 |
| 環境変数によるパターン指定（CI/CD 対応） | ✅ 良好 | 自動化パイプライン統合可能 |
| PromptBuilder 実装済み | ✅ 実装済み | ただし SKILL.md フローから未活用（M-2） |

### 6-2. 理想アーキテクチャ（M-5 + M-2 対応後）

```
現状（問題点あり）:
  SKILL.md
    └─ Do: python skill_entry.py（core/ ベース）
    └─ scripts/（旧実装 - 未使用状態）
    └─ Step4: 手動テンプレート組み立て（約100行）

理想（一本化 + 自動化後）:
  SKILL.md（~200行）
    └─ Do: generation_context.json の subagent_prompt を使用
    └─ core/（唯一の実装）
        ├─ skill_entry.py
        ├─ state.py
        ├─ precheck.py
        ├─ diff.py
        ├─ orchestrator.py（PromptBuilder 活用 → subagent_prompt を自動生成）
        └─ quality_gate.py（Step5 で自動実行）
  tests/（最低限のスモークテスト）
```

---

## 第7章: 全社公開前 必須対応ロードマップ

### Phase 1: Go 条件クリア（P0 対応・推定工数: 中）

```
□ C-2 / TC-3: core/orchestrator.py の input() を環境変数読み取りに置き換え（~1h）
□ C-3 / TM-6: quality_gate.py を Step5 で自動実行（終了コード 1 時にエラー通知）（~1h）
□ C-4 / TC-4: skills.json の entrypoint_type を "python" に変更、
               SKILL.md フロントマターの entrypoint フィールドを削除（~30min）
□ M-5 / TC-5: scripts/ を archive/ に移動して core/ に一本化（~2h、動作確認含む）
```

**Phase 1 完了後の動作確認**:
- 環境変数なしで `skill_entry.py` を実行してもクラッシュしないこと
- 品質ゲートが Step5 で自動実行されること
- `from core import ...` のみで正常動作すること

### Phase 2: 品質向上（P1 対応・全社公開前推奨・推定工数: 大）

```
□ C-1 / TC-2: SKILL.md を 500行以内（目標 ~200行）に圧縮
   └─ Step4 テンプレート → prompts/subagent_call_template.md に外部化
   └─ フロントマタートリガーを代表 10 個に絞り込み
   └─ Troubleshooting → docs/ に移動、安全対策・バージョン節を削除
□ M-1 / TM-4: description を三人称・トリガーフレーズ含む形式に改訂
□ M-2 / TM-5: orchestrator.prepare_generation_context() に subagent_prompt 自動生成を追加
□ M-4 / TM-3: SKILL.md 本文の version: 3.0.0 を削除し plugin.json に一元化
```

**モニタリング開始**:
- STEP 4-3 の品質指標確認率
- 品質ゲート初回合格率（目標: 80%以上）

### Phase 3: 継続改善（P2 対応・公開後可）

```
□ M-3: サブエージェント再試行ループ（最大3回）の実装
□ M-6 / TM-1: requirements.txt を作成（最小構成）
□ TM-2: test/ にスモークテストを追加
   └─ orchestrator.map_answers_to_pattern() の 4パターン判定ロジック
   └─ orchestrator.get_pattern_from_env() の環境変数取得・不正値処理
   └─ quality_gate.py の合否判定ロジック
□ Tm-1 / m-1: agents/test-case-specialist.md の model を最新モデル名に更新
□ Tm-2: POCHI_SKILL_DEBUG=1 の用途と注意事項を docs/ADVANCED.md に追記
□ Tm-4: docs/ 各ファイルを SKILL.md の適切なステップからリンク
□ Tm-5 / m-3: SKILL.md フロントマターから非標準フィールドを削除、トリガー重複を解消
□ m-4: オーケストレーター側の allowedTools 定義
□ 2〜4週間の社内運用後、status: "wip" → "stable" へ昇格判定
```

---

## 第8章: 全社公開向けチェックリスト

### 必須（Go/No-Go 判定）
- [ ] `input()` ハング問題が解消されている（環境変数プライマリ化済み）
- [ ] 品質ゲートが自動実行されるフローになっている
- [ ] SKILL.md の entrypoint 定義が `skills.json` と一致している（"python"）
- [ ] scripts/ が core/ に一本化されている
- [ ] SKILL.md が 500行以下になっている
- [ ] `description` が三人称で記述されている
- [ ] バージョン番号が plugin.json で一元管理されている

### 推奨（品質向上）
- [ ] Step4 のテンプレートが外部ファイル化されている
- [ ] generation_context.json に subagent_prompt が自動格納される
- [ ] サブエージェント再試行ループが実装されている
- [ ] モデル名が最新バージョンに更新されている
- [ ] test/ に最低限のスモークテストが追加されている

---

## 結論 & 最終判定

`pochi-test-orchestrator` は**セキュリティ設計・サブエージェントアーキテクチャ・コンテキスト圧縮設計**の点で ECC ベストプラクティスに沿った優れた設計を持ち、Pochi 開発チームの生産性向上に大きく貢献できるポテンシャルがある。

**最終判定**: ❌ **No-Go**

**公開条件（P0 全 4 件 + 動作確認テスト）**:
1. C-2 / TC-3: `input()` → 環境変数プライマリ化（EOFError 対策含む）
2. C-3 / TM-6: 品質ゲートの自動実行化
3. C-4 / TC-4: entrypoint 定義の一元化（skills.json を "python" に変更）
4. M-5 / TC-5: scripts/ と core/ の一本化（二重実装解消）

P0 課題 4 件の解消と動作確認テストが完了した段階で、**⚠️ 条件付き Go（P1 対応を次スプリントで実施）** に移行できる。

---

## 付録A: SKILL.md 圧縮の具体的手順（C-1 対応）

### Step 1: フロントマタートリガーを代表10個に絞り込み

削除の基準:
- 英語トリガーは代表1個のみ残す（`generate test cases`）
- 「パターン2」「パターン4」は「パターン1」「パターン3」に代表させる
- 「〜を起動」「〜起動」の重複は1個に統合
- `Pattern1`〜`Pattern4`（英語表記）は削除

残すトリガー（推奨）:
```yaml
triggers:
  - Pochiのテストケースを生成して
  - テストケースを生成して
  - テストケース生成
  - テストケース更新
  - pochi-test-orchestrator を起動
  - 品質チェック
  - パターン1
  - パターン3
  - pochilibアップデート対応のテストケース生成
  - generate test cases
```

### Step 2: Step4 テンプレートを外部ファイル化

```
prompts/subagent_call_template.md  ← 新規作成（既存100行を移動）
```

SKILL.md 側は以下の3行に置き換え:
```markdown
### ステップ4: サブエージェントへのテストケース生成委譲（必須）
`prompts/subagent_call_template.md` を読み込み、
generation_context.json の情報で変数を埋めて @test-case-specialist を呼び出してください。
```

### Step 3: 不要セクションの削除・移動

| セクション | 対応 |
|-----------|------|
| 「使用例」3パターン | README.md へ移動 |
| 「Troubleshooting」 | `docs/` 配下へ完全移動 |
| 「安全対策」「バージョン・ライセンス」 | README.md へ移動 |
| 「参照ドキュメント」リンク集 | 削除（README.md に集約） |
| 「起動しない条件」5行 | 1行に簡潔化 |

---

## 付録B: input() 廃止の実装コード（C-2 対応）

```python
# core/orchestrator.py: detect_pattern() の修正

def detect_pattern(state: SkillState) -> Tuple[Pattern, Dict]:
    details = {"selection_method": None, "confidence": 0.0, "reason": ""}
    
    # 優先順位1: 環境変数（プライマリ）
    pattern = get_pattern_from_env(state)
    if pattern:
        details["selection_method"] = "environment_variable"
        details["confidence"] = 1.0
        details["reason"] = f"環境変数で{pattern.value}が指定"
        return pattern, details
    
    # 優先順位2: 自動判定（input() は使わない）
    pattern, auto_details = auto_detect_pattern(state)
    details["selection_method"] = "auto_detection"
    details["confidence"] = auto_details.get("confidence", 0.8)
    details["reason"] = auto_details.get("reason", "自動判定")
    state.logger.info(f"自動判定結果: {pattern.value}")
    state.logger.info("別パターンを指定する場合は POCHI_PATTERN_SELECTION 環境変数を設定してください")
    return pattern, details

def ask_user_for_pattern(state: SkillState) -> Tuple[str, str]:
    """[DEPRECATED] 対話的質問によるパターン選択。
    Claude Code環境では input() が動作しないため非推奨。
    POCHI_PATTERN_SELECTION 環境変数を使用してください。
    """
    state.logger.warning("ask_user_for_pattern() は非推奨です。環境変数を使用してください。")
    # 既存の実装は維持（CLI フォールバック用）
    ...
```

---

## 付録C: subagent_prompt 自動生成の実装コード（M-2 対応）

```python
# core/orchestrator.py: prepare_generation_context() への追加

def prepare_generation_context(pattern, state, base_branch, details):
    # ... 既存の context 生成ロジック ...
    
    # 新規: サブエージェント向けプロンプトを自動組み立て
    from core.prompt_builder import PromptBuilder
    builder = PromptBuilder()
    subagent_prompt = builder.build_optimized_prompt(pattern, context)
    context["subagent_prompt"] = subagent_prompt
    
    # サブエージェント向けプロンプトをファイル出力
    subagent_prompt_file = state.paths["artifacts"] / "subagent_prompt.md"
    with open(subagent_prompt_file, "w") as f:
        f.write(subagent_prompt)
    context["subagent_prompt_file"] = str(subagent_prompt_file)
    
    return context
```

SKILL.md の Instructions 節（3ステップ化後）:
```markdown
## Instructions

### ステップ1: skill_entry.py 実行
Do 節のコマンドを実行。準備フェーズが完了します。

### ステップ2: generation_context.json 読み込み
`test-cases/generation_context.json` を JSON として読み込み、
`reference_files[]` の各ファイルを順次参照してください。

### ステップ3: サブエージェント呼び出し
generation_context.json の `subagent_prompt_file` を読み込み、
その内容をそのまま @test-case-specialist に渡してください。
手動でのテンプレート組み立ては不要です。
```

---

## 付録D: コアモジュールのユニットテスト推奨（TM-2 対応）

```python
# test/test_orchestrator.py（新規作成）

import pytest
from core.orchestrator import map_answers_to_pattern, Pattern, get_pattern_from_env

class TestMapAnswersToPattern:
    def test_full_integration(self):
        assert map_answers_to_pattern("full", "integration") == Pattern.FULL_INTEGRATION

    def test_full_scenario(self):
        assert map_answers_to_pattern("full", "scenario") == Pattern.FULL_SCENARIO

    def test_partial_integration(self):
        assert map_answers_to_pattern("partial", "integration") == Pattern.PARTIAL_INTEGRATION

    def test_partial_scenario(self):
        assert map_answers_to_pattern("partial", "scenario") == Pattern.PARTIAL_SCENARIO

    def test_unknown_falls_back(self):
        assert map_answers_to_pattern("unknown", "unknown") == Pattern.FULL_INTEGRATION


class TestGetPatternFromEnv:
    def test_valid_env_var(self, monkeypatch):
        monkeypatch.setenv("POCHI_PATTERN_SELECTION", "full_integration")
        # 環境変数から正しく Pattern を取得できること

    def test_invalid_env_var(self, monkeypatch):
        monkeypatch.setenv("POCHI_PATTERN_SELECTION", "invalid_value")
        # 不正値の場合は None を返すこと
```

推奨テスト対象一覧:

| テスト対象 | テスト内容 | 優先度 |
|-----------|-----------|--------|
| `orchestrator.map_answers_to_pattern()` | 4パターンのマッピング正確性 | 高 |
| `orchestrator.get_pattern_from_env()` | 環境変数からのパターン取得・不正値処理 | 高 |
| `precheck.run()` | 環境チェック（Python, Git, 書き込み権限） | 中 |
| `state.SkillState()` | 初期化・パス解決・ログ設定 | 中 |
| `quality_gate.calculate_from_metrics()` | 動的件数計算の正確性 | 中 |
| `prompt_builder.PromptBuilder` | プロンプト組み立て | 低 |

---

## 付録E: コストレポート（2026-04-20 セッション）

| 項目 | 値 |
|------|-----|
| 合計コスト | $3.54 |
| API 処理時間 | 11分10秒 |
| 実経過時間 | 29分36秒 |
| コード変更量 | +2533 / 0行（新規追加のみ） |

| モデル | input | output | cache read | cache write | コスト |
|--------|-------|--------|------------|-------------|--------|
| claude-sonnet-4-6 | 3.0k | 17.3k | 3.6m | 453.9k | $3.06 |
| claude-haiku-4-5 | 11.2k | 46.2k | 445.1k | 153.7k | $0.48 |

**特記事項**:
- Sonnet が $3.06（全体の 86%）を占める。`pochi-unit-test-generator`（Haiku 62%）と逆転しており、新規追加のシンプルなタスクでも Sonnet 依存が高い
- cache read が 3.6m tokens と大量発生。SKILL.md や共通コンテキストの再利用でコストが抑えられている
- Haiku が $0.48 と安価。新規追加のみ（+2533行、削除なし）というシンプルな生成タスクを反映

---

## 付録F: 分析対象ファイル一覧

| ファイル | 行数概算 | 役割 |
|----------|----------|------|
| `skills/run/SKILL.md` | 586行（2026-04-27時点） | Skill定義・実行指示 |
| `plugin.json` | 10行 | プラグインメタデータ |
| `README.md` | ~400行 | ユーザー向け説明 |
| `skill_entry.py` | ~200行 | メインエントリポイント |
| `core/orchestrator.py` | ~200行 | パターン判定ロジック |
| `config/default_config.json` | ~100行 | デフォルト設定 |
| `agents/test-case-specialist.md` | ~100行 | サブエージェント定義 |
| `docs/QUICKSTART.md` | ~100行 | クイックスタート |
| `docs/INSTALLATION.md` | ~100行 | インストール手順 |
| `docs/ADVANCED.md` | ~200行 | 高度な統合ガイド |
| `prompts/generate_test_cases_prompt.md` | ~200行 | 生成プロンプト（Step4 テンプレートと重複） |

---

*本レポートは 2026-04-27 時点の `skills/test/pochi-test-orchestrator/` を対象とした、技術レビュー・UXレビュー・前回 UXレビュー（2026-04-20作成、2026-04-24対応実施）の統合版です。*

---

## 付録G: 指摘別 検知根拠マッピング

各指摘がどの参照ドキュメントのどの記述から検知されたかを示す。「コードレビュー由来」はドキュメントに根拠を持たず、実装コードを直接読んで発見した指摘を指す。

| 指摘ID | 指摘内容 | 検知根拠（ドキュメント・箇所） |
|--------|---------|-------------------------------|
| **C-1 / TC-2** | SKILL.md 586行・500行超過 | `skill-best-practice.md` L229「SKILL.md 本体を最適なパフォーマンスのために 500 行以下に保つ」 |
| **C-2 / TC-3** | `input()` EOFError / ハングリスク | **コードレビュー由来**（3ドキュメントに根拠なし）— `core/orchestrator.py` L69-86 を直接読んで発見した実装バグ |
| **C-3 / TM-6** | 品質ゲートが任意実行のみ | `眺める.md` Slide 13「Checkpoint-Based: 明示的チェックポイントで基準を検証、合格まで次へ進まない」、`everything-claude-code活用事例.md` 活用事例8 L298〜 チェックポイント型フロー図 |
| **C-4 / TC-4** | entrypoint 3重不整合 | **コードレビュー由来**（3ドキュメントに根拠なし）— SKILL.md・skills.json・Do節を突き合わせて発見した実装上の不整合 |
| **M-1 / TM-4** | description 三人称未遵守 | `skill-best-practice.md` L184「常に三人称で書いてください」（Warning ブロック） |
| **M-2 / TM-5** | Step4 テンプレートのインラインハードコード | `skill-best-practice.md` L224〜「プログレッシブディスクロージャーパターン」（外部ファイル分割パターン1/2/3）、`everything-claude-code活用事例.md` 活用事例2 L107「中間出力はファイルに保存すること」 |
| **M-3** | サブエージェント再試行ループ未定義 | `everything-claude-code活用事例.md` 活用事例2 L115「ループは最大3回に制限して無限ループを防ぐ」（反復的取得パターン） |
| **M-4 / TM-3** | バージョン番号の3重不整合 | **コードレビュー由来**（3ドキュメントに根拠なし）— SKILL.md・plugin.json を読み比べて発見した実装の矛盾 |
| **M-5 / TC-5** | scripts/ と core/ の二重実装 | **コードレビュー由来**（3ドキュメントに根拠なし）— ディレクトリ構成とコードを直接読んで発見した重複実装 |
| **M-6 / TM-1** | requirements.txt 不在 | **コードレビュー由来**（3ドキュメントに根拠なし）— Python パッケージ管理の一般知識と、依存管理ファイルが存在しないことを確認して指摘 |
| **m-4** | allowedTools 未定義（オーケストレーター側） | `眺める.md` Slide 22「許可するToolを最小限に絞る（allowedTools の設定）」、`everything-claude-code活用事例.md` 活用事例10 L354〜 サンドボックスの設定例 |
| **TM-2** | test/ が空（スモークテスト不在） | **コードレビュー由来**（3ドキュメントに根拠なし）— ディレクトリ構成を確認して発見 |
