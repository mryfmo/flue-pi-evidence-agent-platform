# 技術レビューレポート: pochi-test-orchestrator 全社公開審査

**作成日**: 2026-04-27  
**レビュアー**: Skillエンジニア（GitHub Copilot）  
**対象Skill**: `skills/test/pochi-test-orchestrator/`  
**レビュー目的**: 全社公開前の技術品質審査  
**参照ドキュメント**:
- `claude-code-guide/official/skill-best-practice.md`（Anthropic公式ベストプラクティス）
- `claude-code-guide/guides/everything-claude-code活用事例.md`（ECC実践活用事例）
- `claude-code-guide/guides/Everything Claude Code を眺める.md`（ECCアーキテクチャ概観）
- `plan/test-skill/UX_REVIEW_REPORT_pochi-test-orchestrator_ux-designer_20260427.md`（既存UXレビュー）

> **本レポートの位置づけ**: UXレビュー（2026-04-27）が発見した課題を技術的側面から深掘りし、加えてコード品質・セキュリティ・アーキテクチャ準拠性の観点から追加評価を実施する。UXレビューとの重複指摘は「UX指摘と同一」と注記し、技術的根拠を補足する。

---

## 1. エグゼクティブサマリ

`pochi-test-orchestrator` は、Pochiアプリのテストケース生成を自動化する意欲的な Skill であり、Python モジュール群（`core/`）による前処理とサブエージェント（`test-case-specialist`）へのオーケストレーション委譲というアーキテクチャは ECC のベストプラクティスに沿った設計方針を持つ。

しかし技術的観点では、全社公開の Go 条件を満たさない **Critical 課題が 4 件**、実装の健全性に懸念を与える **Major 課題が 6 件** が存在する。

**全社公開可否判定: ❌ No-Go（技術審査）**

| 判定基準 | 現状 | 必要条件 | 審査結果 |
|---------|------|---------|---------|
| SKILL.md 行数 | **586 行** | 500 行以下 | ❌ |
| `input()` 対話ブロック | core/orchestrator.py に残存 | 非対話実行可能 | ❌ |
| entrypoint 型整合性 | 3 箇所の定義が不整合 | 一元管理 | ❌ |
| scripts/ と core/ の二重実装 | 同名ファイルが 2 系統存在 | 単一実装 | ❌ |
| requirements.txt | 存在しない | 依存定義が必要 | ⚠️ |
| test/ ディレクトリ | 空（自動テスト不在） | 最低限のスモークテスト | ⚠️ |

---

## 2. 総合評価スコアカード（技術軸）

| 評価軸 | スコア | 判定 |
|--------|--------|------|
| Python コード品質 | ★★★★☆ | 良好（core/ 系統） |
| セキュリティ設計 | ★★★★☆ | 良好（security.py 実装済み） |
| Skill 仕様準拠性 | ★★☆☆☆ | 要改善 |
| アーキテクチャ整合性 | ★★★☆☆ | 改善余地あり |
| 実行時安全性 | ★★☆☆☆ | 要改善（input() ブロック） |
| 依存管理・保守性 | ★★★☆☆ | 改善余地あり |
| テスタビリティ | ★☆☆☆☆ | 要改善（test/ 空） |
| **総合** | **★★★☆☆** | **条件付き保留** |

---

## 3. 参照ドキュメントとの照合分析

### 3-1. skill-best-practice.md との照合

#### 【簡潔さの原則】SKILL.md 586 行 — 500 行上限の 17% 超過

skill-best-practice.md は「SKILL.md 本体を最適なパフォーマンスのために **500 行以下に保つ**」と明記している。

```
$ wc -l skills/test/pochi-test-orchestrator/skills/run/SKILL.md
586
```

**技術的影響**:
- SKILL.md 全体が Claude のコンテキストウィンドウに一度にロードされるため、86 行の超過は約 2,000〜2,500 トークンの余剰消費に相当する（1 行≒25〜30 トークン概算）
- Step4 にインライン埋め込みされたサブエージェント向けテンプレート（約 100 行）が主因。このテンプレートは `prompts/generate_test_cases_prompt.md` にほぼ同一の内容が既に存在しており、**重複格納**になっている

**UX 指摘と同一** / 技術的根拠として補足。

---

#### 【フロントマター仕様】非標準フィールドと entrypoint 3 重不整合

skill-best-practice.md のフロントマター仕様:
```yaml
name: <最大64文字、小文字・数字・ハイフンのみ>
description: <最大1024文字、三人称>
```

**現状の SKILL.md フロントマター（抜粋）**:
```yaml
---
skill_id: pochi-test-orchestrator  # ← 非標準フィールド
id: pochi-test-orchestrator         # ← 非標準フィールド
title: Pochi Test Orchestrator      # ← 非標準フィールド
name: Pochi Test Orchestrator       # ← 小文字・ハイフン規則違反（スペース含む）
version: 1.0.0                      # ← 非標準フィールド
entrypoint:                         # ← 非標準フィールド
  type: prompt
  path: prompts/generate_test_cases_prompt.md
triggers: [...]                     # ← 非標準フィールド（skills.json が正式ソース）
---
```

| 問題 | 詳細 | 影響 |
|------|------|------|
| `name` フィールド値 | `"Pochi Test Orchestrator"`（スペース・大文字を含む） | skill-best-practice §命名規則違反。正しくは `"pochi-test-orchestrator"` |
| 非標準フィールド多数 | `skill_id`, `id`, `title`, `version`, `entrypoint`, `triggers` | Claude のフロントマター解析時に余分なトークン消費、将来の仕様変更で混乱 |
| `entrypoint` の 3 重不整合 | フロントマター `type: prompt` / Do 節 `python skill_entry.py` / skills.json `entrypoint_type: "prompt"` | 利用者が起動方法を誤解。実質的なエントリポイントは Python スクリプトであり、skills.json の `entrypoint_type` は `"python"` が正しい |

---

#### 【プログレッシブディスクロージャー】Step4 テンプレートのインライン埋め込み

skill-best-practice.md「パターン1：参照を含む高レベルガイド」では SKILL.md から外部ファイルへのリンクで実装するよう推奨している。

**現状**: `## ステップ4` 内に約 100 行のサブエージェント向けプロンプトテンプレートが直接記述されており、変数プレースホルダー（`{絶対パス}` 等）の手動置換をエージェントに要求している。

**技術的問題**:
1. `prompts/generate_test_cases_prompt.md` との二重管理になっており DRY 原則違反
2. 変数置換は `orchestrator.py` の `prepare_generation_context()` が `generation_context.json` を生成する際に自動化できる設計になっているにもかかわらず、SKILL.md は手動組み立てを指示しており、設計とドキュメントが矛盾している

---

#### 【description フィールド】三人称原則違反

```yaml
description: Pochiアプリのテストケースを4パターンで自動生成・更新する際に使用。
             ユーザーが「Pochiのテストケースを生成」「テストケース更新」「品質チェック」
             などと依頼した時に起動する。
```

skill-best-practice.md: 「**常に三人称で書いてください**。説明はシステムプロンプトに挿入され、視点の不一貫性は発見の問題を引き起こす可能性があります。」

**改善案**:
```yaml
description: >-
  Pochiアプリのテストケースを FullIntegration / FullScenario /
  PartialIntegration / PartialScenario の 4 パターンで自動生成・更新する。
  「Pochiのテストケースを生成して」「テストケース更新」「品質チェック」
  「pochi-test-orchestratorを起動」と言われた場合に使用する。
```

**UX 指摘と同一** / 技術的根拠として補足。

---

### 3-2. everything-claude-code活用事例.md との照合

#### 【活用事例2: サブエージェント委譲】反復的取得パターンの実装不備

ECC 活用事例での推奨:
> 「オーケストレーターがサブエージェントの返答を毎回評価し、不十分なら追加質問を投げる。**ループは最大3回に制限**して無限ループを防ぐ。クエリだけでなく、より広い目的のコンテキストも一緒にサブエージェントに渡すことで、要約の精度が上がる。」

**現状（SKILL.md Step4-3）**:
```markdown
#### 4-3: サブエージェントからの返却確認
- ✅ test_cases.mdが生成されている（絶対パスで確認）
- ✅ 生成件数が目標範囲内（110-140件）
...
```

確認項目の列挙はあるが、**確認失敗時の再試行フローが定義されていない**。品質指標が基準未満の場合は単に確認するだけで終了するため、低品質な出力でも Skill が「完了」と判定される。

---

#### 【活用事例8: 検証ループ】品質ゲートの任意化

ECC「チェックポイント型」検証ループの推奨:
> 「各マイルストーンで検証基準を満たしているか確認し、失敗したら修正してから次に進む」

**現状（SKILL.md Step5 末尾）**:
```markdown
**注**: 品質ゲート(`quality_gate.py`)は実行しません。
品質チェックが必要な場合は、ユーザーが手動で実行してください。
```

技術的に `quality_gate.py` はフル実装されており（品質レポート生成・合否判定・終了コード設定）、自動実行しない理由が設計文書に示されていない。品質ゲートは `generation_context.json` 内の `quality_gate_entry` フィールドに自動記載されており、自動実行は技術的に容易である。

---

#### 【活用事例7: コンテキスト・トークン最適化】PromptBuilder の未活用

ECC では「最安モデルで十分なタスクを委譲」「コンテキスト節約」を推奨している。

`core/prompt_builder.py` には、パターンに応じて最適化されたプロンプトを動的に組み立てる `PromptBuilder.build_optimized_prompt()` が実装されているが、現在の SKILL.md はこの機能を活用せず、エージェントが手動でテンプレートを組み立てることを要求している。

```python
# core/prompt_builder.py - 実装済みだが SKILL.md から呼ばれていない
def build_optimized_prompt(self, pattern: str, context: Dict) -> str:
    """パターンとコンテキストに基づいて最適なプロンプトを構築"""
    ...
```

`skill_entry.py` の Step7（コンテキスト生成フェーズ）で `PromptBuilder` を呼び出し、完成済みプロンプトを `generation_context.json` の `subagent_prompt` フィールドに格納する方式に変更すれば、SKILL.md の Step4 を大幅に簡素化できる。

---

### 3-3. Everything Claude Code を眺める.md との照合

#### 【Slide 12: モデル選択】旧モデル名の使用

ECC の Slide 12「Subagent Architecture」では、テスト・コードレビュー用途は **Sonnet** を推奨している。

**現状（agents/test-case-specialist.md）**:
```yaml
model: claude-3-5-sonnet
```

`claude-3-5-sonnet` は旧モデル名であり、Claude Code 環境では最新の `claude-sonnet-4-5` 等への更新が推奨される。旧モデル名がエラーになるバージョンでは Skill が実行不可になるリスクがある。

---

#### 【Slide 13: Skill 品質評価】pass@k 測定の欠如

ECC Slide 13「Eval パターン」では:
> 「`/fork` で会話を分岐し、Skill あり/なしで同タスク実行して diff 比較。pass@k（k 回中1回成功）と pass^k（k 回全成功・一貫性指標）でスキルの品質を定量化」

**現状**:
```
skills/test/pochi-test-orchestrator/test/  ← 空ディレクトリ
```

`test/` ディレクトリは存在するが空であり、Skill の出力品質を定量的に測定する仕組みがない。全社公開後に Skill の品質劣化（コンテキスト変化によるテストケース件数減少等）を検知できない。

---

## 4. コード品質・アーキテクチャ分析

### 4-1. scripts/ と core/ の二重実装問題 ⚠️ Critical

**最も深刻な技術的課題**として、同名機能が 2 系統のモジュールで実装されている。

| ファイル | scripts/ 系統（旧） | core/ 系統（新） |
|---------|-------------------|----------------|
| オーケストレーター | `scripts/orchestrator.py` | `core/orchestrator.py` |
| 環境チェック | `scripts/precheck.py` | `core/precheck.py` |
| 差分生成 | `scripts/diff_generator.py` | `core/diff.py` |
| 品質ゲート | `scripts/quality_gate.py` | `core/quality_gate.py` |

- `skill_entry.py` は `core/` を import して実行している（`from core import precheck, diff, orchestrator`）
- `scripts/` は `skill_entry.py` から直接 import されておらず、`scripts/skill_smoke_test.sh` が間接的に参照しているのみ
- `scripts/` のコードは `core/` と実装が異なる箇所があり（例: `scripts/precheck.py` は対話プロンプトを持つが `core/precheck.py` は非対話版）、どちらが正とすべきか不明確

**技術的影響**:
1. メンテナンス時の変更漏れ（片方を修正し忘れるリスク）
2. 利用者や将来の開発者が混乱する
3. `scripts/` 内の `except Exception` 多用（20 箇所以上）によるエラー隠蔽リスク
4. `scripts/security.py` の `POCHI_SKILL_DEBUG=1` バイパス（後述）

**推奨**: `scripts/` を archive か削除し、`core/` に一本化する。`skill_smoke_test.sh` は `core/` ベースのテストに置き換える。

---

### 4-2. `input()` 対話呼び出しの残存 ⚠️ Critical

```python
# core/orchestrator.py L69-86
def ask_user_for_pattern(state: SkillState) -> Tuple[str, str]:
    ...
    scope_answer = input("\n選択 (A/B): ").strip().upper()
    while scope_answer not in ["A", "B"]:
        scope_answer = input("選択 (A/B): ").strip().upper()
    ...
    type_answer = input("\n選択 (A/B): ").strip().upper()
    while type_answer not in ["A", "B"]:
        type_answer = input("選択 (A/B): ").strip().upper()
```

この関数は `detect_pattern()` → `ask_user_for_pattern()` の経路で、環境変数 `POCHI_PATTERN_SELECTION` / `POCHI_TEST_TYPE_SELECTION` が設定されていない場合に呼び出される（`core/orchestrator.py` L176）。

**Claude Code 環境での問題**:
- Claude が `subprocess` でスクリプトを実行する場合、`stdin` は `/dev/null` 相当になり `input()` は即座に `EOFError` を送出する
- `skill_entry.py` の `main()` 内に `except EOFError` ハンドリングがなく、予期しない終了コード 1 になる
- UX レビューの「ハングリスク」に加え、**サイレントクラッシュ**のリスクもある

**修正案**: `input()` 呼び出しを完全に排除し、環境変数またはエージェントからの設定のみでパターンを決定する。SKILL.md の Do 節でユーザーに環境変数設定を求める方式が現実的。

---

### 4-3. requirements.txt の不在 ⚠️ Major

```
skills/test/pochi-test-orchestrator/
├── skill_entry.py          # Python エントリポイント
├── core/                   # Python モジュール群
│   ├── state.py            # pathlib, logging, json, shutil 等
│   ├── diff.py             # subprocess 等
│   ├── orchestrator.py     # subprocess, json 等
│   └── quality_gate.py     # re, json, collections 等
└── （requirements.txt なし）  ← 不在
```

`skill_entry.py` は entrypoint_type が `"python"` として機能するため、依存ライブラリの明示が必要。現在の実装は標準ライブラリのみを使用しているが（`pathlib`, `subprocess`, `re`, `json` 等）、以下の理由で `requirements.txt`（または `pyproject.toml`）の作成が推奨される:

1. 全社配布後に第三者が Python 依存を追加した場合、インストール手順が不明確になる
2. `docs/INSTALLATION.md` に Python バージョン要件（3.8+）の記載はあるが、依存管理の標準的な方法がない
3. Skill の CI/CD 自動テスト（将来実装時）で環境構築が困難になる

---

### 4-4. test/ ディレクトリが空 ⚠️ Major

```
skills/test/pochi-test-orchestrator/test/  ← 完全に空
```

`scripts/skill_smoke_test.sh` は存在するが、これは Claude Code 環境外での手動実行用シェルスクリプトであり、自動化されたユニットテスト・統合テストは存在しない。

**ECC の Eval パターン（Slide 13）との乖離**:
- `pass@k` / `pass^k` 測定なし
- 期待出力との比較テスト（回帰テスト）なし
- `skill_smoke_test.sh` 自体もファイル配置確認のみで機能検証がない

**最低限必要なテスト**:
1. `skill_entry.py` の環境チェック通過確認（`--dry-run` モード等）
2. `orchestrator.detect_pattern()` のパターン判定ロジックユニットテスト
3. `quality_gate.py` の合否判定ロジックユニットテスト

---

### 4-5. docs/ の 6 ファイル分散とメンテナンス負荷 ⚠️ Minor

```
docs/
├── ADVANCED.md
├── INSTALLATION.md
├── OPERATIONS_RUNBOOK.md
├── QUICKSTART.md
├── UPSTREAM_FIX_README.md
└── VERIFICATION_GUIDE.md
```

skill-best-practice.md「プログレッシブディスクロージャーパターン」では、SKILL.md から 1 レベル深い参照で整理することを推奨している。6 ファイルのうち `README.md`（スキルルート）はユーザーが最初に参照するが、`docs/` 配下のファイルは SKILL.md のどのステップからもリンクされていない。特に `UPSTREAM_FIX_README.md` は暫定対処のドキュメントとして陳腐化リスクが高い。

---

### 4-6. バージョン番号の 3 重不整合 ⚠️ Major

| 出所 | バージョン値 |
|------|------------|
| `skills/run/SKILL.md` フロントマター `version:` | `1.0.0` |
| `plugin.json` | `1.0.0` |
| SKILL.md 内 `## バージョン・ライセンス` セクション | `3.0.0` |

SKILL.md 本文の `## バージョン・ライセンス` セクションには `3.0.0` が記載されており、フロントマターおよび `plugin.json` の `1.0.0` と一致していない。UXレビューが指摘した「SKILL.md `3.0.0` / plugin.json `1.0.0`」の不整合が本体テキストに残存している。

**ルール**: Pochi CLAUDE.md ガイドラインにより、バージョンは `plugin.json` で一元管理し SKILL.md 本文には記載しない。

---

## 5. セキュリティ評価

### 5-1. 強みとして評価できる実装

| 項目 | 評価 | 根拠 |
|------|------|------|
| subprocess の shell=False | ✅ 安全 | `core/diff.py`, `core/orchestrator.py` で `shell=False`（デフォルト）が確認済み |
| Git リファレンスの入力検証 | ✅ 実装済み | `scripts/security.py:validate_git_ref()` が正規表現で危険パターンを拒否 |
| パストラバーサル対策 | ✅ 実装済み | `scripts/security.py:validate_path_in_artifacts()` が artifact ルート外アクセスを拒否 |
| コマンド引数サニタイズ | ✅ 実装済み | `scripts/security.py:sanitize_command_args()` が危険文字を検出 |
| タイムアウト設定 | ✅ 実装済み | `app_structure_analyzer.py` 実行に 300 秒タイムアウト設定 |
| 環境変数ガード | ✅ 実装済み | `POCHI_SKILL_ACTIVE=1` による誤実行防止 |
| サブエージェントの tools 制限 | ✅ 最小権限 | `test-case-specialist.md` が `Read/Write/Glob/Grep` のみに制限 |

---

### 5-2. セキュリティ懸念事項

#### デバッグバイパスの本番混入リスク（Minor）

```python
# scripts/security.py L31-33
if os.environ.get("POCHI_SKILL_DEBUG") == "1":
    logger.warning("⚠️  デバッグモード: Skills専用チェックをバイパスしました")
    return
```

`POCHI_SKILL_DEBUG=1` により `POCHI_SKILL_ACTIVE` チェックを完全バイパスできる。開発環境での便宜のための実装だが、本番利用者が誤って設定した場合にセキュリティガードが無効化される。ドキュメント（README 等）にこの変数の存在が明示されていないため、意図しない利用を防ぐ注記が必要。

#### オーケストレーター側の allowedTools 未定義（Minor）

`test-case-specialist.md` にはサブエージェントの tools 制限が適切に定義されているが、親 Claude エージェント（オーケストレーター）側の `allowedTools` 制限は SKILL.md に定義されていない。ECC の AgentShield の考え方（Slide 21）では、オーケストレーター側にも必要最小限の tool 制限を設けることを推奨している。

#### except Exception の広域ハンドリング（Minor）

`scripts/` 系統のコードで `except Exception as e:` が 20 箇所以上確認される。エラーを握り潰してサイレントに次処理に進むケースがあり（例: `pass` で終了するブロック）、実行失敗の原因が特定困難になるリスクがある。`core/` 系統は比較的適切にエラーを再 raise またはログ記録しているため、`core/` への一本化により改善される。

---

## 6. 重大度別 課題一覧（技術審査）

### 🔴 Critical（全社公開前の必須対応）

| ID | 課題 | 技術的根拠 | 影響 |
|----|------|----------|------|
| **TC-2** | SKILL.md 586 行（500 行上限超過） | skill-best-practice §簡潔さ | コンテキスト ~2,500 トークン余剰消費 |
| **TC-3** | `core/orchestrator.py` に `input()` 4 箇所残存 | subprocess 非対話実行 | EOFError でサイレントクラッシュ / ハング |
| **TC-4** | entrypoint 3 重不整合（フロントマター/Do 節/skills.json） | skill-best-practice §スキル構造 | 起動タイプの誤解、トラブルシュート困難 |
| **TC-5** | scripts/ と core/ の二重実装 | ソフトウェア設計原則（DRY）| メンテ時の変更漏れ、エラー隠蔽リスク |

### 🟡 Major（全社公開前の強く推奨する対応）

| ID | 課題 | 技術的根拠 | 影響 |
|----|------|----------|------|
| **TM-1** | requirements.txt / pyproject.toml 不在 | Python パッケージングベストプラクティス | 依存環境の再現性なし |
| **TM-2** | test/ ディレクトリが空（自動テスト不在） | ECC Slide13 §Eval パターン | 回帰品質劣化を検知できない |
| **TM-3** | SKILL.md 本文 `## バージョン・ライセンス` 内 `3.0.0` がフロントマター / plugin.json `1.0.0` と不整合 | Pochi CLAUDE.md §plugin.json ルール | バージョン管理の混乱 |
| **TM-4** | description 三人称違反（UX 指摘の技術的裏付け） | skill-best-practice §効果的な説明 | Skill 発見精度の低下 |
| **TM-5** | PromptBuilder が SKILL.md フロー未活用 | ECC 活用事例7 §トークン最適化 | Step4 のテンプレート手動組み立てリスク |
| **TM-6** | 品質ゲート（quality_gate.py）の任意実行（UX 指摘の技術的裏付け） | ECC 活用事例8 §検証ループ | 低品質テストケースの無検証承認 |

### 🟢 Minor（公開後対応可）

| ID | 課題 | 技術的根拠 | 影響 |
|----|------|----------|------|
| **Tm-1** | `model: claude-3-5-sonnet` が旧モデル名 | ECC Slide12 §モデル選択 | 最新モデルで最適性能が得られない |
| **Tm-2** | `POCHI_SKILL_DEBUG=1` バイパスのドキュメント不備 | OWASP §セキュリティ設定の文書化 | 誤用によるガード無効化 |
| **Tm-3** | `except Exception` 広域ハンドリング 20 箇所（scripts/ 系統） | Python ベストプラクティス | エラーサイレント化 |
| **Tm-4** | docs/ 6 ファイルのメンテナンス負荷（SKILL.md からリンクなし） | skill-best-practice §プログレッシブディスクロージャー | 情報断片化・陳腐化 |
| **Tm-5** | SKILL.md フロントマター内の非標準フィールド（skill_id, id, title 等） | skill-best-practice §スキル構造 | 余分なトークン消費 |

---

## 7. アーキテクチャ評価

### 7-1. 強みとして評価できる設計

| 設計要素 | 評価 | ECC 対応 |
|---------|------|---------|
| サブエージェント分離（test-case-specialist） | ✅ 優良 | ECC Tier1 サブエージェントパターン準拠 |
| 厳格サマリ返却（80-100K→3-5K tokens 圧縮） | ✅ 優良 | ECC 活用事例2 コンテキスト削減設計 |
| SkillState による一元的パス管理 | ✅ 優良 | 絶対パス使用・ロガー重複対策済み |
| security.py による入力検証 | ✅ 優良 | OWASP §インジェクション対策 |
| run_id による実行履歴管理 | ✅ 良好 | 運用トレーサビリティ確保 |
| 4 パターン体系（Full/Partial × Integration/Scenario） | ✅ 良好 | 直交した分類で利用者に理解しやすい |
| 自動バックアップ（.bak ファイル生成） | ✅ 良好 | データ安全性 |
| 環境変数によるパターン指定（CI/CD 対応） | ✅ 良好 | 自動化パイプライン統合可能 |

### 7-2. アーキテクチャ上の改善提案

```
現状（問題点あり）:
  SKILL.md
    └─ Do: python skill_entry.py（core/ ベース）
    └─ scripts/（旧実装 - 未使用?）

理想（一本化後）:
  SKILL.md
    └─ Do: generation_context.json の subagent_prompt を使用
    └─ core/（唯一の実装）
        ├─ skill_entry.py
        ├─ state.py
        ├─ precheck.py
        ├─ diff.py
        ├─ orchestrator.py（PromptBuilder 活用）
        └─ quality_gate.py（Step5 で自動実行）
  tests/（最低限のスモークテスト）
```

---

## 8. 全社公開前 必須対応ロードマップ（技術版）

### Phase 1: Go 条件クリア（Critical 対応）

| 優先度 | 課題 ID | 具体的な対応内容 | 推定工数 |
|--------|---------|-----------------|---------|
| P0 | TC-3 | `core/orchestrator.py` `ask_user_for_pattern()` の `input()` を環境変数読み取りに置き換え | 小（~1h） |
| P0 | TC-4 | `skills.json` `entrypoint_type` を `"python"` に変更、SKILL.md フロントマターの `entrypoint` を削除または整合 | 小（~30min） |
| P0 | TC-5 | `scripts/` を `archive/` に移動または削除し `core/` に一本化 | 中（~2h、動作確認含む） |

### Phase 2: 品質向上（Major 対応、全社公開前推奨）

| 優先度 | 課題 ID | 具体的な対応内容 |
|--------|---------|-----------------|
| P1 | TC-2 | SKILL.md を 500 行以内に圧縮（Step4 テンプレートを外部ファイルへ移動） |
| P1 | TM-6 | `quality_gate.py` を Step5 で自動実行し、終了コード 1 時にエラー通知 |
| P1 | TM-3 | SKILL.md 本文の `version: 3.0.0` を削除し `plugin.json` に一元化 |
| P1 | TM-4 | `description` を三人称・トリガーフレーズ含む形式に改訂 |
| P2 | TM-1 | `requirements.txt` を作成（現在は標準ライブラリのみのため最小構成で可） |
| P2 | TM-2 | `test/` に最低限のスモークテスト（`test_skill_entry.py`）を追加 |
| P2 | TM-5 | `PromptBuilder` を `orchestrator.prepare_generation_context()` 内で活用し、完成済み `subagent_prompt` を `generation_context.json` に格納 |

### Phase 3: 継続改善（Minor・公開後可）

| 課題 ID | 具体的な対応内容 |
|---------|-----------------|
| Tm-1 | `agents/test-case-specialist.md` の `model` を最新モデル名に更新 |
| Tm-2 | `POCHI_SKILL_DEBUG=1` の用途と注意事項を `docs/ADVANCED.md` に追記 |
| Tm-3 | `scripts/` 廃止後は不要。`core/` の `except Exception` を適切な例外型に絞る |
| Tm-4 | `docs/` 各ファイルを SKILL.md の適切なステップからリンクするか、README.md に集約 |
| Tm-5 | SKILL.md フロントマターから非標準フィールドを削除 |

---

## 9. UX レビューとの対応関係

既存 UX レビュー（`UX_REVIEW_REPORT_pochi-test-orchestrator_ux-designer_20260427.md`）の指摘と本技術レビューの対応関係を以下に示す。

| UX 課題 ID | UX 指摘内容 | 本技術レビューでの確認 |
|-----------|-----------|---------------------|
| C-1 | SKILL.md 586 行超過 | ✅ TC-2 で確認・技術的根拠補足 |
| C-3 | `input()` ハングリスク | ✅ TC-3 で確認・EOFError リスクを追記 |
| C-4 | 品質ゲートが任意実行 | ✅ TM-6 で確認・技術的裏付け補足 |
| C-5 | entrypoint 3 重不整合 | ✅ TC-4 で確認・技術的根拠補足 |
| M-1 | description 三人称違反 | ✅ TM-4 で確認 |
| M-2 | Step4 インライン埋め込み | ✅ TM-5 で PromptBuilder 未活用として技術深掘り |
| M-4 | バージョン不整合 | ✅ TM-3 で確認 |

**本技術レビューで新規発見した課題**（UX レビュー未指摘）:
- TC-5: scripts/ と core/ の二重実装
- TM-1: requirements.txt 不在
- TM-2: test/ 空（自動テスト不在）
- TM-5: PromptBuilder 未活用
- Tm-2: デバッグバイパスのドキュメント不備
- Tm-3: except Exception 広域ハンドリング

---

## 10. 結論

`pochi-test-orchestrator` は以下の技術的強みを持つ：

- **security.py** による適切な入力検証・パス検証実装（OWASP 準拠）
- **subprocess shell=False** による安全なシェル実行
- **SkillState** による絶対パス一元管理と実行履歴保全
- **サブエージェント分離アーキテクチャ**と厳格サマリ返却によるコンテキスト最適化設計

しかし、以下の **Critical 課題4件** が全社公開の技術的 Go 条件を満たさない：

1. SKILL.md 586 行（500 行上限の 17% 超過）
2. `core/orchestrator.py` に `input()` 4 箇所（EOFError / ハングリスク）
3. entrypoint 3 重不整合（実態は Python スクリプト型なのに SKILL.md と skills.json が `prompt` 型を宣言）
4. `scripts/` と `core/` の二重実装（メンテナンス上の技術的負債）

これらを解消した後、本 Skill は Pochi 開発チームの生産性向上に大きく貢献できる全社公開可能な品質水準に到達できると判断する。

---

*本レポートは 2026-04-27 時点のコード状態に基づいて作成されました。*  
*参照: UXレビューレポート [UX_REVIEW_REPORT_pochi-test-orchestrator_ux-designer_20260427.md](UX_REVIEW_REPORT_pochi-test-orchestrator_ux-designer_20260427.md)*
