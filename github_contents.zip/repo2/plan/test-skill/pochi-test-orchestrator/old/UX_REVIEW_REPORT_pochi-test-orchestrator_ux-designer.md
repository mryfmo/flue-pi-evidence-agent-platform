# UXレビューレポート: pochi-test-orchestrator 全社公開審査

**作成日**: 2026-04-27  
**レビュアー**: UXデザイナー（GitHub Copilot）  
**対象Skill**: `skills/test/pochi-test-orchestrator/`  
**レビュー目的**: 全社公開可否の判定  
**参照ドキュメント**:
- `claude-code-guide/official/skill-best-practice.md`（Anthropic公式ベストプラクティス）
- `claude-code-guide/guides/everything-claude-code活用事例.md`（ECC実践ガイド）
- `claude-code-guide/guides/Everything Claude Code を眺める.md`（ECCアーキテクチャ概観）

---

## 1. エグゼクティブサマリ

`pochi-test-orchestrator` は、Pochiアプリのテストケースを4パターンで自動生成する意欲的なSkillです。アーキテクチャ（オーケストレーター＋専門サブエージェント）は ECC のベストプラクティスに沿っており、機能的な価値は高いと評価します。

**全社公開可否判定: ❌ 条件付き保留（No-Go）**

以下の理由から、現状では全社公開には適していません：

| 判定基準 | 現状 | 必要条件 |
|---------|------|---------|
| SKILL.md 行数 | **586行** | 500行以下 |
| input() による対話 | 未解決（ハングリスク） | 安定動作保証 |
| バージョン整合性 | SKILL.md `3.0.0` / plugin.json `1.0.0` | 一元管理 |
| description 品質 | 三人称未遵守 | 三人称・具体的 |

---

## 2. 総合評価スコアカード

| 評価軸 | スコア | 前回比 | 判定 |
|--------|--------|--------|------|
| トリガー発見性 | ★★★☆☆ | ↑ (+1) | 改善余地あり |
| SKILL.md の簡潔性 | ★★☆☆☆ | → (0) | 要改善 |
| 実行フロー明確性 | ★★☆☆☆ | ↑ (+1) | 要改善 |
| エラーリカバリ体験 | ★★★☆☆ | → (0) | 改善余地あり |
| サブエージェント設計 | ★★★★☆ | - (新規) | 良好 |
| セキュリティ設計 | ★★★☆☆ | - (新規) | 改善余地あり |
| ドキュメント整合性 | ★★★☆☆ | ↑ (+1) | 改善余地あり |
| **総合** | **★★★☆☆** | ↑ (+0.5) | **条件付き保留** |

---

## 3. 参照ドキュメントとの照合分析

### 3-1. skill-best-practice.md との照合

#### 【簡潔さの原則】SKILL.md が 586行 で 500行上限を超過

skill-best-practice.md は明確に「SKILL.md 本体を最適なパフォーマンスのために **500行以下に保つ**」と規定しています。

| 指標 | 現状 | 推奨値 | 乖離 |
|------|------|--------|------|
| SKILL.md 総行数 | **586行** | 500行以下 | **+86行超過** |
| Step4 テンプレート行数 | 約100行 | 外部ファイル化 | 外部化必須 |
| フロントマタートリガー | 8件 | 代表的なもの | 概ね適切 |

**ベストプラクティスの言及**:
> 「この制限に近づいたときにコンテンツを別のファイルに分割する」
> 「プログレッシブディスクロージャーパターン」を活用すること

Step4（サブエージェント呼び出し指示：約100行）は外部ファイルへの参照リンクに置き換えるべきです。

---

#### 【description フィールドの品質】三人称原則に非準拠

skill-best-practice.md は description は「**常に三人称で書いてください**」と規定しています。

**現状の description**（SKILL.md フロントマター）:
```yaml
description: Pochiアプリのテストケースを4パターンで自動生成・更新する際に使用。
             ユーザーが「Pochiのテストケースを生成」「テストケース更新」「品質チェック」
             などと依頼した時に起動する。
```

**問題点**:
- 「使用」「起動する」という記述は、何をするかでなく「いつ起動するか」の説明になっている
- 「〜する際に使用」は three-person視点に欠ける
- 「依頼した時に起動する」はシステム的な動作の説明であり、Skillが「提供する価値」の説明になっていない

**ベストプラクティス準拠の改善例**:
```yaml
description: >-
  Pochiアプリのテストケースを4パターン（FullIntegration / FullScenario /
  PartialIntegration / PartialScenario）で自動生成・更新する。
  「Pochiのテストケースを生成して」「テストケース更新」「品質チェック」
  「pochi-test-orchestratorを起動」と言われた場合に使用する。
```

---

#### 【プログレッシブディスクロージャー】Step4 テンプレートの外部化が未実施

skill-best-practice.md のパターン1・2を参照すると、SKILL.md は「高レベルガイド」として機能し、詳細は別ファイルへのリンクで参照させる構造が推奨されています。

**現状**: Step4（約100行）のサブエージェント向けプロンプトテンプレートが SKILL.md にハードコードされている。

```markdown
# 現状（SKILL.md Step4: 約100行のインラインテンプレート）
@test-case-specialist

以下のタスクを実行してください：
## タスク概要
...（延々と続くテンプレート）
```

**推奨構造（ベストプラクティス準拠）**:
```markdown
# SKILL.md Step4（改善案: リンク参照に置き換え）
サブエージェント呼び出しプロンプトは自動生成されます：
- 呼び出しテンプレート: [prompts/subagent-call-template.md](prompts/subagent-call-template.md)
- generation_context.json の `subagent_prompt` フィールドを使用
```

---

#### 【参照深度】許容範囲内（問題なし）

skill-best-practice.md は「SKILL.md から1レベル深い参照を保つ」と規定。SKILL.md から参照されている外部ファイル群は直接参照であり、この点は準拠しています。

---

#### 【フロントマター非標準フィールド】entrypoint フィールドの問題

SKILL.md フロントマターに `entrypoint` フィールドが記述されていますが、skills.json の定義と実際の Do 節の指示との間に **3重の不整合**が存在します。

| 出所 | 定義内容 |
|------|---------|
| SKILL.md フロントマター | `type: prompt`, `path: prompts/generate_test_cases_prompt.md` |
| Do 節の実行指示 | `python skills/test/pochi-test-orchestrator/skill_entry.py` |
| CLAUDE.md ガイドライン | `entrypoint_type: "python"` または `"prompt"` |

フロントマターが `prompt` 型を宣言しているにもかかわらず、Do 節が Python スクリプト実行を求めているため、利用者が混乱します。`skill_entry.py` が主たる起動手段であれば、skills.json の `entrypoint_type: "python"` への変更が必要です。

---

### 3-2. everything-claude-code活用事例.md との照合

#### 【サブエージェント設計：良好点】反復的取得パターンの部分採用

ECC の「反復的取得パターン」では：
> 「オーケストレーターがサブエージェントの返答を毎回評価し、不十分なら追加質問を投げる。ループは最大3回に制限」

**現状の設計**:  
- ✅ サブエージェント分離（test-case-specialist）が実装されている  
- ✅ 「厳格サマリ返却」で80-100K tokens → 3-5K tokens に圧縮するコンセプトは正しい  
- ❌ **不十分な場合の再問い合わせループが未定義**  
- ❌ Step4-3 で確認のみ（「✅確認してください」）であり、不合格時の再試行フローがない

**改善案**:  
Step4-3 の後に、品質指標が基準未満の場合は test-case-specialist を再起動するフィードバックループを追加する。

---

#### 【コンテキスト・トークン最適化】手動テンプレート組み立ての問題

ECC 活用事例7「コンテキストとトークンの最適化」では、コンテキスト消費の最小化を強調しています。

**現状の問題**:  
Step4 の指示により、Claude エージェントは 100 行超のテンプレートを **手動でコピー＆カスタマイズ** するよう求められています。これは：
- コンテキストウィンドウの無駄な消費（テンプレート内容 + 生成後のコンテンツが2重化）
- テンプレート組み立て失敗リスク（変数の置き換え漏れ）
- 「問い返し禁止」制約と矛盾（失敗時の自律回復が困難）

**ECC推奨のアプローチ**:  
`generation_context.json` 生成時点で、`subagent_prompt` フィールドにサブエージェント向け完成済みプロンプトを格納する。Claude エージェントはそのまま渡すだけにする。

---

#### 【検証ループ】品質ゲートの任意化が ECC の原則に反する

ECC 活用事例8「検証ループと評価」では：
> 「チェックポイント型：各マイルストーンで検証基準を満たしているか確認し、失敗したら修正してから次に進む」

**現状（Step5）**:
```markdown
品質ゲート（quality_gate.py）は実行しません。
品質チェックが必要な場合は、ユーザーが手動で実行してください。
```

これは ECC のチェックポイント型検証ループと真逆の設計です。品質ゲートを任意にする理由が不明であり、全社公開後に低品質なテストケースが生成されたまま承認される懸念があります。

**改善案（最低要件）**:  
品質ゲートを Step5 で自動実行し、「終了コード1（不合格）の場合にエラーをユーザーに通知する」フローに変更する。

---

#### 【モデル選択の明示】サブエージェントのモデル指定

ECC 活用事例7「モデル使い分け」では、テスト・コードレビューには **Sonnet** を推奨しています。

`agents/test-case-specialist.md` の `model: claude-3-5-sonnet` という指定は方向性として正しいですが、以下の問題があります：
- `claude-3-5-sonnet` は旧バージョン名であり、現在は `claude-sonnet-4-5` 等の最新モデル名に更新が必要
- SKILL.md 本文にモデル選択の理由・推奨が記載されておらず、利用者がカスタマイズ時に判断できない

---

### 3-3. Everything Claude Code を眺める.md との照合

#### 【セキュリティ設計】AgentShield の考慮不足

ECCのセキュリティガイド（Slide 21-22）では：
> 「許可するToolを最小限に絞る（allowedTools の設定）」  
> 「ファイルシステムへのアクセス範囲の制限」  
> 「External Reference読み込み時のセキュリティガードレールの強制挿入」

**現状の security 節**:
```markdown
## 安全対策
- 環境変数チェック: POCHI_SKILL_ACTIVE=1 が必須
- 直接実行の防止: セキュリティリスク低減
```

`POCHI_SKILL_ACTIVE=1` ガードのみでは不十分です。`test-case-specialist.md` の `tools` 定義に `Read`, `Write`, `Glob`, `Grep` のみが許可されており（適切）、一方でオーケストレーター側（メインの Claude エージェント）の `allowedTools` 制限が定義されていません。

---

#### 【Eval パターン（Slide 13）】Skill 自体の品質測定が欠如

ECC の評価アプローチでは「`/fork` で会話を分岐し、Skill あり/なしで同タスク実行して diff 比較」を推奨しています。また `pass@k` / `pass^k` メトリクスによる一貫性の測定が示されています。

**現状**:  
`test/test-input/` に入力データのみが存在し、期待出力との比較テスト（回帰テスト）がありません。Skill の出力品質を定量的に測定する仕組みがないまま全社公開されるリスクがあります。

---

---

## 4. 重大度別 課題一覧（2026-04-27 時点）

### 🔴 Critical（全社公開前の必須対応）

| ID | 課題 | 参照 | 影響 |
|----|------|------|------|
| **C-1** | SKILL.md 586行で500行上限超過 | skill-best-practice §簡潔さ | コンテキスト過消費、認知負荷増大 |
| **C-3** | `input()` による対話ハングリスク（既存C-3: 未解決） | skill-best-practice §低い自由度 | Claude Code環境で実行ブロック |
| **C-4** | 品質ゲートが任意実行のみで自動検証なし | ECC 活用事例8 §検証ループ | 低品質テストケースが無検証で出力 |
| **C-5** | entrypoint フィールドの3重不整合（フロントマター vs Do節 vs skills.json） | Pochi CLAUDE.md §skills.jsonスキーマ | Skill 起動タイプの誤解 |

### 🟡 Major（全社公開前の強く推奨する対応）

| ID | 課題 | 参照 | 影響 |
|----|------|------|------|
| **M-1** | description が三人称未遵守 | skill-best-practice §効果的な説明 | Skill 発見精度の低下 |
| **M-2** | Step4 テンプレートのインラインハードコード（100行超） | skill-best-practice §プログレッシブディスクロージャー | コンテキスト消費、組み立て失敗リスク |
| **M-3** | サブエージェント再試行ループが未定義 | ECC 活用事例2 §反復的取得パターン | 生成失敗時のリカバリ不可 |
| **M-4** | バージョン不整合（SKILL.md `3.0.0` / plugin.json `1.0.0`） | plugin.json §version ルール | 管理混乱、利用者への誤情報 |

### 🟢 Minor（公開後対応可）

| ID | 課題 | 参照 | 影響 |
|----|------|------|------|
| **m-1** | model 指定が旧モデル名 `claude-3-5-sonnet` | ECC 活用事例7 §モデル使い分け | 最新モデルでの最適性能を得られない |
| **m-2** | Skill自体の回帰テスト（期待出力比較）が不在 | ECC Slide13 §Eval パターン | 品質劣化を検知できない |
| **m-3** | トリガー重複（フロントマター + `## Trigger Phrases` セクション） | skill-best-practice §簡潔さ | 不要なコンテキスト消費 |
| **m-4** | allowedTools がオーケストレーター側に未定義 | ECC Slide22 §AgentShield | セキュリティ保証の弱さ |
| **m-5** | docs/ に 6 ファイル分散（README・QUICKSTART・INSTALLATION等）の陳腐化リスク | skill-best-practice §プログレッシブディスクロージャー | 情報断片化・メンテ負荷 |

---

## 5. ユーザージャーニー分析（現状 vs 理想）

### 5-1. 現状のユーザージャーニー（全社公開ユーザー視点）

```
【新規ユーザー】 「Pochiのテストケースを生成して」
    │
    ├─ 1. SKILL.md 読み込み（586行）
    │        └─ 🔴 コンテキスト大量消費。Step4到達前に情報過多
    │
    ├─ 2. Do節のコマンド実行
    │        └─ skill_entry.py 起動
    │            ├─ 環境変数未設定の場合: input() でユーザーに質問
    │            │     └─ 🔴 Claude Code環境でハングの可能性
    │            └─ 環境変数設定済みの場合: スキップ（理想フロー）
    │
    ├─ 3. generation_context.json 読み込み（Step2）
    │
    ├─ 4. reference_files[] を順次読み込み（Step3）
    │        └─ 🟡 ファイル数が多い（5〜8ファイル）
    │
    ├─ 5. Step4: サブエージェント呼び出しテンプレートを手動組み立て
    │        └─ 🔴 100行超のテンプレートを変数置換しながら組み立て
    │              └─ 変数の置き換え漏れリスク大
    │
    ├─ 6. test-case-specialist が test_cases.md 生成
    │        └─ 不合格でも検証なし（Step5で品質ゲートスキップ）
    │              └─ 🔴 低品質テストケースが無検証で完了
    │
    └─ 7. 完了（品質保証なし）
```

### 5-2. 全社公開に向けた理想のユーザージャーニー

```
【新規ユーザー】 「Pochiのテストケースを生成して」
    │
    ├─ 1. SKILL.md 読み込み（500行以内）
    │
    ├─ 2. Claude エージェントがユーザーにパターン選択を質問
    │        (skill_entry.py 実行前のインタラクション)
    │
    ├─ 3. skill_entry.py 実行
    │        └─ generation_context.json に完成済みサブエージェントプロンプトも格納
    │
    ├─ 4. generation_context.json 読み込み（完成済みプロンプト含む）
    │
    ├─ 5. test-case-specialist を Agentツールで呼び出し（プロンプト自動使用）
    │        └─ 不十分な場合は最大3回再試行（反復的取得パターン）
    │
    ├─ 6. 品質ゲート自動実行
    │        ├─ 合格: 完了
    │        └─ 不合格: エラーメッセージとともに改善箇所を通知
    │
    └─ 7. 完了（品質保証済み）
```

---

## 6. 全社公開前 必須対応ロードマップ

### Phase 1: 公開ブロック解除（必須・推定工数: 中）

| 優先度 | 課題ID | 対応内容 | 推定効果 |
|--------|--------|----------|----------|
| P0 | **C-3** | `input()` → 環境変数プライマリ化（エージェント側事前質問方式へ変更） | 実行ブロック解消 |
| P0 | **C-4** | `quality_gate.py` を Step5 で自動実行（終了コード1の場合はエラー通知） | 品質保証の実装 |
| P0 | **C-5** | SKILL.md フロントマターの `entrypoint` を `skills.json` の定義に統一 | 起動タイプ不整合解消 |

### Phase 2: SKILL.md リファクタリング（必須・推定工数: 大）

| 優先度 | 課題ID | 対応内容 | 推定効果 |
|--------|--------|----------|----------|
| P1 | **C-1** | SKILL.md を 500 行以内に圧縮（Step4 テンプレートを外部ファイル化） | コンテキスト消費約15%削減 |
| P1 | **M-1** | `description` を三人称・具体的トリガーフレーズ含む形式に改訂 | Skill発見精度向上 |
| P1 | **M-2** | `generation_context.json` 生成時に `subagent_prompt` を自動格納し Step4 を簡素化 | テンプレート組み立て失敗ゼロ化 |
| P1 | **M-4** | バージョンを `plugin.json` で一元管理（SKILL.md `3.0.0` → `plugin.json` の値に揃える） | 管理一元化 |

### Phase 3: 品質向上（推奨・公開後も可）

| 優先度 | 課題ID | 対応内容 | 推定効果 |
|--------|--------|----------|----------|
| P2 | **M-3** | 反復的取得パターン（最大3回再試行ループ）の実装 | サブエージェント失敗時のリカバリ |
| P3 | **m-1** | `model` を `claude-3-5-sonnet` → 最新モデル名に更新 | 最新モデル性能の活用 |
| P3 | **m-2** | 期待出力ベースの回帰テストを `test/` に追加 | Skill品質劣化の早期検知 |
| P3 | **m-3** | フロントマタートリガーと `## Trigger Phrases` セクションの重複を削除 | 不要コンテキスト削減 |
| P3 | **m-4** | オーケストレーター側の `allowedTools` 定義 | セキュリティ強化 |

---

## 7. 良好点（全社公開に向けた強み）

前回レビュー（2026-04-20）以降の対応で改善された点と、現在の設計上の強みを挙げます。

### ✅ 対応済みの改善点（2026-04-24 対応）
- `skills.json` と SKILL.md フロントマター triggers の同期
- パス不整合の修正（絶対パス → 相対パス）
- Windows固有コマンドの削除

### ✅ 設計上の強み
- **サブエージェント分離アーキテクチャ**: `test-case-specialist` を独立エージェントとして定義し、オーケストレーターと明確に役割分担している。ECC の Tier 1 サブエージェントパターンを正しく実装している
- **コンテキスト圧縮の意図**: 「厳格サマリ返却」（80-100K tokens → 3-5K tokens）の設計思想は ECC の反復的取得パターンと方向性が一致している
- **4パターン体系**: Full/Partial × Integration/Scenario の直交した分類体系は利用者にとって理解しやすい
- **自動バックアップ**: 既存 `test_cases.md` の `.bak` バックアップは安全なデータ更新の観点から優れている
- **環境変数によるパターン指定**: CI/CD パイプラインでの自動化対応が可能な設計
- **ログ出力**: `test-orchestrator/logs/skill_run_{run_id}.log` による実行履歴の保存

---

## 8. 全社公開向け チェックリスト

全社公開の最終確認として、以下のチェックリストを使用してください：

### 必須（Go/No-Go 判定）
- [ ] `input()` ハング問題が解消されている（または環境変数が常にセットされる仕組みがある）
- [ ] 品質ゲートが自動実行されるフローになっている
- [ ] SKILL.md の entrypoint 定義が `skills.json` と一致している
- [ ] SKILL.md が 500 行以下になっている
- [ ] `description` が三人称で記述されている
- [ ] バージョン番号が一元管理されている

### 推奨（品質向上）
- [ ] Step4 のテンプレートが外部ファイル化されている
- [ ] サブエージェント再試行ループが実装されている
- [ ] モデル名が最新バージョンに更新されている
- [ ] 期待出力ベースの回帰テストが追加されている

---

## 9. 結論

`pochi-test-orchestrator` は、ECC のサブエージェント分離パターンを採用した先進的な設計を持ち、Pochi アプリ開発者にとって高い価値をもたらすポテンシャルがあります。

**ただし、全社公開のためには以下4点が必須条件です：**

1. `input()` ハング問題の解消
2. 品質ゲートの自動実行化
3. entrypoint 定義の一元化
4. SKILL.md の 500 行以内への圧縮

これらを対応した後、`pochi-test-orchestrator` は Pochi 開発チームの生産性を大幅に向上させる全社公開可能な Skill として認定できると判断します。

---

*本レポートは 2026-04-27 時点の Skill 状態に基づいて作成されました。*  
*前回レビュー: UX_REVIEW_REPORT_pochi-test-orchestrator.md（2026-04-20作成、2026-04-24対応実施）— 本レポートに統合済み*

---

## 付録A: 課題別 詳細対応案（前回レビュー由来）

### C-1: SKILL.mdの肥大化 → コア指示200行化

#### 対象ファイル
- `skills/run/SKILL.md`

#### 具体的な作業手順

**Step 1: フロントマターのtriggers削減**

現在50個超のトリガーを、以下の代表10個に絞る：

```yaml
triggers:
  - Pochiのテストケースを生成して
  - テストケースを生成して
  - テストケース生成
  - テストケース更新
  - pochi-test-orchestrator を起動
  - 品質チェック
  - パターン1
  - パターン3
  - pochilibアップデート対応のテストケース生成
  - generate test cases
```

削除するトリガーの基準：
- 英語トリガーは代表1個のみ残す（`generate test cases`）
- 「パターン2」「パターン4」は「パターン1」「パターン3」に代表させる
- 「〜を起動」「〜起動」の重複は1個に統合
- `Pattern1`〜`Pattern4`（英語表記）は削除

**Step 2: Step4のサブエージェントテンプレートを外部化**

現在SKILL.md内にインラインで記載されている100行超のテンプレートを以下に分離：

```
prompts/subagent_call_template.md   ← 新規作成
```

SKILL.md側の記載は以下のように短縮：

```markdown
### ステップ4: サブエージェントへのテストケース生成委譲（必須）

`prompts/subagent_call_template.md` を読み込み、
generation_context.jsonの情報で変数を埋めて
@test-case-specialist を呼び出してください。
```

**Step 3: When/Don't節の圧縮**

- 「起動しない条件」の5行 → 1行（「明確なトリガー一致が必要」のみ）
- 「使用例」3パターン → README.mdへ移動
- 「Troubleshooting」セクション → `docs/`配下へ完全移動
- 「安全対策」「バージョン・ライセンス」 → README.mdへ移動
- 「参照ドキュメント」リンク集 → 削除（README.mdに集約）

**Step 4: 目標構成（200行以内）**

```
フロントマター        : ~20行（triggers 10個）
Trigger Phrases節    : ~15行（箇条書きのみ）
When節               : ~15行（起動条件・前提条件）
Do節                 : ~20行（コマンド1つ）
Instructions節       : ~80行（3ステップ）
Don't節              : ~15行（禁止事項5個）
Inputs/Outputs節     : ~25行
4パターン概要         : ~10行（詳細はREADME参照）
合計                 : ~200行
```

---

### C-2: 実行フローの圧縮 → 3ステップ化

#### 対象ファイル
- `skills/run/SKILL.md`（Instructions節）
- `core/orchestrator.py`（`prepare_generation_context()`）
- `skill_entry.py`

#### 具体的な作業手順

**Step 1: generation_context.jsonにサブエージェント向けプロンプトを自動生成**

`core/orchestrator.py` の `prepare_generation_context()` に以下を追加：

```python
def prepare_generation_context(pattern, state, base_branch, details):
    # ... 既存のcontext生成ロジック ...
    
    # 新規: サブエージェント向けプロンプトを自動組み立て
    subagent_prompt = build_subagent_prompt(context, reference_files)
    context["subagent_prompt"] = subagent_prompt
    context["subagent_prompt_file"] = str(
        state.paths["artifacts"] / "subagent_prompt.md"
    )
    
    # サブエージェント向けプロンプトをファイル出力
    with open(context["subagent_prompt_file"], "w") as f:
        f.write(subagent_prompt)
    
    return context
```

**Step 2: SKILL.mdのInstructions節を3ステップに書き換え**

```markdown
## Instructions

### ステップ1: skill_entry.py実行
Do節のコマンドを実行。準備フェーズが完了します。

### ステップ2: generation_context.json読み込み
`test-cases/generation_context.json` をJSONとして読み込み、
`reference_files[]` の各ファイルを順次参照してください。

### ステップ3: サブエージェント呼び出し
generation_context.jsonの `subagent_prompt_file` を読み込み、
その内容をそのまま @test-case-specialist に渡してください。
手動でのテンプレート組み立ては不要です。
```

**Step 3: 完了メッセージの改善**

`skill_entry.py` の完了メッセージを以下に簡素化：

```
✅ 準備完了
📋 次: test-cases/generation_context.json を読み込み、
   subagent_prompt_file のパスにあるプロンプトで
   @test-case-specialist を呼び出してください。
```

---

### C-3: input()廃止 → 環境変数プライマリ化

#### 対象ファイル
- `core/orchestrator.py`（`detect_pattern()`, `ask_user_for_pattern()`）
- `skills/run/SKILL.md`（Do節・Instructions節）

#### 具体的な作業手順

**Step 1: detect_pattern()のフロー変更**

```python
def detect_pattern(state: SkillState) -> Tuple[Pattern, Dict]:
    details = {"selection_method": None, "confidence": 0.0, "reason": ""}
    
    # 優先順位1: 環境変数（プライマリ）
    pattern = get_pattern_from_env(state)
    if pattern:
        details["selection_method"] = "environment_variable"
        details["confidence"] = 1.0
        details["reason"] = f"環境変数で{pattern.value}が指定"
        return pattern, details
    
    # 優先順位2: 自動判定（input()は使わない）
    pattern, auto_details = auto_detect_pattern(state)
    details["selection_method"] = "auto_detection"
    details["confidence"] = auto_details.get("confidence", 0.8)
    details["reason"] = auto_details.get("reason", "自動判定")
    
    # 注意: 自動判定結果をログに出力（ユーザー確認用）
    state.logger.info(f"自動判定結果: {pattern.value}")
    state.logger.info(f"理由: {details['reason']}")
    state.logger.info("別パターンを指定する場合は POCHI_PATTERN_SELECTION 環境変数を設定してください")
    
    return pattern, details
```

**Step 2: SKILL.mdのDo節を変更**

パターン選択をエージェント側の事前質問に委譲する：

```markdown
## Do

**起動前にユーザーにパターンを確認してください：**

1. スコープ: 全機能（full）/ 特定範囲（partial）
2. テストタイプ: 結合テスト（integration）/ シナリオテスト（scenario）

確認後、以下を実行：

```bash
POCHI_SKILL_ACTIVE=1 \
POCHI_PATTERN_SELECTION={判定されたパターン} \
python skills/test/pochi-test-orchestrator/skill_entry.py
```
```

**Step 3: ask_user_for_pattern()を非推奨化**

```python
def ask_user_for_pattern(state: SkillState) -> Tuple[str, str]:
    """[DEPRECATED] 対話的質問によるパターン選択
    
    Claude Code環境ではinput()が動作しないため非推奨。
    POCHI_PATTERN_SELECTION環境変数を使用してください。
    """
    state.logger.warning("ask_user_for_pattern()は非推奨です。環境変数を使用してください。")
    # ... 既存の実装は維持（CLIフォールバック用）
```

---

### m-3: version不整合の解消

#### 対象ファイル
- `plugin.json`
- `skills/run/SKILL.md`

#### 修正内容

**方針**: plugin.jsonのversionを正とし、SKILL.md内のバージョン記載を削除。

SKILL.md末尾の「バージョン・ライセンス」セクション：
```markdown
# Before
- **バージョン**: 3.0.0（Skill-first化対応版）

# After（セクションごと削除。plugin.jsonに一元化）
```

フロントマターの`version`もplugin.jsonと同期：
```yaml
version: 1.0.0  # plugin.jsonと同期
```

---

### m-4: logsディレクトリの永続化

#### 対象ファイル
- `logs/.gitkeep`（新規作成）
- `skill_entry.py`

#### 修正内容

**Step 1: .gitkeep配置**

```bash
touch skills/test/pochi-test-orchestrator/logs/.gitkeep
git add skills/test/pochi-test-orchestrator/logs/.gitkeep
```

**Step 2: skill_entry.pyにディレクトリ作成保証を追加**

`SkillState.__init__()`またはskill_entry.pyの冒頭：

```python
# ログディレクトリの自動作成
log_dir = SKILL_DIR / "logs"
log_dir.mkdir(parents=True, exist_ok=True)
```

---

### m-5: コアモジュールのユニットテスト追加

#### 対象ファイル
- `test/test_orchestrator.py`（新規作成）
- `test/test_precheck.py`（新規作成）
- `test/test_state.py`（新規作成）

#### 推奨テスト内容

| テスト対象 | テスト内容 | 優先度 |
|-----------|-----------|--------|
| `orchestrator.map_answers_to_pattern()` | 4パターンのマッピング正確性 | 高 |
| `orchestrator.get_pattern_from_env()` | 環境変数からのパターン取得・不正値処理 | 高 |
| `precheck.run()` | 環境チェック（Python, Git, 書き込み権限） | 中 |
| `state.SkillState()` | 初期化・パス解決・ログ設定 | 中 |
| `metrics.calculate_from_metrics()` | 動的件数計算の正確性 | 中 |
| `prompt_builder.PromptBuilder` | プロンプト組み立て | 低 |

最小テスト例：

```python
# test/test_orchestrator.py
import pytest
from core.orchestrator import map_answers_to_pattern, Pattern

class TestMapAnswersToPattern:
    def test_full_integration(self):
        assert map_answers_to_pattern("full", "integration") == Pattern.FULL_INTEGRATION

    def test_full_scenario(self):
        assert map_answers_to_pattern("full", "scenario") == Pattern.FULL_SCENARIO

    def test_partial_integration(self):
        assert map_answers_to_pattern("partial", "integration") == Pattern.PARTIAL_INTEGRATION

    def test_partial_scenario(self):
        assert map_answers_to_pattern("partial", "scenario") == Pattern.PARTIAL_SCENARIO

    def test_unknown_falls_back(self):
        assert map_answers_to_pattern("unknown", "unknown") == Pattern.FULL_INTEGRATION
```

---

## 付録B: 分析対象ファイル一覧

| ファイル | 行数概算 | 役割 |
|----------|----------|------|
| `skills/run/SKILL.md` | ~700行（2026-04-20時点）/ 586行（2026-04-27時点） | Skill定義・実行指示 |
| `plugin.json` | 10行 | プラグインメタデータ |
| `.claude-plugin/plugin.json` | 12行 | プラグインメタデータ（重複） |
| `README.md` | ~400行 | ユーザー向け説明 |
| `skill_entry.py` | ~200行 | メインエントリポイント |
| `core/orchestrator.py` | ~200行 | パターン判定ロジック |
| `config/default_config.json` | ~100行 | デフォルト設定 |
| `agents/test-case-specialist.md` | ~100行 | サブエージェント定義 |
| `docs/QUICKSTART.md` | ~100行 | クイックスタート |
| `docs/INSTALLATION.md` | ~100行 | インストール手順 |
| `docs/ADVANCED.md` | ~200行 | 高度な統合ガイド |
| `docs/OPERATIONS_RUNBOOK.md` | ~100行 | 運用ランブック |
| `docs/VERIFICATION_GUIDE.md` | ~100行 | 検証ガイド |
| `prompts/generate_test_cases_prompt.md` | ~200行 | 生成プロンプト |

---

## 付録C: コストレポート（2026-04-20 セッション）

### セッション概要

| 項目 | 値 |
|------|-----|
| 合計コスト | $3.54 |
| API処理時間 | 11分10秒 |
| 実経過時間 | 29分36秒 |
| コード変更量 | +2533 / 0行（新規追加のみ） |

### モデル別内訳

| モデル | input | output | cache read | cache write | コスト |
|--------|-------|--------|------------|-------------|--------|
| claude-sonnet-4-6 | 3.0k | 17.3k | 3.6m | 453.9k | $3.06 |
| claude-haiku-4-5 | 11.2k | 46.2k | 445.1k | 153.7k | $0.48 |

### 特記事項

- Sonnet が $3.06（全体の 86%）を占め、pochi-unit-test-generator より Sonnet 依存が高い
- cache read が 3.6m tokens と大量発生しており、SKILL.md や共通コンテキストの再利用でコストが抑えられている
- Haiku が $0.48 と安価 — 新規追加のみ（+2533行、削除なし）というシンプルな生成タスクを反映

### 2スキルのコスト比較

| 項目 | pochi-unit-test-generator | pochi-test-orchestrator |
|------|--------------------------|------------------------|
| コスト | $6.08 | $3.54 |
| 主コスト | Haiku ($3.76) | Sonnet ($3.06) |
| API処理時間 | 38分44秒 | 11分10秒 |
| 変更規模 | +6081/-1897行 | +2533/0行 |
| 処理の性質 | 複雑（修正含む） | シンプル（新規追加） |

コスト差の主因は**コード変更量（複雑さ）**と**Haiku サブエージェントの使用量**。
