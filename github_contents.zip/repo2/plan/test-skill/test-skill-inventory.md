# テストスキル整理計画

## 方針

- **TDDフロー（コード不在の開発初期）**: `pochi-tdd-test-generator` → `pochi-coding-agent` → `pochi-unit-test-generator`
- **通常フロー（実装済みコードへの後付け）**: `pochi-unit-test-generator`（`pochi-test-strategy-initializer`を統合）
- **結合・シナリオテストケース生成**: `pochi-test-orchestrator`
- **E2Eテストコード生成**: `pochi-e2e-test-generator`
- **テスト実施**: テストケースMDを見ながら人が手動で実施
- 上記4スキル以外はarchive対象

---

## 現状スキル一覧と対応方針

| スキル | 役割 | 対応 | レベル |
|---|---|---|---|
| `pochi-unit-test-generator` | データ契約テスト・ロジック単体テストコード生成 | **残す（strategy-initializerを統合）** | 単体 |
| `pochi-test-orchestrator` | 結合テストケース・シナリオテストケースをMD形式で生成（テストコードは生成しない） | **残す** | 結合 / シナリオ |
| `pochi-e2e-test-generator` | E2Eテストケース設計書からPlaywrightテストコード生成 | **残す** | シナリオ |
| `pochi-tdd-test-generator` | spec.jsonからデータ契約・ロジック単体のREDテスト先行生成（TDDフロー専用） | **残す** | 単体 |
| `pochi-test-strategy-initializer` | モック方針・品質目標・テスト比率をヒアリングし`test-strategy-config.json`と`conftest.py`を生成 | **unit-test-generatorに統合してarchive** | 単体 |
| `pochi-integration-test-designer` | AppTest結合テスト設計書生成 | **archive** | 結合 |
| `pochi-integration-test-generator` | 結合テスト設計書からテストコード生成 | **archive** | 結合 |
| `pochi-e2e-test-designer` | PlaywrightE2Eテストケース設計書生成。pochi-test-orchestratorの後継として実装されたが方針変更により不採用 | **archive** | シナリオ |
| `pochi-e2e-base-verifier` | E2Eテスト基盤ファイル（BasePage等）の検証ファイル配置 | **archive** | シナリオ |
| `pochi-coverage-fixer` | テスト生成後のカバレッジ向上（conftest.py修正・不足テスト追加） | **archive** | 単体 |

---

## スキルフロー

### 通常フロー（実装済みコードへの後付け）

```
[app_path + entrypoint + ヒアリング（カバレッジ目標・モック方針）]
                          ↓
          pochi-unit-test-generator
   Layer1（データ契約）+ Layer2（ロジック単体）テストコード生成
   出力: tests/contracts/ / tests/unit/ / tests/fixtures/ / tests/conftest.py
                          ↓（オプション）
          pochi-test-orchestrator
      結合・シナリオテストケースMD生成（人が手動実施）
                          ↓（オプション）
          pochi-e2e-test-generator
         E2Eテストコード（Playwright）生成
```

### TDDフロー（コード不在の開発初期）

```
[spec.json + plan.json + ヒアリング（カバレッジ目標・モック方針）]
                          ↓
        pochi-tdd-test-generator
   Layer1・2のREDテスト先行生成 → test-mapping.json 出力
   出力: tests/contracts/ / tests/unit/ / tests/fixtures/ / tests/conftest.py
                          ↓
           pochi-coding-agent
      test-mapping.json を参照して実装
                          ↓
          pochi-unit-test-generator
         GREEN を確認・テスト補強
                          ↓（オプション）
          pochi-test-orchestrator
      結合・シナリオテストケースMD生成（人が手動実施）
```

### スキルの役割まとめ

| スキル | レイヤー | 出力 | 備考 |
|---|---|---|---|
| `pochi-tdd-test-generator` | L1 + L2（RED） | テストコード + test-mapping.json | TDDフロー専用 |
| `pochi-unit-test-generator` | L1 + L2（GREEN） | テストコード + module-inventory.json | 通常フロー・TDD両対応 |
| `pochi-test-orchestrator` | L3 | テストケースMD（手動実施） | 結合・シナリオ |
| `pochi-e2e-test-generator` | L4 | Playwrightテストコード | オプション |

---

## レビュー結果（2026-04-20）

### 総合評価

計画の方向性は妥当。strategy-initializer統合によるUX改善（前提スキル実行不要化）と、不要スキルのarchiveによるスキル群の簡素化は合理的。ただし以下の点で補足・修正が必要。

### 指摘事項

#### 指摘1: archive対象スキルへの相互参照が残存（重要度: 高）

改修対象スキルのSKILL.md内に、archive予定のスキルへの参照が多数残っている。

| 参照元 | 参照先（archive予定） | 該当箇所 |
|---|---|---|
| `pochi-unit-test-generator` SKILL.md | `pochi-integration-test-designer` / `pochi-integration-test-generator` | 完了レポート（STEP 10）の「次のステップ」 |
| `pochi-unit-test-generator` SKILL.md | `pochi-test-onboarding` | 注意事項セクション「Layer3・4非対応」 |
| `pochi-tdd-test-generator` SKILL.md | `pochi-integration-test-designer` | 生成対象テーブルの注記・完了レポート（STEP 10）の「次のステップ」 |
| `pochi-tdd-test-generator` SKILL.md | `pochi-integration-test-designer` → `pochi-integration-test-generator` | 注意事項セクション「Layer3は対象外」 |
| CLAUDE.md | `pochi-test-strategy-initializer` / `pochi-integration-test-designer` / `pochi-integration-test-generator` | 「テスト生成スキルのワークフロー」セクション |

**対応**: 全参照先を `pochi-test-orchestrator`（テストケースMD生成）に統一変更する。

#### 指摘2: conftest.py生成時のmock_strategy参照の設計が不足（重要度: 高）

計画ではconfigファイル廃止とヒアリング変数化を定義しているが、conftest.py生成ステップ（STEP 5）での具体的な変数引き渡し設計が不足。

現在のunit-test-generatorのSTEP 5は `test-strategy-config.json` の `mock_strategy.always_mock` / `never_mock` を参照して `_MOCK_MODULES` リストを生成している。統合後はこれらの値をどのようにサブエージェントに引き渡すかを明示する必要がある。

**対応**: 後述の改修設計で詳細化。

#### 指摘3: T0後のモック方針マージ・確定フローが未設計（重要度: 中）

strategy-initializerのSTEP 3では、T0の依存パッケージ自動検出結果とユーザーのヒアリング結果をマージし、ユーザーに確認を取っている。計画では「ヒアリング結果を変数として直接保持」としているが、T0結果との統合タイミング・ユーザー確認UIが未定義。

**対応**: 後述の改修設計でSTEP 2.5を「モック方針確定」ステップとして再定義。

#### 指摘4: STEP番号の整合性（重要度: 低）

計画では「STEP 1.5を削除」「STEP 2.5を削除」としているが、残ったSTEP番号が飛ぶ。
ただし、既存サブエージェント側にSTEP番号参照がなければ影響は軽微。

**対応**: 改修設計ではSTEP番号をリナンバリングせず、削除箇所の番号を詰める形で対応。

#### 指摘５: pochi-tdd-test-generatorのモック方针ソースが異なる（重要度: 中）

unit-test-generatorはT0実行後に依存パッケージを自動検出できるが、tdd-test-scaffolderはT0を実行しない（コード不在）。そのためモック方針は「ユーザーのヒアリング結果のみ」か「plan.jsonのartifactsから推定」の二択になる。この差異を計画に明記すべき。

**対応**: 後述の改修設計で差異を明確化。

---

## 改修設計

### 1. pochi-unit-test-generator SKILL.md 改修設計

#### 変更概要

| 変更箇所 | 変更種別 | 内容 |
|---|---|---|
| STEP 1 | 修正 | カバレッジ目標・モック方針のヒアリングを追加 |
| STEP 1.5 | **削除** | config存在確認を完全削除 |
| STEP 2 | 修正 | module-inventory.json既存時のスキップオプション追加 |
| STEP 2.5 | **置換** | config読み込み → モック方針自動検出・確定 |
| STEP 5 | 修正 | config参照をヒアリング変数参照に変更 |
| STEP 10 | 修正 | 完了レポートのLayer3参照先変更 |
| 注意事項 | 修正 | Layer3参照先変更・config関連の記述削除 |

#### STEP 1 改修後（差分のみ）

```markdown
## STEP 1: ユーザーからの情報収集

AskUserQuestionツールで以下を確認する（**最大2回の質問で完結させること**）：

**1回目の質問（必須）**:
- **`app_path`**: 対象アプリのリポジトリルートパス（例: `/home/user/my-pochi-app`）
- **`entrypoint`**: アプリのエントリポイントファイル（例: `app.py`）

**2回目の質問（推奨項目を一括提示）**:
以下の項目を一覧で提示し、ユーザーが「デフォルトで続行」を選べるようにする：
- **カバレッジ目標**: 60% / 70% / 80% / カスタム（デフォルト: 60%）
- **モック方針（概要）**: 以下のデフォルト分類を提示し、変更があれば指定してもらう
  - always_mock（常にモック）: pochilib, streamlit系, Snowflake系 → デフォルト
  - never_mock（本物を使用）: pandas, numpy, whoosh, sqlalchemy → デフォルト
  - 「T0解析後に依存パッケージを自動検出し、最終確認します」と案内する
- **Python バージョン**: pytest / fixture の互換性確認のため（デフォルト: 自動検出）
- **既存テストの有無**: `tests/` が既に存在する場合、上書き確認が必要
- **T0/T1 スキップ希望**: `tests/contracts/` が既に存在するが最新化が不要な場合
- **対象ディレクトリ制限**: 大規模リポジトリで `app/` 以外を除外したい場合

> ヒアリング結果は以下の変数として保持し、後続ステップで直接参照する:
> - `coverage_target`: カバレッジ目標（数値、デフォルト: 60）
> - `mock_always`: 常にモックするパッケージリスト
> - `mock_never`: 本物を使用するパッケージリスト
> - `mock_layer_conditional`: Layer別に切り替えるパッケージ（任意）

情報収集後、以下の実行計画を提示して確認を取ること：

  実行計画:
    STEP 2:   T0 - 既存コード解析（pochi-t0-legacy-analyzer）
    STEP 2.5: モック方針の自動検出・確定（T0結果とヒアリング結果をマージ）
    STEP 3:   T1 - テスト契約初期化（pochi-t1-contract-initializer）＋確認チェックポイント
    STEP 4:   T4 - テストデータ生成（pochi-t4-fixtures-manager）
    STEP 5:   conftest.py 生成（pochi-t2-tdd-workflow / test-author）
    STEP 6:   Layer1 - データ契約テスト生成
    STEP 7:   Layer2 - ロジック単体テスト設計
    STEP 8:   Layer2 - テストコード実装
    STEP 8.5: 生成コード品質検証
    STEP 9:   生成テスト検証（--collect-only → pytest）
    STEP 10:  完了レポート
```

#### STEP 1.5 → 削除

以下のブロックをSKILL.mdから完全削除する:

```
## STEP 1.5: test-strategy-config.json の存在確認
（全文削除）
```

#### STEP 2 改修後（差分のみ）

T0実行部分の前に以下のスキップ判定を追加:

```markdown
### T0 スキップ判定

`{app_path}/tests/.onboarding/module-inventory.json` が既に存在するか確認する。

**存在する場合**:
→ 以下を提示してユーザーに選択させる：
  既存の module-inventory.json が見つかりました。
  [A] T0をスキップして既存のmodule-inventory.jsonを使用する
  [B] T0を再実行して最新のコード状態を反映する（推奨）

ユーザーが[A]を選択した場合 → STEP 2.5に進む
ユーザーが[B]を選択した場合 → T0を実行する

**存在しない場合**: T0を実行する
```

#### STEP 2.5 改修後（config読み込み → モック方針確定）

```markdown
## STEP 2.5: モック方針の自動検出・確定

T0の出力（`module-inventory.json`）から依存パッケージを抽出し、
STEP 1のヒアリング結果とマージしてモック方針を確定する。

### マージルール

1. `module-inventory.json` の `external_dependencies` を読み込む
2. 各パッケージについてインストール状況を確認:
   - インストール済み → `mock_never` 候補に追加
   - 未インストール → `mock_always` 候補に追加
3. STEP 1のユーザー指定と統合（ユーザー指定が優先）

### ユーザー確認

以下の形式でマージ結果を提示し、確認を取る:

  📋 モック戦略（確認してください）

  always_mock（常にモック）:
    - pochilib, pochilib.snowflake, pochilib.llm
    - （T0で未インストールと判定されたパッケージを追加表示）

  never_mock（本物を使用）:
    - pandas, numpy, whoosh, sqlalchemy
    - （T0でインストール済みと判定されたパッケージを追加表示）

  layer_conditional（Layer別に切り替え）:
    - （該当パッケージがあれば表示）

  [A] この設定で確定する
  [B] 変更してから確定する

### 確定後の変数更新

ユーザー確認後、以下の変数を最終値に更新する:
- `mock_always`: 確定版の常にモックリスト
- `mock_never`: 確定版の本物使用リスト
- `mock_layer_conditional`: 確定版のLayer別切り替えリスト

> これらの変数はSTEP 5（conftest.py生成）およびテスト生成の各ステップで直接参照される。
> test-strategy-config.json は生成しない。
```

#### STEP 5 改修後（差分のみ: conftest.py生成時のmock_strategy参照変更）

以下の箇所を変更:

**変更前:**
```
→ _MOCK_MODULES リストを test-strategy-config.json の mock_strategy.always_mock から生成する
→ mock_strategy.never_mock に含まれるパッケージは _MOCK_MODULES から除外する
```

**変更後:**
```
→ _MOCK_MODULES リストをSTEP 2.5で確定した `mock_always` 変数から生成する
→ `mock_never` 変数に含まれるパッケージは _MOCK_MODULES から除外する
```

#### STEP 10 改修後（差分のみ: 完了レポートのLayer3参照先変更）

**変更前:**
```
🚀 次のステップ:
  Layer3（結合テスト）が必要な場合は以下を実行してください：
    1. 「結合テストを設計して」（pochi-integration-test-designer）
    2. 「結合テストコードを生成して」（pochi-integration-test-generator）
```

**変更後:**
```
🚀 次のステップ:
  結合テスト・シナリオテストが必要な場合:
    「テストケースを生成して」（pochi-test-orchestrator）
    ※ テストケースMDを生成し、人が手動で実施するフローです
```

#### 注意事項セクション改修後（差分のみ）

**変更前:**
```
- **Layer3・4 非対応**: このスキルは Layer3（結合テスト）・Layer4（E2Eテスト）を生成しない。
  これらが必要な場合は `pochi-test-onboarding` を使用すること。
```

**変更後:**
```
- **Layer3・4 非対応**: このスキルは Layer3（結合テスト）・Layer4（E2Eテスト）のテストコードを生成しない。
  結合・シナリオテストケースが必要な場合は `pochi-test-orchestrator` を使用すること
  （テストケースMDを生成し、人が手動実施するフロー）。
```

---

### 2. pochi-tdd-test-generator SKILL.md 改修設計

#### 変更概要

| 変更箇所 | 変更種別 | 内容 |
|---|---|---|
| STEP 1 | 修正 | カバレッジ目標・モック方針のヒアリングを追加 |
| STEP 1.5 | **削除** | config存在確認を完全削除 |
| STEP 4 | 修正 | conftest.py生成時のmock_strategy参照をヒアリング変数に変更 |
| STEP 10 | 修正 | 完了レポートのLayer3参照先変更 |
| 生成対象テーブル | 修正 | integration-test-designer参照を削除 |
| 注意事項 | 修正 | Layer3参照先変更・config関連の記述削除 |

#### STEP 1 改修後（差分のみ）

```markdown
## STEP 1: ユーザーからの情報収集

AskUserQuestionツールで以下を確認する（**最大2回の質問で完結させること**）：

**1回目の質問（必須）**:
- **`app_path`**: プロジェクトルートパス（例: `/home/user/my-pochi-app`）
- **`spec_json_path`**: spec.json のパス（例: `spec.json` または `docs/spec.json`）
- **`plan_json_path`**: plan.json のパス（例: `plan.json` または `docs/plan.json`）

**2回目の質問（推奨項目を一括提示）**:
以下の項目を一覧で提示し、ユーザーが「デフォルトで続行」を選べるようにする：
- **カバレッジ目標**: 60% / 70% / 80% / カスタム（デフォルト: 60%）
- **モック方針**: 以下のデフォルト分類を提示し、変更があれば指定してもらう
  - always_mock（常にモック）: pochilib, streamlit系, Snowflake系 → デフォルト
  - never_mock（本物を使用）: pandas, numpy, whoosh, sqlalchemy → デフォルト
  - ※ T0未実行のため依存パッケージの自動検出は不可。plan.jsonのartifactsから推定する
- **Python バージョン**: pytest / fixture の互換性確認のため（デフォルト: 自動検出）
- **既存テストの有無**: `tests/` が既に存在する場合、上書き確認が必要
- **Snowflake/LLM 依存の有無**: モック戦略の事前判断（デフォルト: plan.json から自動検出）

> ヒアリング結果は以下の変数として保持し、後続ステップで直接参照する:
> - `coverage_target`: カバレッジ目標（数値、デフォルト: 60）
> - `mock_always`: 常にモックするパッケージリスト
> - `mock_never`: 本物を使用するパッケージリスト
> ※ unit-test-generatorと異なり、T0を実行しないためSTEP 2.5（モック方針自動検出）は存在しない。
> plan.jsonのartifactsに含まれるSnowflake/LLM依存情報があれば、mock_alwaysに自動追加する。

情報収集後、以下の実行計画を提示して確認を取ること：

  実行計画:
    STEP 2:  contracts/ 直接生成（spec.json → 6ファイル）
    STEP 3:  T4 - テストデータ生成（pochi-t4-fixtures-manager）
    STEP 4:  conftest.py 生成（plan.json の artifacts からモジュール構成を推定）
    STEP 5:  Layer1 - データ契約テスト生成（spec.json スキーマベース）
    STEP 6:  Layer2 - ロジック単体テスト設計（関数シグネチャを仕様から予測）
    STEP 7:  Layer2 - テストコード実装
    STEP 8:  検証（--collect-only のみ、RED状態は正常）
    STEP 9:  test-mapping.json 出力（coding-agent用）
    STEP 10: 完了レポート
```

#### STEP 1.5 → 削除

以下のブロックをSKILL.mdから完全削除する:

```
## STEP 1.5: test-strategy-config.json の存在確認
（全文削除）
```

#### STEP 4 改修後（差分のみ: conftest.py生成時のmock_strategy参照変更）

conftest.py生成のフレームワーク別モック戦略セクションに以下の変更を加える:

**変更前（_MOCK_MODULES部分）:**
```
→ _MOCK_MODULES リスト（未インストールパッケージ）を設定する
```

**変更後:**
```
→ _MOCK_MODULES リストをSTEP 1で確定した `mock_always` 変数から生成する
→ `mock_never` 変数に含まれるパッケージは _MOCK_MODULES から除外する
```

#### STEP 10 改修後（差分のみ: 完了レポートのLayer3参照先変更）

**変更前:**
```
  3. Layer3（結合テスト）が必要な場合:
       「結合テストを設計して」（pochi-integration-test-designer）を実行
```

**変更後:**
```
  3. 結合テスト・シナリオテストケースが必要な場合:
       「テストケースを生成して」（pochi-test-orchestrator）
       ※ テストケースMDを生成し、人が手動で実施するフローです
```

#### 生成対象テーブル注記の変更

**変更前:**
```
Layer3 設計書が必要な場合は実装完了後に `pochi-integration-test-designer` を使用すること。
```

**変更後:**
```
結合・シナリオテストケースが必要な場合は `pochi-test-orchestrator` を使用すること。
```

#### 注意事項セクション改修後（差分のみ）

**変更前:**
```
- **Layer3 は対象外**: このスキルは Layer1・Layer2 のみ生成する。
  Layer3（結合テスト）が必要な場合は実装完了後に pochi-integration-test-designer → pochi-integration-test-generator を使用すること。
```

**変更後:**
```
- **Layer3 は対象外**: このスキルは Layer1・Layer2 のみ生成する。
  結合・シナリオテストケースが必要な場合は `pochi-test-orchestrator` を使用すること
  （テストケースMDを生成し、人が手動実施するフロー）。
```

---

### 3. CLAUDE.md「テスト生成スキルのワークフロー」改修設計

#### 変更概要

「実行順序（依存関係）」セクションを新フローに完全置換する。

**変更後:**

```markdown
### 実行順序（依存関係）

テスト生成スキルは以下のいずれかのフローで実行する。

#### 通常フロー（実装済みコードへの後付け）

```
1. pochi-unit-test-generator（Layer1 + Layer2）
   入力: app_path + entrypoint + カバレッジ目標・モック方針（ヒアリング）
   出力: tests/contracts/（Layer1テスト + 契約ファイル）
         tests/unit/（Layer2テスト）
         tests/fixtures/（テストデータ）
         tests/.onboarding/module-inventory.json
         tests/conftest.py
   ↓
2. pochi-test-orchestrator（結合・シナリオテストケース）
   入力: 対象アプリ
   出力: テストケース設計書MD（人が手動実施）
```

#### TDDフロー（コード不在の開発初期）

```
1. pochi-tdd-test-generator（Layer1 + Layer2 のREDテスト先行生成）
   入力: spec.json + plan.json + カバレッジ目標・モック方針（ヒアリング）
   出力: tests/contracts/（Layer1テスト + 契約ファイル）
         tests/unit/（Layer2テスト）
         tests/fixtures/（テストデータ）
         tests/.onboarding/test-mapping.json
         tests/conftest.py
   ↓
2. pochi-coding-agent（test-mapping.json を見て実装）
   ↓
3. pochi-unit-test-generator（GREENを確認・テスト補強）
   ↓
4. pochi-test-orchestrator（結合・シナリオテストケース）
```

### 前提ファイルについて

- `test-strategy-config.json` は廃止。各スキルがSTEP 1のヒアリングで直接収集する
- pochi-unit-test-generator / pochi-tdd-test-generator は前提スキルなしで単独起動可能
```

### 「前提ファイルが存在しない場合の対応」セクションの変更

**変更後:**
```markdown
### 前提ファイルが存在しない場合の対応

pochi-unit-test-generator / pochi-tdd-test-generator は前提スキルなしで単独起動可能。
test-strategy-config.json の事前生成は不要（各スキル内でヒアリングを実施する）。
pochi-test-orchestrator は前提なしで起動可能（skill_entry.py が自動準備する）。
```

---

### 4. pochi-unit-test-generator と pochi-tdd-test-generator のモック方針差異まとめ

| 観点 | pochi-unit-test-generator | pochi-tdd-test-generator |
|---|---|---|
| モック方針のソース | STEP 1ヒアリング + T0自動検出 | STEP 1ヒアリングのみ |
| T0実行 | 実行する（依存パッケージを自動検出） | 実行しない（コード不在） |
| 自動検出の有無 | あり（module-inventory.json） | なし（plan.jsonから一部推定のみ） |
| モック方針確定STEP | STEP 2.5（T0結果とマージ → ユーザー確認） | STEP 1内で完結（ヒアリング結果がそのまま最終値） |
| conftest.py の _MOCK_MODULES | 確定版 `mock_always` から生成 | 確定版 `mock_always` から生成 |

> **設計方針**: 両スキルとも `mock_always` / `mock_never` 変数を同じ名前で保持し、
> conftest.py生成ステップでは同一のインターフェースでサブエージェントに渡す。
> ソースの違い（T0自動検出 vs ヒアリングのみ）はスキル側で吸収する。
