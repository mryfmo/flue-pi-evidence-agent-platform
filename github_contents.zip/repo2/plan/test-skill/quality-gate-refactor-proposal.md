# quality_gate.py 問題点と改善提案

調査日: 2026-05-07

---

## 1. 発端

`pochi-test-orchestrator` を最近改修した結果、品質ゲートの観点カウントロジックでバグが混入した。
`pochi-id-converter` のシナリオテスト生成時に品質ゲートが誤カウントを報告し、
オーケストレーター自身がファイルのカラム順を変更するという誤った自己修正を行った。

---

## 2. バグの根本原因（3点）

### Bug 1: `analyze_perspectives` の分割パターン拡張による誤判定（主因）

**混入コミット**: `d2c89ce`（2026-05-07）

**変更内容**: `### SC-001 詳細定義:` 形式も分割対象に追加した。

**問題**: 詳細定義のテキストにはブラケットタグ `[基本]`/`[境界]`/`[異常]` が存在しない。
このためキーワードフォールバックが走り、境界テストのブロック内の「最大件数で**正常**に動作し」
という自然な日本語が `basic` に誤分類される。

```
SC-002（境界テスト）詳細定義: 「最大件数で正常に動作し、1001件目はエラーになる」
  → タグなし → キーワード判定へ
  → 「正常」がヒット → basic と誤判定（実際は boundary）
```

### Bug 2: `count_test_cases` と `count_test_cases_by_section` の不整合

セクション1が見出し形式、セクション2がテーブル形式の混在ファイルで:

- `count_test_cases` → 見出し形式のみカウント（例: 2件）
- `count_test_cases_by_section` → 両セクションをカウント（例: 4件）
- `integration_count + scenario_count > test_case_count` となり達成率計算が破綻する

**混入コミット**: `e30b1bc`（テーブル形式追加）+ `d2c89ce`（max採用）

### Bug 3: カラム順固定による脆弱性（暫定修正の限界）

Bug 1/2 の暫定対応として「サマリーテーブルの3列目が観点」と固定したが、
`format_spec.md` の仕様はセクション1とセクション2でカラム構成が異なる。

| セクション | テーブル仕様 | 観点の位置 |
|---|---|---|
| セクション1（結合テスト） | `テストID \| テストケース名 \| 機能カテゴリ \| テスト観点` | 4列目 |
| セクション2（シナリオテスト） | `テストID \| シナリオ名 \| 関連機能 \| 業務フロー` | **観点列なし** |

観点の正式な記載場所は詳細定義内の `- **観点**: [基本/...]` フィールド。
しかし実際には `test-case-specialist` がサマリーに観点列を追加するケースがあり、
その列インデックスがアプリごとにブレるため、固定インデックスでは確実に読めない。

---

## 3. 問題の本質

**マークダウン形式で生成・品質チェックをしていること自体**が構造的な脆弱性の原因。

```
現状のフロー:
LLM → マークダウン生成 → quality_gate.py が正規表現でパース → 品質チェック → レポート
```

マークダウン表は人間可読性を優先した形式であり、パーサーには向いていない:

- カラム順がエージェントの生成ごとにブレる
- ヘッダー行・セパレーター行・データ行の区別が正規表現頼り
- 観点がサマリー・詳細定義・ブラケットタグなど複数箇所に分散
- キーワードフォールバックは日本語の技術文書では誤判定が構造的に不可避

---

## 4. 改善提案: 中間フォーマットをJSONに変更

### 4.1 変更後のフロー

```
変更後のフロー:
LLM → JSON生成 → quality_gate.py がJSONを直接読む → 品質チェック
                                                     ↓ 合格
                                              マークダウン変換（最終出力・人間可読）
```

人間が読む用のマークダウン形式は品質チェック完了後に生成する。
品質チェック中はJSONのみを扱う。

### 4.2 JSONスキーマ案

```json
{
  "app_name": "pochi-id-converter",
  "generated_at": "2026-05-07",
  "test_cases": [
    {
      "id": "SC-001",
      "title": "アカウント識別子から共通IDグループ番号への単純変換",
      "type": "scenario",
      "perspective": "basic",
      "flow": "正常系フロー",
      "steps": [
        "アプリを起動する",
        "CSVファイルをアップロードする"
      ],
      "expected": [
        "変換処理が正常に完了する",
        "出力ファイルに正しい列が含まれる"
      ]
    }
  ]
}
```

### 4.3 変更が必要な箇所

| ファイル | 変更内容 |
|---|---|
| `prompts/core/format_spec.md` | JSONスキーマ定義に書き換え |
| `agents/test-case-specialist.md` | JSON形式で出力するよう指示変更 |
| `core/quality_gate.py` | JSON読み込みに全面置き換え（正規表現パーサー廃止） |
| `core/orchestrator.py` | 品質合格後にJSONからマークダウンを生成するステップを追加 |
| `prompts/generate_test_cases_prompt.md` | JSON出力仕様に更新 |

### 4.4 quality_gate.py の簡素化イメージ

```python
def analyze_perspectives(test_cases: list) -> Dict[str, int]:
    counts = {"basic": 0, "boundary": 0, "abnormal": 0, "other": 0}
    perspective_map = {
        "基本": "basic", "境界": "boundary",
        "異常": "abnormal", "その他": "other"
    }
    for tc in test_cases:
        cat = perspective_map.get(tc.get("perspective", ""), "other")
        counts[cat] += 1
    return counts

def count_test_cases_by_section(test_cases: list) -> Tuple[int, int]:
    integration = sum(1 for tc in test_cases if tc["type"] == "integration")
    scenario = sum(1 for tc in test_cases if tc["type"] == "scenario")
    return integration, scenario
```

正規表現が不要になり、カウントロジックが単純・確実になる。

---

## 5. 移行方針

### フェーズ1: 暫定修正（実施済み・2026-05-07）

`quality_gate.py` の `analyze_perspectives` をヘッダー行から観点列インデックスを動的特定する方式に修正。
Bug 1/2 を一時的に抑制する。

### フェーズ2: JSON中間フォーマット化（本質的な修正）

上記 4.3 の変更を実施。既存の出力ファイル（`.md`）との互換性は捨て、新規生成からJSONを採用する。

### 移行上の注意点

- `test-case-specialist` がJSON形式で安定して出力できるかプロンプト検証が必要
- 長大なJSONをLLMが一度に生成する場合の構造崩れリスクを評価する
  - 対策案: テストケースを20件ずつ分割生成してからマージする
- マークダウン変換処理（`orchestrator.py` に追加）の実装コスト

---

## 6. 暫定修正の現状（`quality_gate.py`）

以下の修正を実施済み（フェーズ1相当）:

- `analyze_perspectives`: セクション2サマリーのヘッダー行から観点列インデックスを動的特定 → 観点フィールド → キーワードの3段階フォールバック
- `run_quality_gate_core`: `test_case_count` の源泉を `count_test_cases_by_section` の合計値に統一（Bug 2対応）

ただしこれは暫定対応であり、JSON化（フェーズ2）で廃止予定。
