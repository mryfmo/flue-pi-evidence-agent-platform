"""
pytest 用の共通フィクスチャとモック設定

このファイルは T0 (pochi-unit-test-analyzer) で自動生成されました。
characterization モード でテストコードを生成するための前提条件です。
"""
import os
import sys
from unittest.mock import MagicMock

# アプリケーションコードへのパスを sys.path に追加
# これにより lib.* として app/lib/ 配下のモジュールを import できます
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

# ========================================
# モック設定: Streamlit とその依存パッケージ
# ========================================
# Streamlit が必要とするランタイムサブモジュールを全てモック化
# whoosh, sqlalchemy は実装が必要なため、モック対象から外す
_MOCK_MODULES = [
    "streamlit",
    "streamlit.runtime",
    "streamlit.runtime.scriptrunner",
    "streamlit.runtime.scriptrunner.script_runner",
    "streamlit.runtime.state",
    "streamlit.runtime.state.session_state",
    "streamlit.components",
    "streamlit.components.v1",
    "streamlit.delta_generator",
    "streamlit_folium",
    "streamlit_antd_components",
    "pochilib",
    "pochilib.snowflake",
    "pochilib.llm",
    "shapely",
    "kaleido",
    "snowflake",
    "snowflake.connector",
    "snowflake.connector.pandas_tools",
]

# モックモジュールを事前登録（import時に MagicMock に差し替え）
for module_name in _MOCK_MODULES:
    sys.modules[module_name] = MagicMock()

# ========================================
# Streamlit デコレータの差し替え
# ========================================
# @st.cache_data @st.cache_resource デコレータをパススルー実装に置き換える
# これにより、デコレータが元の関数を上書きせず、その中身を実行できます
def _passthrough_decorator(func=None, **kwargs):
    """
    パススルーデコレータ。
    元の関数をそのまま返す。@st.cache_data / @st.cache_resource の
    モック実装として使用します。
    """
    if func is not None:
        return func
    return lambda f: f

# モック化された streamlit モジュールに対してデコレータを割り当てる
_st = sys.modules["streamlit"]
_st.cache_data = _passthrough_decorator
_st.cache_resource = _passthrough_decorator

# ========================================
# その他 Streamlit API のモック化
# ========================================
_st.session_state = MagicMock()
_st.column = MagicMock(return_value=MagicMock())
_st.columns = MagicMock(return_value=[MagicMock()])
_st.button = MagicMock(return_value=False)
_st.write = MagicMock()
_st.markdown = MagicMock()
_st.error = MagicMock()
_st.warning = MagicMock()
_st.info = MagicMock()
_st.success = MagicMock()
_st.selectbox = MagicMock(return_value=None)
_st.slider = MagicMock(return_value=None)
_st.text_input = MagicMock(return_value="")

# ========================================
# jinja2 の実装取得とモック化の後処理
# ========================================
# folium が jinja2.Template を使用するため、jinja2.Template は実装から取得する
import jinja2 as _real_jinja2
_jinja2 = sys.modules["jinja2"]
_jinja2.Template = _real_jinja2.Template

# ========================================
# モジュールプリロードリスト
# ========================================
# pytest 実行時にカバレッジ測定の対象にするモジュールを指定
# これにより app/ 配下の全モジュールが import されたかどうかに関わらず
# カバレッジ対象になります
_PRELOAD_MODULES = [
    "lib._InitialDisplay",
    "lib.address",
    "lib.app_designer",
    "lib.app_designer.export_handler",
    "lib.app_designer.session_state",
    "lib.app_designer.solution_engine",
    "lib.app_designer_catalogs.catalogs.loader",
    "lib.const",
    "lib.data_loader._address",
    "lib.data_loader._base",
    "lib.data_loader._graph_data",
    "lib.data_loader._map_data",
    "lib.data_loader._merchant_store",
    "lib.data_loader._settlement_integration_jenre",
    "lib.data_loader._store_information_management",
    "lib.data_loader._user_list_data",
    "lib.data_loader.const",
    "lib.data_loader.data_models.merchant_key",
    "lib.data_loader.intermediate_data_builder.merchant_keys",
    "lib.data_loader.intermediate_data_builder.settlement",
    "lib.data_loader.sa_models.base",
    "lib.data_loader.sa_models.pj_ml_geocoding_address_mst",
    "lib.data_loader.sa_models.pj_ml_geocoding_dbarai_mst",
    "lib.data_loader.sa_models.vw_adw_dncl_store_information_management_master",
    "lib.data_loader.sa_models.vw_dic_dnhd_settlement_integration",
    "lib.data_loader.sa_models.vw_hmd_mjcd_integration_genre_master",
    "lib.data_loader.utils.fuzzy_search",
    "lib.folium_utils",
    "lib.generate_analysis_result_data",
    "lib.generate_user_list",
    "lib.graph_visualizer",
    "lib.merchant_keyword_search",
    "lib.merchant_map",
    "lib.models",
    "lib.patch._execute_patch",
    "lib.patch._streamlit_antd_components",
    "lib.patch._streamlit_antd_components.component_func",
    "lib.profiling_util",
    "lib.session_manager.snowflake_sqlalchemy",
    "lib.store_search",
    "lib.utils",
    "app_pages.about_this_app",
    "app_pages.app_designer",
    "app_pages.data_sources",
    "app_pages.how_to_use",
    "app_pages.visualization_tool",
    "reporting_function._address_input_form",
    "reporting_function._check",
    "reporting_function._query_params",
    "reporting_function._reporting_page",
    "reporting_function._utils",
    "reporting_function.sa_models.base",
    "reporting_function.sa_models.dbarai_city_store_diff_master",
    "reporting_function.sa_models.vw_pochi_dbarai_city_store_master",
]
