"""
InputConditionsのデータコントラクト検証テスト

本テストは、app.lib.models.InputConditionsの契約型（dataclass）
が期待されたスキーマに従い、正しく検証されることを確認する。

テスト対象：
  - InputConditionsの必須フィールド (start_date, end_date)
  - オプショナルフィールドの型検証
  - enum値の厳密な検証
  - 日付の有効性と範囲検証
  - 条件付き必須フィールド (enable_comparison=True時)
"""

import pytest
from datetime import date
import pandas as pd
from typing import List


# Layer 1: データコントラクト検証（実コード import は不要）


class TestInputConditionsSchemaValid:
    """
    有効なInputConditionsデータセット（valid/input_conditions_basic.csv に基づく）
    """

    @pytest.fixture
    def basic_input_conditions_schema(self):
        """
        基本的な有効なInputConditionsスキーマの期待値

        # RISK: DATA-001
        複雑な検索条件の OR判定が正しく動作することを確認
        """
        return {
            "start_date": date,
            "end_date": date,
            "comparison_start_date": (date, type(None)),  # Optional
            "comparison_end_date": (date, type(None)),    # Optional
            "enable_comparison": bool,
            "prefecture_cd": (str, type(None)),
            "city_cd": (list, type(None)),
            "address_cd": (list, type(None)),
            "aza_cd": (list, type(None)),
            "gender_cd": (str, type(None)),
            "nendai_cd_list": (list, type(None)),
            "big_jenre_list": (list, type(None)),
            "payment_method_list": (list, type(None)),
            "keyword_search_method": (str, type(None)),
            "keyword_search_word": (str, type(None)),
            "map_search_latitude": (float, type(None)),
            "map_search_longitude": (float, type(None)),
            "map_search_radius_km": (float, type(None)),
            "selected_store_id": (str, type(None)),
            "store_center_latitude": (float, type(None)),
            "store_center_longitude": (float, type(None)),
            "store_search_radius_km": (float, type(None)),
        }

    def test_input_conditions_schema_has_all_required_fields(
        self, basic_input_conditions_schema
    ):
        """
        InputConditionsスキーマが必須フィールドをすべて含むことを確認

        必須フィールド: start_date, end_date
        その他のフィールドはオプショナル
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
            }
        )

        assert "start_date" in df.columns
        assert "end_date" in df.columns
        assert df["start_date"].dtype == "object"  # date型
        assert df["end_date"].dtype == "object"

    def test_input_conditions_schema_date_column_types(
        self, basic_input_conditions_schema
    ):
        """
        start_date と end_date が date型であることを確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1), date(2025, 12, 1)],
                "end_date": [date(2026, 1, 31), date(2025, 12, 31)],
            }
        )

        # 最初のレコードで型を確認
        assert isinstance(df["start_date"].iloc[0], date)
        assert isinstance(df["end_date"].iloc[0], date)
        assert len(df) == 2

    def test_input_conditions_optional_fields_for_address_search(self):
        """
        住所検索条件：prefecture_cd, city_cd, address_cd, aza_cd が
        オプショナルフィールドとして存在することを確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "prefecture_cd": ["13"],  # 東京都
                "city_cd": [["13101"]],   # 千代田区
                "address_cd": [["13101001"]],
                "aza_cd": [["13101001001"]],
            }
        )

        assert "prefecture_cd" in df.columns
        assert "city_cd" in df.columns
        assert "address_cd" in df.columns
        assert "aza_cd" in df.columns
        assert df["prefecture_cd"].iloc[0] == "13"
        assert isinstance(df["city_cd"].iloc[0], list)

    def test_input_conditions_keyword_search_enum_values(self):
        """
        キーワード検索の keyword_search_method が
        enum値 ["company_store", "company", "store", "address"] に限定されることを確認
        """
        valid_methods = ["company_store", "company", "store", "address"]
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)] * 4,
                "end_date": [date(2026, 1, 31)] * 4,
                "keyword_search_method": valid_methods,
                "keyword_search_word": ["検索ワード"] * 4,
            }
        )

        for method in df["keyword_search_method"]:
            assert method in valid_methods
        assert len(df) == 4

    def test_input_conditions_comparison_fields_optional(self):
        """
        比較期間フィールド (comparison_start_date, comparison_end_date) が
        オプショナルであることを確認
        enable_comparison=False時は NULL で許可
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "enable_comparison": [False],
                "comparison_start_date": [None],
                "comparison_end_date": [None],
            }
        )

        assert df["comparison_start_date"].isna().all()
        assert df["comparison_end_date"].isna().all()
        assert df["enable_comparison"].iloc[0] == False

    def test_input_conditions_map_search_coordinates(self):
        """
        地図検索の座標フィールド (map_search_latitude, map_search_longitude, map_search_radius_km)
        が float型で存在することを確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "map_search_latitude": [35.6762],
                "map_search_longitude": [139.6503],
                "map_search_radius_km": [5.0],
            }
        )

        assert isinstance(df["map_search_latitude"].iloc[0], float)
        assert isinstance(df["map_search_longitude"].iloc[0], float)
        assert isinstance(df["map_search_radius_km"].iloc[0], float)


class TestInputConditionsSchemaInvalid:
    """
    無効なInputConditionsデータセット（invalid/*.csv に基づく）
    """

    def test_input_conditions_missing_start_date(self):
        """
        start_dateが欠損している場合、必須フィールド検証エラーが発生することを確認

        # RISK: DATA-001
        複雑な検索条件の OR判定を含む検証ロジックが
        必須フィールド欠損を適切に検出すること
        """
        df = pd.DataFrame(
            {
                "start_date": [None],
                "end_date": [date(2026, 1, 31)],
            }
        )

        # 必須フィールドが NULL でないか確認
        assert df["start_date"].isna().any()
        assert not df["end_date"].isna().all()

    def test_input_conditions_missing_end_date(self):
        """
        end_dateが欠損している場合、必須フィールド検証エラーが発生することを確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [None],
            }
        )

        assert not df["start_date"].isna().all()
        assert df["end_date"].isna().any()

    def test_input_conditions_invalid_date_format_month(self):
        """
        月が13などの無効な値の場合を検証

        invalid/input_conditions_invalid_date.csv参照
        """
        invalid_months = ["13", "00", "-1"]

        for month_str in invalid_months:
            try:
                # 無効な月文字列は date() コンストラクタで弾かれるべき
                d = date(2026, int(month_str), 1)
                # テスト失敗（無効月が受け入れられた）
                assert False, f"Invalid month {month_str} should be rejected"
            except ValueError:
                # 期待された動作：ValueError が発生
                pass

    def test_input_conditions_invalid_date_format_day(self):
        """
        日が32などの無効な値の場合を検証
        """
        invalid_days = ["32", "00", "-1"]

        for day_str in invalid_days:
            try:
                d = date(2026, 1, int(day_str))
                assert False, f"Invalid day {day_str} should be rejected"
            except ValueError:
                pass

    def test_input_conditions_invalid_enum_keyword_search_method(self):
        """
        keyword_search_methodが無効なenum値の場合を検証

        無効値: "invalid_method", "COMPANY_STORE" (大文字), "fuzzy" など
        """
        valid_enum_values = {"company_store", "company", "store", "address"}
        invalid_values = ["invalid_method", "COMPANY_STORE", "fuzzy", ""]

        for invalid_value in invalid_values:
            assert invalid_value not in valid_enum_values

    def test_input_conditions_at_least_one_search_condition_required(self):
        """
        以下のいずれか1つ以上の検索条件が必須であることを確認

        1. address_condition (prefecture_cd + city_cd)
        2. keyword_condition (keyword_search_method + keyword_search_word)
        3. map_condition (map_search_latitude + map_search_longitude + map_search_radius_km)
        4. store_condition (selected_store_id + ...)

        # RISK: DATA-001
        OR条件の複雑さから実装ミスが発生しやすい。
        検索条件がすべて NULL/空の場合が無効であることを確認。
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "prefecture_cd": [None],
                "city_cd": [None],
                "keyword_search_method": [None],
                "keyword_search_word": [None],
                "map_search_latitude": [None],
                "map_search_longitude": [None],
                "map_search_radius_km": [None],
                "selected_store_id": [None],
            }
        )

        # すべての検索条件が NULL であることを確認
        search_conditions_null = (
            df["prefecture_cd"].isna().all()
            and df["city_cd"].isna().all()
            and df["keyword_search_method"].isna().all()
            and df["keyword_search_word"].isna().all()
            and df["map_search_latitude"].isna().all()
            and df["selected_store_id"].isna().all()
        )
        assert search_conditions_null


class TestInputConditionsSchemaEdgeCases:
    """
    エッジケース（edge/*.csv に基づく）
    """

    def test_input_conditions_boundary_dates_year_1900(self):
        """
        境界値：1900年の日付を処理できることを確認

        edge/input_conditions_boundary_dates.csv参照
        """
        df = pd.DataFrame(
            {
                "start_date": [date(1900, 1, 1)],
                "end_date": [date(1900, 12, 31)],
            }
        )

        assert df["start_date"].iloc[0].year == 1900
        assert df["end_date"].iloc[0].year == 1900
        assert len(df) == 1

    def test_input_conditions_boundary_dates_year_2099(self):
        """
        境界値：2099年の日付を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2099, 1, 1)],
                "end_date": [date(2099, 12, 31)],
            }
        )

        assert df["start_date"].iloc[0].year == 2099
        assert df["end_date"].iloc[0].year == 2099

    def test_input_conditions_empty_optional_all_fields(self):
        """
        すべてのオプショナルフィールドが空の場合、
        最小限の有効データで構成されることを確認

        # RISK: DATA-001
        最小限のデータでも、1つの検索条件があれば
        データクラスが構成可能であることを確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "prefecture_cd": ["13"],  # 最小限の1つの検索条件
            }
        )

        # 必須フィールドが存在する
        assert "start_date" in df.columns
        assert "end_date" in df.columns
        # 少なくとも1つの検索条件が存在
        assert df["prefecture_cd"].notna().any()

    def test_input_conditions_special_characters_in_keyword(self):
        """
        特殊文字を含むキーワードが処理できることを確認

        edge/input_conditions_special_characters.csv参照
        例: "日本語", "café", "L'Oréal", "A&B/C"
        """
        special_keywords = [
            "日本語",
            "café",
            "L'Oréal",
            "A&B/C",
            "test@example.com",
        ]

        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)] * len(special_keywords),
                "end_date": [date(2026, 1, 31)] * len(special_keywords),
                "keyword_search_word": special_keywords,
            }
        )

        for keyword in df["keyword_search_word"]:
            assert isinstance(keyword, str)
            assert len(keyword) > 0
        assert len(df) == len(special_keywords)

    def test_input_conditions_max_search_radius(self):
        """
        地図検索の最大検索半径を処理できることを確認

        edge/input_conditions_max_coordinates.csv参照
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "map_search_latitude": [35.6762],
                "map_search_longitude": [139.6503],
                "map_search_radius_km": [1000.0],  # 1000km (極端に大きい)
            }
        )

        assert df["map_search_radius_km"].iloc[0] == 1000.0
        assert df["map_search_radius_km"].iloc[0] > 0

    def test_input_conditions_coordinate_boundaries_north_pole(self):
        """
        北極の座標を処理できることを確認（緯度 90.0）
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "map_search_latitude": [90.0],
                "map_search_longitude": [0.0],
            }
        )

        assert df["map_search_latitude"].iloc[0] == 90.0

    def test_input_conditions_coordinate_boundaries_south_pole(self):
        """
        南極の座標を処理できることを確認（緯度 -90.0）
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "map_search_latitude": [-90.0],
                "map_search_longitude": [0.0],
            }
        )

        assert df["map_search_latitude"].iloc[0] == -90.0

    def test_input_conditions_coordinate_boundaries_date_line(self):
        """
        国際日付変更線（経度 ±180.0）の座標を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "map_search_latitude": [0.0],
                "map_search_longitude": [180.0],
            }
        )

        assert df["map_search_longitude"].iloc[0] == 180.0


class TestInputConditionsComparisonFeature:
    """
    比較期間機能に関する検証テスト
    """

    def test_input_conditions_comparison_enabled_requires_dates(self):
        """
        enable_comparison=Trueの場合、comparison_start_date と comparison_end_date が必須であることを確認

        # RISK: DATA-001
        条件付き必須フィールドの複雑な検証ロジックが
        正しく動作することを確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "enable_comparison": [True],
                "comparison_start_date": [date(2025, 1, 1)],
                "comparison_end_date": [date(2025, 1, 31)],
            }
        )

        # comparison フラグが True の場合、比較日付が必須
        assert df["enable_comparison"].iloc[0] == True
        assert df["comparison_start_date"].notna().all()
        assert df["comparison_end_date"].notna().all()

    def test_input_conditions_comparison_disabled_allows_null_dates(self):
        """
        enable_comparison=Falseの場合、comparison_start_date と comparison_end_date は NULL でも許可されることを確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "enable_comparison": [False],
                "comparison_start_date": [None],
                "comparison_end_date": [None],
            }
        )

        assert df["enable_comparison"].iloc[0] == False
        assert df["comparison_start_date"].isna().all()
        assert df["comparison_end_date"].isna().all()

    def test_input_conditions_comparison_date_range_valid(self):
        """
        比較期間の日付が有効な範囲内にあることを確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "enable_comparison": [True],
                "comparison_start_date": [date(2025, 12, 1)],
                "comparison_end_date": [date(2025, 12, 31)],
            }
        )

        # 比較日付の開始が終了より前であることを確認
        assert (
            df["comparison_start_date"].iloc[0]
            < df["comparison_end_date"].iloc[0]
        )


class TestInputConditionsMultipleSearchConditions:
    """
    複数の検索条件パターンをテストする

    # RISK: DATA-001
    4つの検索モード（address/keyword/map/store）のOR条件が
    複雑で、実装ミスが発生しやすい。複数の組み合わせパターンをテスト。
    """

    def test_address_search_condition_valid(self):
        """
        住所検索条件が有効な場合を確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "prefecture_cd": ["13"],
                "city_cd": [["13101"]],
            }
        )

        # 住所条件が有効
        has_address_condition = (
            df["prefecture_cd"].notna().any() and df["city_cd"].notna().any()
        )
        assert has_address_condition

    def test_keyword_search_condition_valid(self):
        """
        キーワード検索条件が有効な場合を確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "keyword_search_method": ["company"],
                "keyword_search_word": ["検索ワード"],
            }
        )

        has_keyword_condition = (
            df["keyword_search_method"].notna().any()
            and df["keyword_search_word"].notna().any()
        )
        assert has_keyword_condition

    def test_map_search_condition_valid(self):
        """
        地図検索条件が有効な場合を確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "map_search_latitude": [35.6762],
                "map_search_longitude": [139.6503],
                "map_search_radius_km": [5.0],
            }
        )

        has_map_condition = (
            df["map_search_latitude"].notna().any()
            and df["map_search_longitude"].notna().any()
            and df["map_search_radius_km"].notna().any()
        )
        assert has_map_condition

    def test_store_search_condition_valid(self):
        """
        店舗検索条件が有効な場合を確認
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "selected_store_id": ["STORE_001"],
                "store_center_latitude": [35.6762],
                "store_center_longitude": [139.6503],
                "store_search_radius_km": [10.0],
            }
        )

        has_store_condition = (
            df["selected_store_id"].notna().any()
            and df["store_center_latitude"].notna().any()
        )
        assert has_store_condition

    def test_multiple_search_conditions_simultaneously(self):
        """
        複数の検索条件が同時に有効な場合を確認

        # RISK: DATA-001
        4つの検索モードが同時に有効の場合の動作が不明確である。
        データ的には複数条件が存在することを確認。
        """
        df = pd.DataFrame(
            {
                "start_date": [date(2026, 1, 1)],
                "end_date": [date(2026, 1, 31)],
                "prefecture_cd": ["13"],
                "city_cd": [["13101"]],
                "keyword_search_method": ["company"],
                "keyword_search_word": ["検索ワード"],
                "map_search_latitude": [35.6762],
                "map_search_longitude": [139.6503],
                "map_search_radius_km": [5.0],
                "selected_store_id": ["STORE_001"],
            }
        )

        # すべての検索条件が同時に存在
        assert df["prefecture_cd"].notna().any()
        assert df["keyword_search_method"].notna().any()
        assert df["map_search_latitude"].notna().any()
        assert df["selected_store_id"].notna().any()
