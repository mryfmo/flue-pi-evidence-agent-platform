"""
決済レコード（settlement_records）のデータコントラクト検証テスト

本テストは、Snowflake の決済統合テーブルから取得される決済レコードの
スキーマが期待された構造に従うことを確認する。

テスト対象：
  - キーカラム: site_id_cpid, company_code, store_code, settlement_use_date
  - メジャーカラム: pay_money_amount_total（数値型、非負）
  - ディメンションカラム: comnid, gender_code, nendai_code
  - 金額の有効性（非負、形式）
"""

import pytest
import pandas as pd
import numpy as np
from datetime import date
from decimal import Decimal


class TestSettlementRecordsSchemaValid:
    """
    有効な決済レコードスキーマ（valid/settlement_records.csv に基づく）
    """

    @pytest.fixture
    def settlement_records_valid_data(self):
        """
        基本的な有効な決済レコードのデータセット
        """
        return pd.DataFrame(
            {
                "site_id_cpid": ["SITE001", "SITE002", "SITE003", "SITE001", "SITE002"],
                "company_code": ["CP001", "CP002", "CP003", "CP001", "CP002"],
                "store_code": ["ST001", "ST002", "ST003", "ST001", "ST002"],
                "settlement_use_date": [
                    date(2026, 1, 15),
                    date(2026, 1, 16),
                    date(2026, 1, 17),
                    date(2026, 1, 18),
                    date(2026, 1, 19),
                ],
                "pay_money_amount_total": [1000, 2500, 1500, 3000, 5000],
                "settlement_integration_genre_large_classification": [
                    "食品",
                    "衣料",
                    "食品",
                    "衣料",
                    "食品",
                ],
                "comnid": ["USER001", "USER002", "USER001", "USER003", "USER002"],
                "gender_code": ["1", "2", "1", "2", None],
                "nendai_code": ["03", "05", "04", "07", None],
            }
        )

    def test_settlement_records_has_all_key_columns(self, settlement_records_valid_data):
        """
        決済レコードが必須のキーカラムをすべて含むことを確認

        キーカラム: site_id_cpid, company_code, store_code, settlement_use_date
        """
        df = settlement_records_valid_data

        required_columns = [
            "site_id_cpid",
            "company_code",
            "store_code",
            "settlement_use_date",
        ]

        for col in required_columns:
            assert col in df.columns, f"キーカラム {col} が欠落"

    def test_settlement_records_key_column_types(self, settlement_records_valid_data):
        """
        キーカラムが期待された型であることを確認

        - site_id_cpid: str
        - company_code: str
        - store_code: str
        - settlement_use_date: date
        """
        df = settlement_records_valid_data

        assert df["site_id_cpid"].dtype == "object"  # str型
        assert df["company_code"].dtype == "object"
        assert df["store_code"].dtype == "object"
        assert all(isinstance(d, date) for d in df["settlement_use_date"])

    def test_settlement_records_measure_column_pay_amount(
        self, settlement_records_valid_data
    ):
        """
        メジャーカラム pay_money_amount_total が数値型であることを確認
        """
        df = settlement_records_valid_data

        assert "pay_money_amount_total" in df.columns
        assert np.issubdtype(df["pay_money_amount_total"].dtype, np.number)
        # 具体値を確認
        assert df["pay_money_amount_total"].iloc[0] == 1000
        assert df["pay_money_amount_total"].iloc[2] == 1500

    def test_settlement_records_pay_amount_non_negative(
        self, settlement_records_valid_data
    ):
        """
        決済金額がすべて 0 以上であることを確認
        """
        df = settlement_records_valid_data

        # 負の値がないことを確認
        assert (df["pay_money_amount_total"] >= 0).all()
        # 具体値も確認
        assert len(df[df["pay_money_amount_total"] < 0]) == 0

    def test_settlement_records_dimension_columns(self, settlement_records_valid_data):
        """
        ディメンションカラムが存在することを確認

        - comnid: ユーザー識別子
        - gender_code: 性別コード（1=男性, 2=女性, NULL=不明）
        - nendai_code: 年代コード
        """
        df = settlement_records_valid_data

        assert "comnid" in df.columns
        assert "gender_code" in df.columns
        assert "nendai_code" in df.columns

        # comnidが存在すること
        assert df["comnid"].notna().all()
        # gender_code と nendai_code は NULL を許可
        assert df["gender_code"].isna().sum() >= 0
        assert df["nendai_code"].isna().sum() >= 0

    def test_settlement_records_gender_code_values(self, settlement_records_valid_data):
        """
        性別コードが期待される値（'1', '2', NULL）のみであることを確認
        """
        df = settlement_records_valid_data

        valid_gender_codes = {"1", "2"}
        non_null_codes = df["gender_code"].dropna()

        for code in non_null_codes:
            assert str(code) in valid_gender_codes

    def test_settlement_records_rows_non_empty(self, settlement_records_valid_data):
        """
        レコード数が 1 件以上であることを確認
        """
        df = settlement_records_valid_data

        assert len(df) > 0
        assert len(df) == 5  # テストデータは5件

    def test_settlement_records_no_duplicate_full_keys(
        self, settlement_records_valid_data
    ):
        """
        full キーの重複が許可されることを確認（複数レコードで同一キー可）

        # RISK: 決済レコードの性質上、同じ店舗・日付での複数決済は正常
        """
        df = settlement_records_valid_data

        # 重複キーが存在することを確認
        full_keys = list(
            zip(
                df["site_id_cpid"],
                df["company_code"],
                df["store_code"],
                df["settlement_use_date"],
            )
        )
        # テストデータは重複キーを含む可能性がある
        # それ自体は問題ではない
        assert len(full_keys) == len(df)

    def test_settlement_records_genre_classification_present(
        self, settlement_records_valid_data
    ):
        """
        大ジャンル分類カラムが存在し、値が入っていることを確認
        """
        df = settlement_records_valid_data

        assert "settlement_integration_genre_large_classification" in df.columns
        # すべてのレコードにジャンル値が存在
        assert df["settlement_integration_genre_large_classification"].notna().all()


class TestSettlementRecordsSchemaInvalid:
    """
    無効な決済レコード（invalid/*.csv に基づく）
    """

    def test_settlement_records_negative_amount(self):
        """
        負の決済金額が検出されることを確認

        # RISK: データ品質リスク
        無効な金額値（負数）がエラーハンドリング対象として
        識別可能であることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(2026, 1, 15)],
                "pay_money_amount_total": [-1000],  # 負の金額
            }
        )

        # 負の値を検出可能
        assert (df["pay_money_amount_total"] < 0).any()

    def test_settlement_records_non_numeric_amount(self):
        """
        非数値の決済金額が検出されることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(2026, 1, 15)],
                "pay_money_amount_total": ["1000円"],  # 文字列
            }
        )

        # 文字列型の金額
        assert df["pay_money_amount_total"].dtype == "object"
        assert isinstance(df["pay_money_amount_total"].iloc[0], str)

    def test_settlement_records_missing_key_column(self):
        """
        キーカラムが欠損している場合を検出

        例: site_id_cpid が欠損
        """
        df = pd.DataFrame(
            {
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(2026, 1, 15)],
                "pay_money_amount_total": [1000],
            }
        )

        # site_id_cpid が欠落
        assert "site_id_cpid" not in df.columns

    def test_settlement_records_null_measure_column(self):
        """
        メジャーカラム pay_money_amount_total が NULL の場合を検出
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(2026, 1, 15)],
                "pay_money_amount_total": [None],
            }
        )

        # NULL 値を検出
        assert df["pay_money_amount_total"].isna().any()

    def test_settlement_records_invalid_gender_code(self):
        """
        無効な性別コード（'3', '0', 'M' など）が検出されることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(2026, 1, 15)],
                "pay_money_amount_total": [1000],
                "gender_code": ["3"],  # 無効なコード
            }
        )

        valid_codes = {"1", "2"}
        invalid_code = df["gender_code"].iloc[0]
        assert invalid_code not in valid_codes


class TestSettlementRecordsSchemaEdgeCases:
    """
    エッジケース（edge/*.csv に基づく）
    """

    def test_settlement_records_zero_amount(self):
        """
        0円決済の処理を確認

        edge/settlement_records_zero_amount.csv参照
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(2026, 1, 15)],
                "pay_money_amount_total": [0],
            }
        )

        # 0円は有効な値
        assert df["pay_money_amount_total"].iloc[0] == 0
        assert (df["pay_money_amount_total"] >= 0).all()
        assert len(df) == 1

    def test_settlement_records_very_small_amount(self):
        """
        1円などの最小単位決済を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(2026, 1, 15)],
                "pay_money_amount_total": [0.01],  # 1銭
            }
        )

        assert df["pay_money_amount_total"].iloc[0] == 0.01
        assert df["pay_money_amount_total"].iloc[0] > 0

    def test_settlement_records_very_large_amount(self):
        """
        非常に大きな決済金額（数十億円）を処理できることを確認

        edge/settlement_statistics_large_values.csv参照
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(2026, 1, 15)],
                "pay_money_amount_total": [9999999999],  # 約100億円
            }
        )

        assert df["pay_money_amount_total"].iloc[0] == 9999999999
        assert len(df) == 1

    def test_settlement_records_boundary_date_historical(self):
        """
        歴史的な日付（1900年代）を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(1900, 1, 1)],
                "pay_money_amount_total": [1000],
            }
        )

        assert df["settlement_use_date"].iloc[0].year == 1900

    def test_settlement_records_boundary_date_future(self):
        """
        未来の日付（2099年）を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(2099, 12, 31)],
                "pay_money_amount_total": [1000],
            }
        )

        assert df["settlement_use_date"].iloc[0].year == 2099

    def test_settlement_records_multiple_transactions_same_store_same_day(self):
        """
        同じ店舗が同じ日に複数の決済を記録することを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001", "SITE001", "SITE001"],
                "company_code": ["CP001", "CP001", "CP001"],
                "store_code": ["ST001", "ST001", "ST001"],
                "settlement_use_date": [date(2026, 1, 15)] * 3,
                "pay_money_amount_total": [1000, 2000, 3000],
                "comnid": ["USER001", "USER002", "USER003"],
            }
        )

        # 同一キーで複数レコード
        same_key_records = df[
            (df["site_id_cpid"] == "SITE001")
            & (df["company_code"] == "CP001")
            & (df["store_code"] == "ST001")
            & (df["settlement_use_date"] == date(2026, 1, 15))
        ]
        assert len(same_key_records) == 3
        # 合計金額を計算可能
        assert same_key_records["pay_money_amount_total"].sum() == 6000

    def test_settlement_records_single_user_multiple_transactions(self):
        """
        同一ユーザーが複数回決済することを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001", "SITE002", "SITE003"],
                "company_code": ["CP001", "CP002", "CP003"],
                "store_code": ["ST001", "ST002", "ST003"],
                "settlement_use_date": [
                    date(2026, 1, 15),
                    date(2026, 1, 16),
                    date(2026, 1, 17),
                ],
                "pay_money_amount_total": [1000, 2000, 3000],
                "comnid": ["USER001", "USER001", "USER001"],  # 同一ユーザー
            }
        )

        user_records = df[df["comnid"] == "USER001"]
        assert len(user_records) == 3
        # ユーザーの合計金額
        assert user_records["pay_money_amount_total"].sum() == 6000


class TestSettlementRecordsDataIntegrity:
    """
    決済レコードのデータ整合性テスト
    """

    def test_settlement_records_all_columns_non_null_for_keys(self):
        """
        キーカラムがすべて非NULL であることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001", "SITE002"],
                "company_code": ["CP001", "CP002"],
                "store_code": ["ST001", "ST002"],
                "settlement_use_date": [date(2026, 1, 15), date(2026, 1, 16)],
                "pay_money_amount_total": [1000, 2000],
            }
        )

        # キーカラムがすべて非NULL
        assert df["site_id_cpid"].notna().all()
        assert df["company_code"].notna().all()
        assert df["store_code"].notna().all()
        assert df["settlement_use_date"].notna().all()

    def test_settlement_records_genre_classification_valid(self):
        """
        大ジャンル分類が妥当な値であることを確認
        """
        valid_genres = {
            "食品",
            "衣料",
            "電子機器",
            "サービス",
            "その他",
        }

        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001", "SITE002"],
                "company_code": ["CP001", "CP002"],
                "store_code": ["ST001", "ST002"],
                "settlement_use_date": [date(2026, 1, 15), date(2026, 1, 16)],
                "pay_money_amount_total": [1000, 2000],
                "settlement_integration_genre_large_classification": ["食品", "衣料"],
            }
        )

        for genre in df["settlement_integration_genre_large_classification"]:
            assert genre in valid_genres

    def test_settlement_records_decimal_precision(self):
        """
        決済金額が適切な精度（小数第2位）で保持されることを確認

        # RISK: データ品質リスク
        浮動小数点演算による誤差を避けるため、
        Decimal型または整数型での保持が望ましい
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "settlement_use_date": [date(2026, 1, 15)],
                "pay_money_amount_total": [1000.99],
            }
        )

        # 金額が数値型（float または int）
        assert np.issubdtype(df["pay_money_amount_total"].dtype, np.number)
        assert df["pay_money_amount_total"].iloc[0] == 1000.99
