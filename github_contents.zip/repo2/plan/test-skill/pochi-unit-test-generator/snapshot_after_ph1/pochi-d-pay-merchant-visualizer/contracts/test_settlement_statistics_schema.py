"""
決済統計データ（settlement_statistics）のデータコントラクト検証テスト

本テストは、app.lib.data_loader._graph_data.get_si_statistics の出力である
決済統計データが期待されたスキーマに従うことを確認する。

テスト対象：
  - 店舗数: integer型、非負
  - 決済合計金額: numeric型、非負
  - 決済平均金額: numeric型、非負
  - 決済回数: integer型、非負
  - ユニークユーザー数: integer型、非負
"""

import pytest
import pandas as pd
import numpy as np


class TestSettlementStatisticsSchemaValid:
    """
    有効な決済統計データセット（valid/settlement_statistics.csv に基づく）
    """

    @pytest.fixture
    def settlement_statistics_valid_data(self):
        """
        基本的な有効な決済統計データ
        """
        return pd.DataFrame(
            {
                "店舗数": [100, 150, 80],
                "決済合計金額": [5000000, 7500000, 4000000],
                "決済平均金額": [50000, 50000, 50000],
                "決済回数": [100, 150, 80],
                "ユニークユーザー数": [80, 120, 65],
            }
        )

    def test_settlement_statistics_has_all_columns(
        self, settlement_statistics_valid_data
    ):
        """
        決済統計が必須カラムをすべて含むことを確認
        """
        df = settlement_statistics_valid_data

        required_columns = [
            "店舗数",
            "決済合計金額",
            "決済平均金額",
            "決済回数",
            "ユニークユーザー数",
        ]

        # すべてのカラムが存在する
        assert list(df.columns) == required_columns

    def test_settlement_statistics_column_count_exact_match(
        self, settlement_statistics_valid_data
    ):
        """
        カラン数がちょうど5つであることを確認（予期しない追加カラムがない）
        """
        df = settlement_statistics_valid_data

        assert len(df.columns) == 5
        assert df.columns.tolist() == [
            "店舗数",
            "決済合計金額",
            "決済平均金額",
            "決済回数",
            "ユニークユーザー数",
        ]

    def test_settlement_statistics_store_count_integer(
        self, settlement_statistics_valid_data
    ):
        """
        店舗数が integer 型であることを確認
        """
        df = settlement_statistics_valid_data

        # NumPy整数型またはPandas整数型
        assert np.issubdtype(df["店舗数"].dtype, np.integer)
        # 具体値を確認
        assert df["店舗数"].iloc[0] == 100
        assert df["店舗数"].iloc[1] == 150
        assert df["店舗数"].iloc[2] == 80

    def test_settlement_statistics_payment_total_numeric(
        self, settlement_statistics_valid_data
    ):
        """
        決済合計金額が numeric 型（int または float）であることを確認
        """
        df = settlement_statistics_valid_data

        assert np.issubdtype(df["決済合計金額"].dtype, np.number)
        # 具体値を確認
        assert df["決済合計金額"].iloc[0] == 5000000
        assert df["決済合計金額"].iloc[1] == 7500000

    def test_settlement_statistics_payment_average_numeric(
        self, settlement_statistics_valid_data
    ):
        """
        決済平均金額が numeric 型であることを確認
        """
        df = settlement_statistics_valid_data

        assert np.issubdtype(df["決済平均金額"].dtype, np.number)
        # 具体値を確認
        assert df["決済平均金額"].iloc[0] == 50000

    def test_settlement_statistics_settlement_count_integer(
        self, settlement_statistics_valid_data
    ):
        """
        決済回数が integer 型であることを確認
        """
        df = settlement_statistics_valid_data

        assert np.issubdtype(df["決済回数"].dtype, np.integer)
        # 具体値を確認
        assert df["決済回数"].iloc[0] == 100
        assert df["決済回数"].iloc[1] == 150

    def test_settlement_statistics_unique_user_count_integer(
        self, settlement_statistics_valid_data
    ):
        """
        ユニークユーザー数が integer 型であることを確認
        """
        df = settlement_statistics_valid_data

        assert np.issubdtype(df["ユニークユーザー数"].dtype, np.integer)
        # 具体値を確認
        assert df["ユニークユーザー数"].iloc[0] == 80

    def test_settlement_statistics_all_values_non_negative(
        self, settlement_statistics_valid_data
    ):
        """
        すべてのメジャー値が非負であることを確認
        """
        df = settlement_statistics_valid_data

        assert (df["店舗数"] >= 0).all()
        assert (df["決済合計金額"] >= 0).all()
        assert (df["決済平均金額"] >= 0).all()
        assert (df["決済回数"] >= 0).all()
        assert (df["ユニークユーザー数"] >= 0).all()

    def test_settlement_statistics_average_calculation_relationship(
        self, settlement_statistics_valid_data
    ):
        """
        決済平均金額 = 決済合計金額 / 決済回数 の関係を確認

        # RISK: TST-001
        計算ロジックが正しく実装されていることを確認
        """
        df = settlement_statistics_valid_data

        for idx in range(len(df)):
            total = df["決済合計金額"].iloc[idx]
            count = df["決済回数"].iloc[idx]
            average = df["決済平均金額"].iloc[idx]

            if count > 0:
                # 計算値が一致
                expected_average = total / count
                assert abs(average - expected_average) < 1  # 1円未満の差を許容

    def test_settlement_statistics_unique_user_less_than_settlement_count(
        self, settlement_statistics_valid_data
    ):
        """
        ユニークユーザー数 <= 決済回数 の関係を確認

        # RISK: TST-001
        データ整合性：1ユーザーが複数回決済できるため、
        ユニークユーザー数は決済回数以下であるべき
        """
        df = settlement_statistics_valid_data

        assert (df["ユニークユーザー数"] <= df["決済回数"]).all()

    def test_settlement_statistics_row_count(self, settlement_statistics_valid_data):
        """
        行数が1行以上であることを確認
        """
        df = settlement_statistics_valid_data

        assert len(df) >= 1
        assert len(df) == 3  # テストデータ


class TestSettlementStatisticsSchemaInvalid:
    """
    無効な決済統計データセット（invalid/*.csv に基づく）
    """

    def test_settlement_statistics_negative_store_count(self):
        """
        負の店舗数が検出されることを確認

        # RISK: データ品質リスク
        """
        df = pd.DataFrame(
            {
                "店舗数": [-10],
                "決済合計金額": [1000000],
                "決済平均金額": [50000],
                "決済回数": [20],
                "ユニークユーザー数": [15],
            }
        )

        # 負の値を検出
        assert (df["店舗数"] < 0).any()

    def test_settlement_statistics_negative_total_amount(self):
        """
        負の決済合計金額が検出されることを確認
        """
        df = pd.DataFrame(
            {
                "店舗数": [100],
                "決済合計金額": [-1000000],  # 負の金額
                "決済平均金額": [50000],
                "決済回数": [20],
                "ユニークユーザー数": [15],
            }
        )

        assert (df["決済合計金額"] < 0).any()

    def test_settlement_statistics_negative_settlement_count(self):
        """
        負の決済回数が検出されることを確認
        """
        df = pd.DataFrame(
            {
                "店舗数": [100],
                "決済合計金額": [1000000],
                "決済平均金額": [50000],
                "決済回数": [-20],  # 負の回数
                "ユニークユーザー数": [15],
            }
        )

        assert (df["決済回数"] < 0).any()

    def test_settlement_statistics_negative_unique_user(self):
        """
        負のユニークユーザー数が検出されることを確認
        """
        df = pd.DataFrame(
            {
                "店舗数": [100],
                "決済合計金額": [1000000],
                "決済平均金額": [50000],
                "決済回数": [20],
                "ユニークユーザー数": [-5],  # 負の値
            }
        )

        assert (df["ユニークユーザー数"] < 0).any()

    def test_settlement_statistics_missing_column(self):
        """
        必須カラムが欠損している場合を検出

        例: ユニークユーザー数カラムが欠落
        """
        df = pd.DataFrame(
            {
                "店舗数": [100],
                "決済合計金額": [1000000],
                "決済平均金額": [50000],
                "決済回数": [20],
            }
        )

        # ユニークユーザー数カラムが欠落
        assert "ユニークユーザー数" not in df.columns

    def test_settlement_statistics_wrong_column_type(self):
        """
        カラムが期待されない型の場合を検出

        例: 店舗数が文字列型
        """
        df = pd.DataFrame(
            {
                "店舗数": ["100"],  # 文字列
                "決済合計金額": [1000000],
                "決済平均金額": [50000],
                "決済回数": [20],
                "ユニークユーザー数": [15],
            }
        )

        # 文字列型であることを確認（エラーケース）
        assert df["店舗数"].dtype == "object"
        assert not np.issubdtype(df["店舗数"].dtype, np.integer)

    def test_settlement_statistics_null_in_measure_column(self):
        """
        メジャーカラムに NULL が含まれている場合を検出
        """
        df = pd.DataFrame(
            {
                "店舗数": [100],
                "決済合計金額": [None],  # NULL
                "決済平均金額": [50000],
                "決済回数": [20],
                "ユニークユーザー数": [15],
            }
        )

        # NULL 値を検出
        assert df["決済合計金額"].isna().any()

    def test_settlement_statistics_invalid_average_calculation(self):
        """
        平均金額 = 合計金額 / 回数 の関係が破綻している場合を検出

        # RISK: TST-001
        計算ロジックエラーの検出
        """
        df = pd.DataFrame(
            {
                "店舗数": [100],
                "決済合計金額": [1000000],
                "決済平均金額": [1000],  # 期待値は 1000000 / 20 = 50000
                "決済回数": [20],
                "ユニークユーザー数": [15],
            }
        )

        total = df["決済合計金額"].iloc[0]
        count = df["決済回数"].iloc[0]
        average = df["決済平均金額"].iloc[0]

        if count > 0:
            expected_average = total / count
            # 実際の平均と計算値が一致しない
            assert abs(average - expected_average) > 100


class TestSettlementStatisticsSchemaEdgeCases:
    """
    エッジケース（edge/*.csv に基づく）
    """

    def test_settlement_statistics_all_zeros(self):
        """
        すべての値が0の統計データのエッジケース

        edge/settlement_statistics_zero.csv参照
        """
        df = pd.DataFrame(
            {
                "店舗数": [0],
                "決済合計金額": [0],
                "決済平均金額": [0],
                "決済回数": [0],
                "ユニークユーザー数": [0],
            }
        )

        assert (df["店舗数"] == 0).all()
        assert (df["決済合計金額"] == 0).all()
        assert len(df) == 1

    def test_settlement_statistics_large_values(self):
        """
        非常に大きな値を含むエッジケース

        edge/settlement_statistics_large_values.csv参照
        数十億の決済回数、高精度の金額
        """
        df = pd.DataFrame(
            {
                "店舗数": [999999],
                "決済合計金額": [9999999999999],  # 約100兆円
                "決済平均金額": [10000000],
                "決済回数": [999999],
                "ユニークユーザー数": [900000],
            }
        )

        assert df["店舗数"].iloc[0] == 999999
        assert df["決済合計金額"].iloc[0] == 9999999999999
        assert np.issubdtype(df["決済合計金額"].dtype, np.number)

    def test_settlement_statistics_single_store(self):
        """
        単一店舗のみの統計データ
        """
        df = pd.DataFrame(
            {
                "店舗数": [1],
                "決済合計金額": [100000],
                "決済平均金額": [10000],
                "決済回数": [10],
                "ユニークユーザー数": [8],
            }
        )

        assert df["店舗数"].iloc[0] == 1
        assert df["決済回数"].iloc[0] == 10

    def test_settlement_statistics_single_user(self):
        """
        単一ユーザーのみの統計データ
        """
        df = pd.DataFrame(
            {
                "店舗数": [50],
                "決済合計金額": [100000],
                "決済平均金額": [10000],
                "決済回数": [10],
                "ユニークユーザー数": [1],  # 1ユーザーのみ
            }
        )

        assert df["ユニークユーザー数"].iloc[0] == 1
        assert df["決済回数"].iloc[0] == 10

    def test_settlement_statistics_single_transaction(self):
        """
        単一決済のみの統計データ
        """
        df = pd.DataFrame(
            {
                "店舗数": [1],
                "決済合計金額": [50000],
                "決済平均金額": [50000],
                "決済回数": [1],  # 1決済のみ
                "ユニークユーザー数": [1],
            }
        )

        assert df["決済回数"].iloc[0] == 1
        assert df["決済平均金額"].iloc[0] == df["決済合計金額"].iloc[0]

    def test_settlement_statistics_high_precision_decimal(self):
        """
        高精度の小数値（銭単位）を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "店舗数": [100],
                "決済合計金額": [1000000.99],  # 小数第2位
                "決済平均金額": [10000.0099],  # 高精度
                "決済回数": [100],
                "ユニークユーザー数": [80],
            }
        )

        assert df["決済合計金額"].iloc[0] == 1000000.99
        assert df["決済平均金額"].iloc[0] == 10000.0099


class TestSettlementStatisticsDataIntegrity:
    """
    決済統計データの整合性テスト
    """

    def test_settlement_statistics_business_rule_store_count_maximum(self):
        """
        店舗数が決済回数を超えないことを確認

        # RISK: TST-001
        business-rules.json の「店舗数の重複排除」ルール：
        複数の決済レコードを持つ店舗も1件として計算される
        → 店舗数 <= 決済レコード数（理論的には交差テーブル検証が必要）
        """
        df = pd.DataFrame(
            {
                "店舗数": [100],
                "決済合計金額": [1000000],
                "決済平均金額": [50000],
                "決済回数": [50],  # 50決済
                "ユニークユーザー数": [40],
            }
        )

        # 店舗数が多い可能性あり（複数ユーザーが同じ店舗で決済）
        assert df["店舗数"].iloc[0] >= 0

    def test_settlement_statistics_user_count_maximum(self):
        """
        ユニークユーザー数が決済回数を超えないことを確認

        # RISK: TST-001
        business-rules.json の「ユニークユーザー数の集計」ルール：
        1ユーザーが複数決済できるため、ユーザー数 <= 決済回数
        """
        df = pd.DataFrame(
            {
                "店舗数": [100],
                "決済合計金額": [1000000],
                "決済平均金額": [50000],
                "決済回数": [100],
                "ユニークユーザー数": [120],  # 決済回数より多い（不可能）
            }
        )

        # データが不整合
        assert df["ユニークユーザー数"].iloc[0] > df["決済回数"].iloc[0]

    def test_settlement_statistics_average_within_reasonable_bounds(self):
        """
        平均金額が合計金額と件数に基づいて妥当な範囲にあることを確認
        """
        df = pd.DataFrame(
            {
                "店舗数": [100],
                "決済合計金額": [1000000],
                "決済平均金額": [50000],
                "決済回数": [20],
                "ユニークユーザー数": [15],
            }
        )

        total = df["決済合計金額"].iloc[0]
        count = df["決済回数"].iloc[0]
        average = df["決済平均金額"].iloc[0]

        # 平均は最小値と最大値の間にある
        # min_avg = total / count, max_avg = total / count（厳密には同じ）
        if count > 0:
            expected = total / count
            # 浮動小数点誤差を許容（1円未満）
            assert abs(average - expected) < 1
