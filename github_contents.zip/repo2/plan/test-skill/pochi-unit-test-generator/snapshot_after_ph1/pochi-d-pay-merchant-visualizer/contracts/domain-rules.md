# ドメインルール - d払い決済状況見える化ツール

**生成日**: 2026-05-01  
**アプリケーション**: d払い決済状況見える化ツール  
**フレームワーク**: Streamlit + Snowflake  
**対象バージョン**: main ブランチ時点

---

## 1. ドメイン概要

本アプリケーションは、d払い（NTTドコモが提供するスマートフォン決済サービス）の決済データを分析・可視化するツールです。加盟店ごとの決済統計、ユーザー属性別（性別・年代）の分析、地理的分析（緯度経度・住所）など、多次元の視点から決済動向を把握することができます。

### ドメイン領域
- **決済データ管理**: Snowflakeの複数テーブルを統合した決済統計の集計
- **ジオロケーション分析**: 加盟店の位置情報（緯度経度）を利用した地図表示
- **ユーザー属性分析**: 性別、年代といったユーザー属性別の集計
- **時系列分析**: 日別、時間帯別の決済動向分析
- **期間比較**: 前月対比などの期間比較による分析

---

## 2. 基本用語定義

### 決済関連用語

| 用語 | 定義 | 備考 |
|------|------|------|
| **決済レコード** | 1件の決済トランザクション | Snowflakeの決済統合テーブル（vw_dic_dnhd_settlement_integration）に対応 |
| **決済合計金額** | 1件の決済の金額（単位：円） | `pay_money_amount_total` カラム |
| **決済平均金額** | 条件内の全決済合計金額 ÷ 決済回数 | 1決済あたりの平均。ユーザーあたりの平均ではない |
| **決済回数** | 条件に該当するトランザクション数 | COUNT(決済レコード) |
| **ユニークユーザー数** | 異なるユーザー識別子（comnid）の数 | COUNT(DISTINCT comnid) |
| **店舗数** | 条件に該当する加盟店の数 | DISTINCT COUNT(site_id_cpid, company_code, store_code) |

### ユーザー属性関連

| 用語 | 定義 | 値範囲 | 備考 |
|------|------|--------|------|
| **comnid** | ユーザー識別子 | 文字列 | d払いのユーザー一意ID |
| **性別コード** | ユーザーの性別 | 1=男性、2=女性、NULL=不明 | データベースに記録されるコード値 |
| **年代コード** | ユーザーの年代 | 00=10代未満、01=10代、...、08=80代以上、NULL=不明 | データベースに記録されるコード値 |
| **大ジャンル** | 加盟店の業態分類 | 文字列（例：「飲食店」「コンビニ」） | 決済統合ジャンルマスタで定義 |

### 地理関連用語

| 用語 | 定義 | データソース |
|------|------|--------------|
| **都道府県コード** | 日本の47都道府県を識別 | ジオコーディングマスタ（pj_ml_geocoding_address_mst） |
| **市区町村コード** | 市区町村を識別 | ジオコーディングマスタ |
| **住所コード** | 丁目・番地レベルの住所コード | ジオコーディングマスタ |
| **字コード** | ジオコーディングマスタの字（あざ）レベルのコード | ジオコーディングマスタ |
| **緯度経度** | GPS座標（WGS84座標系） | 加盟店マスタ（latitude, longitude カラム） |

### 検索関連用語

| 用語 | 定義 | 検索対象 |
|------|------|---------|
| **住所条件検索** | 都道府県 + 市区町村で検索 | 加盟店の住所 |
| **キーワード検索** | テキストキーワードで検索 | 加盟店名、会社名、住所 |
| **地図検索** | 中心座標 + 半径(km)で検索 | 緯度経度から距離計算 |
| **店舗検索** | 特定店舗IDで検索 | 店舗マスタのID |

---

## 3. ビジネスルール詳細

### 3.1 入力条件の検証ルール

#### ルール1: 必須フィールド
```
start_date (開始日) と end_date (終了日) は必須フィールドである。
型: date
- 過去日付のみ許可
- start_date <= end_date の関係を満たす必要がある
```

**例**:
- OK: 2026-04-01 ～ 2026-04-30
- NG: 2026-05-01 ～ 2026-05-01 （同一日付は許可する場合と許可しない場合がある）
- NG: 2026-05-01 ～ 2026-04-30 （逆順）

#### ルール2: 検索条件の排他性
```
以下4つの検索条件のうち、最低1つ以上が必須である：
1) 住所条件: prefecture_cd + city_cd (必須)
2) キーワード条件: keyword_search_method + keyword_search_word (必須)
3) 地図条件: map_search_latitude + map_search_longitude + map_search_radius_km (必須)
4) 店舗条件: selected_store_id + store_center_latitude + store_center_longitude + store_search_radius_km (必須)

複数条件が同時に有効な場合の処理：
- 優先順位は実装で定義される（通常は住所条件 > キーワード > 地図 > 店舗）
- OR演算により組み合わせられるか、単一条件で制御するか仕様確認要
```

#### ルール3: 期間比較の一貫性
```
enable_comparison = True の場合:
  - comparison_start_date (比較開始日) は必須
  - comparison_end_date (比較終了日) は必須
  - 両者とも date型
  - comparison_start_date <= comparison_end_date

enable_comparison = False の場合:
  - 比較期間フィールドは無視される
  - UI側で比較フィールドを非表示にしてもよい
```

---

### 3.2 データ集計ルール

#### ルール4: 店舗数の計算
```
店舗数 = DISTINCT COUNT(site_id_cpid, company_code, store_code)

説明:
- 決済レコードが複数ある店舗も1件として計算
- 3要素の組み合わせで一意性を判定
- 同じ store_code でも company_code が異なれば別店舗
```

**実装例**:
```python
func.count(func.distinct(func.concat(baseTbl.c.site_id_cpid, 
                                     baseTbl.c.company_code, 
                                     baseTbl.c.store_code)))
```

#### ルール5: ユニークユーザー数の計算
```
ユニークユーザー数 = COUNT(DISTINCT comnid)

説明:
- 同じユーザーが複数回決済した場合も1ユーザーとして計算
- comnid（ユーザー識別子）で重複排除
- NULLユーザーは除外
```

#### ルール6: 平均決済金額の計算
```
決済平均金額 = SUM(pay_money_amount_total) / COUNT(決済レコード)

説明:
- 決済ごとの平均であり、ユーザーあたりの平均ではない
- 計算対象は条件に該当する全決済レコード
- 0件の場合は 0 または NULL を返す
```

#### ルール7: 性別コードの変換
```
データベースの性別コード値から日本語ラベルへの変換:

CASE
  WHEN gender_code = '1' THEN '男性'
  WHEN gender_code = '2' THEN '女性'
  ELSE '不明'
END

出力順序の保証: 男性 → 女性 → 不明（固定順）
```

**具体例**:
```
DB: 1, 1, 2, NULL, 2, 1
↓ 集計後
男性: 3件, 女性: 2件, 不明: 1件
```

#### ルール8: 年代コードの変換
```
データベースの年代コード値から日本語ラベルへの変換:

CASE
  WHEN nendai_code = '00' THEN '10代未満'
  WHEN nendai_code = '01' THEN '10代'
  WHEN nendai_code = '02' THEN '20代'
  ...
  WHEN nendai_code = '08' THEN '80代以上'
  ELSE '不明'
END

出力順序の保証: 10代未満 → 10代 → 20代 → ... → 80代以上 → 不明（固定順）
欠落グループの補完: fill_value=0 で0件として補完
```

**具体例**:
```
DB: 01, 03, 05, 05
↓ 集計後（10グループに展開・補完）
10代未満: 0, 10代: 1, 20代: 0, 30代: 1, 40代: 0, 50代: 2, 
60代: 0, 70代: 0, 80代以上: 0, 不明: 0
```

#### ルール9: 決済金額帯の分類
```
決済金額を5段階に分類:

CASE
  WHEN pay_money_amount_total >= 0 AND < 5000 THEN '0～5000円'
  WHEN pay_money_amount_total >= 5000 AND < 10000 THEN '5000～10000円'
  WHEN pay_money_amount_total >= 10000 AND < 15000 THEN '10000～15000円'
  WHEN pay_money_amount_total >= 15000 AND < 20000 THEN '15000～20000円'
  WHEN pay_money_amount_total >= 20000 THEN '2万円～'
END

出力時の加工: 先頭の順序プレフィックス（'1_', '2_'等）を削除
```

#### ルール10: 時間帯別集計
```
決済タイムスタンプから 時間 (hour) を抽出して集計:

EXTRACT(HOUR FROM settlement_timestamp) AS hour

結果: 0～23 の24グループ
備考: タイムゾーンはJST（日本標準時）固定
```

#### ルール11: 日別集計
```
決済タイムスタンプを日付（YYYY-MM-DD）にキャストして集計:

CAST(settlement_timestamp AS DATE) AS settlement_date

結果: 日付ごとの決済統計
備考: 時刻情報は破棄
```

#### ルール12: 業態別の上位店舗抽出
```
業態ごとに決済合計金額が多い順にランク付けし、各業態から上位N件を抽出:

ROW_NUMBER() OVER (
  PARTITION BY big_genre 
  ORDER BY pay_money_amount_total DESC
) AS rn

WHERE rn <= max_rows_per_industry (デフォルト: 50)

結果: 業態ごとに最大50件の店舗データ
```

---

### 3.3 キャッシング戦略

#### ルール13: 決済レコード基盤テーブルのキャッシュ
```
設定:
  - デコレータ: @st.cache_resource
  - 関数: create_settlement_records_query_from_input_conditions
  - TTL: 300秒（5分）
  - ハッシュ方式: Session: lambda session: id(session)

効果:
  - 同一InputConditions & 同一Sessionで複数呼び出し時は1度のDB問い合わせで済む
  - TTL後は自動無効化
  - Session オブジェクトのライフサイクルに付随

注意:
  - cache_resource は状態を持つオブジェクト（Session等）用
  - id() ハッシング戦略は脆弱な可能性（メモリ再割り当てで別IDになる可能性）
```

#### ルール14: 加盟店リストのキャッシュ
```
設定:
  - デコレータ: @st.cache_resource
  - 関数: get_merchant_store_list
  - TTL: 1800秒（30分）
  - ハッシュ方式: 環境キーを含める

効果:
  - 加盟店マスタデータの頻繁な再取得を削減
  - 30分ごとにマスタデータを更新
```

#### ルール15: 集計データのキャッシュ
```
設定:
  - デコレータ: @st.cache_data
  - 対象関数: get_si_statistics, get_si_agg_by_* など
  - TTL: 1800秒（30分）
  - persist: False

特殊ルール（get_si_statistics のみ）:
  - enable_comparison = False → use_session_cache = True（セッション内キャッシュ活用）
  - enable_comparison = True → use_session_cache = False（常に最新データ取得）
  
  理由: 比較対象データの鮮度確保

注意:
  - cache_data は計算結果（DataFrame等）用
  - 通常の cache_resource との混在使用は非標準だが機能
```

---

### 3.4 期間比較ロジック

#### ルール16: 比較フラグ判定
```
enable_comparison = False の場合:
  全ての *_comparison 関数は空DataFrame() を返す
  
if not conditions.enable_comparison:
    return pd.DataFrame()

効果:
  - UI側で比較表示を回避可能
  - DB負荷を低減
```

#### ルール17: 比較期間InputConditionsのコピー生成
```
比較期間データ取得時:
  comparison_conditions = dataclasses.replace(
    conditions,
    start_date=comparison_start_date,
    end_date=comparison_end_date,
    enable_comparison=False  # 無限ループ回避
  )

効果:
  - 他のフィルター条件（住所、業態、決済方式等）は共通
  - 日付範囲のみが異なるデータセットを比較可能

注意:
  - enable_comparison=False にリセットして無限ループを回避
```

---

### 3.5 環境別の動作分岐

#### ルール18: 加盟店マスタビュー選択
```
PochiEnvironment.stage に応じて参照先Viewを切り替え:

IF env.stage == 'prod':
    mst_view = PochiDbaraiCityStoreMaster  # 本番マスタ
ELSE:
    mst_view = PochiDbaraiCityStoreMasterDev  # 開発マスタ

環境定義:
  - prod: 本番環境 → PochiDbaraiCityStoreMaster
  - dev: 開発環境 → PochiDbaraiCityStoreMasterDev
  - test: テスト環境 → PochiDbaraiCityStoreMasterDev
```

---

### 3.6 データ整合性ルール

#### ルール19: NULL値の処理
```
集計時のNULL値の扱い:

性別別集計:
  - NULL は 'not null' フィルタで除外
  - 別途「不明」ラベルで NULL を代表可能

年代別集計:
  - NULL は 'not null' フィルタで除外
  - reindex() で「不明」グループを補完（fill_value=0）

大ジャンル集計:
  - NULL は除外、または「不明」カテゴリで表現
```

#### ルール20: 空の結果セット処理
```
集計結果が0件の場合:
  - pd.DataFrame() を返す
  - UI側で空判定: if not df.empty

一部の集計（性別、年代）では:
  - reindex() により欠落グループが fill_value=0 で補完される
  - 常に同じ列数・行数の結果が返される
```

#### ルール21: マージ操作の安全性
```
get_si_agg_by_industry_and_stores での LEFT OUTER JOIN:

result = pd.merge(
    aggregated_df,
    merchant_master_df,
    how='left',
    on=['site_id_cpid', 'company_code', 'store_code']
)

効果:
  - マスタに存在しないレコードは NULL 値で補完
  - マスタに存在する追加情報（住所、緯度経度等）を付加
```

---

## 4. ドメイン制約と前提条件

### 時間的制約
- **過去データのみ**: 未来日付での検索は不可
- **キャッシュTTL**: 決済レコード基盤テーブル=300秒、加盟店リスト=1800秒
- **比較期間の鮮度**: enable_comparison=True時は常に最新データ取得

### 空間的制約
- **地域範囲**: 日本国内のみ対応（47都道府県）
- **緯度経度**: WGS84座標系（GPS標準座標系）
- **距離計算**: 大円距離（Haversine公式）を想定

### ユーザー属性制約
- **性別**: 3値（男性、女性、不明）のみ
- **年代**: 10値（10代未満～80代以上、不明）
- **comnid**: NULLは集計対象外

---

## 5. 参考資料

- `data-contracts.json`: データコントラクト定義
- `business-rules.json`: ビジネスルール定義（詳細）
- `risk-catalog.md`: リスク分析・カタログ
- `test-viewpoints.json`: テスト観点の定義
- `scenarios.json`: テストシナリオの具体例

---

**作成日**: 2026-05-01  
**最終確認**: 確認モード（T1フェーズ）  
**次のステップ**: T2フェーズでのユニットテスト生成
