"""
地図表示用加盟店データ（merchant_map_data）のデータコントラクト検証テスト

本テストは、app.lib.merchant_map で生成される Folium 地図レンダリング用の
加盟店位置情報データが期待されたスキーマに従うことを確認する。

テスト対象：
  - キーカラム: site_id_cpid, company_code, store_code
  - 必須フィールド: latitude（緯度）, longitude（経度）, store_name（店舗名）
  - オプショナルフィールド: settlement_amount, user_count, category
  - 地理座標の有効性（緯度 -90～90, 経度 -180～180）
"""

import pytest
import pandas as pd
import numpy as np


class TestMerchantMapDataSchemaValid:
    """
    有効な地図用加盟店データセット（valid/merchant_store_list.csv に基づく）
    """

    @pytest.fixture
    def merchant_map_data_valid(self):
        """
        地図表示用加盟店データのサンプル
        """
        return pd.DataFrame(
            {
                "site_id_cpid": ["SITE001", "SITE002", "SITE003", "SITE004", "SITE005"],
                "company_code": ["CP001", "CP002", "CP003", "CP004", "CP005"],
                "store_code": ["ST001", "ST002", "ST003", "ST004", "ST005"],
                "store_name": ["東京店", "大阪店", "名古屋店", "福岡店", "札幌店"],
                "latitude": [35.6762, 34.6937, 35.1815, 33.5904, 43.0642],
                "longitude": [139.6503, 135.5023, 136.9066, 130.4017, 141.3469],
                "settlement_amount": [500000, 750000, 400000, 600000, 450000],
                "user_count": [400, 500, 320, 480, 360],
                "category": ["食品", "衣料", "食品", "電子機器", "サービス"],
            }
        )

    def test_merchant_map_data_has_key_columns(self, merchant_map_data_valid):
        """
        地図用加盟店データがキーカラムをすべて含むことを確認
        """
        df = merchant_map_data_valid

        key_columns = ["site_id_cpid", "company_code", "store_code"]
        for col in key_columns:
            assert col in df.columns

    def test_merchant_map_data_has_required_fields(self, merchant_map_data_valid):
        """
        地図表示に必須のフィールドを含むことを確認

        必須フィールド: latitude, longitude, store_name
        """
        df = merchant_map_data_valid

        required_fields = ["latitude", "longitude", "store_name"]
        for field in required_fields:
            assert field in df.columns

    def test_merchant_map_data_latitude_valid_range(self, merchant_map_data_valid):
        """
        緯度がすべて -90～90 の範囲内であることを確認
        """
        df = merchant_map_data_valid

        assert (df["latitude"] >= -90).all()
        assert (df["latitude"] <= 90).all()

    def test_merchant_map_data_longitude_valid_range(self, merchant_map_data_valid):
        """
        経度がすべて -180～180 の範囲内であることを確認
        """
        df = merchant_map_data_valid

        assert (df["longitude"] >= -180).all()
        assert (df["longitude"] <= 180).all()

    def test_merchant_map_data_coordinates_float_type(self, merchant_map_data_valid):
        """
        座標値が float 型であることを確認
        """
        df = merchant_map_data_valid

        assert np.issubdtype(df["latitude"].dtype, np.floating)
        assert np.issubdtype(df["longitude"].dtype, np.floating)

    def test_merchant_map_data_store_name_non_empty(self, merchant_map_data_valid):
        """
        店舗名がすべて空でないことを確認
        """
        df = merchant_map_data_valid

        assert df["store_name"].notna().all()
        # 空文字列ではないことを確認
        assert not (df["store_name"] == "").any()

    def test_merchant_map_data_store_name_type(self, merchant_map_data_valid):
        """
        店舗名が文字列型であることを確認
        """
        df = merchant_map_data_valid

        for name in df["store_name"]:
            assert isinstance(name, str)

    def test_merchant_map_data_optional_fields_present(self, merchant_map_data_valid):
        """
        オプショナルフィールド (settlement_amount, user_count, category) が存在することを確認
        """
        df = merchant_map_data_valid

        optional_fields = ["settlement_amount", "user_count", "category"]
        for field in optional_fields:
            assert field in df.columns

    def test_merchant_map_data_settlement_amount_numeric(
        self, merchant_map_data_valid
    ):
        """
        settlement_amount が numeric 型であることを確認
        """
        df = merchant_map_data_valid

        assert np.issubdtype(df["settlement_amount"].dtype, np.number)
        # 具体値を確認
        assert df["settlement_amount"].iloc[0] == 500000

    def test_merchant_map_data_user_count_numeric(self, merchant_map_data_valid):
        """
        user_count が numeric 型であることを確認
        """
        df = merchant_map_data_valid

        assert np.issubdtype(df["user_count"].dtype, np.number)

    def test_merchant_map_data_category_string(self, merchant_map_data_valid):
        """
        category が文字列型であることを確認
        """
        df = merchant_map_data_valid

        for cat in df["category"]:
            assert isinstance(cat, str)

    def test_merchant_map_data_row_count(self, merchant_map_data_valid):
        """
        行数が1行以上であることを確認
        """
        df = merchant_map_data_valid

        assert len(df) >= 1
        assert len(df) == 5


class TestMerchantMapDataSchemaInvalid:
    """
    無効な地図用加盟店データセット（invalid/*.csv に基づく）
    """

    def test_merchant_map_data_invalid_latitude_out_of_range(self):
        """
        緯度が 91 など範囲外の場合を検出

        # RISK: DATA品質リスク
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["テスト店"],
                "latitude": [91.0],  # 範囲外
                "longitude": [135.0],
            }
        )

        # 範囲外の緯度を検出
        assert (df["latitude"] > 90).any()

    def test_merchant_map_data_invalid_longitude_out_of_range(self):
        """
        経度が 181 など範囲外の場合を検出
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["テスト店"],
                "latitude": [35.0],
                "longitude": [181.0],  # 範囲外
            }
        )

        assert (df["longitude"] > 180).any()

    def test_merchant_map_data_invalid_coordinate_non_numeric(self):
        """
        座標値が非数値の場合を検出
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["テスト店"],
                "latitude": ["35.6762"],  # 文字列
                "longitude": [139.6503],
            }
        )

        # 文字列型
        assert df["latitude"].dtype == "object"

    def test_merchant_map_data_missing_store_name(self):
        """
        店舗名が欠損している場合を検出
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "latitude": [35.6762],
                "longitude": [139.6503],
            }
        )

        # store_name カラムが欠落
        assert "store_name" not in df.columns

    def test_merchant_map_data_null_store_name(self):
        """
        店舗名が NULL の場合を検出
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": [None],  # NULL
                "latitude": [35.6762],
                "longitude": [139.6503],
            }
        )

        # NULL 値を検出
        assert df["store_name"].isna().any()

    def test_merchant_map_data_empty_store_name(self):
        """
        店舗名が空文字列の場合を検出
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": [""],  # 空文字列
                "latitude": [35.6762],
                "longitude": [139.6503],
            }
        )

        # 空文字列を検出
        assert (df["store_name"] == "").any()

    def test_merchant_map_data_negative_settlement_amount(self):
        """
        負の決済金額を検出
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "store_name": ["テスト店"],
                "latitude": [35.6762],
                "longitude": [139.6503],
                "settlement_amount": [-100000],  # 負の値
            }
        )

        assert (df["settlement_amount"] < 0).any()

    def test_merchant_map_data_negative_user_count(self):
        """
        負のユーザー数を検出
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "store_name": ["テスト店"],
                "latitude": [35.6762],
                "longitude": [139.6503],
                "user_count": [-10],  # 負の値
            }
        )

        assert (df["user_count"] < 0).any()


class TestMerchantMapDataSchemaEdgeCases:
    """
    エッジケース（edge/*.csv に基づく）
    """

    def test_merchant_map_data_boundary_coordinates_north_pole(self):
        """
        北極の座標（緯度 90.0）を処理できることを確認

        edge/merchant_store_list_boundary_coordinates.csv参照
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["北極点"],
                "latitude": [90.0],
                "longitude": [0.0],
            }
        )

        assert df["latitude"].iloc[0] == 90.0
        assert len(df) == 1

    def test_merchant_map_data_boundary_coordinates_south_pole(self):
        """
        南極の座標（緯度 -90.0）を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["南極点"],
                "latitude": [-90.0],
                "longitude": [0.0],
            }
        )

        assert df["latitude"].iloc[0] == -90.0

    def test_merchant_map_data_boundary_coordinates_date_line_east(self):
        """
        国際日付変更線の東側（経度 180.0）を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["テスト店"],
                "latitude": [0.0],
                "longitude": [180.0],
            }
        )

        assert df["longitude"].iloc[0] == 180.0

    def test_merchant_map_data_boundary_coordinates_date_line_west(self):
        """
        国際日付変更線の西側（経度 -180.0）を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["テスト店"],
                "latitude": [0.0],
                "longitude": [-180.0],
            }
        )

        assert df["longitude"].iloc[0] == -180.0

    def test_merchant_map_data_boundary_coordinates_equator(self):
        """
        赤道上（緯度 0.0）の座標を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["赤道上"],
                "latitude": [0.0],
                "longitude": [0.0],
            }
        )

        assert df["latitude"].iloc[0] == 0.0
        assert df["longitude"].iloc[0] == 0.0

    def test_merchant_map_data_special_store_names(self):
        """
        特殊文字や長い名前を含む店舗データのエッジケース

        edge/merchant_store_list_special_names.csv参照
        """
        special_names = [
            "東京・渋谷店",
            "日本語＆English",
            "café-français",
            "超長い超長い超長い超長い超長い超長い超長い超長い超長い店舗名",
        ]

        df = pd.DataFrame(
            {
                "site_id_cpid": [f"SITE{i:03d}" for i in range(1, len(special_names) + 1)],
                "company_code": ["CP001"] * len(special_names),
                "store_code": [f"ST{i:03d}" for i in range(1, len(special_names) + 1)],
                "store_name": special_names,
                "latitude": [35.0] * len(special_names),
                "longitude": [135.0] * len(special_names),
            }
        )

        for i, name in enumerate(special_names):
            assert df["store_name"].iloc[i] == name
            assert len(df["store_name"].iloc[i]) > 0

    def test_merchant_map_data_high_precision_coordinates(self):
        """
        高精度の座標値（小数第4位以上）を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["高精度店"],
                "latitude": [35.67623456],  # 高精度
                "longitude": [139.65034567],
            }
        )

        assert df["latitude"].iloc[0] == 35.67623456
        assert df["longitude"].iloc[0] == 139.65034567

    def test_merchant_map_data_zero_settlement_zero_users(self):
        """
        決済金額とユーザー数がともに0のエッジケース
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["テスト店"],
                "latitude": [35.6762],
                "longitude": [139.6503],
                "settlement_amount": [0],
                "user_count": [0],
            }
        )

        assert df["settlement_amount"].iloc[0] == 0
        assert df["user_count"].iloc[0] == 0

    def test_merchant_map_data_very_large_settlement_amount(self):
        """
        非常に大きな決済金額を処理できることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["テスト店"],
                "latitude": [35.6762],
                "longitude": [139.6503],
                "settlement_amount": [9999999999999],  # 約100兆円
            }
        )

        assert df["settlement_amount"].iloc[0] == 9999999999999


class TestMerchantMapDataGeographicValidity:
    """
    地図表示用データの地理的妥当性テスト
    """

    def test_merchant_map_data_clustering_possible(self):
        """
        クラスタリング機能が正しく機能するために必要な座標情報を確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001", "SITE002", "SITE003"],
                "company_code": ["CP001", "CP002", "CP003"],
                "store_code": ["ST001", "ST002", "ST003"],
                "store_name": ["店1", "店2", "店3"],
                "latitude": [35.6762, 35.6763, 35.6764],
                "longitude": [139.6503, 139.6504, 139.6505],
            }
        )

        # すべてのレコードに座標が存在
        assert df["latitude"].notna().all()
        assert df["longitude"].notna().all()

        # 座標がすべて有効範囲内
        assert (df["latitude"] >= -90).all()
        assert (df["latitude"] <= 90).all()

    def test_merchant_map_data_point_pin_display(self):
        """
        地点ピン表示に必要な座標データが完全であることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": ["SITE001"],
                "company_code": ["CP001"],
                "store_code": ["ST001"],
                "store_name": ["テスト店"],
                "latitude": [35.6762],
                "longitude": [139.6503],
            }
        )

        # Folium で地点ピン表示可能
        assert df["latitude"].notna().all()
        assert df["longitude"].notna().all()
        assert df["store_name"].notna().all()

    def test_merchant_map_data_center_coordinates_valid(self):
        """
        地図の中心座標として使用可能であることを確認
        """
        df = pd.DataFrame(
            {
                "site_id_cpid": [
                    "SITE001",
                    "SITE002",
                    "SITE003",
                    "SITE004",
                    "SITE005",
                ],
                "latitude": [35.6762, 34.6937, 35.1815, 33.5904, 43.0642],
                "longitude": [139.6503, 135.5023, 136.9066, 130.4017, 141.3469],
                "store_name": [
                    "東京店",
                    "大阪店",
                    "名古屋店",
                    "福岡店",
                    "札幌店",
                ],
            }
        )

        # 中心座標を計算可能
        center_lat = df["latitude"].mean()
        center_lon = df["longitude"].mean()

        assert -90 <= center_lat <= 90
        assert -180 <= center_lon <= 180
