"""
RenderOptions（描画オプション）のデータコントラクト検証テスト

本テストは、app.lib.models.RenderOptions のデータクラスが
UI描画の制御オプションを正しく保持することを確認する。

テスト対象：
  - enable_merchant_map: bool型（デフォルト False）
  - enable_acctid_list_download: bool型（デフォルト False）
  - enable_analysis_data_download: bool型（デフォルト False）
  - enable_graphs: bool型（デフォルト False）
  - enable_store_information_display: bool型（デフォルト False）
  - show_map_point_pin: bool型（デフォルト True）
  - payment_method_list: List[str]（オプショナル）
"""

import pytest
import pandas as pd


class TestRenderOptionsSchemaValid:
    """
    有効なRenderOptionsデータセット（valid/render_options.csv に基づく）
    """

    @pytest.fixture
    def render_options_valid_data(self):
        """
        基本的な有効なRenderOptionsデータ
        """
        return pd.DataFrame(
            {
                "enable_merchant_map": [True, False, True],
                "enable_acctid_list_download": [False, True, False],
                "enable_analysis_data_download": [True, False, True],
                "enable_graphs": [True, True, False],
                "enable_store_information_display": [False, False, True],
                "show_map_point_pin": [True, True, False],
                "payment_method_list": [
                    ["card", "points"],
                    ["cash"],
                    None,
                ],
            }
        )

    def test_render_options_has_all_bool_fields(self, render_options_valid_data):
        """
        RenderOptionsがすべてのブール型フィールドを含むことを確認
        """
        df = render_options_valid_data

        bool_fields = [
            "enable_merchant_map",
            "enable_acctid_list_download",
            "enable_analysis_data_download",
            "enable_graphs",
            "enable_store_information_display",
            "show_map_point_pin",
        ]

        for field in bool_fields:
            assert field in df.columns

    def test_render_options_bool_field_types(self, render_options_valid_data):
        """
        すべてのブール型フィールドが bool 値を持つことを確認
        """
        df = render_options_valid_data

        bool_fields = [
            "enable_merchant_map",
            "enable_acctid_list_download",
            "enable_analysis_data_download",
            "enable_graphs",
            "enable_store_information_display",
            "show_map_point_pin",
        ]

        for field in bool_fields:
            # すべてのレコードが True または False
            assert df[field].dtype == bool
            for value in df[field]:
                assert isinstance(value, (bool, pd.NA)) or value in [True, False]

    def test_render_options_merchant_map_enabled_disabled(
        self, render_options_valid_data
    ):
        """
        enable_merchant_map が True/False の両方で動作することを確認
        """
        df = render_options_valid_data

        # True と False の両方が存在
        assert df["enable_merchant_map"].eq(True).any()
        assert df["enable_merchant_map"].eq(False).any()

    def test_render_options_acctid_list_download_control(
        self, render_options_valid_data
    ):
        """
        enable_acctid_list_download フラグが機能することを確認
        """
        df = render_options_valid_data

        # フラグが True の場合、ダウンロード機能が有効
        download_enabled = df[df["enable_acctid_list_download"] == True]
        assert len(download_enabled) > 0

        # フラグが False の場合、ダウンロード機能が無効
        download_disabled = df[df["enable_acctid_list_download"] == False]
        assert len(download_disabled) > 0

    def test_render_options_analysis_data_download_control(
        self, render_options_valid_data
    ):
        """
        enable_analysis_data_download フラグが機能することを確認
        """
        df = render_options_valid_data

        assert df["enable_analysis_data_download"].eq(True).any()
        assert df["enable_analysis_data_download"].eq(False).any()

    def test_render_options_graphs_control(self, render_options_valid_data):
        """
        enable_graphs フラグが機能することを確認
        """
        df = render_options_valid_data

        assert df["enable_graphs"].eq(True).any()
        assert df["enable_graphs"].eq(False).any()

    def test_render_options_store_information_control(
        self, render_options_valid_data
    ):
        """
        enable_store_information_display フラグが機能することを確認
        """
        df = render_options_valid_data

        assert df["enable_store_information_display"].eq(True).any()
        assert df["enable_store_information_display"].eq(False).any()

    def test_render_options_map_point_pin_default_true(self, render_options_valid_data):
        """
        show_map_point_pin がデフォルト True で、False に変更可能であることを確認
        """
        df = render_options_valid_data

        # True と False の両方が存在
        assert df["show_map_point_pin"].eq(True).any()
        assert df["show_map_point_pin"].eq(False).any()

    def test_render_options_payment_method_list_optional(
        self, render_options_valid_data
    ):
        """
        payment_method_list がオプショナルフィールドであることを確認
        NULL 値を許可
        """
        df = render_options_valid_data

        # 一部は NULL
        assert df["payment_method_list"].isna().any()
        # 一部は値を持つ
        assert df["payment_method_list"].notna().any()

    def test_render_options_payment_method_list_structure(
        self, render_options_valid_data
    ):
        """
        payment_method_list が文字列のリストであることを確認
        """
        df = render_options_valid_data

        non_null_values = df["payment_method_list"].dropna()
        for value in non_null_values:
            assert isinstance(value, list)
            # リスト内のすべての要素が文字列
            for item in value:
                assert isinstance(item, str)

    def test_render_options_row_count(self, render_options_valid_data):
        """
        行数が1行以上であることを確認
        """
        df = render_options_valid_data

        assert len(df) >= 1
        assert len(df) == 3


class TestRenderOptionsSchemaInvalid:
    """
    無効なRenderOptionsデータセット（invalid/render_options_invalid_bool.csv に基づく）
    """

    def test_render_options_invalid_bool_yes_no(self):
        """
        ブール値に 'yes' / 'no' を使用すると検出される

        invalid/render_options_invalid_bool.csv参照
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": ["yes"],  # 文字列
                "enable_graphs": ["no"],
            }
        )

        # 文字列型のため、bool型ではない
        assert df["enable_merchant_map"].dtype == "object"
        assert df["enable_merchant_map"].iloc[0] == "yes"

    def test_render_options_invalid_bool_uppercase_true_false(self):
        """
        大文字の 'True' / 'False' が文字列として扱われることを確認
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": ["True"],  # 大文字
                "enable_graphs": ["False"],
            }
        )

        # 文字列型
        assert df["enable_merchant_map"].dtype == "object"
        assert df["enable_merchant_map"].iloc[0] == "True"

    def test_render_options_invalid_bool_numeric_1_0(self):
        """
        数値 1/0 をブール値として解釈される可能性を確認
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": [1],  # 数値
                "enable_graphs": [0],
            }
        )

        # int型
        assert df["enable_merchant_map"].dtype == "int64"
        assert df["enable_merchant_map"].iloc[0] == 1

    def test_render_options_invalid_bool_ambiguous_values(self):
        """
        あいまいなブール値（'T', 'F', 'Y', 'N'）が検出される
        """
        ambiguous_values = ["T", "F", "Y", "N", "t", "f", "y", "n"]

        for value in ambiguous_values:
            df = pd.DataFrame(
                {
                    "enable_merchant_map": [value],
                }
            )

            # 文字列型のため、bool型ではない
            assert df["enable_merchant_map"].dtype == "object"
            assert not isinstance(df["enable_merchant_map"].iloc[0], bool)

    def test_render_options_missing_bool_field(self):
        """
        必須のブール型フィールドが欠損している場合を検出
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": [True],
                # enable_acctid_list_download が欠落
                "enable_analysis_data_download": [True],
            }
        )

        # enable_acctid_list_download カラムが存在しない
        assert "enable_acctid_list_download" not in df.columns

    def test_render_options_invalid_payment_method_structure(self):
        """
        payment_method_list が期待されない構造の場合を検出
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": [True, False],
                "payment_method_list": ["card", "points"],  # リストではなく文字列
            }
        )

        # 文字列型（リストではない）
        assert isinstance(df["payment_method_list"].iloc[0], str)
        assert not isinstance(df["payment_method_list"].iloc[0], list)


class TestRenderOptionsSchemaEdgeCases:
    """
    エッジケース（edge/*.csv に基づく）
    """

    def test_render_options_all_false(self):
        """
        すべての機能が無効化されたRenderOptionsのエッジケース

        edge/render_options_all_false.csv参照
        最小限のUI構成での動作確認
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": [False],
                "enable_acctid_list_download": [False],
                "enable_analysis_data_download": [False],
                "enable_graphs": [False],
                "enable_store_information_display": [False],
                "show_map_point_pin": [False],
                "payment_method_list": [None],
            }
        )

        # すべてが False
        assert (df["enable_merchant_map"] == False).all()
        assert (df["enable_graphs"] == False).all()
        # payment_method_list は NULL
        assert df["payment_method_list"].isna().all()
        assert len(df) == 1

    def test_render_options_all_true(self):
        """
        すべての機能が有効化されたRenderOptionsのエッジケース

        edge/render_options_all_true.csv参照
        全機能有効時のUI動作確認
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": [True],
                "enable_acctid_list_download": [True],
                "enable_analysis_data_download": [True],
                "enable_graphs": [True],
                "enable_store_information_display": [True],
                "show_map_point_pin": [True],
                "payment_method_list": [["card", "points", "cash"]],
            }
        )

        # すべてが True
        assert (df["enable_merchant_map"] == True).all()
        assert (df["enable_acctid_list_download"] == True).all()
        assert (df["enable_graphs"] == True).all()
        # payment_method_list に値が存在
        assert df["payment_method_list"].notna().all()
        assert len(df["payment_method_list"].iloc[0]) == 3

    def test_render_options_selective_features(self):
        """
        一部の機能のみが有効な複数パターンのエッジケース
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": [True, False, True, False],
                "enable_graphs": [True, True, False, False],
                "enable_acctid_list_download": [False, True, True, False],
                "enable_analysis_data_download": [False, False, True, True],
                "enable_store_information_display": [False, False, False, False],
                "show_map_point_pin": [True, True, False, True],
            }
        )

        # 各パターンで異なる組み合わせ
        assert len(df) == 4
        # 最初のパターン：地図とグラフのみ有効
        assert df["enable_merchant_map"].iloc[0] == True
        assert df["enable_graphs"].iloc[0] == True
        assert df["enable_acctid_list_download"].iloc[0] == False

    def test_render_options_empty_payment_method_list(self):
        """
        payment_method_list が空リストの場合を確認
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": [True],
                "enable_graphs": [True],
                "payment_method_list": [[]],  # 空リスト
            }
        )

        # 空リストが存在する
        assert isinstance(df["payment_method_list"].iloc[0], list)
        assert len(df["payment_method_list"].iloc[0]) == 0

    def test_render_options_large_payment_method_list(self):
        """
        payment_method_list に大量の要素がある場合を確認
        """
        large_list = [f"method_{i}" for i in range(100)]

        df = pd.DataFrame(
            {
                "enable_merchant_map": [True],
                "payment_method_list": [large_list],
            }
        )

        assert len(df["payment_method_list"].iloc[0]) == 100

    def test_render_options_special_characters_in_payment_methods(self):
        """
        payment_method_list に特殊文字を含むメソッド名がある場合を確認
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": [True],
                "payment_method_list": [
                    [
                        "credit-card",
                        "debit_card",
                        "QR.Code",
                        "digital@wallet",
                    ]
                ],
            }
        )

        methods = df["payment_method_list"].iloc[0]
        assert all(isinstance(m, str) for m in methods)
        assert "credit-card" in methods
        assert "digital@wallet" in methods


class TestRenderOptionsUIBehavior:
    """
    RenderOptionsの UI 制御動作に関するテスト
    """

    def test_render_options_controls_map_visibility(self):
        """
        enable_merchant_map フラグで地図表示を制御可能であることを確認

        # RISK: ARCH-001
        UI制御フラグが正しく機能することを確認
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": [True, False, True],
            }
        )

        # True の場合、地図を表示
        map_enabled = df[df["enable_merchant_map"] == True]
        assert len(map_enabled) > 0

        # False の場合、地図を非表示
        map_disabled = df[df["enable_merchant_map"] == False]
        assert len(map_disabled) > 0

    def test_render_options_controls_download_visibility(self):
        """
        enable_acctid_list_download と enable_analysis_data_download が
        ダウンロード機能を独立制御できることを確認
        """
        df = pd.DataFrame(
            {
                "enable_acctid_list_download": [True, False, True, False],
                "enable_analysis_data_download": [True, True, False, False],
            }
        )

        # ユーザーリストのみ有効
        user_list_only = df[
            (df["enable_acctid_list_download"] == True)
            & (df["enable_analysis_data_download"] == False)
        ]
        assert len(user_list_only) > 0

        # 分析データのみ有効
        analysis_only = df[
            (df["enable_acctid_list_download"] == False)
            & (df["enable_analysis_data_download"] == True)
        ]
        assert len(analysis_only) > 0

    def test_render_options_controls_graph_visibility(self):
        """
        enable_graphs フラグがグラフ表示を制御することを確認
        """
        df = pd.DataFrame(
            {
                "enable_graphs": [True, True, False, False],
            }
        )

        graphs_shown = df[df["enable_graphs"] == True]
        assert len(graphs_shown) > 0

        graphs_hidden = df[df["enable_graphs"] == False]
        assert len(graphs_hidden) > 0

    def test_render_options_independent_feature_control(self):
        """
        各機能フラグが相互に独立して制御可能であることを確認
        """
        df = pd.DataFrame(
            {
                "enable_merchant_map": [True],
                "enable_acctid_list_download": [False],
                "enable_analysis_data_download": [True],
                "enable_graphs": [True],
                "enable_store_information_display": [False],
                "show_map_point_pin": [True],
            }
        )

        # 複数の機能が異なる状態で共存可能
        options = df.iloc[0]
        assert options["enable_merchant_map"] == True
        assert options["enable_acctid_list_download"] == False
        assert options["enable_analysis_data_download"] == True
        assert options["enable_graphs"] == True
