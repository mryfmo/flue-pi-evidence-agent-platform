"""
多次元集計データ（aggregations_by_dimension）のデータコントラクト検証テスト

本テストは、app.lib.data_loader._graph_data の集計関数群が出力する
業態別、性別別、年代別などの多次元集計データが期待されたスキーマに従うことを確認する。

テスト対象：
  - 業態別集計（get_si_agg_by_industry）
  - 性別別集計（get_si_agg_by_gender）
  - 年代別集計（get_si_agg_by_nendai）
  - 決済金額帯別集計（get_si_agg_by_payment_amount）
"""

import pytest
import pandas as pd
import numpy as np


class TestAggregationsByIndustrySchema:
    """
    業態別集計データの検証テスト（valid/aggregations_by_industry.csv に基づく）
    """

    @pytest.fixture
    def aggregations_by_industry_data(self):
        """
        業態別集計データのサンプル
        """
        return pd.DataFrame(
            {
                "業態": ["食品", "衣料", "電子機器"],
                "店舗数": [100, 150, 80],
                "決済合計金額": [5000000, 7500000, 4000000],
                "決済回数": [500, 600, 400],
                "ユニークユーザー数": [400, 500, 320],
            }
        )

    def test_aggregations_by_industry_has_required_columns(
        self, aggregations_by_industry_data
    ):
        """
        業態別集計が必須カラムをすべて含むことを確認
        """
        df = aggregations_by_industry_data

        required_columns = ["業態", "店舗数", "決済合計金額", "決済回数", "ユニークユーザー数"]
        assert list(df.columns) == required_columns

    def test_aggregations_by_industry_row_count(self, aggregations_by_industry_data):
        """
        業態別集計が複数の業態を含むことを確認
        """
        df = aggregations_by_industry_data

        assert len(df) == 3
        # インデックスカラム "業態" の値を確認
        assert df["業態"].iloc[0] == "食品"
        assert df["業態"].iloc[1] == "衣料"

    def test_aggregations_by_industry_numeric_values(self, aggregations_by_industry_data):
        """
        メジャー値がすべて numeric 型であることを確認
        """
        df = aggregations_by_industry_data

        measure_columns = ["店舗数", "決済合計金額", "決済回数", "ユニークユーザー数"]
        for col in measure_columns:
            assert np.issubdtype(df[col].dtype, np.number)

    def test_aggregations_by_industry_values_non_negative(
        self, aggregations_by_industry_data
    ):
        """
        すべてのメジャー値が非負であることを確認
        """
        df = aggregations_by_industry_data

        assert (df["店舗数"] >= 0).all()
        assert (df["決済合計金額"] >= 0).all()
        assert (df["決済回数"] >= 0).all()
        assert (df["ユニークユーザー数"] >= 0).all()

    def test_aggregations_by_industry_user_count_less_than_settlement(
        self, aggregations_by_industry_data
    ):
        """
        ユニークユーザー数 <= 決済回数 の関係を確認

        # RISK: TST-001
        business-rules.json の集計ルール：
        1ユーザーが複数決済できるため、ユーザー数 <= 決済回数
        """
        df = aggregations_by_industry_data

        assert (df["ユニークユーザー数"] <= df["決済回数"]).all()


class TestAggregationsByGenderSchema:
    """
    性別別集計データの検証テスト（valid/aggregations_by_gender.csv に基づく）
    """

    @pytest.fixture
    def aggregations_by_gender_data(self):
        """
        性別別集計データのサンプル
        """
        return pd.DataFrame(
            {
                "性別": ["男性", "女性", "不明"],
                "店舗数": [100, 120, 50],
                "決済合計金額": [5000000, 6000000, 2000000],
                "決済回数": [300, 400, 100],
                "ユニークユーザー数": [250, 350, 80],
            }
        )

    def test_aggregations_by_gender_has_required_columns(
        self, aggregations_by_gender_data
    ):
        """
        性別別集計が必須カラムをすべて含むことを確認
        """
        df = aggregations_by_gender_data

        assert "性別" in df.columns
        assert "店舗数" in df.columns
        assert "決済合計金額" in df.columns

    def test_aggregations_by_gender_enum_values(self, aggregations_by_gender_data):
        """
        性別が期待される値（男性、女性、不明）のみであることを確認

        # RISK: TST-001 + DATA-002
        business-rules.json の「性別コードの変換ルール」：
        '1'=男性、'2'=女性、その他または NULL='不明'
        出力順序は『男性、女性、不明』に統一される
        """
        df = aggregations_by_gender_data

        valid_genders = {"男性", "女性", "不明"}
        for gender in df["性別"]:
            assert gender in valid_genders

    def test_aggregations_by_gender_output_order(self, aggregations_by_gender_data):
        """
        性別別集計の出力順序が『男性→女性→不明』に統一されていることを確認

        # RISK: TST-001 + DATA-002
        business-rules.json で指定された順序：
        output_order: ["男性", "女性", "不明"]
        """
        df = aggregations_by_gender_data

        expected_order = ["男性", "女性", "不明"]
        actual_order = df["性別"].tolist()
        assert actual_order == expected_order

    def test_aggregations_by_gender_row_count(self, aggregations_by_gender_data):
        """
        性別別集計が3行（男性、女性、不明）を持つことを確認
        """
        df = aggregations_by_gender_data

        assert len(df) == 3

    def test_aggregations_by_gender_numeric_values(self, aggregations_by_gender_data):
        """
        メジャー値がすべて numeric 型であることを確認
        """
        df = aggregations_by_gender_data

        measure_columns = ["店舗数", "決済合計金額", "決済回数", "ユニークユーザー数"]
        for col in measure_columns:
            assert np.issubdtype(df[col].dtype, np.number)


class TestAggregationsByNendaiSchema:
    """
    年代別集計データの検証テスト（valid/aggregations_by_nendai.csv に基づく）
    """

    @pytest.fixture
    def aggregations_by_nendai_data(self):
        """
        年代別集計データのサンプル
        """
        return pd.DataFrame(
            {
                "年代": [
                    "10代未満",
                    "10代",
                    "20代",
                    "30代",
                    "40代",
                    "50代",
                    "60代",
                    "70代",
                    "80代以上",
                    "不明",
                ],
                "店舗数": [10, 30, 80, 100, 120, 100, 80, 40, 20, 50],
                "決済合計金額": [
                    500000,
                    1500000,
                    4000000,
                    5000000,
                    6000000,
                    5500000,
                    4500000,
                    2000000,
                    1000000,
                    2000000,
                ],
                "決済回数": [50, 150, 400, 500, 600, 550, 450, 200, 100, 200],
                "ユニークユーザー数": [40, 120, 320, 400, 480, 440, 360, 160, 80, 160],
            }
        )

    def test_aggregations_by_nendai_has_required_columns(
        self, aggregations_by_nendai_data
    ):
        """
        年代別集計が必須カラムをすべて含むことを確認
        """
        df = aggregations_by_nendai_data

        assert "年代" in df.columns
        assert "店舗数" in df.columns

    def test_aggregations_by_nendai_enum_values(self, aggregations_by_nendai_data):
        """
        年代が期待される値のみであることを確認

        # RISK: TST-001 + DATA-002
        business-rules.json の「年代コードの変換ルール」：
        '00'=10代未満、'01'=10代、'02'=20代、...、'08'=80代以上、その他='不明'
        """
        df = aggregations_by_nendai_data

        valid_nendai = {
            "10代未満",
            "10代",
            "20代",
            "30代",
            "40代",
            "50代",
            "60代",
            "70代",
            "80代以上",
            "不明",
        }

        for nendai in df["年代"]:
            assert nendai in valid_nendai

    def test_aggregations_by_nendai_output_order(self, aggregations_by_nendai_data):
        """
        年代別集計の出力順序が固定されていることを確認

        # RISK: TST-001 + DATA-002
        business-rules.json で指定された順序：
        output_order: ["10代未満", "10代", ..., "80代以上", "不明"]
        """
        df = aggregations_by_nendai_data

        expected_order = [
            "10代未満",
            "10代",
            "20代",
            "30代",
            "40代",
            "50代",
            "60代",
            "70代",
            "80代以上",
            "不明",
        ]
        actual_order = df["年代"].tolist()
        assert actual_order == expected_order

    def test_aggregations_by_nendai_row_count(self, aggregations_by_nendai_data):
        """
        年代別集計が10行を持つことを確認（10代未満～不明）
        """
        df = aggregations_by_nendai_data

        assert len(df) == 10

    def test_aggregations_by_nendai_fill_value_for_missing_groups(self):
        """
        欠落した年代グループが fill_value=0 で補完されることを確認

        # RISK: TST-001 + DATA-002
        business-rules.json の fill_value: 0 で、欠落グループは0で補完される
        """
        # 一部の年代のみ存在するケース
        df = pd.DataFrame(
            {
                "年代": ["10代", "30代", "50代"],
                "店舗数": [30, 100, 100],
                "決済回数": [150, 500, 550],
            }
        )

        # 欠落グループを fill_value=0 で補完する処理を想定
        full_nendai = [
            "10代未満",
            "10代",
            "20代",
            "30代",
            "40代",
            "50代",
            "60代",
            "70代",
            "80代以上",
            "不明",
        ]
        missing_nendai = set(full_nendai) - set(df["年代"])
        assert len(missing_nendai) > 0  # 欠落グループが存在


class TestAggregationsByPaymentAmountSchema:
    """
    決済金額帯別集計データの検証テスト
    """

    def test_aggregations_by_payment_amount_brackets(self):
        """
        決済金額帯が期待される区分であることを確認

        # RISK: TST-001 + DATA-002
        business-rules.json の「決済金額帯の区分ルール」：
        0～5000円、5000～10000円、10000～15000円、15000～20000円、2万円～
        実装時に先頭の数字_を削除して日本語化
        """
        df = pd.DataFrame(
            {
                "決済合計金額帯": [
                    "0～5000円",
                    "5000～10000円",
                    "10000～15000円",
                    "15000～20000円",
                    "2万円～",
                ],
                "店舗数": [50, 100, 150, 120, 80],
                "決済合計金額": [
                    200000,
                    700000,
                    2000000,
                    2200000,
                    5000000,
                ],
                "決済回数": [100, 150, 200, 150, 100],
            }
        )

        valid_brackets = {
            "0～5000円",
            "5000～10000円",
            "10000～15000円",
            "15000～20000円",
            "2万円～",
        }

        for bracket in df["決済合計金額帯"]:
            assert bracket in valid_brackets

    def test_aggregations_by_payment_amount_prefix_removed(self):
        """
        決済金額帯から先頭の数字プレフィックスが削除されることを確認

        # RISK: DATA-003
        実装時に先頭数字_を削除して日本語化
        """
        # プレフィックス付きの生データ
        df_raw = pd.DataFrame(
            {
                "決済合計金額帯": [
                    "1_0～5000円",
                    "2_5000～10000円",
                    "3_10000～15000円",
                    "4_15000～20000円",
                    "5_2万円～",
                ]
            }
        )

        # プレフィックス削除後（PREFIX_LENGTH = 2）
        df_processed = df_raw.copy()
        df_processed["決済合計金額帯"] = df_processed["決済合計金額帯"].map(
            lambda x: x[2:]
        )

        expected_brackets = [
            "0～5000円",
            "5000～10000円",
            "10000～15000円",
            "15000～20000円",
            "2万円～",
        ]
        assert df_processed["決済合計金額帯"].tolist() == expected_brackets


class TestAggregationsEmptyResult:
    """
    集計結果が空（0件）の場合の動作確認
    """

    def test_aggregations_empty_dataframe_returned(self):
        """
        集計結果が空の場合、pd.DataFrame() を返すことを確認

        # RISK: TST-001 + DATA-002
        business-rules.json の「空の結果セットの扱い」：
        集計結果が空（0件）の場合、pd.DataFrame() を返す
        """
        df = pd.DataFrame()

        assert len(df) == 0
        assert isinstance(df, pd.DataFrame)

    def test_aggregations_empty_result_handling_in_ui(self):
        """
        UI側で空結果を判定可能であることを確認（if not df.empty）
        """
        df = pd.DataFrame()

        if df.empty:
            # UI側では表示を回避
            display = False
        else:
            display = True

        assert display == False


class TestAggregationsDataIntegrity:
    """
    集計データのデータ整合性テスト
    """

    def test_aggregations_sum_relationship(self):
        """
        各次元別の集計値の合計が全体集計と一致することを確認

        # RISK: TST-001 + DATA-002
        業態別や性別別の合計が、全体統計と一致する
        """
        aggregations = pd.DataFrame(
            {
                "次元": ["食品", "衣料", "電子機器"],
                "決済合計金額": [5000000, 7500000, 4000000],
            }
        )

        total_aggregation = 16500000  # 全体

        actual_sum = aggregations["決済合計金額"].sum()
        assert actual_sum == total_aggregation

    def test_aggregations_no_duplicate_dimension_values(self):
        """
        各次元で重複がないことを確認
        """
        df = pd.DataFrame(
            {
                "業態": ["食品", "衣料", "電子機器", "食品"],  # 食品が重複
                "決済回数": [100, 150, 200, 50],
            }
        )

        duplicate_industries = df[df["業態"].duplicated()]
        assert len(duplicate_industries) > 0  # 重複が存在（エラーケース）
