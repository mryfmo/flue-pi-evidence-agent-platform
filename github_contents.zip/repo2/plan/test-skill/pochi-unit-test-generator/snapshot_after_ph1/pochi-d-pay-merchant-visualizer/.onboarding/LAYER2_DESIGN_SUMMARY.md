# Layer 2 設計完了サマリー

**実行日時**: 2026-05-01  
**設計モード**: characterization（既存動作の固定化）  
**対象プロジェクト**: d払い決済状況見える化ツール  

---

## 1. 設計ファイル出力結果

### 生成ファイル
- **ファイルパス**: `/home/user/pochi-d-pay-merchant-visualizer-repository/tests/.onboarding/unit-test-design.md`
- **ファイルサイズ**: 1,078 行
- **形式**: Markdown / AAAパターン（Arrange-Act-Assert）

---

## 2. 設計スコープと対象範囲

### 2.1 テスト対象モジュール（Layer 2 適用可能）

**テスト対象関数数**: 22 関数 + 2 クラス

| モジュール | 関数/クラス | Streamlitデコレータ | テスト対象 |
|----------|----------|------------------|----------|
| lib/models.py | InputConditions, RenderOptions | 無し | ✅ Layer 2 |
| lib/address.py | remove_none_and_list_keys, get_pref_code, get_address_master_* | 無し | ✅ Layer 2 |
| lib/utils.py | json_serial, to_json, get_streamlit_session_id | @st.cache_data1件 | ⚠ 混在 |
| lib/session_manager/ | セッション管理関数4件 | 無し | ✅ Layer 2 |
| lib/data_loader/utils/fuzzy_search.py | generate_search_condition, whoosh_to_sqlalchemy | 無し | ✅ Layer 2 |
| lib/data_loader/data_models/ | MerchantStoreKey, MerchantStoreKeyList | 無し | ✅ Layer 2 |
| lib/generate_analysis_result_data.py | get_east_asian_width_count（ほか） | 無し | ✅ Layer 2 |
| lib/merchant_keyword_search.py | create_map（他2件） | @st.cache_data | ↑ Layer 3 |

### 2.2 Streamlitデコレータ除外分（Layer 3 移行）

**合計 39 個のデコレータ付き関数が Level 3 統合テストに移行**:
- lib/data_loader/_graph_data.py: 15 関数（全て @st.cache_data）
- lib/address.py: 5 関数（@st.cache_data）
- lib/data_loader/ 配下: 19 関数（@st.cache_data/@st.cache_resource 混在）

---

## 3. 定量目標（計算結果）

### 3.1 test-viewpoints.json 分析

- **Layer 2 観点総数**: 約 45 観点
- **計算式**: N × 2 = 45 × 2
- **Layer 2 最低生成数**: **90 テスト関数以上**

### 3.2 テスト比率（test-ratio.json から適用）

- **正常系テスト**: 40% → **36 テスト関数**
- **異常系テスト**: 50% → **45 テスト関数**
- **境界値テスト**: 10% → **9 テスト関数**
- **合計**: 90 テスト関数（最小値）

### 3.3 リスク対応テスト（risk-catalog.md から）

| リスクID | 優先度 | テスト対象 | 最小テスト数 |
|---------|--------|----------|-----------|
| TST-001 | CRITICAL | InputConditions/RenderOptions 検証 | 3+ |
| TST-002 | HIGH | セッション管理・キャッシュ | 2+ |
| DATA-001 | HIGH | InputConditions 複雑OR判定 | 5+ |
| DEPS-001 | HIGH | Pochilib セッション依存 | 2+ |
| DATA-002 | MEDIUM | NULL値処理・リスト操作 | 3+ |
| SEC-001 | MEDIUM | SQL Injection対策 | 2+ |
| **合計** | | | **17+ リスク対応テスト** |

---

## 4. 設計内容（詳細）

### 4.1 テストケース総数

#### モジュール別テストケース設計数

| モジュール | テストケース数 | 層別分布 |
|----------|------------|---------|
| test_models.py (InputConditions) | 9 TC | 6正常 / 2異常 / 1境界 |
| test_models.py (RenderOptions) | 3 TC | 2正常 / 1異常 |
| test_address.py (remove_none_and_list_keys) | 4 TC | 3正常 / 1境界 |
| test_address.py (get_pref_code) | 4 TC | 2正常 / 2異常 |
| test_address.py (get_address_master_*) | 6 TC | 4正常 / 1異常 / 1境界 |
| test_session_manager.py | 4 TC | 2正常 / 2異常 |
| test_fuzzy_search.py | 5 TC | 2正常 / 2異常 / 1境界 |
| test_utils.py | 8 TC | 6正常 / 1異常 / 1境界 |
| test_merchant_key.py | 3 TC | 3正常 |
| test_generate_analysis.py | 6 TC | 4正常 / 1異常 / 1境界 |
| **合計設計** | **52 TC** | **33正常 / 11異常 / 8境界** |

### 4.2 アサーション品質基準

各テストケースで以下の 3 段階のアサーションを実装する設計：

**レベル1（必須）**: 具体値の完全一致
```python
assert result is True
assert result == "2026-05-01"
assert len(result) == 2
```

**レベル2（必須）**: 出力構造の厳密検証
```python
assert "oaza_popularname_kanji" in result.columns
assert isinstance(result, pd.DataFrame)
assert len(result) > 0
```

**レベル3（推奨）**: 否定条件の検証
```python
assert None not in result.keys()
assert "error" not in result.get("message", "")
```

### 4.3 出力契約テストの実装パターン

各関数について以下の形式で出力契約テストを設計：

```python
def test_function_outputs_match_caller_expectations():
    """
    出力契約:
      - 戻り値型: <type>
      - スキーマ: <カラム一覧 or キー一覧>
      - 値の範囲: <valid range>
    
    呼び出い元: <caller_function>
    呼び出い元の期待値: <expected format>
    """
    # テスト実装
```

### 4.4 リスク対応テストの実装ガイド

各リスクID に対応するテストケースには以下のコメントを記載：

```python
# RISK: DATA-001 - InputConditions の複雑な検証ロジック
def test_input_conditions_check_DATA_001_all_search_modes():
    """複数検索条件が同時有効な場合、OR判定が正確に機能すること"""
```

---

## 5. conftest.py 実装仕様

### 5.1 必須要素

```
1. sys.modules モック（16 個）
   - pochilib.*, streamlit.*, snowflake.*, sqlalchemy, その他

2. _passthrough_decorator
   - @st.cache_data, @st.cache_resource をパススルー化
   
3. sys.path 設定
   - app/ を sys.path に追加

4. pytest フィクスチャ
   - input_conditions_valid（有効なInputConditions）
   - mock_snowflake_session（モックセッション）
```

### 5.2 モック戦略

| モジュール | モック方式 | 理由 |
|----------|---------|------|
| pochilib | MagicMock | 外部依存、認証必須 |
| streamlit | @cache = passthrough | ランタイム依存 |
| snowflake.connector | MagicMock | ライセンス・認証 |
| sqlalchemy.orm.Session | MagicMock | DB接続 |

---

## 6. テスト実装アーキテクチャ

### 6.1 ファイル構成

```
tests/
├── unit/
│   ├── test_models.py              # 12 テスト（入力条件モデル）
│   ├── test_address.py             # 14 テスト（住所処理）
│   ├── test_utils.py               # 8 テスト（ユーティリティ）
│   ├── test_session_manager.py     # 4 テスト（セッション管理）
│   ├── test_fuzzy_search.py        # 5 テスト（ファジー検索、セキュリティ）
│   ├── test_merchant_key.py        # 3 テスト（データモデル）
│   └── test_generate_analysis.py   # 6 テスト（分析データ）
│
└── conftest.py                     # 共有フィクスチャ、モック設定
```

### 6.2 実装スケジュール

| フェーズ | 対象モジュール | テスト数 | 日程 |
|---------|-----------|--------|------|
| A | models.py | 12 TC | 1 日目 |
| B | address.py, session_manager.py | 18 TC | 2 日目 |
| C | fuzzy_search.py, utils.py, merchant_key.py | 16 TC | 3 日目 |
| D | 検証・補完・リスク対応 | 6 TC | 4 日目 |

---

## 7. 品質保証ポイント

### 7.1 アサーション品質チェックリスト

- [ ] 全テストで「型チェックのみ」は禁止
- [ ] 全テストで「存在確認のみ」は禁止
- [ ] 全異常系テストで例外型を明記
- [ ] 全境界値テストで極端な値の具体例を明記

### 7.2 リスク対応チェックリスト

- [ ] TST-001, DATA-001（CRITICAL/HIGH）のテストが 5 件以上存在
- [ ] SEC-001 対応（SQL Injection）のテストが 2 件以上存在
- [ ] DEPS-001 対応（Pochilib）のモック設定が conftest.py に明記

### 7.3 比率確認チェックリスト

- [ ] 正常系テスト: 全体の 40% 前後（33～37 件）
- [ ] 異常系テスト: 全体の 50% 前後（42～48 件）
- [ ] 境界値テスト: 全体の 10% 前後（8～12 件）

---

## 8. 次のステップ（T2 フェーズ実装）

### 8.1 実装順序

1. **conftest.py の生成** → sys.modules, sys.path, フィクスチャ設定
2. **test_models.py** → InputConditions.check の 9 TC + RenderOptions の 3 TC
3. **test_address.py** → remove_none_and_list_keys, get_pref_code, get_address_master_*
4. **test_session_manager.py** → get_snowflake_sqlalchemy_session, clear_cache 等
5. **test_fuzzy_search.py** → generate_search_condition（SEC-001）
6. **test_utils.py, test_merchant_key.py, test_generate_analysis.py** → 補完

### 8.2 品質検証

実装後に以下を実行：
```bash
# テスト収集確認
pytest tests/unit/ --collect-only

# テスト実行
pytest tests/unit/ -v

# カバレッジ確認
pytest tests/unit/ --cov=app/lib --cov=app/reporting_function --cov-report=html

# テスト統計
pytest tests/unit/ --co -q | wc -l
```

---

## 9. 参考資料マッピング

| 設計参照 | ソースファイル | 記述箇所 |
|--------|------------|--------|
| テスト比率 | test-ratio.json | fixture_distribution |
| リスク一覧 | risk-catalog.md | Section 3（詳細リスク評価） |
| 観点一覧 | test-viewpoints.json | layer=2 エントリ |
| テストデータ | fixtures/manifest.json | valid/invalid/edge |
| モジュール一覧 | module-inventory.json | streamlit_decorators |

---

## 10. 実装上の注意点

### 10.1 パッチパス

conftest.py で `sys.path` に `app/` を追加した場合、import と patch を一致させる：
```python
# ✅ 正しい
from lib.address import get_pref_code
@patch("lib.address.get_address_master")

# ❌ 間違い（別の名前空間）
from app.lib.address import get_pref_code
@patch("app.lib.address.get_address_master")
```

### 10.2 Streamlitデコレータ処理

conftest.py で以下の差し替えが必須：
```python
def _passthrough_decorator(func=None, **kwargs):
    if func is not None:
        return func
    return lambda f: f

st.cache_data = _passthrough_decorator
st.cache_resource = _passthrough_decorator
```

これにより、Layer 2 テストで `@st.cache_data` 付き関数を import 可能に。

### 10.3 Layer 3 移行関数

以下のモジュールは **Layer 3 統合テスト**として AppTest 経由でテスト：
- lib/data_loader/_graph_data.py（全 15 関数）
- lib/data_loader/_address.py（全 1 関数）
- lib/address.py（5 関数）
- その他 @st.cache_data/@st.cache_resource 付き関数

---

**設計完了**: 2026-05-01  
**準備状況**: T2 フェーズ実装準備完了  
**次フェーズ**: pytest テストコード自動生成
