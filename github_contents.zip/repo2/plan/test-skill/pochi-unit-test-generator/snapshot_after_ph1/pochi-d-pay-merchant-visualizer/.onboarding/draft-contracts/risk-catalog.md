# リスクカタログ - d払い決済状況見える化ツール

**生成日**: 2026-05-01  
**アプリケーション**: d払い決済状況見える化ツール  
**フレームワーク**: Streamlit + Snowflake  
**対象バージョン**: main ブランチ時点

---

## 1. 概要

本ドキュメントは、d払い決済状況見える化ツールの静的解析に基づくリスク評価です。  
Streamlitアプリケーションとしての構造的脆弱性、データキャッシング戦略、外部依存ライブラリ、テスト状況などを評価対象としています。

---

## 2. リスク分類と優先度

### 優先度定義

| 優先度 | 説明 | 対応タイムライン |
|--------|------|-----------------|
| **CRITICAL** | システム全体の機能停止、データ破損、セキュリティ脅威が発生 | 即座に対応 |
| **HIGH** | 主要機能の不具合、パフォーマンス問題、テストカバレッジ不足 | 次のスプリント以内 |
| **MEDIUM** | サブ機能の不具合、部分的な影響 | 計画的に対応 |
| **LOW** | コード品質の向上、将来の保守性向上 | 長期的改善 |

---

## 3. 詳細リスク評価

### 3.1 テストカバレッジリスク

#### リスク ID: TST-001
**タイトル**: テストコード欠落による品質保証不足  
**優先度**: **CRITICAL**  
**現状**: スキルコンフィグで `coverage_target: 60%` が指定されているが、T0時点でテストが大幅に欠落している  
**根拠**: 以下のファイルが単一テストもなく、コード行数が多い（レガシー）
- `app/app_pages/visualization_tool.py` (1063行)
- `app/lib/graph_visualizer.py` (560行)
- `app/lib/merchant_map.py` (540行)
- `app/lib/generate_analysis_result_data.py` (538行)
- `app/lib/data_loader/_graph_data.py` (456行)

**影響範囲**: システム全体、特にデータ集計・可視化機能

**推奨対応**:
1. T2フェーズで Layer 2/3 ユニットテスト生成により80件以上のテストを追加予定
2. データ集計ロジック（business-rules.json で定義）のキャラクタリゼーションテスト実装
3. 各集計関数（get_si_agg_by_* 等）の引数別動作テスト

**テスト対象機能（優先順位付き）**:
1. **集計関数群** (`_graph_data.py`)
   - gender/age group mapping の正確性（順序保証、NULL値処理）
   - payment_amount_bracket 分類の正確性
   - 比較期間機能の enable_comparison フラグ判定
2. **データローダー** (`_merchant_store.py`, `_merchant_store.py`)
   - 環境別マスタView選択（prod/dev 切り替え）
   - ファジー検索結果の精度
3. **UI描画コンポーネント** (`visualization_tool.py`, `merchant_map.py`)
   - RenderOptions による表示制御の動作
   - StreamlitWidget （st.checkbox, st.selectbox 等）の状態管理

---

#### リスク ID: TST-002
**タイトル**: Streamlit キャッシュ戦略の複雑性とテスト困難性  
**優先度**: **HIGH**  
**現状**: `@st.cache_resource` と `@st.cache_data` が混在して使用されている
```python
# cache_resource: Session オブジェクトなど状態を持つもの
@st.cache_resource(ttl=300, hash_funcs={Session: lambda session: id(session)})
def create_settlement_records_query_from_input_conditions(...)

# cache_data: データFrame など計算結果
@st.cache_data(show_spinner=False, persist=False, ttl=1800)
def get_si_statistics(...)
```

**影響**: 
- キャッシュの有効期間内にDB側のマスタデータが更新された場合、古いデータが表示される可能性
- Session オブジェクトの id() ハッシング戦略が脆弱（メモリ再割り当てで別idになる可能性）

**推奨対応**:
1. キャッシュ戦略ドキュメント作成（business-rules.json#data_caching_strategy 参照）
2. TTL値の正当性検証テスト（業務要件に応じた鮮度確保）
3. Session ハッシング方式の見直し（より安定的なID戦略の検討）

---

### 3.2 データ品質リスク

#### リスク ID: DATA-001
**タイトル**: InputConditions の複雑な検証ロジック  
**優先度**: **HIGH**  
**現状**: `InputConditions.check` が4つの検索条件（address/keyword/map/store）のいずれか1つ必須を検証
```python
def check(self) -> bool:
    address_condition = self.prefecture_cd and self.city_cd
    keyword_condition = self.keyword_search_method and self.keyword_search_word
    map_condition = (self.map_search_latitude is not None and ...)
    store_condition = (self.selected_store_id and ...)
    
    if not (address_condition or keyword_condition or map_condition or store_condition):
        return False
```

**リスク**:
- OR条件の複雑さから実装ミスが発生しやすい
- 4つの検索モード全てが同時に満たされる場合の動作が不明確
- UI側で入力制約をしていない場合、無効な組み合わせが送信される可能性

**推奨対応**:
1. InputConditions.check() のユニットテスト：全16パターン（2^4 組み合わせ）
2. 各検索モードの排他制御確認（同時複数有効時の優先順位ドキュメント化）
3. UI側で検索条件の排他制御を実装（異なるモードは同時有効不可）

---

#### リスク ID: DATA-002
**タイトル**: 集計時の NULL値/空結果の不統一な処理  
**優先度**: **MEDIUM**  
**現状**: NULL値の扱いが関数ごとに異なる
- 性別別集計：NULL は 'not null' フィルタで除外 → 'default'で 'not null' ラベル
- 年代別集計：NULL は 'not null' フィルタで除外 → reindex() で '不明' を補完
- 集計結果が空の場合：pd.DataFrame() を返す（ただし、一部は fill_value=0 で補完）

**リスク**:
- 結果の一貫性が低く、UI側で各関数別に特殊処理が必要
- テストでの期待値設定が複雑

**推奨対応**:
1. NULL値処理の標準化：「欠落グループは fill_value で補完」をルール化
2. 集計結果の空判定の一貫化（全関数で if not df.empty チェック）
3. business-rules.json#data_integrity を参考にしたテスト実装

---

#### リスク ID: DATA-003
**タイトル**: 決済金額帯の数値プレフィックス削除による文字列置換リスク  
**優先度**: **LOW**  
**現状**: `get_si_agg_by_payment_amount()` で、決済金額帯の先頭数字をマップで削除
```python
df["決済合計金額帯"] = df["決済合計金額帯"].map(lambda x: x[2:])
```

**リスク**: 
- 魔法の数字 `[2:]` が名前なしで使用。プレフィックス削除の目的が不明確
- 将来の仕様変更（プレフィックス形式の変更）で破壊される可能性

**推奨対応**:
1. 定数化：`PREFIX_LENGTH = 2` として明示
2. コメント追加：「集計結果の先頭にある順序付けプレフィックス（'1_', '2_'...）を削除」
3. テストで期待値を明示

---

### 3.3 外部依存リスク

#### リスク ID: DEPS-001
**タイトル**: Pochilib への強い依存性  
**優先度**: **HIGH**  
**現状**: スキルコンフィグで `mock_always: ["pochilib", "pochilib.snowflake", "pochilib.llm", "streamlit"]`
- 10個のモジュールが `pochilib` をインポート
- PochiEnvironment(), get_snowflake_sqlalchemy_session() などの key functions が app 全体に散在

**リスク**:
- Pochilib の更新による破壊的変更が即座に影響
- Pochilib のテスト用モック実装が必須（T2で必ずモック化）
- ローカル開発環境での動作確認が困難（snowflake.connector の認証が必要）

**推奨対応**:
1. T2フェーズでのモック実装（pytest-mock でInjection）
2. Pochilib API の変更追跡（dependency pinning: requirements.txt に明示）
3. 統合テストは CI/CD 環境のみで実行（ローカルではモック）

---

#### リスク ID: DEPS-002
**タイトル**: SQLAlchemy ORM の複雑なクエリ構築  
**優先度**: **MEDIUM**  
**現状**: SQLAlchemy の select(), case(), func.*, over() など高度な機能が多用
```python
query = (
    select(
        case(
            (baseTbl.c.gender_code == "1", "男性"),
            (baseTbl.c.gender_code == "2", "女性"),
            else_="不明",
        ).label("性別"),
        func.count(...).label("..."),
        func.row_number().over(partition_by=..., order_by=...).label("rn"),
    )
    .select_from(baseTbl)
    .group_by("性別")
)
```

**リスク**:
- クエリの論理が複雑で、SQL生成ミスが発生しやすい
- Snowflake の SQL 方言による生成ミス（例：OVER句の構文）
- テストで予期しない SQL が生成される可能性

**推奨対応**:
1. SQLAlchemy クエリのユニットテスト（生成SQL の比較）
2. Snowflake 方言への適合性テスト
3. スロー実行クエリのモニタリング

---

### 3.4 アーキテクチャリスク

#### リスク ID: ARCH-001
**タイトル**: データレイヤーとプレゼンテーションレイヤーの強い結合  
**優先度**: **MEDIUM**  
**現状**: 
- `visualization_tool.py` (1063行) が、入力UI、データ取得、グラフ描画をすべて実装
- データローダー関数が Streamlit デコレータ（@st.cache_*）に依存
- UI層のロジック変更がデータ層に波及

**リスク**:
- テストが困難（Streamlit ウィジェットのモック化が複雑）
- 再利用性が低い（他のフレームワーク（FastAPI など）での利用が困難）

**推奨対応**:
1. プレゼンテーション層の分離：入力UI → 条件オブジェクト生成 → データ取得 → 表示
2. ビジネスロジック層の独立化：Streamlit デコレータを別ファイルに移す
3. Layer 2/3 テストで層ごとの責務を明確化

---

#### リスク ID: ARCH-002
**タイトル**: グローバルセッション管理の脆弱性  
**優先度**: **MEDIUM**  
**現状**: 
- `lib/session_manager/snowflake_sqlalchemy.py` で Snowflake セッションをグローバル管理
- `clear_cache_snowflake_sqlalchemy_session()` 関数が手動で呼び出される

**リスク**:
- マルチスレッド環境でセッションの競合が発生
- セッションのライフサイクルが不明確（いつ close されるか）

**推奨対応**:
1. セッションライフサイクルドキュメント化
2. Context Manager (with 文) による明示的管理
3. スレッドセーフテスト実装

---

### 3.5 保守性リスク

#### リスク ID: MAINT-001
**タイトル**: マジックナンバー・マジック文字列の多用  
**優先度**: **LOW**  
**現状**: 
- 性別コード '1'='男性', '2'='女性' が複数箇所で硬度化
- 年代コード '00'～'08' のマッピングが関数内に埋め込まれ
- TTL値（300, 1800）が定数化されていない

**リスク**:
- 仕様変更時の修正範囲が不明確
- 同じ定義が複数箇所に散在

**推奨対応**:
1. 定数ファイル作成：`lib/const.py` に GENDER_CODE_MAP, AGE_GROUP_MAP を追加
2. TTL値の集約：`lib/const.py` に CACHE_TTL_SETTLEMENT, CACHE_TTL_MERCHANT を定義
3. Enum 化の検討（TypeAlias ではなく）

---

#### リスク ID: MAINT-002
**タイトル**: ドキュメント不足  
**優先度**: **MEDIUM**  
**現状**: 
- 関数の docstring が最小限（引数説明がない、戻り値型が不明確）
- キャッシング戦略が明文化されていない
- 比較期間機能の仕様が不明確（dataclasses.replace() の使用目的が不明）

**リスク**:
- 新規開発者の学習コストが高い
- API変更時の影響範囲が判断しにくい

**推奨対応**:
1. Docstring テンプレート統一（Args, Returns, Raises を明記）
2. architecture.md 作成：レイアー構成、データフロー、キャッシング戦略を図解
3. SKILL.md 更新：T0 で生成した contracts ドキュメントを参照

---

### 3.6 セキュリティリスク

#### リスク ID: SEC-001
**タイトル**: SQL Injection の潜在リスク  
**優先度**: **MEDIUM**  
**現状**: SQLAlchemy ORM を使用しており、SQL Injection の直接的リスクは低いが、
- `fuzzy_search.py` の generate_search_condition() で動的にクエリを構築
- ユーザー入力が直接 or_() 条件に組み込まれる

**リスク**:
- 検索ワードの不正なエスケープ

**推奨対応**:
1. generate_search_condition() のユニットテスト（特殊文字を含むワード）
2. SQLAlchemy API による安全なパラメタライズの確認
3. Snowflake の権限管理：テストDB は限定的な権限でアクセス

---

#### リスク ID: SEC-002
**タイトル**: 個人情報（ユーザー ID）の取得・保存リスク  
**優先度**: **MEDIUM**  
**現状**: 
- ユーザーリストダウンロード機能（enable_acctid_list_download）が実装
- comnid（ユーザー識別子）を含むデータを CSV でダウンロード可能

**リスク**:
- ダウンロードしたファイルの暗号化、安全削除が不明確
- 権限チェック（誰がダウンロード可能か）が実装されていない可能性

**推奨対応**:
1. データダウンロード機能のアクセス制御テスト
2. ファイル削除・暗号化のセキュリティ要件確認
3. 監査ログの実装（誰が、いつ、何をダウンロードしたか）

---

### 3.7 パフォーマンスリスク

#### リスク ID: PERF-001
**タイトル**: 大規模データセットでのメモリ不足リスク  
**優先度**: **MEDIUM**  
**現状**: 
- `get_si_agg_by_industry_and_stores()` が業態ごとに最大50件の店舗データを取得
- DataFrameの全体をメモリに展開（バッチ処理がない）

**リスク**:
- 検索条件が広い場合（例：日本全国の全決済レコード）、メモリ不足エラー
- Snowflake への接続タイムアウト（MAX_ROWS_PER_INDUSTRY を超える場合）

**推奨対応**:
1. ページング機能の実装（上位N件取得に限定）
2. メモリプロファイリングテスト（大規模検索での最大メモリ使用量）
3. クエリ実行計画の確認（Snowflake EXPLAIN PLAN）

---

#### リスク ID: PERF-002
**タイトル**: Streamlit キャッシュの無効化による性能低下  
**優先度**: **MEDIUM**  
**現状**: 
- 比較期間機能が有効な場合、get_si_statistics() で use_session_cache=False
- 毎回 Snowflake にクエリを実行（キャッシュを利用しない）

**リスク**:
- 比較期間データの取得に数秒～数十秒の遅延
- ユーザーエクスペリエンスの低下

**推奨対応**:
1. キャッシュキーの工夫（enable_comparison フラグを hash_funcs に含める）
2. Snowflake のクエリ最適化（インデックス、メモリキャッシュ）
3. バックグラウンドプリロード（比較期間データを事前取得）

---

## 4. リスク対応ロードマップ

### T0 フェーズ（現在）
✅ リスク分析・カタログ化  
✅ data-contracts.json 生成  
✅ business-rules.json 生成

### T1 フェーズ（次フェーズ）
予定:
- ドラフト契約の業務要件確認
- 環境構成の確認（Pochilib 依存性、Snowflake アクセス権限）

### T2 フェーズ（ユニットテスト生成）
予定:
- テスト実装（80件以上）：集計ロジック、キャッシング、NULL値処理
- ARCH-001, DATA-001 に対応するテスト
- DEPS-001 のモック実装

### T3 フェーズ（統合テスト）
予定:
- PERF-001, PERF-002 のパフォーマンステスト
- SEC-001, SEC-002 のセキュリティテスト

---

## 5. 参考資料

- `data-contracts.json`: データコントラクト定義（7つのデータセット）
- `business-rules.json`: ビジネスルール定義（6つのカテゴリ、28個のルール）
- `module-inventory.json`: モジュール一覧（63個のモジュール、39個の Streamlit デコレータ）
- Skill Config: `/tests/.onboarding/skill-config.json` （coverage_target: 60%）

---

**スキャン完了日**: 2026-05-01  
**次の操作**: T1（ドラフト契約確認） → T2（テスト生成）
