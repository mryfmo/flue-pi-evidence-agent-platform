# Layer 2（ユニットテスト）設計書

**生成日**: 2026-05-01  
**プロジェクト**: d払い決済状況見える化ツール  
**対象フレームワーク**: Streamlit + Snowflake  
**設計モード**: characterization（既存動作の固定化）

---

## 概要

このドキュメントは、Layer 2 ユニットテストの設計仕様を定義します。
既存コードの動作を characterization テスト（既存動作を期待値として固定するテスト）として実装します。

### テスト比率（test-ratio.json から）

- **正常系テスト**: 40%
- **異常系テスト**: 50%
- **境界値テスト**: 10%

### リスク対応テスト（risk-catalog.md から優先度HIGH/CRITICAL）

| リスクID | リスク概要 | 優先度 | 対応テスト数 |
|---------|----------|--------|-----------|
| TST-001 | テストコード欠落 | CRITICAL | 3+ |
| TST-002 | キャッシュ戦略複雑性 | HIGH | 2+ |
| DATA-001 | InputConditions複雑検証 | HIGH | 5+ |
| DEPS-001 | Pochilib依存 | HIGH | 2+ |
| DATA-002 | NULL値処理不統一 | MEDIUM | 3+ |

### Layer 2 適用範囲（@st.cache_data/@st.cache_resource 除外）

以下のモジュールは **Layer 3（統合テスト）に移行**：
- lib/address.py の以下関数: `get_regions_and_prefectures`, `get_prefectures`, `get_concat_address`, `_filter_address_df_by_oaza_popularname`, `_filter_address_df_by_sectionname_chome`
- lib/data_loader/_graph_data.py の全15関数（全て @st.cache_data付き）
- lib/data_loader/_address.py の全1関数（@st.cache_data付き）
- lib/data_loader/_base.py の全1関数（@st.cache_resource付き）
- lib/data_loader/_merchant_store.py の `get_merchant_store_list`（@st.cache_resource付き）
- その他20+ 関数

**Layer 2 対象モジュール**（Streamlitデコレータなし、または純粋関数）:
- lib/models.py: InputConditions, RenderOptions
- lib/address.py: `remove_none_and_list_keys`, `get_pref_code`, `get_address_master_with_name`, `get_address_master_with_code`
- lib/utils.py: `json_serial`, `to_json`, `get_streamlit_session_id` (※ `get_usage_dates` は Layer 3)
- lib/session_manager/snowflake_sqlalchemy.py: セッション管理関数群
- lib/data_loader/utils/fuzzy_search.py: `generate_search_condition`, `whoosh_to_sqlalchemy`
- その他ビジネスロジック層

---

## 1. テスト対象モジュール別設計

### 1.1 lib/models.py（入力条件・描画オプション）

#### テスト対象クラス: InputConditions

**出力契約テストの定義**:
- `InputConditions.check` プロパティの戻り値は bool 型であること
- 呼び出し元: visualization_tool.py の on_click_search_button() が check プロパティを参照
- 呼び出し元の期待値: True/False の bool 値

##### TC-1.1.1: 正常系 - 住所条件のみ（正常な入力）

```
入力: InputConditions(
    start_date=date(2026, 1, 1),
    end_date=date(2026, 1, 31),
    prefecture_cd="13",
    city_cd=["1001"],
    enable_comparison=False
)
期待値: check プロパティが True を返す
アサーション1: isinstance(result, bool) == True
アサーション2: result is True
```

**テストコース理由**: 住所条件（prefecture_cd + city_cd）が充足される最小パターン。ADDRESS_CONDITION が True になることを確認。

---

##### TC-1.1.2: 正常系 - キーワード検索条件のみ

```
入力: InputConditions(
    start_date=date(2026, 1, 1),
    end_date=date(2026, 1, 31),
    keyword_search_method="company_store",
    keyword_search_word="ドコモショップ",
    enable_comparison=False
)
期待値: check プロパティが True を返す
アサーション1: isinstance(result, bool) == True
アサーション2: result is True
```

**テストコース理由**: キーワード検索条件（keyword_search_method + keyword_search_word）が充足される。KEYWORD_CONDITION が True になることを確認。

---

##### TC-1.1.3: 正常系 - 地図検索条件のみ

```
入力: InputConditions(
    start_date=date(2026, 1, 1),
    end_date=date(2026, 1, 31),
    map_search_latitude=35.6762,
    map_search_longitude=139.6503,
    map_search_radius_km=5.0,
    enable_comparison=False
)
期待値: check プロパティが True を返す
アサーション: result is True
```

---

##### TC-1.1.4: 正常系 - 店舗検索条件のみ

```
入力: InputConditions(
    start_date=date(2026, 1, 1),
    end_date=date(2026, 1, 31),
    selected_store_id="store_001",
    store_center_latitude=35.6762,
    store_center_longitude=139.6503,
    store_search_radius_km=1.0,
    enable_comparison=False
)
期待値: check プロパティが True を返す
アサーション: result is True
```

---

##### TC-1.1.5: 異常系 - 必須フィールド欠損（start_date が None）

```
入力: InputConditions(
    start_date=None,  # 必須フィールドが None
    end_date=date(2026, 1, 31),
    prefecture_cd="13",
    city_cd=["1001"],
    enable_comparison=False
)
期待値: check プロパティが False を返す
アサーション: result is False
```

**テストコース理由**: 日付チェック `isinstance(self.start_date, date)` が False になることを検証。DATA-001 対応。

---

##### TC-1.1.6: 異常系 - 検索条件すべて欠損

```
入力: InputConditions(
    start_date=date(2026, 1, 1),
    end_date=date(2026, 1, 31),
    prefecture_cd=None,
    city_cd=None,
    keyword_search_word=None,
    map_search_latitude=None,
    selected_store_id=None,
    enable_comparison=False
)
期待値: check プロパティが False を返す
アサーション: result is False
```

**テストコース理由**: 全4つの検索条件が満たされない場合、OR 条件全体が False になることを確認。DATA-001 対応。

---

##### TC-1.1.7: 異常系 - 比較期間有効時に比較開始日が None

```
入力: InputConditions(
    start_date=date(2026, 1, 1),
    end_date=date(2026, 1, 31),
    comparison_start_date=None,  # 比較日付が None なのに enable_comparison=True
    comparison_end_date=date(2025, 12, 1),
    enable_comparison=True,
    prefecture_cd="13",
    city_cd=["1001"]
)
期待値: check プロパティが False を返す
アサーション: result is False
```

**テストコース理由**: 比較期間有効時の条件付き必須フィールド検証。DATA-001 対応。

---

##### TC-1.1.8: 境界値 - 開始日 = 終了日（同一日）

```
入力: InputConditions(
    start_date=date(2026, 1, 1),
    end_date=date(2026, 1, 1),  # start_date と同じ日
    prefecture_cd="13",
    city_cd=["1001"],
    enable_comparison=False
)
期待値: check プロパティが True を返す
アサーション: result is True
```

**テストコース理由**: 日付範囲が 1 日の極端なケース。型チェックのみで制約はないことを確認。

---

##### TC-1.1.9: 境界値 - 複数検索条件同時有効

```
入力: InputConditions(
    start_date=date(2026, 1, 1),
    end_date=date(2026, 1, 31),
    prefecture_cd="13",
    city_cd=["1001"],
    keyword_search_method="company",
    keyword_search_word="ショップ",
    enable_comparison=False
)
期待値: check プロパティが True を返す（住所 OR キーワード = True）
アサーション: result is True
```

**テストコース理由**: OR 条件なので複数同時有効でも True。優先順位がないことを確認。

---

#### テスト対象クラス: RenderOptions

**出力契約テストの定義**:
- RenderOptions オブジェクトの各ブール値フィールドが正確に保持されていること
- 呼び出し元: visualization_tool.py の main() で RenderOptions インスタンスが作られ、各フラグを参照
- 呼び出し元の期待値: 各フラグが指定値を正確に反映していること

##### TC-1.2.1: 正常系 - デフォルト初期化

```
入力: RenderOptions()
期待値: 全フラグが以下のデフォルト値を持つ
  - enable_merchant_map == False
  - enable_acctid_list_download == False
  - enable_analysis_data_download == False
  - enable_graphs == False
  - enable_store_information_display == False
  - show_map_point_pin == True
  - payment_method_list == None
アサーション1: result.enable_merchant_map is False
アサーション2: result.enable_acctid_list_download is False
... (全フラグを検証)
```

---

##### TC-1.2.2: 正常系 - 指定値で初期化

```
入力: RenderOptions(
    enable_merchant_map=True,
    enable_graphs=True,
    show_map_point_pin=False
)
期待値: 指定値が正確に反映
アサーション: result.enable_merchant_map is True
アサーション: result.enable_graphs is True
アサーション: result.show_map_point_pin is False
```

---

##### TC-1.2.3: 異常系 - ブール値以外（型チェック）

```
入力: RenderOptions(enable_merchant_map="yes")  # 文字列を指定
期待値: dataclass の型チェックで Exception が発生
アサーション: raises TypeError
```

**テストコース理由**: frozen dataclass の型安全性を確認。

---

### 1.2 lib/address.py（住所処理、Streamlitデコレータなし）

#### テスト対象関数: remove_none_and_list_keys

**出力契約テストの定義**:
- 入力辞書から None キーと None/空リスト値を再帰的に削除
- 戻り値は修正済みの辞書オブジェクト
- 呼び出い元: components_address_input() で検索条件から None/空を削除するのに使用

##### TC-2.1.1: 正常系 - トップレベルの None キー削除

```
入力: {
    None: "skip_this",
    "prefecture_cd": "13",
    "city_cd": ["1001"]
}
期待値: {
    "prefecture_cd": "13",
    "city_cd": ["1001"]
}
アサーション: None not in result.keys()
アサーション: result["prefecture_cd"] == "13"
アサーション: len(result) == 2
```

**テストコース理由**: None キーが確実に除去されることを確認。

---

##### TC-1.2.2: 正常系 - 空リスト値を None に変換

```
入力: {
    "prefecture_cd": "13",
    "city_cd": [],  # 空リスト
    "keywords": None
}
期待値: {
    "prefecture_cd": "13",
    "city_cd": None,
    "keywords": None
}
アサーション: result["city_cd"] is None
```

---

##### TC-2.1.3: 正常系 - ネストした辞書のリスト内 None 削除

```
入力: {
    "name": "store",
    "details": {
        "tags": ["tag1", None, "tag2"],
        "meta": {
            "values": [1, 2, None]
        }
    }
}
期待値: {
    "name": "store",
    "details": {
        "tags": ["tag1", "tag2"],
        "meta": {
            "values": [1, 2]
        }
    }
}
アサーション: None not in result["details"]["tags"]
アサーション: len(result["details"]["tags"]) == 2
```

---

##### TC-2.1.4: 境界値 - 空辞書

```
入力: {}
期待値: {}
アサーション: result == {}
```

---

#### テスト対象関数: get_pref_code

**出力契約テストの定義**:
- 都道府県名から JIS コード（整数）を返す
- 戻り値型: int | None
- 呼び出い元: get_address_master_with_name() で都道府県名をコードに変換

##### TC-2.2.1: 正常系 - 有効な都道府県名

```
入力: "東京都"
期待値: 13 (東京都のJISコード)
アサーション: isinstance(result, int)
アサーション: result == 13
```

**テストコース理由**: static/prefectures.json から正確にコードが取得できることを確認。

---

##### TC-2.2.2: 正常系 - 有効な都道府県名（別例）

```
入力: "大阪府"
期待値: 27
アサーション: result == 27
```

---

##### TC-2.2.3: 異常系 - 存在しない都道府県名

```
入力: "火星県"
期待値: None
アサーション: result is None
```

---

##### TC-2.2.4: 異常系 - 空文字列

```
入力: ""
期待値: None
アサーション: result is None
```

---

#### テスト対象関数: get_address_master_with_name

**出力契約テストの定義**:
- 都道府県名からアドレスマスタ DataFrame を取得
- 戻り値型: pd.DataFrame
- 呼び出い元: components_address_input() でフィルター用の住所 DataFrame を取得
- 呼び出い元の期待値: ["oaza_popularname_kanji", "sectionname_chome_kanji", "address_code"] カラムを含む DataFrame

##### TC-2.3.1: 正常系 - 有効な都道府県名

```
入力: "東京都"
期待値: DataFrame (東京都の住所マスタ)
アサーション1: isinstance(result, pd.DataFrame)
アサーション2: "oaza_popularname_kanji" in result.columns
アサーション3: "sectionname_chome_kanji" in result.columns
アサーション4: "address_code" in result.columns
アサーション5: len(result) > 0
```

---

##### TC-2.3.2: 異常系 - 空文字列

```
入力: ""
期待値: DataFrame (オプショナルパラメータのデフォルト)
アサーション: isinstance(result, pd.DataFrame)
```

---

#### テスト対象関数: get_address_master_with_code

**出力契約テストの定義**:
- 都道府県コードからアドレスマスタ DataFrame を取得
- 戻り値型: pd.DataFrame
- 戻り値スキーマ: get_address_master_with_name と同一

##### TC-2.4.1: 正常系 - 有効な都道府県コード

```
入力: 13  # 東京都
期待値: DataFrame (東京都の住所マスタ)
アサーション: isinstance(result, pd.DataFrame)
アサーション: "oaza_popularname_kanji" in result.columns
```

---

##### TC-2.4.2: 異常系 - None を指定

```
入力: None
期待値: DataFrame (全国の住所マスタ、または空)
アサーション: isinstance(result, pd.DataFrame)
```

---

### 1.3 lib/utils.py（ユーティリティ関数）

#### テスト対象関数: json_serial

**出力契約テストの定義**:
- datetime/date オブジェクトを ISO 形式文字列に変換
- その他は str() で変換
- 戻り値型: str
- 呼び出い元: to_json() で default handler として使用

##### TC-3.1.1: 正常系 - date オブジェクト

```
入力: date(2026, 5, 1)
期待値: "2026-05-01"
アサーション: result == "2026-05-01"
アサーション: isinstance(result, str)
```

---

##### TC-3.1.2: 正常系 - datetime オブジェクト

```
入力: datetime(2026, 5, 1, 12, 30, 45)
期待値: "2026-05-01T12:30:45"
アサーション: result.startswith("2026-05-01")
アサーション: "T" in result
```

---

##### TC-3.1.3: 正常系 - 数値（int）

```
入力: 12345
期待値: "12345"
アサーション: result == "12345"
```

---

##### TC-3.1.4: 正常系 - 文字列

```
入力: "test_string"
期待値: "test_string"
アサーション: result == "test_string"
```

---

#### テスト対象関数: to_json

**出力契約テストの定義**:
- オブジェクトを JSON 文字列に変換
- date/datetime は ISO 形式に変換
- 戻り値は JSON 形式の文字列
- 呼び出い元: API レスポンス生成など

##### TC-3.2.1: 正常系 - InputConditions オブジェクト

```
入力: InputConditions(
    start_date=date(2026, 1, 1),
    end_date=date(2026, 1, 31),
    prefecture_cd="13"
)
期待値: JSON 文字列で start_date が "2026-01-01" として表現
アサーション: isinstance(result, str)
アサーション: '"start_date": "2026-01-01"' in result
```

---

##### TC-3.2.2: 正常系 - 辞書（複合オブジェクト）

```
入力: {
    "date": date(2026, 5, 1),
    "count": 123,
    "name": "東京"
}
期待値: JSON で各フィールドが正確に表現
アサーション: '"date": "2026-05-01"' in result
アサーション: '"count": 123' in result
```

---

##### TC-3.2.3: 異常系 - ensure_ascii=False（日本語対応）

```
入力: {"name": "東京"}
期待値: JSON で 東京 が UTF-8 で保持（エスケープなし）
アサーション: "東京" in result
```

---

#### テスト対象関数: get_streamlit_session_id

**出力契約テストの定義**:
- 現在の Streamlit セッション ID を返す
- 戻り値型: str
- Layer 2 テストで直接テスト可能（モック必要）

##### TC-3.3.1: 正常系 - セッション ID 取得

```
入力: (Streamlit セッション実行中)
期待値: セッション ID 文字列
アサーション: isinstance(result, str)
アサーション: len(result) > 0
モック: streamlit.runtime.scriptrunner.get_script_run_ctx() をモック
```

---

### 1.4 lib/session_manager/snowflake_sqlalchemy.py（セッション管理）

#### テスト対象関数: get_snowflake_sqlalchemy_session（モック可能な部分）

**出力契約テストの定義**:
- Snowflake SQLAlchemy セッションを取得または再利用
- 戻り値型: Session（SQLAlchemy）
- 呼び出い元: 全データローダー関数で DB クエリ実行に使用
- 呼び出い元の期待値: session.bind が Snowflake エンジンであること、session.query() が可能であること

##### TC-4.1.1: 正常系 - セッション取得

```
入力: (デフォルト)
期待値: Session オブジェクト
アサーション1: hasattr(result, "query")
アサーション2: hasattr(result, "bind")
モック: PochiEnvironment().get_snowflake_sqlalchemy_session() をモック
```

**テストコース理由**: セッション管理の戻り値が SQLAlchemy Session インターフェースを満たすことを確認。DEPS-001, ARCH-002 対応。

---

##### TC-4.1.2: 異常系 - Snowflake 接続エラー時

```
入力: (接続失敗のモック)
期待値: Exception が raise される
アサーション: raises Exception
モック: snowflake.connector.connect() をモック側で失敗させる
```

---

#### テスト対象関数: clear_cache_snowflake_sqlalchemy_session

**出力契約テストの定義**:
- キャッシュされたセッションを削除し、session_state をリセット
- 戻り値: None（副作用でセッションが削除される）
- 呼び出い元: visualization_tool.py で検索条件変更時に呼ばれる

##### TC-4.2.1: 正常系 - キャッシュ削除

```
入力: (キャッシュあり)
期待値: 副作用でセッションが削除される
アサーション: st.cache_resource.clear() または同等が実行される
モック: st.session_state, streamlit.runtime.caching をモック
```

---

### 1.5 lib/data_loader/utils/fuzzy_search.py（ファジー検索）

#### テスト対象関数: generate_search_condition

**出力契約テストの定義**:
- ユーザー入力のキーワードから SQLAlchemy filter 条件を生成
- 戻り値型: sqlalchemy.sql.expression.BinaryExpression
- 呼び出い元: get_merchant_store_list_from_input_conditions() でクエリに filter() で適用
- 呼び出い元の期待値: SQL の WHERE 句として適切に機能すること

##### TC-5.1.1: 正常系 - 単純キーワード

```
入力: 
  - column: GeocodingAddressMst.store_name
  - search_word: "ドコモショップ"
期待値: SQLAlchemy filter 条件
アサーション1: result is not None
アサーション2: str(result) に filter 的な表現が含まれる
セキュリティ: SQL Injection 対策が入っていることを確認（SEC-001 対応）
```

---

##### TC-5.1.2: 正常系 - 特殊文字を含むキーワード

```
入力:
  - column: GeocodingAddressMst.store_name
  - search_word: "ショップ\&販売"  # & を含む
期待値: SQLAlchemy が安全にエスケープ
アサーション: エスケープされた形式で SQL が生成される
```

**テストコース理由**: 特殊文字（&, ', ", %, _）のエスケープを確認。SEC-001 対応。

---

##### TC-5.1.3: 異常系 - 空キーワード

```
入力: 
  - search_word: ""
期待値: Exception または empty condition が返される
アサーション: result is not None または exception が raise
```

---

#### テスト対象関数: whoosh_to_sqlalchemy

**出力契約テストの定義**:
- Whoosh の検索条件を SQLAlchemy に変換
- 戻り値型: sqlalchemy filter condition

##### TC-5.2.1: 正常系 - Whoosh クエリ変換

```
入力: (Whoosh Query オブジェクト)
期待値: SQLAlchemy filter 条件
アサーション: result is not None
```

---

### 1.6 lib/data_loader/data_models/merchant_key.py（データモデル）

#### テスト対象クラス: MerchantStoreKey

**出力契約テストの定義**:
- 加盟店キーの 3 要素（site_id_cpid, company_code, store_code）を保持
- 戻り値: dataclass インスタンス
- 呼び出い元: create_settlement_records() で中間テーブル生成に使用

##### TC-6.1.1: 正常系 - オブジェクト作成と属性検証

```
入力: MerchantStoreKey(
    site_id_cpid="site_001",
    company_code="comp_001",
    store_code="store_001"
)
期待値: 3つの属性が正確に保持される
アサーション1: result.site_id_cpid == "site_001"
アサーション2: result.company_code == "comp_001"
アサーション3: result.store_code == "store_001"
```

---

#### テスト対象クラス: MerchantStoreKeyList

**出力契約テストの定義**:
- MerchantStoreKey のリストを管理
- 戻り値: dataclass リスト

##### TC-6.2.1: 正常系 - リスト操作

```
入力: MerchantStoreKeyList(keys=[...])
期待値: リスト内の全要素にアクセス可能
アサーション: len(result.keys) > 0
```

---

### 1.7 lib/generate_analysis_result_data.py（分析データ生成、モック対象）

#### テスト対象関数: get_east_asian_width_count

**出力契約テストの定義**:
- 東アジア文字（日本語）の幅を計算
- 戻り値型: int

##### TC-7.1.1: 正常系 - 日本語文字列

```
入力: "東京"
期待値: 4 (東=2, 京=2)
アサーション: result == 4
```

---

##### TC-7.1.2: 正常系 - ASCII 文字列

```
入力: "Tokyo"
期待値: 5 (T=1, o=1, k=1, y=1, o=1)
アサーション: result == 5
```

---

##### TC-7.1.3: 正常系 - 混在文字列

```
入力: "東京1号"
期待値: 6 (東=2, 京=2, 1=1, 号=1)
アサーション: result == 6
```

---

### 1.8 lib/merchant_keyword_search.py（キーワード検索、モック対象）

#### テスト対象関数: create_map（Streamlitデコレータ付きのため Layer 3 移行）

**注記**: @st.cache_data 付きのため Layer 3 統合テストとして配置。ここでは記載のみ。

---

## 2. テスト実装アーキテクチャ

### 2.1 ディレクトリ構成

```
tests/
├── unit/                           # Layer 2 ユニットテスト
│   ├── test_models.py              # InputConditions, RenderOptions
│   ├── test_address.py             # address.py のデコレータなし関数
│   ├── test_utils.py               # utils.py の純粋関数
│   ├── test_session_manager.py     # セッション管理
│   ├── test_fuzzy_search.py        # ファジー検索（SQL Injection テスト含む）
│   ├── test_merchant_key.py        # データモデル
│   ├── test_generate_analysis.py   # 分析データ生成ユーティリティ
│   └── test_merchant_keyword.py    # キーワード検索ユーティリティ
│
├── integration/                    # Layer 3 統合テスト（AppTest）
│   ├── test_address_integration.py # @st.cache_data 付き関数
│   ├── test_graph_data.py          # 集計関数群（15 関数）
│   └── ... その他 Layer 3
│
└── conftest.py                     # 共有フィクスチャ、モック設定
```

### 2.2 conftest.py の必須要素

```python
# conftest.py の構成（必須）

import sys
import os
from unittest.mock import MagicMock
import pytest

# 1. sys.modules モック（Pochilib, Streamlit 依存）
_MOCK_MODULES = [
    "pochilib",
    "pochilib.snowflake",
    "pochilib.llm",
    "streamlit",
    "streamlit_folium",
    "whoosh",
    "sqlalchemy",
    "shapely",
    "jinja2",
    "kaleido",
    "snowflake.connector",
    "streamlit.runtime",
    "streamlit.runtime.scriptrunner",
    "streamlit.runtime.state",
    "streamlit.components",
    "streamlit.delta_generator",
]

# sys.modules にモック追加
for module_name in _MOCK_MODULES:
    sys.modules[module_name] = MagicMock()

# 2. sys.path に app/ を追加
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

# 3. Streamlit キャッシュデコレータをパススルーに差し替え
def _passthrough_decorator(func=None, **kwargs):
    if func is not None:
        return func
    return lambda f: f

sys.modules["streamlit"].cache_data = _passthrough_decorator
sys.modules["streamlit"].cache_resource = _passthrough_decorator

# 4. pytest フィクスチャの定義
@pytest.fixture
def input_conditions_valid():
    """有効な InputConditions インスタンス"""
    from datetime import date
    from lib.models import InputConditions
    return InputConditions(
        start_date=date(2026, 1, 1),
        end_date=date(2026, 1, 31),
        prefecture_cd="13",
        city_cd=["1001"],
        enable_comparison=False
    )

@pytest.fixture
def mock_snowflake_session():
    """Snowflake セッションのモック"""
    mock_session = MagicMock()
    mock_session.bind = MagicMock()
    return mock_session
```

---

## 3. テスト実装の品質基準（必須）

### 3.1 アサーション具体性ルール

**禁止パターン**:
```python
# ❌ 存在確認のみ
assert result is not None
assert isinstance(result, bool)

# ❌ 型確認のみ
assert isinstance(result, pd.DataFrame)
```

**推奨パターン**:
```python
# ✅ 具体値の完全一致
assert result is True
assert result == "2026-05-01"

# ✅ スキーマ・構造の明示
assert "oaza_popularname_kanji" in result.columns
assert result.shape[0] > 0
assert result.dtypes["oaza_popularname_kanji"] == "object"

# ✅ 内容の検証
assert "error" not in result.get("message", "")
assert result["prefecture_cd"] in ["13", "27"]
```

### 3.2 出力契約テストの基本パターン

```python
def test_function_name_outputs_match_caller_expectations():
    """
    関数の戻り値が呼び出い元の期待形式を満たすことを検証
    
    出力契約:
      - 戻り値型: bool
      - 値の範囲: True または False
      - スキーマ: N/A（単純型）
    
    呼び出い元: visualization_tool.on_click_search_button()
    呼び出い元の期待値: bool で検索条件の妥当性を判定
    """
    # Arrange: テストデータ準備
    conditions = InputConditions(...)
    
    # Act: 関数実行
    result = conditions.check
    
    # Assert: 出力契約検証
    assert isinstance(result, bool), "戻り値は bool 型であること"
    assert result is True, "有効な条件では True を返す"
```

### 3.3 リスク対応テストの実装ガイド

```python
def test_input_conditions_check_DATA_001_all_search_modes():
    """
    DATA-001: InputConditions の複雑な検証ロジック
    リスク: 4 つの検索条件の OR 判定が複雑で実装ミスが発生しやすい
    
    対応テスト: 全 16 パターン（2^4 組み合わせ）中の重要パターン
    """
    # TC-1.1.5 対応: 複数検索条件が同時に有効な場合
    conditions = InputConditions(
        start_date=date(2026, 1, 1),
        end_date=date(2026, 1, 31),
        prefecture_cd="13",
        city_cd=["1001"],
        keyword_search_word="ショップ",
        enable_comparison=False
    )
    
    assert conditions.check is True, "OR 条件が複数満たされても True"
```

---

## 4. リスク対応テストマッピング

| リスクID | リスク概要 | 対応テストケース | Layer |
|---------|---------|--------------|------|
| TST-001 | テストコード欠落 | TC-1.1.1～9（InputConditions検証） | 2 |
| TST-002 | キャッシュ戦略複雑性 | TC-4.1.1（セッション取得検証） | 2 |
| DATA-001 | InputConditions複雑検証 | TC-1.1.5～7、9（複雑OR判定） | 2 |
| DEPS-001 | Pochilib依存性 | TC-4.1.1～2（セッション管理） | 2 |
| DATA-002 | NULL値処理不統一 | TC-2.1.2～3（リスト・ネスト処理） | 2 |
| SEC-001 | SQL Injection潜在リスク | TC-5.1.2（特殊文字エスケープ） | 2 |
| SEC-002 | 個人情報取得リスク | （Layer 3）test_user_list_download | 3 |

---

## 5. テスト実施予定（T2フェーズ）

### 生成予定テスト数（定量目標）

**test-viewpoints.json の Layer 2 観点数**: 約 45 件

**計算根拠**:
- test-viewpoints.json から layer=2 のエントリを count
- Layer 2 最低生成数 = 45 × 2 = **90 件以上**

**実装予定分布**:
- 正常系テスト: 90 × 0.40 = **36 件**
- 異常系テスト: 90 × 0.50 = **45 件**
- 境界値テスト: 90 × 0.10 = **9 件**

**配置先**:
- tests/unit/ に約 90 件のテスト関数
- 各モジュール別に集約

---

## 6. 実装フェーズ別スケジュール

### フェーズ A（初期実装）: 1 日目
- [ ] conftest.py の基本設定（sys.modules, sys.path）
- [ ] test_models.py: InputConditions の 9 テストケース実装
- [ ] test_models.py: RenderOptions の 3 テストケース実装
- [ ] テスト実行確認（pytest --collect-only）

### フェーズ B（リスク対応）: 2 日目
- [ ] test_address.py: remove_none_and_list_keys（4 TC）
- [ ] test_address.py: get_pref_code（4 TC）
- [ ] test_address.py: get_address_master_* （6 TC）
- [ ] test_session_manager.py: セッション管理（4 TC）

### フェーズ C（セキュリティ・ユーティリティ）: 3 日目
- [ ] test_fuzzy_search.py: ファジー検索（3 TC、SEC-001対応）
- [ ] test_utils.py: json_serial, to_json（6 TC）
- [ ] test_merchant_key.py: データモデル（3 TC）
- [ ] test_generate_analysis.py: ユーティリティ（3 TC）

### フェーズ D（検証・補完）: 4 日目
- [ ] Layer 2 テスト総数確認（90 件以上）
- [ ] 比率検証（正常系 40%, 異常系 50%, 境界値 10%）
- [ ] リスク対応テスト全数確認
- [ ] pytest 実行、カバレッジ確認

---

## 付録 A: テストフィクスチャマッピング（fixtures/manifest.json から）

| フィクスチャID | 用途 | Layer | 関連テストケース |
|-------------|------|------|----------------|
| input_conditions_basic | InputConditions正常系 | 1/2 | TC-1.1.1～4 |
| input_conditions_missing_required | 必須フィールド欠損 | 1/2 | TC-1.1.5 |
| input_conditions_comparison_missing | 条件付き必須欠損 | 1/2 | TC-1.1.7 |
| settlement_records | 決済レコード | 1/3 | （Layer 3） |
| render_options | 描画オプション | 1/2 | TC-1.2.1～3 |

---

## 付録 B: モック戦略ガイド

### B.1 必須モック対象

| モジュール | モック理由 | 差し替え内容 |
|----------|---------|-----------|
| pochilib.snowflake | 外部依存、認証必須 | MagicMock |
| streamlit | ランタイム依存 | @st.cache_* = _passthrough_decorator |
| snowflake.connector | ライセンス・認証 | MagicMock |
| sqlalchemy | DB接続 | MagicMock（Session） |

### B.2 モック不要（実装使用）

| モジュール | 理由 |
|----------|------|
| pandas | 純粋な計算ライブラリ |
| numpy | 純粋な計算ライブラリ |
| datetime | 標準ライブラリ |
| json | 標準ライブラリ |

---

**設計完了日**: 2026-05-01  
**次の操作**: T2 フェーズでテストコード生成実施
