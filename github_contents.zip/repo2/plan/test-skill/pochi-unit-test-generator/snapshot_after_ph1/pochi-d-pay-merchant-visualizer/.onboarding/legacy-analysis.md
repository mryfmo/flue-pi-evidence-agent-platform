# レガシー解析レポート - d払い決済状況見える化ツール

**生成日**: 2026-05-01  
**解析対象**: /home/user/pochi-d-pay-merchant-visualizer-repository/app  
**エントリポイント**: app/main.py  
**フレームワーク**: Streamlit + Snowflake + SQLAlchemy  
**言語**: Python 3.x  

---

## 1. 概要

d払い決済状況見える化ツール（"見える化ツール"）は、Streamlit ベースの Web アプリケーションです。  
d払い決済データを複数の角度から可視化・分析し、加盟店や決済統計を地図・グラフで表現します。

### 主要目的
- 決済統計の多次元集計（業態別、性別、年代別、決済金額帯別、時間別）
- 加盟店検索・地図表示
- 期間比較機能による推移分析
- データの CSV ダウンロード

### 技術スタック
| 層 | 技術・フレームワーク |
|----|-----------------|
| **フロントエンド** | Streamlit (Python) |
| **バックエンド** | SQLAlchemy ORM + Snowflake |
| **共通ライブラリ** | Pochilib (pochilib.snowflake, pochilib.llm) |
| **データベース** | Snowflake Data Warehouse |
| **地図描画** | Folium + Streamlit-Folium |
| **テスト** | pytest (未実装) |

---

## 2. アプリケーション構造

### 2.1 ディレクトリツリー

```
app/
├── main.py                              # エントリポイント（ページナビゲーション）
├── _初期表示.py                          # 初期表示（非アクティブ）
├── app_pages/                           # Streamlit マルチページ構成
│   ├── visualization_tool.py           # 主要ページ（見える化ツール）
│   ├── app_designer.py                 # App Designer ページ
│   ├── about_this_app.py               # アプリ説明
│   ├── data_sources.py                 # データソース説明
│   ├── how_to_use.py                   # 使い方ガイド
├── lib/                                 # メインロジック層
│   ├── models.py                       # InputConditions, RenderOptions
│   ├── const.py                        # グローバル定数
│   ├── utils.py                        # ユーティリティ関数
│   ├── address.py                      # 住所入力 UI コンポーネント
│   ├── merchant_map.py                 # 加盟店地図描画
│   ├── merchant_keyword_search.py      # キーワード検索 UI
│   ├── store_search.py                 # 店舗検索 UI
│   ├── graph_visualizer.py             # グラフ描画
│   ├── generate_analysis_result_data.py # CSV ダウンロード機能
│   ├── generate_user_list.py           # ユーザーリスト生成
│   ├── folium_utils.py                 # Folium ユーティリティ
│   ├── profiling_util.py               # プロファイリング（開発用）
│   ├── patch/                          # Streamlit モンキーパッチ
│   │   ├── _execute_patch.py
│   │   └── _streamlit_antd_components/ # Ant Design コンポーネント
│   ├── session_manager/                # Snowflake セッション管理
│   │   └── snowflake_sqlalchemy.py
│   ├── app_designer/                   # App Designer 機能
│   │   ├── session_state.py
│   │   ├── solution_engine.py
│   │   └── export_handler.py
│   ├── app_designer_catalogs/          # App Designer カタログ
│   │   └── catalogs/loader.py
│   └── data_loader/                    # 【重要】データレイヤー
│       ├── _base.py                    # 決済レコード基盤テーブル
│       ├── _graph_data.py              # 【メイン】多次元集計
│       ├── _merchant_store.py          # 加盟店リスト取得
│       ├── _map_data.py                # 地図表示用データ
│       ├── _store_information_management.py # 店舗情報管理
│       ├── _user_list_data.py          # ユーザーリスト
│       ├── _address.py                 # 住所情報
│       ├── _settlement_integration_jenre.py
│       ├── const.py                    # データローダー定数
│       ├── data_models/                # データモデル定義
│       │   ├── merchant_key.py
│       ├── intermediate_data_builder/  # 中間データ構築
│       │   ├── merchant_keys.py
│       │   └── settlement.py
│       ├── sa_models/                  # SQLAlchemy モデル
│       │   ├── base.py
│       │   ├── vw_*.py (テーブルマッピング)
│       ├── utils/
│       │   └── fuzzy_search.py         # ファジー検索
└── reporting_function/                 # レポート機能
    ├── _reporting_page.py
    ├── _address_input_form.py
    ├── _check.py
    ├── _query_params.py
    └── _utils.py
```

### 2.2 モジュール統計

| 区分 | 数値 |
|------|------|
| **総モジュール数** | 63 |
| **総行数（Python）** | 9,074 行 |
| **Streamlit デコレータあり** | 15 モジュール（39 個デコレータ） |
| **Snowflake/SQLAlchemy 接続** | 21 モジュール |
| **Pochilib 依存** | 10 モジュール |
| **テストファイル** | 0 個（全欠落） |

---

## 3. 主要機能フロー

### 3.1 データ取得フロー

```
┌──────────────────────────┐
│ visualization_tool.py    │（ユーザー入力）
│ - 日付範囲選択           │
│ - 住所条件（or 検索条件）│
│ - グラフ表示オプション   │
└────────┬─────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│ InputConditions オブジェクト生成         │
│ - start_date, end_date                  │
│ - prefecture_cd, city_cd, ... (or kw...) │
│ - enable_comparison, comparison_dates    │
└────────┬────────────────────────────────┘
         │
         ▼
┌────────────────────────────────────────────────────────────┐
│ lib/data_loader/ (データレイヤー)                         │
├────────────────────────────────────────────────────────────┤
│ 1. create_settlement_records_query_from_input_conditions   │
│    @st.cache_resource(ttl=300, Session hash)             │
│    ├── get_merchant_store_list()                          │
│    │   @st.cache_resource(ttl=1800)                       │
│    │   └─ Snowflake: PochiDbaraiCityStoreMaster           │
│    └── create_settlement_records()                         │
│        └─ 決済統合テーブル生成（動的SQL）                │
│                                                            │
│ 2. 集計関数群 @st.cache_data(ttl=1800)                   │
│    ├── get_si_statistics()                                │
│    │   ├── 店舗数, 決済合計金額, 平均金額, 決済回数      │
│    │   └── ユニークユーザー数                             │
│    │                                                      │
│    ├── get_si_agg_by_industry()       ┐                  │
│    ├── get_si_agg_by_gender()         ├─ DataFrame       │
│    ├── get_si_agg_by_nendai()         │ (各次元別)        │
│    ├── get_si_agg_by_payment_amount() ┤                  │
│    ├── get_agg_for_each_hour()        │                  │
│    └── get_agg_for_each_day()         ┘                  │
│                                                            │
│ 3. 比較期間集計 @st.cache_data(ttl=1800)                │
│    ├── get_si_statistics_comparison()                     │
│    ├── get_si_agg_by_industry_comparison()               │
│    ├── get_si_agg_by_gender_comparison()                 │
│    ├── get_si_agg_by_nendai_comparison()                 │
│    ├── get_si_agg_by_payment_amount_comparison()         │
│    ├── get_agg_for_each_day_comparison()                 │
│    └── get_agg_for_each_hour_comparison()                │
│        ※ enable_comparison=False の場合は空DataFrame   │
└────────┬───────────────────────────────────────────────────┘
         │ Pandas DataFrame
         ▼
┌────────────────────────────────────┐
│ UI コンポーネント描画              │
├────────────────────────────────────┤
│ - graph_visualizer.py              │
│   └─ Matplotlib/Plotly グラフ      │
│                                    │
│ - merchant_map.py                  │
│   └─ Folium 地図                   │
│                                    │
│ - 表形式テーブル                   │
│   └─ st.dataframe(), st.table()   │
└────────────────────────────────────┘
```

### 3.2 検索条件の4つのモード

```
InputConditions.check() では以下のいずれか1つが必須：

【モード 1】住所条件検索
├─ prefecture_cd（都道府県コード）+ city_cd（市区町村コード）
├─ address_cd（住所コード）
├─ aza_cd（ジオコーディング字コード）

【モード 2】キーワード検索
├─ keyword_search_method（"company_store" / "company" / "store" / "address"）
└─ keyword_search_word（検索ワード）

【モード 3】地図検索
├─ map_search_latitude（中心緯度）
├─ map_search_longitude（中心経度）
└─ map_search_radius_km（検索半径）

【モード 4】店舗検索
├─ selected_store_id（選択店舗ID）
├─ store_center_latitude（中心緯度）
├─ store_center_longitude（中心経度）
└─ store_search_radius_km（検索半径）
```

---

## 4. キャッシング戦略

### 4.1 @st.cache_resource（状態保持オブジェクト用）

```python
# 決済レコード基盤テーブル
@st.cache_resource(ttl=300, show_spinner=False, hash_funcs={Session: lambda session: id(session)})
def create_settlement_records_query_from_input_conditions(session, conditions):
    # TTL: 300秒（5分）
    # Hash: Session ID（メモリ上のセッション同一性）
    
# 加盟店リスト
@st.cache_resource(show_spinner=False, ttl=1800)
def get_merchant_store_list(...):
    # TTL: 1800秒（30分）
```

**特徴**:
- ウィジェットなど状態を持つオブジェクトに使用
- SessionのIDハッシング戦略は脆弱（メモリ再割り当てで別IDになる可能性あり）

### 4.2 @st.cache_data（計算結果用）

```python
# 統計情報集計
@st.cache_data(show_spinner=False, persist=False, ttl=1800)
def get_si_statistics(conditions):
    # TTL: 1800秒（30分）
    # persist: False（キャッシュを保存しない、セッション内のみ）
    
    # 【注意】enable_comparison フラグに応じて use_session_cache を切り替え
    if not conditions.enable_comparison:
        session = get_snowflake_sqlalchemy_session("Large", use_session_cache=True)
    else:
        session = get_snowflake_sqlalchemy_session("Large", use_session_cache=False)
        # 比較期間データ取得時は常に最新データを取得（キャッシュなし）
```

**特徴**:
- DataFrame など状態レスな計算結果用
- persist=False によりセッション内キャッシュのみ
- **特異な仕様**: enable_comparison フラグで cache 有効/無効を切り替え

---

## 5. エコシステム依存

### 5.1 Pochilib（共通ライブラリ）への依存

**依存するモジュール（10個）**:
1. `reporting_function/_reporting_page.py` - PochiEnvironment
2. `lib/session_manager/snowflake_sqlalchemy.py` - PochiEnvironment
3. `app_pages/visualization_tool.py` - PochiEnvironment, user_interface_support
4. `lib/data_loader/_merchant_store.py` - PochiEnvironment
5. その他 5 個モジュール

**主要API**:
- `PochiEnvironment()` - 環境判定（prod/dev）
- `get_snowflake_sqlalchemy_session()` - Snowflake セッション取得
- `pochilib.user_interface_support` - UI生成ユーティリティ

**リスク**: Pochilib 更新による破壊的変更が即座に影響

### 5.2 Snowflake テーブル依存

**参照テーブル一覧**:

| テーブル/ビュー | 用途 | 環境分岐 |
|---|---|---|
| vw_dic_dnhd_settlement_integration | 決済統合テーブル | なし |
| vw_adw_dncl_store_information_management_master | 店舗情報管理マスタ | なし |
| vw_hmd_mjcd_integration_genre_master | 業態・ジャンルマスタ | なし |
| pj_ml_geocoding_address_mst | ジオコーディング住所マスタ | なし |
| pj_ml_geocoding_dbarai_mst | ジオコーディングd払いマスタ | なし |
| PochiDbaraiCityStoreMaster | 加盟店マスタ | **prod のみ** |
| PochiDbaraiCityStoreMasterDev | 加盟店マスタ | **dev/test のみ** |

**環境判定ロジック**:
```python
env = PochiEnvironment()
if env.stage == "prod":
    mst = PochiDbaraiCityStoreMaster
else:
    mst = PochiDbaraiCityStoreMasterDev
```

---

## 6. コード品質指標

### 6.1 ファイルサイズと複雑度（行数ベース）

| ランク | ファイル | 行数 | 複雑度推定 |
|--------|---------|------|----------|
| 1 | visualization_tool.py | 1,063 | **VERY HIGH** |
| 2 | graph_visualizer.py | 560 | HIGH |
| 3 | merchant_map.py | 540 | HIGH |
| 4 | generate_analysis_result_data.py | 538 | HIGH |
| 5 | data_sources.py | 504 | MEDIUM-HIGH |
| 6 | app_designer.py | 526 | MEDIUM-HIGH |
| 7 | address.py | 512 | MEDIUM-HIGH |
| 8 | _graph_data.py | 456 | **HIGH（ロジック密度）** |
| 9 | _reporting_page.py | 559 | HIGH |
| 10 | folium_utils.py | 276 | MEDIUM |

**懸念事項**:
- visualization_tool.py が 1000行超え（単一モジュールに責務が集中）
- _graph_data.py が 456行（集計ロジックの密度が高い）

### 6.2 テストカバレッジ

| 項目 | 現状 | 目標 |
|------|------|------|
| **テスト総数** | 0 個 | 80+ 個（T2で追加予定） |
| **カバレッジ** | 0% | 60%（skill-config で指定） |
| **Layer 2** | なし | ユニットテスト（データローダー、集計ロジック） |
| **Layer 3** | なし | 統合テスト（UI + データ層） |

---

## 7. アーキテクチャパターン分析

### 7.1 クリーンアーキテクチャ適合性：**低**

#### 現状構造
```
app_pages/visualization_tool.py (1063行)
├── st.sidebar UI 描画
├── InputConditions オブジェクト生成
├── lib/data_loader.get_si_* 呼び出し
└── graph_visualizer/merchant_map で描画
```

**問題点**:
- プレゼンテーション層とビジネス層の分離が不十分
- データローダー関数が Streamlit デコレータ（@st.cache_*）に依存
  → Streamlit 以外のフレームワークでの再利用不可
- 入力UI、条件オブジェクト生成、データ取得、表示がモノリシック

### 7.2 推奨アーキテクチャ（理想形）

```
Presentation Layer（UI）
├── visualization_tool.py（入力UI ← → st.session_state）
└── components/ → st.container で再利用可能な部品化

Business Logic Layer（検証・集計）
├── models.py（InputConditions）
├── validators/（データ検証）
└── aggregators/（集計ロジック）
    ※ Streamlit デコレータなし（テスト容易）

Data Access Layer
├── data_loader/（DB クエリ）
│   ※ @st.cache_resource, @st.cache_data はこの層に閉じ込める
└── repositories/（マスタデータ取得）

Infrastructure Layer
├── snowflake_sqlalchemy.py（セッション管理）
├── pochilib integration（PochiEnvironment など）
└── config/（定数、環境変数）
```

---

## 8. 集計ロジック仕様

### 8.1 基本集計（get_si_statistics）

**入力**: InputConditions  
**出力**: 
```
┌──────────────┬───────┐
│ 店舗数       │ N     │
│ 決済合計金額  │ Y 万円│
│ 決済平均金額  │ Z 万円│
│ 決済回数      │ M 件  │
│ ユーザー数    │ U 人  │
└──────────────┴───────┘
```

**計算式**:
- 店舗数 = COUNT(DISTINCT site_id_cpid || company_code || store_code)
- 決済合計金額 = SUM(pay_money_amount_total)
- 決済平均金額 = SUM(pay_money_amount_total) / COUNT()
- 決済回数 = COUNT()
- ユーザー数 = COUNT(DISTINCT comnid)

### 8.2 多次元集計パターン

#### 業態別集計（get_si_agg_by_industry）
```
GROUP BY settlement_integration_genre_large_classification
```

#### 性別別集計（get_si_agg_by_gender）
```
CASE gender_code
  WHEN '1' THEN '男性'
  WHEN '2' THEN '女性'
  ELSE '不明'
END AS 性別
出力順: 男性 → 女性 → 不明
```

#### 年代別集計（get_si_agg_by_nendai）
```
CASE nendai_code
  WHEN '00' THEN '10代未満'
  WHEN '01' THEN '10代'
  ...
  WHEN '08' THEN '80代以上'
  ELSE '不明'
END AS 年代
出力順: 10代未満 → 10代 → ... → 80代以上 → 不明
※ 欠落グループは fill_value=0 で補完
```

#### 決済金額帯別集計（get_si_agg_by_payment_amount）
```
CASE pay_money_amount_total
  WHEN < 5000 THEN '1_0～5000円'
  WHEN < 10000 THEN '2_5000～10000円'
  ...
  ELSE '9_不明'
END
※ UI表示時に先頭の数字_を削除
```

#### 時間別集計（get_agg_for_each_hour）
```
GROUP BY EXTRACT(HOUR FROM settlement_use_date)
```

#### 日別集計（get_agg_for_each_day）
```
GROUP BY CAST(settlement_use_date AS DATE)
```

### 8.3 業態×店舗別集計（get_si_agg_by_industry_and_stores）

**特殊処理**: ランキングと上位N件抽出
```sql
WITH ranked_data AS (
  SELECT
    site_id_cpid, company_code, store_code,
    settlement_integration_genre_large_classification,
    SUM(pay_money_amount_total) AS 決済合計金額,
    ROW_NUMBER() OVER (
      PARTITION BY settlement_integration_genre_large_classification
      ORDER BY SUM(pay_money_amount_total) DESC
    ) AS rn
  FROM base_tbl
  GROUP BY ...
)
SELECT * FROM ranked_data WHERE rn <= max_rows_per_industry (デフォルト: 50)
```

---

## 9. 既知の非標準実装

### 9.1 キャッシング戦略の非標準性

**問題**: @st.cache_resource と @st.cache_data を混在させている
- 理由：Session オブジェクト（状態保持）と DataFrame（計算結果）の両方が必要
- 結果：キャッシュ動作が複雑で、テスト困難

### 9.2 enable_comparison フラグの特異な使用

**問題**: 比較期間データ取得時に use_session_cache を False にする
```python
if not conditions.enable_comparison:
    session = ... use_session_cache=True
else:
    session = ... use_session_cache=False  # キャッシュなし！
```

**目的**: 比較対象データの鮮度確保（キャッシュの影響を避ける）  
**課題**: パフォーマンス低下（毎回 DB クエリ）

### 9.3 SQLAlchemy での動的テーブル参照

**問題**: create_settlement_records() で条件に応じて SQL を動的に構築
```python
baseTbl = create_settlement_records_query_from_input_conditions(session, conditions)
# baseTbl は SQLAlchemy CTE（Common Table Expression）
```

**課題**: SQL生成ミスが発生しやすい（テストで確認必須）

---

## 10. セキュリティ考慮事項

### 10.1 ユーザー情報の取り扱い

- ユーザーリストダウンロード機能で comnid（ユーザーID）を含むCSVファイルを出力
- 権限チェック実装の有無が不明

### 10.2 キーワード検索の入力検証

- fuzzy_search.py で generate_search_condition() を使用
- SQLAlchemy による自動パラメタライズで SQL Injection は防止されているはず
- ただし、特殊文字（%, _, など）の処理を確認する必要あり

---

## 11. 今後の改善提案

### 11.1 アーキテクチャ改善

1. **プレゼンテーション層とビジネス層の分離**
   - visualization_tool.py を 500行 以下に分割
   - UI コンポーネントの再利用化

2. **データアクセス層の独立化**
   - @st.cache_* デコレータを別ファイル（cache_loaders.py など）に集約
   - テスト時のモック化を容易に

3. **設定管理の一元化**
   - マジックナンバー・文字列を const.py に集約
   - Enum 化による型安全性向上

### 11.2 テスト体系の整備

1. **Layer 2（ユニットテスト）**
   - 集計ロジック（_graph_data.py）
   - 検索条件検証（InputConditions.check）
   - NULL値処理、空結果処理

2. **Layer 3（統合テスト）**
   - Streamlit UI + データ層の統合
   - キャッシング戦略の検証

3. **パフォーマンステスト**
   - 大規模検索での実行時間・メモリ使用量
   - クエリ実行計画の最適化

### 11.3 ドキュメント整備

1. **API ドキュメント**: docstring の統一（Args, Returns, Raises）
2. **アーキテクチャドキュメント**: レイアー構成、データフロー図
3. **運用ドキュメント**: デプロイ手順、トラブルシューティング

---

## 12. モジュール一覧（主要）

| モジュール | 行数 | 用途 | Streamlit デコレータ |
|---|---|---|---|
| **visualization_tool.py** | 1,063 | メインページ | 複数 |
| **_graph_data.py** | 456 | 集計関数群 | 18個（@st.cache_data） |
| **merchant_map.py** | 540 | 地図表示 | 2個 |
| **graph_visualizer.py** | 560 | グラフ描画 | 複数 |
| **_merchant_store.py** | 259 | 加盟店リスト | 2個（@st.cache_resource） |
| **_base.py** | 52 | 決済レコードCTE | 1個（@st.cache_resource） |
| **address.py** | 512 | 住所入力UI | 複数 |
| **app_designer.py** | 526 | App Designer | 複数 |
| **models.py** | 106 | データクラス | なし |
| **const.py** | 40 | グローバル定数 | なし |

---

## 13. まとめ

### 現状評価

| 観点 | 評価 | コメント |
|------|------|---------|
| **機能性** | ✅ Good | 多様な検索・集計・可視化機能を実装 |
| **テスト** | ❌ Critical | テストが完全欠落 |
| **保守性** | ⚠️ Medium | 複雑な集計ロジック、ドキュメント不足 |
| **拡張性** | ⚠️ Medium | Streamlit に強く依存、再利用困難 |
| **パフォーマンス** | ⚠️ Medium | キャッシング戦略の複雑性、大規模検索時の未検証 |
| **セキュリティ** | ⚠️ Medium | 権限チェック、監査ログの不明確 |

### 次ステップ

1. **T1フェーズ**: ドラフト契約（data-contracts.json, business-rules.json）の確認
2. **T2フェーズ**: テスト実装（80件以上）、特に集計ロジックのキャラクタリゼーション
3. **T3フェーズ**: パフォーマンス・セキュリティテスト

---

**レポート作成**: T0（pochi-legacy-analyzer）  
**次の操作**: T1（契約確認） → T2（テスト生成）
