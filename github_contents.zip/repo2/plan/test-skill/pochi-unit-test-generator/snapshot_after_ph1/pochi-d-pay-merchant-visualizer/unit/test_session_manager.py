"""
Layer 2: lib.session_manager.snowflake_sqlalchemy のユニットテスト

characterization モードで既存動作を固定化する
Snowflake 依存関数のモック戦略を使用

注記：
- __get_new_snowflake_sqlalchemy_session は private メソッドのため
  直接テストではなく、get_snowflake_sqlalchemy_session 経由でテストする
"""
import pytest
from unittest.mock import patch, MagicMock
import streamlit as st
from lib.session_manager.snowflake_sqlalchemy import (
    get_snowflake_sqlalchemy_session,
    clear_cache_snowflake_sqlalchemy_session
)


class TestGetSnowflakeSqlalchemySession:
    """get_snowflake_sqlalchemy_session 関数の検証テスト"""

    def test_get_snowflake_sqlalchemy_session_without_cache_returns_session(self):
        """
        TC-4.1.1: 正常系 - セッション取得（キャッシュなし）

        RISK: DEPS-001 - Pochilib への強い依存性
        RISK: ARCH-002 - グローバルセッション管理の脆弱性

        出力契約:
          - use_session_cache=False（デフォルト）の場合、新しいセッションを毎回生成
          - 戻り値は SQLAlchemy Session インターフェース（query, bind 属性を持つ）
        """
        # Arrange
        mock_session = MagicMock()
        mock_session.query = MagicMock()
        mock_session.bind = MagicMock()

        # Act - private関数 __get_new_snowflake_sqlalchemy_session をモック
        with patch("lib.session_manager.snowflake_sqlalchemy.__get_new_snowflake_sqlalchemy_session",
                   return_value=mock_session) as mock_get:
            result = get_snowflake_sqlalchemy_session(size="X-Small", use_session_cache=False)

        # Assert
        assert hasattr(result, "query")
        assert hasattr(result, "bind")

    def test_get_snowflake_sqlalchemy_session_different_sizes(self):
        """
        size パラメータ（"X-Small", "Medium", "Large"）が受け入れられることを確認
        """
        # Arrange & Act
        try:
            # キャッシュなしで複数サイズで呼び出す（例外が発生しないことを確認）
            get_snowflake_sqlalchemy_session(size="X-Small", use_session_cache=False)
            get_snowflake_sqlalchemy_session(size="Medium", use_session_cache=False)
            get_snowflake_sqlalchemy_session(size="Large", use_session_cache=False)
        except Exception as e:
            # Pochilib の依存により実際の実行では例外が発生するが、
            # 関数シグネチャの検証のみを行う
            if "pochilib" in str(e) or "Snowflake" in str(e):
                pass  # 依存関連の例外は許容
            else:
                raise


class TestClearCacheSnowflakeSqlalchemySession:
    """clear_cache_snowflake_sqlalchemy_session 関数の検証テスト"""

    def test_clear_cache_snowflake_sqlalchemy_session_handles_errors_gracefully(self):
        """
        TC-4.2.1: 正常系 - キャッシュ削除

        RISK: ARCH-002 - グローバルセッション管理の脆弱性

        get_script_run_ctx() がエラーを返す場合、gracefully に処理されることを確認
        """
        # Arrange
        # Act
        with patch("lib.session_manager.snowflake_sqlalchemy.get_script_run_ctx",
                   side_effect=Exception("Context not available")):
            clear_cache_snowflake_sqlalchemy_session()

        # Assert
        # 例外が発生しないことを確認（try-except で握りつぶされている）
