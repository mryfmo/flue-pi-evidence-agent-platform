"""
Layer 2: lib.data_loader.utils.fuzzy_search のユニットテスト

characterization モードで既存動作を固定化する
SQL Injection セキュリティ検証を含む
"""
import pytest
from unittest.mock import MagicMock
from sqlalchemy import Column, String
from lib.data_loader.utils.fuzzy_search import (
    generate_search_condition,
    whoosh_to_sqlalchemy
)


class DummyTable:
    """SQLAlchemy Column をテストするためのダミーテーブル"""
    content = Column(String, name="content")


class TestGenerateSearchCondition:
    """generate_search_condition 関数の検証テスト"""

    def test_generate_search_condition_simple_keyword_returns_sqlalchemy_condition(self):
        """
        TC-5.1.1: 正常系 - 単純キーワード

        RISK: SEC-001 - SQL Injection の潜在リスク

        シンプルなキーワードに対して SQLAlchemy filter 条件を生成する
        戻り値は SqlAlchemy ColumnElement であり、SQL に変換可能であること
        """
        # Arrange
        search_word = "ドコモショップ"
        column = DummyTable.content

        # Act
        result = generate_search_condition(search_word, column)

        # Assert
        assert result is not None
        # SQLAlchemy ColumnElement のチェック（str() で SQL に変換可能）
        sql_str = str(result)
        assert "content" in sql_str
        assert ("ilike" in sql_str or "LIKE" in sql_str)

    def test_generate_search_condition_with_special_characters_returns_escaped_condition(self):
        """
        TC-5.1.2: 正常系 - 特殊文字を含むキーワード

        RISK: SEC-001 - SQL Injection の潜在リスク

        特殊文字（&, ', ", %, _）を含むキーワードがエスケープされて
        安全に SQL に組み込まれることを確認
        """
        # Arrange
        search_word = "ショップ&販売"
        column = DummyTable.content

        # Act
        result = generate_search_condition(search_word, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # エスケープ処理が行われていることを確認
        assert "content" in sql_str
        assert ("ilike" in sql_str or "LIKE" in sql_str)

    def test_generate_search_condition_with_single_quote(self):
        """
        シングルクォート（'）を含むキーワードが安全に処理されることを確認
        """
        # Arrange
        search_word = "太郎's store"
        column = DummyTable.content

        # Act
        result = generate_search_condition(search_word, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        assert "content" in sql_str

    def test_generate_search_condition_with_double_quote_phrase(self):
        """
        ダブルクォーテーション（"）で囲まれたフレーズが
        exact match として処理されることを確認

        ダブルクォートで囲まれたフレーズは LIKE 条件に変換される
        """
        # Arrange
        search_word = '"完全一致フレーズ"'
        column = DummyTable.content

        # Act
        result = generate_search_condition(search_word, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        assert "content" in sql_str
        # SQL に変換されて LIKE または ilike が含まれる
        assert ("LIKE" in sql_str or "ilike" in sql_str or "like" in sql_str)

    def test_generate_search_condition_with_and_operator(self):
        """
        AND オペレータを含むクエリが複数条件の AND として処理されることを確認
        """
        # Arrange
        search_word = "ショップ AND 東京"
        column = DummyTable.content

        # Act
        result = generate_search_condition(search_word, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # AND 条件なので AND が含まれる
        assert "AND" in sql_str

    def test_generate_search_condition_with_or_operator(self):
        """
        OR オペレータを含むクエリが複数条件の OR として処理されることを確認
        """
        # Arrange
        search_word = "ショップ OR 販売"
        column = DummyTable.content

        # Act
        result = generate_search_condition(search_word, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # OR 条件なので OR が含まれる
        assert "OR" in sql_str

    def test_generate_search_condition_with_not_operator(self):
        """
        NOT オペレータを含むクエリが否定条件として処理されることを確認
        """
        # Arrange
        search_word = "ショップ -太郎"
        column = DummyTable.content

        # Act
        result = generate_search_condition(search_word, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # NOT 条件なので NOT または AND が含まれる
        assert ("NOT" in sql_str or "AND" in sql_str)

    def test_generate_search_condition_case_insensitive(self):
        """
        AND, OR, NOT オペレータが大文字小文字を区別しないことを確認
        """
        # Arrange
        search_words = [
            "ショップ and 東京",
            "ショップ AND 東京",
            "ショップ And 東京"
        ]
        column = DummyTable.content

        for search_word in search_words:
            # Act
            result = generate_search_condition(search_word, column)

            # Assert
            assert result is not None
            sql_str = str(result)
            # AND 条件なので AND が含まれることを確認
            assert "AND" in sql_str


class TestWhooshToSqlalchemy:
    """whoosh_to_sqlalchemy 関数の検証テスト"""

    def test_whoosh_to_sqlalchemy_with_term_returns_sqlalchemy_condition(self):
        """
        Whoosh の Term クエリが SQLAlchemy ilike 条件に変換されることを確認

        ilike は SQLAlchemy の方言によって LIKE に変換される可能性がある
        """
        # Arrange
        from whoosh.query import Term
        column = DummyTable.content
        query = Term("content", "ショップ")

        # Act
        result = whoosh_to_sqlalchemy(query, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # content と (LIKE または ilike) が含まれる
        assert "content" in sql_str
        assert ("LIKE" in sql_str or "ilike" in sql_str or "like" in sql_str)

    def test_whoosh_to_sqlalchemy_with_phrase_returns_equality_condition(self):
        """
        Whoosh の Phrase クエリが SQLAlchemy 等値条件に変換されることを確認
        """
        # Arrange
        from whoosh.query import Phrase
        column = DummyTable.content
        query = Phrase("content", ["完全", "一致"])

        # Act
        result = whoosh_to_sqlalchemy(query, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # 等値条件なので content と = が含まれる
        assert "content" in sql_str and "=" in sql_str

    def test_whoosh_to_sqlalchemy_with_and_returns_and_condition(self):
        """
        Whoosh の And クエリが SQLAlchemy and_ に変換されることを確認
        """
        # Arrange
        from whoosh.query import And, Term
        column = DummyTable.content
        query = And([Term("content", "ショップ"), Term("content", "東京")])

        # Act
        result = whoosh_to_sqlalchemy(query, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # AND 条件なので AND が含まれる
        assert "AND" in sql_str

    def test_whoosh_to_sqlalchemy_with_or_returns_or_condition(self):
        """
        Whoosh の Or クエリが SQLAlchemy or_ に変換されることを確認
        """
        # Arrange
        from whoosh.query import Or, Term
        column = DummyTable.content
        query = Or([Term("content", "ショップ"), Term("content", "販売")])

        # Act
        result = whoosh_to_sqlalchemy(query, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # OR 条件なので OR が含まれる
        assert "OR" in sql_str

    def test_whoosh_to_sqlalchemy_with_not_returns_not_condition(self):
        """
        Whoosh の Not クエリが SQLAlchemy not_ に変換されることを確認
        """
        # Arrange
        from whoosh.query import Not, Term
        column = DummyTable.content
        query = Not(Term("content", "太郎"))

        # Act
        result = whoosh_to_sqlalchemy(query, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # NOT 条件なので NOT または content が含まれる
        assert ("NOT" in sql_str or "content" in sql_str)


class TestSearchConditionSecurity:
    """ファジー検索のセキュリティ関連テスト"""

    def test_generate_search_condition_prevents_sql_injection_with_union(self):
        """
        UNION ベースの SQL Injection が防止されることを確認

        SQLAlchemy のパラメタライズまたは Whoosh パーサのエラーによって
        SQL Injection が防止される。実装では特殊文字を含むクエリが
        未処理のクエリ型（Every）として解析される場合、
        ValueError が発生することで攻撃を防いでいる
        """
        # Arrange
        search_word = "test' UNION SELECT * FROM users --"
        column = DummyTable.content

        # Act & Assert
        # 特殊文字を含むクエリが例外で処理されるか、
        # またはパラメータ化されて安全に処理されるか
        try:
            result = generate_search_condition(search_word, column)
            # パラメータ化されて安全に処理された場合
            assert result is not None
            sql_str = str(result)
            assert "content" in sql_str
        except ValueError as e:
            # Unhandled query type による例外が発生
            assert "Unhandled query type" in str(e)

    def test_generate_search_condition_prevents_sql_injection_with_drop(self):
        """
        DROP/DELETE などの DDL インジェクションが防止されることを確認
        """
        # Arrange
        search_word = "test'; DROP TABLE users; --"
        column = DummyTable.content

        # Act
        result = generate_search_condition(search_word, column)

        # Assert
        # SQLAlchemy のパラメタライズにより安全に処理される
        assert result is not None
        sql_str = str(result)
        # SQLAlchemy が値をパラメータ化するため、DROP キーワードは SQL に組み込まれない
        assert "content" in sql_str

    def test_generate_search_condition_with_percent_sign(self):
        """
        LIKE ワイルドカード（%）がリテラルとして処理されることを確認
        """
        # Arrange
        search_word = "50%割引"
        column = DummyTable.content

        # Act
        result = generate_search_condition(search_word, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # 検索条件が生成されていることを確認
        assert "content" in sql_str


class TestGenerateSearchConditionEdgeCases:
    """エッジケーステスト"""

    def test_generate_search_condition_with_empty_string(self):
        """
        空文字列でクエリが生成されるか確認

        空文字列の入力時に関数が正常に完了するか、
        またはパーサエラーが発生するかを検証する
        """
        # Arrange
        search_word = ""
        column = DummyTable.content

        # Act & Assert
        # 空文字列の処理が成功するか、パーサエラーで失敗するか
        try:
            result = generate_search_condition(search_word, column)
            # 成功した場合、何らかのSQLAlchemy要素が返される
            assert result is not None
            sql_str = str(result)
            assert "content" in sql_str
        except Exception as e:
            # パーサエラーが発生することも仕様として許容
            assert isinstance(e, Exception)

    def test_generate_search_condition_with_only_operators(self):
        """
        オペレータのみのクエリが処理されるか確認

        オペレータのみで構成されたクエリが処理できるか、
        またはパーサエラーが発生するかを検証する
        """
        # Arrange
        search_word = "AND OR NOT"
        column = DummyTable.content

        # Act & Assert
        try:
            result = generate_search_condition(search_word, column)
            # 成功した場合、何らかのSQLAlchemy要素が返される
            assert result is not None
            sql_str = str(result)
            assert "content" in sql_str or "AND" in sql_str or "OR" in sql_str
        except Exception as e:
            # パーサエラーが発生することも仕様として許容（オペレータのみは無効な入力）
            assert isinstance(e, Exception)

    def test_generate_search_condition_with_parentheses(self):
        """
        括弧を含む複雑なクエリが処理されることを確認
        """
        # Arrange
        search_word = "(ショップ OR 販売) AND (東京 OR 大阪)"
        column = DummyTable.content

        # Act
        result = generate_search_condition(search_word, column)

        # Assert
        assert result is not None
        sql_str = str(result)
        # AND と OR の両方が含まれることを確認
        assert ("AND" in sql_str and "OR" in sql_str)
