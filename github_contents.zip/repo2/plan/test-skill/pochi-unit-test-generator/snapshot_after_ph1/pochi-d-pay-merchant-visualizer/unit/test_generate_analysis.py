"""
Layer 2: lib.generate_analysis_result_data のユニットテスト

characterization モードで既存動作を固定化する
get_east_asian_width_count 関数の検証
"""
import pytest
from lib.generate_analysis_result_data import get_east_asian_width_count


class TestGetEastAsianWidthCount:
    """get_east_asian_width_count 関数の検証テスト"""

    def test_get_east_asian_width_count_with_japanese_text(self):
        """
        TC-7.1.1: 正常系 - 日本語文字列

        出力契約:
          - 全角文字は 2 の幅としてカウント
          - 日本語「東京」の幅は 4 となる（東=2, 京=2）
        """
        # Arrange
        text = "東京"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        assert result == 4

    def test_get_east_asian_width_count_with_ascii_text(self):
        """
        TC-7.1.2: 正常系 - ASCII 文字列

        出力契約:
          - 半角文字は 1 の幅としてカウント
          - ASCII「Tokyo」の幅は 5 となる（T=1, o=1, k=1, y=1, o=1）
        """
        # Arrange
        text = "Tokyo"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        assert result == 5

    def test_get_east_asian_width_count_with_mixed_text(self):
        """
        TC-7.1.3: 正常系 - 混在文字列

        出力契約:
          - 全角と半角が混在する文字列を正しく計算
          - 「東京1号」の幅は 7 となる（東=2, 京=2, 1=1, 号=2）
          - 「号」は全角文字のため幅は 2
        """
        # Arrange
        text = "東京1号"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        assert result == 7  # 東=2, 京=2, 1=1, 号=2

    def test_get_east_asian_width_count_with_empty_string(self):
        """
        空文字列の幅は 0 となることを確認
        """
        # Arrange
        text = ""

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        assert result == 0

    def test_get_east_asian_width_count_with_single_ascii_char(self):
        """
        半角 1 文字の幅は 1 となることを確認
        """
        # Arrange
        text = "a"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        assert result == 1

    def test_get_east_asian_width_count_with_single_japanese_char(self):
        """
        全角 1 文字の幅は 2 となることを確認
        """
        # Arrange
        text = "東"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        assert result == 2

    def test_get_east_asian_width_count_with_number(self):
        """
        数字（半角）の幅は 1 となることを確認
        """
        # Arrange
        text = "123"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        assert result == 3

    def test_get_east_asian_width_count_with_special_symbols(self):
        """
        特殊記号（半角）の幅を確認
        """
        # Arrange
        text = "!@#$%"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        assert result == 5

    def test_get_east_asian_width_count_with_japanese_symbols(self):
        """
        全角記号（括弧など）の幅を確認
        """
        # Arrange
        text = "（東京）"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        # （＝2, 東＝2, 京＝2, ）＝2
        assert result == 8

    def test_get_east_asian_width_count_with_space(self):
        """
        スペース（半角）の幅は 1 となることを確認
        """
        # Arrange
        text = "a b"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        assert result == 3  # a=1, space=1, b=1

    def test_get_east_asian_width_count_with_japanese_space(self):
        """
        全角スペースの幅は 2 となることを確認
        """
        # Arrange
        text = "東　京"  # 全角スペースを含む

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        # 東=2, 全角スペース=2, 京=2
        assert result == 6

    def test_get_east_asian_width_count_with_long_text(self):
        """
        長めのテキストで正しく計算されることを確認
        """
        # Arrange
        text = "東京都渋谷区のドコモショップ"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        # 全て全角文字なので、文字数 × 2
        expected = len(text) * 2
        assert result == expected

    def test_get_east_asian_width_count_with_complex_mixed_text(self):
        """
        複雑な混在文字列の計算を確認
        """
        # Arrange
        text = "東京都の店舗はStore123です"

        # Act
        result = get_east_asian_width_count(text)

        # Assert
        # 東京都の店舗は=12(6文字*2)
        # は=2
        # Store=5
        # 123=3
        # です=4(2文字*2)
        expected = 12 + 2 + 5 + 3 + 4
        assert result == expected
