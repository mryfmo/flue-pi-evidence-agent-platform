"""
Layer 2: lib.utils のユニットテスト

characterization モードで既存動作を固定化する
対象: Streamlit デコレータなし関数（json_serial, to_json, get_streamlit_session_id）
"""
import pytest
import json
from datetime import date, datetime
from unittest.mock import patch, MagicMock
from lib.utils import json_serial, to_json, get_streamlit_session_id


class TestJsonSerial:
    """json_serial 関数の検証テスト"""

    def test_json_serial_with_date_returns_iso_format_string(self):
        """
        TC-3.1.1: 正常系 - date オブジェクト

        datetime/date オブジェクトを ISO 8601 形式文字列に変換する
        """
        # Arrange
        obj = date(2026, 5, 1)

        # Act
        result = json_serial(obj)

        # Assert
        assert result == "2026-05-01"
        assert isinstance(result, str)

    def test_json_serial_with_datetime_returns_iso_format_string(self):
        """
        TC-3.1.2: 正常系 - datetime オブジェクト

        datetime オブジェクトを ISO 8601 形式（タイムスタンプ付き）で返す
        """
        # Arrange
        obj = datetime(2026, 5, 1, 12, 30, 45)

        # Act
        result = json_serial(obj)

        # Assert
        assert isinstance(result, str)
        assert result.startswith("2026-05-01")
        assert "T" in result

    def test_json_serial_with_int_returns_string(self):
        """
        TC-3.1.3: 正常系 - 数値（int）

        int 値を文字列に変換する
        """
        # Arrange
        obj = 12345

        # Act
        result = json_serial(obj)

        # Assert
        assert result == "12345"
        assert isinstance(result, str)

    def test_json_serial_with_string_returns_same_string(self):
        """
        TC-3.1.4: 正常系 - 文字列

        既に文字列の場合、str() で処理されて同じ文字列が返される
        """
        # Arrange
        obj = "test_string"

        # Act
        result = json_serial(obj)

        # Assert
        assert result == "test_string"

    def test_json_serial_with_float_returns_string(self):
        """
        float 値を文字列に変換する
        """
        # Arrange
        obj = 123.456

        # Act
        result = json_serial(obj)

        # Assert
        assert isinstance(result, str)
        assert "123.456" in result

    def test_json_serial_with_none_returns_none_string(self):
        """
        None 値を文字列 "None" に変換する（str(None) の動作）
        """
        # Arrange
        obj = None

        # Act
        result = json_serial(obj)

        # Assert
        assert result == "None"
        assert isinstance(result, str)


class TestToJson:
    """to_json 関数の検証テスト"""

    def test_to_json_with_dict_containing_date_returns_valid_json(self):
        """
        TC-3.2.1: 正常系 - 辞書（複合オブジェクト）

        date フィールドを含む辞書を JSON 文字列に変換する
        JSON 内の date は ISO 形式文字列として表現される
        """
        # Arrange
        obj = {
            "date": date(2026, 5, 1),
            "count": 123,
            "name": "東京"
        }

        # Act
        result = to_json(obj)

        # Assert
        assert isinstance(result, str)
        assert '"date": "2026-05-01"' in result
        assert '"count": 123' in result
        # ensure_ascii=False により日本語は UTF-8 でエンコード
        assert "東京" in result

    def test_to_json_with_unicode_characters(self):
        """
        TC-3.2.2: 正常系 - ensure_ascii=False（日本語対応）

        日本語文字を含むオブジェクトが UTF-8 でエンコードされることを確認
        """
        # Arrange
        obj = {"name": "東京"}

        # Act
        result = to_json(obj)

        # Assert
        assert "東京" in result
        assert isinstance(result, str)

    def test_to_json_is_valid_json_parseable(self):
        """
        生成された JSON 文字列は json.loads() で再解析可能であることを確認
        """
        # Arrange
        obj = {
            "date": date(2026, 5, 1),
            "count": 123,
            "name": "東京"
        }

        # Act
        json_str = to_json(obj)
        parsed = json.loads(json_str)

        # Assert
        assert parsed["date"] == "2026-05-01"
        assert parsed["count"] == 123
        assert parsed["name"] == "東京"

    def test_to_json_with_list_returns_valid_json(self):
        """
        リスト型オブジェクトを JSON に変換する
        """
        # Arrange
        obj = [date(2026, 1, 1), date(2026, 1, 2)]

        # Act
        result = to_json(obj)

        # Assert
        assert isinstance(result, str)
        parsed = json.loads(result)
        assert parsed == ["2026-01-01", "2026-01-02"]

    def test_to_json_with_nested_dict(self):
        """
        ネストした辞書を JSON に変換する
        """
        # Arrange
        obj = {
            "user": {
                "name": "太郎",
                "created_date": date(2026, 1, 1)
            }
        }

        # Act
        result = to_json(obj)

        # Assert
        parsed = json.loads(result)
        assert parsed["user"]["name"] == "太郎"
        assert parsed["user"]["created_date"] == "2026-01-01"


class TestGetStreamlitSessionId:
    """get_streamlit_session_id 関数の検証テスト"""

    def test_get_streamlit_session_id_returns_string(self):
        """
        TC-3.3.1: 正常系 - セッション ID 取得

        Streamlit セッション ID をモックして、関数が文字列を返すことを確認
        """
        # Arrange
        mock_ctx = MagicMock()
        mock_ctx.session_id = "test_session_id_abc123"

        # Act
        with patch("lib.utils.get_script_run_ctx", return_value=mock_ctx):
            result = get_streamlit_session_id()

        # Assert
        assert isinstance(result, str)
        assert len(result) > 0
        assert result == "test_session_id_abc123"

    def test_get_streamlit_session_id_with_different_ids(self):
        """
        異なるセッション ID に対して、その ID が返されることを確認
        """
        # Arrange
        session_ids = ["session_001", "session_002", "session_xyz"]

        for session_id in session_ids:
            # Arrange
            mock_ctx = MagicMock()
            mock_ctx.session_id = session_id

            # Act
            with patch("lib.utils.get_script_run_ctx", return_value=mock_ctx):
                result = get_streamlit_session_id()

            # Assert
            assert result == session_id
