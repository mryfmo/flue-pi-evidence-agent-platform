"""
Layer 2: lib.models のユニットテスト

このテストは characterization モードで既存動作を固定化します。
"""
import pytest
from datetime import date
from lib.models import InputConditions, RenderOptions


class TestInputConditionsCheck:
    """InputConditions.check プロパティの検証テスト"""

    # ======== TC-1.1: 正常系テスト ========

    def test_input_conditions_check_with_address_only_returns_true(self):
        """
        TC-1.1.1: 住所条件のみ（正常な入力）

        出力契約:
          - 入力条件が有効（prefecture_cd + city_cd が満たされる）
          - 期間指定が有効（start_date/end_date）
          - check プロパティが True を返す
        """
        # Arrange
        conditions = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            prefecture_cd="13",
            city_cd=["1001"],
            enable_comparison=False
        )

        # Act
        result = conditions.check

        # Assert
        assert isinstance(result, bool)
        assert result is True

    def test_input_conditions_check_with_keyword_search_only_returns_true(self):
        """
        TC-1.1.2: キーワード検索条件のみ

        キーワード検索方式（keyword_search_method）と検索キーワード（keyword_search_word）
        が同時に指定された場合、check は True を返す
        """
        # Arrange
        conditions = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            keyword_search_method="company_store",
            keyword_search_word="ドコモショップ",
            enable_comparison=False
        )

        # Act
        result = conditions.check

        # Assert
        assert result is True

    def test_input_conditions_check_with_map_search_only_returns_true(self):
        """
        TC-1.1.3: 地図検索条件のみ

        緯度・経度・半径がすべて指定された場合、map_condition が満たされて
        check は True を返す
        """
        # Arrange
        conditions = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            map_search_latitude=35.6762,
            map_search_longitude=139.6503,
            map_search_radius_km=5.0,
            enable_comparison=False
        )

        # Act
        result = conditions.check

        # Assert
        assert result is True

    def test_input_conditions_check_with_store_search_only_returns_true(self):
        """
        TC-1.1.4: 店舗検索条件のみ

        店舗ID、店舗の緯度・経度・検索半径がすべて指定された場合、
        check は True を返す
        """
        # Arrange
        conditions = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            selected_store_id="store_001",
            store_center_latitude=35.6762,
            store_center_longitude=139.6503,
            store_search_radius_km=1.0,
            enable_comparison=False
        )

        # Act
        result = conditions.check

        # Assert
        assert result is True

    # ======== TC-1.1: 異常系テスト ========

    def test_input_conditions_check_with_missing_start_date_returns_false(self):
        """
        TC-1.1.5: 異常系 - 必須フィールド欠損（start_date が None）

        RISK: DATA-001 - InputConditions の複雑な検証ロジック

        start_date が None の場合、isinstance(self.start_date, date) が False となり
        check は False を返す（第1の必須チェック）
        """
        # Arrange
        conditions = InputConditions(
            start_date=None,
            end_date=date(2026, 1, 31),
            prefecture_cd="13",
            city_cd=["1001"],
            enable_comparison=False
        )

        # Act
        result = conditions.check

        # Assert
        assert result is False

    def test_input_conditions_check_with_all_search_conditions_missing_returns_false(self):
        """
        TC-1.1.6: 異常系 - 全検索条件欠損

        RISK: DATA-001 - InputConditions の複雑な検証ロジック

        4つの検索条件（address/keyword/map/store）のいずれも満たされない場合、
        OR 条件全体が False となり check は False を返す
        """
        # Arrange
        conditions = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            prefecture_cd=None,
            city_cd=None,
            keyword_search_word=None,
            map_search_latitude=None,
            selected_store_id=None,
            enable_comparison=False
        )

        # Act
        result = conditions.check

        # Assert
        assert result is False

    def test_input_conditions_check_with_comparison_enabled_missing_dates_returns_false(self):
        """
        TC-1.1.7: 異常系 - 比較期間有効時に比較開始日が None

        RISK: DATA-001 - InputConditions の複雑な検証ロジック

        enable_comparison=True で comparison_start_date=None の場合、
        条件付き必須フィールドが欠損しているため check は False を返す
        """
        # Arrange
        conditions = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            comparison_start_date=None,
            comparison_end_date=date(2025, 12, 1),
            enable_comparison=True,
            prefecture_cd="13",
            city_cd=["1001"]
        )

        # Act
        result = conditions.check

        # Assert
        assert result is False

    # ======== TC-1.1: 境界値テスト ========

    def test_input_conditions_check_with_same_start_and_end_date_returns_true(self):
        """
        TC-1.1.8: 境界値 - 開始日 = 終了日（同一日）

        日付範囲が 1 日の極端なケース（開始日と終了日が同じ日）でも、
        型チェック `isinstance(start_date, date)` が満たされるため check は True を返す
        """
        # Arrange
        conditions = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 1),
            prefecture_cd="13",
            city_cd=["1001"],
            enable_comparison=False
        )

        # Act
        result = conditions.check

        # Assert
        assert result is True

    def test_input_conditions_check_with_multiple_search_conditions_returns_true(self):
        """
        TC-1.1.9: 境界値 - 複数検索条件同時有効

        複数の検索条件が同時に満たされた場合、OR 条件により check は True を返す
        （優先順位の制御は UI 層で行われることが想定）
        """
        # Arrange
        conditions = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            prefecture_cd="13",
            city_cd=["1001"],
            keyword_search_method="company",
            keyword_search_word="ショップ",
            enable_comparison=False
        )

        # Act
        result = conditions.check

        # Assert
        assert result is True


class TestRenderOptionsInitialization:
    """RenderOptions のデフォルト値と初期化テスト"""

    def test_render_options_default_initialization_all_false_except_show_map_point_pin(self):
        """
        TC-1.2.1: 正常系 - デフォルト初期化

        RenderOptions() でインスタンス化された場合、各フラグがデフォルト値を持つことを検証

        出力契約:
          - enable_merchant_map: False（デフォルト）
          - enable_acctid_list_download: False（デフォルト）
          - enable_analysis_data_download: False（デフォルト）
          - enable_graphs: False（デフォルト）
          - enable_store_information_display: False（デフォルト）
          - show_map_point_pin: True（デフォルト）
          - payment_method_list: None（デフォルト）
        """
        # Arrange & Act
        result = RenderOptions()

        # Assert
        assert result.enable_merchant_map is False
        assert result.enable_acctid_list_download is False
        assert result.enable_analysis_data_download is False
        assert result.enable_graphs is False
        assert result.enable_store_information_display is False
        assert result.show_map_point_pin is True
        assert result.payment_method_list is None

    def test_render_options_with_specified_values(self):
        """
        TC-1.2.2: 正常系 - 指定値で初期化

        RenderOptions に明示的に値を指定した場合、その値が正確に反映されることを検証
        """
        # Arrange & Act
        result = RenderOptions(
            enable_merchant_map=True,
            enable_graphs=True,
            show_map_point_pin=False,
            payment_method_list=["credit_card", "digital_money"]
        )

        # Assert
        assert result.enable_merchant_map is True
        assert result.enable_graphs is True
        assert result.show_map_point_pin is False
        assert result.payment_method_list == ["credit_card", "digital_money"]
        # デフォルト値は変わらず
        assert result.enable_acctid_list_download is False

    def test_render_options_is_frozen_dataclass(self):
        """
        TC-1.2.3: 異常系 - frozen dataclass の不変性

        RenderOptions は frozen=True で定義されているため、
        インスタンス化後に属性を変更しようとすると FrozenInstanceError が発生する
        """
        # Arrange
        result = RenderOptions()

        # Act & Assert
        with pytest.raises(AttributeError):
            result.enable_merchant_map = True


class TestInputConditionsHashMd5:
    """InputConditions.hash_md5 プロパティの検証"""

    def test_input_conditions_hash_md5_returns_32_char_hexadecimal(self):
        """
        同じ InputConditions インスタンスに対して hash_md5 を呼び出した場合、
        MD5 ハッシュ値（32 文字の 16 進数文字列）を返す
        """
        # Arrange
        conditions = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            prefecture_cd="13",
            city_cd=["1001"],
            enable_comparison=False
        )

        # Act
        result = conditions.hash_md5

        # Assert
        assert isinstance(result, str)
        assert len(result) == 32
        # 16進数文字列の検証
        assert all(c in "0123456789abcdef" for c in result)

    def test_input_conditions_hash_md5_same_conditions_same_hash(self):
        """
        同じ条件で作成された 2つの InputConditions インスタンスは、
        同じ hash_md5 値を返す
        """
        # Arrange
        conditions1 = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            prefecture_cd="13",
            city_cd=["1001"],
            enable_comparison=False
        )
        conditions2 = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            prefecture_cd="13",
            city_cd=["1001"],
            enable_comparison=False
        )

        # Act
        hash1 = conditions1.hash_md5
        hash2 = conditions2.hash_md5

        # Assert
        assert hash1 == hash2

    def test_input_conditions_hash_md5_different_conditions_different_hash(self):
        """
        異なる条件で作成された InputConditions インスタンスは、
        異なる hash_md5 値を返す
        """
        # Arrange
        conditions1 = InputConditions(
            start_date=date(2026, 1, 1),
            end_date=date(2026, 1, 31),
            prefecture_cd="13",
            city_cd=["1001"],
            enable_comparison=False
        )
        conditions2 = InputConditions(
            start_date=date(2026, 1, 2),  # 開始日が異なる
            end_date=date(2026, 1, 31),
            prefecture_cd="13",
            city_cd=["1001"],
            enable_comparison=False
        )

        # Act
        hash1 = conditions1.hash_md5
        hash2 = conditions2.hash_md5

        # Assert
        assert hash1 != hash2
