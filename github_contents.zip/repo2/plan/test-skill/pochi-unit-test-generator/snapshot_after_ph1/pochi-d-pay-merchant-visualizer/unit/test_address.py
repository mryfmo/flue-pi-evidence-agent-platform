"""
Layer 2: lib.address のユニットテスト

characterization モードで既存動作を固定化する
対象: Streamlit デコレータなし関数のみ

注記：
- static/prefectures.json をロードする関数（get_pref_code, get_address_master_* など）
  は Layer 3（統合テスト）で AppTest 経由でテストする設計
- Layer 2 では remove_none_and_list_keys など純粋関数のみをテストする
"""
import pytest
from lib.address import remove_none_and_list_keys


class TestRemoveNoneAndListKeys:
    """remove_none_and_list_keys 関数の検証テスト"""

    def test_remove_none_and_list_keys_removes_none_keys(self):
        """
        TC-2.1.1: 正常系 - トップレベルの None キー削除

        None がキーとして使用されている場合、そのキー・バリューペアを削除する
        """
        # Arrange
        data = {
            None: "skip_this",
            "prefecture_cd": "13",
            "city_cd": ["1001"]
        }

        # Act
        result = remove_none_and_list_keys(data)

        # Assert
        assert None not in result.keys()
        assert result["prefecture_cd"] == "13"
        assert len(result) == 2
        assert result["city_cd"] == ["1001"]

    def test_remove_none_and_list_keys_converts_empty_list_to_none(self):
        """
        TC-2.1.2: 正常系 - 空リスト値を None に変換

        リスト値が空の場合、その値を None に変換する
        """
        # Arrange
        data = {
            "prefecture_cd": "13",
            "city_cd": [],
            "keywords": None
        }

        # Act
        result = remove_none_and_list_keys(data)

        # Assert
        assert result["prefecture_cd"] == "13"
        assert result["city_cd"] is None
        assert result["keywords"] is None

    def test_remove_none_and_list_keys_removes_none_from_nested_lists(self):
        """
        TC-2.1.3: 正常系 - ネストした辞書のリスト内 None 削除

        ネストした辞書内のリストから None 値を削除する
        """
        # Arrange
        data = {
            "name": "store",
            "details": {
                "tags": ["tag1", None, "tag2"],
                "meta": {
                    "values": [1, 2, None]
                }
            }
        }

        # Act
        result = remove_none_and_list_keys(data)

        # Assert
        assert result["details"]["tags"] == ["tag1", "tag2"]
        assert len(result["details"]["tags"]) == 2
        assert None not in result["details"]["tags"]
        assert result["details"]["meta"]["values"] == [1, 2]

    def test_remove_none_and_list_keys_with_empty_dict_returns_empty_dict(self):
        """
        TC-2.1.4: 境界値 - 空辞書

        空の辞書を入力した場合、空の辞書を返す
        """
        # Arrange
        data = {}

        # Act
        result = remove_none_and_list_keys(data)

        # Assert
        assert result == {}

    def test_remove_none_and_list_keys_preserves_non_empty_lists(self):
        """
        None を含まない非空リストは保持される
        """
        # Arrange
        data = {
            "city_cd": ["1001", "1002", "1003"]
        }

        # Act
        result = remove_none_and_list_keys(data)

        # Assert
        assert result["city_cd"] == ["1001", "1002", "1003"]
