"""
Layer 2: lib.data_loader.data_models.merchant_key のユニットテスト

characterization モードで既存動作を固定化する
MerchantStoreKey と MerchantStoreKeyList のデータモデル検証
"""
import pytest
import hashlib
from lib.data_loader.data_models.merchant_key import (
    MerchantStoreKey,
    MerchantStoreKeyList
)


class TestMerchantStoreKey:
    """MerchantStoreKey NamedTuple の検証テスト"""

    def test_merchant_store_key_initialization_with_required_fields(self):
        """
        TC-6.1.1: 正常系 - オブジェクト作成と属性検証

        出力契約:
          - 3つの必須フィールド（site_id_cpid, company_code, store_code）が正確に保持される
          - NamedTuple のため不変（immutable）である
        """
        # Arrange
        site_id_cpid = "site_001"
        company_code = "comp_001"
        store_code = "store_001"

        # Act
        result = MerchantStoreKey(
            site_id_cpid=site_id_cpid,
            company_code=company_code,
            store_code=store_code
        )

        # Assert
        assert result.site_id_cpid == "site_001"
        assert result.company_code == "comp_001"
        assert result.store_code == "store_001"

    def test_merchant_store_key_with_optional_fields(self):
        """
        オプショナルフィールド（company_name, store_name）の指定が機能することを確認
        """
        # Arrange & Act
        result = MerchantStoreKey(
            site_id_cpid="site_001",
            company_code="comp_001",
            store_code="store_001",
            company_name="ドコモショップ太郎",
            store_name="渋谷店"
        )

        # Assert
        assert result.company_name == "ドコモショップ太郎"
        assert result.store_name == "渋谷店"

    def test_merchant_store_key_optional_fields_default_to_none(self):
        """
        オプショナルフィールドが指定されない場合、None になることを確認
        """
        # Arrange & Act
        result = MerchantStoreKey(
            site_id_cpid="site_001",
            company_code="comp_001",
            store_code="store_001"
        )

        # Assert
        assert result.company_name is None
        assert result.store_name is None

    def test_merchant_store_key_is_immutable(self):
        """
        MerchantStoreKey は NamedTuple のため、属性の変更ができないことを確認
        """
        # Arrange
        key = MerchantStoreKey(
            site_id_cpid="site_001",
            company_code="comp_001",
            store_code="store_001"
        )

        # Act & Assert
        with pytest.raises(AttributeError):
            key.site_id_cpid = "site_002"

    def test_merchant_store_key_tuple_unpacking(self):
        """
        NamedTuple として tuple unpacking が機能することを確認
        """
        # Arrange
        key = MerchantStoreKey(
            site_id_cpid="site_001",
            company_code="comp_001",
            store_code="store_001"
        )

        # Act
        site_id, company_cd, store_cd = key[:3]

        # Assert
        assert site_id == "site_001"
        assert company_cd == "comp_001"
        assert store_cd == "store_001"

    def test_merchant_store_key_equality(self):
        """
        同じ値で初期化された 2つの MerchantStoreKey インスタンスは等価であることを確認
        """
        # Arrange
        key1 = MerchantStoreKey(
            site_id_cpid="site_001",
            company_code="comp_001",
            store_code="store_001"
        )
        key2 = MerchantStoreKey(
            site_id_cpid="site_001",
            company_code="comp_001",
            store_code="store_001"
        )

        # Act & Assert
        assert key1 == key2


class TestMerchantStoreKeyList:
    """MerchantStoreKeyList クラスの検証テスト"""

    def test_merchant_store_key_list_initialization(self):
        """
        TC-6.2.1: 正常系 - リスト操作

        出力契約:
          - MerchantStoreKey のリストを管理
          - リスト内の全要素にアクセス可能
          - len() により要素数を取得可能
        """
        # Arrange
        keys = [
            MerchantStoreKey(
                site_id_cpid="site_001",
                company_code="comp_001",
                store_code="store_001"
            ),
            MerchantStoreKey(
                site_id_cpid="site_002",
                company_code="comp_002",
                store_code="store_002"
            )
        ]

        # Act
        result = MerchantStoreKeyList(keys=keys)

        # Assert
        assert len(result.keys) > 0
        assert len(result) == 2
        assert result.keys[0].site_id_cpid == "site_001"
        assert result.keys[1].site_id_cpid == "site_002"

    def test_merchant_store_key_list_getitem_access(self):
        """
        インデックスアクセス（__getitem__）により要素にアクセスできることを確認
        """
        # Arrange
        keys = [
            MerchantStoreKey(
                site_id_cpid="site_001",
                company_code="comp_001",
                store_code="store_001"
            ),
            MerchantStoreKey(
                site_id_cpid="site_002",
                company_code="comp_002",
                store_code="store_002"
            )
        ]
        key_list = MerchantStoreKeyList(keys=keys)

        # Act
        first = key_list[0]
        second = key_list[1]

        # Assert
        assert first.site_id_cpid == "site_001"
        assert second.site_id_cpid == "site_002"

    def test_merchant_store_key_list_slice_access(self):
        """
        スライスアクセス（__getitem__ with slice）が機能することを確認
        """
        # Arrange
        keys = [
            MerchantStoreKey(
                site_id_cpid="site_001",
                company_code="comp_001",
                store_code="store_001"
            ),
            MerchantStoreKey(
                site_id_cpid="site_002",
                company_code="comp_002",
                store_code="store_002"
            ),
            MerchantStoreKey(
                site_id_cpid="site_003",
                company_code="comp_003",
                store_code="store_003"
            )
        ]
        key_list = MerchantStoreKeyList(keys=keys)

        # Act
        sliced = key_list[0:2]

        # Assert
        assert len(sliced) == 2
        assert sliced[0].site_id_cpid == "site_001"
        assert sliced[1].site_id_cpid == "site_002"

    def test_merchant_store_key_list_iteration(self):
        """
        イテレーション（__iter__）により要素を順番に列挙できることを確認
        """
        # Arrange
        keys = [
            MerchantStoreKey(
                site_id_cpid="site_001",
                company_code="comp_001",
                store_code="store_001"
            ),
            MerchantStoreKey(
                site_id_cpid="site_002",
                company_code="comp_002",
                store_code="store_002"
            )
        ]
        key_list = MerchantStoreKeyList(keys=keys)

        # Act
        results = [key for key in key_list]

        # Assert
        assert len(results) == 2
        assert results[0].site_id_cpid == "site_001"
        assert results[1].site_id_cpid == "site_002"

    def test_merchant_store_key_list_hash_sha256_with_small_batch(self):
        """
        hash_sha256 プロパティが SHA256 ハッシュ値（64 文字の 16 進数）を返すことを確認
        """
        # Arrange
        keys = [
            MerchantStoreKey(
                site_id_cpid="site_001",
                company_code="comp_001",
                store_code="store_001"
            ),
            MerchantStoreKey(
                site_id_cpid="site_002",
                company_code="comp_002",
                store_code="store_002"
            )
        ]
        key_list = MerchantStoreKeyList(keys=keys)

        # Act
        result = key_list.hash_sha256

        # Assert
        assert isinstance(result, str)
        assert len(result) == 64
        # 16進数文字列の検証
        assert all(c in "0123456789abcdef" for c in result)

    def test_merchant_store_key_list_hash_sha256_consistency(self):
        """
        同じ key リストに対して hash_sha256 は同じ値を返すことを確認
        """
        # Arrange
        keys = [
            MerchantStoreKey(
                site_id_cpid="site_001",
                company_code="comp_001",
                store_code="store_001"
            )
        ]
        key_list = MerchantStoreKeyList(keys=keys)

        # Act
        hash1 = key_list.hash_sha256
        hash2 = key_list.hash_sha256

        # Assert
        assert hash1 == hash2

    def test_merchant_store_key_list_with_large_batch(self):
        """
        大量のキーを含む MerchantStoreKeyList のハッシュ計算を確認
        batch_size = min(5000, len(keys)) で分割処理される
        """
        # Arrange
        keys = [
            MerchantStoreKey(
                site_id_cpid=f"site_{i:05d}",
                company_code=f"comp_{i:05d}",
                store_code=f"store_{i:05d}"
            )
            for i in range(100)
        ]

        # Act
        key_list = MerchantStoreKeyList(keys=keys)
        result = key_list.hash_sha256

        # Assert
        assert isinstance(result, str)
        assert len(result) == 64

    def test_merchant_store_key_list_len(self):
        """
        len() により要素数を取得できることを確認
        """
        # Arrange
        keys = [
            MerchantStoreKey(
                site_id_cpid="site_001",
                company_code="comp_001",
                store_code="store_001"
            ),
            MerchantStoreKey(
                site_id_cpid="site_002",
                company_code="comp_002",
                store_code="store_002"
            )
        ]
        key_list = MerchantStoreKeyList(keys=keys)

        # Act
        result = len(key_list)

        # Assert
        assert result == 2

    def test_merchant_store_key_list_str_representation(self):
        """
        __str__ により文字列表現が生成されることを確認
        """
        # Arrange
        keys = [
            MerchantStoreKey(
                site_id_cpid="site_001",
                company_code="comp_001",
                store_code="store_001"
            )
        ]
        key_list = MerchantStoreKeyList(keys=keys)

        # Act
        result = str(key_list)

        # Assert
        assert isinstance(result, str)
        assert len(result) > 0
