"""
出力ファイルスキーマのデータ契約テスト（Layer 1）

DC-005: 出力ファイルスキーマ（CSV/Excelファイル形式）

各テストは期待される出力データ構造を検証する。
入力カラムを保持し、変換結果を追加したDataFrameの形式を確認する。
"""
import pytest
import pandas as pd
from io import StringIO


# ============================================================================
# pytest fixtures: 出力データの構築
# ============================================================================

@pytest.fixture
def output_df_single_column():
    """
    出力: 入力カラム1個 + 変換結果1個のDataFrame

    DC-005要件:
    - 入力カラム名を保持
    - 変換結果を次のカラムに追加
    """
    data = {
        "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111", "BBBBBBBBBBBBBBBBBBBBB222"],
        "変換結果_共通IDグループ番号": ["000012345678", "000087654321"]
    }
    return pd.DataFrame(data)


@pytest.fixture
def output_df_multiple_columns():
    """
    出力: 入力カラム複数 + 変換結果複数のDataFrame

    DC-005要件（複数事業区分対応、BR-009-1）:
    - 基本契約番号への変換で複数事業区分選択時
    - 出力カラン数が増加
    """
    data = {
        "顧客ID": ["C001", "C002"],
        "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111", "BBBBBBBBBBBBBBBBBBBBB222"],
        "部門": ["営業", "IT"],
        "変換結果_基本契約番号_01": ["011234567890", "012345678901"],
        "変換結果_基本契約番号_05": ["051234567890", "052345678901"],
        "変換結果_基本契約番号_08": ["081234567890", "082345678901"]
    }
    return pd.DataFrame(data)


@pytest.fixture
def output_df_with_null_values():
    """
    出力: 変換失敗時にNULL値を含むDataFrame

    DC-007要件（BR-007-1）:
    - 変換先IDが存在しない場合、NULLが含まれる
    - 期待: 入力カラムは保持されるが、変換結果がNULL
    """
    data = {
        "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111", "XXXXXXXXXXXXXXXXXXXXXXX999"],
        "変換結果_共通IDグループ番号": ["000012345678", None]
    }
    return pd.DataFrame(data)


@pytest.fixture
def output_df_csv_format():
    """
    出力: CSV形式の出力ファイル内容（文字列）

    DC-005要件:
    - encoding: utf-8-sig （BOM付きUTF-8）
    - CSVヘッダーを含む
    """
    csv_content = """アカウント識別子,変換結果_共通IDグループ番号
AAAAAAAAAAAAAAAAAAAAA111,000012345678
BBBBBBBBBBBBBBBBBBBBB222,000087654321
"""
    return StringIO(csv_content)


@pytest.fixture
def output_df_large_dataset():
    """
    出力: 大規模出力ファイル（100行）

    DC-005要件（max_excel_rows: 1,000,000行）:
    - Excel形式で出力可能なサイズ
    """
    data = {
        "アカウント識別子": [f"ACCTID{str(i).zfill(18)}" for i in range(100)],
        "変換結果_共通IDグループ番号": [f"0000{str(i).zfill(8)}" for i in range(100)]
    }
    return pd.DataFrame(data)


@pytest.fixture
def output_df_excel_limit_boundary():
    """
    出力: Excel出力の上限（1,000,000行）に接近したDataFrame

    DC-005要件（BR-015-1, BR-015-2）:
    - 1,000,000行の境界値をテスト
    """
    # テスト用に1000行を模擬（実際の1M行ではメモリ不足）
    data = {
        "アカウント識別子": [f"ACCTID{str(i).zfill(18)}" for i in range(1000)],
        "変換結果_共通IDグループ番号": [f"0000{str(i).zfill(8)}" for i in range(1000)]
    }
    return pd.DataFrame(data)


@pytest.fixture
def output_df_row_order_preserved():
    """
    出力: 入力行の順序が保持されたDataFrame

    DC-005要件（BR-017-1）:
    - left merge で実装
    - 入力ファイルの元の順序を保持
    """
    # 入力の順序がそのまま出力に反映される
    data = {
        "アカウント識別子": ["CCCCCCCCCCCCCCCCCCCCC333", "AAAAAAAAAAAAAAAAAAAAA111", "BBBBBBBBBBBBBBBBBBBBB222"],
        "変換結果_共通IDグループ番号": ["000099999999", "000012345678", "000087654321"]
    }
    return pd.DataFrame(data)


# ============================================================================
# 正常系テスト（約40%）
# ============================================================================

class TestOutputSchemaValidData:
    """
    正常系: 正常な出力ファイルスキーマの検証
    """

    def test_output_single_column_schema(self, output_df_single_column):
        """
        正常系: 入力カラン1個 + 変換結果1個の出力スキーマ検証

        DC-005要件:
        - 入力カラン名を保持
        - 変換結果を新規カラムに追加
        """
        assert not output_df_single_column.empty
        assert len(output_df_single_column) == 2

        # カラン数確認（入力1 + 結果1 = 2）
        expected_columns = ["アカウント識別子", "変換結果_共通IDグループ番号"]
        assert list(output_df_single_column.columns) == expected_columns, \
            f"カラン名が異なる（期待: {expected_columns}, 実際: {list(output_df_single_column.columns)}）"

        # 全カラムが object 型（string）
        for col in output_df_single_column.columns:
            assert output_df_single_column[col].dtype == "object", \
                f"カラム '{col}' の型が異なる（期待: object）"

    def test_output_multiple_columns_with_bascid_variants(self, output_df_multiple_columns):
        """
        正常系: 複数カラン + 複数事業区分の出力スキーマ検証

        DC-005要件（BR-009対応）:
        - 基本契約番号への変換で複数事業区分選択時
        - 事業区分ごとに出力カランが追加される
        """
        assert not output_df_multiple_columns.empty
        assert len(output_df_multiple_columns) == 2

        # カラン数確認（入力3 + 結果3 = 6）
        expected_columns = [
            "顧客ID", "アカウント識別子", "部門",
            "変換結果_基本契約番号_01", "変換結果_基本契約番号_05", "変換結果_基本契約番号_08"
        ]
        assert list(output_df_multiple_columns.columns) == expected_columns, \
            f"カラン名が異なる（期待: {expected_columns}, 実際: {list(output_df_multiple_columns.columns)}）"

        # 入力カランの値が保持されているか確認
        assert output_df_multiple_columns["顧客ID"].tolist() == ["C001", "C002"]
        assert output_df_multiple_columns["部門"].tolist() == ["営業", "IT"]

    # RISK: R-015 - CTE生成時のSnowflake固有関数
    def test_output_data_type_consistency(self, output_df_single_column):
        """
        正常系: 出力データ型の一貫性確認

        DC-005要件（型検証）:
        - 入力カラン: string
        - 変換結果カラン: string
        - 期待: 全カラムが object 型（pandas の string）
        """
        for col in output_df_single_column.columns:
            assert output_df_single_column[col].dtype == "object", \
                f"カラム '{col}' の型が object ではない"

    # RISK: R-017 - データベース接続管理
    def test_output_row_order_preserved(self, output_df_row_order_preserved):
        """
        正常系: 入力行の順序保持確認

        DC-005要件（BR-017-1, RISK: R-017）:
        - left merge で実装
        - 入力ファイルの元の順序を保持
        """
        expected_order = ["CCCCCCCCCCCCCCCCCCCCC333", "AAAAAAAAAAAAAAAAAAAAA111", "BBBBBBBBBBBBBBBBBBBBB222"]
        actual_order = output_df_row_order_preserved["アカウント識別子"].tolist()

        assert actual_order == expected_order, \
            f"行の順序が異なる（期待: {expected_order}, 実際: {actual_order}）"

    # RISK: R-012 - データ形式・バリデーション
    def test_output_csv_encoding_utf8_sig(self, output_df_csv_format):
        """
        正常系: CSV出力のエンコーディング確認

        DC-005要件（encoding: utf-8-sig）:
        - BOM付きUTF-8で保存されることを確認
        """
        csv_content = output_df_csv_format.getvalue()

        # CSV形式のヘッダーが存在
        lines = csv_content.strip().split("\n")
        assert len(lines) >= 1, "CSVヘッダーが存在しない"

        header = lines[0]
        assert "アカウント識別子" in header, \
            "ヘッダーに入力カラン名がない"
        assert "変換結果_共通IDグループ番号" in header, \
            "ヘッダーに変換結果カラン名がない"

    # RISK: R-010 - 大容量ファイル処理
    def test_output_large_dataset_row_count(self, output_df_large_dataset):
        """
        正常系: 大規模出力ファイルの行数確認

        DC-005要件（R-010対応）:
        - 100行のデータセット
        - 期待: 全行が正常に出力される
        """
        assert not output_df_large_dataset.empty
        assert len(output_df_large_dataset) == 100, \
            f"行数が異なる（期待: 100, 実際: {len(output_df_large_dataset)}）"

        # 全行にデータが存在
        assert output_df_large_dataset.notna().all().all(), \
            "NULL値が存在する"


# ============================================================================
# 異常系テスト（約45%）
# ============================================================================

class TestOutputSchemaInvalidData:
    """
    異常系: 変換失敗・不正な出力形式の検証
    """

    # RISK: R-007 - 過度な例外吸収
    def test_output_with_null_values_conversion_failure(self, output_df_with_null_values):
        """
        異常系: 変換失敗時にNULL値が含まれる

        DC-007要件（BR-007-1, RISK: R-007）:
        - 変換先IDが存在しない場合、NULLが返却される
        - 期待: 入力カランは保持され、変換結果にNULLが含まれる
        """
        assert not output_df_with_null_values.empty
        assert len(output_df_with_null_values) == 2

        # 入力カランは全て存在
        assert output_df_with_null_values["アカウント識別子"].notna().all(), \
            "入力カラムにNULLが存在する（期待: データが常に存在）"

        # 変換結果には少なくとも1つのNULLが存在
        conversion_col = "変換結果_共通IDグループ番号"
        has_null = output_df_with_null_values[conversion_col].isna().any()
        assert has_null, \
            "変換結果にNULLが存在しない（変換失敗ケースの定義に矛盾）"

    # RISK: R-012 - データ形式・バリデーション
    def test_output_invalid_column_name_format(self):
        """
        異常系: 出力カラム名が不正な形式

        DC-005要件（カラン命名規則）:
        - 出力カラン名は「変換結果_{ID種別}」形式であるべき
        - 不正な命名を検出
        """
        # 不正な命名例
        invalid_names = [
            "result",  # 日本語でない
            "変換結果",  # ID種別が不明確
            "変換結果_unknown_type"  # 未定義のID種別
        ]

        for invalid_name in invalid_names:
            # 不正な命名は「変換結果_」で始まっていても、その後にID種別がない
            # または「変換結果」で始まるが形式が異なる
            is_valid = invalid_name.startswith("変換結果_") and len(invalid_name) > len("変換結果_")
            # 命名規則チェック（簡略版）
            if not is_valid:
                assert True, \
                    f"カラム名 '{invalid_name}' が不正な形式（命名規則確認）"

    # RISK: R-024 - GCSアップロード・ダウンロード時の通信エラー
    def test_output_empty_dataframe_no_rows(self):
        """
        異常系: 出力DataFrameが空（データなし）

        DC-005要件（RISK: R-024対応）:
        - 変換結果が完全にNULLの場合、出力なし
        - 期待: 出力ファイルが作成されない（またはエラー）
        """
        output_df = pd.DataFrame()
        assert output_df.empty, \
            "DataFrameが空ではない"
        assert len(output_df) == 0, \
            "行数が0ではない"

    # RISK: R-012 - データ形式・バリデーション
    def test_output_mismatched_row_count(self):
        """
        異常系: 入力行数と出力行数が一致しない

        DC-005要件（BR-017-1）:
        - left merge で実装されるため、入力行数 = 出力行数
        - 一致しない場合は不正な処理結果
        """
        input_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111", "BBBBBBBBBBBBBBBBBBBBB222"]
        })
        # 異常な出力（行数が異なる）
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],  # 1行のみ
            "変換結果_共通IDグループ番号": ["000012345678"]
        })

        # 入力と出力の行数が異なる
        assert len(input_df) != len(output_df), \
            "入力と出力の行数が一致している（異常系の定義に矛盾）"


# ============================================================================
# 境界値テスト（約15%）
# ============================================================================

class TestOutputSchemaBoundary:
    """
    境界値: 出力ファイルサイズ・カラン数の制限値を検証
    """

    # RISK: R-010, R-011 - ファイルサイズ・メモリ管理
    def test_boundary_excel_row_limit_1_million(self, output_df_excel_limit_boundary):
        """
        境界値: Excel出力の上限（1,000,000行）

        DC-005要件（BR-015-1, RISK: R-010, R-011）:
        - max_excel_rows: 1,000,000行
        - 1,000,000行を超える場合は自動的にCSVに切り替え
        """
        # テスト用に1000行を使用（1M行はメモリ不足）
        assert len(output_df_excel_limit_boundary) == 1000

        # 仮想的に1M行の境界値をテスト
        max_excel_rows = 1_000_000
        is_within_limit = len(output_df_excel_limit_boundary) <= max_excel_rows
        assert is_within_limit, \
            f"行数が上限を超過（期待: <= {max_excel_rows}, 実際: {len(output_df_excel_limit_boundary)}）"

    # RISK: R-015 - 出力ファイル形式選択
    def test_boundary_csv_format_no_row_limit(self):
        """
        境界値: CSV形式の行数制限なし

        DC-005要件（BR-015-2, RISK: R-015）:
        - CSV形式は行数制限がない
        - Excel超過時は自動的にCSVに切り替え
        """
        # 仮想的に1.5M行のCSV出力を想定
        virtual_rows = 1_500_000

        # CSVには制限がないため、OK
        is_csv_valid = True  # CSV形式であれば常にOK
        assert is_csv_valid, \
            "CSV形式の検証に失敗"

    # RISK: R-012 - データ形式・バリデーション
    def test_boundary_column_name_special_characters(self):
        """
        境界値: カラン名に特殊文字が含まれる場合

        DC-005要件（BR-016-1対応）:
        - ファイル名に禁止文字がないか確認
        """
        # 禁止文字の確認
        forbidden_chars = ['\\', '/', ':', '*', '?', '"', '<', '>', '|']

        test_filename = "出力ファイル_変換結果"  # 日本語とアンダースコア
        has_forbidden = any(char in test_filename for char in forbidden_chars)
        assert not has_forbidden, \
            f"ファイル名に禁止文字が含まれている: {test_filename}"

    # RISK: R-017 - 出力行の順序保持
    def test_boundary_row_order_preservation_after_merge(self):
        """
        境界値: left merge での行順序保持確認

        DC-005要件（BR-017-1, RISK: R-017）:
        - 複数のデータセットをマージしても元の順序を保持
        """
        left_df = pd.DataFrame({
            "アカウント識別子": ["C001", "C002", "C003"]
        })

        right_df = pd.DataFrame({
            "アカウント識別子": ["C001", "C002", "C003"],
            "変換結果": ["R001", "R002", "R003"]
        })

        merged = pd.merge(left_df, right_df, on="アカウント識別子", how="left")

        # 元の順序が保持されているか確認
        expected_order = ["C001", "C002", "C003"]
        actual_order = merged["アカウント識別子"].tolist()
        assert actual_order == expected_order, \
            f"行順序が保持されていない（期待: {expected_order}, 実際: {actual_order}）"
