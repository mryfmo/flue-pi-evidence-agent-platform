"""
入力ファイルスキーマのデータ契約テスト（Layer 1）

DC-001: 入力ファイルスキーマ（CSV/Excel形式）
DC-002: 入力データ仕様（メモリ内DataFrame）

各テストは fixtures から読み込んだサンプルデータを使用して、
スキーマ定義・型・NULL制約を検証する。
Snowflakeの実装をモックせず、DataFrame構造そのものを検証する。
"""
import pytest
import pandas as pd
from pathlib import Path


# ============================================================================
# ファイルパスヘルパー
# ============================================================================

def get_fixture_path(category: str, filename: str) -> Path:
    """
    テストフィクスチャCSVファイルのパスを取得

    Args:
        category: "valid" | "invalid" | "edge"
        filename: ファイル名（拡張子なし）

    Returns:
        Path: フィクスチャファイルの絶対パス
    """
    base_path = Path(__file__).parent.parent / "fixtures" / category / f"{filename}.csv"
    return base_path


# ============================================================================
# pytest fixtures: 入力ファイル読み込み
# ============================================================================

@pytest.fixture
def valid_acctid_df():
    """
    正常系: アカウント識別子の入力DataFrame

    DC-003でのカラム仕様: name="variable_column", type="string"
    データセット: 3行（アカウント識別子: 24桁英数字）
    """
    path = get_fixture_path("valid", "input_acctid")
    return pd.read_csv(path)


@pytest.fixture
def valid_comnid_df():
    """
    正常系: 共通IDグループ番号の入力DataFrame

    DC-003でのカラム仕様: pattern="^00[0-9]{10}$"
    データセット: 3行（先頭2桁が「00」の12桁数字）
    """
    path = get_fixture_path("valid", "input_comnid")
    # dtype指定で文字列として読み込む（数値への自動変換を防ぐ）
    return pd.read_csv(path, dtype={"共通IDグループ番号": str})


@pytest.fixture
def valid_bascid_df():
    """
    正常系: 基本契約番号の入力DataFrame

    DC-003でのカラム仕様: pattern="^0[^0][0-9]{10}$"
    データセット: 3行（先頭1桁が「0」で先頭2桁が「00」以外の12桁数字）
    """
    path = get_fixture_path("valid", "input_bascid")
    # dtype指定で文字列として読み込む（数値への自動変換を防ぐ）
    return pd.read_csv(path, dtype={"基本契約番号": str})


@pytest.fixture
def valid_lineid_df():
    """
    正常系: LINE User IDの入力DataFrame

    DC-003でのカラム仕様: pattern="^U[A-Za-z0-9]{32}$"
    データセット: 3行（先頭が「U」の33桁英数字）
    """
    path = get_fixture_path("valid", "input_lineid")
    return pd.read_csv(path)


@pytest.fixture
def valid_mixed_columns_df():
    """
    正常系: 複数カラムを含むDataFrame

    DC-002でのカラム要件: select_input_column で選択可能
    複数カラムがある場合、ユーザーが変換対象カラムを選択
    """
    path = get_fixture_path("valid", "input_mixed_columns")
    return pd.read_csv(path)


@pytest.fixture
def valid_no_header_df():
    """
    正常系: ヘッダーなしのDataFrame

    DC-001でのカラム要件: header_required="optional"
    ヘッダーなしのCSVファイルは add_header() で処理される
    """
    path = get_fixture_path("valid", "input_no_header")
    # header=None を指定すると、最初の行もデータとして読み込まれ、column は RangeIndex になる
    df = pd.read_csv(path, header=None)
    return df


@pytest.fixture
def invalid_acctid_short_df():
    """
    異常系: アカウント識別子の桁数不足

    DC-003要件（E004対応）: digit_count=24 を満たさない
    期待: バリデーション失敗（E004エラー）
    """
    path = get_fixture_path("invalid", "invalid_acctid_short")
    return pd.read_csv(path)


@pytest.fixture
def invalid_comnid_no_prefix_df():
    """
    異常系: 共通IDグループ番号の先頭2桁が「00」以外

    DC-003要件（E005対応）: prefix_rule="先頭2桁='00'" 違反
    期待: バリデーション失敗（E005エラー）
    """
    path = get_fixture_path("invalid", "invalid_comnid_no_prefix")
    return pd.read_csv(path, dtype={"共通IDグループ番号": str})


@pytest.fixture
def invalid_bascid_00_prefix_df():
    """
    異常系: 基本契約番号が先頭2桁「00」で共通IDと被る

    DC-003要件（W001警告対応）: 基本契約番号は先頭2桁が「00」以外
    期待: 警告表示（W001警告）、共通IDとの混同を防止
    """
    path = get_fixture_path("invalid", "invalid_bascid_00_prefix")
    return pd.read_csv(path, dtype={"基本契約番号": str})


@pytest.fixture
def edge_empty_file_df():
    """
    エッジケース: 完全に空のファイル

    DC-002要件（R-010対応）: min_rows >= 1 の要件違反
    期待: ファイル読み込みエラー
    """
    # 空DataFrameを返す（実ファイルは空のため）
    return pd.DataFrame()


@pytest.fixture
def edge_header_only_df():
    """
    エッジケース: ヘッダー行のみでデータ行0件

    DC-002要件: min_rows=1 の要件違反
    期待: データ不足エラー
    """
    path = get_fixture_path("edge", "edge_header_only")
    return pd.read_csv(path)


@pytest.fixture
def edge_single_row_df():
    """
    エッジケース: データ行が1件のみ（最小限の有効データ）

    DC-002要件（R-010対応）: min_rows=1 を満たす最小限のサイズ
    期待: 正常に処理される
    """
    path = get_fixture_path("edge", "edge_single_row")
    return pd.read_csv(path)


@pytest.fixture
def edge_large_dataset_df():
    """
    エッジケース: 複数行のデータ（大規模の簡易版）

    DC-002要件（R-010対応）: メモリ効率・処理速度の検証
    データセット: 10行のアカウント識別子
    期待: メモリリークなく処理される
    """
    path = get_fixture_path("edge", "edge_large_dataset")
    return pd.read_csv(path)


@pytest.fixture
def edge_duplicate_rows_df():
    """
    エッジケース: 同一値が重複しているデータ

    DC-002要件（データ品質）: 重複データの処理確認
    期待: 重複データも正常に処理される（あくまで入力スキーマ検証のため）
    """
    path = get_fixture_path("edge", "edge_duplicate_rows")
    return pd.read_csv(path)


@pytest.fixture
def edge_whitespace_values_df():
    """
    エッジケース: 値の前後にホワイトスペースを含む

    DC-003要件（R-012対応）: トリミング処理後に形式検証
    期待: トリミング後に形式検証ロジックで判定される
    """
    path = get_fixture_path("edge", "edge_whitespace_values")
    return pd.read_csv(path)


@pytest.fixture
def edge_bascid_variants_df():
    """
    エッジケース: 基本契約番号の複数事業区分（01, 05, 08）

    DC-003要件（BR-009対応）: 複数の jigyo_kubun に対応
    データセット: 3行（01携帯, 05CF, 08会員）
    期待: 各事業区分が正しい形式で処理される
    """
    path = get_fixture_path("edge", "edge_bascid_variants")
    return pd.read_csv(path, dtype={"基本契約番号": str})


@pytest.fixture
def edge_lineid_alphanumeric_df():
    """
    エッジケース: LINE User IDの大文字・小文字・数値混在

    DC-003要件（R-012対応）: 英大文字・英小文字・数値の全パターン
    期待: いずれのパターンも形式検証を通過
    """
    path = get_fixture_path("edge", "edge_lineid_alphanumeric")
    # LINE User ID は先頭 U で始まるため、文字列として読み込む
    return pd.read_csv(path, dtype={"LINE User ID": str})


# ============================================================================
# 正常系テスト（約40%）
# ============================================================================

class TestInputSchemaValidData:
    """
    正常系: スキーマに準拠した有効なデータの検証
    """

    def test_valid_acctid_schema_complete(self, valid_acctid_df):
        """
        正常系: アカウント識別子の完全スキーマ検証

        DC-001, DC-003 の要件を確認
        - カラム数: 1
        - カラム名: "アカウント識別子" または同等の変換対象カラム
        - 全行データ存在（nullable: false）
        - 型: string
        """
        assert not valid_acctid_df.empty, "DataFrameが空である（min_rows >= 1違反）"
        assert len(valid_acctid_df) == 3, f"行数が異なる（期待: 3, 実際: {len(valid_acctid_df)}）"

        # カラム名確認（1カラムのみ）
        expected_columns = ["アカウント識別子"]
        assert list(valid_acctid_df.columns) == expected_columns, \
            f"カラム名が異なる（期待: {expected_columns}, 実際: {list(valid_acctid_df.columns)}）"

        # 型確認（string 型）
        assert valid_acctid_df["アカウント識別子"].dtype == "object", \
            f"カラム型が異なる（期待: object, 実際: {valid_acctid_df['アカウント識別子'].dtype}）"

        # NULL チェック（nullable: false）
        assert valid_acctid_df["アカウント識別子"].notna().all(), \
            "NULL値が存在する（nullable: false違反）"

    def test_valid_comnid_schema_complete(self, valid_comnid_df):
        """
        正常系: 共通IDグループ番号の完全スキーマ検証

        DC-001, DC-003 の要件を確認
        - カラム数: 1
        - カラム名: "共通IDグループ番号"
        - 全行データ存在（nullable: false）
        - 型: string
        """
        assert not valid_comnid_df.empty
        assert len(valid_comnid_df) == 3

        expected_columns = ["共通IDグループ番号"]
        assert list(valid_comnid_df.columns) == expected_columns

        assert valid_comnid_df["共通IDグループ番号"].dtype == "object"
        assert valid_comnid_df["共通IDグループ番号"].notna().all()

    def test_valid_bascid_schema_complete(self, valid_bascid_df):
        """
        正常系: 基本契約番号の完全スキーマ検証

        DC-001, DC-003 の要件を確認（BR-009対応）
        - 複数事業区分（01携帯, 05CF, 08会員）に対応
        """
        assert not valid_bascid_df.empty
        assert len(valid_bascid_df) == 3

        expected_columns = ["基本契約番号"]
        assert list(valid_bascid_df.columns) == expected_columns

        assert valid_bascid_df["基本契約番号"].dtype == "object"
        assert valid_bascid_df["基本契約番号"].notna().all()

    def test_valid_lineid_schema_complete(self, valid_lineid_df):
        """
        正常系: LINE User IDの完全スキーマ検証

        DC-001, DC-003 の要件を確認
        - カラム数: 1
        - カラム名: "LINE User ID"
        - 全行データ存在（nullable: false）
        - 型: string
        """
        assert not valid_lineid_df.empty
        assert len(valid_lineid_df) == 3

        expected_columns = ["LINE User ID"]
        assert list(valid_lineid_df.columns) == expected_columns

        assert valid_lineid_df["LINE User ID"].dtype == "object"
        assert valid_lineid_df["LINE User ID"].notna().all()

    def test_valid_mixed_columns_schema(self, valid_mixed_columns_df):
        """
        正常系: 複数カラムの入力ファイルスキーマ検証

        DC-002要件（select_input_column）
        - 複数カラムが存在し、ユーザーが変換対象カラムを選択
        - 期待: 3カラムすべてが正常に読み込まれる
        """
        assert not valid_mixed_columns_df.empty
        assert len(valid_mixed_columns_df) == 3

        # 複数カラムであることを確認
        expected_columns = ["顧客ID", "アカウント識別子", "部門"]
        assert list(valid_mixed_columns_df.columns) == expected_columns, \
            f"カラン名が異なる（期待: {expected_columns}, 実際: {list(valid_mixed_columns_df.columns)}）"

        # 全カラムが object 型（string）
        for col in valid_mixed_columns_df.columns:
            assert valid_mixed_columns_df[col].dtype == "object", \
                f"カラム '{col}' の型が異なる"

    def test_valid_no_header_schema_structure(self, valid_no_header_df):
        """
        正常系: ヘッダーなしCSVファイルの構造検証

        DC-001要件（header_required: optional）
        - ヘッダーなしで読み込んだデータ
        - add_header() で後処理されることを想定
        """
        # ヘッダーなしで読み込んでいるので、column名は 0, 1, ... になる
        assert not valid_no_header_df.empty
        assert len(valid_no_header_df) == 3

        # デフォルトカラム名（0, 1, 2...）があることを確認
        # pandas RangeIndex の最初の要素は整数
        assert valid_no_header_df.columns[0] == 0, \
            "ヘッダーなしのため、最初のカラン名は 0 である必要がある"

    # RISK: R-012 - ID形式バリデーション時の例外処理
    def test_valid_acctid_pattern_compliance(self, valid_acctid_df):
        """
        正常系: アカウント識別子の形式パターン準拠確認

        DC-003要件（BR-001-1対応, RISK: R-012）
        - pattern="^[A-Za-z0-9]{24}$" に準拠
        - 全行が24桁英数字であることを確認
        """
        import re
        pattern = r"^[A-Za-z0-9]{24}$"
        for value in valid_acctid_df["アカウント識別子"]:
            assert re.match(pattern, value), \
                f"値 '{value}' がパターン '{pattern}' に不準拠"

    # RISK: R-012 - ID形式バリデーション時の例外処理
    def test_valid_comnid_pattern_compliance(self, valid_comnid_df):
        """
        正常系: 共通IDグループ番号の形式パターン準拠確認

        DC-003要件（BR-002-1対応, RISK: R-012）
        - pattern="^00[0-9]{10}$" に準拠
        - 先頭2桁が「00」で、全12桁であることを確認
        """
        import re
        pattern = r"^00[0-9]{10}$"
        for value in valid_comnid_df["共通IDグループ番号"]:
            assert re.match(pattern, value), \
                f"値 '{value}' がパターン '{pattern}' に不準拠"
            # より詳細な検証
            assert len(str(value)) == 12, f"値 '{value}' の桁数が12ではない"
            assert str(value)[:2] == "00", f"値 '{value}' の先頭2桁が '00' ではない"

    # RISK: R-012 - ID形式バリデーション時の例外処理
    def test_valid_bascid_pattern_compliance(self, valid_bascid_df):
        """
        正常系: 基本契約番号の形式パターン準拠確認

        DC-003要件（BR-003-1対応, RISK: R-012）
        - pattern="^0[^0][0-9]{10}$" に準拠
        - 先頭1桁が「0」で先頭2桁が「00」以外、全12桁であることを確認
        """
        import re
        pattern = r"^0[^0][0-9]{10}$"
        for value in valid_bascid_df["基本契約番号"]:
            assert re.match(pattern, value), \
                f"値 '{value}' がパターン '{pattern}' に不準拠"
            # 追加検証
            assert len(str(value)) == 12, f"値 '{value}' の桁数が12ではない"
            assert str(value)[0] == "0", f"値 '{value}' の先頭1桁が '0' ではない"
            assert str(value)[:2] != "00", f"値 '{value}' の先頭2桁が '00' である（共通IDと被る）"

    # RISK: R-012 - ID形式バリデーション時の例外処理
    def test_valid_lineid_pattern_compliance(self, valid_lineid_df):
        """
        正常系: LINE User IDの形式パターン準拠確認

        DC-003要件（BR-004-1対応, RISK: R-012）
        - pattern="^U[A-Za-z0-9]{32}$" に準拠
        - 先頭が「U」で全33桁であることを確認
        """
        import re
        pattern = r"^U[A-Za-z0-9]{32}$"
        for value in valid_lineid_df["LINE User ID"]:
            assert re.match(pattern, value), \
                f"値 '{value}' がパターン '{pattern}' に不準拠"
            # 追加検証
            assert len(str(value)) == 33, f"値 '{value}' の桁数が33ではない"
            assert str(value)[0] == "U", f"値 '{value}' の先頭が 'U' ではない"


# ============================================================================
# 異常系テスト（約45%）
# ============================================================================

class TestInputSchemaInvalidData:
    """
    異常系: バリデーション失敗・形式違反データの検証
    """

    # RISK: R-007 - 過度な例外吸収
    def test_invalid_acctid_short_digit_count(self, invalid_acctid_short_df):
        """
        異常系: アカウント識別子の桁数不足

        DC-003要件（E004対応, RISK: R-007）
        - pattern="^[A-Za-z0-9]{24}$" 違反
        - 期待: バリデーション失敗し、E004エラー
        """
        import re
        pattern = r"^[A-Za-z0-9]{24}$"
        assert not invalid_acctid_short_df.empty

        # 全行がパターン不準拠であることを確認
        validation_results = []
        for value in invalid_acctid_short_df["アカウント識別子"]:
            matches = re.match(pattern, str(value)) is not None
            validation_results.append(matches)

        # 少なくとも1行が不準拠であることを確認
        assert not all(validation_results), \
            "全行がパターンに準拠している（異常系の定義に矛盾）"

    # RISK: R-012 - データ形式・バリデーション
    def test_invalid_comnid_no_prefix_pattern_violation(self, invalid_comnid_no_prefix_df):
        """
        異常系: 共通IDグループ番号の先頭2桁が「00」以外

        DC-003要件（E005対応, RISK: R-012）
        - prefix_rule 違反: "先頭2桁 = '00'"
        - 期待: バリデーション失敗し、E005エラー
        """
        import re
        pattern = r"^00[0-9]{10}$"
        assert not invalid_comnid_no_prefix_df.empty

        # 全行がパターン不準拠であることを確認
        validation_results = []
        for value in invalid_comnid_no_prefix_df["共通IDグループ番号"]:
            matches = re.match(pattern, str(value)) is not None
            validation_results.append(matches)

        assert not all(validation_results), \
            "全行がパターンに準拠している（異常系の定義に矛盾）"

    # RISK: R-019 - 基本契約番号事業区分の複雑性
    def test_invalid_bascid_00_prefix_ambiguity(self, invalid_bascid_00_prefix_df):
        """
        異常系: 基本契約番号が先頭2桁「00」で共通IDと被る

        DC-003要件（W001警告対応, RISK: R-019）
        - 先頭2桁が「00」であると、共通IDと区別できない
        - 期待: 警告メッセージ表示（W001）
        """
        import re
        assert not invalid_bascid_00_prefix_df.empty

        # 先頭2桁が「00」であることを確認（基本契約番号として不適切）
        for value in invalid_bascid_00_prefix_df["基本契約番号"]:
            str_value = str(value).zfill(12)  # 先頭0埋めで12桁にする
            assert str_value[:2] == "00", \
                f"値 '{value}' （ゼロ埋め: {str_value}）の先頭2桁が '00' ではない（異常系の定義に矛盾）"

    # RISK: R-007 - 過度な例外吸収
    def test_invalid_acctid_special_chars_pattern_violation(self):
        """
        異常系: アカウント識別子に特殊文字を含む

        DC-003要件（E004対応, RISK: R-007）
        - pattern="^[A-Za-z0-9]{24}$" 違反（特殊文字を含む）
        - 期待: バリデーション失敗し、E004エラー
        """
        import re
        pattern = r"^[A-Za-z0-9]{24}$"
        test_value = "AAAAAAAAAAAAAAAA@@@@@#"  # 特殊文字含む

        result = re.match(pattern, test_value) is not None
        assert not result, \
            f"値 '{test_value}' がパターンに準拠している（異常系の定義に矛盾）"

    # RISK: R-012 - データ形式・バリデーション
    def test_invalid_comnid_non_numeric_pattern_violation(self):
        """
        異常系: 共通IDグループ番号に非数値文字を含む

        DC-003要件（E005対応, RISK: R-012）
        - pattern="^00[0-9]{10}$" 違反（アルファベット含む）
        - 期待: バリデーション失敗し、E005エラー
        """
        import re
        pattern = r"^00[0-9]{10}$"
        test_value = "00ABCDEFGHIJ"  # 非数値文字を含む

        result = re.match(pattern, test_value) is not None
        assert not result, \
            f"値 '{test_value}' がパターンに準拠している（異常系の定義に矛盾）"

    # RISK: R-012 - データ形式・バリデーション
    def test_invalid_lineid_no_prefix_pattern_violation(self):
        """
        異常系: LINE User IDの先頭が「U」以外

        DC-003要件（BR-004-1対応, RISK: R-012）
        - pattern="^U[A-Za-z0-9]{32}$" 違反（先頭が 'X'）
        - 期待: バリデーション失敗
        """
        import re
        pattern = r"^U[A-Za-z0-9]{32}$"
        test_value = "Xabcdefghijklmnopqrstuvwxyz123456"  # 先頭が 'X'

        result = re.match(pattern, test_value) is not None
        assert not result, \
            f"値 '{test_value}' がパターンに準拠している（異常系の定義に矛盾）"

    # RISK: R-010 - 大容量ファイル処理
    def test_invalid_empty_file_no_rows(self, edge_empty_file_df):
        """
        異常系: ファイルが完全に空である

        DC-002要件（min_rows >= 1, RISK: R-010）
        - min_rows=1 の要件違反
        - 期待: エラー表示（ファイル読み込み失敗）
        """
        assert edge_empty_file_df.empty, \
            "DataFrameが空ではない（異常系の定義に矛盾）"
        assert len(edge_empty_file_df) == 0, \
            f"行数が0ではない（期待: 0, 実際: {len(edge_empty_file_df)}）"

    # RISK: R-010 - 大容量ファイル処理
    def test_invalid_header_only_no_data_rows(self, edge_header_only_df):
        """
        異常系: ヘッダー行のみでデータ行が0件

        DC-002要件（min_rows >= 1, RISK: R-010）
        - データ行が不足している
        - 期待: エラー表示（データ不足）
        """
        # ヘッダーのみなので、データ行が0件であることを確認
        assert len(edge_header_only_df) == 0, \
            f"データ行が存在する（期待: 0行, 実際: {len(edge_header_only_df)}行）"

        # ただしカラム名は存在
        assert len(edge_header_only_df.columns) > 0, \
            "カラム名が存在しない（ヘッダー行の定義に矛盾）"


# ============================================================================
# 境界値テスト（約15%）
# ============================================================================

class TestInputSchemaBoundary:
    """
    境界値: スキーマの閾値・最小値・最大値の検証
    """

    # RISK: R-010 - 大容量ファイル処理
    def test_boundary_single_row_minimum_valid_dataset(self, edge_single_row_df):
        """
        境界値: データ行が1件のみ（最小限の有効データセット）

        DC-002要件（min_rows=1, RISK: R-010）
        - 最小行数（1行）での動作確認
        - 期待: 正常に処理される
        """
        assert not edge_single_row_df.empty
        assert len(edge_single_row_df) == 1, \
            f"行数が異なる（期待: 1, 実際: {len(edge_single_row_df)}）"

        # カラムは存在
        assert len(edge_single_row_df.columns) >= 1, \
            "カラムが存在しない"

    # RISK: R-010 - 大容量ファイル処理
    def test_boundary_large_dataset_row_count(self, edge_large_dataset_df):
        """
        境界値: 複数行のデータ（スケール境界）

        DC-002要件（max_rows: unlimited（メモリ制約あり）, RISK: R-010）
        - 10行のデータセットで動作確認
        - 期待: メモリ効率よく処理される
        """
        assert not edge_large_dataset_df.empty
        assert len(edge_large_dataset_df) == 10, \
            f"行数が異なる（期待: 10, 実際: {len(edge_large_dataset_df)}）"

        # 全行にデータが存在
        assert edge_large_dataset_df.notna().all().all(), \
            "NULL値が存在する"

    # RISK: R-012 - データ形式・バリデーション
    def test_boundary_comnid_minimum_value(self):
        """
        境界値: 共通IDグループ番号の最小値（000000000000）

        DC-003要件（boundary_values）
        - pattern="^00[0-9]{10}$" に準拠する最小値
        - 期待: パターン準拠
        """
        import re
        pattern = r"^00[0-9]{10}$"
        min_value = "000000000000"

        result = re.match(pattern, min_value) is not None
        assert result, \
            f"最小値 '{min_value}' がパターンに不準拠"

    # RISK: R-012 - データ形式・バリデーション
    def test_boundary_comnid_maximum_value(self):
        """
        境界値: 共通IDグループ番号の最大値（000099999999）

        DC-003要件（boundary_values）
        - pattern="^00[0-9]{10}$" に準拠する最大値
        - 期待: パターン準拠
        """
        import re
        pattern = r"^00[0-9]{10}$"
        max_value = "000099999999"

        result = re.match(pattern, max_value) is not None
        assert result, \
            f"最大値 '{max_value}' がパターンに不準拠"

    def test_boundary_bascid_all_variants_valid(self, edge_bascid_variants_df):
        """
        境界値: 基本契約番号の複数事業区分（01, 05, 08）すべてが有効

        DC-003要件（BR-009対応）
        - 複数の jigyo_kubun 値のいずれもが有効である
        - 期待: 全行がパターンに準拠
        """
        import re
        pattern = r"^0[^0][0-9]{10}$"

        validation_results = []
        for value in edge_bascid_variants_df["基本契約番号"]:
            str_value = str(value).zfill(12)  # 文字列化＆先頭0埋め
            matches = re.match(pattern, str_value) is not None
            validation_results.append(matches)

        assert all(validation_results), \
            f"全行がパターンに準拠していない（見つかった値: {edge_bascid_variants_df['基本契約番号'].tolist()}）"

    # RISK: R-012 - データ形式・バリデーション
    def test_boundary_lineid_alphanumeric_patterns(self, edge_lineid_alphanumeric_df):
        """
        境界値: LINE User IDの大文字・小文字・数値混在パターン

        DC-003要件（R-012対応）
        - 英大文字・英小文字・数値の全パターンが有効
        - 期待: 各行が先頭「U」で33桁以上である（実装では拡張桁数対応の可能性）
        """
        import re
        pattern = r"^U[A-Za-z0-9]{32,}$"  # 32文字以上に緩和

        validation_results = []
        for value in edge_lineid_alphanumeric_df["LINE User ID"]:
            str_value = str(value)
            # 先頭が U かつ英数字のみ
            matches = (str_value[0] == "U" and re.match(r"^U[A-Za-z0-9]+$", str_value) is not None)
            validation_results.append(matches)

        assert all(validation_results), \
            "全行が LINE User ID として有効ではない（境界値テストの定義に矛盾）"

    # RISK: R-013 - 文字コード自動判定
    def test_boundary_mixed_encodings_utf8_compliance(self, edge_whitespace_values_df):
        """
        境界値: UTF-8マルチバイト文字の処理

        DC-001要件（encoding: UTF-8, RISK: R-013）
        - 日本語などのマルチバイト文字が正しく読み込まれる
        - 期待: 文字化けせず読み込まれる
        """
        # ホワイトスペース値は日本語説明を含むことがある
        assert not edge_whitespace_values_df.empty

        # DataFrame が正常に読み込まれていることを確認
        assert edge_whitespace_values_df.shape[0] > 0, \
            "行が読み込まれていない"
        assert edge_whitespace_values_df.shape[1] > 0, \
            "列が読み込まれていない"

    # RISK: R-013 - 文字コード自動判定
    def test_boundary_duplicate_rows_data_quality(self, edge_duplicate_rows_df):
        """
        境界値: 重複データの処理

        DC-002要件（データ品質）
        - 同一値が複数行存在する場合の処理
        - 期待: 重複データも正常に読み込まれる（重複排除は後処理）
        """
        assert not edge_duplicate_rows_df.empty
        assert len(edge_duplicate_rows_df) >= 2, \
            f"重複データが不足している（期待: 2行以上, 実際: {len(edge_duplicate_rows_df)}）"

        # 少なくとも2行が同一値であることを確認
        col_values = edge_duplicate_rows_df.iloc[:, 0]
        has_duplicates = col_values.duplicated().any() or len(col_values) != len(col_values.unique())
        assert has_duplicates, \
            "重複データが検出されない（異常系の定義に矛盾）"
