# ドメイン・ルール定義書

**対象アプリケーション**: pochi-id-converter  
**生成日時**: 2026-05-01  
**テスト対象**: ビジネスロジック・ドメインルール  

---

## 1. 概要

本ドキュメントは、pochi-id-converter アプリケーションの中核ドメインルールを定義し、テスト観点・検証方法を明記します。

---

## 2. ID種別の定義とパターン

### 2.1 アカウント識別子（acctid）

| 項目 | 定義 |
|------|------|
| **ID名** | アカウント識別子 |
| **ID コード** | `acctid` |
| **桁数** | 24 桁 |
| **形式パターン** | `^[A-Za-z0-9]{24}$` |
| **説明** | NTTドコモのアカウント識別子 |
| **Snowflake カラム** | `kk_acctid` |
| **例** | `AAAAAAAAAAAAAAAAAAAAA111`, `BBBBBBBBBBBBBBBBBBBBB222` |

**バリデーションルール**:
- 英数字のみ（大文字・小文字混在可）
- 24 桁固定
- 形式チェックロジック: `check_input_data(source_id='acctid', input_df)`

**テスト観点**:
- 正常値: 24 桁英数字
- 異常値: 23 桁、25 桁、特殊文字含む、記号含む

---

### 2.2 共通IDグループ番号（comnid）

| 項目 | 定義 |
|------|------|
| **ID名** | 共通IDグループ番号 |
| **ID コード** | `comnid` |
| **桁数** | 12 桁 |
| **形式パターン** | `^00[0-9]{10}$` |
| **説明** | 先頭2桁が「00」で固定の12桁数字 |
| **プレフィックスルール** | 先頭2桁 = `'00'`（共通IDの識別子） |
| **Snowflake カラム** | `comnid` |
| **例** | `000012345678`, `000087654321` |

**バリデーションルール**:
- 数字のみ
- 12 桁固定
- 先頭2桁が「00」
- 形式チェックロジック: `check_input_data(source_id='comnid', input_df)`

**テスト観点**:
- 正常値: `00` で始まる 12 桁数字
- 異常値: 先頭が「01」〜「99」、11 桁、13 桁、英字含む

---

### 2.3 基本契約番号（bascid）

| 項目 | 定義 |
|------|------|
| **ID名** | 基本契約番号 |
| **ID コード** | `bascid` |
| **桁数** | 12 桁 |
| **形式パターン** | `^0[^0][0-9]{10}$` |
| **説明** | 先頭1桁が「0」で固定。先頭2桁は「00」以外 |
| **プレフィックスルール** | 先頭1桁 = `'0'` AND 先頭2桁 != `'00'`（共通IDと区別） |
| **Snowflake カラム** | 事業区分依存（下記参照） |
| **例** | `012345678901`, `051234567890`, `082345678901` |

**バリデーションルール**:
- 数字のみ
- 12 桁固定
- 先頭1桁が「0」
- 先頭2桁が「00」以外（共通IDと区別）
- 形式チェックロジック: `check_input_data(source_id='bascid*', input_df)`

**テスト観点**:
- 正常値: `01`〜`09`, `10`〜`99` で始まる 12 桁数字（ただし先頭は「0」で固定のため `01`〜`09` が一般的）
- 異常値: 先頭2桁が「00」（共通IDと混同）、先頭が「1」〜「9」、11 桁、13 桁

---

#### 2.3.1 基本契約番号の事業区分バリアント

| コード | 事業区分 | 説明 | Snowflake カラム |
|--------|---------|------|-------------------|
| `bascid01` | 01 | 基本契約番号_01携帯事業 | `kk_account_bascid` |
| `bascid05` | 05 | 基本契約番号_05CF事業 | `kk_account_bascid` |
| `bascid08` | 08 | 基本契約番号_08会員事業 | `bascid_ki` |

**特殊ロジック**:
- 事業区分 01, 05 は同じカラム `kk_account_bascid` を使用
- 事業区分 08 は別カラム `bascid_ki` を使用
- 変換時、ユーザーが複数事業区分を同時選択可能
- 警告メッセージ: 事業区分別フィルタの重要性を案内

**テスト観点**:
- 各事業区分の SQL 生成ロジック確認
- 複数事業区分選択時の OUTER JOIN 確認
- カラムマッピングの正確性確認

---

### 2.4 LINE User ID（lineid）

| 項目 | 定義 |
|------|------|
| **ID名** | LINE User ID |
| **ID コード** | `lineid` |
| **桁数** | 33 桁 |
| **形式パターン** | `^U[A-Za-z0-9]{32}$` |
| **説明** | LINE User ID。先頭は「U」で固定 |
| **Snowflake カラム** | `line_uid` |
| **例** | `Uabcdefghijklmnopqrstuvwxyz123456`, `Uzyxwvutsrqponmlkjihgfedcba000000` |

**バリデーションルール**:
- 先頭1文字が「U」で固定
- 残り 32 文字は英数字（大文字・小文字混在可）
- 33 桁固定
- 形式チェックロジック: `check_input_data(source_id='lineid', input_df)`

**テスト観点**:
- 正常値: `U` + 32 桁英数字
- 異常値: 先頭が「L」や数字、32 桁、34 桁、特殊文字含む

---

## 3. ID変換ロジックのドメインルール

### 3.1 基準日フィルタリング

| 項目 | ルール |
|------|--------|
| **テーブル** | `VW_ADM_DNCL_COMNID_INTEGRATION` |
| **カラム** | `LAK_PTK_CRITERIA_DAY` |
| **値** | `CURRENT_DATE - 5日` |
| **実装** | `target_date = (datetime.now() - timedelta(days=5)).date()` |
| **理由** | リアルタイムデータではなく、確定データを使用 |

**テスト観点**:
- 固定日付でのテスト（テスト環境では日付を置き換え）
- 基準日が正確に適用されているか確認
- 基準日ロジック自体の検証（-5日計算）

---

### 3.2 正規判定区分フィルタリング

| 項目 | ルール |
|------|--------|
| **カラム** | `REGULAR_INCOMPLETE_JUDGMENT_CLASSIFICATION` |
| **値** | `'0'`（正規完了のみ） |
| **SQLAlchemy** | `ComnidIntegration.regular_incomplete_judgment_classification == '0'` |
| **理由** | 未完了データを除外し、確定データのみ使用 |

**テスト観点**:
- WHERE 条件が正確に適用されているか確認
- 未完了データ（区分 != '0'）が除外されているか確認

---

### 3.3 NULL値フィルタリング

| 項目 | ルール |
|------|--------|
| **カラム** | 変換先カラム（対象ID） |
| **条件** | `IS NOT NULL` |
| **SQLAlchemy** | `target_column.isnot(None)` |
| **理由** | 変換先IDが存在しない場合は結果を返さない |

**テスト観点**:
- NULL 値を持つレコードが除外されているか確認
- 出力結果に NULL が含まれていないか確認

---

### 3.4 重複レコード処理

| 項目 | ルール |
|------|--------|
| **条件** | 複数の対応IDが存在する場合 |
| **SQLAlchemy** | `func.row_number().over(PARTITION BY join_column ORDER BY record_update_date DESC, target_column DESC)` |
| **優先順位** | 1位: `RECORD_UPDATE_DATE DESC`（最新を優先） / 2位: 対応値 `DESC`（値の大きい順） |
| **結果** | ROW_NUMBER() = 1 のレコードのみ抽出 |

**テスト観点**:
- 複数対応時に最新レコードが選択されているか確認
- 更新日が同じ場合、値の大きい順で 1位が選択されているか確認
- 重複排除後、重複がないこと確認

---

## 4. ID変換マッピング

### 4.1 ID コード ↔ 日本語名 マッピング

| ID コード | 日本語名 |
|----------|---------|
| `acctid` | アカウント識別子 |
| `comnid` | 共通IDグループ番号 |
| `bascid01` | 基本契約番号_01携帯事業 |
| `bascid05` | 基本契約番号_05CF事業 |
| `bascid08` | 基本契約番号_08会員事業 |
| `lineid` | LINEID |

**実装**: `definition.py` 内の `source_id_dict`

**テスト観点**:
- マッピング辞書の整合性確認
- 全 ID コードが辞書に含まれているか確認
- 日本語名の一意性確認

---

### 4.2 Snowflake カラム マッピング

| ID コード | Snowflake カラム | テーブル |
|----------|-----------------|---------|
| `acctid` | `kk_acctid` | VW_ADM_DNCL_COMNID_INTEGRATION |
| `comnid` | `comnid` | VW_ADM_DNCL_COMNID_INTEGRATION |
| `bascid01` | `kk_account_bascid` | VW_ADM_DNCL_COMNID_INTEGRATION |
| `bascid05` | `kk_account_bascid` | VW_ADM_DNCL_COMNID_INTEGRATION |
| `bascid08` | `bascid_ki` | VW_ADM_DNCL_COMNID_INTEGRATION |
| `lineid` | `line_uid` | VW_DMC_DNCL_LINE_* |

**テスト観点**:
- SQL 生成時にカラムマッピングが正確か確認
- テーブル選択が正確か確認
- 事業区分別の異なるカラル使い分けを確認

---

## 5. LINE連携ロジック

### 5.1 アカウント識別子 → LINE User ID 変換

| ステップ | 実行内容 | 関数 |
|---------|---------|------|
| 1 | 入力ID をキーに LineUserIdCoordinattionData を検索 | `__create_convert_acctid_to_lineid_CTE()` |
| 2 | フィルタ: `account_coordination_flag = 1` | WHERE 条件 |
| 3 | フィルタ: `line_business_account = '1654296328'` | WHERE 条件 |
| 4 | LineFriendList にジョイン（`chnl_id = '1654296328'`） | INNER JOIN |
| 5 | 基準日フィルタ: `lakptk_standard_nengappi = CURRENT_DATE - 2日` | WHERE 条件 |
| 6 | LINE User ID を出力 | SELECT |

**テスト観点**:
- 各 WHERE 条件が正確に適用されているか
- ジョイン条件が正確か
- 基準日ロジックが正確か

---

### 5.2 LINE User ID → アカウント識別子 変換

| ステップ | 実行内容 | 関数 |
|---------|---------|------|
| 1 | 入力ID（LINE User ID）をキーに検索 | `__create_convert_lineid_to_acctid_CTE()` |
| 2 | LineUserIdCoordinattionData で `line_uid = 入力ID` | WHERE 条件 |
| 3 | LineFriendList で `line_user_id = 入力ID` | WHERE 条件 |
| 4 | フィルタ: `chnl_id = '1654296328'` | WHERE 条件 |
| 5 | アカウント識別子を出力 | SELECT |

**テスト観点**:
- 逆方向変換ロジックの正確性
- テーブル選択の正確性

---

### 5.3 LINE User ID ↔ 他ID種別 中間変換

| フロー | 説明 |
|--------|------|
| `lineid → acctid → comnid` | LINE → アカウント識別子 → 共通ID |
| `comnid → acctid → lineid` | 共通ID → アカウント識別子 → LINE |

**実装**: `_execute_orm_query_line()` で統括

**テスト観点**:
- 中間変換が順序通りに実行されるか
- 2段階変換での精度確認
- 最終出力が正確か

---

## 6. ファイル入出力ドメインルール

### 6.1 入力ファイル仕様

| 項目 | 値 |
|------|-----|
| **ファイル形式** | CSV, XLSX |
| **文字コード** | UTF-8, UTF-8-SIG, Shift-JIS, EUC-JP, CP932 |
| **ヘッダー** | あり / なし（ユーザー判定） |
| **データ型** | Pandas DataFrame（メモリ内） |

**テスト観点**:
- 全ファイル形式のアップロード確認
- 複数文字コード対応確認
- ヘッダーあり/なしの両方確認

---

### 6.2 出力ファイル仕様

| 項目 | 値 |
|------|-----|
| **ファイル形式** | CSV, XLSX（出力件数で自動選択） |
| **文字コード（CSV）** | UTF-8-SIG（Excel 文字化け対策） |
| **文字コード（XLSX）** | openpyxl（バイナリ） |
| **最大行数（XLSX）** | 1,000,000 行（超過時は CSV に自動切り替え） |
| **行順序** | 入力ファイルの元の順序を保持（left merge） |

**テスト観点**:
- CSV/XLSX の文字コード確認
- 1M 行超過時の自動切り替え確認
- 行順序保持の確認

---

### 6.3 ファイル名バリデーション

| 項目 | ルール |
|------|--------|
| **禁止文字** | `\ / : * ? " < > \|` |
| **最大長** | 255 文字（OS制限） |
| **関数** | `check_input_file(file_name)` |

**テスト観点**:
- 各禁止文字の検出確認
- ファイル名長の上限確認

---

## 7. セッション状態管理ルール

### 7.1 初期化トリガー

| トリガー | 初期化対象 | 関数 |
|---------|----------|------|
| **新規ファイルアップロード** | 全変換結果・出力ファイル | `init_convert()` |
| **入力カラム変更** | 全変換結果・出力ファイル | `init_convert()` |
| **出力ID種別変更** | 全変換結果・出力ファイル | `init_convert()` |
| **事業区分選択変更** | 全変換結果・出力ファイル | `init_convert()` |

**初期化内容**:
```python
st.session_state['convert'] = False
st.session_state['convert_done'] = False
st.session_state['get_output'] = None
st.session_state['output_df_culums_num'] = None
st.session_state['output_file_name'] = None
st.session_state['output_file'] = None
st.session_state['output_file_url'] = None
```

**テスト観点**:
- 各トリガーの正確な検知
- 初期化タイミングの正確性
- 前回データの混在がないこと

---

### 7.2 セッション状態変数

| キー | 型 | 初期値 | 説明 |
|------|-----|--------|------|
| `convert` | `bool` | `False` | ID変換処理実行フラグ |
| `convert_done` | `bool` | `False` | ID変換処理完了フラグ |
| `get_output` | `pd.DataFrame \| None` | `None` | 変換結果 DataFrame |
| `output_df_culums_num` | `int \| None` | `None` | 出力データ行数 |
| `output_file_name` | `str \| None` | `None` | ダウンロードファイル名 |
| `output_file` | `bytes \| None` | `None` | ファイルバイナリ |
| `output_file_url` | `str \| None` | `None` | GCS ダウンロード URL |
| `save_file_path` | `str` | `""` | アップロードファイルの GCS パス |
| `selected_convert_base_culumns` | `str` | `""` | 選択中の入力カラム名 |
| `selected_convert_after_id` | `str` | `""` | 選択中の出力ID種別 |
| `selected_convert_after_bascid` | `list[str]` | `""` | 選択中の事業区分リスト |

**テスト観点**:
- 各状態変数の初期値確認
- 状態遷移の正確性確認
- 状態依存ロジックの動作確認

---

## 8. キャッシング・パフォーマンスルール

### 8.1 Streamlit キャッシング（@st.cache_data）

| 関数 | 対象 | キャッシュキー | 理由 |
|------|------|-----------------|------|
| `add_header()` | ヘッダー追加処理 | 入力 DataFrame | パフォーマンス最適化 |

**テスト観点**:
- キャッシュが正確に機能しているか
- キャッシュ有効期限の確認
- テスト環境でのキャッシュクリア確認

---

## 9. セキュリティ・コンプライアンスルール

### 9.1 データの社外提供禁止

| 対象 | ルール | 表示箇所 |
|------|--------|---------|
| **ID変換結果** | 社内利用限定。社外提供不可 | 複数ページ |

**実装箇所**:
- ホーム画面（`view_home_information()`）
- 01_IDを変換する.py（使用方法冒頭）
- 02_使い方がわからないときは.py（注意事項）
- 04_データソースについて.py（テスト結果説明）

**テスト観点**:
- 警告メッセージが全表示箇所で表示されているか
- メッセージ内容が正確か

---

### 9.2 SQL Injection 対策

| 対策 | 実装 |
|------|------|
| **パラメータバインディング** | SQLAlchemy ORM 使用（既実装） |
| **入力サニタイゼーション** | ID形式チェック（`check_input_data()`）|

**テスト観点**:
- SQLAlchemy のパラメータバインディング確認
- 特殊文字・SQL 予約語の入力による SQL Injection テスト

---

## 10. エラーハンドリングドメインルール

### 10.1 例外型別の処理

| 例外型 | エラーコード | メッセージ | 対処方法 |
|--------|-------------|-----------|---------|
| `MemoryError` | E001 | メモリエラー | ファイル分割 |
| `XLRDError` | E002 | ファイル暗号化 | 暗号化解除 |
| `UnicodeDecodeError` | E003 | 文字コード読込失敗 | 文字コード手動選択 |
| `ValidationError` (acctid) | E004 | アカウント識別子形式不正 | データ修正 |
| `ValidationError` (comnid) | E005 | 共通ID形式不正 | データ修正 |
| `ValidationError` (bascid) | E006 | 基本契約番号形式不正 | データ修正 |
| その他 | E007 | 予期しないエラー | 再試行 |

**テスト観点**:
- 各例外型の正確な検出
- エラーメッセージの正確性
- ユーザーへの導出の正確性

---

### 10.2 警告メッセージ

| 警告コード | タイプ | メッセージ | トリガー |
|-----------|--------|----------|---------|
| W001 | 基本契約番号関連 | 事業区分確認警告 | 基本契約番号選択時 |
| W002 | 事業区分未選択 | チェックボックス最低1つ選択 | 基本契約番号変換時 |

**テスト観点**:
- 警告表示タイミングの正確性
- 警告メッセージの正確性

---

## 11. DogHarness データセット監視

| 項目 | ルール |
|------|--------|
| **監視対象** | `VW_ADM_DNCL_COMNID_INTEGRATION` |
| **監視項目** | 遅延・汚染情報 |
| **表示方法** | `st.warning()` / `st.error()` |
| **実装関数** | `view_dog_harness()` in `dogharness.py` |

**テスト観点**:
- 監視対象テーブルが正確に登録されているか
- 遅延・汚染情報の検出確認
- UI 表示の確認

---

## 12. テスト実装ガイダンス

### 12.1 単体テスト（Unit Test）

- **ID形式バリデーション**: 各パターン（正常値・異常値）
- **マッピング辞書**: 整合性・完全性
- **ビジネスロジック**: 各ルール独立の動作確認

### 12.2 統合テスト（Integration Test）

- **Snowflake クエリ**: CTE生成ロジック・実行確認
- **ID変換パイプライン**: 全ステップの動作確認
- **ファイル入出力**: GCS との連携確認

### 12.3 E2E テスト（End-to-End）

- **ページルーティング**: 全ページ遷移確認
- **ユーザーフロー**: ファイルアップロード〜ダウンロードの完全フロー
- **エラーハンドリング**: 各エラーケースの UI 動作確認

---

## 付録

### 参照ドキュメント

- `data-contracts.json`: 入出力データ仕様
- `business-rules.json`: ビジネスルール定義
- `risk-catalog.md`: リスク・カタログ
- `test-viewpoints.json`: テスト観点定義
- `scenarios.json`: テストシナリオ
