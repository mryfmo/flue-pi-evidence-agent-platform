import pytest
import sys
import os
import importlib
from datetime import datetime as dt

import pandas as pd

# app配下のパスを追加
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "app"))
print(sys.path)
# テスト対象のモジュールをインポート
test_module_name = "lib.queries.get_statement"
test_module = importlib.import_module(test_module_name)
globals().update(
    {
        name: getattr(test_module, name)
        for name in dir(test_module)
        if not name.startswith("__")
    }
)

# 比較対象のモジュールをインポート
module_name = "lib.old_query_collect"
module = importlib.import_module(module_name)
globals().update(
    {name: getattr(module, name) for name in dir(module) if not name.startswith("__")}
)


# 変換前・後のモジュールをインポート
vod_module_name = "lib.view_output_data"
vod_module = importlib.import_module(vod_module_name)
globals().update(
    {
        name: getattr(vod_module, name)
        for name in dir(vod_module)
        if not name.startswith("__")
    }
)


class old_input_datas:
    def __init__(
        self,
        origin_source,
        input_colum_name,
        target_id_column,
        select_input_colum,
        select_id,
        bascid_list=[],
    ):
        self.origin_source = origin_source
        self.input_colum_name = input_colum_name
        self.target_id_column = target_id_column
        self.select_input_colum = select_input_colum
        self.select_id = select_id
        self.bascid_list = bascid_list


class input_datas:

    def __init__(
        self,
        input_df,
        input_data_type,
        output_data_type,
        select_input_column,
        bascid_list=[],
    ):
        self.input_df = input_df
        self.input_data_type = input_data_type
        self.output_data_type = output_data_type
        self.select_input_column = select_input_column
        self.bascid_list = bascid_list


def test_acctid_base():
    """
    ### 概要
    このテストコードの概要は、acctidを変換元にした変換が正しく機能しているかを確認するためのものです。
    具体的方法は、現在の変換方法とoldの変換方法が一致しているかを検証します。

    ### テスト内容:
    - acctid_to_comnid 変換が正しく機能していること (旧変換方法と一致)
    - acctid_to_bascid (01) 変換が正しく機能していること (旧変換方法と一致)
    - acctid_to_bascid (05) 変換が正しく機能していること (旧変換方法と一致)
    - acctid_to_bascid (08) 変換が正しく機能していること (旧変換方法と一致)
    - acctid_to_bascid (01, 05) 変換が正しく機能していること (旧変換方法と一致)
    - acctid_to_bascid (01, 08) 変換が正しく機能していること (旧変換方法と一致)
    - acctid_to_bascid (05, 08) 変換が正しく機能していること (旧変換方法と一致)
    - acctid_to_bascid (01, 05, 08) 変換が正しく機能していること (旧変換方法と一致)
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/acctid_100.csv"
    )
    df = df["ACCTID"].dropna()

    input_df = make_input_df(df, "ACCTID")

    ##############################
    # acctid_to_comnid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="共通IDグループ番号",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="comnid",
        select_input_column="ACCTID",
    )

    new_acctid_to_comnid_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_comnid_result = left_merge_df(
        df, new_acctid_to_comnid_result, new_input_data_name_list.select_input_column
    )

    old_acctid_to_comnid_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_comnid_result = left_merge_df(
        df, old_acctid_to_comnid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_acctid_to_comnid_result.equals(old_acctid_to_comnid_result)

    ##############################
    # acctid_to_bascid (01)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["mb"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["01"],
    )

    new_acctid_to_bascid_01_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_01_result = left_merge_df(
        df, new_acctid_to_bascid_01_result, new_input_data_name_list.select_input_column
    )

    old_acctid_to_bascid_01_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_01_result = left_merge_df(
        df, old_acctid_to_bascid_01_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_acctid_to_bascid_01_result.equals(old_acctid_to_bascid_01_result)

    ##############################
    # acctid_to_bascid (05)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["cf"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["05"],
    )

    new_acctid_to_bascid_05_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_05_result = left_merge_df(
        df, new_acctid_to_bascid_05_result, new_input_data_name_list.select_input_column
    )

    old_acctid_to_bascid_05_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_05_result = left_merge_df(
        df, old_acctid_to_bascid_05_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_acctid_to_bascid_05_result.equals(old_acctid_to_bascid_05_result)

    ##############################
    # acctid_to_bascid (08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["08"],
    )

    new_acctid_to_bascid_08_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_08_result = left_merge_df(
        df, new_acctid_to_bascid_08_result, new_input_data_name_list.select_input_column
    )

    old_acctid_to_bascid_08_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_08_result = left_merge_df(
        df, old_acctid_to_bascid_08_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_acctid_to_bascid_08_result.equals(old_acctid_to_bascid_08_result)

    ##############################
    # acctid_to_bascid (01, 05)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["mb", "cf"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["01", "05"],
    )

    new_acctid_to_bascid_01_05_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_01_05_result = left_merge_df(
        df,
        new_acctid_to_bascid_01_05_result,
        new_input_data_name_list.select_input_column,
    )

    old_acctid_to_bascid_01_05_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_01_05_result = left_merge_df(
        df,
        old_acctid_to_bascid_01_05_result,
        old_input_data_name_list.select_input_colum,
    )

    # 検証
    assert new_acctid_to_bascid_01_05_result.equals(old_acctid_to_bascid_01_05_result)

    ##############################
    # acctid_to_bascid (01, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["mb", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["01", "08"],
    )

    new_acctid_to_bascid_01_08_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_01_08_result = left_merge_df(
        df,
        new_acctid_to_bascid_01_08_result,
        new_input_data_name_list.select_input_column,
    )

    old_acctid_to_bascid_01_08_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_01_08_result = left_merge_df(
        df,
        old_acctid_to_bascid_01_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 検証
    assert new_acctid_to_bascid_01_08_result.equals(old_acctid_to_bascid_01_08_result)

    ##############################
    # acctid_to_bascid (05, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["cf", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["05", "08"],
    )

    new_acctid_to_bascid_05_08_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_05_08_result = left_merge_df(
        df,
        new_acctid_to_bascid_05_08_result,
        new_input_data_name_list.select_input_column,
    )

    old_acctid_to_bascid_05_08_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_05_08_result = left_merge_df(
        df,
        old_acctid_to_bascid_05_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 検証
    assert new_acctid_to_bascid_05_08_result.equals(old_acctid_to_bascid_05_08_result)

    ##############################
    # acctid_to_bascid (01, 05, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["mb", "cf", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["01", "05", "08"],
    )

    new_acctid_to_bascid_01_05_08_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_01_05_08_result = left_merge_df(
        df,
        new_acctid_to_bascid_01_05_08_result,
        new_input_data_name_list.select_input_column,
    )

    old_acctid_to_bascid_01_05_08_result = throw_query(
        input_df, old_input_data_name_list
    )
    old_acctid_to_bascid_01_05_08_result = left_merge_df(
        df,
        old_acctid_to_bascid_01_05_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 検証
    assert new_acctid_to_bascid_01_05_08_result.equals(
        old_acctid_to_bascid_01_05_08_result
    )


def test_acctid_duplication_base():
    """
    ### 概要
    このテストコードの概要は、acctidを変換元にした変換かつ重複データが含まれている際に正しく機能しているかを確認するためのものです。
    具体的方法は、現在の変換方法とoldの変換方法が一致しているかと、変換前・後に件数が一致しているか確認します。

    ### テスト内容:
    - acctid_to_comnid 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - acctid_to_bascid (01) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - acctid_to_bascid (05) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - acctid_to_bascid (08) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - acctid_to_bascid (01, 05) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - acctid_to_bascid (01, 08) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - acctid_to_bascid (05, 08) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - acctid_to_bascid (01, 05, 08) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/acctid_100_duplication_20.csv"
    )
    df = df["ACCTID"].dropna()

    input_df = make_input_df(df, "ACCTID")

    ##############################
    # acctid_to_comnid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="共通IDグループ番号",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="comnid",
        select_input_column="ACCTID",
    )

    new_acctid_to_comnid_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_comnid_result = left_merge_df(
        df, new_acctid_to_comnid_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_acctid_to_comnid_result) == len(df)

    old_acctid_to_comnid_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_comnid_result = left_merge_df(
        df, old_acctid_to_comnid_result, old_input_data_name_list.select_input_colum
    )

    # 変換検証
    assert new_acctid_to_comnid_result.equals(old_acctid_to_comnid_result)

    ##############################
    # acctid_to_bascid (01)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["mb"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["01"],
    )

    new_acctid_to_bascid_01_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_01_result = left_merge_df(
        df, new_acctid_to_bascid_01_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_acctid_to_bascid_01_result) == len(df)

    old_acctid_to_bascid_01_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_01_result = left_merge_df(
        df, old_acctid_to_bascid_01_result, old_input_data_name_list.select_input_colum
    )

    # 変換検証
    assert new_acctid_to_bascid_01_result.equals(old_acctid_to_bascid_01_result)

    ##############################
    # acctid_to_bascid (05)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["cf"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["05"],
    )

    new_acctid_to_bascid_05_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_05_result = left_merge_df(
        df, new_acctid_to_bascid_05_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_acctid_to_bascid_05_result) == len(df)

    old_acctid_to_bascid_05_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_05_result = left_merge_df(
        df, old_acctid_to_bascid_05_result, old_input_data_name_list.select_input_colum
    )

    # 変換検証
    assert new_acctid_to_bascid_05_result.equals(old_acctid_to_bascid_05_result)

    ##############################
    # acctid_to_bascid (08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["08"],
    )

    new_acctid_to_bascid_08_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_08_result = left_merge_df(
        df, new_acctid_to_bascid_08_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_acctid_to_bascid_08_result) == len(df)

    old_acctid_to_bascid_08_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_08_result = left_merge_df(
        df, old_acctid_to_bascid_08_result, old_input_data_name_list.select_input_colum
    )

    # 変換検証
    assert new_acctid_to_bascid_08_result.equals(old_acctid_to_bascid_08_result)

    ##############################
    # acctid_to_bascid (01, 05)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["mb", "cf"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["01", "05"],
    )

    new_acctid_to_bascid_01_05_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_01_05_result = left_merge_df(
        df,
        new_acctid_to_bascid_01_05_result,
        new_input_data_name_list.select_input_column,
    )

    # 件数検証
    assert len(new_acctid_to_bascid_01_05_result) == len(df)

    old_acctid_to_bascid_01_05_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_01_05_result = left_merge_df(
        df,
        old_acctid_to_bascid_01_05_result,
        old_input_data_name_list.select_input_colum,
    )

    # 変換検証
    assert new_acctid_to_bascid_01_05_result.equals(old_acctid_to_bascid_01_05_result)

    ##############################
    # acctid_to_bascid (01, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["mb", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["01", "08"],
    )

    new_acctid_to_bascid_01_08_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_01_08_result = left_merge_df(
        df,
        new_acctid_to_bascid_01_08_result,
        new_input_data_name_list.select_input_column,
    )

    # 件数検証
    assert len(new_acctid_to_bascid_01_08_result) == len(df)

    old_acctid_to_bascid_01_08_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_01_08_result = left_merge_df(
        df,
        old_acctid_to_bascid_01_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 変換検証
    assert new_acctid_to_bascid_01_08_result.equals(old_acctid_to_bascid_01_08_result)

    ##############################
    # acctid_to_bascid (05, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["cf", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["05", "08"],
    )

    new_acctid_to_bascid_05_08_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_05_08_result = left_merge_df(
        df,
        new_acctid_to_bascid_05_08_result,
        new_input_data_name_list.select_input_column,
    )

    # 件数検証
    assert len(new_acctid_to_bascid_05_08_result) == len(df)

    old_acctid_to_bascid_05_08_result = throw_query(input_df, old_input_data_name_list)
    old_acctid_to_bascid_05_08_result = left_merge_df(
        df,
        old_acctid_to_bascid_05_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 変換検証
    assert new_acctid_to_bascid_05_08_result.equals(old_acctid_to_bascid_05_08_result)

    ##############################
    # acctid_to_bascid (01, 05, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="アカウント識別子",
        input_colum_name="KK_ACCTID",
        target_id_column="ACCTID",
        select_input_colum="ACCTID",
        select_id="基本契約番号",
        bascid_list=["mb", "cf", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="acctid",
        output_data_type="bascid",
        select_input_column="ACCTID",
        bascid_list=["01", "05", "08"],
    )

    new_acctid_to_bascid_01_05_08_result = execute_orm_query(new_input_data_name_list)
    new_acctid_to_bascid_01_05_08_result = left_merge_df(
        df,
        new_acctid_to_bascid_01_05_08_result,
        new_input_data_name_list.select_input_column,
    )

    # 件数検証
    assert len(new_acctid_to_bascid_01_05_08_result) == len(df)

    old_acctid_to_bascid_01_05_08_result = throw_query(
        input_df, old_input_data_name_list
    )
    old_acctid_to_bascid_01_05_08_result = left_merge_df(
        df,
        old_acctid_to_bascid_01_05_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 変換検証
    assert new_acctid_to_bascid_01_05_08_result.equals(
        old_acctid_to_bascid_01_05_08_result
    )


def test_comnid_base():
    """
    ### 概要
    このテストコードの概要は、comnidを変換元にした変換が正しく機能しているかを確認するためのものです。
    具体的方法は、現在の変換方法とoldの変換方法が一致しているかを検証します。

    ### テスト内容:
    - comnid_to_acctid 変換が正しく機能していること (旧変換方法と一致)
    - comnid_to_bascid (01) 変換が正しく機能していること (旧変換方法と一致)
    - comnid_to_bascid (05) 変換が正しく機能していること (旧変換方法と一致)
    - comnid_to_bascid (08) 変換が正しく機能していること (旧変換方法と一致)
    - comnid_to_bascid (01, 05) 変換が正しく機能していること (旧変換方法と一致)
    - comnid_to_bascid (01, 08) 変換が正しく機能していること (旧変換方法と一致)
    - comnid_to_bascid (05, 08) 変換が正しく機能していること (旧変換方法と一致)
    - comnid_to_bascid (01, 05, 08) 変換が正しく機能していること (旧変換方法と一致)
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/comnid_100.csv", dtype=str
    )
    df = df["COMNID"].dropna()

    input_df = make_input_df(df, "COMNID")

    ##############################
    # comnid_to_acctid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="アカウント識別子",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="acctid",
        select_input_column="COMNID",
    )

    new_comnid_to_acctid_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_acctid_result = left_merge_df(
        df, new_comnid_to_acctid_result, new_input_data_name_list.select_input_column
    )

    old_comnid_to_acctid_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_acctid_result = left_merge_df(
        df, old_comnid_to_acctid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_comnid_to_acctid_result.equals(old_comnid_to_acctid_result)

    ##############################
    # comnid_to_bascid (01)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["mb"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["01"],
    )

    new_comnid_to_bascid_01_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_01_result = left_merge_df(
        df, new_comnid_to_bascid_01_result, new_input_data_name_list.select_input_column
    )

    old_comnid_to_bascid_01_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_01_result = left_merge_df(
        df, old_comnid_to_bascid_01_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_comnid_to_bascid_01_result.equals(old_comnid_to_bascid_01_result)

    ##############################
    # comnid_to_bascid (05)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["cf"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["05"],
    )

    new_comnid_to_bascid_05_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_05_result = left_merge_df(
        df, new_comnid_to_bascid_05_result, new_input_data_name_list.select_input_column
    )

    old_comnid_to_bascid_05_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_05_result = left_merge_df(
        df, old_comnid_to_bascid_05_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_comnid_to_bascid_05_result.equals(old_comnid_to_bascid_05_result)

    ##############################
    # comnid_to_bascid (08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["08"],
    )

    new_comnid_to_bascid_08_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_08_result = left_merge_df(
        df, new_comnid_to_bascid_08_result, new_input_data_name_list.select_input_column
    )

    old_comnid_to_bascid_08_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_08_result = left_merge_df(
        df, old_comnid_to_bascid_08_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_comnid_to_bascid_08_result.equals(old_comnid_to_bascid_08_result)

    ##############################
    # comnid_to_bascid (01, 05)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["mb", "cf"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["01", "05"],
    )

    new_comnid_to_bascid_01_05_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_01_05_result = left_merge_df(
        df,
        new_comnid_to_bascid_01_05_result,
        new_input_data_name_list.select_input_column,
    )

    old_comnid_to_bascid_01_05_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_01_05_result = left_merge_df(
        df,
        old_comnid_to_bascid_01_05_result,
        old_input_data_name_list.select_input_colum,
    )

    # 検証
    assert new_comnid_to_bascid_01_05_result.equals(old_comnid_to_bascid_01_05_result)

    ##############################
    # comnid_to_bascid (01, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["mb", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["01", "08"],
    )

    new_comnid_to_bascid_01_08_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_01_08_result = left_merge_df(
        df,
        new_comnid_to_bascid_01_08_result,
        new_input_data_name_list.select_input_column,
    )

    old_comnid_to_bascid_01_08_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_01_08_result = left_merge_df(
        df,
        old_comnid_to_bascid_01_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 検証
    assert new_comnid_to_bascid_01_08_result.equals(old_comnid_to_bascid_01_08_result)

    ##############################
    # comnid_to_bascid (05, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["cf", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["05", "08"],
    )

    new_comnid_to_bascid_05_08_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_05_08_result = left_merge_df(
        df,
        new_comnid_to_bascid_05_08_result,
        new_input_data_name_list.select_input_column,
    )

    old_comnid_to_bascid_05_08_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_05_08_result = left_merge_df(
        df,
        old_comnid_to_bascid_05_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 検証
    assert new_comnid_to_bascid_05_08_result.equals(old_comnid_to_bascid_05_08_result)

    ##############################
    # comnid_to_bascid (01, 05, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["mb", "cf", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["01", "05", "08"],
    )

    new_comnid_to_bascid_01_05_08_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_01_05_08_result = left_merge_df(
        df,
        new_comnid_to_bascid_01_05_08_result,
        new_input_data_name_list.select_input_column,
    )

    old_comnid_to_bascid_01_05_08_result = throw_query(
        input_df, old_input_data_name_list
    )
    old_comnid_to_bascid_01_05_08_result = left_merge_df(
        df,
        old_comnid_to_bascid_01_05_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 検証
    assert new_comnid_to_bascid_01_05_08_result.equals(
        old_comnid_to_bascid_01_05_08_result
    )


def test_comnid_duplication_base():
    """
    ### 概要
    このテストコードの概要は、comnidを変換元にした変換かつ重複データが含まれている際に正しく機能しているかを確認するためのものです。
    具体的方法は、現在の変換方法とoldの変換方法が一致しているかと、変換前・後に件数が一致しているか確認します。

    ### テスト内容:
    - comnid_to_acctid 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - comnid_to_bascid (01) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - comnid_to_bascid (05) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - comnid_to_bascid (08) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - comnid_to_bascid (01, 05) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - comnid_to_bascid (01, 08) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - comnid_to_bascid (05, 08) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - cpmnid_to_bascid (01, 05, 08) 変換が正しく機能していること (旧変換方法と一致+件数一致)
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/comnid_100_duplication_20.csv",
        dtype=str,
    )
    df = df["COMNID"].dropna()
    base_df = df.copy()

    input_df = make_input_df(df, "COMNID")

    ##############################
    # comnid_to_acctid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="アカウント識別子",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="acctid",
        select_input_column="COMNID",
    )

    new_comnid_to_acctid_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_acctid_result = left_merge_df(
        df, new_comnid_to_acctid_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_comnid_to_acctid_result) == len(base_df)

    old_comnid_to_acctid_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_acctid_result = left_merge_df(
        df, old_comnid_to_acctid_result, old_input_data_name_list.select_input_colum
    )

    # 変換検証
    assert new_comnid_to_acctid_result.equals(old_comnid_to_acctid_result)

    ##############################
    # comnid_to_bascid (01)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["mb"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["01"],
    )

    new_comnid_to_bascid_01_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_01_result = left_merge_df(
        df, new_comnid_to_bascid_01_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_comnid_to_bascid_01_result) == len(df)

    old_comnid_to_bascid_01_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_01_result = left_merge_df(
        df, old_comnid_to_bascid_01_result, old_input_data_name_list.select_input_colum
    )

    # 変換検証
    assert new_comnid_to_bascid_01_result.equals(old_comnid_to_bascid_01_result)

    ##############################
    # comnid_to_bascid (05)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["cf"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["05"],
    )

    new_comnid_to_bascid_05_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_05_result = left_merge_df(
        df, new_comnid_to_bascid_05_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_comnid_to_bascid_05_result) == len(df)

    old_comnid_to_bascid_05_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_05_result = left_merge_df(
        df, old_comnid_to_bascid_05_result, old_input_data_name_list.select_input_colum
    )

    # 変換検証
    assert new_comnid_to_bascid_05_result.equals(old_comnid_to_bascid_05_result)

    ##############################
    # comnid_to_bascid (08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["08"],
    )

    new_comnid_to_bascid_08_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_08_result = left_merge_df(
        df, new_comnid_to_bascid_08_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_comnid_to_bascid_08_result) == len(df)

    old_comnid_to_bascid_08_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_08_result = left_merge_df(
        df, old_comnid_to_bascid_08_result, old_input_data_name_list.select_input_colum
    )

    # 変換検証
    assert new_comnid_to_bascid_08_result.equals(old_comnid_to_bascid_08_result)

    ##############################
    # comnid_to_bascid (01, 05)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["mb", "cf"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["01", "05"],
    )

    new_comnid_to_bascid_01_05_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_01_05_result = left_merge_df(
        df,
        new_comnid_to_bascid_01_05_result,
        new_input_data_name_list.select_input_column,
    )

    # 件数検証
    assert len(new_comnid_to_bascid_01_05_result) == len(df)

    old_comnid_to_bascid_01_05_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_01_05_result = left_merge_df(
        df,
        old_comnid_to_bascid_01_05_result,
        old_input_data_name_list.select_input_colum,
    )

    # 変換検証
    assert new_comnid_to_bascid_01_05_result.equals(old_comnid_to_bascid_01_05_result)

    ##############################
    # comnid_to_bascid (01, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["mb", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["01", "08"],
    )

    new_comnid_to_bascid_01_08_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_01_08_result = left_merge_df(
        df,
        new_comnid_to_bascid_01_08_result,
        new_input_data_name_list.select_input_column,
    )

    # 件数検証
    assert len(new_comnid_to_bascid_01_08_result) == len(df)

    old_comnid_to_bascid_01_08_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_01_08_result = left_merge_df(
        df,
        old_comnid_to_bascid_01_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 変換検証
    assert new_comnid_to_bascid_01_08_result.equals(old_comnid_to_bascid_01_08_result)

    ##############################
    # comnid_to_bascid (05, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["cf", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["05", "08"],
    )

    new_comnid_to_bascid_05_08_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_05_08_result = left_merge_df(
        df,
        new_comnid_to_bascid_05_08_result,
        new_input_data_name_list.select_input_column,
    )

    # 件数検証
    assert len(new_comnid_to_bascid_05_08_result) == len(df)

    old_comnid_to_bascid_05_08_result = throw_query(input_df, old_input_data_name_list)
    old_comnid_to_bascid_05_08_result = left_merge_df(
        df,
        old_comnid_to_bascid_05_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 変換検証
    assert new_comnid_to_bascid_05_08_result.equals(old_comnid_to_bascid_05_08_result)

    ##############################
    # comnid_to_bascid (01, 05, 08)
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="共通IDグループ番号",
        input_colum_name="COMNID",
        target_id_column="COMNID",
        select_input_colum="COMNID",
        select_id="基本契約番号",
        bascid_list=["mb", "cf", "ki"],
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="comnid",
        output_data_type="bascid",
        select_input_column="COMNID",
        bascid_list=["01", "05", "08"],
    )

    new_comnid_to_bascid_01_05_08_result = execute_orm_query(new_input_data_name_list)
    new_comnid_to_bascid_01_05_08_result = left_merge_df(
        df,
        new_comnid_to_bascid_01_05_08_result,
        new_input_data_name_list.select_input_column,
    )

    # 件数検証
    assert len(new_comnid_to_bascid_01_05_08_result) == len(df)

    old_comnid_to_bascid_01_05_08_result = throw_query(
        input_df, old_input_data_name_list
    )
    old_comnid_to_bascid_01_05_08_result = left_merge_df(
        df,
        old_comnid_to_bascid_01_05_08_result,
        old_input_data_name_list.select_input_colum,
    )

    # 変換検証
    assert new_comnid_to_bascid_01_05_08_result.equals(
        old_comnid_to_bascid_01_05_08_result
    )


def test_bascid_01_base():
    """
    ### 概要
    このテストコードの概要は、bascid(01)を変換元にした変換が正しく機能しているかを確認するためのものです。
    具体的方法は、現在の変換方法とoldの変換方法が一致しているかを検証します。

    ### テスト内容:
    - bascid_01_to_acctid 変換が正しく機能していること (旧変換方法と一致)
    - bascid_01_to_comnid 変換が正しく機能していること (旧変換方法と一致)
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/bascid_01_100.csv",
        dtype=str,
    )
    df = df["BASCID"].dropna()

    input_df = make_input_df(df, "BASCID")

    ##############################
    # bascid_01_to_acctid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(01_携帯事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="アカウント識別子",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid01",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_01_to_acctid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_01_to_acctid_result = left_merge_df(
        df, new_bascid_01_to_acctid_result, new_input_data_name_list.select_input_column
    )

    old_bascid_01_to_acctid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_01_to_acctid_result = left_merge_df(
        df, old_bascid_01_to_acctid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_bascid_01_to_acctid_result.equals(old_bascid_01_to_acctid_result)

    ##############################
    # bascid_01_to_comnid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(01_携帯事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="共通IDグループ番号",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid01",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_01_to_comnid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_01_to_comnid_result = left_merge_df(
        df, new_bascid_01_to_comnid_result, new_input_data_name_list.select_input_column
    )

    old_bascid_01_to_comnid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_01_to_comnid_result = left_merge_df(
        df, old_bascid_01_to_comnid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_bascid_01_to_comnid_result.equals(old_bascid_01_to_comnid_result)


def test_bascid_05_duplication_base():
    """
    ### 概要
    このテストコードの概要は、bascid(01)を変換元にした変換かつ重複データが含まれている際に正しく機能しているかを確認するためのものです。
    具体的方法は、現在の変換方法とoldの変換方法が一致しているかと、変換前・後に件数が一致しているか確認します。

    ### テスト内容:
    - bascid_01_to_acctid 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - bascid_01_to_comnid 変換が正しく機能していること (旧変換方法と一致+件数一致)
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/bascid_01_100_duplication_20.csv",
        dtype=str,
    )
    df = df["BASCID"].dropna()

    input_df = make_input_df(df, "BASCID")

    ##############################
    # bascid_01_to_acctid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(01_携帯事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="アカウント識別子",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid01",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_01_to_acctid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_01_to_acctid_result = left_merge_df(
        df, new_bascid_01_to_acctid_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_bascid_01_to_acctid_result) == len(df)

    old_bascid_01_to_acctid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_01_to_acctid_result = left_merge_df(
        df, old_bascid_01_to_acctid_result, old_input_data_name_list.select_input_colum
    )

    # 変換検証
    assert new_bascid_01_to_acctid_result.equals(old_bascid_01_to_acctid_result)

    ##############################
    # bascid_01_to_comnid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(01_携帯事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="共通IDグループ番号",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid01",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_01_to_comnid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_01_to_comnid_result = left_merge_df(
        df, new_bascid_01_to_comnid_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_bascid_01_to_comnid_result) == len(df)

    old_bascid_01_to_comnid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_01_to_comnid_result = left_merge_df(
        df, old_bascid_01_to_comnid_result, old_input_data_name_list.select_input_colum
    )

    # 変換検証
    assert new_bascid_01_to_comnid_result.equals(old_bascid_01_to_comnid_result)


def test_bascid_05_base():
    """
    ### 概要
    このテストコードの概要は、bascid(05)を変換元にした変換が正しく機能しているかを確認するためのものです。
    具体的方法は、現在の変換方法とoldの変換方法が一致しているかを検証します。

    ### テスト内容:
    - bascid_05_to_acctid 変換が正しく機能していること (正解データと一致)
    - bascid_05_to_comnid 変換が正しく機能していること (旧変換方法と一致)
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/bascid_05_100.csv",
        dtype=str,
    )
    df = df["BASCID"].dropna()

    input_df = make_input_df(df, "BASCID")

    ##############################
    # bascid_05_to_acctid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(05_CF事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="アカウント識別子",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid05",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_05_to_acctid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_05_to_acctid_result = left_merge_df(
        df, new_bascid_05_to_acctid_result, new_input_data_name_list.select_input_column
    )

    old_bascid_05_to_acctid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_05_to_acctid_result = left_merge_df(
        df, old_bascid_05_to_acctid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_bascid_05_to_acctid_result.equals(old_bascid_05_to_acctid_result)

    ##############################
    # bascid_05_to_comnid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(05_CF事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="共通IDグループ番号",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid05",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_05_to_comnid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_05_to_comnid_result = left_merge_df(
        df, new_bascid_05_to_comnid_result, new_input_data_name_list.select_input_column
    )

    old_bascid_05_to_comnid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_05_to_comnid_result = left_merge_df(
        df, old_bascid_05_to_comnid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_bascid_05_to_comnid_result.equals(old_bascid_05_to_comnid_result)


def test_bascid_05_duplication_base():
    """
    ### 概要
    このテストコードの概要は、bascid(05)を変換元にした変換かつ重複データが含まれている際に正しく機能しているかを確認するためのものです。
    具体的方法は、現在の変換方法とoldの変換方法が一致しているかと、変換前・後に件数が一致しているか確認します。

    ### テスト内容:
    - bascid_05_to_acctid 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - bascid_05_to_comnid 変換が正しく機能していること (旧変換方法と一致+件数一致)
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/bascid_05_100_duplication_20.csv",
        dtype=str,
    )
    df = df["BASCID"].dropna()

    input_df = make_input_df(df, "BASCID")

    ##############################
    # bascid_05_to_acctid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(05_CF事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="アカウント識別子",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid05",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_05_to_acctid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_05_to_acctid_result = left_merge_df(
        df, new_bascid_05_to_acctid_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_bascid_05_to_acctid_result) == len(df)

    old_bascid_05_to_acctid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_05_to_acctid_result = left_merge_df(
        df, old_bascid_05_to_acctid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_bascid_05_to_acctid_result.equals(old_bascid_05_to_acctid_result)

    ##############################
    # bascid_05_to_comnid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(05_CF事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="共通IDグループ番号",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid05",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_05_to_comnid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_05_to_comnid_result = left_merge_df(
        df, new_bascid_05_to_comnid_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_bascid_05_to_comnid_result) == len(df)

    old_bascid_05_to_comnid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_05_to_comnid_result = left_merge_df(
        df, old_bascid_05_to_comnid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_bascid_05_to_comnid_result.equals(old_bascid_05_to_comnid_result)


def test_bascid_08_base():
    """
    ### 概要
    このテストコードの概要は、bascid(08)を変換元にした変換が正しく機能しているかを確認するためのものです。
    具体的方法は、現在の変換方法とoldの変換方法が一致しているかを検証します。

    ### テスト内容:
    - bascid_08_to_acctid 変換が正しく機能していること (旧変換方法と一致)
    - bascid_08_to_comnid 変換が正しく機能していること (旧変換方法と一致)
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/bascid_08_100.csv",
        dtype=str,
    )
    df = df["BASCID"].dropna()

    input_df = make_input_df(df, "BASCID")

    ##############################
    # bascid_08_to_acctid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(08_会員事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="アカウント識別子",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid08",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_08_to_acctid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_08_to_acctid_result = left_merge_df(
        df, new_bascid_08_to_acctid_result, new_input_data_name_list.select_input_column
    )

    old_bascid_08_to_acctid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_08_to_acctid_result = left_merge_df(
        df, old_bascid_08_to_acctid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_bascid_08_to_acctid_result.equals(old_bascid_08_to_acctid_result)

    ##############################
    # bascid_08_to_comnid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(08_会員事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="共通IDグループ番号",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid08",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_08_to_comnid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_08_to_comnid_result = left_merge_df(
        df, new_bascid_08_to_comnid_result, new_input_data_name_list.select_input_column
    )

    old_bascid_08_to_comnid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_08_to_comnid_result = left_merge_df(
        df, old_bascid_08_to_comnid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_bascid_08_to_comnid_result.equals(old_bascid_08_to_comnid_result)


def test_bascid_08_duplication_base():
    """
    ### 概要
    このテストコードの概要は、bascid(08)を変換元にした変換かつ重複データが含まれている際に正しく機能しているかを確認するためのものです。
    具体的方法は、現在の変換方法とoldの変換方法が一致しているかと、変換前・後に件数が一致しているか確認します。

    ### テスト内容:
    - bascid_08_to_acctid 変換が正しく機能していること (旧変換方法と一致+件数一致)
    - bascid_08_to_comnid 変換が正しく機能していること (旧変換方法と一致+件数一致)
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/bascid_08_100_duplication_20.csv",
        dtype=str,
    )
    df = df["BASCID"].dropna()

    input_df = make_input_df(df, "BASCID")

    ##############################
    # bascid_08_to_acctid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(08_会員事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="アカウント識別子",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid08",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_08_to_acctid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_08_to_acctid_result = left_merge_df(
        df, new_bascid_08_to_acctid_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_bascid_08_to_acctid_result) == len(df)

    old_bascid_08_to_acctid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_08_to_acctid_result = left_merge_df(
        df, old_bascid_08_to_acctid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_bascid_08_to_acctid_result.equals(old_bascid_08_to_acctid_result)

    ##############################
    # bascid_08_to_comnid
    ##############################

    old_input_data_name_list = old_input_datas(
        origin_source="基本契約番号(08_会員事業)",
        input_colum_name="BASCID",
        target_id_column="BASCID",
        select_input_colum="BASCID",
        select_id="共通IDグループ番号",
    )

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid08",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_08_to_comnid_result = execute_orm_query(new_input_data_name_list)
    new_bascid_08_to_comnid_result = left_merge_df(
        df, new_bascid_08_to_comnid_result, new_input_data_name_list.select_input_column
    )

    # 件数検証
    assert len(new_bascid_08_to_comnid_result) == len(df)

    old_bascid_08_to_comnid_result = throw_query(input_df, old_input_data_name_list)
    old_bascid_08_to_comnid_result = left_merge_df(
        df, old_bascid_08_to_comnid_result, old_input_data_name_list.select_input_colum
    )

    # 検証
    assert new_bascid_08_to_comnid_result.equals(old_bascid_08_to_comnid_result)


def test_bascid_01_set_another():
    """
    ### 概要
    このテストコードの概要は、bascid(01)を変換元にして、その他の基本契約番号を選択した際に変換されないことを確認するためのものです。
    具体的方法は、01をinputにいれて、05, 08を変換元に指定し、アカウント識別子、共通IDグループ番号が変換されないことを検証します。

    ### テスト内容:
    - bascid_01(05)_to_acctid 変換の変換結果がNullであること
    - bascid_01(08)_to_acctid 変換の変換結果がNullであること
    - bascid_01(05)_to_comnid 変換の変換結果がNullであること
    - bascid_01(08)_to_comnid 変換の変換結果がNullであること
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/bascid_01_100.csv",
        dtype=str,
    )
    df = df["BASCID"].dropna()

    input_df = make_input_df(df, "BASCID")

    ##############################
    # bascid_01(05)_to_acctid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid05",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_01_to_acctid_result = execute_orm_query(new_input_data_name_list)
    check_acctid = new_bascid_01_to_acctid_result["アカウント識別子"]

    # check_acctidの中身が全てNoneであることを検証
    assert check_acctid.isnull().all()

    ##############################
    # bascid_01(08)_to_acctid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid08",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_01_to_acctid_result = execute_orm_query(new_input_data_name_list)
    check_acctid = new_bascid_01_to_acctid_result["アカウント識別子"]

    # check_acctidの中身が全てNoneであることを検証
    assert check_acctid.isnull().all()

    ##############################
    # bascid_01(05)_to_comnid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid05",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_01_to_comnid_result = execute_orm_query(new_input_data_name_list)
    check_comnid = new_bascid_01_to_comnid_result["共通IDグループ番号"]

    # check_comnidの中身が全てNoneであることを検証
    assert check_comnid.isnull().all()

    ##############################
    # bascid_01(08)_to_comnid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid08",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_01_to_comnid_result = execute_orm_query(new_input_data_name_list)
    check_comnid = new_bascid_01_to_comnid_result["共通IDグループ番号"]

    # check_comnidの中身が全てNoneであることを検証
    assert check_comnid.isnull().all()


def test_bascid_05_set_another():
    """
    ### 概要
    このテストコードの概要は、bascid(05)を変換元にして、その他の基本契約番号を選択した際に変換されないことを確認するためのものです。
    具体的方法は、05をinputにいれて、01, 08を変換元に指定し、アカウント識別子、共通IDグループ番号が変換されないことを検証します。

    ### テスト内容:
    - bascid_05(01)_to_acctid 変換の変換結果がNullであること
    - bascid_05(08)_to_acctid 変換の変換結果がNullであること
    - bascid_05(01)_to_comnid 変換の変換結果がNullであること
    - bascid_05(08)_to_comnid 変換の変換結果がNullであること
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/bascid_05_100.csv",
        dtype=str,
    )
    df = df["BASCID"].dropna()

    input_df = make_input_df(df, "BASCID")

    ##############################
    # bascid_05(01)_to_acctid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid01",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_05_to_acctid_result = execute_orm_query(new_input_data_name_list)

    check_acctid = new_bascid_05_to_acctid_result["アカウント識別子"]

    # check_acctidの中身が全てNoneであることを検証
    assert check_acctid.isnull().all()

    ##############################
    # bascid_05(08)_to_acctid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid08",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_05_to_acctid_result = execute_orm_query(new_input_data_name_list)

    check_acctid = new_bascid_05_to_acctid_result["アカウント識別子"]

    # check_acctidの中身が全てNoneであることを検証
    assert check_acctid.isnull().all()

    ##############################
    # bascid_05(01)_to_comnid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid01",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_05_to_comnid_result = execute_orm_query(new_input_data_name_list)

    check_comnid = new_bascid_05_to_comnid_result["共通IDグループ番号"]

    # check_comnidの中身が全てNoneであることを検証
    assert check_comnid.isnull().all()

    ##############################
    # bascid_05(08)_to_comnid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid08",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_05_to_comnid_result = execute_orm_query(new_input_data_name_list)

    check_comnid = new_bascid_05_to_comnid_result["共通IDグループ番号"]

    # check_comnidの中身が全てNoneであることを検証
    assert check_comnid.isnull().all()


def test_bascid_08_set_another():
    """
    ### 概要
    このテストコードの概要は、bascid(08)を変換元にして、その他の基本契約番号を選択した際に変換されないことを確認するためのものです。
    具体的方法は、08をinputにいれて、01, 05を変換元に指定し、アカウント識別子、共通IDグループ番号が変換されないことを検証します。

    ### テスト内容:
    - bascid_08(01)_to_acctid 変換の変換結果がNullであること
    - bascid_08(05)_to_acctid 変換の変換結果がNullであること
    - bascid_08(01)_to_comnid 変換の変換結果がNullであること
    - bascid_08(05)_to_comnid 変換の変換結果がNullであること
    """

    # テストデータ取得
    df = pd.read_csv(
        "/home/user/pochi-id-converter-repository/tests/data/bascid_08_100.csv",
        dtype=str,
    )
    df = df["BASCID"].dropna()

    input_df = make_input_df(df, "BASCID")

    ##############################
    # bascid_08(01)_to_acctid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid01",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_08_to_acctid_result = execute_orm_query(new_input_data_name_list)

    check_acctid = new_bascid_08_to_acctid_result["アカウント識別子"]

    # check_acctidの中身が全てNoneであることを検証
    assert check_acctid.isnull().all()

    ##############################
    # bascid_08(05)_to_acctid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid05",
        output_data_type="acctid",
        select_input_column="BASCID",
    )

    new_bascid_08_to_acctid_result = execute_orm_query(new_input_data_name_list)

    check_acctid = new_bascid_08_to_acctid_result["アカウント識別子"]

    # check_acctidの中身が全てNoneであることを検証
    assert check_acctid.isnull().all()

    ##############################
    # bascid_08(01)_to_comnid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid01",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_08_to_comnid_result = execute_orm_query(new_input_data_name_list)

    check_comnid = new_bascid_08_to_comnid_result["共通IDグループ番号"]

    # check_comnidの中身が全てNoneであることを検証
    assert check_comnid.isnull().all()

    ##############################
    # bascid_08(05)_to_comnid
    ##############################

    new_input_data_name_list = input_datas(
        input_df=input_df,
        input_data_type="bascid05",
        output_data_type="comnid",
        select_input_column="BASCID",
    )

    new_bascid_08_to_comnid_result = execute_orm_query(new_input_data_name_list)

    check_comnid = new_bascid_08_to_comnid_result["共通IDグループ番号"]

    # check_comnidの中身が全てNoneであることを検証
    assert check_comnid.isnull().all()
