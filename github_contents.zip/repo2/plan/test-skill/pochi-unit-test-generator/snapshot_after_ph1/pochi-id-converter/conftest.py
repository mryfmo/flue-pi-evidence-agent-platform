"""
Test suite の共通フィクスチャ・設定を定義するモジュール

Streamlit依存のモック化、Snowflake等の外部依存のモック化、
およびテストで使用するフィクスチャを集中管理する。
"""
import sys
import os
from unittest.mock import MagicMock, patch
import pytest

# ============================================================================
# sys.modules のモック設定（Streamlit、Snowflake等の外部ライブラリ）
# ============================================================================

# Streamlitランタイムなしでインポート可能にするためのモック対象リスト
# 常にモック対象（mock_always）: pochilib, streamlit
# 本物を使用（mock_never）: pandas, numpy, sqlalchemy, openpyxl, xlrd
_MOCK_MODULES = [
    # Streamlit本体とランタイムモジュール（AppTest外での実行に必須）
    "streamlit",
    "streamlit.runtime",
    "streamlit.runtime.scriptrunner",
    "streamlit.runtime.scriptrunner.script_runner",
    "streamlit.runtime.state",
    "streamlit.runtime.state.session_state",
    "streamlit.components",
    "streamlit.components.v1",
    "streamlit.delta_generator",
    "streamlit.testing",
    "streamlit.testing.v1",

    # Pochilib モジュール群
    "pochilib",
    "pochilib.snowflake",
    "pochilib.snowflake._winter_stream_flow",
    "pochilib.llm",
    "pochilib.user_interface_support",

    # その他の外部ライブラリ（必要に応じて追加）
    "folium",
    "folium.elements",
    "folium.plugins",
]

# モック対象モジュールを事前登録
for module_name in _MOCK_MODULES:
    if module_name not in sys.modules:
        sys.modules[module_name] = MagicMock()

# ============================================================================
# sys.path にアプリケーションディレクトリを追加
# ============================================================================

app_path = os.path.join(os.path.dirname(__file__), "..", "app")
if app_path not in sys.path:
    sys.path.insert(0, app_path)

# ============================================================================
# Streamlit デコレータのパススルー設定
# ============================================================================
# @st.cache_data/@st.cache_resource を使用した関数でもインポートが成功するよう
# デコレータを「元の関数をそのまま返す」フィクスチャに置き換える

def _passthrough_decorator(func=None, **kwargs):
    """
    Streamlitデコレータのパススルー実装

    @st.cache_data や @st.cache_resource に置き換えられ、
    デコレータ自体は機能させずに元の関数をそのまま返す。
    （Streamlitセッションコンテキストなしでテスト可能にするため）
    """
    if func is not None:
        return func
    return lambda f: f

# streamlit モジュックスをセットアップ
_st = sys.modules["streamlit"]
_st.cache_data = _passthrough_decorator
_st.cache_resource = _passthrough_decorator
_st.write = MagicMock()
_st.title = MagicMock()
_st.header = MagicMock()
_st.subheader = MagicMock()
_st.button = MagicMock(return_value=False)
_st.text_input = MagicMock(return_value="")
_st.selectbox = MagicMock(return_value=None)
_st.multiselect = MagicMock(return_value=[])
_st.session_state = MagicMock()

# ============================================================================
# モジュールのプリロード（インポートパス解決）
# ============================================================================
# テスト実行前にアプリモジュールをインポートして、モック対象との
# 名前解決を確保する
_PRELOAD_MODULES = [
    "main",
    "app_pages.routing",
    "app_pages.01_IDを変換する",
    "app_pages.02_使い方がわからないときは",
    "app_pages.03_このアプリについて",
    "app_pages.04_データソースについて",
    "lib.definition",
    "lib.dogharness",
    "lib.information",
    "lib.old_query_collect",
    "lib.queries.get_statement",
    "lib.queries.sa_models.base",
    "lib.queries.sa_models.temporary_table",
    "lib.queries.sa_models.vw_adm_dncl_comnid_integration",
    "lib.queries.sa_models.vw_dmc_dncl_line_friend_list",
    "lib.queries.sa_models.vw_dmc_dncl_line_user_id_coordination_datas",
    "lib.utility._error_message",
    "lib.utility._get_pstorage",
    "lib.utility._set_page_config",
    "lib.utility._utils",
    "lib.view_input_data",
    "lib.view_output_data",
]

for module_name in _PRELOAD_MODULES:
    try:
        __import__(module_name)
    except (ImportError, AttributeError, ModuleNotFoundError, FileNotFoundError, IsADirectoryError):
        # インポート失敗は無視（テスト時のみ必要）
        # ※ Streamlitページモジュールはリソースファイル参照のため失敗することがある
        pass

# ============================================================================
# テストフィクスチャ
# ============================================================================

@pytest.fixture
def mock_snowflake_session():
    """
    Snowflakeセッションのモック

    Snowflake接続が必要なテストで使用。
    """
    mock_session = MagicMock()
    mock_session.bind = MagicMock()
    mock_session.query = MagicMock(return_value=MagicMock())
    return mock_session


@pytest.fixture
def mock_streamlit_session_state():
    """
    Streamlit session_state のモック

    st.session_state を使用するテストで使用。
    """
    mock_state = {}
    _st = sys.modules["streamlit"]
    _st.session_state = mock_state
    return mock_state


@pytest.fixture
def app_path_fixture():
    """
    アプリケーションディレクトリパス

    テストからアプリコードの相対参照が必要な場合に使用。
    """
    return os.path.join(os.path.dirname(__file__), "..", "app")
