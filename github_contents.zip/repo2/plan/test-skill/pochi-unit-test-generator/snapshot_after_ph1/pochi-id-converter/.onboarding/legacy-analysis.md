# レガシーコード解析レポート：pochi-id-converter

## 1. 解析概要

**対象アプリケーション**: Pochi ID変換器（pochi-id-converter-repository）  
**解析日時**: 2026-05-01  
**エントリポイント**: `app/main.py`  
**フレームワーク**: Streamlit  
**言語**: Python  

---

## 2. アプリケーション構成

### 2.1 ディレクトリ構造

```
app/
├── main.py                           # エントリポイント
├── app_pages/                        # Streamlit マルチページアプリケーション
│   ├── routing.py                    # ページルーティング定義
│   ├── 01_IDを変換する.py            # メイン機能：ID変換ページ
│   ├── 02_使い方がわからないときは.py # 使い方ガイド
│   ├── 03_このアプリについて.py      # アプリ情報
│   └── 04_データソースについて.py    # データソース仕様
└── lib/                              # ビジネスロジック層
    ├── definition.py                 # 定義・マッピング
    ├── view_input_data.py            # 入力UI・ロジック
    ├── view_output_data.py           # 出力UI・ロジック
    ├── information.py                # UI情報表示
    ├── dogharness.py                 # データ品質監視
    ├── old_query_collect.py          # レガシークエリ（未使用）
    ├── utility/                      # ユーティリティ
    │   ├── _utils.py                 # バリデーション、変換
    │   ├── _error_message.py         # エラーメッセージ
    │   ├── _set_page_config.py       # ページ設定
    │   └── _get_pstorage.py          # GCS接続
    └── queries/                      # SQLAlchemy ORM層
        ├── get_statement.py          # クエリ生成・実行
        └── sa_models/                # SQLAlchemy定義
            ├── base.py
            ├── temporary_table.py     # アップロードデータ一時テーブル
            ├── vw_adm_dncl_comnid_integration.py    # 共通ID統合VIEW
            ├── vw_dmc_dncl_line_user_id_coordination_datas.py
            └── vw_dmc_dncl_line_friend_list.py
```

### 2.2 モジュール統計

- **総モジュール数**: 23
- **クラス定義**: 7個
  - `input_datas` - 入力データ管理クラス
  - `Base` - SQLAlchemy ベースクラス
  - `UploadTargetList` - 一時テーブルモデル
  - `ComnidIntegration` - 共通ID統合VIEW
  - `LineFriendList` - LINE友だちリスト
  - `LineUserIdCoordinattionData` - LINE ID連携
  - `ValidationError` - カスタム例外
  - `ErrorMessage` - 静的エラーメッセージクラス

- **関数総数**: 58
- **Streamlit キャッシング**: 1関数（`add_header` に `@st.cache_data`）

---

## 3. 主要機能フロー

### 3.1 ユースケース：ID変換

```
1. ファイルアップロード
   └─> view_id_input_widgets()
       └─> pstorage_user.signed_url_file_uploader()

2. 入力データ検証・設定
   └─> view_input_data(gcs_path, ...)
       ├─> ファイル読込（CSV/XLSX）
       ├─> エンコーディング自動判定
       ├─> add_header() [キャッシュ]
       └─> check_input_data() : ID形式バリデーション

3. 出力データ選択・変換実行
   └─> view_output_data(gcs_path, input_dict)
       ├─> execute_orm_query(input_data_instance)
       │   └─> _generate_sql_extract() : SQLAlchemy CTEを生成
       ├─> ID変換ロジック（複数パターン対応）
       └─> df_to_xlsx() : ファイル出力

4. ダウンロード
   └─> pstorage_user.upload_from_string()
       └─> pstorage_user.generate_download_url()
```

### 3.2 対応ID変換パターン

| 変換元 | 変換先 | 備考 |
|------|------|------|
| アカウント識別子 | 共通IDグループ番号 | 直接変換 |
| 共通IDグループ番号 | アカウント識別子 | 直接変換 |
| 基本契約番号（01, 05, 08） | アカウント識別子 | 事業区分別対応 |
| 基本契約番号（01, 05, 08） | 共通IDグループ番号 | 事業区分別対応 |
| アカウント識別子 | 基本契約番号（複数事業） | 複数事業選択可能 |
| 共通IDグループ番号 | 基本契約番号（複数事業） | 複数事業選択可能 |
| アカウント識別子 | LINE User ID | LINE連携テーブル経由 |
| LINE User ID | アカウント識別子 | LINE連携テーブル経由 |
| LINE User ID | 他ID種別 | 中間変換（アカウント識別子経由） |
| 他ID種別 | LINE User ID | 中間変換（アカウント識別子経由） |

---

## 4. 外部依存関係

### 4.1 PochiLib

- `pochilib.PochiStorage` - GCSファイル操作
- `pochilib.PochiUserInfo` - ユーザー情報取得
- `pochilib.PochiEnvironment` - 環境情報
- `pochilib.snowflake.generate_pochi_snowflake_connector` - Snowflake接続
- `pochilib.snowflake.sf_sqlalchemy_tools` - SQLAlchemy ツール
- `pochilib.user_interface_support.DogHarness` - データ品質監視
- `pochilib.user_interface_support.detect_encoding` - 文字コード検出
- `pochilib.user_interface_support.generate_gallery_back_button` - UI補助

### 4.2 外部ライブラリ

| ライブラリ | 用途 | 主要関数 |
|-----------|------|---------|
| `streamlit` | UI フレームワーク | st.file_uploader, st.session_state, st.cache_data |
| `pandas` | データ処理 | pd.read_csv, pd.read_excel, pd.merge, pd.DataFrame |
| `sqlalchemy` | ORM | select, join, CTE, sessionmaker |
| `openpyxl` | Excel出力 | (via pandas) |
| `xlrd` | Excel読込 | XLRDError例外 |
| `jinja2` | テンプレート | (レガシー：old_query_collect.py で使用) |

---

## 5. ビジネスルール・ロジック

### 5.1 ID形式検証ルール

**アカウント識別子**
- 桁数: 24桁
- 形式: 英数字

**共通IDグループ番号**
- 桁数: 12桁
- 先頭2桁: "00" (固定)

**基本契約番号**
- 桁数: 12桁
- 先頭1桁: "0" (固定)
- 先頭2桁: "00" 以外（共通IDと区別）

**LINE User ID**
- 桁数: 33桁
- 形式: 英数字

実装: `check_input_data()` in `_utils.py`

### 5.2 データソース・SQL条件

**基本テーブル**: `VW_ADM_DNCL_COMNID_INTEGRATION`

フィルタ条件:
```
- LAK_PTK_CRITERIA_DAY = 現在日 - 5日
- REGULAR_INCOMPLETE_JUDGMENT_CLASSIFICATION = '0' (正規)
- 取得値 IS NOT NULL
```

重複処理:
```
- PARTITION BY (変換元ID)
- ORDER BY RECORD_UPDATE_DATE DESC, (対応値) DESC
- -> row_number() = 1 を選択
```

実装: `_generate_sql_extract()`, `__create_convert_cte()` in `get_statement.py`

### 5.3 LINE ID連携特殊処理

アカウント識別子 ⇄ LINE User ID変換:
```
1. LineUserIdCoordinattionData にジョイン
2. account_coordination_flag = 1 で限定
3. line_business_account = "1654296328" で限定
4. LineFriendList でさらにフィルタ（chnl_id = "1654296328"）
5. lakptk_standard_nengappi = 現在日 - 2日 で限定
```

実装: `__create_convert_acctid_to_lineid_CTE()`, `__create_convert_lineid_to_acctid_CTE()` in `get_statement.py`

---

## 6. 既知の問題・リスク

### 6.1 テスト可能性の課題

- **グローバルエンジン初期化**: `get_statement.py` の先頭で `engine` を グローバル変数として初期化
  ```python
  psc = generate_pochi_snowflake_connector()
  psc.size = "MEDIUM"
  engine = psc.create_sqlalchemy_engine()
  ```
  → テスト時にモッキング困難、テスト用接続の切り替えが必要

- **Session の グローバル化**: 同様に `Session` と `session` がグローバル
  → テスト間のデータベース状態分離が困難

- **Streamlit session_state への依存**: `view_output_data` が `st.session_state` に直接書き込み
  → 単体テスト時に Streamlit ランタイムが必須

### 6.2 エラーハンドリング

**例外処理の粗さ**:
- `view_input_data.py` 行156-158: 広すぎる `except` ブロック
  ```python
  except:
      ErrorMessage.unexpected_error()
      df = None
  ```
  → 予期しない例外も吸収され、デバッグが困難

**エラーメッセージの静的出力**:
- `ErrorMessage` クラスのすべてのメソッドが副作用（`st.error()` 直接呼び出し）
  → 単体テストでエラーロジック検証が困難

### 6.3 データ処理のリスク

**大容量データ**:
- `pd.read_csv()` や `pd.read_excel()` で全メモリ読込
- 数百万行以上のファイルはメモリ不足リスク
- エラーメッセージで対処法は提示しているが、事前の行数チェックなし

**文字コード対応**:
- CSV の自動判定は `detect_encoding()` に依存
- 稀なエンコーディングは手動選択が必要（UIで対応）

**データ品質**:
- 入力IDの形式バリデーションはあるが、論理妥当性（実際に存在するIDか）は未検証
- 不正なID → NULL で返却（テスト項目04_データソースについて.py で記述）

### 6.4 セッション管理

**セッションID取得**:
```python
def get_streamlit_session_id() -> str:
    return get_script_run_ctx().session_id
```
→ `get_script_run_ctx()` が None の場合クラッシュ（ユニットテスト環境）

**セッション状態の永続化**:
- ファイルアップロード時に `st.session_state["save_file_path"]` で変更を検知
- 複数ファイルアップロード時の状態管理はやや複雑

---

## 7. テスト対象領域

### 7.1 優先度高

1. **ID形式バリデーション** (`check_input_data` in `_utils.py`)
   - 各ID種別の桁数・形式チェック
   - 境界値テスト（先頭文字判定）

2. **ファイル入出力** (`view_input_data.py`, `view_output_data.py`)
   - CSV/XLSX読込エラーハンドリング
   - 文字コード自動判定
   - ファイル名バリデーション

3. **SQL CTE生成ロジック** (`get_statement.py`)
   - 変換モード別のCTE生成
   - 複数事業区分への対応
   - LINE ID中間変換ロジック

4. **基本契約番号の複数事業区分処理** (`view_output_data.py`)
   - チェックボックス選択状態の管理
   - 事業区分別データ抽出

### 7.2 優先度中

1. **Streamlit キャッシング** (`add_header`)
   - ヘッダー追加処理が正確に実行されているか

2. **エラーメッセージの出力** (`ErrorMessage` クラス)
   - 各エラー種別の適切な表示確認

3. **GCS ファイル操作** (`get_pstorage`, `get_pstorage_user`)
   - アップロード・ダウンロード機能

4. **データマージ処理** (`left_merge_df`, `make_input_df`)
   - 入力順序の保持確認
   - 重複排除の動作確認

### 7.3 優先度低

1. **UI情報表示** (`information.py`, `dogharness.py`)
   - 表示内容の確認（単体テストよりはE2E向き）

2. **ページルーティング** (`routing.py`)
   - ページ遷移の確認

---

## 8. レガシーコード特有の課題

### 8.1 保守性の課題

- **IDマッピングの複数表現**: `definition.py` に4つの辞書で管理
  ```python
  dict_id_to_name, dict_name_to_id, source_id_dict, get_column_name
  ```
  → 不整合のリスク、変更時の誤り可能性高い

- **get_statement.py の関数密度**: 14個の関数、うち7個がプライベート（`__` プリフィックス）
  → 関数が長く、ロジックの重複がある（CTE生成の類似パターン）

- **old_query_collect.py のレガシー**: 完全にコメントアウト（SQL Jinja2テンプレート方式）
  → 削除推奨だが、過去参照用に残存

### 8.2 テスト戦略上の課題

- **Snowflake依存の強さ**: ORM層を経由しているため、テスト時に実SnowflakeへのアクセスOR モッキングが必須
- **Streamlit統合の強さ**: UI層とビジネスロジックが分離不十分
- **セッション状態管理**: Streamlit 特有の `session_state` が各所に散在

---

## 9. 推奨テスト戦略

### 9.1 レイヤー別テスト計画

| レイヤー | モジュール | テスト方式 | 優先度 |
|---------|-----------|----------|-------|
| **UI層** | app_pages/*.py | E2E/UI | 中 |
| **ビジネスロジック層** | view_input_data.py, view_output_data.py | ユニット + 統合 | 高 |
| **バリデーション層** | _utils.py (check_input_data) | ユニット | 高 |
| **SQL/ORM層** | get_statement.py | 統合テスト（Snowflake Mock） | 高 |
| **ユーティリティ層** | _error_message.py, _set_page_config.py | ユニット | 低 |

### 9.2 モック戦略

- **Snowflake**: `pochilib.snowflake` は常にモック（本番DB接触防止）
- **PochiStorage**: GCSアクセスはモック
- **Streamlit**: `st.cache_data` などのデコレータはパス、`st.session_state` はMock
- **pandas**: CSV/XLSX読込はモックまたはテスト用ファイル

---

## 10. 摘要

**pochi-id-converter** は、Streamlit を用いた**ID相互変換SaaS**として機能していますが、以下の点でテスト設計に配慮が必要です：

1. **多様なID変換ロジック** → テストケース数が多い（10+パターン）
2. **Snowflake との密結合** → モッキング戦略が重要
3. **Streamlit session_state への依存** → 単体テスト環境での工夫が必要
4. **エラーハンドリングの粗さ** → 例外処理テストの充実が推奨
5. **大容量データ対応** → パフォーマンステストも視野に

**次フェーズ（T1）では**、これらの課題を踏まえて、`draft-contracts/` 配下の以下ファイルを精緻化してください：

- `data-contracts.json` - 入出力データ仕様（スキーマ）
- `business-rules.json` - ID形式ルール、変換ロジック
- `risk-catalog.md` - 既知リスク・対応策

