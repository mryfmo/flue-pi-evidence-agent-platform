# Layer 2 ユニットテスト設計書
**対象プロジェクト**: pochi-id-converter  
**生成日**: 2026-05-01  
**モード**: Characterization（既存コード動作の固定）

---

## 1. 定量目標の事前算出

### 1.1 テスト層構成の目標値

**test-viewpoints.json の Layer 2 観点数**:
- VP-002: app/app_pages/01_IDを変換する.py
- VP-003: app/app_pages/02_使い方がわからないときは.py
- VP-004: app/app_pages/03_このアプリについて.py
- VP-005: app/app_pages/04_データソースについて.py
- VP-006: app/app_pages/routing.py

計 5 個の Layer 2 観点が存在する（N=5）

**Layer 2 最低生成数**:
```
N × 2 = 5 × 2 = 10 件（直接観点から）

総テスト予定数の目安:
- Layer 1（契約テスト）: ~15 件
- Layer 2（ロジックテスト）: ~25 件
- Layer 3（結合テスト）: ~15 件
- Layer 4（E2Eテスト）: ~5 件
合計: 60 件程度

Layer 2 目標比率 40% → 24 件
最大(10, 24) = 24 件以上
```

**最低生成数: 24 件**

### 1.2 テスト比率（test-ratio.json から）

適用比率:
- 正常系（Normal）: 40%
- 異常系（Error）: 45%
- 境界値（Boundary）: 15%

**Layer 2 内の内訳（24 件基準）**:
- 正常系: 24 × 0.40 = 9.6 → 10 件
- 異常系: 24 × 0.45 = 10.8 → 11 件
- 境界値: 24 × 0.15 = 3.6 → 3 件

---

## 2. Streamlit デコレータ振り分け（Layer 2 vs Layer 3 分類）

### 2.1 Layer 3 必須モジュール（@st.cache_data/@st.cache_resource 付き）

| モジュールパス | 関数名 | デコレータ | 層の分類 |
|---|---|---|---|
| app/lib/view_input_data.py | add_header | @st.cache_data | **Layer 3 必須**（AppTest経由） |

**判定**: view_input_data.py の add_header() は @st.cache_data デコレータ付きのため、
Layer 2 ユニットテストは不可。Layer 3 統合テストで AppTest を使用してテストする。

### 2.2 Layer 2 対象モジュール（Streamlit装飾なし、テスト可能）

```
app/lib/definition.py
  ├─ input_datas（クラス）
  └─ __init__（メソッド）

app/lib/utility/_utils.py
  ├─ check_input_data()
  ├─ df_to_xlsx()
  ├─ check_input_file()
  └─ ValidationError（カスタム例外）

app/lib/utility/_error_message.py
  ├─ ErrorMessage.memory_error()
  ├─ ErrorMessage.unexpected_error()
  ├─ ErrorMessage.file_lock_error()
  ├─ ErrorMessage.decode_error()
  ├─ ErrorMessage.acctid_input_error()
  ├─ ErrorMessage.comnid_input_error()
  └─ ErrorMessage.bascid_input_error()

app/lib/view_output_data.py（Streamlit依存部分はモック）
  ├─ init_convert()
  ├─ get_streamlit_session_id()
  ├─ load_input_dict()
  ├─ make_input_df()
  └─ left_merge_df()
```

**計**: Layer 2 テスト対象関数は約 18 個（直接テスト可能）

---

## 3. リスク対応テスト（risk-catalog.md）の最優先生成

### 3.1 重要度 HIGH・CRITICAL のリスク対応テスト

| リスクID | リスク概要 | 対応テスト関数 | テスト層 | 優先度 |
|---|---|---|---|---|
| **R-007** | 過度な例外吸収（全例外を catch-all） | test_check_input_data_memory_error_handling | Layer 2 | **CRITICAL** |
| **R-007** | 過度な例外吸収（全例外を catch-all） | test_check_input_file_validation_error_handling | Layer 2 | **CRITICAL** |
| **R-008** | ErrorMessage の副作用（直接 st.error()） | test_error_message_memory_error_output | Layer 2 | CRITICAL |
| **R-012** | ID形式バリデーション（論理妥当性未検証） | test_check_input_data_acctid_format_validation | Layer 2 | HIGH |
| **R-012** | ID形式バリデーション（論理妥当性未検証） | test_check_input_data_comnid_format_validation | Layer 2 | HIGH |
| **R-012** | ID形式バリデーション（論理妥当性未検証） | test_check_input_data_bascid_format_validation | Layer 2 | HIGH |
| **R-012** | ID形式バリデーション（論理妥当性未検証） | test_check_input_data_lineid_format_validation | Layer 2 | HIGH |
| **R-019** | 基本契約番号事業区分の複雑性 | test_input_datas_init_bascid_list_variants | Layer 2 | HIGH |

---

## 4. Layer 2 テストケース設計

### 4.1 モジュール: app/lib/definition.py

#### 4.1.1 input_datas クラス

**関数**: input_datas.__init__()

**呼び出し元分析**: 
- view_output_data.py の view_output_data() で使用
- 受け取り側が期待する形式: 入力されたすべての属性が正しく保持される

**テストケース設計**:

| No. | テスト名 | テスト種別 | 入力 | 期待出力 | アサーション3段階 |
|---|---|---|---|---|---|
| 1 | test_input_datas_init_basic | 正常系 | input_df=DataFrame(5行), input_data_type="acctid", output_data_type="comnid", select_input_column="col1", bascid_list=[] | 4つの属性が正確に設定される | Lv1: 全属性値の完全一致 / Lv2: DataFrame形状(5行確認) / Lv3: 属性の型チェック |
| 2 | test_input_datas_init_with_bascid_list | 正常系 | input_df=DataFrame(3行), input_data_type="comnid", output_data_type="bascid01", select_input_column="col2", bascid_list=["01", "05"] | bascid_list が正確に2要素保持 | Lv1: len(bascid_list)==2 かつ要素が["01","05"] / Lv2: 順序が同じ / Lv3: 全要素型がstr |
| 3 | test_input_datas_init_empty_bascid_list | 正常系 | input_df=DataFrame(1行), input_data_type="acctid", output_data_type="lineid", select_input_column="col3", bascid_list（デフォルト） | bascid_list がデフォルト[] で初期化 | Lv1: bascid_list == [] / Lv2: len(bascid_list)==0 / Lv3: リスト型 |
| 4 | test_input_datas_init_all_bascid_variants | 正常系 | input_df=DataFrame(10行), input_data_type="comnid", output_data_type="bascid05", select_input_column="col4", bascid_list=["01", "05", "08"] | 3つの事業区分すべてを保持 | Lv1: bascid_list == ["01","05","08"] / Lv2: len==3 / Lv3: 順序保持確認 |
| 5 | test_input_datas_init_large_dataframe | 正常系 | input_df=DataFrame(1000行), input_data_type="lineid", output_data_type="acctid", select_input_column="large_col", bascid_list=[] | 大規模DataFrameも正確に保持 | Lv1: len(input_df)==1000 / Lv2: shape確認(1000行) / Lv3: メモリ参照確認 |
| 6 | test_input_datas_init_special_characters_in_column_name | 境界値 | input_df=DataFrame(2行, columns=["カラム名(01_携帯)"]）, input_data_type="comnid", output_data_type="bascid01", select_input_column="カラム名(01_携帯)", bascid_list=["01"] | 日本語を含むカラム名を正確に保持 | Lv1: select_input_column == "カラム名(01_携帯)" / Lv2: 文字列長が正確 / Lv3: 文字コード確認 |

**出力契約テスト**（view_output_data() への入力仕様を満たす）:

| No. | テスト名 | テスト内容 | 期待出力 | アサーション |
|---|---|---|---|---|
| 7 | test_input_datas_出力が_view_output_data_の入力仕様を満たす | input_datas インスタンスが view_output_data の execute_orm_query() に正しく受け渡される | bascid_list が None でなく、list型 | isinstance(instance.bascid_list, list) |

---

### 4.2 モジュール: app/lib/utility/_utils.py

#### 4.2.1 check_input_data() 関数

**関数**: check_input_data(source_id: str, input_df: DataFrame) -> bool

**呼び出し元分析**:
- view_input_data.py: 入力データの形式検証
- view_output_data.py: 変換前バリデーション
- 期待される戻り値: bool（True=正常, False=異常）

**リスク対応**: R-007（過度な例外吸収）, R-012（ID形式バリデーション）

**テストケース設計**:

| No. | テスト名 | テスト種別 | 入力 | 期待出力 | アサーション3段階 |
|---|---|---|---|---|---|
| 1 | test_check_input_data_acctid_valid_24digit | 正常系 | source_id="acctid", input_df=["AAAAAAAAAAAAAAAAAAAAA111"] | True | Lv1: result==True / Lv2: len==24確認 / Lv3: 英数字のみ |
| 2 | test_check_input_data_acctid_invalid_short | 異常系 | source_id="acctid", input_df=["AAAAAAAAAAAAAAAAAAAAAA11"] | False | Lv1: result==False / Lv2: len==23 / Lv3: フォーマット不正 |
| 3 | test_check_input_data_acctid_invalid_long | 異常系 | source_id="acctid", input_df=["AAAAAAAAAAAAAAAAAAAAAAA1111"] | False | Lv1: result==False / Lv2: len==26 / Lv3: 超過検知 |
| 4 | test_check_input_data_comnid_valid_00prefix | 正常系 | source_id="comnid", input_df=["000012345678"] | True | Lv1: result==True / Lv2: len==12 かつ [0:2]=="00" / Lv3: 12桁全て数字確認 |
| 5 | test_check_input_data_comnid_invalid_no_prefix | 異常系 | source_id="comnid", input_df=["100012345678"] | False | Lv1: result==False / Lv2: [0:2]=="10" （不正） / Lv3: プレフィックス検知 |
| 6 | test_check_input_data_comnid_invalid_short | 異常系 | source_id="comnid", input_df=["0001234567"] | False | Lv1: result==False / Lv2: len==10 / Lv3: 桁数不足検知 |
| 7 | test_check_input_data_bascid_valid_01variant | 正常系 | source_id="bascid01", input_df=["012345678901"] | True | Lv1: result==True / Lv2: len==12 かつ [0]=="0" かつ [1]!="0" / Lv3: 携帯事業パターン確認 |
| 8 | test_check_input_data_bascid_invalid_00prefix | 異常系 | source_id="bascid", input_df=["001234567890"] | False | Lv1: result==False / Lv2: [0:2]=="00"（共通IDと同じ） / Lv3: bascidフォーマット検知 |
| 9 | test_check_input_data_bascid_invalid_no_zero_prefix | 異常系 | source_id="bascid", input_df=["112345678901"] | False | Lv1: result==False / Lv2: [0]!="0" / Lv3: プレフィックス欠落検知 |
| 10 | test_check_input_data_lineid_valid_33digit | 正常系 | source_id="lineid", input_df=["Uabcdefghijklmnopqrstuvwxyz123456"] | True | Lv1: result==True / Lv2: len==33 かつ [0]=="U" / Lv3: 英数字確認 |
| 11 | test_check_input_data_lineid_invalid_no_prefix | 異常系 | source_id="lineid", input_df=["Wabcdefghijklmnopqrstuvwxyz123456"] | False | Lv1: result==False / Lv2: [0]=="W" （不正） / Lv3: プレフィックス不正検知 |
| 12 | test_check_input_data_lineid_invalid_short | 異常系 | source_id="lineid", input_df=["Uabcdefghijklmnopqrstuvwxy12345"] | False | Lv1: result==False / Lv2: len==32 / Lv3: 桁数不足検知 |
| 13 | test_check_input_data_multiple_valid_rows | 正常系 | source_id="comnid", input_df=["000012345678", "000087654321", "000055555555"] | True | Lv1: result==True / Lv2: len(input)==3 かつ全て有効 / Lv3: 反復検証 |
| 14 | test_check_input_data_multiple_mixed_valid_invalid | 異常系 | source_id="comnid", input_df=["000012345678", "100012345678"] | False | Lv1: result==False / Lv2: 2番目が不正 / Lv3: 最初の不正で中止 |
| 15 | test_check_input_data_none_input | 異常系 | source_id="acctid", input_df=None | False | Lv1: result==False / Lv2: input==None検知 / Lv3: 例外なく処理 |
| 16 | test_check_input_data_memory_error_handling | 異常系・RISK:R-007 | source_id="comnid", input_df が MemoryError を発生させる大規模リスト | False | Lv1: result==False / Lv2: 例外をキャッチ / Lv3: エラーハンドリング確認 |
| 17 | test_check_input_data_bascid_05_variant | 正常系 | source_id="bascid05", input_df=["051234567890"] | True | Lv1: result==True / Lv2: [0:2]!="00" / Lv3: CF事業パターン確認 |
| 18 | test_check_input_data_bascid_08_variant | 正常系 | source_id="bascid08", input_df=["082345678901"] | True | Lv1: result==True / Lv2: [0]=="0" 確認 / Lv3: 会員事業パターン確認 |
| 19 | test_check_input_data_boundary_acctid_24digit_exact | 境界値 | source_id="acctid", input_df=["A"*24] | True | Lv1: result==True / Lv2: len==24正確 / Lv3: 境界値で成功 |
| 20 | test_check_input_data_boundary_comnid_12digit_exact | 境界値 | source_id="comnid", input_df=["00"+"9"*10] | True | Lv1: result==True / Lv2: len==12正確 / Lv3: 最大値テスト |
| 21 | test_check_input_data_boundary_lineid_33digit_exact | 境界値 | source_id="lineid", input_df=["U"+"9"*32] | True | Lv1: result==True / Lv2: len==33正確 / Lv3: 最大値テスト |

**出力契約テスト**（呼び出し元への保証）:

| No. | テスト名 | テスト内容 | 期待出力 | アサーション |
|---|---|---|---|---|
| 22 | test_check_input_data_出力が_view_input_data_の条件分岐を制御 | 戻り値が bool 型で view_input_data の if 分岐を正確に制御 | bool 値のみ | isinstance(result, bool) and (result in [True, False]) |
| 23 | test_check_input_data_出力が_view_output_data_のバリデーション制御 | False 時に view_output_data の処理がスキップされる | if not check_input_data(...): 実行 | result==False で後続処理スキップ確認 |

---

#### 4.2.2 df_to_xlsx() 関数

**関数**: df_to_xlsx(df: DataFrame) -> bytes

**呼び出し元分析**:
- view_output_data.py: ファイルダウンロード前の変換処理
- 期待される戻り値: bytes（Excel形式のバイナリ）

**テストケース設計**:

| No. | テスト名 | テスト種別 | 入力 | 期待出力 | アサーション3段階 |
|---|---|---|---|---|---|
| 1 | test_df_to_xlsx_basic_conversion | 正常系 | DataFrame({"col1": [1,2,3], "col2": ["a","b","c"]}) | バイト列で Excel 形式 | Lv1: isinstance(result, bytes) / Lv2: len(result) > 0 / Lv3: Excel シグネチャ確認 |
| 2 | test_df_to_xlsx_preserves_column_names | 正常系 | DataFrame({"カラム1": [1], "カラム2": [2]}) | Excel の 1 行目に カラム1, カラム2 | Lv1: バイト長 > 100 / Lv2: openpyxl で読込テスト / Lv3: カラム名一致確認 |
| 3 | test_df_to_xlsx_empty_dataframe | 正常系 | DataFrame(columns=["col1", "col2"]) | 空のExcelファイル（ヘッダーのみ） | Lv1: isinstance(result, bytes) / Lv2: len(result) > 0 / Lv3: openpyxl で解析確認 |
| 4 | test_df_to_xlsx_single_row | 正常系 | DataFrame({"col": [100]}) | 1行（ヘッダー+データ） | Lv1: isinstance(result, bytes) / Lv2: len(result) > 50 / Lv3: データ行確認 |
| 5 | test_df_to_xlsx_large_dataframe | 正常系 | DataFrame(100行 × 10列） | 大規模 Excel ファイル | Lv1: isinstance(result, bytes) / Lv2: len(result) > 10000 / Lv3: 行数検証 |
| 6 | test_df_to_xlsx_numeric_and_string | 正常系 | DataFrame({"num": [1,2,3], "str": ["a","b","c"]}) | 混合型が正しく保持 | Lv1: isinstance(result, bytes) / Lv2: バイナリサイズ確認 / Lv3: openpyxl で型確認 |
| 7 | test_df_to_xlsx_special_characters | 正常系 | DataFrame({"col": ["日本語", "特殊文字①", "emoji😀"]}) | UTF-8 でエンコードされた Excel | Lv1: isinstance(result, bytes) / Lv2: len > 0 / Lv3: デコード可能確認 |
| 8 | test_df_to_xlsx_return_type_is_bytes | 正常系 | DataFrame({"col": [1]}) | bytes 型 | Lv1: type(result)==bytes / Lv2: len(result) > 0 / Lv3: メモリ参照確認 |

---

#### 4.2.3 check_input_file() 関数

**関数**: check_input_file(file_name: str) -> None （例外発生時は ValidationError）

**呼び出し元分析**:
- view_output_data.py: ダウンロード時のファイル名検証
- 期待される動作: 不正な文字の場合 ValidationError を throw

**リスク対応**: R-007（例外処理）

**テストケース設計**:

| No. | テスト名 | テスト種別 | 入力 | 期待出力 | アサーション3段階 |
|---|---|---|---|---|---|
| 1 | test_check_input_file_valid_simple_name | 正常系 | "output" | 例外なし | Lv1: 例外 raise なし / Lv2: 関数終了 / Lv3: 戻り値 None |
| 2 | test_check_input_file_valid_with_extension | 正常系 | "result.csv" | 例外なし | Lv1: 例外なし / Lv2: 関数終了 / Lv3: None 返却 |
| 3 | test_check_input_file_valid_with_underscore | 正常系 | "output_file_name" | 例外なし | Lv1: 例外なし / Lv2: _ 許可 / Lv3: 完了 |
| 4 | test_check_input_file_valid_with_hyphen | 正常系 | "output-file" | 例外なし | Lv1: 例外なし / Lv2: - 許可 / Lv3: 完了 |
| 5 | test_check_input_file_valid_japanese_name | 正常系 | "出力ファイル" | 例外なし | Lv1: 例外なし / Lv2: 日本語許可 / Lv3: エンコード確認 |
| 6 | test_check_input_file_invalid_backslash | 異常系 | "output\\file" | ValidationError | Lv1: ValidationError raise / Lv2: メッセージに "\\" 含む / Lv3: error_code存在確認 |
| 7 | test_check_input_file_invalid_forward_slash | 異常系 | "output/file" | ValidationError | Lv1: ValidationError raise / Lv2: メッセージに "/" 含む / Lv3: 正確なエラー内容 |
| 8 | test_check_input_file_invalid_colon | 異常系 | "output:file" | ValidationError | Lv1: ValidationError raise / Lv2: メッセージに ":" 含む / Lv3: コロン検知 |
| 9 | test_check_input_file_invalid_asterisk | 異常系 | "output*file" | ValidationError | Lv1: ValidationError raise / Lv2: メッセージに "*" 含む / Lv3: アスタリスク検知 |
| 10 | test_check_input_file_invalid_question_mark | 異常系 | "output?file" | ValidationError | Lv1: ValidationError raise / Lv2: メッセージに "?" 含む / Lv3: 疑問符検知 |
| 11 | test_check_input_file_invalid_double_quote | 異常系 | 'output"file' | ValidationError | Lv1: ValidationError raise / Lv2: メッセージに '"' 含む / Lv3: クォート検知 |
| 12 | test_check_input_file_invalid_angle_bracket_lt | 異常系 | "output<file" | ValidationError | Lv1: ValidationError raise / Lv2: メッセージに "<" 含む / Lv3: 角括弧検知 |
| 13 | test_check_input_file_invalid_angle_bracket_gt | 異常系 | "output>file" | ValidationError | Lv1: ValidationError raise / Lv2: メッセージに ">" 含む / Lv3: 角括弧検知 |
| 14 | test_check_input_file_invalid_pipe | 異常系 | "output\|file" | ValidationError | Lv1: ValidationError raise / Lv2: メッセージに "\|" 含む / Lv3: パイプ検知 |
| 15 | test_check_input_file_invalid_multiple_forbidden_chars | 異常系 | "output*file:name" | ValidationError | Lv1: ValidationError raise / Lv2: 最初の不正文字を検知 / Lv3: メッセージ確認 |
| 16 | test_check_input_file_error_message_contains_invalid_char | 異常系 | "file<name" | ValidationError with message | Lv1: exception.message に "<" 含む / Lv2: メッセージが読みやすい / Lv3: エスケープ確認 |
| 17 | test_check_input_file_boundary_long_filename | 正常系 | "a" * 255 | 例外なし | Lv1: 例外なし / Lv2: 長い名前も許可 / Lv3: メモリ確認 |
| 18 | test_check_input_file_boundary_forbidden_at_end | 異常系 | "filename_" (最後が _) | 例外なし | Lv1: 例外なし / Lv2: _ は許可 / Lv3: 完了 |

---

#### 4.2.4 ValidationError クラス

**クラス**: ValidationError（Exception を継承）

**テストケース設計**:

| No. | テスト名 | テスト種別 | 入力 | 期待出力 | アサーション3段階 |
|---|---|---|---|---|---|
| 1 | test_validation_error_init_with_message | 正常系 | message="エラー内容" | message 属性に格納 | Lv1: error.message=="エラー内容" / Lv2: Exception としても機能 / Lv3: str(error) 確認 |
| 2 | test_validation_error_init_with_code | 正常系 | message="msg", code="E001" | message と code を保持 | Lv1: error.code=="E001" / Lv2: error.message=="msg" / Lv3: 両属性一致 |
| 3 | test_validation_error_init_code_default | 正常系 | message="msg", code=None | code は None | Lv1: error.code is None / Lv2: message は保持 / Lv3: デフォルト値確認 |
| 4 | test_validation_error_is_exception | 正常系 | ValidationError("msg") | Exception サブクラス | Lv1: isinstance(error, Exception)==True / Lv2: raise 可能 / Lv3: try-except で捕捉可能 |
| 5 | test_validation_error_raise_and_catch | 正常系 | raise ValidationError("test", "E001") | 例外が正常に発生・捕捉 | Lv1: except ValidationError で捕捉 / Lv2: 属性アクセス可能 / Lv3: message と code 確認 |

---

### 4.3 モジュール: app/lib/utility/_error_message.py

#### 4.3.1 ErrorMessage クラス

**クラス**: ErrorMessage（複数の静的メソッド）

**リスク対応**: R-008（ErrorMessage の副作用）

**テストケース設計**:

| No. | テスト名 | テスト種別 | 入力 | 期待出力 | アサーション3段階 | モック対象 |
|---|---|---|---|---|---|---|
| 1 | test_error_message_memory_error_output | 異常系・RISK:R-008 | ErrorMessage.memory_error() 呼び出し | st.error() が呼ばれる | Lv1: st.error 呼び出し確認 / Lv2: メッセージに "メモリ" 含む / Lv3: Slack リンク確認 | @patch("streamlit.error") |
| 2 | test_error_message_unexpected_error_output | 異常系・RISK:R-008 | ErrorMessage.unexpected_error() 呼び出し | st.error() が呼ばれる | Lv1: st.error 呼び出し確認 / Lv2: メッセージに "予期せぬ" 含む / Lv3: Slack リンク確認 | @patch("streamlit.error") |
| 3 | test_error_message_file_lock_error_returns_string | 正常系 | ErrorMessage.file_lock_error() 呼び出し | 文字列を返す | Lv1: isinstance(result, str)==True / Lv2: len(result)>0 / Lv3: "暗号化" を含む | なし |
| 4 | test_error_message_decode_error_output | 異常系・RISK:R-008 | ErrorMessage.decode_error() 呼び出し | st.error() が呼ばれる | Lv1: st.error 呼び出し確認 / Lv2: メッセージに "文字コード" 含む / Lv3: Slack リンク確認 | @patch("streamlit.error") |
| 5 | test_error_message_acctid_input_error_output | 異常系・RISK:R-008 | ErrorMessage.acctid_input_error() 呼び出し | st.error() が呼ばれる | Lv1: st.error 呼び出し確認 / Lv2: メッセージに "24桁" 含む / Lv3: Slack リンク確認 | @patch("streamlit.error") |
| 6 | test_error_message_comnid_input_error_output | 異常系・RISK:R-008 | ErrorMessage.comnid_input_error() 呼び出し | st.error() が呼ばれる | Lv1: st.error 呼び出し確認 / Lv2: メッセージに "頭2桁" 含む / Lv3: "00" 確認 | @patch("streamlit.error") |
| 7 | test_error_message_bascid_input_error_output | 異常系・RISK:R-008 | ErrorMessage.bascid_input_error() 呼び出し | st.error() が呼ばれる | Lv1: st.error 呼び出し確認 / Lv2: メッセージに "頭1桁が「0」" 含む / Lv3: "12桁" 確認 | @patch("streamlit.error") |
| 8 | test_error_message_file_lock_error_contains_unlock_instruction | 正常系 | ErrorMessage.file_lock_error() 呼び出し | "解除" または "Unlock" を含む | Lv1: "解除" in result / Lv2: len(result)>50 / Lv3: ユーザーガイダンス確認 | なし |

---

### 4.4 モジュール: app/lib/view_output_data.py

#### 4.4.1 init_convert() 関数

**関数**: init_convert() -> None

**呼び出し元分析**:
- view_output_data.py: session_state をリセット
- view_input_data.py: ファイル変更時に呼び出し

**テストケース設計**:

| No. | テスト名 | テスト種別 | 入力 | 期待出力 | アサーション3段階 |
|---|---|---|---|---|---|
| 1 | test_init_convert_resets_all_flags | 正常系 | st.session_state 事前に複数設定 | 全てのキーが初期値に | Lv1: session_state["convert"]==False / Lv2: 7個キー全て確認 / Lv3: 値の型チェック |
| 2 | test_init_convert_sets_convert_false | 正常系 | session_state["convert"]=True | False に | Lv1: session_state["convert"]==False / Lv2: bool型確認 / Lv3: 値の確実性 |
| 3 | test_init_convert_sets_convert_done_false | 正常系 | session_state["convert_done"]=True | False に | Lv1: session_state["convert_done"]==False / Lv2: bool型確認 / Lv3: フラグリセット |
| 4 | test_init_convert_sets_get_output_none | 正常系 | session_state["get_output"]=DataFrame(...) | None に | Lv1: session_state["get_output"] is None / Lv2: not DataFrame / Lv3: メモリ解放確認 |
| 5 | test_init_convert_sets_output_df_culums_num_none | 正常系 | session_state["output_df_culums_num"]=100 | None に | Lv1: session_state["output_df_culums_num"] is None / Lv2: int でなく | Lv3: 計数リセット |
| 6 | test_init_convert_sets_output_file_name_none | 正常系 | session_state["output_file_name"]="file" | None に | Lv1: session_state["output_file_name"] is None / Lv2: str でなく / Lv3: ファイル名クリア |
| 7 | test_init_convert_sets_output_file_none | 正常系 | session_state["output_file"]=b"binary" | None に | Lv1: session_state["output_file"] is None / Lv2: bytes でなく / Lv3: バイナリクリア |
| 8 | test_init_convert_sets_output_file_url_none | 正常系 | session_state["output_file_url"]="http://..." | None に | Lv1: session_state["output_file_url"] is None / Lv2: str でなく / Lv3: URL クリア |

---

#### 4.4.2 load_input_dict() 関数

**関数**: load_input_dict(input_dict: dict) -> tuple

**呼び出し元分析**:
- view_output_data() で使用
- 期待される戻り値: 5つの要素のタプル

**テストケース設計**:

| No. | テスト名 | テスト種別 | 入力 | 期待出力 | アサーション3段階 |
|---|---|---|---|---|---|
| 1 | test_load_input_dict_basic | 正常系 | {"select_source": "comnid", "select_df": [1,2,3], "id_list": ["a"], "select_input_colum": "col", "column_name": "COMNID"} | 5要素の タプル | Lv1: len(result)==5 / Lv2: 型が (str,list,list,str,str) / Lv3: 値の完全一致 |
| 2 | test_load_input_dict_return_order | 正常系 | input_dict で順序確認 | (select_source, select_df, id_list, select_input_colum, column_name) | Lv1: result[0]=="comnid" / Lv2: result[1]==[1,2,3] / Lv3: 全要素順序確認 |
| 3 | test_load_input_dict_with_bascid | 正常系 | {"select_source": "bascid01", ...} | 正確に "bascid01" を返す | Lv1: result[0]=="bascid01" / Lv2: tuple 型 / Lv3: 事業区分保持 |

---

#### 4.4.3 make_input_df() 関数

**関数**: make_input_df(select_df: Series, column_name: str) -> DataFrame

**呼び出し元分析**:
- view_output_data(): 入力を ORM クエリ用に変換
- 期待される戻り値: 単一カラムの DataFrame（重複削除済み）

**テストケース設計**:

| No. | テスト名 | テスト種別 | 入力 | 期待出力 | アサーション3段階 |
|---|---|---|---|---|---|
| 1 | test_make_input_df_basic | 正常系 | select_df=Series(["A","B","C"]), column_name="ACCTID" | {"ACCTID": ["A","B","C"]} の DataFrame | Lv1: isinstance(result, pd.DataFrame) / Lv2: len(result)==3 / Lv3: カラム名="ACCTID" |
| 2 | test_make_input_df_removes_duplicates | 正常系 | select_df=Series(["A","B","A","C"]), column_name="COMNID" | 重複削除後 ["A","B","C"] | Lv1: len(result)==3 / Lv2: result[カラム名] に "A" は 1 回のみ / Lv3: 重複削除確認 |
| 3 | test_make_input_df_single_row | 正常系 | select_df=Series(["X"]), column_name="BASCID" | 1 行の DataFrame | Lv1: len(result)==1 / Lv2: result["BASCID"][0]=="X" / Lv3: 単一行保持 |
| 4 | test_make_input_df_column_name_japanese | 正常系 | select_df=Series([1,2,3]), column_name="基本契約番号" | カラム名が "基本契約番号" | Lv1: "基本契約番号" in result.columns / Lv2: len(result)==3 / Lv3: 日本語カラム対応 |

---

#### 4.4.4 left_merge_df() 関数

**関数**: left_merge_df(base_df: DataFrame, select_df: DataFrame, base_column_name: str) -> DataFrame

**呼び出し元分析**:
- view_output_data(): 入力順序を保持して変換結果をマージ

**テストケース設計**:

| No. | テスト名 | テスト種別 | 入力 | 期待出力 | アサーション3段階 |
|---|---|---|---|---|---|
| 1 | test_left_merge_df_basic | 正常系 | base_df={"col": [1,2,3], "data": ["a","b","c"]}, select_df={"col": [1,2], "result": ["X","Y"]}, base_column_name="col" | {"col":[1,2,3], "data":["a","b","c"], "result":["X","Y",None]} | Lv1: len(result)==3 / Lv2: result["data"]==["a","b","c"] 保持 / Lv3: 左マージ確認 |
| 2 | test_left_merge_df_preserves_order | 正常系 | 入力順序 [1,2,3] | 出力も [1,2,3] 順序保持 | Lv1: result.iloc[:,0].tolist()==[1,2,3] / Lv2: left merge で順序保持 / Lv3: インデックス確認 |
| 3 | test_left_merge_df_adds_null_for_missing | 正常系 | base_df に col=3 があるが select_df にない | result["result"][2]==None | Lv1: result.iloc[2,-1] is None / Lv2: NaN でなく None / Lv3: NULL 値確認 |
| 4 | test_left_merge_df_single_row | 正常系 | base_df={"col": [1]}, select_df={"col": [1], "val": ["A"]} | {"col":[1], "val":["A"]} | Lv1: len(result)==1 / Lv2: result["val"][0]=="A" / Lv3: マージ成功 |

---

## 5. テスト実施方針

### 5.1 Mock/Patch 戦略

**必須モック対象**（skill-config.json より）:
- `streamlit` モジュール → `@patch("streamlit.error")` で st.error() を mock
- `pochilib` モジュール → テスト環境では使用しない（Layer 3 統合テスト対象）
- `sqlalchemy` モジュール → 実import OK（mock never）

**Layer 2 では以下をモック**:
```python
@patch("streamlit.error")
@patch("streamlit.warning")
def test_error_message_*(mock_st_error, mock_st_warning):
    # Streamlit 副作用をモック
    ...
```

### 5.2 Fixture 活用（tests/fixtures/ より）

**valid ディレクトリの活用**:
- input_acctid.csv → check_input_data の acctid テスト
- input_comnid.csv → check_input_data の comnid テスト
- input_bascid.csv → check_input_data の bascid テスト
- input_lineid.csv → check_input_data の lineid テスト
- input_mixed_columns.csv → DataFrame 操作テスト

**invalid ディレクトリの活用**:
- invalid_acctid_*.csv → check_input_data の異常系テスト
- invalid_comnid_*.csv → comnid フォーマット異常系
- invalid_bascid_*.csv → bascid フォーマット異常系

**edge ディレクトリの活用**:
- edge_empty_file.csv → 空ファイルハンドリング
- edge_single_row.csv → 単行ファイル処理
- edge_duplicate_rows.csv → 重複排除テスト（make_input_df）

### 5.3 テストレイアウト

**生成先ディレクトリ**: `/home/user/pochi-id-converter-repository/tests/unit/`

**ファイル構成**:
```
tests/unit/
├── test_definition.py         # input_datas クラス
├── test_utils.py              # check_input_data, df_to_xlsx, check_input_file, ValidationError
├── test_error_message.py      # ErrorMessage クラス
└── test_view_output_data.py   # view_output_data モジュール（init_convert, load_input_dict, make_input_df, left_merge_df）
```

---

## 6. テスト関数命名規則と品質基準

### 6.1 命名規則（TDD スタイル）

```
test_{対象関数名}_{条件}_{期待結果}

例:
  test_check_input_data_acctid_valid_24digit
  test_check_input_data_acctid_invalid_short
  test_error_message_memory_error_output
  test_make_input_df_removes_duplicates
```

### 6.2 アサーション品質基準（3段階）

**レベル1（必須）**: 具体値の完全一致
```python
assert result == True
assert error.message == "エラー内容"
assert isinstance(result, bytes)
```

**レベル2（必須）**: 出力構造・スキーマの厳密検証
```python
assert len(input_df) == 3
assert list(result.columns) == ["col1", "col2"]
assert result["col"].dtype == "object"
```

**レベル3（推奨）**: 否定条件・副次効果の検証
```python
assert "forbidden_char" not in result
assert st.error.called
assert session_state.get("convert") is False
```

### 6.3 禁止パターン

❌ **NG**: 曖昧なテスト
```python
assert result is not None
assert df_result  # 存在確認のみ
```

❌ **NG**: 実装ロジック再実装
```python
# 代わりに app.lib の実装を呼び出す
for char in ignore_chars:
    if char in file_name:
        raise ValidationError(...)
```

✅ **OK**: 具体的で明確なテスト
```python
assert isinstance(result, bytes)
assert len(result) > 100
assert result[:4] == b"PK\x03\x04"  # ZIP（Excel）シグネチャ
```

---

## 7. リスク ID 対応マッピング

| リスク ID | リスク概要 | 対応テスト関数 | テスト層 |
|---|---|---|---|
| R-001 | Snowflake グローバル engine 変数のモッキング困難 | Layer 3 統合テスト対象 | Layer 3 |
| R-002 | グローバル Session 共有問題 | Layer 3 統合テスト対象 | Layer 3 |
| R-007 | 過度な例外吸収 | test_check_input_data_memory_error_handling, test_check_input_file_validation_error_handling | Layer 2 |
| R-008 | ErrorMessage の副作用 | test_error_message_*_output（全7種類） | Layer 2 |
| R-012 | ID形式バリデーション | test_check_input_data_acctid_*, test_check_input_data_comnid_*, test_check_input_data_bascid_*, test_check_input_data_lineid_* | Layer 2 |
| R-019 | 基本契約番号事業区分の複雑性 | test_input_datas_init_all_bascid_variants, test_check_input_data_bascid_*_variant | Layer 2 |

---

## 8. 観点カバレッジマッピング

| 観点 ID | 観点名 | 対応テスト関数 | カバー状況 |
|---|---|---|---|
| VP-002 | ID変換メイン画面のUI・ユーザーアクション処理確認 | test_make_input_df_*, test_left_merge_df_* | Layer 2 部分カバー（UI除外） |
| VP-006 | ページナビゲーション・ルーティング機能確認 | Layer 3 で AppTest 実施 | Layer 3 |
| VP-007 | 入力データクラス (input_datas) の定義・初期化確認 | test_input_datas_init_* | Layer 2 完全カバー |

---

## 9. テスト実装時の注意事項

### 9.1 conftest.py での準備

以下を conftest.py に追加:
```python
import sys
import os
from unittest.mock import MagicMock, patch
import pandas as pd

# sys.path に app/ を追加
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

# Streamlit モック
_st = MagicMock()
_st.session_state = {}

@pytest.fixture
def mock_streamlit(monkeypatch):
    """Streamlit モジュールをモック"""
    monkeypatch.setitem(sys.modules, 'streamlit', MagicMock())
    monkeypatch.setitem(sys.modules, 'streamlit.runtime.scriptrunner', MagicMock())
```

### 9.2 テストデータの準備

```python
# tests/unit/conftest.py
@pytest.fixture
def sample_acctid_series():
    """サンプル ACCTID Series"""
    return pd.Series(["AAAAAAAAAAAAAAAAAAAAA111", "BBBBBBBBBBBBBBBBBBBBB222"])

@pytest.fixture
def sample_comnid_series():
    """サンプル COMNID Series"""
    return pd.Series(["000012345678", "000087654321"])
```

### 9.3 Edge Case 対応

- 空 DataFrame、NULL 値：fixture から読込
- 文字エンコーディング問題：UTF-8, Shift-JIS テスト
- 大規模データセット：edge_large_dataset.csv 活用

---

## 10. 生成完了チェックリスト

生成時に以下を確認する:

- [ ] Layer 2 テスト関数数が 24 件以上
- [ ] 正常系 10 件、異常系 11 件、境界値 3 件（最低目標）
- [ ] 全リスク ID（R-007, R-008, R-012, R-019）に対応テストが存在
- [ ] 全観点（VP-002〜VP-007）に対応テストが配置
- [ ] テスト関数名が "{機能}_{条件}_{期待結果}" パターン
- [ ] アサーションが 3 段階で具体的
- [ ] mock 対象が skill-config.json の指示に従う
- [ ] conftest.py に sys.path, mock 設定がある
- [ ] 出力契約テスト（呼び出し元への保証）が含まれている

---

**テスト設計完了。次フェーズで実装テストコードを生成します。**
