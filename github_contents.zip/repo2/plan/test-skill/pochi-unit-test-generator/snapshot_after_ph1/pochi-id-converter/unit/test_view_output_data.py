"""
app/lib/view_output_data.py のユニットテスト

このモジュールは以下の関数をテストする：
- init_convert: session_state のリセット
- load_input_dict: input_dict の読み込みと解凍
- make_input_df: Series から重複削除した DataFrame 作成
- left_merge_df: 左結合による DataFrame マージ

テスト観点: VP-002（メイン画面のデータ処理）
"""
import sys
import os
import pandas as pd
import pytest
from unittest.mock import patch, MagicMock

# conftest.py で sys.path に app/ が追加されているので、lib.* でインポート可能
from lib.view_output_data import (
    init_convert,
    load_input_dict,
    make_input_df,
    left_merge_df
)


class TestInitConvert:
    """init_convert() のテストクラス"""

    def test_init_convert_resets_all_flags(self):
        """
        正常系: session_state 内のすべてのフラグが初期値にリセットされる

        入力: st.session_state に複数の値が事前に設定されている
        期待: 全てのキーが初期値に（False, None等）
        """
        # Arrange - Mock streamlit.session_state
        with patch("lib.view_output_data.st") as mock_st:
            mock_session_state = {
                "convert": True,
                "convert_done": True,
                "get_output": pd.DataFrame({"col": [1, 2, 3]}),
                "output_df_culums_num": 3,
                "output_file_name": "test.csv",
                "output_file": b"test",
                "output_file_url": "http://example.com"
            }
            mock_st.session_state = mock_session_state

            # Act
            init_convert()

            # Assert
            # 全てのキーが初期値に
            assert mock_session_state["convert"] is False
            assert mock_session_state["convert_done"] is False
            assert mock_session_state["get_output"] is None
            assert mock_session_state["output_df_culums_num"] is None
            assert mock_session_state["output_file_name"] is None
            assert mock_session_state["output_file"] is None
            assert mock_session_state["output_file_url"] is None

    def test_init_convert_sets_convert_false(self):
        """
        正常系: session_state["convert"] が False に設定される

        入力: session_state["convert"]=True
        期待: False に
        """
        # Arrange
        with patch("lib.view_output_data.st") as mock_st:
            mock_session_state = {"convert": True}
            mock_st.session_state = mock_session_state

            # Act
            init_convert()

            # Assert
            assert mock_session_state["convert"] is False
            assert isinstance(mock_session_state["convert"], bool)

    def test_init_convert_sets_convert_done_false(self):
        """
        正常系: session_state["convert_done"] が False に設定される

        入力: session_state["convert_done"]=True
        期待: False に
        """
        # Arrange
        with patch("lib.view_output_data.st") as mock_st:
            mock_session_state = {"convert_done": True}
            mock_st.session_state = mock_session_state

            # Act
            init_convert()

            # Assert
            assert mock_session_state["convert_done"] is False

    def test_init_convert_sets_get_output_none(self):
        """
        正常系: session_state["get_output"] が None に設定される

        入力: session_state["get_output"]=DataFrame(...)
        期待: None に
        """
        # Arrange
        with patch("lib.view_output_data.st") as mock_st:
            mock_session_state = {
                "get_output": pd.DataFrame({"col": [1, 2, 3]})
            }
            mock_st.session_state = mock_session_state

            # Act
            init_convert()

            # Assert
            assert mock_session_state["get_output"] is None
            assert not isinstance(mock_session_state["get_output"], pd.DataFrame)

    def test_init_convert_sets_output_df_culums_num_none(self):
        """
        正常系: session_state["output_df_culums_num"] が None に設定される

        入力: session_state["output_df_culums_num"]=100
        期待: None に
        """
        # Arrange
        with patch("lib.view_output_data.st") as mock_st:
            mock_session_state = {"output_df_culums_num": 100}
            mock_st.session_state = mock_session_state

            # Act
            init_convert()

            # Assert
            assert mock_session_state["output_df_culums_num"] is None
            assert not isinstance(mock_session_state["output_df_culums_num"], int)

    def test_init_convert_sets_output_file_name_none(self):
        """
        正常系: session_state["output_file_name"] が None に設定される

        入力: session_state["output_file_name"]="file"
        期待: None に
        """
        # Arrange
        with patch("lib.view_output_data.st") as mock_st:
            mock_session_state = {"output_file_name": "file"}
            mock_st.session_state = mock_session_state

            # Act
            init_convert()

            # Assert
            assert mock_session_state["output_file_name"] is None
            assert not isinstance(mock_session_state["output_file_name"], str)

    def test_init_convert_sets_output_file_none(self):
        """
        正常系: session_state["output_file"] が None に設定される

        入力: session_state["output_file"]=b"binary"
        期待: None に
        """
        # Arrange
        with patch("lib.view_output_data.st") as mock_st:
            mock_session_state = {"output_file": b"binary"}
            mock_st.session_state = mock_session_state

            # Act
            init_convert()

            # Assert
            assert mock_session_state["output_file"] is None
            assert not isinstance(mock_session_state["output_file"], bytes)

    def test_init_convert_sets_output_file_url_none(self):
        """
        正常系: session_state["output_file_url"] が None に設定される

        入力: session_state["output_file_url"]="http://..."
        期待: None に
        """
        # Arrange
        with patch("lib.view_output_data.st") as mock_st:
            mock_session_state = {"output_file_url": "http://example.com"}
            mock_st.session_state = mock_session_state

            # Act
            init_convert()

            # Assert
            assert mock_session_state["output_file_url"] is None
            assert not isinstance(mock_session_state["output_file_url"], str)


class TestLoadInputDict:
    """load_input_dict() のテストクラス"""

    def test_load_input_dict_basic(self):
        """
        正常系: input_dict を読み込み、5要素のタプルを返す

        入力: {"select_source": "comnid", "select_df": [1,2,3],
               "id_list": ["a"], "select_input_colum": "col", "column_name": "COMNID"}
        期待: 5要素のタプル
        """
        # Arrange
        input_dict = {
            "select_source": "comnid",
            "select_df": [1, 2, 3],
            "id_list": ["a"],
            "select_input_colum": "col",
            "column_name": "COMNID"
        }

        # Act
        result = load_input_dict(input_dict)

        # Assert
        assert len(result) == 5
        assert isinstance(result, tuple)
        # 型チェック
        assert isinstance(result[0], str)  # select_source
        assert isinstance(result[1], list)  # select_df
        assert isinstance(result[2], list)  # id_list
        assert isinstance(result[3], str)   # select_input_colum
        assert isinstance(result[4], str)   # column_name

    def test_load_input_dict_return_order(self):
        """
        正常系: タプルの要素が正しい順序で返される

        期待: (select_source, select_df, id_list, select_input_colum, column_name)
        """
        # Arrange
        input_dict = {
            "select_source": "comnid",
            "select_df": [1, 2, 3],
            "id_list": ["a"],
            "select_input_colum": "col",
            "column_name": "COMNID"
        }

        # Act
        result = load_input_dict(input_dict)

        # Assert
        assert result[0] == "comnid"
        assert result[1] == [1, 2, 3]
        assert result[2] == ["a"]
        assert result[3] == "col"
        assert result[4] == "COMNID"

    def test_load_input_dict_with_bascid(self):
        """
        正常系: select_source が "bascid01" の場合も正確に返す

        期待: 正確に "bascid01" を返す
        """
        # Arrange
        input_dict = {
            "select_source": "bascid01",
            "select_df": pd.Series(["012345678901"]),
            "id_list": ["基本契約番号"],
            "select_input_colum": "col",
            "column_name": "BASCID"
        }

        # Act
        result = load_input_dict(input_dict)

        # Assert
        assert result[0] == "bascid01"
        assert isinstance(result, tuple)


class TestMakeInputDf:
    """make_input_df() のテストクラス"""

    def test_make_input_df_basic(self):
        """
        正常系: Series を DataFrame に変換

        入力: select_df=Series(["A","B","C"]), column_name="ACCTID"
        期待: {"ACCTID": ["A","B","C"]} の DataFrame
        """
        # Arrange
        select_df = pd.Series(["A", "B", "C"])
        column_name = "ACCTID"

        # Act
        result = make_input_df(select_df, column_name)

        # Assert
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 3
        assert list(result.columns) == ["ACCTID"]
        assert result["ACCTID"].tolist() == ["A", "B", "C"]

    def test_make_input_df_removes_duplicates(self):
        """
        正常系: 重複を削除する

        入力: select_df=Series(["A","B","A","C"]), column_name="COMNID"
        期待: 重複削除後 ["A","B","C"]
        """
        # Arrange
        select_df = pd.Series(["A", "B", "A", "C"])
        column_name = "COMNID"

        # Act
        result = make_input_df(select_df, column_name)

        # Assert
        assert len(result) == 3
        # 重複削除確認
        assert "A" in result["COMNID"].values
        assert result["COMNID"].value_counts()["A"] == 1

    def test_make_input_df_single_row(self):
        """
        正常系: 1行の Series を DataFrame に変換

        入力: select_df=Series(["X"]), column_name="BASCID"
        期待: 1行の DataFrame
        """
        # Arrange
        select_df = pd.Series(["X"])
        column_name = "BASCID"

        # Act
        result = make_input_df(select_df, column_name)

        # Assert
        assert len(result) == 1
        assert result["BASCID"][0] == "X"

    def test_make_input_df_column_name_japanese(self):
        """
        正常系: 日本語のカラム名に対応

        入力: select_df=Series([1,2,3]), column_name="基本契約番号"
        期待: カラム名が "基本契約番号"
        """
        # Arrange
        select_df = pd.Series([1, 2, 3])
        column_name = "基本契約番号"

        # Act
        result = make_input_df(select_df, column_name)

        # Assert
        assert "基本契約番号" in result.columns
        assert len(result) == 3


class TestLeftMergeDf:
    """left_merge_df() のテストクラス"""

    def test_left_merge_df_basic(self):
        """
        正常系: 左結合を実行

        入力: base_df={"col": [1,2,3], "data": ["a","b","c"]},
              select_df={"col": [1,2], "result": ["X","Y"]},
              base_column_name="col"
        期待: {"col":[1,2,3], "data":["a","b","c"], "result":["X","Y",None]}
        """
        # Arrange
        base_df = pd.DataFrame({
            "col": [1, 2, 3],
            "data": ["a", "b", "c"]
        })
        select_df = pd.DataFrame({
            "col": [1, 2],
            "result": ["X", "Y"]
        })
        base_column_name = "col"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        assert len(result) == 3
        assert result["data"].tolist() == ["a", "b", "c"]
        assert list(result.columns) == ["col", "data", "result"]

    def test_left_merge_df_preserves_order(self):
        """
        正常系: 左結合で入力順序が保持される

        入力: 入力順序 [1,2,3]
        期待: 出力も [1,2,3] 順序保持
        """
        # Arrange
        base_df = pd.DataFrame({
            "col": [1, 2, 3],
            "data": ["a", "b", "c"]
        })
        select_df = pd.DataFrame({
            "col": [3, 1, 2],
            "result": ["Z", "X", "Y"]
        })
        base_column_name = "col"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        # 左結合なので base_df の順序が保持される
        assert result["col"].tolist() == [1, 2, 3]
        assert result["data"].tolist() == ["a", "b", "c"]

    def test_left_merge_df_adds_null_for_missing(self):
        """
        正常系: マッチしないキーには NaN/None が追加される

        入力: base_df に col=3 があるが select_df にない
        期待: result["result"][2]==None（またはNaN）
        """
        # Arrange
        base_df = pd.DataFrame({
            "col": [1, 2, 3],
            "data": ["a", "b", "c"]
        })
        select_df = pd.DataFrame({
            "col": [1, 2],
            "result": ["X", "Y"]
        })
        base_column_name = "col"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        # 3番目の行で result が NaN または None
        assert len(result) == 3
        # pd.isna で NULL/NaN を確認
        assert pd.isna(result.iloc[2]["result"])

    def test_left_merge_df_single_row(self):
        """
        正常系: 1行のマージ

        入力: base_df={"col": [1]}, select_df={"col": [1], "val": ["A"]}
        期待: {"col":[1], "val":["A"]}
        """
        # Arrange
        base_df = pd.DataFrame({"col": [1]})
        select_df = pd.DataFrame({
            "col": [1],
            "val": ["A"]
        })
        base_column_name = "col"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        assert len(result) == 1
        assert result["val"][0] == "A"
