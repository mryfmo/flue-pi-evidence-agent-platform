"""
input_datas クラスのユニットテスト

input_datas クラスは入力データを管理するクラスで、
データフレーム、データ種別、カラム名、事業区分リストを保持する。
このモジュールはそれらの属性が正確に初期化・保持されることを確認する。

テスト観点: VP-007（入力データクラスの定義・初期化）
リスク対応: R-019（基本契約番号事業区分の複雑性）
"""
import sys
import os
import pandas as pd
import pytest

# conftest.py で sys.path に app/ が追加されているので、lib.* でインポート可能
from lib.definition import input_datas


class TestInputDatasInit:
    """input_datas.__init__() のテストクラス"""

    def test_input_datas_init_basic(self):
        """
        正常系: 基本的な属性初期化が正確に実行されること

        入力: input_df=DataFrame(5行), input_data_type="acctid",
              output_data_type="comnid", select_input_column="col1", bascid_list=[]
        期待: 4つの属性が正確に設定される
        """
        # Arrange
        input_df = pd.DataFrame({
            "col1": ["A" * 24, "B" * 24, "C" * 24, "D" * 24, "E" * 24]
        })
        input_data_type = "acctid"
        output_data_type = "comnid"
        select_input_column = "col1"
        bascid_list = []

        # Act
        instance = input_datas(
            input_df=input_df,
            input_data_type=input_data_type,
            output_data_type=output_data_type,
            select_input_column=select_input_column,
            bascid_list=bascid_list
        )

        # Assert
        # Lv1: 全属性値の完全一致
        assert instance.input_data_type == "acctid"
        assert instance.output_data_type == "comnid"
        assert instance.select_input_column == "col1"
        assert instance.bascid_list == []
        # Lv2: DataFrame形状(5行確認)
        assert len(instance.input_df) == 5
        # Lv3: 属性の型チェック
        assert isinstance(instance.input_df, pd.DataFrame)
        assert isinstance(instance.input_data_type, str)
        assert isinstance(instance.bascid_list, list)

    def test_input_datas_init_with_bascid_list(self):
        """
        正常系: bascid_list に複数の事業区分が設定される

        入力: input_df=DataFrame(3行), input_data_type="comnid",
              output_data_type="bascid01", bascid_list=["01", "05"]
        期待: bascid_list が正確に2要素保持される
        """
        # Arrange
        input_df = pd.DataFrame({
            "col2": ["000012345678", "000087654321", "000099999999"]
        })
        bascid_list = ["01", "05"]

        # Act
        instance = input_datas(
            input_df=input_df,
            input_data_type="comnid",
            output_data_type="bascid01",
            select_input_column="col2",
            bascid_list=bascid_list
        )

        # Assert
        # Lv1: len(bascid_list)==2 かつ要素が["01","05"]
        assert len(instance.bascid_list) == 2
        assert instance.bascid_list == ["01", "05"]
        # Lv2: 順序が同じ
        assert instance.bascid_list[0] == "01"
        assert instance.bascid_list[1] == "05"
        # Lv3: 全要素型がstr
        assert all(isinstance(item, str) for item in instance.bascid_list)

    def test_input_datas_init_empty_bascid_list(self):
        """
        正常系: bascid_list がデフォルト[] で初期化される

        入力: input_df=DataFrame(1行), input_data_type="acctid",
              output_data_type="lineid", bascid_list（デフォルト）
        期待: bascid_list がデフォルト[] で初期化される
        """
        # Arrange
        input_df = pd.DataFrame({
            "col3": ["U" + "a" * 31 + "123456"]
        })

        # Act - bascid_list を指定しない（デフォルト値を使用）
        instance = input_datas(
            input_df=input_df,
            input_data_type="acctid",
            output_data_type="lineid",
            select_input_column="col3"
        )

        # Assert
        # Lv1: bascid_list == []
        assert instance.bascid_list == []
        # Lv2: len(bascid_list)==0
        assert len(instance.bascid_list) == 0
        # Lv3: リスト型
        assert isinstance(instance.bascid_list, list)

    def test_input_datas_init_all_bascid_variants(self):
        """
        正常系: 3つの事業区分すべてを保持（R-019 対応）

        入力: input_df=DataFrame(10行), input_data_type="comnid",
              output_data_type="bascid05", bascid_list=["01", "05", "08"]
        期待: 3つの事業区分すべてを保持
        """
        # Arrange
        input_df = pd.DataFrame({
            "col4": ["00" + str(i).zfill(10) for i in range(1000, 1010)]
        })
        bascid_list = ["01", "05", "08"]

        # Act
        instance = input_datas(
            input_df=input_df,
            input_data_type="comnid",
            output_data_type="bascid05",
            select_input_column="col4",
            bascid_list=bascid_list
        )

        # Assert
        # Lv1: bascid_list == ["01","05","08"]
        assert instance.bascid_list == ["01", "05", "08"]
        # Lv2: len==3
        assert len(instance.bascid_list) == 3
        # Lv3: 順序保持確認
        assert instance.bascid_list[0] == "01"
        assert instance.bascid_list[1] == "05"
        assert instance.bascid_list[2] == "08"

    def test_input_datas_init_large_dataframe(self):
        """
        正常系: 大規模DataFrameも正確に保持

        入力: input_df=DataFrame(1000行), input_data_type="lineid",
              output_data_type="acctid"
        期待: 大規模DataFrameも正確に保持される
        """
        # Arrange
        large_data = ["U" + "a" * 31 + str(i).zfill(1) for i in range(10)]
        large_df = pd.DataFrame({
            "large_col": large_data * 100  # 1000行相当
        })

        # Act
        instance = input_datas(
            input_df=large_df,
            input_data_type="lineid",
            output_data_type="acctid",
            select_input_column="large_col",
            bascid_list=[]
        )

        # Assert
        # Lv1: len(input_df)==1000
        assert len(instance.input_df) == 1000
        # Lv2: shape確認(1000行)
        assert instance.input_df.shape[0] == 1000
        # Lv3: メモリ参照確認
        assert instance.input_df is not None
        assert isinstance(instance.input_df, pd.DataFrame)

    def test_input_datas_init_special_characters_in_column_name(self):
        """
        境界値: 日本語を含むカラム名を正確に保持

        入力: input_df=DataFrame(2行, columns=["カラム名(01_携帯)"]),
              select_input_column="カラム名(01_携帯)"
        期待: 日本語を含むカラム名を正確に保持
        """
        # Arrange
        input_df = pd.DataFrame({
            "カラム名(01_携帯)": ["012345678901", "052345678901"]
        })
        column_name = "カラム名(01_携帯)"

        # Act
        instance = input_datas(
            input_df=input_df,
            input_data_type="comnid",
            output_data_type="bascid01",
            select_input_column=column_name,
            bascid_list=["01"]
        )

        # Assert
        # Lv1: select_input_column == "カラム名(01_携帯)"
        assert instance.select_input_column == "カラム名(01_携帯)"
        # Lv2: 文字列長が正確
        assert len(instance.select_input_column) == 11
        # Lv3: 文字コード確認（日本語が正しくエンコードされている）
        assert "カラム名" in instance.select_input_column

    def test_input_datas_output_contract_tuple_elements(self):
        """
        出力契約テスト: input_datas インスタンスの bascid_list が
        view_output_data の execute_orm_query() に正しく受け渡される

        期待: bascid_list が None でなく、list型であること
        """
        # Arrange
        input_df = pd.DataFrame({"col": ["012345678901"]})

        # Act
        instance = input_datas(
            input_df=input_df,
            input_data_type="comnid",
            output_data_type="bascid01",
            select_input_column="col",
            bascid_list=["01", "05"]
        )

        # Assert
        # bascid_list が後続関数の期待形式を満たす
        assert isinstance(instance.bascid_list, list)
        assert instance.bascid_list is not None
        assert all(isinstance(item, str) for item in instance.bascid_list)
