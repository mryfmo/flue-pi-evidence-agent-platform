"""
app/lib/utility/_error_message.py のユニットテスト

ErrorMessage クラスは複数の静的メソッドを持ち、
各メソッドは Streamlit の st.error() を呼び出してエラーメッセージを表示する。
このモジュールはそれらのメソッドが正しく Streamlit を呼び出すことを確認する。

テスト観点: Error handling and user messaging
リスク対応: R-008（ErrorMessage の副作用）
"""
import sys
import os
import pytest
from unittest.mock import patch, MagicMock

# conftest.py で sys.path に app/ が追加されているので、lib.* でインポート可能
from lib.utility._error_message import ErrorMessage


class TestErrorMessageMemoryError:
    """ErrorMessage.memory_error() のテストクラス"""

    @patch("lib.utility._error_message.st.error")
    def test_error_message_memory_error_output(self, mock_st_error):
        """
        異常系・R-008: memory_error() が st.error() を呼び出す

        期待: st.error() が呼ばれ、メッセージに「メモリ」を含む
        """
        # Act
        ErrorMessage.memory_error()

        # Assert
        # st.error が呼び出されたことを確認
        assert mock_st_error.called
        assert mock_st_error.call_count == 1
        # メッセージに「メモリ」を含むことを確認
        call_args = mock_st_error.call_args[0][0]
        assert "メモリ" in call_args
        # Slack リンクを含むことを確認
        assert "Slack" in call_args or "slack.com" in call_args


class TestErrorMessageUnexpectedError:
    """ErrorMessage.unexpected_error() のテストクラス"""

    @patch("lib.utility._error_message.st.error")
    def test_error_message_unexpected_error_output(self, mock_st_error):
        """
        異常系・R-008: unexpected_error() が st.error() を呼び出す

        期待: st.error() が呼ばれ、メッセージに「予期せぬ」を含む
        """
        # Act
        ErrorMessage.unexpected_error()

        # Assert
        assert mock_st_error.called
        assert mock_st_error.call_count == 1
        call_args = mock_st_error.call_args[0][0]
        assert "予期せぬ" in call_args
        # Slack リンクを含むことを確認
        assert "Slack" in call_args or "slack.com" in call_args


class TestErrorMessageFileLockError:
    """ErrorMessage.file_lock_error() のテストクラス"""

    def test_error_message_file_lock_error_returns_string(self):
        """
        正常系: file_lock_error() が文字列を返す

        期待: 文字列を返し、「暗号化」を含む
        """
        # Act
        result = ErrorMessage.file_lock_error()

        # Assert
        assert isinstance(result, str)
        assert len(result) > 0
        assert "暗号化" in result

    def test_error_message_file_lock_error_contains_unlock_instruction(self):
        """
        正常系: file_lock_error() が「解除」または解除方法を含む

        期待: ユーザーガイダンスが含まれている
        """
        # Act
        result = ErrorMessage.file_lock_error()

        # Assert
        assert isinstance(result, str)
        assert len(result) > 50
        # 「解除」または「Unlock」を含む
        assert "解除" in result or "Unlock" in result


class TestErrorMessageDecodeError:
    """ErrorMessage.decode_error() のテストクラス"""

    @patch("lib.utility._error_message.st.error")
    def test_error_message_decode_error_output(self, mock_st_error):
        """
        異常系・R-008: decode_error() が st.error() を呼び出す

        期待: st.error() が呼ばれ、メッセージに「文字コード」を含む
        """
        # Act
        ErrorMessage.decode_error()

        # Assert
        assert mock_st_error.called
        assert mock_st_error.call_count == 1
        call_args = mock_st_error.call_args[0][0]
        assert "文字コード" in call_args
        # Slack リンクを含むことを確認
        assert "Slack" in call_args or "slack.com" in call_args


class TestErrorMessageAcctidInputError:
    """ErrorMessage.acctid_input_error() のテストクラス"""

    @patch("lib.utility._error_message.st.error")
    def test_error_message_acctid_input_error_output(self, mock_st_error):
        """
        異常系・R-008: acctid_input_error() が st.error() を呼び出す

        期待: st.error() が呼ばれ、メッセージに「24桁」を含む
        """
        # Act
        ErrorMessage.acctid_input_error()

        # Assert
        assert mock_st_error.called
        assert mock_st_error.call_count == 1
        call_args = mock_st_error.call_args[0][0]
        assert "24桁" in call_args
        # アカウント識別子についてのメッセージであることを確認
        assert "アカウント識別子" in call_args


class TestErrorMessageComnidInputError:
    """ErrorMessage.comnid_input_error() のテストクラス"""

    @patch("lib.utility._error_message.st.error")
    def test_error_message_comnid_input_error_output(self, mock_st_error):
        """
        異常系・R-008: comnid_input_error() が st.error() を呼び出す

        期待: st.error() が呼ばれ、メッセージに「頭2桁」を含む
        """
        # Act
        ErrorMessage.comnid_input_error()

        # Assert
        assert mock_st_error.called
        assert mock_st_error.call_count == 1
        call_args = mock_st_error.call_args[0][0]
        assert "頭2桁" in call_args
        # 「00」が正しい形式であることを確認
        assert "00" in call_args


class TestErrorMessageBascidInputError:
    """ErrorMessage.bascid_input_error() のテストクラス"""

    @patch("lib.utility._error_message.st.error")
    def test_error_message_bascid_input_error_output(self, mock_st_error):
        """
        異常系・R-008: bascid_input_error() が st.error() を呼び出す

        期待: st.error() が呼ばれ、メッセージに「頭1桁が「0」」を含む
        """
        # Act
        ErrorMessage.bascid_input_error()

        # Assert
        assert mock_st_error.called
        assert mock_st_error.call_count == 1
        call_args = mock_st_error.call_args[0][0]
        assert "頭1桁" in call_args or "頭" in call_args
        # 「12桁」が確認されることを確認
        assert "12桁" in call_args
