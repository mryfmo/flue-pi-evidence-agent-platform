"""
app/lib/utility/_utils.py のユニットテスト

このモジュールは以下の関数とクラスをテストする：
- check_input_data: 入力IDの形式検証
- df_to_xlsx: DataFrameをExcelバイナリに変換
- check_input_file: ファイル名の有効性検証
- ValidationError: カスタム例外クラス

テスト観点: VP-002（メイン画面のデータ処理）
リスク対応: R-007（過度な例外吸収）, R-012（ID形式バリデーション）
"""
import sys
import os
import pandas as pd
import pytest
from io import BytesIO
from openpyxl import load_workbook

# conftest.py で sys.path に app/ が追加されているので、lib.* でインポート可能
from lib.utility._utils import (
    check_input_data,
    df_to_xlsx,
    check_input_file,
    ValidationError
)


class TestCheckInputData:
    """check_input_data() のテストクラス"""

    def test_check_input_data_acctid_valid_24digit(self):
        """
        正常系: ACCTID の有効形式（24桁）を検証

        入力: source_id="acctid", input_df=["AAAAAAAAAAAAAAAAAAAAA111"]
        期待: True
        """
        # Arrange
        source_id = "acctid"
        input_df = ["AAAAAAAAAAAAAAAAAAAAA111"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is True
        assert isinstance(result, bool)
        assert len(input_df[0]) == 24

    def test_check_input_data_acctid_invalid_short(self):
        """
        異常系: ACCTID が23桁（短い）で不正

        入力: source_id="acctid", input_df=["AAAAAAAAAAAAAAAAAAAAA11"]
        期待: False
        """
        # Arrange
        source_id = "acctid"
        input_df = ["AAAAAAAAAAAAAAAAAAAAA11"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is False
        assert len(input_df[0]) == 23

    def test_check_input_data_acctid_invalid_long(self):
        """
        異常系: ACCTID が25桁（長い）で不正

        入力: source_id="acctid", input_df=["AAAAAAAAAAAAAAAAAAAAAAAAA"]
        期待: False
        """
        # Arrange
        source_id = "acctid"
        input_df = ["AAAAAAAAAAAAAAAAAAAAAAAAA"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is False
        assert len(input_df[0]) == 25

    def test_check_input_data_comnid_valid_00prefix(self):
        """
        正常系: COMNID の有効形式（頭2桁が「00」、全12桁）を検証

        入力: source_id="comnid", input_df=["000012345678"]
        期待: True
        """
        # Arrange
        source_id = "comnid"
        input_df = ["000012345678"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is True
        assert len(input_df[0]) == 12
        assert input_df[0][:2] == "00"

    def test_check_input_data_comnid_invalid_no_prefix(self):
        """
        異常系: COMNID で頭2桁が「00」でない（「10」）

        入力: source_id="comnid", input_df=["100012345678"]
        期待: False
        """
        # Arrange
        source_id = "comnid"
        input_df = ["100012345678"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is False
        assert input_df[0][:2] == "10"

    def test_check_input_data_comnid_invalid_short(self):
        """
        異常系: COMNID が10桁（短い）で不正

        入力: source_id="comnid", input_df=["0001234567"]
        期待: False
        """
        # Arrange
        source_id = "comnid"
        input_df = ["0001234567"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is False
        assert len(input_df[0]) == 10

    def test_check_input_data_bascid_valid_01variant(self):
        """
        正常系: BASCID の有効形式（頭1桁が「0」、全12桁、但し「00」でない）

        入力: source_id="bascid01", input_df=["012345678901"]
        期待: True
        """
        # Arrange
        source_id = "bascid01"
        input_df = ["012345678901"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is True
        assert len(input_df[0]) == 12
        assert input_df[0][0] == "0"
        assert input_df[0][:2] != "00"

    def test_check_input_data_bascid_invalid_00prefix(self):
        """
        異常系: BASCID で頭2桁が「00」（COMNID と同じ形式）で不正

        入力: source_id="bascid", input_df=["001234567890"]
        期待: False
        """
        # Arrange
        source_id = "bascid"
        input_df = ["001234567890"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is False
        assert input_df[0][:2] == "00"

    def test_check_input_data_bascid_invalid_no_zero_prefix(self):
        """
        異常系: BASCID で頭1桁が「0」でない（「1」）で不正

        入力: source_id="bascid", input_df=["112345678901"]
        期待: False
        """
        # Arrange
        source_id = "bascid"
        input_df = ["112345678901"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is False
        assert input_df[0][0] != "0"

    def test_check_input_data_lineid_valid_33digit(self):
        """
        正常系: LINEID の有効形式（頭1桁が「U」、全33桁）を検証

        入力: source_id="lineid", input_df=["Uabcdefghijklmnopqrstuvwxyz123456"]
        期待: True
        """
        # Arrange
        source_id = "lineid"
        input_df = ["Uabcdefghijklmnopqrstuvwxyz123456"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is True
        assert len(input_df[0]) == 33
        assert input_df[0][0] == "U"

    def test_check_input_data_lineid_invalid_no_prefix(self):
        """
        異常系: LINEID で桁数が33でない（32桁）で不正

        入力: source_id="lineid", input_df=["Uabcdefghijklmnopqrstuvwxy123456"]
        期待: False
        """
        # Arrange
        source_id = "lineid"
        input_df = ["Uabcdefghijklmnopqrstuvwxy123456"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is False
        assert len(input_df[0]) == 32

    def test_check_input_data_lineid_invalid_short(self):
        """
        異常系: LINEID が32桁（短い）で不正

        入力: source_id="lineid", input_df=["Uabcdefghijklmnopqrstuvwxyz12345"]
        期待: False
        """
        # Arrange
        source_id = "lineid"
        input_df = ["Uabcdefghijklmnopqrstuvwxyz12345"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is False
        assert len(input_df[0]) == 32

    def test_check_input_data_multiple_valid_rows(self):
        """
        正常系: 複数行の有効なデータ

        入力: source_id="comnid", input_df=["000012345678", "000087654321", "000055555555"]
        期待: True
        """
        # Arrange
        source_id = "comnid"
        input_df = ["000012345678", "000087654321", "000055555555"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is True
        assert len(input_df) == 3
        assert all(len(val) == 12 for val in input_df)
        assert all(val[:2] == "00" for val in input_df)

    def test_check_input_data_multiple_mixed_valid_invalid(self):
        """
        異常系: 複数行のうち2番目が不正

        入力: source_id="comnid", input_df=["000012345678", "100012345678"]
        期待: False
        """
        # Arrange
        source_id = "comnid"
        input_df = ["000012345678", "100012345678"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is False
        assert len(input_df) == 2
        assert input_df[1][:2] != "00"

    def test_check_input_data_none_input(self):
        """
        異常系・R-007: None 入力でエラーなく処理される

        入力: source_id="acctid", input_df=None
        期待: False（エラーなく処理される）
        """
        # Arrange
        source_id = "acctid"
        input_df = None

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is False
        # R-007: 例外をキャッチして False を返す
        assert isinstance(result, bool)

    def test_check_input_data_bascid_05_variant(self):
        """
        正常系: BASCID_05（CF事業）の有効形式

        入力: source_id="bascid05", input_df=["051234567890"]
        期待: True
        """
        # Arrange
        source_id = "bascid05"
        input_df = ["051234567890"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is True
        assert len(input_df[0]) == 12
        assert input_df[0][0] == "0"

    def test_check_input_data_bascid_08_variant(self):
        """
        正常系: BASCID_08（会員事業）の有効形式

        入力: source_id="bascid08", input_df=["082345678901"]
        期待: True
        """
        # Arrange
        source_id = "bascid08"
        input_df = ["082345678901"]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is True
        assert len(input_df[0]) == 12
        assert input_df[0][0] == "0"

    def test_check_input_data_boundary_acctid_24digit_exact(self):
        """
        境界値: ACCTID の桁数がちょうど24桁

        入力: source_id="acctid", input_df=["A"*24]
        期待: True
        """
        # Arrange
        source_id = "acctid"
        input_df = ["A" * 24]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is True
        assert len(input_df[0]) == 24

    def test_check_input_data_boundary_comnid_12digit_exact(self):
        """
        境界値: COMNID の桁数がちょうど12桁、最大値

        入力: source_id="comnid", input_df=["00"+"9"*10]
        期待: True
        """
        # Arrange
        source_id = "comnid"
        input_df = ["00" + "9" * 10]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is True
        assert len(input_df[0]) == 12
        assert input_df[0][:2] == "00"

    def test_check_input_data_boundary_lineid_33digit_exact(self):
        """
        境界値: LINEID の桁数がちょうど33桁、最大値

        入力: source_id="lineid", input_df=["U"+"9"*32]
        期待: True
        """
        # Arrange
        source_id = "lineid"
        input_df = ["U" + "9" * 32]

        # Act
        result = check_input_data(source_id, input_df)

        # Assert
        assert result is True
        assert len(input_df[0]) == 33
        assert input_df[0][0] == "U"


class TestDfToXlsx:
    """df_to_xlsx() のテストクラス"""

    def test_df_to_xlsx_basic_conversion(self):
        """
        正常系: DataFrame を Excelバイナリに変換

        入力: DataFrame({"col1": [1,2,3], "col2": ["a","b","c"]})
        期待: バイト列で Excel 形式
        """
        # Arrange
        df = pd.DataFrame({"col1": [1, 2, 3], "col2": ["a", "b", "c"]})

        # Act
        result = df_to_xlsx(df)

        # Assert
        assert isinstance(result, bytes)
        assert len(result) > 0
        # Excel の ZIP シグネチャ確認
        assert result[:4] == b"PK\x03\x04"

    def test_df_to_xlsx_preserves_column_names(self):
        """
        正常系: Excel の1行目にカラム名が保持される

        入力: DataFrame({"カラム1": [1], "カラム2": [2]})
        期待: Excel のヘッダーにカラム名が含まれる
        """
        # Arrange
        df = pd.DataFrame({"カラム1": [1], "カラム2": [2]})

        # Act
        result = df_to_xlsx(df)

        # Assert
        assert isinstance(result, bytes)
        assert len(result) > 100
        # openpyxl で読込を確認
        workbook = load_workbook(BytesIO(result))
        sheet = workbook.active
        assert sheet.cell(1, 1).value == "カラム1"
        assert sheet.cell(1, 2).value == "カラム2"

    def test_df_to_xlsx_empty_dataframe(self):
        """
        正常系: 空の DataFrame を Excelファイルに変換

        入力: DataFrame(columns=["col1", "col2"])
        期待: 空のExcelファイル（ヘッダーのみ）
        """
        # Arrange
        df = pd.DataFrame(columns=["col1", "col2"])

        # Act
        result = df_to_xlsx(df)

        # Assert
        assert isinstance(result, bytes)
        assert len(result) > 0
        # openpyxl で解析確認
        workbook = load_workbook(BytesIO(result))
        sheet = workbook.active
        assert sheet.cell(1, 1).value == "col1"
        assert sheet.cell(1, 2).value == "col2"

    def test_df_to_xlsx_single_row(self):
        """
        正常系: 1行のデータを Excelに変換

        入力: DataFrame({"col": [100]})
        期待: 1行のExcelファイル（ヘッダー+データ）
        """
        # Arrange
        df = pd.DataFrame({"col": [100]})

        # Act
        result = df_to_xlsx(df)

        # Assert
        assert isinstance(result, bytes)
        assert len(result) > 50
        workbook = load_workbook(BytesIO(result))
        sheet = workbook.active
        assert sheet.cell(1, 1).value == "col"
        assert sheet.cell(2, 1).value == 100

    def test_df_to_xlsx_large_dataframe(self):
        """
        正常系: 大規模 DataFrame を Excelに変換

        入力: DataFrame(100行 × 10列）
        期待: 大規模 Excel ファイル
        """
        # Arrange
        df = pd.DataFrame({f"col{i}": range(100) for i in range(10)})

        # Act
        result = df_to_xlsx(df)

        # Assert
        assert isinstance(result, bytes)
        assert len(result) > 5000  # Excel ファイルのサイズ確認
        workbook = load_workbook(BytesIO(result))
        sheet = workbook.active
        assert sheet.max_row == 101  # ヘッダー + 100行

    def test_df_to_xlsx_numeric_and_string(self):
        """
        正常系: 混合型（数値と文字列）が正しく保持される

        入力: DataFrame({"num": [1,2,3], "str": ["a","b","c"]})
        期待: 混合型が正しく保持される
        """
        # Arrange
        df = pd.DataFrame({"num": [1, 2, 3], "str": ["a", "b", "c"]})

        # Act
        result = df_to_xlsx(df)

        # Assert
        assert isinstance(result, bytes)
        assert len(result) > 0
        workbook = load_workbook(BytesIO(result))
        sheet = workbook.active
        # 数値型の確認
        assert sheet.cell(2, 1).value == 1
        # 文字列型の確認
        assert sheet.cell(2, 2).value == "a"

    def test_df_to_xlsx_special_characters(self):
        """
        正常系: 特殊文字（日本語、emoji等）がUTF-8でエンコードされる

        入力: DataFrame({"col": ["日本語", "特殊文字①", "emoji😀"]})
        期待: UTF-8 でエンコードされた Excel
        """
        # Arrange
        df = pd.DataFrame({"col": ["日本語", "特殊文字①", "emoji😀"]})

        # Act
        result = df_to_xlsx(df)

        # Assert
        assert isinstance(result, bytes)
        assert len(result) > 0
        workbook = load_workbook(BytesIO(result))
        sheet = workbook.active
        assert sheet.cell(2, 1).value == "日本語"
        assert "特殊文字①" in str(sheet.cell(3, 1).value)

    def test_df_to_xlsx_return_type_is_bytes(self):
        """
        正常系: 戻り値は bytes 型

        入力: DataFrame({"col": [1]})
        期待: bytes 型
        """
        # Arrange
        df = pd.DataFrame({"col": [1]})

        # Act
        result = df_to_xlsx(df)

        # Assert
        assert type(result) == bytes
        assert len(result) > 0


class TestCheckInputFile:
    """check_input_file() のテストクラス"""

    def test_check_input_file_valid_simple_name(self):
        """
        正常系: シンプルなファイル名は許可される

        入力: "output"
        期待: 例外なし
        """
        # Arrange
        file_name = "output"

        # Act & Assert
        # 例外が発生しない
        check_input_file(file_name)

    def test_check_input_file_valid_with_extension(self):
        """
        正常系: 拡張子付きのファイル名は許可される

        入力: "result.csv"
        期待: 例外なし
        """
        # Arrange
        file_name = "result.csv"

        # Act & Assert
        check_input_file(file_name)

    def test_check_input_file_valid_with_underscore(self):
        """
        正常系: アンダースコアを含むファイル名は許可される

        入力: "output_file_name"
        期待: 例外なし
        """
        # Arrange
        file_name = "output_file_name"

        # Act & Assert
        check_input_file(file_name)

    def test_check_input_file_valid_with_hyphen(self):
        """
        正常系: ハイフンを含むファイル名は許可される

        入力: "output-file"
        期待: 例外なし
        """
        # Arrange
        file_name = "output-file"

        # Act & Assert
        check_input_file(file_name)

    def test_check_input_file_valid_japanese_name(self):
        """
        正常系: 日本語のファイル名は許可される

        入力: "出力ファイル"
        期待: 例外なし
        """
        # Arrange
        file_name = "出力ファイル"

        # Act & Assert
        check_input_file(file_name)

    def test_check_input_file_invalid_backslash(self):
        """
        異常系: バックスラッシュを含むファイル名は不正

        入力: "output\\file"
        期待: ValidationError
        """
        # Arrange
        file_name = "output\\file"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        assert "\\" in str(exc_info.value.message)

    def test_check_input_file_invalid_forward_slash(self):
        """
        異常系: フォワードスラッシュを含むファイル名は不正

        入力: "output/file"
        期待: ValidationError
        """
        # Arrange
        file_name = "output/file"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        assert "/" in str(exc_info.value.message)

    def test_check_input_file_invalid_colon(self):
        """
        異常系: コロンを含むファイル名は不正

        入力: "output:file"
        期待: ValidationError
        """
        # Arrange
        file_name = "output:file"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        assert ":" in str(exc_info.value.message)

    def test_check_input_file_invalid_asterisk(self):
        """
        異常系: アスタリスクを含むファイル名は不正

        入力: "output*file"
        期待: ValidationError
        """
        # Arrange
        file_name = "output*file"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        assert "*" in str(exc_info.value.message)

    def test_check_input_file_invalid_question_mark(self):
        """
        異常系: 疑問符を含むファイル名は不正

        入力: "output?file"
        期待: ValidationError
        """
        # Arrange
        file_name = "output?file"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        assert "?" in str(exc_info.value.message)

    def test_check_input_file_invalid_double_quote(self):
        """
        異常系: ダブルクォートを含むファイル名は不正

        入力: 'output"file'
        期待: ValidationError
        """
        # Arrange
        file_name = 'output"file'

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        assert '"' in str(exc_info.value.message)

    def test_check_input_file_invalid_angle_bracket_lt(self):
        """
        異常系: 小なり記号を含むファイル名は不正

        入力: "output<file"
        期待: ValidationError
        """
        # Arrange
        file_name = "output<file"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        assert "<" in str(exc_info.value.message)

    def test_check_input_file_invalid_angle_bracket_gt(self):
        """
        異常系: 大なり記号を含むファイル名は不正

        入力: "output>file"
        期待: ValidationError
        """
        # Arrange
        file_name = "output>file"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        assert ">" in str(exc_info.value.message)

    def test_check_input_file_invalid_pipe(self):
        """
        異常系: パイプ記号を含むファイル名は不正

        入力: "output|file"
        期待: ValidationError
        """
        # Arrange
        file_name = "output|file"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        assert "|" in str(exc_info.value.message)

    def test_check_input_file_invalid_multiple_forbidden_chars(self):
        """
        異常系: 複数の禁止文字を含むファイル名

        入力: "output*file:name"
        期待: ValidationError（最初の不正文字で検知）
        """
        # Arrange
        file_name = "output*file:name"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        # 最初の不正文字（*）が検知されている
        assert ("*" in str(exc_info.value.message) or
                ":" in str(exc_info.value.message))

    def test_check_input_file_error_message_contains_invalid_char(self):
        """
        異常系: エラーメッセージに不正文字が含まれる

        入力: "file<name"
        期待: ValidationError with message（メッセージに「<」を含む）
        """
        # Arrange
        file_name = "file<name"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)
        assert "<" in str(exc_info.value.message)
        # メッセージが読みやすい日本語
        assert "ファイル名に使用できない文字" in str(exc_info.value.message)

    def test_check_input_file_boundary_long_filename(self):
        """
        境界値: 255文字の長いファイル名も許可される

        入力: "a" * 255
        期待: 例外なし
        """
        # Arrange
        file_name = "a" * 255

        # Act & Assert
        check_input_file(file_name)

    def test_check_input_file_boundary_forbidden_at_end(self):
        """
        境界値: 最後がアンダースコアのファイル名は許可される

        入力: "filename_"
        期待: 例外なし
        """
        # Arrange
        file_name = "filename_"

        # Act & Assert
        check_input_file(file_name)


class TestValidationError:
    """ValidationError クラスのテストクラス"""

    def test_validation_error_init_with_message(self):
        """
        正常系: message を指定して初期化

        入力: message="エラー内容"
        期待: message 属性に格納される
        """
        # Arrange
        message = "エラー内容"

        # Act
        error = ValidationError(message)

        # Assert
        assert error.message == "エラー内容"
        assert isinstance(error, Exception)

    def test_validation_error_init_with_code(self):
        """
        正常系: message と code を指定して初期化

        入力: message="msg", code="E001"
        期待: message と code を保持
        """
        # Arrange
        message = "msg"
        code = "E001"

        # Act
        error = ValidationError(message, code)

        # Assert
        assert error.message == "msg"
        assert error.code == "E001"

    def test_validation_error_init_code_default(self):
        """
        正常系: code を指定しない場合はデフォルト値 None

        入力: message="msg", code=None
        期待: code は None
        """
        # Arrange
        message = "msg"

        # Act
        error = ValidationError(message, None)

        # Assert
        assert error.code is None
        assert error.message == "msg"

    def test_validation_error_is_exception(self):
        """
        正常系: ValidationError は Exception のサブクラス

        入力: ValidationError("msg")
        期待: Exception サブクラス
        """
        # Arrange
        error = ValidationError("msg")

        # Assert
        assert isinstance(error, Exception)
        # raise/catch 可能なことを検証する
        caught = False
        try:
            raise error
        except ValidationError:
            caught = True
        assert caught is True

    def test_validation_error_raise_and_catch(self):
        """
        正常系: ValidationError が正常に発生・捕捉される

        入力: raise ValidationError("test", "E001")
        期待: 例外が正常に発生・捕捉される
        """
        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            raise ValidationError("test", "E001")

        # 属性アクセス可能
        assert exc_info.value.message == "test"
        assert exc_info.value.code == "E001"
