import sys
import os
import pytest
import types
import pandas as pd
from unittest.mock import MagicMock, patch

# sys.path 設定
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

# =====================================================================
# Streamlit モック設定
# framework: "streamlit" のため _passthrough_decorator を定義
# =====================================================================

def _passthrough_decorator(func=None, **kwargs):
    """st.cache_data / st.cache_resource のパススルーデコレータ"""
    if func is not None:
        return func
    def decorator(f):
        return f
    return decorator

# モックする必要があるモジュール
_MOCK_MODULES = [
    "streamlit",
    "streamlit.runtime",
    "streamlit.runtime.scriptrunner",
    "pochilib",
    "pochilib.snowflake",
    "pochilib.snowflake.connector",
    "pochilib.snowflake.context",
    "pochilib.snowflake.sqlalchemy_tools",
    "pochilib.llm",
    "pochilib.llm.connector",
    "pochilib.llm.context",
    "pochilib.storage",
    "pochilib.storage.connector",
    "pochilib.storage.user_info",
    "xlrd",
]

# モックモジュールを sys.modules に登録
for _mod_name in _MOCK_MODULES:
    _parts = _mod_name.split(".")
    for _i in range(len(_parts)):
        _full_name = ".".join(_parts[:_i+1])
        if _full_name not in sys.modules:
            _mock_obj = MagicMock()
            # xlrd の場合はバージョン情報を設定
            if _full_name == "xlrd":
                _mock_obj.__version__ = "2.0.1"
                _mock_obj.__name__ = "xlrd"
            sys.modules[_full_name] = _mock_obj

# Streamlit の cache デコレータをパススルーに設定
import streamlit as st
st.cache_data = _passthrough_decorator
st.cache_resource = _passthrough_decorator

# streamlit.runtime.scriptrunner のモック設定
import streamlit.runtime.scriptrunner as sr
def _mock_get_script_run_ctx():
    """Streamlit session コンテキストのモック"""
    mock_ctx = MagicMock()
    mock_ctx.session_id = "test_session_id_12345"
    return mock_ctx

sr.get_script_run_ctx = _mock_get_script_run_ctx

# =====================================================================
# 事前インポート（アプリモジュールの読み込みエラーを防ぐ）
# =====================================================================

_PRELOAD_MODULES = [
    "lib.definition",
    "lib.utility._utils",
    "lib.utility._error_message",
    "lib.utility._get_pstorage",
    "lib.information",
    "lib.view_input_data",
    "lib.view_output_data",
    "lib.queries.sa_models.base",
    "lib.queries.sa_models.temporary_table",
    "lib.queries.sa_models.vw_adm_dncl_comnid_integration",
    "lib.queries.sa_models.vw_dmc_dncl_line_friend_list",
    "lib.queries.sa_models.vw_dmc_dncl_line_user_id_coordination_datas",
    "lib.queries.get_statement",
    "app_pages.routing",
]

# =====================================================================
# pytest フィクスチャ
# =====================================================================

@pytest.fixture
def mock_snowflake():
    """Snowflake接続のモック"""
    with patch("pochilib.snowflake") as mock:
        yield mock

@pytest.fixture
def mock_llm():
    """LLM接続のモック"""
    with patch("pochilib.llm") as mock:
        yield mock

@pytest.fixture
def sample_acctid_df():
    """正常な acctid DataFrame（テストデータ: valid/valid_acctid_list.csv）"""
    import csv
    fixture_path = os.path.join(os.path.dirname(__file__), "fixtures", "valid", "valid_acctid_list.csv")
    return pd.read_csv(fixture_path)

@pytest.fixture
def sample_comnid_df():
    """正常な comnid DataFrame（テストデータ: valid/valid_comnid_list.csv）"""
    fixture_path = os.path.join(os.path.dirname(__file__), "fixtures", "valid", "valid_comnid_list.csv")
    return pd.read_csv(fixture_path)

@pytest.fixture
def sample_bascid_df():
    """正常な bascid DataFrame（テストデータ: valid/valid_bascid_list.csv）"""
    fixture_path = os.path.join(os.path.dirname(__file__), "fixtures", "valid", "valid_bascid_list.csv")
    return pd.read_csv(fixture_path)

@pytest.fixture
def sample_lineid_df():
    """正常な lineid DataFrame（テストデータ: valid/valid_lineid_list.csv）"""
    fixture_path = os.path.join(os.path.dirname(__file__), "fixtures", "valid", "valid_lineid_list.csv")
    return pd.read_csv(fixture_path)

@pytest.fixture
def invalid_acctid_df():
    """異常な acctid DataFrame（テストデータ: invalid/invalid_acctid_wrong_length.csv）"""
    fixture_path = os.path.join(os.path.dirname(__file__), "fixtures", "invalid", "invalid_acctid_wrong_length.csv")
    return pd.read_csv(fixture_path)

@pytest.fixture
def empty_df():
    """空の DataFrame（テストデータ: edge/edge_empty.csv）"""
    fixture_path = os.path.join(os.path.dirname(__file__), "fixtures", "edge", "edge_empty.csv")
    return pd.read_csv(fixture_path)
