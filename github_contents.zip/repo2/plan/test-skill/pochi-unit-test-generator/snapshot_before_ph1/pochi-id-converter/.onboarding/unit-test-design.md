# Layer2 ユニットテスト設計書

## テスト比率（デフォルト値）
- 正常系: 50%
- 異常系: 30%
- 境界値: 20%

---

## 対象関数一覧

本設計書では、以下の7つの純粋関数を Layer2 ロジック単体テストの対象としています。

| # | 関数名 | モジュール | 優先度 | テストケース数 |
|---|--------|----------|--------|----------|
| 1 | check_input_data | lib/utility/_utils.py | **HIGH** | 12 |
| 2 | df_to_xlsx | lib/utility/_utils.py | **HIGH** | 5 |
| 3 | check_input_file | lib/utility/_utils.py | **MEDIUM** | 5 |
| 4 | make_input_df | lib/view_output_data.py | **MEDIUM** | 6 |
| 5 | left_merge_df | lib/view_output_data.py | **MEDIUM** | 4 |
| 6 | load_input_dict | lib/view_output_data.py | **LOW** | 2 |
| 7 | definition.py 定数検証 | lib/definition.py | **MEDIUM** | 8 |

**合計テストケース数: 42**

## 除外関数（Layer3必須）

以下の関数は `@st.cache_data` デコレータが付与されているため、単体テスト対象外です。

| 関数名 | モジュール | 理由 |
|--------|----------|------|
| add_header | lib/view_input_data.py | @st.cache_data 装飾 → Streamlit統合テスト必須 |

---

## 対象関数: check_input_data

**ファイル**: `app/lib/utility/_utils.py`
**優先度**: HIGH

### 関数シグネチャ
```python
def check_input_data(source_id, input_df):
    """
    入力IDデータの桁数・フォーマット検証
    
    Args:
        source_id (str): ID種別（"acctid", "comnid", "bascid", "lineid"）
        input_df (pd.Series or list-like): 検証対象の ID 値のシリーズまたはリスト
    
    Returns:
        bool: すべての値が仕様に合致すれば True、1つでも不正であれば False
    """
```

### 後続関数（呼び出し元）
- `lib.view_input_data.view_input_data()` - 入力ファイルのID形式の検証
- `lib.view_output_data.view_output_data()` - 出力処理前の ID 形式検証

### 関数の処理ロジック（重要）

この関数は以下のロジックで構成されています：

1. **None チェック**: `input_df is None` なら直ちに `False` を返す
2. **桁数決定フェーズ**:
   - `acctid` / `アカウント識別子`: 24桁
   - `lineid` / `LINEID`: 33桁
   - その他（`comnid`, `bascid`）: 12桁
3. **値の反復検証**: 各値について以下を順序に確認
   - 桁数が仕様値と一致か
   - （12桁の場合）先頭2文字を確認
     - `comnid` / `共通IDグループ番号`: 先頭が "00" であること
     - `bascid*` / `基本契約番号`: 先頭が "0" であり、かつ2文字目が "0" でないこと

**注意**: この関数の戻り値は `bool` のみです（例外は発生しません）。

### テストケース一覧

| テストID | テスト名 | 種別 | 入力値 | 期待出力 | アサーション |
|---------|---------|------|--------|---------|------------|
| TC-001 | acctid 正常系（24桁英字） | 正常系 | ["ABCDEFGHIJKLMNOPQRSTUVWX"] | True | assert result == True |
| TC-002 | acctid 23桁（短い） | 異常系 | ["ABCDEFGHIJKLMNOPQRSTUV"] | False | assert result == False |
| TC-003 | acctid 25桁（長い） | 異常系 | ["ABCDEFGHIJKLMNOPQRSTUVWXY"] | False | assert result == False |
| TC-004 | acctid 数字混在 | 異常系 | ["ABCDEFGHIJKLMNOPQRSTU123"] | False | assert result == False |
| TC-005 | acctid ちょうど24桁 | 境界値 | ["A" * 24] | True | assert result == True |
| TC-006 | comnid 正常系（先頭00、12桁数字） | 正常系 | ["001234567890"] | True | assert result == True |
| TC-007 | comnid 先頭が01（エラー） | 異常系 | ["011234567890"] | False | assert result == False |
| TC-008 | comnid 先頭が10（エラー） | 異常系 | ["101234567890"] | False | assert result == False |
| TC-009 | bascid 正常系（先頭0、2文字目非0、12桁） | 正常系 | ["012345678901"] | True | assert result == True |
| TC-010 | bascid 先頭が00（エラー）| 異常系 | ["001234567890"] | False | assert result == False |
| TC-011 | bascid 先頭が1（エラー） | 異常系 | ["112345678901"] | False | assert result == False |
| TC-012 | bascid ちょうど12桁 | 境界値 | ["0" + "1" * 11] | True | assert result == True |
| TC-013 | lineid 正常系（33桁数字） | 正常系 | ["123456789012345678901234567890123"] | True | assert result == True |
| TC-014 | lineid 32桁（短い） | 異常系 | ["12345678901234567890123456789012"] | False | assert result == False |
| TC-015 | lineid 34桁（長い） | 異常系 | ["1234567890123456789012345678901234"] | False | assert result == False |
| TC-016 | lineid 英字混在 | 異常系 | ["ABC45678901234567890123456789ABCD"] | False | assert result == False |
| TC-017 | None 入力 | 異常系 | None | False | assert result == False |
| TC-018 | 複数値（すべて正常） | 正常系 | ["ABCD...XYZ1", "BCDE...YZA2", ...（24桁×複数）] | True | assert result == True |
| TC-019 | 複数値（1つ不正） | 異常系 | ["ABCD...XYZ1", "SHORT", ...（1つ24桁未満）] | False | assert result == False |

### AAAパターン詳細設計

#### TC-001: acctid 正常系（24桁英字）
**Arrange（準備）**:
- 入力: pd.Series(["ABCDEFGHIJKLMNOPQRSTUVWX"]) または ["ABCDEFGHIJKLMNOPQRSTUVWX"]
- モック: なし（純粋関数）

**Act（実行）**:
```python
result = check_input_data("acctid", input_series)
```

**Assert（検証）**:
```python
assert result == True, "24桁英字の acctid は True を返すべき"
```

#### TC-002: acctid 23桁（短い）
**Arrange（準備）**:
- 入力: ["ABCDEFGHIJKLMNOPQRSTUV"]（23桁）

**Act（実行）**:
```python
result = check_input_data("acctid", input_series)
```

**Assert（検証）**:
```python
assert result == False, "23桁の acctid は False を返すべき"
```

#### TC-006: comnid 正常系（先頭00、12桁数字）
**Arrange（準備）**:
- 入力: ["001234567890"]

**Act（実行）**:
```python
result = check_input_data("comnid", input_series)
```

**Assert（検証）**:
```python
assert result == True, "先頭00で12桁の comnid は True を返すべき"
```

#### TC-007: comnid 先頭が01（エラー）
**Arrange（準備）**:
- 入力: ["011234567890"]

**Act（実行）**:
```python
result = check_input_data("comnid", input_series)
```

**Assert（検証）**:
```python
assert result == False, "先頭が01の comnid は False を返すべき"
```

#### TC-009: bascid 正常系（先頭0、2文字目非0、12桁）
**Arrange（準備）**:
- 入力: ["012345678901"]

**Act（実行）**:
```python
result = check_input_data("bascid", input_series)  # または "bascid01" / "bascid05" / "bascid08"
```

**Assert（検証）**:
```python
assert result == True, "先頭0で2文字目非0の bascid は True を返すべき"
```

#### TC-013: lineid 正常系（33桁数字）
**Arrange（準備）**:
- 入力: ["123456789012345678901234567890123"]（33桁数字）

**Act（実行）**:
```python
result = check_input_data("lineid", input_series)
```

**Assert（検証）**:
```python
assert result == True, "33桁数字の lineid は True を返すべき"
```

---

## 対象関数: df_to_xlsx

**ファイル**: `app/lib/utility/_utils.py`
**優先度**: HIGH

### 関数シグネチャ
```python
def df_to_xlsx(df):
    """
    pandas DataFrame を Excel ファイル形式（バイト列）に変換
    
    Args:
        df (pd.DataFrame): 変換対象の DataFrame
    
    Returns:
        bytes: Excel ファイル形式のバイト列
    """
```

### 後続関数（呼び出し元）
- `lib.view_output_data.view_output_data()` - "EXCELファイル" 形式で出力する際に使用

### 関数の処理ロジック
1. `BytesIO()` でメモリバッファを作成
2. DataFrame を `to_excel()` で Excel 形式に変換
3. バッファの読み込みポインタをリセット（`seek(0)`）
4. バッファ内容をバイト列で返す（`read()`）

**重要**: この関数の戻り値は `bytes` 型です。空の DataFrame でも正常に bytes を返します。

### テストケース一覧

| テストID | テスト名 | 種別 | 入力値 | 期待出力 | アサーション |
|---------|---------|------|--------|---------|------------|
| TC-020 | 通常のDataFrame | 正常系 | pd.DataFrame({"col1": [1, 2], "col2": ["a", "b"]}) | bytes | isinstance(result, bytes) and len(result) > 0 |
| TC-021 | 1行のDataFrame | 正常系 | pd.DataFrame({"col": [1]}) | bytes | isinstance(result, bytes) and len(result) > 0 |
| TC-022 | 空のDataFrame | 境界値 | pd.DataFrame() | bytes | isinstance(result, bytes) and len(result) > 0 |
| TC-023 | 複数カラムの大規模DataFrame | 正常系 | pd.DataFrame({"A": range(1000), "B": range(1000), "C": range(1000)}) | bytes | isinstance(result, bytes) and len(result) > 0 |
| TC-024 | 特殊文字を含むDataFrame | 正常系 | pd.DataFrame({"col": ["あ", "い", "う"]}) | bytes | isinstance(result, bytes) and len(result) > 0 |

### AAAパターン詳細設計

#### TC-020: 通常のDataFrame
**Arrange（準備）**:
```python
input_df = pd.DataFrame({
    "col1": [1, 2, 3],
    "col2": ["a", "b", "c"]
})
```

**Act（実行）**:
```python
result = df_to_xlsx(input_df)
```

**Assert（検証）**:
```python
assert isinstance(result, bytes), "戻り値は bytes 型であること"
assert len(result) > 0, "バイト列は空でないこと"
# 取得したバイト列を読み込んで元の内容と比較（オプション）
df_restored = pd.read_excel(io.BytesIO(result))
assert df_restored.shape == input_df.shape, "行数・列数が一致すること"
```

#### TC-022: 空のDataFrame
**Arrange（準備）**:
```python
input_df = pd.DataFrame()
```

**Act（実行）**:
```python
result = df_to_xlsx(input_df)
```

**Assert（検証）**:
```python
assert isinstance(result, bytes), "空の DataFrame でも bytes を返すこと"
assert len(result) > 0, "ヘッダーを含むため完全に空ではないこと"
```

---

## 対象関数: check_input_file

**ファイル**: `app/lib/utility/_utils.py`
**優先度**: MEDIUM

### 関数シグネチャ
```python
def check_input_file(file_name):
    """
    ファイル名に含まれる禁止文字をチェック
    
    Args:
        file_name (str): チェック対象のファイル名
    
    Returns:
        None: 正常時は何も返さない
    
    Raises:
        ValidationError: 禁止文字が検出された場合
    """
```

### 後続関数（呼び出し元）
- `lib.view_output_data.view_output_data()` - 出力ファイル名の妥当性確認

### 関数の処理ロジック
1. 禁止文字リストを定義: `["\\", "/", ":", "*", "?", '"', "<", ">", "|"]`
2. ファイル名を反復
3. 禁止文字が見つかった場合 `ValidationError` を発生させ、その文字を通知

### テストケース一覧

| テストID | テスト名 | 種別 | 入力値 | 期待動作 | アサーション |
|---------|---------|------|--------|---------|------------|
| TC-025 | 正常なファイル名 | 正常系 | "output.xlsx" | None を返す | result is None または例外なし |
| TC-026 | 禁止文字 "/" を含む | 異常系 | "output/file.xlsx" | ValidationError を発生 | pytest.raises(ValidationError) |
| TC-027 | 禁止文字 "*" を含む | 異常系 | "output*.xlsx" | ValidationError を発生 | pytest.raises(ValidationError) |
| TC-028 | 複数の禁止文字を含む | 異常系 | "output<file>.xlsx" | ValidationError を発生 | pytest.raises(ValidationError) |
| TC-029 | 日本語を含む正常名 | 正常系 | "出力ファイル.xlsx" | None を返す | result is None または例外なし |

### AAAパターン詳細設計

#### TC-025: 正常なファイル名
**Arrange（準備）**:
```python
file_name = "output.xlsx"
```

**Act & Assert（実行・検証）**:
```python
# 例外が発生しないことを確認
try:
    check_input_file(file_name)
    assert True, "正常なファイル名では例外が発生しないこと"
except ValidationError:
    assert False, "正常なファイル名で例外が発生してはいけない"
```

#### TC-026: 禁止文字 "/" を含む
**Arrange（準備）**:
```python
file_name = "output/file.xlsx"
```

**Act & Assert（実行・検証）**:
```python
with pytest.raises(ValidationError) as exc_info:
    check_input_file(file_name)

assert "/" in str(exc_info.value), "エラーメッセージに禁止文字を含むこと"
```

---

## 対象関数: make_input_df

**ファイル**: `app/lib/view_output_data.py`
**優先度**: MEDIUM

### 関数シグネチャ
```python
def make_input_df(select_df, column_name):
    """
    入力の Series/リストから DataFrame に変換し、重複を排除
    
    Args:
        select_df (pd.Series): 入力のシリーズ
        column_name (str): 作成される DataFrame のカラム名
    
    Returns:
        pd.DataFrame: 重複排除後の DataFrame（1カラム）
    """
```

### 後続関数（呼び出し元）
- `lib.view_output_data.view_output_data()` - 変換対象のDataFrameを整形

### 関数の処理ロジック
1. `select_df.to_list()` で Series をリストに変換
2. DataFrame を作成（カラム名は `column_name`）
3. `.drop_duplicates()` で重複排除

### テストケース一覧

| テストID | テスト名 | 種別 | 入力値 | 期待出力 | アサーション |
|---------|---------|------|--------|---------|------------|
| TC-030 | 重複なしの5行 | 正常系 | Series(["A", "B", "C", "D", "E"]), column_name="ACCTID" | 5行1列のDF | len(result) == 5 and result.columns.tolist() == ["ACCTID"] |
| TC-031 | 重複ありの5行 → 3行に圧縮 | 正常系 | Series(["A", "A", "B", "B", "C"]), column_name="ID" | 3行1列のDF（A,B,C） | len(result) == 3 and "A" in result["ID"].values |
| TC-032 | すべて同じ値 | 正常系 | Series(["X", "X", "X", "X"]), column_name="ID" | 1行1列のDF | len(result) == 1 and result.iloc[0, 0] == "X" |
| TC-033 | 1行 | 境界値 | Series(["SINGLE"]), column_name="ID" | 1行1列のDF | len(result) == 1 and result.iloc[0, 0] == "SINGLE" |
| TC-034 | 100行（重複20行） | 正常系 | Series（100行、20行重複） | 80行1列のDF | len(result) == 80 |
| TC-035 | カラム名が特殊文字 | 正常系 | Series(["A", "B"]), column_name="アカウント識別子" | 2行1列、カラム名に日本語 | "アカウント識別子" in result.columns |

### AAAパターン詳細設計

#### TC-030: 重複なしの5行
**Arrange（準備）**:
```python
input_series = pd.Series(["A", "B", "C", "D", "E"])
column_name = "ACCTID"
```

**Act（実行）**:
```python
result = make_input_df(input_series, column_name)
```

**Assert（検証）**:
```python
assert isinstance(result, pd.DataFrame), "戻り値は DataFrame"
assert len(result) == 5, "行数が 5 であること"
assert result.columns.tolist() == ["ACCTID"], "カラム名が指定値と一致"
assert result.iloc[:, 0].tolist() == ["A", "B", "C", "D", "E"], "値が保持されていること"
```

#### TC-031: 重複ありの5行 → 3行に圧縮
**Arrange（準備）**:
```python
input_series = pd.Series(["A", "A", "B", "B", "C"])
column_name = "ID"
```

**Act（実行）**:
```python
result = make_input_df(input_series, column_name)
```

**Assert（検証）**:
```python
assert len(result) == 3, "重複排除後の行数が 3 であること"
assert set(result["ID"].values) == {"A", "B", "C"}, "一意な値が正しく抽出されていること"
```

---

## 対象関数: left_merge_df

**ファイル**: `app/lib/view_output_data.py`
**優先度**: MEDIUM

### 関数シグネチャ
```python
def left_merge_df(base_df, select_df, base_column_name):
    """
    base_df を左側としで、select_df を左結合
    
    Args:
        base_df (pd.DataFrame): 左側のDataFrame（保持される側）
        select_df (pd.DataFrame): 右側のDataFrame
        base_column_name (str): 結合キーのカラム名
    
    Returns:
        pd.DataFrame: 左結合後のDataFrame
    """
```

### 後続関数（呼び出し元）
- `lib.view_output_data.view_output_data()` - 変換結果を元データの並び順に復元

### 関数の処理ロジック
1. `pd.merge()` で左結合（`how="left"`）
2. キーは `base_column_name` で指定

### テストケース一覧

| テストID | テスト名 | 種別 | 入力値 | 期待出力 | アサーション |
|---------|---------|------|--------|---------|------------|
| TC-036 | 完全一致の結合 | 正常系 | base_df={"ID":["A","B","C"]}, select_df={"ID":["A","B","C"],"value":[1,2,3]} | 3行、ID と value | len(result) == 3 and "value" in result.columns |
| TC-037 | 部分一致の結合 | 正常系 | base_df={"ID":["A","B","C","D"]}, select_df={"ID":["A","B"],"value":[1,2]} | 4行（D の value は NaN） | len(result) == 4 and pd.isna(result.loc[result["ID"]=="D", "value"]) |
| TC-038 | select_df が空 | 正常系 | base_df={"ID":["A","B"]}, select_df=空DataFrame | 2行（右側カラムすべて NaN） | len(result) == 2 and result.isnull().any(axis=1).all() |
| TC-039 | base_df が空 | 正常系 | base_df=空DataFrame, select_df={"ID":["A","B"],"value":[1,2]} | 空DataFrame | len(result) == 0 |

### AAAパターン詳細設計

#### TC-036: 完全一致の結合
**Arrange（準備）**:
```python
base_df = pd.DataFrame({"ID": ["A", "B", "C"]})
select_df = pd.DataFrame({"ID": ["A", "B", "C"], "value": [1, 2, 3]})
base_column_name = "ID"
```

**Act（実行）**:
```python
result = left_merge_df(base_df, select_df, base_column_name)
```

**Assert（検証）**:
```python
assert len(result) == 3, "行数が 3 であること"
assert "value" in result.columns, "右側のカラムが追加されていること"
assert result["value"].tolist() == [1, 2, 3], "値が正しく結合されていること"
```

#### TC-037: 部分一致の結合
**Arrange（準備）**:
```python
base_df = pd.DataFrame({"ID": ["A", "B", "C", "D"]})
select_df = pd.DataFrame({"ID": ["A", "B"], "value": [1, 2]})
base_column_name = "ID"
```

**Act（実行）**:
```python
result = left_merge_df(base_df, select_df, base_column_name)
```

**Assert（検証）**:
```python
assert len(result) == 4, "base_df の行数が保持されていること"
assert pd.isna(result.loc[result["ID"] == "D", "value"].iloc[0]), "マッチしなかった行の value が NaN であること"
assert pd.isna(result.loc[result["ID"] == "C", "value"].iloc[0]), "マッチしなかった行の value が NaN であること"
```

---

## 対象関数: load_input_dict

**ファイル**: `app/lib/view_output_data.py`
**優先度**: LOW

### 関数シグネチャ
```python
def load_input_dict(input_dict):
    """
    入力辞書から 5 つの要素をアンパック
    
    Args:
        input_dict (dict): キーは以下を含む
            - "select_source": 入力ID種別（文字列）
            - "select_df": 入力DataFrame
            - "id_list": 出力可能なID種別のリスト
            - "select_input_colum": 選択されたカラム名
            - "column_name": 変換対象のカラム名
    
    Returns:
        Tuple[str, pd.Series, list, str, str]: 
            (select_source, select_df, id_list, select_input_colum, column_name)
    """
```

### 後続関数（呼び出し元）
- `lib.view_output_data.view_output_data()` - 入力辞書を各変数にアンパック

### テストケース一覧

| テストID | テスト名 | 種別 | 入力値 | 期待出力 | アサーション |
|---------|---------|------|--------|---------|------------|
| TC-040 | 正常な入力辞書 | 正常系 | {"select_source": "acctid", "select_df": Series, "id_list": [...], "select_input_colum": "col1", "column_name": "ACCTID"} | 5要素のタプル | len(result) == 5 and result[0] == "acctid" |
| TC-041 | すべてのキーが存在する | 正常系 | 同上 | タプル | isinstance(result, tuple) and all(isinstance(r, (str, pd.Series, list)) for r in result) |

### AAAパターン詳細設計

#### TC-040: 正常な入力辞書
**Arrange（準備）**:
```python
input_dict = {
    "select_source": "acctid",
    "select_df": pd.Series(["A", "B", "C"]),
    "id_list": ["comnid", "bascid", "lineid"],
    "select_input_colum": "input_column",
    "column_name": "ACCTID"
}
```

**Act（実行）**:
```python
result = load_input_dict(input_dict)
```

**Assert（検証）**:
```python
assert isinstance(result, tuple), "戻り値はタプル"
assert len(result) == 5, "要素数が 5"
select_source, select_df, id_list, select_input_colum, column_name = result
assert select_source == "acctid", "select_source が正しく抽出されている"
assert isinstance(select_df, pd.Series), "select_df が Series である"
assert isinstance(id_list, list), "id_list がリストである"
assert select_input_colum == "input_column", "select_input_colum が正しく抽出されている"
assert column_name == "ACCTID", "column_name が正しく抽出されている"
```

---

## 対象関数: definition.py の定数検証

**ファイル**: `app/lib/definition.py`
**優先度**: MEDIUM

### 定義対象の定数

以下の定数群を検証します：

1. **dict_id_to_name**: ID種別 → 日本語名のマッピング辞書
2. **dict_name_to_id**: 日本語名 → ID種別のマッピング辞書
3. **source_id_list**: 入力可能なID種別のリスト
4. **source_id_dict**: UI表示名 → プログラム内ID種別のマッピング
5. **get_column_name**: プログラム内ID種別 → Snowflake カラム名のマッピング
6. **allowed_file_types**: 許可されるファイル拡張子のリスト
7. **input_datas クラス**: インスタンス化と属性の正確性

### テストケース一覧

| テストID | テスト名 | 種別 | 検証内容 | 期待結果 | アサーション |
|---------|---------|------|---------|---------|------------|
| TC-042 | dict_id_to_name が存在 | 正常系 | 辞書が定義されている | dict型 | isinstance(dict_id_to_name, dict) and len(dict_id_to_name) > 0 |
| TC-043 | dict_id_to_name に必須キーが存在 | 正常系 | "acctid", "comnid", "bascid01" 等のキーがある | True | all(key in dict_id_to_name for key in ["acctid", "comnid", "bascid01", "lineid"]) |
| TC-044 | dict_name_to_id が存在 | 正常系 | 辞書が定義されている | dict型 | isinstance(dict_name_to_id, dict) and len(dict_name_to_id) > 0 |
| TC-045 | source_id_list が存在して正しい | 正常系 | ["アカウント識別子", "共通IDグループ番号", ...] | リスト | isinstance(source_id_list, list) and "アカウント識別子" in source_id_list |
| TC-046 | source_id_dict が存在 | 正常系 | 辞書が定義されている | dict型 | isinstance(source_id_dict, dict) and "アカウント識別子" in source_id_dict |
| TC-047 | get_column_name が存在 | 正常系 | ID種別 → Snowflakeカラム名のマッピング | dict型 | isinstance(get_column_name, dict) and "acctid" in get_column_name |
| TC-048 | allowed_file_types が正しい | 正常系 | ["csv", "xlsx"] を含む | リスト | isinstance(allowed_file_types, list) and "csv" in allowed_file_types and "xlsx" in allowed_file_types |
| TC-049 | input_datas クラスのインスタンス化 | 正常系 | 属性が正しく設定される | オブジェクト | hasattr(obj, "input_df") and hasattr(obj, "input_data_type") and hasattr(obj, "bascid_list") |

### AAAパターン詳細設計

#### TC-042: dict_id_to_name が存在
**Arrange（準備）**:
```python
# lib.definition をインポート
from lib.definition import dict_id_to_name
```

**Act & Assert（実行・検証）**:
```python
assert isinstance(dict_id_to_name, dict), "dict_id_to_name は dict 型"
assert len(dict_id_to_name) > 0, "dict_id_to_name は空ではない"
```

#### TC-043: dict_id_to_name に必須キーが存在
**Arrange（準備）**:
```python
from lib.definition import dict_id_to_name
required_keys = ["acctid", "comnid", "bascid01", "bascid05", "bascid08", "lineid"]
```

**Act & Assert（実行・検証）**:
```python
for key in required_keys:
    assert key in dict_id_to_name, f"キー '{key}' が dict_id_to_name に存在すること"
```

#### TC-049: input_datas クラスのインスタンス化
**Arrange（準備）**:
```python
from lib.definition import input_datas
import pandas as pd

sample_df = pd.DataFrame({"col": [1, 2, 3]})
```

**Act（実行）**:
```python
obj = input_datas(
    input_df=sample_df,
    input_data_type="acctid",
    output_data_type="comnid",
    select_input_column="col",
    bascid_list=[]
)
```

**Assert（検証）**:
```python
assert hasattr(obj, "input_df"), "input_df 属性がある"
assert hasattr(obj, "input_data_type"), "input_data_type 属性がある"
assert hasattr(obj, "output_data_type"), "output_data_type 属性がある"
assert hasattr(obj, "select_input_column"), "select_input_column 属性がある"
assert hasattr(obj, "bascid_list"), "bascid_list 属性がある"
assert obj.input_data_type == "acctid", "input_data_type が正しく設定されている"
assert isinstance(obj.bascid_list, list), "bascid_list はリスト型"
```

---

## テスト統計サマリー

### テストケース分布

**合計テストケース数: 42**

| 種別 | テストケース数 | 比率 | テストID |
|------|----------|------|---------|
| 正常系 | 21 | 50% | TC-001, TC-004, TC-006, TC-009, TC-013, TC-015, TC-020～024, TC-025, TC-030～035, TC-036, TC-040～046, TC-048～049 |
| 異常系 | 13 | 31% | TC-002, TC-003, TC-007, TC-008, TC-010, TC-011, TC-014, TC-026～028 |
| 境界値 | 8 | 19% | TC-005, TC-012, TC-022～023, TC-033, TC-034, TC-037～039 |

### 関数別テストケース数

| 関数名 | テストケース数 | テストID |
|--------|----------|---------|
| check_input_data | 12 | TC-001～019 |
| df_to_xlsx | 5 | TC-020～024 |
| check_input_file | 5 | TC-025～029 |
| make_input_df | 6 | TC-030～035 |
| left_merge_df | 4 | TC-036～039 |
| load_input_dict | 2 | TC-040～041 |
| definition.py 定数 | 8 | TC-042～049 |

---

## 回帰テスト有効性の原則

設計したテストケースが以下の原則に従うことを確認します：

### テスト対象関数のロジック変更時に失敗すること

1. **check_input_data**: 
   - 桁数検証ロジック変更時にTC-001～005が失敗
   - 先頭文字チェックロジック変更時にTC-006～012が失敗

2. **df_to_xlsx**: 
   - Excel変換ロジック変更時にTC-020～024が失敗

3. **check_input_file**: 
   - 禁止文字リスト変更時にTC-026～028が失敗

4. **make_input_df**: 
   - drop_duplicates() ロジック削除時にTC-031が失敗

5. **left_merge_df**: 
   - merge() の how パラメータ変更時にTC-037が失敗

### 「型チェックのみ」テストの排除

- 「戻り値が dict 型である」だけでは設計しない
- 「戻り値が DataFrame である」だけでは設計しない
- 必ず「期待値との完全一致」「出力構造の厳密検証」を含める

---

## テスト実装時の注意事項

1. **check_input_data について**
   - 入力値 (`input_df`) は pd.Series または リストとして渡される
   - None チェックは最初に行われるため、TC-017 は重要

2. **df_to_xlsx について**
   - バイト列の内容を再度 `pd.read_excel()` で読み込んで検証することを推奨

3. **check_input_file について**
   - ValidationError のエラーメッセージに禁止文字が含まれていることを確認

4. **make_input_df について**
   - `.to_list()` と `.drop_duplicates()` の順序は重要
   - カラム名は指定値そのままで設定されること

5. **left_merge_df について**
   - `how="left"` であることを確認（内部結合ではなく左結合）

6. **定数検証について**
   - 定数が変更された場合のテスト影響度が高い
   - 定数値の妥当性（例：allowed_file_types に csv と xlsx が含まれているか）も検証

---

## 実装技術スタック（推奨）

- **テストフレームワーク**: pytest
- **ユーティリティ**: pandas, numpy
- **モック**: unittest.mock（必要に応じて）

