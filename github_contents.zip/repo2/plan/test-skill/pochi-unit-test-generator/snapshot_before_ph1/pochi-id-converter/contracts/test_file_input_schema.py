"""
ファイル入力系スキーマ検証テスト

Layer1（データ契約テスト）
対象境界:
- csv_input: ユーザーがアップロードするCSVファイルのスキーマ
- xlsx_input: ユーザーがアップロードするExcelファイルのスキーマ
"""
import pytest
import pandas as pd
import io
from lib.utility._utils import check_input_file, ValidationError


class TestCsvInputSchema:
    """CSVファイル入力スキーマテスト"""

    # ===== 正常系テスト =====

    def test_csv_input_has_columns(self, sample_acctid_df):
        """正常: CSVファイルに1つ以上のカラムが存在"""
        assert len(sample_acctid_df.columns) > 0
        assert sample_acctid_df.shape[1] >= 1

    def test_csv_input_has_rows(self, sample_acctid_df):
        """正常: CSVファイルに1つ以上の行が存在"""
        assert len(sample_acctid_df) > 0
        assert sample_acctid_df.shape[0] >= 1

    def test_csv_input_dataframe_structure(self, sample_acctid_df):
        """正常: CSVファイルはDataFrameとしてロード可能"""
        assert isinstance(sample_acctid_df, pd.DataFrame)
        assert sample_acctid_df.shape[0] == 5  # テストデータは5行

    # ===== 異常系テスト =====

    # RISK: R006 (ファイル名検証)
    def test_csv_input_filename_with_backslash_invalid(self):
        """異常: ファイル名に バックスラッシュ を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test\\file.csv")
        assert "使用できない文字" in str(exc_info.value.message)
        assert "\\" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_csv_input_filename_with_forward_slash_invalid(self):
        """異常: ファイル名に スラッシュ を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test/file.csv")
        assert "使用できない文字" in str(exc_info.value.message)
        assert "/" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_csv_input_filename_with_colon_invalid(self):
        """異常: ファイル名に コロン を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test:file.csv")
        assert "使用できない文字" in str(exc_info.value.message)
        assert ":" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_csv_input_filename_with_asterisk_invalid(self):
        """異常: ファイル名に アスタリスク を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test*file.csv")
        assert "使用できない文字" in str(exc_info.value.message)
        assert "*" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_csv_input_filename_with_question_mark_invalid(self):
        """異常: ファイル名に クエスチョンマーク を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test?file.csv")
        assert "使用できない文字" in str(exc_info.value.message)
        assert "?" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_csv_input_filename_with_double_quote_invalid(self):
        """異常: ファイル名に ダブルクォート を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file('test"file.csv')
        assert "使用できない文字" in str(exc_info.value.message)
        assert '"' in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_csv_input_filename_with_less_than_invalid(self):
        """異常: ファイル名に < を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test<file.csv")
        assert "使用できない文字" in str(exc_info.value.message)
        assert "<" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_csv_input_filename_with_greater_than_invalid(self):
        """異常: ファイル名に > を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test>file.csv")
        assert "使用できない文字" in str(exc_info.value.message)
        assert ">" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_csv_input_filename_with_pipe_invalid(self):
        """異常: ファイル名に パイプ を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test|file.csv")
        assert "使用できない文字" in str(exc_info.value.message)
        assert "|" in str(exc_info.value.message)

    # ===== 境界値テスト =====

    def test_csv_input_filename_valid_simple(self):
        """境界: シンプルなファイル名は許可"""
        try:
            check_input_file("testfile.csv")
        except ValidationError:
            pytest.fail("シンプルなファイル名がValidationErrorを発生させた")

    def test_csv_input_filename_valid_with_numbers(self):
        """境界: ファイル名に数字を含む場合"""
        try:
            check_input_file("test123file.csv")
        except ValidationError:
            pytest.fail("数字を含むファイル名がValidationErrorを発生させた")

    def test_csv_input_filename_valid_with_underscore(self):
        """境界: ファイル名にアンダースコアを含む場合"""
        try:
            check_input_file("test_file.csv")
        except ValidationError:
            pytest.fail("アンダースコアを含むファイル名がValidationErrorを発生させた")

    def test_csv_input_filename_valid_with_hyphen(self):
        """境界: ファイル名にハイフンを含む場合"""
        try:
            check_input_file("test-file.csv")
        except ValidationError:
            pytest.fail("ハイフンを含むファイル名がValidationErrorを発生させた")

    def test_csv_input_filename_valid_with_dot(self):
        """境界: ファイル名にドット（拡張子以外）を含む場合"""
        try:
            check_input_file("test.file.csv")
        except ValidationError:
            pytest.fail("ドットを含むファイル名がValidationErrorを発生させた")

    def test_csv_input_filename_valid_with_japanese(self):
        """境界: ファイル名に日本語を含む場合"""
        try:
            check_input_file("テストfile.csv")
        except ValidationError:
            pytest.fail("日本語を含むファイル名がValidationErrorを発生させた")

    def test_csv_input_filename_valid_long_name(self):
        """境界: 長いファイル名の場合"""
        try:
            long_name = "a" * 100 + ".csv"
            check_input_file(long_name)
        except ValidationError:
            pytest.fail("長いファイル名がValidationErrorを発生させた")


class TestXlsxInputSchema:
    """Excelファイル入力スキーマテスト"""

    # ===== 正常系テスト =====

    def test_xlsx_input_has_columns(self, sample_acctid_df):
        """正常: Excelファイルに1つ以上のカラムが存在"""
        assert len(sample_acctid_df.columns) > 0
        assert sample_acctid_df.shape[1] >= 1

    def test_xlsx_input_has_rows(self, sample_acctid_df):
        """正常: Excelファイルに1つ以上の行が存在"""
        assert len(sample_acctid_df) > 0
        assert sample_acctid_df.shape[0] >= 1

    def test_xlsx_input_dataframe_structure(self, sample_acctid_df):
        """正常: ExcelファイルはDataFrameとしてロード可能"""
        assert isinstance(sample_acctid_df, pd.DataFrame)

    # ===== 異常系テスト =====

    # RISK: R006 (ファイル名検証)
    def test_xlsx_input_filename_with_backslash_invalid(self):
        """異常: ファイル名に バックスラッシュ を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test\\file.xlsx")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_xlsx_input_filename_with_forward_slash_invalid(self):
        """異常: ファイル名に スラッシュ を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test/file.xlsx")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_xlsx_input_filename_with_colon_invalid(self):
        """異常: ファイル名に コロン を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test:file.xlsx")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_xlsx_input_filename_with_asterisk_invalid(self):
        """異常: ファイル名に アスタリスク を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test*file.xlsx")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_xlsx_input_filename_with_question_mark_invalid(self):
        """異常: ファイル名に クエスチョンマーク を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test?file.xlsx")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_xlsx_input_filename_with_double_quote_invalid(self):
        """異常: ファイル名に ダブルクォート を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file('test"file.xlsx')
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_xlsx_input_filename_with_less_than_invalid(self):
        """異常: ファイル名に < を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test<file.xlsx")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_xlsx_input_filename_with_greater_than_invalid(self):
        """異常: ファイル名に > を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test>file.xlsx")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006 (ファイル名検証)
    def test_xlsx_input_filename_with_pipe_invalid(self):
        """異常: ファイル名に パイプ を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test|file.xlsx")
        assert "使用できない文字" in str(exc_info.value.message)

    # ===== 境界値テスト =====

    def test_xlsx_input_filename_valid_simple(self):
        """境界: シンプルなファイル名は許可"""
        try:
            check_input_file("testfile.xlsx")
        except ValidationError:
            pytest.fail("シンプルなファイル名がValidationErrorを発生させた")

    def test_xlsx_input_filename_valid_with_numbers(self):
        """境界: ファイル名に数字を含む場合"""
        try:
            check_input_file("test123file.xlsx")
        except ValidationError:
            pytest.fail("数字を含むファイル名がValidationErrorを発生させた")

    def test_xlsx_input_filename_valid_with_underscore(self):
        """境界: ファイル名にアンダースコアを含む場合"""
        try:
            check_input_file("test_file.xlsx")
        except ValidationError:
            pytest.fail("アンダースコアを含むファイル名がValidationErrorを発生させた")

    def test_xlsx_input_filename_valid_with_hyphen(self):
        """境界: ファイル名にハイフンを含む場合"""
        try:
            check_input_file("test-file.xlsx")
        except ValidationError:
            pytest.fail("ハイフンを含むファイル名がValidationErrorを発生させた")

    def test_xlsx_input_filename_valid_with_dot(self):
        """境界: ファイル名にドット（拡張子以外）を含む場合"""
        try:
            check_input_file("test.file.xlsx")
        except ValidationError:
            pytest.fail("ドットを含むファイル名がValidationErrorを発生させた")
