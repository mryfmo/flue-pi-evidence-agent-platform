"""
ビジネスルール検証テスト

Layer1（データ契約テスト）
対象ビジネスルール:
- BR-001 ～ BR-020: acctid/comnid/bascid/lineid フォーマット検証、
  Snowflakeフィルタ条件、基本契約番号制約、ファイル拡張子制限等
"""
import pytest
import pandas as pd
from lib.utility._utils import check_input_data, check_input_file, ValidationError
from lib.definition import allowed_file_types, source_id_dict, input_datas


class TestBusinessRuleAcctidFormat:
    """BR-001: acctid フォーマット検証"""

    # RISK: R001
    def test_br001_acctid_valid_24_alpha(self):
        """BR-001 正常: acctid は24桁英字"""
        valid_acctid = pd.Series(["AAAAAAAAAAAAAAAAAAAAA111"])
        result = check_input_data("acctid", valid_acctid)
        assert result is True

    # RISK: R001
    def test_br001_acctid_invalid_short(self):
        """BR-001 異常: acctid が23桁（不正な桁数）"""
        invalid_short = pd.Series(["AAAAAAAAAAAAAAAAAAAAA12"])
        result = check_input_data("acctid", invalid_short)
        assert result is False

    # RISK: R001
    def test_br001_acctid_invalid_long(self):
        """BR-001 異常: acctid が25桁（不正な桁数）"""
        invalid_long = pd.Series(["AAAAAAAAAAAAAAAAAAAAA12345"])
        result = check_input_data("acctid", invalid_long)
        assert result is False

    # RISK: R001
    def test_br001_acctid_invalid_with_digit(self):
        """BR-001 異常: acctid が25桁（数字含む、不正な桁数）"""
        invalid_with_digit = pd.Series(["AAAAAAAAAAAAAAAAAAAAA12AB"])
        result = check_input_data("acctid", invalid_with_digit)
        assert result is False


class TestBusinessRuleComnidFormat:
    """BR-002: comnid フォーマット検証"""

    # RISK: R001
    def test_br002_comnid_valid_12_digit_prefix_00(self):
        """BR-002 正常: comnid は12桁、先頭00"""
        valid_comnid = pd.Series(["000123456789"])
        result = check_input_data("comnid", valid_comnid)
        assert result is True

    # RISK: R001
    def test_br002_comnid_invalid_prefix_01(self):
        """BR-002 異常: comnid の先頭が00ではない（01）"""
        invalid_prefix = pd.Series(["011234567890"])
        result = check_input_data("comnid", invalid_prefix)
        assert result is False

    # RISK: R001
    def test_br002_comnid_invalid_short(self):
        """BR-002 異常: comnid が11桁（短すぎる）"""
        invalid_short = pd.Series(["0012345678"])
        result = check_input_data("comnid", invalid_short)
        assert result is False

    # RISK: R001
    def test_br002_comnid_invalid_with_alpha(self):
        """BR-002 異常: comnid に英字を含む"""
        invalid_with_alpha = pd.Series(["00ABC123456"])
        result = check_input_data("comnid", invalid_with_alpha)
        assert result is False


class TestBusinessRuleBascidFormat:
    """BR-003: bascid フォーマット検証"""

    # RISK: R001
    def test_br003_bascid_valid_12_digit_prefix_01(self):
        """BR-003 正常: bascid は12桁、先頭0、2文字目非0（01）"""
        valid_bascid = pd.Series(["010123456789"])
        result = check_input_data("bascid", valid_bascid)
        assert result is True

    # RISK: R001
    def test_br003_bascid_invalid_prefix_00(self):
        """BR-003 異常: bascid の先頭が00（共通ID形式）"""
        invalid_prefix = pd.Series(["001234567890"])
        result = check_input_data("bascid", invalid_prefix)
        assert result is False

    # RISK: R001
    def test_br003_bascid_invalid_prefix_no_0(self):
        """BR-003 異常: bascid の先頭が0ではない"""
        invalid_prefix = pd.Series(["112345678901"])
        result = check_input_data("bascid", invalid_prefix)
        assert result is False

    # RISK: R001
    def test_br003_bascid_invalid_short(self):
        """BR-003 異常: bascid が11桁（短すぎる）"""
        invalid_short = pd.Series(["0112345678"])
        result = check_input_data("bascid", invalid_short)
        assert result is False


class TestBusinessRuleLineIdFormat:
    """BR-004: lineid フォーマット検証"""

    # RISK: R001
    def test_br004_lineid_valid_33_digit(self):
        """BR-004 正常: lineid は33桁数字"""
        valid_lineid = pd.Series(["123456789012345678901234567890123"])
        result = check_input_data("lineid", valid_lineid)
        assert result is True

    # RISK: R001
    def test_br004_lineid_invalid_short(self):
        """BR-004 異常: lineid が32桁（短すぎる）"""
        invalid_short = pd.Series(["12345678901234567890123456789012"])
        result = check_input_data("lineid", invalid_short)
        assert result is False

    # RISK: R001
    def test_br004_lineid_invalid_long(self):
        """BR-004 異常: lineid が34桁（長すぎる）"""
        invalid_long = pd.Series(["12345678901234567890123456789012345"])
        result = check_input_data("lineid", invalid_long)
        assert result is False

    # RISK: R001
    def test_br004_lineid_invalid_with_alpha(self):
        """BR-004 異常: lineid が34桁（英字含む）"""
        invalid_with_alpha = pd.Series(["123456789012345678901234567890123A"])
        result = check_input_data("lineid", invalid_with_alpha)
        assert result is False


class TestBusinessRuleFileValidation:
    """BR-013/BR-014: ファイル拡張子・ファイル名の制限"""

    # RISK: R006
    def test_br013_allowed_file_extensions_are_csv_xlsx(self):
        """BR-013 正常: ファイル拡張子として csv と xlsx が定義されている"""
        assert "csv" in allowed_file_types
        assert "xlsx" in allowed_file_types
        assert len(allowed_file_types) == 2

    # RISK: R006
    def test_br014_filename_with_backslash_invalid(self):
        """BR-014 異常: ファイル名に \\ を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test\\file.csv")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006
    def test_br014_filename_with_forward_slash_invalid(self):
        """BR-014 異常: ファイル名に / を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test/file.csv")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006
    def test_br014_filename_with_colon_invalid(self):
        """BR-014 異常: ファイル名に : を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test:file.csv")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006
    def test_br014_filename_with_asterisk_invalid(self):
        """BR-014 異常: ファイル名に * を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test*file.csv")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006
    def test_br014_filename_with_question_mark_invalid(self):
        """BR-014 異常: ファイル名に ? を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test?file.csv")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006
    def test_br014_filename_with_double_quote_invalid(self):
        """BR-014 異常: ファイル名に \" を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file('test"file.csv')
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006
    def test_br014_filename_with_less_than_invalid(self):
        """BR-014 異常: ファイル名に < を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test<file.csv")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006
    def test_br014_filename_with_greater_than_invalid(self):
        """BR-014 異常: ファイル名に > を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test>file.csv")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006
    def test_br014_filename_with_pipe_invalid(self):
        """BR-014 異常: ファイル名に | を含む"""
        with pytest.raises(ValidationError) as exc_info:
            check_input_file("test|file.csv")
        assert "使用できない文字" in str(exc_info.value.message)

    # RISK: R006
    def test_br014_filename_valid_simple(self):
        """BR-014 正常: シンプルなファイル名は許可"""
        try:
            check_input_file("testfile.csv")
        except ValidationError:
            pytest.fail("シンプルなファイル名がValidationErrorを発生させた")

    # RISK: R006
    def test_br014_filename_valid_with_underscore(self):
        """BR-014 正常: ファイル名にアンダースコアを含む"""
        try:
            check_input_file("test_file.csv")
        except ValidationError:
            pytest.fail("アンダースコアを含むファイル名がValidationErrorを発生させた")

    # RISK: R006
    def test_br014_filename_valid_with_hyphen(self):
        """BR-014 正常: ファイル名にハイフンを含む"""
        try:
            check_input_file("test-file.csv")
        except ValidationError:
            pytest.fail("ハイフンを含むファイル名がValidationErrorを発生させた")


class TestBusinessRuleDataDefinition:
    """BR-001～BR-004 に関連する定義の検証"""

    # RISK: R015 (definition.py 定数の不整合)
    def test_source_id_dict_coverage(self):
        """source_id_dict に必要なID種別が定義されている"""
        required_keys = [
            "アカウント識別子",
            "共通IDグループ番号",
            "基本契約番号(01_携帯事業)",
            "基本契約番号(05_CF事業)",
            "基本契約番号(08_会員事業)",
            "LINEID"
        ]
        for key in required_keys:
            assert key in source_id_dict, f"{key} が source_id_dict に定義されていない"

    # RISK: R015 (definition.py 定数の不整合)
    def test_source_id_dict_values_are_valid(self):
        """source_id_dict の値がすべて有効なID種別"""
        valid_values = ["acctid", "comnid", "bascid", "bascid01", "bascid05", "bascid08", "lineid"]
        for key, value in source_id_dict.items():
            assert value in valid_values, f"無効な値: {value}"

    # RISK: R015 (definition.py 定数の不整合)
    def test_acctid_maps_to_acctid(self):
        """アカウント識別子は acctid にマップ"""
        assert source_id_dict["アカウント識別子"] == "acctid"

    # RISK: R015 (definition.py 定数の不整合)
    def test_comnid_maps_to_comnid(self):
        """共通IDグループ番号は comnid にマップ"""
        assert source_id_dict["共通IDグループ番号"] == "comnid"

    # RISK: R015 (definition.py 定数の不整合)
    def test_bascid_01_maps_to_bascid01(self):
        """基本契約番号(01_携帯事業) は bascid01 にマップ"""
        assert source_id_dict["基本契約番号(01_携帯事業)"] == "bascid01"

    # RISK: R015 (definition.py 定数の不整合)
    def test_bascid_05_maps_to_bascid05(self):
        """基本契約番号(05_CF事業) は bascid05 にマップ"""
        assert source_id_dict["基本契約番号(05_CF事業)"] == "bascid05"

    # RISK: R015 (definition.py 定数の不整合)
    def test_bascid_08_maps_to_bascid08(self):
        """基本契約番号(08_会員事業) は bascid08 にマップ"""
        assert source_id_dict["基本契約番号(08_会員事業)"] == "bascid08"

    # RISK: R015 (definition.py 定数の不整合)
    def test_lineid_maps_to_lineid(self):
        """LINEID は lineid にマップ"""
        assert source_id_dict["LINEID"] == "lineid"


class TestBusinessRuleInputDatasClass:
    """input_datas クラスのビジネスルール検証"""

    def test_input_datas_class_instantiation(self):
        """input_datas クラスのインスタンス化が可能"""
        sample_df = pd.DataFrame({"col1": ["value1", "value2"]})
        instance = input_datas(
            input_df=sample_df,
            input_data_type="acctid",
            output_data_type="comnid",
            select_input_column="col1",
            bascid_list=[]
        )
        assert instance.input_data_type == "acctid"
        assert instance.output_data_type == "comnid"

    def test_input_datas_class_with_bascid_list(self):
        """input_datas クラスは bascid_list をサポート"""
        sample_df = pd.DataFrame({"col1": ["value1", "value2"]})
        instance = input_datas(
            input_df=sample_df,
            input_data_type="acctid",
            output_data_type="bascid01",
            select_input_column="col1",
            bascid_list=["01", "05", "08"]
        )
        assert instance.bascid_list == ["01", "05", "08"]

    def test_input_datas_class_default_bascid_list(self):
        """input_datas クラスの bascid_list デフォルト値は空リスト"""
        sample_df = pd.DataFrame({"col1": ["value1", "value2"]})
        instance = input_datas(
            input_df=sample_df,
            input_data_type="acctid",
            output_data_type="comnid",
            select_input_column="col1"
        )
        assert instance.bascid_list == []


class TestBusinessRuleNullValueHandling:
    """BR-010: NULL値処理（左結合保持）"""

    # RISK: R008
    def test_br010_left_join_preserves_input_rows(self):
        """BR-010 正常: 変換結果がNULLでも入力行は保持される"""
        input_df = pd.DataFrame({
            "input_id": ["ID1", "ID2", "ID3"]
        })
        output_df = pd.DataFrame({
            "input_id": ["ID1", "ID2", "ID3"],
            "output_id": ["OUT1", None, "OUT3"]
        })
        # 左結合により入力行数と出力行数が一致
        assert len(input_df) == len(output_df)
        assert output_df["input_id"].notna().all()
        assert output_df["output_id"].isna().any()

    # RISK: R008
    def test_br010_partial_match_null_in_output(self):
        """BR-010 正常: 部分的にマッチしない場合、出力はNULL"""
        input_df = pd.DataFrame({
            "id": ["A", "B", "C"]
        })
        # Bは対応なし
        merge_result = pd.DataFrame({
            "id": ["A", "B", "C"],
            "converted": ["X", None, "Z"]
        })
        assert merge_result["converted"].isna().any()
        assert merge_result["id"].notna().all()
