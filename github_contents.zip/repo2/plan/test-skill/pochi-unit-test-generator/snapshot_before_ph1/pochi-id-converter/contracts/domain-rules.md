# ドメインルール

## 概要

ID変換システム（pochi-id-converter）のビジネスドメインにおけるルール定義書です。各ID種別の仕様、変換ルール、データ品質に関する要件を記載します。

---

## 1. ID種別の定義と制約

### 1.1 アカウント識別子（acctid / KK_ACCTID）

**定義**
- 顧客のアカウント識別子
- 別名：KK_ACCTID（Snowflakeテーブルのカラム名）

**形式**
- 桁数：24桁（固定）
- 文字種：英字大文字のみ（A-Z）
- 例：`AAAAAAAAAAAAAAAAAAAAA111`

**検証ルール**
```
len(value) == 24 AND value.isalpha() == True AND value.isupper() == True
```

**データソース**
- VW_ADM_DNCL_COMNID_INTEGRATION.KK_ACCTID
- VW_DMC_DNCL_LINE_USER_ID_COORDINATION_DATA.ACCTID
- VW_DMC_DNCL_LINE_FRIEND_LIST.ACCTID

**ビジネス的意味**
顧客を一意に識別する基本的なID。複数のビジネス区分（携帯・CF・会員）に関連付けられます。

---

### 1.2 共通IDグループ番号（comnid / COMNID）

**定義**
- 複数のID体系を統合するためのグループID
- 別名：COMNID（Snowflakeテーブルのカラム名）

**形式**
- 桁数：12桁（固定）
- 文字型：数字のみ（0-9）
- 先頭2桁：必ず『00』で固定
- 例：`000123456789`

**検証ルール**
```
len(value) == 12 AND value.startswith('00') AND value.isdigit() == True
```

**データソース**
- VW_ADM_DNCL_COMNID_INTEGRATION.COMNID

**ビジネス的意味**
複数のID変換処理における中心的なハブIDとして機能します。acctid、bascid、lineid 間の変換の中継点です。

---

### 1.3 基本契約番号（bascid / KK_ACCOUNT_BASCID / BASCID_KI）

**定義**
- 事業契約を識別するID
- 事業区分によって異なるカラムに格納：
  - 事業区分01・05：KK_ACCOUNT_BASCID
  - 事業区分08：BASCID_KI

**形式**
- 桁数：12桁（固定）
- 文字型：数字のみ（0-9）
- 先頭1桁：『0』で固定
- 2文字目：『0』以外（1-9）で固定
- 例：`012345678901`

**検証ルール**
```
len(value) == 12 AND value[0] == '0' AND value[1] != '0' AND value.isdigit() == True
```

**事業区分マッピング**
| 事業区分 | 説明 | テーブルカラム |
|---------|------|----------------|
| 01 | 携帯事業 | KK_ACCOUNT_BASCID |
| 05 | CF事業 | KK_ACCOUNT_BASCID |
| 08 | 会員事業 | BASCID_KI |

**データソース**
- VW_ADM_DNCL_COMNID_INTEGRATION.KK_ACCOUNT_BASCID（01,05用）
- VW_ADM_DNCL_COMNID_INTEGRATION.BASCID_KI（08用）

**ビジネス的意味**
特定の事業区分における契約の基本単位です。複数の事業区分への変換時には、各事業区分に対応した値が異なります。

---

### 1.4 LINE User ID（lineid / LINE_UID）

**定義**
- LINE連携システムにおけるユーザーID
- 別名：LINE_UID（Snowflakeテーブルのカラム名）

**形式**
- 桁数：33桁（固定）
- 文字型：数字のみ（0-9）
- 例：`123456789012345678901234567890123`

**検証ルール**
```
len(value) == 33 AND value.isdigit() == True
```

**データソース**
- VW_DMC_DNCL_LINE_USER_ID_COORDINATION_DATA.LINE_UID
- VW_DMC_DNCL_LINE_FRIEND_LIST.LINE_USER_ID

**ビジネス的意味**
LINE連携（CRM連携）を通じた顧客認識の基本ID。acctidとの連携が必須です。

---

## 2. 変換モードの一覧

### 2.1 許可される変換パターン

基本的なルール：
- **任意のIDから任意のIDへの変換が可能**ですが、データソースの利用可能性に依存します

| 入力ID | 変換先ID | 仕様 | 備考 |
|--------|---------|------|------|
| acctid | comnid | 1:1変換 | COMNID統合テーブル利用 |
| acctid | bascid | 複数事業区分対応 | 01/05/08の事業区分指定必須 |
| acctid | lineid | 1:1変換 | LINE連携テーブル利用 |
| comnid | acctid | 1:1変換 | COMNID統合テーブル利用 |
| comnid | bascid | 複数事業区分対応 | 01/05/08の事業区分指定必須 |
| comnid | lineid | 1:1変換 | acctidを中継 |
| bascid | acctid | 1:1変換 | 事業区分指定必須（逆変換） |
| bascid | comnid | 1:1変換 | 事業区分指定必須（逆変換） |
| bascid | lineid | 1:1変換 | acctidを中継 |
| lineid | acctid | 1:1変換 | LINE連携テーブル利用 |
| lineid | comnid | 1:1変換 | acctidを中継 |
| lineid | bascid | 複数事業区分対応 | acctidを中継、事業区分指定必須 |

### 2.2 bascid（基本契約番号）変換の特殊仕様

**複数事業区分への同時変換**
- ユーザーがチェックボックスで複数事業区分（01/05/08）を選択可能
- 選択した事業区分の数だけ出力カラムが動的に生成される
- 非選択の事業区分はカラムが出力されない

**例**
- 01と05を選択 → 出力カラム：『基本契約番号(01_携帯事業)』『基本契約番号(05_CF事業)』
- 08のみ選択 → 出力カラム：『基本契約番号(08_会員事業)』

**bascid05特有のルール**
- bascid05 ↔ 他のID間での変換は**2段階変換**を経由
- パターン例：acctid → comnid → bascid05（順方向）
- この理由：bascid05のデータ構造がcomnidとの中間マッピングを要する

---

## 3. データ品質ルール

### 3.1 基準日フィルタ

**COMNID統合テーブル（VW_ADM_DNCL_COMNID_INTEGRATION）**
- フィルタ条件：`LAK_PTK_CRITERIA_DAY == (現在日時 - 5日)`
- 理由：データのウォーミングアップ期間を考慮（LakeHouse 特有のSLA）

**LINE連携テーブル（VW_DMC_DNCL_LINE_USER_ID_COORDINATION_DATA）**
- フィルタ条件：`LAKPTK_STANDARD_NENGAPPI == (現在日時 - 2日)`
- 理由：LINE連携データの最短ラグを考慮

### 3.2 完了レコードの条件

**COMNID統合テーブルのみに適用**
- フィルタ条件：`REGULAR_INCOMPLETE_JUDGMENT_CLASSIFICATION == '0'`
- 区分値の意味：
  - `'0'` = 完了状態（変換対象）
  - `'1'` = 未完了状態（除外対象）

### 3.3 連携フラグの条件

**LINE連携テーブルのみに適用**
- フィルタ条件：`ACCOUNT_COORDINATION_FLAG == 1`
- 含義：acctidとLINEアカウントの連携確認済み状態

### 3.4 ビジネスアカウント ID の固定値

**LINE連携テーブルに適用**
- 固定値：`LINE_BUSINESS_ACCOUNT == '1654296328'`（特定のビジネスアカウント）
- 固定値：`CHNL_ID == '1654296328'`（特定のチャネルID）
- 理由：特定の公式LINE アカウント（docomo's公式）との連携のみを対象

### 3.5 重複排除ロジック

**複数の変換候補が存在する場合の選択ルール**

```sql
ROW_NUMBER() OVER (
    PARTITION BY join_column
    ORDER BY RECORD_UPDATE_DATE DESC, target_column DESC
) = 1
```

**選択基準**（優先順位）
1. 更新日付が新しい（RECORD_UPDATE_DATE DESC）
2. 対象列の値が大きい（target_column DESC）

**目的**：最新かつ最優先される変換結果を1件のみ選択

### 3.6 NULL値の処理

**変換結果がNULLの場合**
- 処理：左結合（LEFT OUTER JOIN）で元データの行を保持
- 結果：変換対象が見つからなかった行も出力に含まれ、変換結果カラムはNULL

**例**
- 入力行：['A', 'B', 'C']
- 変換可能：['A', 'B'] のみ
- 出力行：[('A', 'X'), ('B', 'Y'), ('C', NULL)]

### 3.7 入力データの重複排除

**処理タイミング**：ユーザーアップロード後、変換実行前

**実装**：`pd.DataFrame.drop_duplicates()`を指定カラムに適用

**効果**：ユーザー入力に重複ID値が含まれていた場合、1件に統合される

---

## 4. Snowflake テーブルのビジネス的意味

### 4.1 VW_ADM_DNCL_COMNID_INTEGRATION

**位置づけ**：ID統合の中心テーブル

**含有情報**
- acctid ↔ comnid ↔ bascid（事業区分別）のマッピング
- 事業区分情報（JIGYO_KUBUN）
- 完了状態フラグ

**ビジネス用途**
- ID間の主要な相互変換に利用
- 複数の契約形態（01/05/08）を統一的に管理

### 4.2 VW_DMC_DNCL_LINE_USER_ID_COORDINATION_DATA

**位置づけ**：acctid ↔ LINE User ID のマッピング

**含有情報**
- acctidとLINE User IDの対応関係
- 連携フラグ（ACCOUNT_COORDINATION_FLAG）
- LINE ビジネスアカウント識別子

**ビジネス用途**
- CRM連携：LINE公式アカウントでの顧客認識
- LINE連携機能の基盤

### 4.3 VW_DMC_DNCL_LINE_FRIEND_LIST

**位置づけ**：LINE フレンド関係情報

**含有情報**
- LINE User ID と acctid のフレンドシップ関係
- チャネルID（CHNL_ID）

**ビジネス用途**
- LINE友だちリスト管理
- LINE連携テーブルとの結合で完全な LINE ユーザー認識を実現

---

## 5. ファイルアップロード仕様

### 5.1 許可するファイル形式

- **CSV形式**（.csv）
- **Excel形式**（.xlsx）

### 5.2 許可する文字コード（CSV）

- UTF-8
- UTF-8-SIG
- Shift-JIS
- EUC-JP
- CP932（Windows-31J）

**特記**：ユーザーは自動判定結果を上書き可能（Expanderで非表示）

### 5.3 ファイル名の禁止文字

以下の文字を含むファイル名は受け入れ不可：
```
\ / : * ? " < > |
```

**理由**：Windows ファイルシステムの制限との互換性維持

### 5.4 出力ファイルの形式選択

**1,000,000件未満**
- CSV・Excel から選択可能

**1,000,000件以上**
- CSV形式のみ（Excel の行数上限制限に準拠）

---

## 6. セッション管理とキャッシュ戦略

### 6.1 ファイルアップロード時の初期化

**トリガー**：新しいファイルがアップロードされた場合

**初期化対象**
```python
convert = False
convert_done = False
get_output = None
output_df_culums_num = None
output_file_name = None
output_file = None
output_file_url = None
```

**目的**：前回の変換結果を完全にリセットし、新ファイルでの処理を開始

### 6.2 変換先ID変更時の初期化

**トリガー**：変換先のID選択が変更された場合

**初期化内容**：同上

**目的**：変換仕様の変更に応じて前回結果をクリア

### 6.3 キャッシュ機構

**add_header関数**
- `@st.cache_data()` デコレータで装飾
- 同じ入力DataFrameは2回目以降キャッシュから返却
- ユーザーがスクリプトを再実行してもキャッシュが有効

---

## 7. エラーハンドリング戦略

### 7.1 ファイル読込エラー

| エラー種別 | トリガー条件 | ハンドリング |
|----------|----------|------------|
| MemoryError | 大きいファイル | ErrorMessage.memory_error() 表示 |
| UnicodeDecodeError | 不正な文字コード | ErrorMessage.decode_error() 表示 |
| XLRDError | 暗号化Excel | ErrorMessage.file_lock_error() 表示 |
| ValidationError | ファイル名に禁止文字 | check_input_file() で例外発生 |

### 7.2 バリデーションエラー

| エラー項目 | 検証関数 | メッセージ |
|----------|--------|---------|
| acctid形式 | check_input_data('acctid') | ErrorMessage.acctid_input_error() |
| comnid形式 | check_input_data('comnid') | ErrorMessage.comnid_input_error() |
| bascid形式 | check_input_data('bascid') | ErrorMessage.bascid_input_error() |

### 7.3 ビジネスロジックエラー

| エラー条件 | 対応 |
|----------|-----|
| bascid変換時にチェックボックス未選択 | エラーメッセージ表示、変換中止 |
| LINE ID変換不可（連携フラグ未設定） | 結果がNULLになる（エラーではなく、マージで対応） |

---

## 8. パフォーマンス考慮事項

### 8.1 基準日フィルタの最適化

- 基準日指定により Snowflake パーティション プルーニングを活用
- COMNID統合テーブル：過去5日分に限定
- LINE連携テーブル：過去2日分に限定

### 8.2 重複排除の時点

- SQL レベルでの row_number() による重複排除
- Python DataFrame の drop_duplicates() は入力値のみに適用

### 8.3 一時テーブルの設計

**POCHI_ID_CONVERTER_ID_TARGET**
- 用途：アップロードされたID値の一時格納
- TTL：セッション期間
- スキーマ：USERDB_B_P01_LAK.USER_PGN_01

---

## 9. セキュリティ・プライバシー要件

### 9.1 出力データの扱い

- **用途制限**：社内利用限定（社外提供不可）
- **実装**：UI上に注記表示

### 9.2 個人情報の取扱い

- 顧客識別ID（acctid, comnid, bascid, lineid）は個人情報
- 適切なアクセス制御下での処理が必須

---

## 10. 将来の拡張性考慮

### 10.1 新しいID種別の追加時の検討項目

1. **形式検証ルール**の追加（BR-新規）
2. **変換パターン**の定義（conversion_rules 拡張）
3. **テーブルスキーマ**の追加（data-contracts.json 拡張）
4. **テスト観点**の追加（test-viewpoints.json 拡張）

### 10.2 Snowflake テーブル仕様変更時

- LAK_PTK_CRITERIA_DAY / LAKPTK_STANDARD_NENGAPPI の基準日ロジックの見直し
- REGULAR_INCOMPLETE_JUDGMENT_CLASSIFICATION / ACCOUNT_COORDINATION_FLAG の値の確認

---

**版管理**
- Version: 1.0
- Last Updated: 2026-04-28
- Owner: テスト検証チーム
