"""
変換出力系スキーマ検証テスト

Layer1（データ契約テスト）
対象境界:
- id_conversion_output_single: 単一ID種別への変換結果DataFrame
- id_conversion_output_bascid_multiple: 基本契約番号への複数事業区分変換結果DataFrame
"""
import pytest
import pandas as pd
from lib.definition import input_datas


class TestIdConversionOutputSingleSchema:
    """単一ID種別への変換結果DataFrameスキーマテスト"""

    # ===== 正常系テスト =====

    def test_conversion_output_single_has_two_columns(self, sample_acctid_df):
        """正常: 変換結果DataFrameは2カラム構成（入力カラム + 出力カラム）"""
        # 実際の変換結果を模擬（入力カラム + 出力カラム）
        output_df = pd.DataFrame({
            "アカウント識別子": sample_acctid_df["アカウント識別子"],
            "共通IDグループ番号": ["000000000001", "000000000002", "000000000003", "000000000004", "000000000005"]
        })
        assert len(output_df.columns) == 2
        assert output_df.shape[1] == 2

    def test_conversion_output_single_column_names_structure(self, sample_acctid_df):
        """正常: 出力DataFrameのカラム構造は（入力名, 出力名）"""
        output_df = pd.DataFrame({
            "アカウント識別子": sample_acctid_df["アカウント識別子"],
            "共通IDグループ番号": ["000000000001", "000000000002", "000000000003", "000000000004", "000000000005"]
        })
        columns = list(output_df.columns)
        assert columns[0] == "アカウント識別子"  # 入力カラム名
        assert columns[1] == "共通IDグループ番号"  # 出力カラム名

    def test_conversion_output_single_input_column_not_null(self, sample_acctid_df):
        """正常: 入力カラムのすべての値は NULL ではない"""
        output_df = pd.DataFrame({
            "アカウント識別子": sample_acctid_df["アカウント識別子"],
            "共通IDグループ番号": ["000000000001", "000000000002", "000000000003", "000000000004", "000000000005"]
        })
        assert output_df["アカウント識別子"].notna().all()
        assert len(output_df) == 5

    def test_conversion_output_single_input_column_dtype_object(self, sample_acctid_df):
        """正常: 入力カラムのデータ型は object（文字列）"""
        output_df = pd.DataFrame({
            "アカウント識別子": sample_acctid_df["アカウント識別子"],
            "共通IDグループ番号": ["000000000001", "000000000002", "000000000003", "000000000004", "000000000005"]
        })
        assert output_df["アカウント識別子"].dtype == object
        assert isinstance(output_df["アカウント識別子"].iloc[0], str)

    def test_conversion_output_single_output_column_dtype_object(self, sample_acctid_df):
        """正常: 出力カラムのデータ型は object（文字列）"""
        output_df = pd.DataFrame({
            "アカウント識別子": sample_acctid_df["アカウント識別子"],
            "共通IDグループ番号": ["000000000001", "000000000002", "000000000003", "000000000004", "000000000005"]
        })
        assert output_df["共通IDグループ番号"].dtype == object
        assert isinstance(output_df["共通IDグループ番号"].iloc[0], str)

    # ===== 異常系テスト =====

    # RISK: R008 (NULL値処理)
    def test_conversion_output_single_partial_null_allowed(self, sample_acctid_df):
        """異常: 変換対象が見つからない場合、出力カラムは NULL を許容"""
        output_df = pd.DataFrame({
            "アカウント識別子": sample_acctid_df["アカウント識別子"],
            "共通IDグループ番号": ["000000000001", None, "000000000003", None, "000000000005"]
        })
        # 出力カラムに NULL が含まれることを確認（部分的なマッチ）
        assert output_df["共通IDグループ番号"].isna().any()
        # ただし、入力カラムは NULL ではないこと
        assert output_df["アカウント識別子"].notna().all()
        assert len(output_df) == 5  # 行数は保持される

    # RISK: R008 (NULL値処理)
    def test_conversion_output_single_all_null_in_output_column(self, sample_acctid_df):
        """異常: すべてのID変換に失敗した場合、出力カラムはすべて NULL"""
        output_df = pd.DataFrame({
            "アカウント識別子": sample_acctid_df["アカウント識別子"],
            "共通IDグループ番号": [None, None, None, None, None]
        })
        # 出力カラムがすべて NULL でも、入力カラムは保持
        assert output_df["共通IDグループ番号"].isna().all()
        assert output_df["アカウント識別子"].notna().all()
        assert len(output_df) == 5  # 行数は保持される

    # RISK: R010 (出力ファイルサイズ制限)
    def test_conversion_output_single_row_count_maintained(self, sample_acctid_df):
        """異常: 入力行数と出力行数は一致すること（left joinで保持）"""
        output_df = pd.DataFrame({
            "アカウント識別子": sample_acctid_df["アカウント識別子"],
            "共通IDグループ番号": ["000000000001", "000000000002", "000000000003", "000000000004", "000000000005"]
        })
        assert len(output_df) == len(sample_acctid_df)
        assert output_df.shape[0] == 5

    # ===== 境界値テスト =====

    def test_conversion_output_single_empty_result(self):
        """境界: 変換結果が空DataFrame（入力データなし）"""
        output_df = pd.DataFrame({
            "アカウント識別子": pd.Series([], dtype=object),
            "共通IDグループ番号": pd.Series([], dtype=object)
        })
        assert len(output_df) == 0
        assert len(output_df.columns) == 2

    def test_conversion_output_single_single_row(self):
        """境界: 変換結果が1行（最小データ）"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],
            "共通IDグループ番号": ["000000000001"]
        })
        assert len(output_df) == 1
        assert len(output_df.columns) == 2

    def test_conversion_output_single_large_result(self):
        """境界: 変換結果が大規模（1000行以上）"""
        large_input = ["AAAAAAAAAAAAAAAAAAAAA" + str(i).zfill(3) for i in range(1001)]
        large_output = ["000000000001" for i in range(1001)]
        output_df = pd.DataFrame({
            "アカウント識別子": large_input,
            "共通IDグループ番号": large_output
        })
        assert len(output_df) == 1001
        assert len(output_df.columns) == 2


class TestIdConversionOutputBascidMultipleSchema:
    """基本契約番号複数事業区分への変換結果DataFrameスキーマテスト"""

    # ===== 正常系テスト =====

    def test_conversion_output_bascid_multiple_has_required_columns(self, sample_acctid_df):
        """正常: 複数事業区分変換は入力カラム + 複数の出力カラム"""
        # 01,05,08の3事業区分すべてを選択した場合
        output_df = pd.DataFrame({
            "アカウント識別子": sample_acctid_df["アカウント識別子"],
            "基本契約番号(01_携帯事業)": ["010000000001", "010000000002", "010000000003", "010000000004", "010000000005"],
            "基本契約番号(05_CF事業)": ["050000000001", "050000000002", None, "050000000004", "050000000005"],
            "基本契約番号(08_会員事業)": [None, "080000000002", "080000000003", None, "080000000005"]
        })
        expected_columns = ["アカウント識別子", "基本契約番号(01_携帯事業)", "基本契約番号(05_CF事業)", "基本契約番号(08_会員事業)"]
        assert list(output_df.columns) == expected_columns

    def test_conversion_output_bascid_multiple_first_column_input(self):
        """正常: 最初のカラムは入力カラム（アカウント識別子）"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],
            "基本契約番号(01_携帯事業)": ["010000000001"],
            "基本契約番号(05_CF事業)": ["050000000001"]
        })
        assert output_df.columns[0] == "アカウント識別子"

    def test_conversion_output_bascid_multiple_input_column_not_null(self):
        """正常: 入力カラムのすべての値は NULL ではない"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111", "BBBBBBBBBBBBBBBBBBBBB222"],
            "基本契約番号(01_携帯事業)": ["010000000001", "010000000002"],
            "基本契約番号(05_CF事業)": ["050000000001", "050000000002"]
        })
        assert output_df["アカウント識別子"].notna().all()
        assert len(output_df) == 2

    def test_conversion_output_bascid_multiple_dtype_object(self):
        """正常: すべてのカラムのデータ型は object（文字列）"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],
            "基本契約番号(01_携帯事業)": ["010000000001"],
            "基本契約番号(05_CF事業)": ["050000000001"]
        })
        assert output_df["アカウント識別子"].dtype == object
        assert output_df["基本契約番号(01_携帯事業)"].dtype == object
        assert output_df["基本契約番号(05_CF事業)"].dtype == object

    def test_conversion_output_bascid_multiple_01_only_columns(self):
        """正常: 01事業区分だけが選択された場合"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],
            "基本契約番号(01_携帯事業)": ["010000000001"]
        })
        # 選択された事業区分のカラムのみが出力
        assert "基本契約番号(01_携帯事業)" in output_df.columns
        assert "基本契約番号(05_CF事業)" not in output_df.columns
        assert "基本契約番号(08_会員事業)" not in output_df.columns

    def test_conversion_output_bascid_multiple_05_only_columns(self):
        """正常: 05事業区分だけが選択された場合"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],
            "基本契約番号(05_CF事業)": ["050000000001"]
        })
        assert "基本契約番号(05_CF事業)" in output_df.columns
        assert "基本契約番号(01_携帯事業)" not in output_df.columns

    def test_conversion_output_bascid_multiple_08_only_columns(self):
        """正常: 08事業区分だけが選択された場合"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],
            "基本契約番号(08_会員事業)": ["080000000001"]
        })
        assert "基本契約番号(08_会員事業)" in output_df.columns
        assert "基本契約番号(01_携帯事業)" not in output_df.columns

    # ===== 異常系テスト =====

    # RISK: R003 (基本契約番号複数事業区分制約)
    def test_conversion_output_bascid_multiple_selected_column_subset(self):
        """異常: 複数事業区分から部分的に選択（01と05だけ）"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],
            "基本契約番号(01_携帯事業)": ["010000000001"],
            "基本契約番号(05_CF事業)": ["050000000001"]
        })
        # 選択された分だけがカラムとして出力される（3つではなく2つ）
        assert len(output_df.columns) == 3
        assert "基本契約番号(08_会員事業)" not in output_df.columns

    # RISK: R008 (NULL値処理)
    def test_conversion_output_bascid_multiple_partial_null_allowed(self):
        """異常: 一部の事業区分で変換対象が見つからない場合、NULL を許容"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111", "BBBBBBBBBBBBBBBBBBBBB222"],
            "基本契約番号(01_携帯事業)": ["010000000001", None],
            "基本契約番号(05_CF事業)": [None, "050000000002"],
            "基本契約番号(08_会員事業)": ["080000000001", "080000000002"]
        })
        # 出力カラムに NULL が含まれることを確認
        assert output_df["基本契約番号(01_携帯事業)"].isna().any()
        assert output_df["基本契約番号(05_CF事業)"].isna().any()
        # ただし、入力カラムは NULL ではないこと
        assert output_df["アカウント識別子"].notna().all()
        assert len(output_df) == 2  # 行数は保持される

    # RISK: R008 (NULL値処理)
    def test_conversion_output_bascid_multiple_row_count_maintained(self):
        """異常: 入力行数と出力行数は一致すること（left joinで保持）"""
        input_rows = 5
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"] * input_rows,
            "基本契約番号(01_携帯事業)": ["010000000001"] * input_rows,
            "基本契約番号(05_CF事業)": ["050000000001"] * input_rows
        })
        assert len(output_df) == input_rows

    # ===== 境界値テスト =====

    def test_conversion_output_bascid_multiple_empty_result(self):
        """境界: 変換結果が空DataFrame"""
        output_df = pd.DataFrame({
            "アカウント識別子": pd.Series([], dtype=object),
            "基本契約番号(01_携帯事業)": pd.Series([], dtype=object),
            "基本契約番号(05_CF事業)": pd.Series([], dtype=object),
            "基本契約番号(08_会員事業)": pd.Series([], dtype=object)
        })
        assert len(output_df) == 0
        assert len(output_df.columns) == 4

    def test_conversion_output_bascid_multiple_single_row(self):
        """境界: 変換結果が1行（最小データ）"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],
            "基本契約番号(01_携帯事業)": ["010000000001"],
            "基本契約番号(05_CF事業)": ["050000000001"],
            "基本契約番号(08_会員事業)": ["080000000001"]
        })
        assert len(output_df) == 1
        assert len(output_df.columns) == 4

    def test_conversion_output_bascid_multiple_division_01_08_combo(self):
        """境界: 01と08だけが選択された場合（05が欠ける）"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],
            "基本契約番号(01_携帯事業)": ["010000000001"],
            "基本契約番号(08_会員事業)": ["080000000001"]
        })
        # 05が選択されていない
        assert len(output_df.columns) == 3
        assert "基本契約番号(05_CF事業)" not in output_df.columns
        assert "基本契約番号(01_携帯事業)" in output_df.columns
        assert "基本契約番号(08_会員事業)" in output_df.columns

    def test_conversion_output_bascid_multiple_all_null_in_output(self):
        """境界: 出力カラムがすべて NULL（変換失敗）"""
        output_df = pd.DataFrame({
            "アカウント識別子": ["AAAAAAAAAAAAAAAAAAAAA111"],
            "基本契約番号(01_携帯事業)": [None],
            "基本契約番号(05_CF事業)": [None],
            "基本契約番号(08_会員事業)": [None]
        })
        # 出力カラムがすべて NULL でも、入力カラムは保持
        assert output_df["基本契約番号(01_携帯事業)"].isna().all()
        assert output_df["基本契約番号(05_CF事業)"].isna().all()
        assert output_df["基本契約番号(08_会員事業)"].isna().all()
        assert output_df["アカウント識別子"].notna().all()
