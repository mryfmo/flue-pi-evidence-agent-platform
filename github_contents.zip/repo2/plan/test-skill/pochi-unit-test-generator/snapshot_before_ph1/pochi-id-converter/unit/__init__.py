"""
Layer2 ユニットテスト（ロジック単体テスト）

このパッケージは、pochi-id-converter-repository アプリの
Pure Function（純粋関数）に対する単体テストを含みます。

対象テストモジュール:
- test_check_input_data.py: 入力IDデータの桁数・フォーマット検証
- test_df_to_xlsx.py: DataFrame を Excel バイト列に変換
- test_check_input_file.py: ファイル名の禁止文字チェック
- test_make_input_df.py: Series から重複排除 DataFrame への変換
- test_left_merge_df.py: 左結合の実装テスト
- test_load_input_dict.py: 入力辞書のアンパック
- test_definition.py: 定数・クラスの定義確認テスト

テスト実行方法:
    pytest tests/unit/ -v
    pytest tests/unit/ --collect-only (テスト発見のみ)
"""
