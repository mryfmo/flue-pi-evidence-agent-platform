"""
load_input_dict 関数のユニットテスト

このモジュールは、lib.view_output_data.load_input_dict 関数をテストします。
関数は、入力辞書から 5 つの要素をアンパックして返します。

テスト対象関数:
    - load_input_dict(input_dict) -> Tuple[str, pd.Series, list, str, str]
"""

import pytest
import pandas as pd
from lib.view_output_data import load_input_dict


class TestLoadInputDict:
    """load_input_dict 関数のテスト"""

    def test_valid_input_dict(self):
        """TC-040: 正常な入力辞書"""
        # Arrange
        input_dict = {
            "select_source": "acctid",
            "select_df": pd.Series(["A", "B", "C"]),
            "id_list": ["comnid", "bascid", "lineid"],
            "select_input_colum": "input_column",
            "column_name": "ACCTID"
        }

        # Act
        result = load_input_dict(input_dict)

        # Assert
        assert isinstance(result, tuple), "戻り値はタプル"
        assert len(result) == 5, "要素数が 5"

        select_source, select_df, id_list, select_input_colum, column_name = result
        assert select_source == "acctid", "select_source が正しく抽出されている"
        assert isinstance(select_df, pd.Series), "select_df が Series である"
        assert isinstance(id_list, list), "id_list がリストである"
        assert select_input_colum == "input_column", "select_input_colum が正しく抽出されている"
        assert column_name == "ACCTID", "column_name が正しく抽出されている"

    def test_all_keys_exist(self):
        """TC-041: すべてのキーが存在する"""
        # Arrange
        input_dict = {
            "select_source": "comnid",
            "select_df": pd.Series(["X", "Y", "Z"]),
            "id_list": ["acctid", "bascid01", "lineid"],
            "select_input_colum": "col_xyz",
            "column_name": "COMNID"
        }

        # Act
        result = load_input_dict(input_dict)

        # Assert
        assert isinstance(result, tuple), "戻り値はタプル"
        assert len(result) == 5, "要素数が 5"

        # 要素の型確認
        select_source, select_df, id_list, select_input_colum, column_name = result
        assert isinstance(select_source, str), "select_source は文字列"
        assert isinstance(select_df, pd.Series), "select_df は Series"
        assert isinstance(id_list, list), "id_list はリスト"
        assert isinstance(select_input_colum, str), "select_input_colum は文字列"
        assert isinstance(column_name, str), "column_name は文字列"

    def test_empty_id_list(self):
        """id_list が空のリストである場合"""
        # Arrange
        input_dict = {
            "select_source": "acctid",
            "select_df": pd.Series(["A"]),
            "id_list": [],
            "select_input_colum": "col",
            "column_name": "ACCTID"
        }

        # Act
        result = load_input_dict(input_dict)

        # Assert
        select_source, select_df, id_list, select_input_colum, column_name = result
        assert id_list == [], "空のリストが正しく返されること"
        assert isinstance(id_list, list), "id_list はリスト型"

    def test_series_with_multiple_values(self):
        """select_df に複数の値が含まれる場合"""
        # Arrange
        input_dict = {
            "select_source": "lineid",
            "select_df": pd.Series(["ID1", "ID2", "ID3", "ID4", "ID5"]),
            "id_list": ["acctid", "comnid"],
            "select_input_colum": "lineid_column",
            "column_name": "LINEID"
        }

        # Act
        result = load_input_dict(input_dict)

        # Assert
        select_source, select_df, id_list, select_input_colum, column_name = result
        assert len(select_df) == 5, "Series の要素数が 5"
        assert list(select_df.values) == ["ID1", "ID2", "ID3", "ID4", "ID5"], "Series の値が保持されている"


class TestLoadInputDictOutputContract:
    """load_input_dict 関数の出力契約テスト"""

    def test_output_is_tuple_of_5_elements(self):
        """出力が5要素のタプルであること（出力契約）"""
        # Arrange
        input_dict = {
            "select_source": "acctid",
            "select_df": pd.Series(["A"]),
            "id_list": ["comnid"],
            "select_input_colum": "col",
            "column_name": "ACCTID"
        }

        # Act
        result = load_input_dict(input_dict)

        # Assert
        assert isinstance(result, tuple), "出力契約: 戻り値はタプル"
        assert len(result) == 5, "出力契約: タプルの要素数は 5"

    def test_output_element_types_are_correct(self):
        """出力の各要素の型が正しいこと（出力契約）"""
        # Arrange
        input_dict = {
            "select_source": "comnid",
            "select_df": pd.Series(["X", "Y"]),
            "id_list": ["a", "b", "c"],
            "select_input_colum": "column",
            "column_name": "COMNID"
        }

        # Act
        result = load_input_dict(input_dict)

        # Assert
        select_source, select_df, id_list, select_input_colum, column_name = result
        assert isinstance(select_source, str), "出力契約: 要素1は文字列"
        assert isinstance(select_df, pd.Series), "出力契約: 要素2は Series"
        assert isinstance(id_list, list), "出力契約: 要素3はリスト"
        assert isinstance(select_input_colum, str), "出力契約: 要素4は文字列"
        assert isinstance(column_name, str), "出力契約: 要素5は文字列"

    def test_output_preserves_input_dict_values(self):
        """出力が入力辞書の値を正確に保持していること（出力契約）"""
        # Arrange
        test_source = "bascid01"
        test_df = pd.Series(["VAL1", "VAL2"])
        test_list = ["id1", "id2", "id3"]
        test_colum = "my_column"
        test_name = "MY_NAME"

        input_dict = {
            "select_source": test_source,
            "select_df": test_df,
            "id_list": test_list,
            "select_input_colum": test_colum,
            "column_name": test_name
        }

        # Act
        result = load_input_dict(input_dict)

        # Assert
        select_source, select_df, id_list, select_input_colum, column_name = result
        assert select_source == test_source, "select_source が正確に保持されている"
        assert list(select_df) == list(test_df), "select_df が正確に保持されている"
        assert id_list == test_list, "id_list が正確に保持されている"
        assert select_input_colum == test_colum, "select_input_colum が正確に保持されている"
        assert column_name == test_name, "column_name が正確に保持されている"
