"""
make_input_df 関数のユニットテスト

このモジュールは、lib.view_output_data.make_input_df 関数をテストします。
関数は、入力の Series/リストから DataFrame に変換し、重複を排除します。

テスト対象関数:
    - make_input_df(select_df, column_name) -> pd.DataFrame
"""

import pytest
import pandas as pd
from lib.view_output_data import make_input_df


class TestMakeInputDf:
    """make_input_df 関数のテスト"""

    def test_no_duplicates_5rows(self):
        """TC-030: 重複なしの5行"""
        # Arrange
        input_series = pd.Series(["A", "B", "C", "D", "E"])
        column_name = "ACCTID"

        # Act
        result = make_input_df(input_series, column_name)

        # Assert
        assert isinstance(result, pd.DataFrame), "戻り値は DataFrame"
        assert len(result) == 5, "行数が 5 であること"
        assert result.columns.tolist() == ["ACCTID"], "カラム名が指定値と一致"
        assert result.iloc[:, 0].tolist() == ["A", "B", "C", "D", "E"], "値が保持されていること"

    def test_with_duplicates_compressed(self):
        """TC-031: 重複ありの5行 → 3行に圧縮"""
        # Arrange
        input_series = pd.Series(["A", "A", "B", "B", "C"])
        column_name = "ID"

        # Act
        result = make_input_df(input_series, column_name)

        # Assert
        assert len(result) == 3, "重複排除後の行数が 3 であること"
        assert set(result["ID"].values) == {"A", "B", "C"}, "一意な値が正しく抽出されていること"
        assert "ID" in result.columns, "カラム名が指定値と一致"

    def test_all_same_value(self):
        """TC-032: すべて同じ値"""
        # Arrange
        input_series = pd.Series(["X", "X", "X", "X"])
        column_name = "ID"

        # Act
        result = make_input_df(input_series, column_name)

        # Assert
        assert len(result) == 1, "すべて同じ値は1行に圧縮されること"
        assert result.iloc[0, 0] == "X", "残された値が正しいこと"

    def test_single_row(self):
        """TC-033: 1行（境界値）"""
        # Arrange
        input_series = pd.Series(["SINGLE"])
        column_name = "ID"

        # Act
        result = make_input_df(input_series, column_name)

        # Assert
        assert len(result) == 1, "1行は1行であること"
        assert result.iloc[0, 0] == "SINGLE", "値が保持されていること"
        assert "ID" in result.columns, "カラム名が指定値と一致"

    def test_100rows_with_20duplicates(self):
        """TC-034: 100行（重複20行）"""
        # Arrange
        # 80個のユニークな値 × 1 + 20個の値で100行
        values = [f"ID_{i}" for i in range(80)]
        # 最後の20個の値は重複させる
        values_with_dup = values + values[:20]
        input_series = pd.Series(values_with_dup)
        column_name = "ID_COLUMN"

        # Act
        result = make_input_df(input_series, column_name)

        # Assert
        assert len(result) == 80, "重複排除後の行数が 80 であること"
        assert len(result) < 100, "重複排除が行われていること"

    def test_special_characters_in_column_name(self):
        """TC-035: カラム名が特殊文字（日本語）"""
        # Arrange
        input_series = pd.Series(["A", "B"])
        column_name = "アカウント識別子"

        # Act
        result = make_input_df(input_series, column_name)

        # Assert
        assert "アカウント識別子" in result.columns, "日本語カラム名が正しく設定されること"
        assert len(result) == 2, "行数が 2 であること"
        assert result["アカウント識別子"].tolist() == ["A", "B"], "値が保持されていること"


class TestMakeInputDfOutputContract:
    """make_input_df 関数の出力契約テスト"""

    def test_output_is_dataframe(self):
        """出力が pd.DataFrame 型であること（出力契約）"""
        # Arrange
        input_series = pd.Series(["A", "B", "C"])
        column_name = "COL"

        # Act
        result = make_input_df(input_series, column_name)

        # Assert
        assert isinstance(result, pd.DataFrame), "出力契約: 常に DataFrame を返すこと"

    def test_output_has_single_column(self):
        """出力が1カラムの DataFrame であること（出力契約）"""
        # Arrange
        input_series = pd.Series(["A", "B", "C"])
        column_name = "COL"

        # Act
        result = make_input_df(input_series, column_name)

        # Assert
        assert len(result.columns) == 1, "出力契約: 1カラムの DataFrame であること"
        assert result.columns[0] == column_name, "出力契約: カラム名が指定値と一致すること"

    def test_output_has_duplicates_removed(self):
        """出力に重複がないこと（出力契約）"""
        # Arrange
        input_series = pd.Series(["A", "A", "B", "B", "C"])
        column_name = "COL"

        # Act
        result = make_input_df(input_series, column_name)

        # Assert
        # 重複がないかを確認: リセットして値を比較
        unique_count = len(result[column_name].unique())
        total_count = len(result)
        assert unique_count == total_count, "出力契約: 重複がないこと（ユニークな値の数 == 総行数）"
