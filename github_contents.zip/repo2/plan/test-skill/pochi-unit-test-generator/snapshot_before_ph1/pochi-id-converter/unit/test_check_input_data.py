"""
check_input_data 関数のユニットテスト

このモジュールは、lib.utility._utils.check_input_data 関数をテストします。
関数は、入力IDデータの桁数・フォーマット検証を行います。

テスト対象関数:
    - check_input_data(source_id, input_df) -> bool
"""

import pytest
import pandas as pd
from lib.utility._utils import check_input_data


class TestCheckInputData:
    """check_input_data 関数のテスト"""

    # =====================================================================
    # 正常系テスト: acctid（アカウント識別子、24桁）
    # =====================================================================

    def test_acctid_24digits_valid(self):
        """TC-001: acctid 正常系（24桁英字）"""
        # Arrange
        input_series = ["ABCDEFGHIJKLMNOPQRSTUVWX"]

        # Act
        result = check_input_data("acctid", input_series)

        # Assert
        assert result is True, "24桁英字の acctid は True を返すべき"

    def test_acctid_24digits_boundary(self):
        """TC-005: acctid ちょうど24桁（境界値）"""
        # Arrange
        input_series = ["A" * 24]

        # Act
        result = check_input_data("acctid", input_series)

        # Assert
        assert result is True, "ちょうど24桁の acctid は True を返すべき"

    # =====================================================================
    # 異常系テスト: acctid（24桁以外）
    # =====================================================================

    def test_acctid_23digits_invalid(self):
        """TC-002: acctid 23桁（短い）"""
        # Arrange
        input_series = ["ABCDEFGHIJKLMNOPQRSTUV"]  # 23桁

        # Act
        result = check_input_data("acctid", input_series)

        # Assert
        assert result is False, "23桁の acctid は False を返すべき"

    def test_acctid_25digits_invalid(self):
        """TC-003: acctid 25桁（長い）"""
        # Arrange
        input_series = ["ABCDEFGHIJKLMNOPQRSTUVWXY"]  # 25桁

        # Act
        result = check_input_data("acctid", input_series)

        # Assert
        assert result is False, "25桁の acctid は False を返すべき"

    def test_acctid_with_digits_valid(self):
        """TC-004: acctid 数字混在（24桁であれば許容）"""
        # Arrange
        input_series = ["ABCDEFGHIJKLMNOPQRSTU123"]  # 24桁、数字含む（実装は数字をチェックしない）

        # Act
        result = check_input_data("acctid", input_series)

        # Assert
        # 実装は数字チェックを行わないため、24桁であれば True を返す
        assert result is True, "24桁であれば数字を含んでも True を返す"

    # =====================================================================
    # 正常系テスト: comnid（共通IDグループ番号、先頭00、12桁）
    # =====================================================================

    def test_comnid_valid_head00(self):
        """TC-006: comnid 正常系（先頭00、12桁数字）"""
        # Arrange
        input_series = ["001234567890"]

        # Act
        result = check_input_data("comnid", input_series)

        # Assert
        assert result is True, "先頭00で12桁の comnid は True を返すべき"

    # =====================================================================
    # 異常系テスト: comnid（先頭が00以外）
    # =====================================================================

    def test_comnid_head01_invalid(self):
        """TC-007: comnid 先頭が01（エラー）"""
        # Arrange
        input_series = ["011234567890"]

        # Act
        result = check_input_data("comnid", input_series)

        # Assert
        assert result is False, "先頭が01の comnid は False を返すべき"

    def test_comnid_head10_invalid(self):
        """TC-008: comnid 先頭が10（エラー）"""
        # Arrange
        input_series = ["101234567890"]

        # Act
        result = check_input_data("comnid", input_series)

        # Assert
        assert result is False, "先頭が10の comnid は False を返すべき"

    # =====================================================================
    # 正常系テスト: bascid（基本契約番号、先頭0かつ2文字目非0、12桁）
    # =====================================================================

    def test_bascid_valid_head0x(self):
        """TC-009: bascid 正常系（先頭0、2文字目非0、12桁）"""
        # Arrange
        input_series = ["012345678901"]

        # Act
        result = check_input_data("bascid01", input_series)

        # Assert
        assert result is True, "先頭0で2文字目非0の bascid は True を返すべき"

    def test_bascid_boundary_12digits(self):
        """TC-012: bascid ちょうど12桁（境界値）"""
        # Arrange
        input_series = ["0" + "1" * 11]  # "01111111111" (12桁)

        # Act
        result = check_input_data("bascid05", input_series)

        # Assert
        assert result is True, "ちょうど12桁でフォーマットが正しい bascid は True を返すべき"

    # =====================================================================
    # 異常系テスト: bascid（フォーマット不正）
    # =====================================================================

    def test_bascid_head00_invalid(self):
        """TC-010: bascid 先頭が00（エラー）"""
        # Arrange
        input_series = ["001234567890"]

        # Act
        result = check_input_data("bascid01", input_series)

        # Assert
        assert result is False, "先頭が00の bascid は False を返すべき"

    def test_bascid_head1_invalid(self):
        """TC-011: bascid 先頭が1（エラー）"""
        # Arrange
        input_series = ["112345678901"]

        # Act
        result = check_input_data("bascid08", input_series)

        # Assert
        assert result is False, "先頭が1の bascid は False を返すべき"

    # =====================================================================
    # 正常系テスト: lineid（33桁数字）
    # =====================================================================

    def test_lineid_33digits_valid(self):
        """TC-013: lineid 正常系（33桁数字）"""
        # Arrange
        input_series = ["123456789012345678901234567890123"]  # 33桁

        # Act
        result = check_input_data("lineid", input_series)

        # Assert
        assert result is True, "33桁数字の lineid は True を返すべき"

    # =====================================================================
    # 異常系テスト: lineid（33桁以外）
    # =====================================================================

    def test_lineid_32digits_invalid(self):
        """TC-014: lineid 32桁（短い）"""
        # Arrange
        input_series = ["12345678901234567890123456789012"]  # 32桁

        # Act
        result = check_input_data("lineid", input_series)

        # Assert
        assert result is False, "32桁の lineid は False を返すべき"

    def test_lineid_34digits_invalid(self):
        """TC-015: lineid 34桁（長い）"""
        # Arrange
        input_series = ["1234567890123456789012345678901234"]  # 34桁

        # Act
        result = check_input_data("lineid", input_series)

        # Assert
        assert result is False, "34桁の lineid は False を返すべき"

    def test_lineid_with_alpha_valid(self):
        """TC-016: lineid 英字混在（33桁であれば許容）"""
        # Arrange
        input_series = ["ABC45678901234567890123456789ABCD"]  # 33桁、英字含む（実装は文字種をチェックしない）

        # Act
        result = check_input_data("lineid", input_series)

        # Assert
        # 実装は文字種チェックを行わないため、33桁であれば True を返す
        assert result is True, "33桁であれば英字を含んでも True を返す"

    # =====================================================================
    # 異常系テスト: None 入力
    # =====================================================================

    def test_none_input_invalid(self):
        """TC-017: None 入力"""
        # Arrange
        input_series = None

        # Act
        result = check_input_data("acctid", input_series)

        # Assert
        assert result is False, "None 入力は False を返すべき"

    # =====================================================================
    # 複数値テスト
    # =====================================================================

    def test_multiple_valid_acctids(self):
        """TC-018: 複数値（すべて正常）"""
        # Arrange
        input_series = [
            "ABCDEFGHIJKLMNOPQRSTUVWX",
            "BCDEFGHIJKLMNOPQRSTUVWXY",
            "CDEFGHIJKLMNOPQRSTUVWXYZ"
        ]

        # Act
        result = check_input_data("acctid", input_series)

        # Assert
        assert result is True, "複数の正常な acctid はすべて True を返すべき"
        assert len(input_series) == 3, "入力した値が3つであること"

    def test_multiple_with_one_invalid(self):
        """TC-019: 複数値（1つ不正）"""
        # Arrange
        input_series = [
            "ABCDEFGHIJKLMNOPQRSTUVWX",  # 正常（24桁）
            "SHORT",  # 不正（24桁未満）
            "CDEFGHIJKLMNOPQRSTUVWXYZ"  # 正常（24桁）
        ]

        # Act
        result = check_input_data("acctid", input_series)

        # Assert
        assert result is False, "1つ不正な値があると False を返すべき"
        assert len(input_series) == 3, "入力した値が3つであること"


class TestCheckInputDataWithDataFrame:
    """check_input_data 関数のテスト（DataFrame 入力）"""

    def test_acctid_with_series(self, sample_acctid_df):
        """正常なacctid DataFrame（フィクスチャ）"""
        # Arrange: sample_acctid_df には5行のデータが含まれる
        input_series = sample_acctid_df.iloc[:, 0]  # 最初のカラムを取得

        # Act
        result = check_input_data("acctid", input_series)

        # Assert
        assert result is True, "フィクスチャの有効な acctid は True を返すべき"
        assert len(sample_acctid_df) == 5, "フィクスチャは5行であること"

    def test_comnid_with_series(self, sample_comnid_df):
        """正常なcomnid DataFrame（フィクスチャ）の先頭00 テスト"""
        # Arrange: フィクスチャの comnid データは先頭が 00 ではないため、実際のフォーマットに合わせたデータで検証
        input_series = pd.Series(["005364967666", "009620940946", "003924700708", "002361512590", "001536560597"])

        # Act
        result = check_input_data("comnid", input_series)

        # Assert
        assert result is True, "先頭が00で12桁の comnid は True を返すべき"
        assert len(input_series) == 5, "5行のデータであること"

    def test_invalid_acctid_with_series(self, invalid_acctid_df):
        """異常なacctid DataFrame（フィクスチャ）"""
        # Arrange: invalid_acctid_df には不正な長さのデータが含まれる
        input_series = invalid_acctid_df.iloc[:, 0]

        # Act
        result = check_input_data("acctid", input_series)

        # Assert
        assert result is False, "フィクスチャの不正な acctid は False を返すべき"
        assert len(invalid_acctid_df) == 2, "不正データは2行であること"

    def test_empty_dataframe(self, empty_df):
        """空のDataFrame（フィクスチャ）"""
        # Arrange: empty_df は ヘッダーのみの空 DataFrame
        input_series = empty_df.iloc[:, 0]

        # Act
        # 空のシリーズは要素がないため、ループが実行されず True を返す
        result = check_input_data("acctid", input_series)

        # Assert
        # 要素がない場合の動作を検証（空シリーズはループ未実行でTrueを返す）
        assert isinstance(result, bool), "戻り値は bool 型"
        assert result is True, "空シリーズは検証エラーなしでTrueを返すこと"
        assert len(empty_df) == 0, "フィクスチャは0行であること"
