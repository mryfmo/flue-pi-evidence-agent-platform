"""
check_input_file 関数のユニットテスト

このモジュールは、lib.utility._utils.check_input_file 関数をテストします。
関数は、ファイル名に含まれる禁止文字をチェックします。

テスト対象関数:
    - check_input_file(file_name) -> None or raises ValidationError
"""

import pytest
from lib.utility._utils import check_input_file, ValidationError


class TestCheckInputFile:
    """check_input_file 関数のテスト"""

    def test_valid_filename(self):
        """TC-025: 正常なファイル名"""
        # Arrange
        file_name = "output.xlsx"

        # Act & Assert
        # 例外が発生しないことを確認
        try:
            check_input_file(file_name)
            # 例外が発生しなければテスト成功
            assert True, "正常なファイル名では例外が発生しないこと"
        except ValidationError:
            pytest.fail("正常なファイル名で ValidationError が発生してはいけない")

    def test_valid_filename_with_underscore(self):
        """正常なファイル名（アンダースコア含む）"""
        # Arrange
        file_name = "output_file_name.csv"

        # Act & Assert
        try:
            check_input_file(file_name)
            assert True, "アンダースコアを含むファイル名は正常である"
        except ValidationError:
            pytest.fail("正常なファイル名で ValidationError が発生してはいけない")

    def test_forbidden_char_slash(self):
        """TC-026: 禁止文字 "/" を含む"""
        # Arrange
        file_name = "output/file.xlsx"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)

        assert "/" in str(exc_info.value), "エラーメッセージに禁止文字を含むこと"

    def test_forbidden_char_asterisk(self):
        """TC-027: 禁止文字 "*" を含む"""
        # Arrange
        file_name = "output*.xlsx"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)

        assert "*" in str(exc_info.value), "エラーメッセージに禁止文字を含むこと"

    def test_forbidden_char_angle_brackets(self):
        """TC-028: 複数の禁止文字を含む"""
        # Arrange
        file_name = "output<file>.xlsx"

        # Act & Assert
        with pytest.raises(ValidationError) as exc_info:
            check_input_file(file_name)

        assert "<" in str(exc_info.value) or ">" in str(exc_info.value), "エラーメッセージに禁止文字を含むこと"

    def test_valid_filename_japanese(self):
        """TC-029: 日本語を含む正常名"""
        # Arrange
        file_name = "出力ファイル.xlsx"

        # Act & Assert
        try:
            check_input_file(file_name)
            assert True, "日本語を含むファイル名は正常である"
        except ValidationError:
            pytest.fail("日本語を含む正常なファイル名で ValidationError が発生してはいけない")

    # 追加の禁止文字テスト
    def test_forbidden_char_backslash(self):
        """禁止文字 "\\" を含む"""
        # Arrange
        file_name = "output\\file.xlsx"

        # Act & Assert
        with pytest.raises(ValidationError):
            check_input_file(file_name)

    def test_forbidden_char_colon(self):
        """禁止文字 ":" を含む"""
        # Arrange
        file_name = "output:file.xlsx"

        # Act & Assert
        with pytest.raises(ValidationError):
            check_input_file(file_name)

    def test_forbidden_char_question(self):
        """禁止文字 "?" を含む"""
        # Arrange
        file_name = "output?.xlsx"

        # Act & Assert
        with pytest.raises(ValidationError):
            check_input_file(file_name)

    def test_forbidden_char_quote(self):
        """禁止文字 '"' を含む"""
        # Arrange
        file_name = 'output"file.xlsx'

        # Act & Assert
        with pytest.raises(ValidationError):
            check_input_file(file_name)

    def test_forbidden_char_pipe(self):
        """禁止文字 "|" を含む"""
        # Arrange
        file_name = "output|file.xlsx"

        # Act & Assert
        with pytest.raises(ValidationError):
            check_input_file(file_name)


class TestCheckInputFileOutputContract:
    """check_input_file 関数の出力契約テスト"""

    def test_valid_file_returns_none_or_raises_nothing(self):
        """出力契約: 正常なファイル名は None を返すまたは例外を発生させないこと"""
        # Arrange
        file_name = "valid_filename.xlsx"

        # Act
        result = check_input_file(file_name)

        # Assert
        assert result is None, "関数は None を返すか何も返さないこと"

    def test_invalid_file_raises_validation_error(self):
        """出力契約: 禁止文字を含むファイル名は ValidationError を発生させること"""
        # Arrange
        file_name = "invalid/name.xlsx"

        # Act & Assert
        with pytest.raises(ValidationError):
            check_input_file(file_name)
