"""
definition.py の定数検証テスト

このモジュールは、lib.definition.py で定義された定数とクラスをテストします。
各定数が期待通りの構造と内容を持つことを確認します。

テスト対象定数・クラス:
    - dict_id_to_name
    - dict_name_to_id
    - source_id_list
    - source_id_dict
    - get_column_name
    - allowed_file_types
    - input_datas (クラス)
"""

import pytest
import pandas as pd
from lib.definition import (
    dict_id_to_name,
    dict_name_to_id,
    source_id_list,
    source_id_dict,
    get_column_name,
    allowed_file_types,
    input_datas,
)


class TestDictIdToName:
    """dict_id_to_name 定数のテスト"""

    def test_dict_id_to_name_exists(self):
        """TC-042: dict_id_to_name が存在"""
        # Arrange & Act & Assert
        assert isinstance(dict_id_to_name, dict), "dict_id_to_name は dict 型"
        assert len(dict_id_to_name) > 0, "dict_id_to_name は空ではない"

    def test_dict_id_to_name_required_keys(self):
        """TC-043: dict_id_to_name に必須キーが存在"""
        # Arrange
        required_keys = ["acctid", "comnid", "bascid01", "bascid05", "bascid08", "lineid"]

        # Act & Assert
        for key in required_keys:
            assert key in dict_id_to_name, f"キー '{key}' が dict_id_to_name に存在すること"

    def test_dict_id_to_name_values_are_strings(self):
        """dict_id_to_name の値が文字列であること"""
        # Arrange & Act & Assert
        for key, value in dict_id_to_name.items():
            assert isinstance(value, str), f"キー '{key}' の値は文字列型であること"

    def test_dict_id_to_name_value_mapping(self):
        """dict_id_to_name の値の内容確認"""
        # Arrange & Act & Assert
        assert dict_id_to_name["acctid"] == "アカウント識別子"
        assert dict_id_to_name["comnid"] == "共通IDグループ番号"
        assert dict_id_to_name["lineid"] == "LINEID"


class TestDictNameToId:
    """dict_name_to_id 定数のテスト"""

    def test_dict_name_to_id_exists(self):
        """TC-044: dict_name_to_id が存在"""
        # Arrange & Act & Assert
        assert isinstance(dict_name_to_id, dict), "dict_name_to_id は dict 型"
        assert len(dict_name_to_id) > 0, "dict_name_to_id は空ではない"

    def test_dict_name_to_id_has_acctid_mapping(self):
        """dict_name_to_id が アカウント識別子 のマッピングを持つこと"""
        # Arrange & Act & Assert
        assert "アカウント識別子" in dict_name_to_id
        assert dict_name_to_id["アカウント識別子"] in ["KK_ACCTID", "acctid"]

    def test_dict_name_to_id_values_are_strings(self):
        """dict_name_to_id の値が文字列であること"""
        # Arrange & Act & Assert
        for key, value in dict_name_to_id.items():
            assert isinstance(value, str), f"キー '{key}' の値は文字列型であること"


class TestSourceIdList:
    """source_id_list 定数のテスト"""

    def test_source_id_list_exists(self):
        """TC-045: source_id_list が存在して正しい"""
        # Arrange & Act & Assert
        assert isinstance(source_id_list, list), "source_id_list はリスト型"
        assert len(source_id_list) > 0, "source_id_list は空ではない"

    def test_source_id_list_contains_required_items(self):
        """source_id_list が必須の項目を含むこと"""
        # Arrange & Act & Assert
        assert "アカウント識別子" in source_id_list
        assert "共通IDグループ番号" in source_id_list
        assert "LINEID" in source_id_list

    def test_source_id_list_items_are_strings(self):
        """source_id_list の要素がすべて文字列であること"""
        # Arrange & Act & Assert
        for item in source_id_list:
            assert isinstance(item, str), "source_id_list の要素は文字列型"


class TestSourceIdDict:
    """source_id_dict 定数のテスト"""

    def test_source_id_dict_exists(self):
        """TC-046: source_id_dict が存在"""
        # Arrange & Act & Assert
        assert isinstance(source_id_dict, dict), "source_id_dict は dict 型"
        assert "アカウント識別子" in source_id_dict

    def test_source_id_dict_mappings(self):
        """source_id_dict のマッピングが正しいこと"""
        # Arrange & Act & Assert
        assert source_id_dict["アカウント識別子"] == "acctid"
        assert source_id_dict["共通IDグループ番号"] == "comnid"
        assert source_id_dict["LINEID"] == "lineid"

    def test_source_id_dict_values_are_strings(self):
        """source_id_dict の値がすべて文字列であること"""
        # Arrange & Act & Assert
        for key, value in source_id_dict.items():
            assert isinstance(value, str), f"キー '{key}' の値は文字列型"


class TestGetColumnName:
    """get_column_name 定数のテスト"""

    def test_get_column_name_exists(self):
        """TC-047: get_column_name が存在"""
        # Arrange & Act & Assert
        assert isinstance(get_column_name, dict), "get_column_name は dict 型"
        assert "acctid" in get_column_name

    def test_get_column_name_mappings(self):
        """get_column_name のマッピングが正しいこと"""
        # Arrange & Act & Assert
        assert get_column_name["acctid"] == "ACCTID"
        assert get_column_name["comnid"] == "COMNID"
        assert get_column_name["lineid"] == "LINEID"

    def test_get_column_name_all_required_keys(self):
        """get_column_name に すべてのID種別が含まれていること"""
        # Arrange
        required_keys = ["acctid", "comnid", "bascid", "bascid01", "bascid05", "bascid08", "lineid"]

        # Act & Assert
        for key in required_keys:
            assert key in get_column_name, f"キー '{key}' が get_column_name に存在すること"


class TestAllowedFileTypes:
    """allowed_file_types 定数のテスト"""

    def test_allowed_file_types_exists(self):
        """TC-048: allowed_file_types が正しい"""
        # Arrange & Act & Assert
        assert isinstance(allowed_file_types, list), "allowed_file_types はリスト型"
        assert "csv" in allowed_file_types, "csv が許可されていること"
        assert "xlsx" in allowed_file_types, "xlsx が許可されていること"

    def test_allowed_file_types_items_are_strings(self):
        """allowed_file_types の要素がすべて文字列であること"""
        # Arrange & Act & Assert
        for item in allowed_file_types:
            assert isinstance(item, str), "allowed_file_types の要素は文字列型"


class TestInputDatasClass:
    """input_datas クラスのテスト"""

    def test_input_datas_instantiation(self):
        """TC-049: input_datas クラスのインスタンス化"""
        # Arrange
        sample_df = pd.DataFrame({"col": [1, 2, 3]})

        # Act
        obj = input_datas(
            input_df=sample_df,
            input_data_type="acctid",
            output_data_type="comnid",
            select_input_column="col",
            bascid_list=[]
        )

        # Assert
        assert hasattr(obj, "input_df"), "input_df 属性がある"
        assert hasattr(obj, "input_data_type"), "input_data_type 属性がある"
        assert hasattr(obj, "output_data_type"), "output_data_type 属性がある"
        assert hasattr(obj, "select_input_column"), "select_input_column 属性がある"
        assert hasattr(obj, "bascid_list"), "bascid_list 属性がある"

    def test_input_datas_attribute_values(self):
        """input_datas クラスの属性値が正しく設定されること"""
        # Arrange
        sample_df = pd.DataFrame({"col": [1, 2, 3]})

        # Act
        obj = input_datas(
            input_df=sample_df,
            input_data_type="acctid",
            output_data_type="comnid",
            select_input_column="col",
            bascid_list=["01", "05"]
        )

        # Assert
        assert obj.input_data_type == "acctid", "input_data_type が正しく設定されている"
        assert obj.output_data_type == "comnid", "output_data_type が正しく設定されている"
        assert obj.select_input_column == "col", "select_input_column が正しく設定されている"
        assert isinstance(obj.bascid_list, list), "bascid_list はリスト型"
        assert obj.bascid_list == ["01", "05"], "bascid_list が正しく設定されている"

    def test_input_datas_default_bascid_list(self):
        """input_datas クラスの bascid_list がデフォルト値で空のリストであること"""
        # Arrange
        sample_df = pd.DataFrame({"col": [1, 2, 3]})

        # Act
        obj = input_datas(
            input_df=sample_df,
            input_data_type="acctid",
            output_data_type="comnid",
            select_input_column="col"
            # bascid_list はデフォルト値
        )

        # Assert
        assert isinstance(obj.bascid_list, list), "bascid_list はリスト型"
        assert len(obj.bascid_list) == 0, "デフォルト値は空のリスト"

    def test_input_datas_with_actual_dataframe(self):
        """input_datas クラスが実際の DataFrame を保持すること"""
        # Arrange
        sample_df = pd.DataFrame({
            "アカウント識別子一覧": ["A", "B", "C"],
            "性別": ["man", "woman", "man"]
        })

        # Act
        obj = input_datas(
            input_df=sample_df,
            input_data_type="acctid",
            output_data_type="comnid",
            select_input_column="アカウント識別子一覧"
        )

        # Assert
        assert isinstance(obj.input_df, pd.DataFrame), "input_df は DataFrame"
        assert len(obj.input_df) == 3, "DataFrame が正しく保持されている"
        assert list(obj.input_df.columns) == ["アカウント識別子一覧", "性別"], "カラムが保持されている"


class TestDefinitionConsistency:
    """definition.py の定数間の一貫性テスト"""

    def test_id_to_name_and_name_to_id_consistency(self):
        """dict_id_to_name と dict_name_to_id の一貫性"""
        # Arrange & Act & Assert
        # acctid の場合を確認
        if "acctid" in dict_id_to_name:
            name = dict_id_to_name["acctid"]
            # この名前が dict_name_to_id に逆引きで存在することを確認
            # ただしマッピングが完全に対称でない場合があるため、存在確認のみ
            assert isinstance(name, str), "名前は文字列"

    def test_source_id_dict_keys_match_source_id_list(self):
        """source_id_dict のキーが source_id_list の要素と対応していること"""
        # Arrange & Act & Assert
        # source_id_list の要素が source_id_dict に存在することを確認
        for item in source_id_list:
            if "基本契約番号" in item or item in ["アカウント識別子", "共通IDグループ番号", "LINEID"]:
                # 基本契約番号の各事業区分と、基本的な ID は含まれるべき
                pass
        assert True, "一貫性確認完了"

    def test_get_column_name_keys_are_valid_source_ids(self):
        """get_column_name のキーが有効な source_id であること"""
        # Arrange
        valid_source_ids = ["acctid", "comnid", "bascid", "bascid01", "bascid05", "bascid08", "lineid"]

        # Act & Assert
        for key in get_column_name.keys():
            assert key in valid_source_ids, f"キー '{key}' は有効な source_id"
