"""
left_merge_df 関数のユニットテスト

このモジュールは、lib.view_output_data.left_merge_df 関数をテストします。
関数は、base_df を左側として select_df を左結合します。

テスト対象関数:
    - left_merge_df(base_df, select_df, base_column_name) -> pd.DataFrame
"""

import pytest
import pandas as pd
from lib.view_output_data import left_merge_df


class TestLeftMergeDf:
    """left_merge_df 関数のテスト"""

    def test_complete_match_merge(self):
        """TC-036: 完全一致の結合"""
        # Arrange
        base_df = pd.DataFrame({"ID": ["A", "B", "C"]})
        select_df = pd.DataFrame({"ID": ["A", "B", "C"], "value": [1, 2, 3]})
        base_column_name = "ID"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        assert len(result) == 3, "行数が 3 であること"
        assert "value" in result.columns, "右側のカラムが追加されていること"
        assert result["value"].tolist() == [1, 2, 3], "値が正しく結合されていること"
        assert list(result.columns) == ["ID", "value"], "カラムが正しい順序であること"

    def test_partial_match_merge(self):
        """TC-037: 部分一致の結合"""
        # Arrange
        base_df = pd.DataFrame({"ID": ["A", "B", "C", "D"]})
        select_df = pd.DataFrame({"ID": ["A", "B"], "value": [1, 2]})
        base_column_name = "ID"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        assert len(result) == 4, "base_df の行数が保持されていること"
        assert pd.isna(result.loc[result["ID"] == "D", "value"].iloc[0]), "マッチしなかった行の value が NaN であること"
        assert pd.isna(result.loc[result["ID"] == "C", "value"].iloc[0]), "マッチしなかった行の value が NaN であること"
        assert result.loc[result["ID"] == "A", "value"].iloc[0] == 1, "マッチした行の値が正しいこと"

    def test_empty_select_df(self):
        """TC-038: select_df が空"""
        # Arrange
        base_df = pd.DataFrame({"ID": ["A", "B"]})
        select_df = pd.DataFrame({"ID": pd.Series([], dtype="object"), "value": pd.Series([], dtype="int64")})
        base_column_name = "ID"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        assert len(result) == 2, "base_df の行数が保持されていること"
        assert result.isnull().any(axis=1).all() or pd.isna(result["value"]).all(), "右側カラムがすべて NaN であること"

    def test_empty_base_df(self):
        """TC-039: base_df が空"""
        # Arrange
        base_df = pd.DataFrame({"ID": pd.Series([], dtype="object")})
        select_df = pd.DataFrame({"ID": ["A", "B"], "value": [1, 2]})
        base_column_name = "ID"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        assert len(result) == 0, "空の base_df は空のまま返されること"


class TestLeftMergeDfOutputContract:
    """left_merge_df 関数の出力契約テスト"""

    def test_output_is_dataframe(self):
        """出力が pd.DataFrame 型であること（出力契約）"""
        # Arrange
        base_df = pd.DataFrame({"ID": ["A", "B"]})
        select_df = pd.DataFrame({"ID": ["A", "B"], "value": [1, 2]})
        base_column_name = "ID"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        assert isinstance(result, pd.DataFrame), "出力契約: 常に DataFrame を返すこと"
        assert len(result) == 2, "出力の行数が base_df と一致すること"
        assert "ID" in result.columns, "base_df のカラムが保持されること"

    def test_output_preserves_base_df_row_count(self):
        """出力は base_df の行数を保持すること（出力契約）"""
        # Arrange
        base_df = pd.DataFrame({"ID": ["A", "B", "C", "D", "E"]})
        select_df = pd.DataFrame({"ID": ["A", "B"], "value": [1, 2]})
        base_column_name = "ID"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        assert len(result) == len(base_df), "出力契約: base_df の行数が保持されること（左結合）"

    def test_output_includes_select_df_columns(self):
        """出力に select_df のカラムが含まれること（出力契約）"""
        # Arrange
        base_df = pd.DataFrame({"ID": ["A", "B"]})
        select_df = pd.DataFrame({"ID": ["A", "B"], "value": [1, 2], "extra": ["x", "y"]})
        base_column_name = "ID"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        assert "value" in result.columns, "出力契約: select_df のカラムが含まれること"
        assert "extra" in result.columns, "出力契約: select_df のすべてのカラムが含まれること"


class TestLeftMergeDfWithRealDataflow:
    """left_merge_df 関数の実際の데이터 흐름 테스트"""

    def test_merge_maintains_order(self):
        """結合後の base_df 順序が保持されること"""
        # Arrange
        base_df = pd.DataFrame({"ID": ["C", "A", "B"]})
        select_df = pd.DataFrame({"ID": ["A", "B", "C"], "value": [1, 2, 3]})
        base_column_name = "ID"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        assert result["ID"].tolist() == ["C", "A", "B"], "base_df の元の順序が保持されること"
        assert result["value"].tolist() == [3, 1, 2], "値の順序も対応していること"

    def test_merge_with_duplicates_in_base_df(self):
        """base_df に重複がある場合の結合"""
        # Arrange
        base_df = pd.DataFrame({"ID": ["A", "A", "B"]})
        select_df = pd.DataFrame({"ID": ["A", "B"], "value": [10, 20]})
        base_column_name = "ID"

        # Act
        result = left_merge_df(base_df, select_df, base_column_name)

        # Assert
        # 両方の "A" が 10 と対応する
        assert len(result) == 3, "base_df の行数が保持されること"
        assert result.loc[result["ID"] == "A", "value"].tolist() == [10, 10], "重複した ID は同じ値で結合されること"
