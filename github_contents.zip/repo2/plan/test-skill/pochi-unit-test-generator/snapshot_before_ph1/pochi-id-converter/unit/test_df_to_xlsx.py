"""
df_to_xlsx 関数のユニットテスト

このモジュールは、lib.utility._utils.df_to_xlsx 関数をテストします。
関数は、pandas DataFrame を Excel ファイル形式（バイト列）に変換します。

テスト対象関数:
    - df_to_xlsx(df) -> bytes
"""

import pytest
import pandas as pd
import io
from lib.utility._utils import df_to_xlsx


class TestDfToXlsx:
    """df_to_xlsx 関数のテスト"""

    def test_normal_dataframe(self):
        """TC-020: 通常のDataFrame"""
        # Arrange
        input_df = pd.DataFrame({
            "col1": [1, 2, 3],
            "col2": ["a", "b", "c"]
        })

        # Act
        result = df_to_xlsx(input_df)

        # Assert
        assert isinstance(result, bytes), "戻り値は bytes 型であること"
        assert len(result) > 0, "バイト列は空でないこと"
        assert result.startswith(b'PK'), "Excel ファイルのシグネチャ（PK）を持つこと"

    def test_single_row_dataframe(self):
        """TC-021: 1行のDataFrame"""
        # Arrange
        input_df = pd.DataFrame({
            "col": [1]
        })

        # Act
        result = df_to_xlsx(input_df)

        # Assert
        assert isinstance(result, bytes), "戻り値は bytes 型"
        assert len(result) > 0, "バイト列は空でないこと"
        assert result.startswith(b'PK'), "Excel ファイルのシグネチャを持つこと"

    def test_empty_dataframe(self):
        """TC-022: 空のDataFrame（境界値）"""
        # Arrange
        input_df = pd.DataFrame()

        # Act
        result = df_to_xlsx(input_df)

        # Assert
        assert isinstance(result, bytes), "空の DataFrame でも bytes を返すこと"
        assert len(result) > 0, "ヘッダーを含むため完全に空ではないこと"
        assert result.startswith(b'PK'), "Excel ファイルのシグネチャを持つこと"

    def test_large_dataframe(self):
        """TC-023: 複数カラムの大規模DataFrame"""
        # Arrange
        input_df = pd.DataFrame({
            "A": range(1000),
            "B": range(1000),
            "C": range(1000)
        })

        # Act
        result = df_to_xlsx(input_df)

        # Assert
        assert isinstance(result, bytes), "戻り値は bytes 型"
        assert len(result) > 0, "バイト列は空でないこと"
        assert len(result) > 10000, "大規模なデータセットはそれなりのサイズを持つこと"
        assert result.startswith(b'PK'), "Excel ファイルのシグネチャを持つこと"

    def test_dataframe_with_special_characters(self):
        """TC-024: 特殊文字を含むDataFrame"""
        # Arrange
        input_df = pd.DataFrame({
            "col": ["あ", "い", "う"]
        })

        # Act
        result = df_to_xlsx(input_df)

        # Assert
        assert isinstance(result, bytes), "戻り値は bytes 型"
        assert len(result) > 0, "バイト列は空でないこと"
        assert result.startswith(b'PK'), "Excel ファイルのシグネチャを持つこと"
        # 日本語文字が含まれるため、バイト列のサイズが大きくなっている
        assert len(result) > 500, "特殊文字が含まれるため適切なサイズを持つこと"


class TestDfToXlsxOutputContract:
    """df_to_xlsx 関数の出力契約テスト"""

    def test_output_is_bytes_type(self):
        """出力が bytes 型であること（出力契約）"""
        # Arrange
        input_df = pd.DataFrame({"col": [1, 2]})

        # Act
        result = df_to_xlsx(input_df)

        # Assert
        assert isinstance(result, bytes), "出力契約: 常に bytes 型を返すこと"

    def test_output_is_readable_excel(self):
        """出力が有効な Excel ファイルフォーマットであること（出力契約）"""
        # Arrange
        input_df = pd.DataFrame({"col1": [1, 2, 3], "col2": ["a", "b", "c"]})

        # Act
        result = df_to_xlsx(input_df)

        # Assert
        # Excel ファイルシグネチャで確認（xlrd モックの影響を回避）
        assert isinstance(result, bytes), "出力は bytes 型"
        assert result.startswith(b'PK'), "Excel ファイルシグネチャ（PK）を持つこと"
        assert b'xl/' in result or b'workbook' in result.lower(), "Excel 内部構造を含むこと"
