# d払い決済状況見える化ツール - ドメインルール仕様書

## 概要

本ドキュメントは、d払い決済状況見える化ツール（Streamlit アプリケーション）のテスト実施に先立ち、アプリケーションのビジネスロジック、データ契約、制約条件を体系的に記述したものです。

テスト担当者、開発者、QA が参照する機能仕様書として機能します。

---

## 1. データモデル仕様

### 1.1 InputConditions（入力条件クラス）

画面からの入力条件を保持する不変（frozen）dataclass。

**必須フィールド**
- `start_date: date` - 集計開始日
- `end_date: date` - 集計終了日
- `enable_comparison: bool` - 期間比較を有効にするか（デフォルト: False）
- `keyword_search_method: KeywordSearchMethod` - キーワード検索方法（デフォルト: "company_store"）

**オプションフィールド**
- `comparison_start_date: Optional[date]` - 比較期間開始日（enable_comparison=True の場合は必須）
- `comparison_end_date: Optional[date]` - 比較期間終了日（enable_comparison=True の場合は必須）
- `prefecture_cd: Optional[str]` - 都道府県コード
- `city_cd: Optional[list[str]]` - 市区町村コードのリスト
- `address_cd: Optional[list[str]]` - 住所コード（大字町域）のリスト
- `aza_cd: Optional[list[str]]` - 字丁目コードのリスト
- `gender_cd: Optional[str]` - 性別コード（"1": 男性, "2": 女性）
- `nendai_cd_list: Optional[list[str]]` - 年代コードのリスト（9種類）
- `big_jenre_list: Optional[list[str]]` - 業態コードのリスト
- `payment_method_list: Optional[list[str]]` - 決済方式のリスト
- `keyword_search_word: Optional[str]` - キーワード検索ワード
- `map_search_latitude: Optional[float]` - 地図検索中心緯度
- `map_search_longitude: Optional[float]` - 地図検索中心経度
- `map_search_radius_km: Optional[float]` - 地図検索半径（km）
- `selected_store_id: Optional[str]` - 店舗検索で選択された店舗ID
- `store_center_latitude: Optional[float]` - 店舗中心緯度
- `store_center_longitude: Optional[float]` - 店舗中心経度
- `store_search_radius_km: Optional[float]` - 店舗検索半径（km）

### 1.2 RenderOptions（描画オプションクラス）

UI描画制御フラグを保持する不変（frozen）dataclass。

**フラグ（デフォルト: すべて False。show_map_point_pin のみ True）**
- `enable_merchant_map: bool` - 加盟店地図表示を有効にするか
- `enable_acctid_list_download: bool` - ユーザーリストダウンロード機能を有効にするか
- `enable_analysis_data_download: bool` - 分析データダウンロード機能を有効にするか
- `enable_graphs: bool` - グラフ表示機能を有効にするか
- `enable_store_information_display: bool` - 店舗情報管理マスター表示を有効にするか
- `show_map_point_pin: bool` - 地図上のピンを表示するか（デフォルト: True）

**フィルター**
- `payment_method_list: Optional[list[str]]` - 決済方式フィルター（加盟店絞込み用）

---

## 2. ビジネスロジック仕様

### 2.1 検索条件の検証ルール

InputConditions の `check` プロパティは、以下の条件をすべて満たす場合にのみ **True** を返す：

1. **日付の妥当性**
   - `start_date` と `end_date` は date 型の必須フィールド
   - `start_date <= end_date` の順序を満たすこと

2. **検索条件の充足**
   以下の 4 つの検索パターンのいずれか 1 つ以上が必須：
   - **住所検索**: `prefecture_cd` && `city_cd` が両方設定されている
   - **キーワード検索**: `keyword_search_word` && `keyword_search_method` が両方設定されている
   - **地図検索**: `map_search_latitude` && `map_search_longitude` && `map_search_radius_km` が全て設定されている
   - **店舗検索**: `selected_store_id` && `store_center_latitude` && `store_center_longitude` && `store_search_radius_km` が全て設定されている

3. **期間比較の検証**
   - `enable_comparison=False`: comparison_* フィールドは未設定でもよい
   - `enable_comparison=True`: `comparison_start_date` && `comparison_end_date` が両方必須で、`comparison_start_date <= comparison_end_date`

### 2.2 検索条件の多重性

複数の検索条件が同時に指定された場合、**すべての条件が有効**になります。

優先順位（Snowflake クエリの適用順）:
1. 住所検索（最優先）
2. キーワード検索
3. 地図検索
4. 店舗検索（最後）

ただし、Layer1/2 のユニットテストでは Snowflake 依存がないため、複合条件の優先順位テストは Layer3（統合テスト）で検証されるべきです。

### 2.3 キーワード検索方法の定義

`keyword_search_method` フィールドは以下の 4 つの値をサポート：

- **"company_store"** (デフォルト): 会社名と店舗名の両方で検索
- **"company"**: 会社名のみで検索
- **"store"**: 店舗名のみで検索
- **"address"**: 住所で検索

### 2.4 利用可能日付の制限

`get_usage_dates()` 関数は、以下の範囲で利用可能な月次日付リストを返す：

**保持開始日**: 2021-07-01
**保持終了日**: 当日 - 3 日（3 日遅延ベース）
**粒度**: 月次（各月の 1 日を返却）
**返却順序**: 新しい順（降順）

例）2024-04-28 時点では、2024-04-25 までのデータが利用可能。遡った期間は最大 36 ヶ月分。

### 2.5 キャッシング戦略

アプリケーションはパフォーマンス向上のため Streamlit キャッシング機構を活用：

**@st.cache_data(ttl=1800)**
- 汎用データキャッシュ
- TTL: 1800 秒（30 分）
- 対象関数: `get_usage_dates()`, `get_regions_and_prefectures()`, `get_prefectures()`, その他

**@st.cache_resource(ttl=300)**
- SQL セッションなどのリソースキャッシュ
- TTL: 300 秒（5 分）
- 対象関数: `create_settlement_records_query_from_input_conditions()`

**注意点**
- キャッシュ有効期限内は同じデータが返却される
- Snowflake 上でデータが更新されても、キャッシュ期限まで反映されない
- Layer1/2 テストでは、キャッシング動作そのもの（TTL の効果）は検証対象外。初期値、範囲の検証のみ
- キャッシング動作の検証は Layer3 テストで実施

### 2.6 ハッシュ値生成

`InputConditions.hash_md5` プロパティは、すべてのフィールドを文字列化したうえで MD5 ハッシュを生成：

**用途**
- ダウンロードファイル名の一部
- キャッシュキーの一部
- 条件の一意識別

**要件**
- 同じ InputConditions からは常に同じハッシュ値を生成（再現性）
- 異なる InputConditions からは異なるハッシュ値を生成（一意性）
- ハッシュ値は 32 文字の 16 進数文字列

---

## 3. 制約・上限値

### 3.1 住所選択の上限

**MAX_SELECTED_CITY_COUNT = 15**

住所入力コンポーネント（`components_address_input()`）で市区町村を選択する際、上限は 15 個。

- **15 個以下**: 大字町域フェーズを表示
- **16 個以上**: 大字町域フェーズをスキップし、次フェーズに進む

**理由**: Snowflake クエリのパフォーマンス最適化

### 3.2 地点数超過時のスキップ

**地点数上限 = 100**

大字町域の地点数が 100 を超えた場合、字丁目フェーズをスキップ。

**例**: 福岡県福岡市中央区赤坂 の場合、地点数が 100 を超える可能性があり、この場合は字丁目フェーズが無効化される。

### 3.3 マップ表示の最大件数制限

**MAP_DEFAULT_MAX_ROWS = 5,000**
**MAP_MOREOVER_MAX_ROWS = 50,000**

加盟店データが検索結果として返されたとき、folium マップに表示する最大件数：

- **5,000 件以下**: 警告なしで表示
- **5,001 ～ 50,000 件**: 「上限を超えています。拡張しますか？」とダイアログ表示
- **50,001 件以上**: エラーメッセージ表示。マップ表示不可

### 3.4 ダウンロード形式の自動制限

**DOWNLOAD_EXCEL_FILE_MERCHANT_LIMIT = 50,000**

加盟店データのダウンロード形式を自動制御：

- **50,000 件以下**: Excel（.xlsx）と CSV（ZIP 圧縮）の両形式対応
- **50,001 件以上**: CSV（ZIP 圧縮）形式のみ

**理由**: Excel の行数上限（約 100 万行）とメモリ制限の考慮

### 3.5 キーワード検索の件数制限

**KEYWORD_SEARCH_LIMIT = 50,000**

キーワード検索の最大検索可能件数。超過した場合、エラーメッセージを表示。

### 3.6 ユーザーリストダウンロードの件数制限

**MAX_USER_LIST_SIZE = 1,000,000**

ユーザーリストダウンロードの最大件数。超過した場合、ダウンロード不可。

### 3.7 店舗検索結果の表示件数

**MAX_STORE_SEARCH_COUNT = 15**

店舗検索結果の最大表示件数。超過した場合、結果を制限して表示。

---

## 4. ユーザー属性マッピング

### 4.1 性別コード

```
GENDER_CODE_MAP = {
    "1": "男性",
    "2": "女性"
}
```

### 4.2 年代コード

```
NENDAI_CODE_MAP = {
    "00": "10代未満",
    "01": "10代",
    "02": "20代",
    "03": "30代",
    "04": "40代",
    "05": "50代",
    "06": "60代",
    "07": "70代",
    "08": "80代以上"
}
```

全 9 種類。

### 4.3 決済方式

**全決済方式 (PAYMENT_METHOD_LIST)**
- 全決済方式マッピングは `app/lib/const.py` で定義（11 種類）

**中小個店向け (PAYMENT_METHOD_LIST_SM)**
- 中小個店向けサブセット（7 種類）

RenderOptions.payment_method_list でフィルタリング可能。

---

## 5. エラーハンドリング要件

### 5.1 入力検証エラー

InputConditions の check プロパティが False を返した場合、ユーザーに以下のいずれかのメッセージを表示：

- 「日付が正しく指定されていません」（日付が未設定）
- 「検索条件をいずれか1つ以上指定してください」（検索条件がすべて未設定）
- 「比較期間を指定してください」（enable_comparison=True だが comparison_dates が未設定）

**使用関数**: `st.error()`

### 5.2 検索結果なし

Snowflake クエリから加盟店データが 0 件返された場合、以下のメッセージを表示：

- 「条件に合致する加盟店がありません」

**使用関数**: `st.warning()`

### 5.3 ダウンロードエラー

ファイル生成、PochiStorage アップロード、署名付き URL 生成に失敗した場合：

- 「ダウンロード準備に失敗しました。時間をおいて再度お試しください。」

**使用関数**: `st.error()`
**ログ出力**: `traceback.print_exc()` でスタックトレース出力

### 5.4 キャッシュエラー（内部）

キャッシュ生成時に例外が発生した場合、例外をキャッチして適切にハンドル。

**ログ出力**: 開発チーム向けデバッグログ

---

## 6. JSON シリアライゼーション

### 6.1 json_serial() ユーティリティ

`datetime` オブジェクトと `date` オブジェクトを JSON シリアライズ可能な形式に変換：

```python
def json_serial(obj):
    """JSON シリアライズ対応オブジェクトを返す"""
    if isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")
```

**ISO 8601 形式**:
- `datetime`: "2024-01-15T10:30:45"
- `date`: "2024-01-15"

### 6.2 to_json() ユーティリティ

オブジェクトを JSON 文字列に変換。日本語は UTF-8 で正しくエンコード：

```python
def to_json(obj):
    """オブジェクトを JSON 文字列に変換"""
    return json.dumps(obj, default=json_serial, ensure_ascii=False)
```

**要件**:
- `ensure_ascii=False`: 日本語文字が \uXXXX エスケープされない
- `default=json_serial`: datetime, date 対応

---

## 7. 文字幅計算（Excel 列幅調整）

### 7.1 get_east_asian_width_count()

全角・半角文字の表示幅を正確にカウント。Excel 出力時の列幅自動調整に使用：

- **全角文字**（CJK）: 2 幅
- **半角文字**: 1 幅
- **曖昧幅（Ambiguous）**: 環境依存（通常は 1 幅）

**例**:
- "あいう" → 6（全角 3 × 2）
- "abc" → 3（半角 3 × 1）
- "aあb" → 5（1 + 2 + 1 + 1）

---

## 8. Streamlit UI コンポーネント仕様

### 8.1 disabled パラメータ

各 UI コンポーネント（`components_address_input()`, `components_store_search()`, など）は `disabled` パラメータをサポート：

- `disabled=False`: ウィジェット操作可能（デフォルト）
- `disabled=True`: ウィジェット操作不可（灰色表示）

ネストしたウィジェットの disabled 状態は親に連動する。

### 8.2 コンテナの height パラメータ

一部コンポーネントでは、コンテナの高さを固定値で指定：

- `components_address_input()`: `height=350px`

**注意**: この固定値はレスポンシブでなく、内容が多い場合にスクロール不可になる可能性あり。

---

## 9. テスト対象範囲の分類

### Layer1（単体テスト - データ契約検証）
- InputConditions、RenderOptions の初期値、型、NULL 許容の検証
- 定数値の整合性確認
- JSON シリアライゼーション（純粋関数）
- 文字幅計算（純粋関数）
- UI コンポーネントの初期状態（Streamlit AppTest 使用）

### Layer2（単体テスト - ロジック検証）
- InputConditions.check プロパティの検証ロジック
- InputConditions.hash_md5 の再現性・一意性
- get_pref_code() のコード変換正確性
- 住所マスタデータの読み込み・返却形式
- 純粋関数の業務ロジック（キャッシュなし）

### Layer3（統合テスト）
- @st.cache_data, @st.cache_resource デコレータ付き関数（キャッシング動作検証）
- Snowflake 依存関数（モック使用）
- PochiStorage 依存関数（モック使用）
- Streamlit UI フロー全体（AppTest / Playwright E2E）

---

## 10. 参考: モック対象範囲

以下の外部依存は Layer1/2 テストで **必ずモック** すること：

- `streamlit` (Streamlit API)
- `snowflake` (Snowflake 接続)
- `pochilib` (PochiStorage, PochiUserInfo)

以下は **モック不要** で実際に使用：

- `pandas` (データフレーム操作)
- `numpy` (数値計算)
- `sqlalchemy` (SQL 構築)
- `plotly`, `folium` (グラフ・地図ライブラリ)
- `dateutil` (日時処理)
- 標準ライブラリ（`json`, `datetime` など）

---

## 11. アプリケーション識別情報

**APP_NAME**: "d-pay-merchant-visualizer"
**Python Version**: ~3.10
**Framework**: Streamlit
**Entrypoint**: app/main.py

