"""InputConditions データ契約テスト。

データスキーマ・型・NULL制約・ビジネスルールを検証する。

Layer1 データ契約テスト実装：
- InputConditions の必須フィールドとオプショナルフィールドの型検証
- データ契約（data-contracts.json）の仕様との整合性検証
- 正常系・異常系・境界値テストの実施
"""

import json
from datetime import date
from pathlib import Path
from typing import Any

import pytest

# =============================================================================
# フィクスチャディレクトリとヘルパー関数
# =============================================================================

FIXTURES_DIR = Path(__file__).parent.parent / "fixtures"
CONTRACTS_DIR = Path(__file__).parent
DATA_CONTRACTS_FILE = CONTRACTS_DIR / "data-contracts.json"


def load_contracts() -> dict:
    """data-contracts.json を読み込む。"""
    with open(DATA_CONTRACTS_FILE, encoding="utf-8") as f:
        return json.load(f)


def get_input_conditions_contract() -> dict:
    """data-contracts.json から InputConditions スキーマ定義を抽出。"""
    contracts = load_contracts()
    for boundary in contracts["boundaries"]:
        if boundary["name"] == "input_conditions":
            return boundary
    raise ValueError("input_conditions boundary not found in data-contracts.json")


# =============================================================================
# テストクラス: スキーマ検証
# =============================================================================


class TestInputConditionsSchema:
    """InputConditions スキーマ検証テスト。"""

    def test_required_fields_have_correct_type(self, input_conditions_basic: Any) -> None:
        """InputConditions の必須フィールドが正しい型を持つこと。

        テスト観点:
        - start_date と end_date が date 型であること
        - enable_comparison が bool 型であること
        - keyword_search_method が str 型であること

        RISK: RC-D001, RC-D003
        """
        assert isinstance(input_conditions_basic.start_date, date)
        assert isinstance(input_conditions_basic.end_date, date)
        assert isinstance(input_conditions_basic.enable_comparison, bool)
        assert isinstance(input_conditions_basic.keyword_search_method, str)

    def test_all_fields_are_defined(self, input_conditions_basic: Any) -> None:
        """InputConditions が期待するフィールドをすべて持つこと。

        テスト観点:
        - data-contracts.json で定義された全フィールドが属性として存在すること
        - フィールド数が 22 個であること

        RISK: RC-D003, RC-T001
        """
        contract = get_input_conditions_contract()
        expected_fields = [field["name"] for field in contract["fields"]]

        for field in expected_fields:
            assert hasattr(
                input_conditions_basic, field
            ), f"InputConditions に '{field}' フィールドが存在すること"

        assert (
            len(expected_fields) == 22
        ), f"フィールド数が 22 であること（実際: {len(expected_fields)}）"

    def test_optional_fields_are_correctly_typed(
        self, input_conditions_full: Any
    ) -> None:
        """オプショナルフィールドが None または期待する型を持つこと。

        テスト観点:
        - prefecture_cd が None または str 型
        - city_cd が None または list 型
        - address_cd が None または list 型

        RISK: RC-D003
        """
        assert input_conditions_full.prefecture_cd is None or isinstance(
            input_conditions_full.prefecture_cd, str
        )
        assert input_conditions_full.city_cd is None or isinstance(
            input_conditions_full.city_cd, list
        )
        assert input_conditions_full.address_cd is None or isinstance(
            input_conditions_full.address_cd, list
        )

    def test_default_values_are_correct(self) -> None:
        """InputConditions のデフォルト値が仕様通りであること。

        テスト観点:
        - enable_comparison の デフォルト = False
        - keyword_search_method の デフォルト = "company_store"

        RISK: RC-D003
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
        )
        assert ic.enable_comparison is False
        assert ic.keyword_search_method == "company_store"

    def test_frozen_dataclass_immutable(
        self, input_conditions_basic: Any
    ) -> None:
        """InputConditions が frozen dataclass であるため、値が変更不可であること。

        テスト観点:
        - インスタンス化後に フィールドを変更しようとすると FrozenInstanceError が発生

        RISK: RC-D001
        """
        with pytest.raises(Exception):  # FrozenInstanceError
            input_conditions_basic.start_date = date(2024, 12, 31)  # type: ignore


# =============================================================================
# テストクラス: NULL制約検証
# =============================================================================


class TestInputConditionsNullConstraints:
    """InputConditions の NULL 制約検証テスト。"""

    def test_required_fields_none_makes_check_false(self) -> None:
        """start_date が None の場合、check プロパティが False を返すこと。

        テスト観点:
        - InputConditions はデータクラスのためランタイム型チェックなし
        - check プロパティで isinstance 確認し False を返す

        RISK: RC-D001, RC-D003
        """
        from lib.models import InputConditions

        ic = InputConditions(  # type: ignore
            start_date=None,  # type: ignore
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
        )
        # start_date が date 型でないため check は False を返す
        assert ic.check is False

    def test_optional_fields_allow_none(self) -> None:
        """prefecture_cd などのオプショナルフィールドが None でも問題ないこと。

        テスト観点:
        - オプショナルフィールドを省略または None で初期化可能
        - インスタンスが正常に生成される

        RISK: RC-D003
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
            prefecture_cd=None,
            city_cd=None,
            gender_cd=None,
        )
        assert ic.prefecture_cd is None
        assert ic.city_cd is None
        assert ic.gender_cd is None

    def test_comparison_fields_allow_none(self, input_conditions_basic: Any) -> None:
        """enable_comparison=False の場合、comparison_start_date と comparison_end_date が None でも問題ないこと。

        テスト観点:
        - enable_comparison=False のとき、比較期間フィールドが None
        - インスタンスが正常に生成される

        RISK: RC-D003
        """
        assert input_conditions_basic.enable_comparison is False
        assert input_conditions_basic.comparison_start_date is None
        assert input_conditions_basic.comparison_end_date is None


# =============================================================================
# テストクラス: 列挙値（Enum）検証
# =============================================================================


class TestInputConditionsEnumValues:
    """InputConditions の列挙値検証テスト。"""

    def test_gender_cd_only_accepts_valid_values(self) -> None:
        """gender_cd が '1' または '2' のみ許容されること。

        テスト観点:
        - gender_cd = '1' （男性）で正常に生成
        - gender_cd = '2' （女性）で正常に生成
        - gender_cd = None で許容

        RISK: RC-D001
        """
        from lib.models import InputConditions

        ic_male = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            gender_cd="1",
            keyword_search_word="テスト",
        )
        assert ic_male.gender_cd == "1"

        ic_female = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            gender_cd="2",
            keyword_search_word="テスト",
        )
        assert ic_female.gender_cd == "2"

    def test_nendai_cd_list_only_accepts_valid_values(self) -> None:
        """nendai_cd_list が '00' ～ '08' のコードのみ許容されること。

        テスト観点:
        - nendai_cd_list = ['00', '01', '02'] で正常に生成
        - 無効なコード（'99' など）を含んでも dataclass レベルでは許可される
          （ビジネスロジック側で検証）

        RISK: RC-D001
        """
        from lib.models import InputConditions

        valid_codes = ["00", "01", "02", "03", "04", "05", "06", "07", "08"]
        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            nendai_cd_list=valid_codes,
            keyword_search_word="テスト",
        )
        assert ic.nendai_cd_list == valid_codes
        assert len(ic.nendai_cd_list) == 9

    def test_keyword_search_method_only_accepts_valid_values(self) -> None:
        """keyword_search_method が 'company_store', 'company', 'store', 'address' のみ許容されること。

        テスト観点:
        - keyword_search_method = 'company_store' で正常に生成
        - keyword_search_method = 'company' で正常に生成
        - keyword_search_method = 'store' で正常に生成
        - keyword_search_method = 'address' で正常に生成

        RISK: RC-D001, RC-B003
        """
        from lib.models import InputConditions

        valid_methods = ["company_store", "company", "store", "address"]
        for method in valid_methods:
            ic = InputConditions(
                start_date=date(2024, 1, 1),
                end_date=date(2024, 1, 31),
                keyword_search_method=method,  # type: ignore
                keyword_search_word="テスト",
            )
            assert ic.keyword_search_method == method


# =============================================================================
# テストクラス: 日付制約検証
# =============================================================================


class TestInputConditionsDateConstraints:
    """InputConditions の日付制約検証テスト。"""

    def test_start_date_and_end_date_are_date_type(self, input_conditions_basic: Any) -> None:
        """start_date と end_date が date 型であること。

        テスト観点:
        - type(start_date) == datetime.date
        - type(end_date) == datetime.date

        RISK: RC-D001
        """
        assert type(input_conditions_basic.start_date) == date
        assert type(input_conditions_basic.end_date) == date

    def test_same_dates_are_allowed(self, input_conditions_same_dates: Any) -> None:
        """start_date == end_date （同一日）を指定可能であること。

        テスト観点:
        - 1日単位の集計に対応するため、同一日の指定を許可

        RISK: RC-E001
        """
        assert input_conditions_same_dates.start_date == input_conditions_same_dates.end_date
        assert input_conditions_same_dates.start_date == date(2024, 1, 15)

    def test_long_period_dates_are_allowed(self, input_conditions_long_period: Any) -> None:
        """長期間（36ヶ月以上）の日付を指定可能であること。

        テスト観点:
        - 開始日 2021-07-01 から最新日までの 36 ヶ月期間を指定可能
        - 実際には日付の妥当性チェック（BR-004）は check プロパティで行う

        RISK: RC-E002
        """
        date_diff = input_conditions_long_period.end_date - input_conditions_long_period.start_date
        # 24ヶ月以上（フィクスチャは 2023-01-01 〜 2024-12-31 = 730日）
        assert date_diff.days >= 365


# =============================================================================
# テストクラス: リスト型フィールド検証
# =============================================================================


class TestInputConditionsListFields:
    """InputConditions のリスト型フィールド検証テスト。"""

    def test_city_cd_is_list_type(self, input_conditions_full: Any) -> None:
        """city_cd がリスト型であること。

        テスト観点:
        - city_cd は list[str] 型または None
        - リスト内のすべての要素が str

        RISK: RC-D003
        """
        if input_conditions_full.city_cd is not None:
            assert isinstance(input_conditions_full.city_cd, list)
            assert all(isinstance(item, str) for item in input_conditions_full.city_cd)

    def test_address_cd_is_list_type(self, input_conditions_full: Any) -> None:
        """address_cd がリスト型であること。

        テスト観点:
        - address_cd は list[str] 型または None
        - リスト内のすべての要素が str

        RISK: RC-D003
        """
        if input_conditions_full.address_cd is not None:
            assert isinstance(input_conditions_full.address_cd, list)
            assert all(isinstance(item, str) for item in input_conditions_full.address_cd)

    def test_nendai_cd_list_is_list_type(self, input_conditions_full: Any) -> None:
        """nendai_cd_list がリスト型であること。

        テスト観点:
        - nendai_cd_list は list[str] 型または None
        - リスト内のすべての要素が str

        RISK: RC-D003
        """
        if input_conditions_full.nendai_cd_list is not None:
            assert isinstance(input_conditions_full.nendai_cd_list, list)
            assert all(isinstance(item, str) for item in input_conditions_full.nendai_cd_list)

    def test_payment_method_list_is_list_type(self, input_conditions_full: Any) -> None:
        """payment_method_list がリスト型であること。

        テスト観点:
        - payment_method_list は list[str] 型または None
        - リスト内のすべての要素が str

        RISK: RC-D003
        """
        if input_conditions_full.payment_method_list is not None:
            assert isinstance(input_conditions_full.payment_method_list, list)
            assert all(
                isinstance(item, str) for item in input_conditions_full.payment_method_list
            )

    def test_empty_list_is_allowed(self) -> None:
        """空リストが許容されること。

        テスト観点:
        - city_cd = [] で正常に生成
        - 空リストであっても検索条件チェック（check プロパティ）で検出される

        RISK: RC-E001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            city_cd=[],
            prefecture_cd="40",
            keyword_search_word="テスト",
        )
        assert ic.city_cd == []


# =============================================================================
# テストクラス: 浮動小数点型フィールド検証
# =============================================================================


class TestInputConditionsFloatFields:
    """InputConditions の浮動小数点型フィールド検証テスト。"""

    def test_map_search_latitude_is_float_type(self, input_conditions_map_search: Any) -> None:
        """map_search_latitude が float 型であること。

        テスト観点:
        - map_search_latitude は float または None
        - 緯度範囲: -90.0 ～ 90.0

        RISK: RC-D003
        """
        if input_conditions_map_search.map_search_latitude is not None:
            assert isinstance(input_conditions_map_search.map_search_latitude, (int, float))

    def test_map_search_longitude_is_float_type(self, input_conditions_map_search: Any) -> None:
        """map_search_longitude が float 型であること。

        テスト観点:
        - map_search_longitude は float または None
        - 経度範囲: -180.0 ～ 180.0

        RISK: RC-D003
        """
        if input_conditions_map_search.map_search_longitude is not None:
            assert isinstance(input_conditions_map_search.map_search_longitude, (int, float))

    def test_map_search_radius_km_is_float_type(self, input_conditions_map_search: Any) -> None:
        """map_search_radius_km が float 型であること。

        テスト観点:
        - map_search_radius_km は float または None
        - 値は 0.0 以上

        RISK: RC-D003
        """
        if input_conditions_map_search.map_search_radius_km is not None:
            assert isinstance(input_conditions_map_search.map_search_radius_km, (int, float))
            assert input_conditions_map_search.map_search_radius_km >= 0.0

    def test_store_search_coordinate_fields_are_float_type(
        self, input_conditions_store_search: Any
    ) -> None:
        """store_center_latitude と store_center_longitude が float 型であること。

        テスト観点:
        - store_center_latitude は float または None
        - store_center_longitude は float または None

        RISK: RC-D003
        """
        if input_conditions_store_search.store_center_latitude is not None:
            assert isinstance(input_conditions_store_search.store_center_latitude, (int, float))
        if input_conditions_store_search.store_center_longitude is not None:
            assert isinstance(input_conditions_store_search.store_center_longitude, (int, float))


# =============================================================================
# テストクラス: 文字列フィールド検証
# =============================================================================


class TestInputConditionsStringFields:
    """InputConditions の文字列フィールド検証テスト。"""

    def test_prefecture_cd_is_string_type(self, input_conditions_full: Any) -> None:
        """prefecture_cd が str 型であること。

        テスト観点:
        - prefecture_cd は str または None
        - 値の妥当性チェック（JISコード）は別テストで実施

        RISK: RC-D003
        """
        if input_conditions_full.prefecture_cd is not None:
            assert isinstance(input_conditions_full.prefecture_cd, str)

    def test_selected_store_id_is_string_type(self, input_conditions_store_search: Any) -> None:
        """selected_store_id が str 型であること。

        テスト観点:
        - selected_store_id は str または None

        RISK: RC-D003
        """
        if input_conditions_store_search.selected_store_id is not None:
            assert isinstance(input_conditions_store_search.selected_store_id, str)

    def test_keyword_search_word_is_string_type(self, input_conditions_basic: Any) -> None:
        """keyword_search_word が str 型であること。

        テスト観点:
        - keyword_search_word は str または None
        - 特殊文字、日本語を含む文字列も許容

        RISK: RC-D003
        """
        if input_conditions_basic.keyword_search_word is not None:
            assert isinstance(input_conditions_basic.keyword_search_word, str)

    def test_special_characters_are_allowed(self, input_conditions_special_chars: Any) -> None:
        """全角文字、特殊文字を含む文字列が許容されること。

        テスト観点:
        - keyword_search_word に日本語を含む
        - 企業名、店舗名に特殊文字を含む

        RISK: RC-E003
        """
        assert input_conditions_special_chars.keyword_search_word is not None
        # 日本語または特殊文字を含むことを確認
        assert len(input_conditions_special_chars.keyword_search_word) > 0


# =============================================================================
# テストクラス: 比較期間フィールド検証
# =============================================================================


class TestInputConditionsComparisonFields:
    """InputConditions の比較期間フィールド検証テスト。"""

    def test_comparison_fields_type_when_enabled(self, input_conditions_with_comparison: Any) -> None:
        """enable_comparison=True の場合、comparison_start_date と comparison_end_date が date 型であること。

        テスト観点:
        - comparison_start_date が date 型
        - comparison_end_date が date 型
        - 両フィールドが None でない

        RISK: RC-D001
        """
        assert input_conditions_with_comparison.enable_comparison is True
        assert isinstance(input_conditions_with_comparison.comparison_start_date, date)
        assert isinstance(input_conditions_with_comparison.comparison_end_date, date)

    def test_comparison_period_respects_date_order(self, input_conditions_with_comparison: Any) -> None:
        """comparison_start_date <= comparison_end_date であること。

        テスト観点:
        - 比較期間の日付順序が正しい

        RISK: RC-D001
        """
        assert (
            input_conditions_with_comparison.comparison_start_date
            <= input_conditions_with_comparison.comparison_end_date
        )

    def test_comparison_fields_are_none_when_disabled(
        self, input_conditions_basic: Any
    ) -> None:
        """enable_comparison=False の場合、comparison_start_date と comparison_end_date が None であること。

        テスト観点:
        - enable_comparison=False のとき、比較期間フィールドは None

        RISK: RC-D003
        """
        assert input_conditions_basic.enable_comparison is False
        assert input_conditions_basic.comparison_start_date is None
        assert input_conditions_basic.comparison_end_date is None
