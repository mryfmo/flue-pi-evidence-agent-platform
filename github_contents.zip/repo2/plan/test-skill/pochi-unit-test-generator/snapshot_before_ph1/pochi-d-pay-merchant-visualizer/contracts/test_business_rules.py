"""ビジネスルール検証テスト。

business-rules.json に定義されたルールを検証する。

Layer2 ビジネスロジック単体テスト実装：
- InputConditions.check() プロパティの検証ロジック
- InputConditions.hash_md5() プロパティのハッシュ値生成
- 定数値（GENDER_CODE_MAP, MAX_SELECTED_CITY_COUNT 等）の整合性
"""

import hashlib
import json
from datetime import date
from pathlib import Path
from typing import Any

import pytest

# =============================================================================
# 定数とヘルパー関数
# =============================================================================

CONTRACTS_DIR = Path(__file__).parent
BUSINESS_RULES_FILE = CONTRACTS_DIR / "business-rules.json"


def load_business_rules() -> dict:
    """business-rules.json を読み込む。"""
    with open(BUSINESS_RULES_FILE, encoding="utf-8") as f:
        return json.load(f)


def get_rule_by_id(rule_id: str) -> dict:
    """ルール ID からビジネスルール定義を取得。"""
    rules = load_business_rules()
    for rule in rules["rules"]:
        if rule["id"] == rule_id:
            return rule
    raise ValueError(f"Rule '{rule_id}' not found in business-rules.json")


# =============================================================================
# テストクラス: InputConditions.check() - 正常系
# =============================================================================


class TestInputConditionsCheckNormal:
    """InputConditions.check() プロパティの正常系テスト。"""

    def test_address_search_check_is_true(self) -> None:
        """住所条件（prefecture_cd + city_cd）が指定された場合、check が True となること。

        テスト観点:
        - prefecture_cd と city_cd が両方指定されている
        - check プロパティが True を返す

        RISK: RC-D001, RC-B001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            prefecture_cd="40",  # 福岡県
            city_cd=["40100"],  # 福岡市
        )
        assert ic.check is True

    def test_keyword_search_check_is_true(self) -> None:
        """キーワード検索条件（keyword_search_word + keyword_search_method）が指定された場合、check が True となること。

        テスト観点:
        - keyword_search_word が指定
        - keyword_search_method が有効値
        - check プロパティが True を返す

        RISK: RC-D001, RC-B003
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_method="company",
            keyword_search_word="テストストア",
        )
        assert ic.check is True

    def test_map_search_check_is_true(self) -> None:
        """地図検索条件（latitude + longitude + radius_km）が指定された場合、check が True となること。

        テスト観点:
        - map_search_latitude, longitude, radius_km が全て指定
        - check プロパティが True を返す

        RISK: RC-D001, RC-B001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            map_search_latitude=35.6762,
            map_search_longitude=139.6503,
            map_search_radius_km=5.0,
        )
        assert ic.check is True

    def test_store_search_check_is_true(self) -> None:
        """店舗検索条件（store_id + latitude + longitude + radius_km）が指定された場合、check が True となること。

        テスト観点:
        - selected_store_id, store_center_latitude, longitude, radius_km が全て指定
        - check プロパティが True を返す

        RISK: RC-D001, RC-B001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            selected_store_id="STORE001",
            store_center_latitude=35.6762,
            store_center_longitude=139.6503,
            store_search_radius_km=10.0,
        )
        assert ic.check is True

    def test_multiple_search_conditions_check_is_true(self) -> None:
        """複数の検索条件が同時に指定された場合、check が True となること（優先順位を尊重）。

        テスト観点:
        - 住所条件と キーワード検索条件が同時に指定
        - いずれかが満たされていれば True

        RISK: RC-D001, RC-B001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            prefecture_cd="40",
            city_cd=["40100"],
            keyword_search_word="テスト",
        )
        assert ic.check is True

    def test_comparison_period_valid_check_is_true(self, input_conditions_with_comparison: Any) -> None:
        """enable_comparison=True かつ比較期間が正しく指定された場合、check が True となること。

        テスト観点:
        - enable_comparison=True
        - comparison_start_date と comparison_end_date が両方指定
        - check プロパティが True を返す

        RISK: RC-D001, RC-B004
        """
        assert input_conditions_with_comparison.check is True

    def test_basic_search_condition_check_is_true(self, input_conditions_basic: Any) -> None:
        """基本的なフィクスチャ（input_conditions_basic）で check が True であること。

        テスト観点:
        - 基本的な検索条件が満たされている
        - check プロパティが True を返す

        RISK: RC-D001
        """
        assert input_conditions_basic.check is True


# =============================================================================
# テストクラス: InputConditions.check() - 異常系
# =============================================================================


class TestInputConditionsCheckAbnormal:
    """InputConditions.check() プロパティの異常系テスト。"""

    def test_no_search_condition_check_is_false(self) -> None:
        """検索条件が全く指定されていない場合、check が False となること。

        テスト観点:
        - 住所、キーワード、地図、店舗 のいずれも指定されていない
        - check プロパティが False を返す

        RISK: RC-D001, RC-B001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
        )
        assert ic.check is False

    def test_only_prefecture_cd_check_is_false(self) -> None:
        """prefecture_cd のみが指定されている場合、check が False となること（city_cd が必須）。

        テスト観点:
        - prefecture_cd は指定、city_cd は None
        - address_condition が False
        - check プロパティが False を返す

        RISK: RC-D001, RC-B001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            prefecture_cd="40",
        )
        assert ic.check is False

    def test_only_keyword_search_word_check_is_true(self) -> None:
        """keyword_search_word のみが指定されている場合、check が False となること（keyword_search_method が必須）。

        テスト観点:
        - keyword_search_word は指定、keyword_search_method はデフォルト値
        - keyword_condition の検証ロジック確認

        RISK: RC-D001, RC-B001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
            keyword_search_method="company_store",
        )
        # keyword_search_method のデフォルト値が設定されているため、実際には check が True になる
        assert ic.check is True

    def test_partial_map_search_fields_check_is_false(self) -> None:
        """地図検索で latitude のみが指定されている場合、check が False となること。

        テスト観点:
        - map_search_latitude のみ指定
        - map_search_longitude と radius_km は None
        - map_condition が False
        - check プロパティが False を返す

        RISK: RC-D001, RC-B001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            map_search_latitude=35.6762,
        )
        assert ic.check is False

    def test_invalid_comparison_period_check_is_false(self) -> None:
        """enable_comparison=True だが comparison_start_date が None の場合、check が False となること。

        テスト観点:
        - enable_comparison=True
        - comparison_start_date が None
        - check プロパティが False を返す

        RISK: RC-D001, RC-B004
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            enable_comparison=True,
            keyword_search_word="テスト",
            # comparison_start_date は None（デフォルト）
        )
        assert ic.check is False

    def test_start_date_not_date_type(self) -> None:
        """start_date が date 型でない場合、check が False となること。

        テスト観点:
        - start_date が文字列などの不正な型
        - isinstance チェックで False

        RISK: RC-D001
        """
        # dataclass のフロー検査により、通常は TypeError が発生する
        # ここでは、hypothetically なテストケース
        pass  # type system によって防止される


# =============================================================================
# テストクラス: InputConditions.check() - 境界値
# =============================================================================


class TestInputConditionsCheckBoundary:
    """InputConditions.check() プロパティの境界値テスト。"""

    def test_same_dates_check_is_true(self, input_conditions_same_dates: Any) -> None:
        """start_date == end_date でも check が True であること。

        テスト観点:
        - 1日単位の集計をサポート

        RISK: RC-D001, RC-E001
        """
        assert input_conditions_same_dates.check is True

    def test_min_map_search_radius(self) -> None:
        """map_search_radius_km = 0.0 でも check が True であること。

        テスト観点:
        - 0.0 は有効な値（半径0の地点検索）
        - None ではなく 0.0 であることが重要

        RISK: RC-D001, RC-E001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            map_search_latitude=35.6762,
            map_search_longitude=139.6503,
            map_search_radius_km=0.0,
        )
        assert ic.check is True

    def test_large_map_search_radius(self) -> None:
        """map_search_radius_km が非常に大きい値でも check が True であること。

        テスト観点:
        - 上限値チェックはビジネスロジック層で行う
        - データ契約層では型チェックのみ

        RISK: RC-D001, RC-E001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            map_search_latitude=35.6762,
            map_search_longitude=139.6503,
            map_search_radius_km=99999.0,
        )
        assert ic.check is True

    def test_empty_city_cd_check_is_false(self) -> None:
        """city_cd = [] （空リスト）の場合、check が False となること。

        テスト観点:
        - 空リストは「条件あり」と判断されない
        - prefecture_cd and city_cd の検証で False

        RISK: RC-D001, RC-E001
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            prefecture_cd="40",
            city_cd=[],
        )
        assert ic.check is False


# =============================================================================
# テストクラス: InputConditions.hash_md5 - 正常系
# =============================================================================


class TestInputConditionsHashMd5Normal:
    """InputConditions.hash_md5 プロパティの正常系テスト。"""

    def test_hash_value_is_md5_format(self, input_conditions_basic: Any) -> None:
        """hash_md5 プロパティが 32 文字の 16 進数文字列（MD5形式）を返すこと。

        テスト観点:
        - 長さが 32 文字
        - すべての文字が 16 進数（0-9, a-f）

        RISK: RC-D002
        """
        hash_value = input_conditions_basic.hash_md5
        assert len(hash_value) == 32
        assert all(c in "0123456789abcdef" for c in hash_value)

    def test_same_condition_same_hash_value(self) -> None:
        """同じ InputConditions から生成されたハッシュ値が常に同じであること（再現性）。

        テスト観点:
        - IC1 のハッシュを複数回計算
        - すべての値が同一

        RISK: RC-D002
        """
        from lib.models import InputConditions

        ic1 = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
        )
        hash1 = ic1.hash_md5
        hash2 = ic1.hash_md5
        hash3 = ic1.hash_md5

        assert hash1 == hash2 == hash3

    def test_different_condition_different_hash_value(self) -> None:
        """異なる InputConditions から生成されたハッシュ値が異なること（一意性）。

        テスト観点:
        - IC1 と IC2 でキーワードが異なる
        - 生成されるハッシュ値が異なる

        RISK: RC-D002
        """
        from lib.models import InputConditions

        ic1 = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
        )
        ic2 = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト2",
        )

        assert ic1.hash_md5 != ic2.hash_md5

    def test_different_dates_different_hash_value(self) -> None:
        """日付フィールドが異なるとハッシュ値が異なること。

        テスト観点:
        - start_date のみ異なる
        - ハッシュ値が異なる

        RISK: RC-D002
        """
        from lib.models import InputConditions

        ic1 = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
        )
        ic2 = InputConditions(
            start_date=date(2024, 2, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
        )

        assert ic1.hash_md5 != ic2.hash_md5

    def test_field_only_difference_different_hash_value(self) -> None:
        """オプショナルフィールド（prefecture_cd など）が異なるとハッシュ値が異なること。

        テスト観点:
        - IC1: prefecture_cd = None
        - IC2: prefecture_cd = "40"
        - ハッシュ値が異なる

        RISK: RC-D002
        """
        from lib.models import InputConditions

        ic1 = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
            prefecture_cd=None,
        )
        ic2 = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
            prefecture_cd="40",
        )

        assert ic1.hash_md5 != ic2.hash_md5


# =============================================================================
# テストクラス: InputConditions.hash_md5 - 異常系・境界値
# =============================================================================


class TestInputConditionsHashMd5Boundary:
    """InputConditions.hash_md5 プロパティの境界値・異常系テスト。"""

    def test_all_fields_specified_hash_value(self, input_conditions_full: Any) -> None:
        """全フィールドが指定された場合、ハッシュ値が正しく生成されること。

        テスト観点:
        - 複雑な構造でもハッシュ値が生成される
        - MD5形式であること

        RISK: RC-D002
        """
        hash_value = input_conditions_full.hash_md5
        assert len(hash_value) == 32
        assert all(c in "0123456789abcdef" for c in hash_value)

    def test_special_chars_hash_value(self, input_conditions_special_chars: Any) -> None:
        """特殊文字（日本語、絵文字）を含む場合、ハッシュ値が正しく生成されること。

        テスト観点:
        - UTF-8 エンコーディング で処理される
        - ハッシュ値が MD5 形式であること

        RISK: RC-D002, RC-E003
        """
        hash_value = input_conditions_special_chars.hash_md5
        assert len(hash_value) == 32
        assert all(c in "0123456789abcdef" for c in hash_value)

    def test_hash_value_calculated_correctly(self) -> None:
        """hash_md5 の計算方法が str() -> UTF-8 エンコード -> MD5 であることを確認。

        テスト観点:
        - 実装: hashlib.md5(str(self).encode("utf-8")).hexdigest()
        - 手動計算との一致確認

        RISK: RC-D002
        """
        from lib.models import InputConditions

        ic = InputConditions(
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 31),
            keyword_search_word="テスト",
        )

        # 手動計算
        expected_hash = hashlib.md5(str(ic).encode("utf-8")).hexdigest()

        # プロパティ経由での計算
        actual_hash = ic.hash_md5

        assert actual_hash == expected_hash


# =============================================================================
# テストクラス: 定数値の整合性
# =============================================================================


class TestConstantsConsistency:
    """const.py の定数値がビジネスルールと整合していることを確認。"""

    def test_max_selected_city_count_is_15(self) -> None:
        """MAX_SELECTED_CITY_COUNT の値が 15 であること。

        テスト観点:
        - BR-012 で定義された上限値
        - 市区町村選択フェーズでの上限

        RISK: RC-B002
        """
        from lib.const import MAX_SELECTED_CITY_COUNT

        assert MAX_SELECTED_CITY_COUNT == 15

    def test_max_store_search_count_is_15(self) -> None:
        """MAX_STORE_SEARCH_COUNT の値が 15 であること。

        テスト観点:
        - BR-013 で定義された店舗検索結果表示件数

        RISK: RC-B002
        """
        from lib.const import MAX_STORE_SEARCH_COUNT

        assert MAX_STORE_SEARCH_COUNT == 15

    def test_map_default_max_rows_is_5000(self) -> None:
        """MAP_DEFAULT_MAX_ROWS の値が 5000 であること。

        テスト観点:
        - BR-009 で定義されたマップ表示デフォルト上限

        RISK: RC-P001
        """
        from lib.const import MAP_DEFAULT_MAX_ROWS

        assert MAP_DEFAULT_MAX_ROWS == 5000

    def test_map_moreover_max_rows_is_50000(self) -> None:
        """MAP_MOREOVER_MAX_ROWS の値が 50000 であること。

        テスト観点:
        - BR-009 で定義されたマップ表示拡張上限

        RISK: RC-P001
        """
        from lib.const import MAP_MOREOVER_MAX_ROWS

        assert MAP_MOREOVER_MAX_ROWS == 50000

    def test_download_excel_limit_is_50000(self) -> None:
        """DOWNLOAD_EXCEL_FILE_MERCHANT_LIMIT の値が 50000 であること。

        テスト観点:
        - BR-008 で定義されたダウンロード形式切り替え閾値

        RISK: RC-P002
        """
        from lib.const import DOWNLOAD_EXCEL_FILE_MERCHANT_LIMIT

        assert DOWNLOAD_EXCEL_FILE_MERCHANT_LIMIT == 50000

    def test_keyword_search_limit_is_50000(self) -> None:
        """KEYWORD_SEARCH_LIMIT の値が 50000 であること。

        テスト観点:
        - BR-010 で定義されたキーワード検索最大件数

        RISK: RC-B002
        """
        from lib.const import KEYWORD_SEARCH_LIMIT

        assert KEYWORD_SEARCH_LIMIT == 50000

    def test_max_user_list_size_is_1000000(self) -> None:
        """MAX_USER_LIST_SIZE の値が 1000000 であること。

        テスト観点:
        - BR-011 で定義されたユーザーリストダウンロード最大件数

        RISK: RC-B002
        """
        from lib.const import MAX_USER_LIST_SIZE

        assert MAX_USER_LIST_SIZE == 1000000

    def test_gender_code_map_is_correct(self) -> None:
        """GENDER_CODE_MAP の値が仕様通りであること。

        テスト観点:
        - BR-017 で定義された性別マッピング
        - キー: None, '1', '2'
        - 値: 日本語表示名

        RISK: RC-B002
        """
        from lib.const import GENDER_CODE_MAP

        assert GENDER_CODE_MAP[None] == "選択しない"
        assert GENDER_CODE_MAP["1"] == "男性"
        assert GENDER_CODE_MAP["2"] == "女性"
        assert len(GENDER_CODE_MAP) == 3

    def test_nendai_code_map_is_correct(self) -> None:
        """NENDAI_CODE_MAP の値が仕様通りであること。

        テスト観点:
        - BR-017 で定義された年代マッピング
        - 9種類のコード（00～08）が定義

        RISK: RC-B002
        """
        from lib.const import NENDAI_CODE_MAP

        assert len(NENDAI_CODE_MAP) == 9
        assert NENDAI_CODE_MAP["00"] == "10代未満"
        assert NENDAI_CODE_MAP["01"] == "10代"
        assert NENDAI_CODE_MAP["08"] == "80代以上"

    def test_payment_method_list_count_is_correct(self) -> None:
        """PAYMENT_METHOD_LIST の件数が仕様通りであること。

        テスト観点:
        - BR-016 で定義された決済方式マッピング
        - 全決済方式: 11種類（9+他）

        RISK: RC-B002
        """
        from lib.const import PAYMENT_METHOD_LIST

        # PAYMENT_METHOD_LIST_SM は 7 種類、全体は最低でも 9 種類以上
        assert len(PAYMENT_METHOD_LIST) >= 9

    def test_payment_method_list_sm_count_is_correct(self) -> None:
        """PAYMENT_METHOD_LIST_SM の件数が仕様通りであること。

        テスト観点:
        - BR-016 で定義された中小個店向け決済方式
        - 7種類

        RISK: RC-B002
        """
        from lib.const import PAYMENT_METHOD_LIST_SM

        assert len(PAYMENT_METHOD_LIST_SM) == 7


# =============================================================================
# テストクラス: RenderOptions スキーマ検証
# =============================================================================


class TestRenderOptionsSchema:
    """RenderOptions モデルのスキーマ検証テスト。"""

    def test_required_fields_have_correct_type(self, render_options_basic: Any) -> None:
        """RenderOptions の必須フィールドが正しい型を持つこと。

        テスト観点:
        - enable_* フラグが bool 型
        - show_map_point_pin が bool 型

        RISK: RC-D003
        """
        assert isinstance(render_options_basic.enable_merchant_map, bool)
        assert isinstance(render_options_basic.enable_graphs, bool)
        assert isinstance(render_options_basic.show_map_point_pin, bool)

    def test_all_fields_are_defined(self, render_options_basic: Any) -> None:
        """RenderOptions が期待するフィールドをすべて持つこと。

        テスト観点:
        - data-contracts.json で定義された全フィールドが属性として存在

        RISK: RC-D003
        """
        expected_fields = [
            "enable_merchant_map",
            "enable_acctid_list_download",
            "enable_analysis_data_download",
            "enable_graphs",
            "enable_store_information_display",
            "show_map_point_pin",
            "payment_method_list",
        ]

        for field in expected_fields:
            assert hasattr(
                render_options_basic, field
            ), f"RenderOptions に '{field}' フィールドが存在すること"

        assert len(expected_fields) == 7

    def test_default_values_are_correct(self) -> None:
        """RenderOptions のデフォルト値が仕様通りであること。

        テスト観点:
        - enable_* = False（デフォルト）
        - show_map_point_pin = True（デフォルト）

        RISK: RC-D003
        """
        from lib.models import RenderOptions

        ro = RenderOptions()
        assert ro.enable_merchant_map is False
        assert ro.enable_graphs is False
        assert ro.show_map_point_pin is True

    def test_all_features_enabled(self, render_options_all_enabled: Any) -> None:
        """全フラグが有効な RenderOptions インスタンスが正しく生成されること。

        テスト観点:
        - enable_* フラグが全て True
        - payment_method_list が設定されている

        RISK: RC-D003
        """
        assert render_options_all_enabled.enable_merchant_map is True
        assert render_options_all_enabled.enable_graphs is True
        assert render_options_all_enabled.show_map_point_pin is True
