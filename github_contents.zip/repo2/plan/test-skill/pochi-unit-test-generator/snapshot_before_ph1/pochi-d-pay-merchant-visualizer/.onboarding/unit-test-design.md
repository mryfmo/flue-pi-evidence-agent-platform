# Layer2 ユニットテスト設計書

## 設計方針

### テスト比率
- **正常系**: 45% (11 テストケース)
- **異常系**: 35% (9 テストケース)
- **境界値**: 20% (5 テストケース)
- **合計**: 25 テストケース

### モック方針

#### Always Mock（外部依存性が強い）
- `pochilib`: PochiStorage, PochiUserInfo
- `streamlit`: st.cache_data, st.cache_resource（キャッシング動作検証は Layer3）
- `snowflake`: Snowflake クエリ実行
- `sqlalchemy`: ORM/SQL 実行

#### Never Mock（純粋な計算ロジック）
- `pandas`: DataFrame 操作
- `numpy`: 数値計算
- `unicodedata`: 文字幅判定
- `hashlib`: MD5 ハッシング
- `datetime.date`: 日付オブジェクト

---

## テスト対象モジュール一覧

### 対象モジュール（Layer2）

1. **`app/lib/models.py`**
   - `InputConditions.check` プロパティ（純粋関数）
   - `InputConditions.hash_md5` プロパティ（純粋関数）

2. **`app/lib/const.py`**
   - マッピング定数（GENDER_CODE_MAP, NENDAI_CODE_MAP）
   - 数値定数（MAX_SELECTED_CITY_COUNT など）

3. **`app/lib/generate_analysis_result_data.py`**
   - `get_east_asian_width_count()` 関数（純粋関数）
   - `_get_conditions_df()` 関数（Snowflake 依存のためモック必須）

4. **`app/lib/utils.py`**
   - `json_serial()` 関数（純粋関数）
   - `to_json()` 関数（純粋関数）
   - `get_streamlit_session_id()` 関数（Streamlit 依存）

### 対象外モジュール（Layer1 または Layer3）

- **`@st.cache_data/@st.cache_resource` 付き関数**: Layer3 テスト対象
  - `__create_xlsx_file_of_analysis_results()` (キャッシング検証)
  - `__create_csv_zip_file_of_analysis_results()` (キャッシング検証)
  - `get_usage_dates()` (キャッシング検証)
  - `get_regions_and_prefectures()` (キャッシング検証)
  - `get_concat_address()` (キャッシング検証)
  - `_filter_address_df_by_oaza_popularname()` (キャッシング検証)
  - `_filter_address_df_by_sectionname_chome()` (キャッシング検証)

- **Streamlit UI コンポーネント関数**: Layer1 AppTest 対象
  - `components_download_analysis_data()`
  - `components_address_input()`
  - `components_store_search()`

- **外部API/Snowflake 依存関数**: Layer3 テスト対象（モック必須）
  - `show_xlsx_file_download_link()` (PochiStorage 依存)
  - `show_csv_zip_file_download_link()` (PochiStorage 依存)
  - `show_dialog_download_analysis_data()` (@st.dialog 装飾)
  - `get_address_master_with_code()` (Snowflake 依存)
  - `get_address_master_with_name()` (Snowflake 依存)

---

## テスト対象関数詳細

### 1. `InputConditions.check` プロパティ

#### 機能説明
入力条件の妥当性をチェックし、以下の条件を検証する：
- 必須フィールド: `start_date`、`end_date` が date 型であること
- 検索条件: 以下のいずれかが満たされていること
  1. 住所条件: `prefecture_cd` と `city_cd` の両方
  2. キーワード検索: `keyword_search_method` と `keyword_search_word`
  3. 地図検索: `map_search_latitude`、`map_search_longitude`、`map_search_radius_km`
  4. 店舗検索: `selected_store_id`、`store_center_latitude`、`store_center_longitude`、`store_search_radius_km`
- 比較期間: `enable_comparison=True` の場合、`comparison_start_date`、`comparison_end_date` が date 型

#### テストケース

##### TC-M001: check プロパティ - 正常系（住所条件）
- **テスト関数名**: `test_check_returns_true_with_valid_address_condition`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is True`
- **期待値**: True
- **RISK**: RC-D001

##### TC-M002: check プロパティ - 正常系（キーワード検索条件）
- **テスト関数名**: `test_check_returns_true_with_valid_keyword_condition`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      keyword_search_method="company_store",
      keyword_search_word="テスト",
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is True`
- **期待値**: True
- **RISK**: RC-D001

##### TC-M003: check プロパティ - 正常系（地図検索条件）
- **テスト関数名**: `test_check_returns_true_with_valid_map_condition`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      map_search_latitude=35.6762,
      map_search_longitude=139.7674,
      map_search_radius_km=5.0,
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is True`
- **期待値**: True
- **RISK**: RC-D001

##### TC-M004: check プロパティ - 正常系（店舗検索条件）
- **テスト関数名**: `test_check_returns_true_with_valid_store_condition`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      selected_store_id="STORE001",
      store_center_latitude=35.6762,
      store_center_longitude=139.7674,
      store_search_radius_km=1.0,
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is True`
- **期待値**: True
- **RISK**: RC-D001

##### TC-M005: check プロパティ - 正常系（比較期間付き）
- **テスト関数名**: `test_check_returns_true_with_valid_comparison_period`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
      enable_comparison=True,
      comparison_start_date=date(2024, 12, 1),
      comparison_end_date=date(2024, 12, 31),
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is True`
- **期待値**: True
- **RISK**: RC-D001

##### TC-M006: check プロパティ - 正常系（複数の付加条件）
- **テスト関数名**: `test_check_returns_true_with_full_conditions`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
      gender_cd="1",
      nendai_cd_list=["01", "02"],
      big_jenre_list=["飲食"]
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is True`
- **期待値**: True
- **RISK**: RC-D001

##### TC-M007: check プロパティ - 正常系（キーワード＋地図の複数条件）
- **テスト関数名**: `test_check_returns_true_with_multiple_search_conditions`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
      map_search_latitude=35.6762,
      map_search_longitude=139.7674,
      map_search_radius_km=5.0,
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is True`
- **期待値**: True （複数条件のいずれかが満たされているので）
- **RISK**: RC-B001

##### TC-M008: check プロパティ - 異常系（検索条件がない）
- **テスト関数名**: `test_check_returns_false_when_no_search_condition`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is False`
- **期待値**: False
- **RISK**: RC-D001

##### TC-M009: check プロパティ - 異常系（start_date が無効）
- **テスト関数名**: `test_check_returns_false_when_start_date_is_not_date`
- **Arrange**: 
  ```python
  # dataclass frozen なので直接作成できない場合は、スキップまたはモック化
  # またはモックで start_date を date 型以外に変更する
  # 実装上、start_date は date 型として宣言されているため、この異常系をテストするには
  # 型チェックをバイパスする必要がある
  ```
- **テスト手法**: `typ.cast()` または pytest の `monkeypatch` で型バイパス
- **期待値**: False
- **RISK**: RC-D001

##### TC-M010: check プロパティ - 異常系（end_date が無効）
- **テスト関数名**: `test_check_returns_false_when_end_date_is_not_date`
- **期待値**: False
- **RISK**: RC-D001

##### TC-M011: check プロパティ - 異常系（比較期間有効だが comparison_start_date がない）
- **テスト関数名**: `test_check_returns_false_when_comparison_enabled_but_comparison_start_date_is_none`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
      enable_comparison=True,
      comparison_start_date=None,
      comparison_end_date=date(2024, 12, 31),
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is False`
- **期待値**: False
- **RISK**: RC-D001

##### TC-M012: check プロパティ - 異常系（比較期間有効だが comparison_end_date がない）
- **テスト関数名**: `test_check_returns_false_when_comparison_enabled_but_comparison_end_date_is_none`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
      enable_comparison=True,
      comparison_start_date=date(2024, 12, 1),
      comparison_end_date=None,
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is False`
- **期待値**: False
- **RISK**: RC-D001

##### TC-M013: check プロパティ - 異常系（住所条件：prefecture_cd のみ）
- **テスト関数名**: `test_check_returns_false_when_prefecture_cd_only`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=None,
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is False`
- **期待値**: False （prefecture_cd と city_cd 両方が必要）
- **RISK**: RC-D001

##### TC-M014: check プロパティ - 異常系（住所条件：city_cd のみ）
- **テスト関数名**: `test_check_returns_false_when_city_cd_only`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd=None,
      city_cd=["13101"],
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is False`
- **期待値**: False
- **RISK**: RC-D001

##### TC-M015: check プロパティ - 異常系（キーワード：検索方法のみ）
- **テスト関数名**: `test_check_returns_false_when_search_method_only`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      keyword_search_method="company_store",
      keyword_search_word=None,
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is False`
- **期待値**: False
- **RISK**: RC-D001

##### TC-M016: check プロパティ - 異常系（地図：latitude のみ）
- **テスト関数名**: `test_check_returns_false_when_map_latitude_only`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      map_search_latitude=35.6762,
      map_search_longitude=None,
      map_search_radius_km=None,
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is False`
- **期待値**: False
- **RISK**: RC-D001

##### TC-M017: check プロパティ - 境界値（start_date == end_date）
- **テスト関数名**: `test_check_returns_true_when_start_date_equals_end_date`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 15),
      end_date=date(2025, 1, 15),
      prefecture_cd="13",
      city_cd=["13101"],
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is True`
- **期待値**: True
- **RISK**: RC-D001

##### TC-M018: check プロパティ - 境界値（map_search_radius_km = 0.0）
- **テスト関数名**: `test_check_returns_true_when_radius_is_zero`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      map_search_latitude=35.6762,
      map_search_longitude=139.7674,
      map_search_radius_km=0.0,
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is True`
- **期待値**: True （radius_km は None でなければ OK）
- **RISK**: RC-D001

##### TC-M019: check プロパティ - 境界値（city_cd が空リスト）
- **テスト関数名**: `test_check_returns_false_when_city_cd_is_empty_list`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=[],
  )
  ```
- **Act**: `result = conditions.check`
- **Assert**: `assert result is False`
- **期待値**: False （空リストは falsy 値）
- **RISK**: RC-D001

---

### 2. `InputConditions.hash_md5` プロパティ

#### 機能説明
InputConditions インスタンスを文字列化して MD5 ハッシング。
ファイル名生成や検索条件の一意識別に使用。

#### テストケース

##### TC-M020: hash_md5 プロパティ - 正常系（ハッシュ値生成）
- **テスト関数名**: `test_hash_md5_returns_valid_hash`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
  )
  ```
- **Act**: `result = conditions.hash_md5`
- **Assert**: 
  ```python
  assert isinstance(result, str)
  assert len(result) == 32  # MD5 は32文字
  assert all(c in '0123456789abcdef' for c in result)  # 16進数
  ```
- **期待値**: 32 文字の 16 進数文字列
- **RISK**: RC-D002

##### TC-M021: hash_md5 プロパティ - 正常系（再現性確認）
- **テスト関数名**: `test_hash_md5_is_deterministic`
- **Arrange**: 
  ```python
  conditions1 = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
  )
  conditions2 = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
  )
  ```
- **Act**: 
  ```python
  hash1 = conditions1.hash_md5
  hash2 = conditions2.hash_md5
  ```
- **Assert**: `assert hash1 == hash2`
- **期待値**: 同一条件で同一ハッシュ
- **RISK**: RC-D002

##### TC-M022: hash_md5 プロパティ - 異常系（異なる条件で異なるハッシュ）
- **テスト関数名**: `test_hash_md5_differs_with_different_conditions`
- **Arrange**: 
  ```python
  conditions1 = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
  )
  conditions2 = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13102"],  # 異なる city_cd
  )
  ```
- **Act**: 
  ```python
  hash1 = conditions1.hash_md5
  hash2 = conditions2.hash_md5
  ```
- **Assert**: `assert hash1 != hash2`
- **期待値**: 異なる条件で異なるハッシュ
- **RISK**: RC-D002

##### TC-M023: hash_md5 プロパティ - 境界値（最小条件）
- **テスト関数名**: `test_hash_md5_with_minimal_conditions`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      keyword_search_method="company_store",
      keyword_search_word="test",
  )
  ```
- **Act**: `result = conditions.hash_md5`
- **Assert**: 
  ```python
  assert isinstance(result, str)
  assert len(result) == 32
  ```
- **期待値**: 有効なハッシュ値（32 文字）
- **RISK**: RC-D002

##### TC-M024: hash_md5 プロパティ - 異常系（None フィールド混在）
- **テスト関数名**: `test_hash_md5_with_none_fields`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd=None,
      city_cd=None,
      keyword_search_method="company",
      keyword_search_word="test",
  )
  ```
- **Act**: `result = conditions.hash_md5`
- **Assert**: 
  ```python
  assert isinstance(result, str)
  assert len(result) == 32
  ```
- **期待値**: 有効なハッシュ値
- **RISK**: RC-D002

---

### 3. `const.py` - 定数値検証

#### テストケース

##### TC-M025: const.py - 定数値の正当性確認
- **テスト関数名**: `test_const_values_are_correct`
- **Arrange**: `const` モジュールをインポート
- **Act**: 各定数値をチェック
- **Assert**: 
  ```python
  assert const.APP_NAME == "d-pay-merchant-visualizer"
  assert const.MAX_SELECTED_CITY_COUNT == 15
  assert const.MAX_STORE_SEARCH_COUNT == 15
  assert const.MAP_DEFAULT_MAX_ROWS == 5000
  assert const.MAP_MOREOVER_MAX_ROWS == 50000
  assert const.DOWNLOAD_EXCEL_FILE_MERCHANT_LIMIT == 50000
  assert const.KEYWORD_SEARCH_LIMIT == 50000
  assert const.MAX_USER_LIST_SIZE == 1000000
  ```
- **期待値**: 全て指定値と一致
- **RISK**: RC-D003

##### TC-M026: const.py - GENDER_CODE_MAP の整合性
- **テスト関数名**: `test_gender_code_map_keys_are_valid`
- **Arrange**: `GENDER_CODE_MAP` をインポート
- **Act**: キーの存在確認
- **Assert**: 
  ```python
  expected_keys = {None, "1", "2"}
  assert set(GENDER_CODE_MAP.keys()) == expected_keys
  assert GENDER_CODE_MAP[None] == "選択しない"
  assert GENDER_CODE_MAP["1"] == "男性"
  assert GENDER_CODE_MAP["2"] == "女性"
  ```
- **期待値**: 全キーが存在し、値が正確
- **RISK**: RC-D003

##### TC-M027: const.py - NENDAI_CODE_MAP の整合性
- **テスト関数名**: `test_nendai_code_map_keys_are_valid`
- **Arrange**: `NENDAI_CODE_MAP` をインポート
- **Act**: キーの存在確認
- **Assert**: 
  ```python
  expected_keys = {"00", "01", "02", "03", "04", "05", "06", "07", "08"}
  assert set(NENDAI_CODE_MAP.keys()) == expected_keys
  assert NENDAI_CODE_MAP["00"] == "10代未満"
  assert NENDAI_CODE_MAP["08"] == "80代以上"
  ```
- **期待値**: 全キーが存在し、値が正確
- **RISK**: RC-D003

---

### 4. `get_east_asian_width_count()` 関数

#### 機能説明
全角文字を 2、半角文字を 1 としてカウント。Excel 列幅自動調整用。

#### テストケース

##### TC-M028: get_east_asian_width_count - 正常系（全角文字のみ）
- **テスト関数名**: `test_get_east_asian_width_count_with_full_width_chars`
- **Arrange**: `text = "テスト"`
- **Act**: `result = get_east_asian_width_count(text)`
- **Assert**: `assert result == 6`  # 3 文字 × 2 = 6
- **期待値**: 6
- **RISK**: RC-T001

##### TC-M029: get_east_asian_width_count - 正常系（半角文字のみ）
- **テスト関数名**: `test_get_east_asian_width_count_with_half_width_chars`
- **Arrange**: `text = "test"`
- **Act**: `result = get_east_asian_width_count(text)`
- **Assert**: `assert result == 4`  # 4 文字 × 1 = 4
- **期待値**: 4
- **RISK**: RC-T001

##### TC-M030: get_east_asian_width_count - 正常系（混合文字）
- **テスト関数名**: `test_get_east_asian_width_count_with_mixed_chars`
- **Arrange**: `text = "テストabc123"`
- **Act**: `result = get_east_asian_width_count(text)`
- **Assert**: `assert result == 9`  # テスト(3×2) + abc(3×1) + 123(3×1) = 6 + 3 = 9
- **期待値**: 9
- **RISK**: RC-T001

##### TC-M031: get_east_asian_width_count - 異常系（空文字列）
- **テスト関数名**: `test_get_east_asian_width_count_with_empty_string`
- **Arrange**: `text = ""`
- **Act**: `result = get_east_asian_width_count(text)`
- **Assert**: `assert result == 0`
- **期待値**: 0
- **RISK**: RC-E001

##### TC-M032: get_east_asian_width_count - 異常系（特殊文字）
- **テスト関数名**: `test_get_east_asian_width_count_with_special_chars`
- **Arrange**: `text = "!@#$%"`
- **Act**: `result = get_east_asian_width_count(text)`
- **Assert**: `assert result == 5`  # 各特殊文字は半角扱い
- **期待値**: 5
- **RISK**: RC-T001

##### TC-M033: get_east_asian_width_count - 境界値（改行を含む）
- **テスト関数名**: `test_get_east_asian_width_count_with_newline`
- **Arrange**: `text = "テスト\nabc"`
- **Act**: `result = get_east_asian_width_count(text)`
- **Assert**: `assert result == 10`  # テスト(6) + \n(1) + abc(3) = 10
- **期待値**: 10
- **RISK**: RC-T001

---

### 5. `json_serial()` と `to_json()` 関数

#### テストケース

##### TC-M034: json_serial - 正常系（datetime オブジェクト）
- **テスト関数名**: `test_json_serial_with_datetime`
- **Arrange**: 
  ```python
  obj = datetime(2025, 1, 15, 10, 30, 45)
  ```
- **Act**: `result = json_serial(obj)`
- **Assert**: `assert result == "2025-01-15T10:30:45"`
- **期待値**: ISO フォーマット文字列
- **RISK**: RC-T001

##### TC-M035: json_serial - 正常系（date オブジェクト）
- **テスト関数名**: `test_json_serial_with_date`
- **Arrange**: 
  ```python
  obj = date(2025, 1, 15)
  ```
- **Act**: `result = json_serial(obj)`
- **Assert**: `assert result == "2025-01-15"`
- **期待値**: ISO フォーマット文字列
- **RISK**: RC-T001

##### TC-M036: json_serial - 正常系（その他のオブジェクト）
- **テスト関数名**: `test_json_serial_with_other_types`
- **Arrange**: `obj = 12345`
- **Act**: `result = json_serial(obj)`
- **Assert**: `assert result == "12345"`
- **期待値**: 文字列化
- **RISK**: RC-T001

##### TC-M037: to_json - 正常系（辞書を含む datetime）
- **テスト関数名**: `test_to_json_with_datetime_dict`
- **Arrange**: 
  ```python
  obj = {
      "timestamp": datetime(2025, 1, 15, 10, 30, 45),
      "name": "test",
      "value": 100,
  }
  ```
- **Act**: `result = to_json(obj)`
- **Assert**: 
  ```python
  assert isinstance(result, str)
  assert "2025-01-15T10:30:45" in result
  assert '"name": "test"' in result or '"name":"test"' in result
  ```
- **期待値**: JSON 文字列（日本語対応）
- **RISK**: RC-T001

##### TC-M038: to_json - 異常系（日本語を含む）
- **テスト関数名**: `test_to_json_with_japanese_text`
- **Arrange**: 
  ```python
  obj = {"name": "テスト"}
  ```
- **Act**: `result = to_json(obj)`
- **Assert**: 
  ```python
  assert isinstance(result, str)
  assert "テスト" in result  # ensure_ascii=False で日本語が保持される
  ```
- **期待値**: JSON 文字列（日本語保持）
- **RISK**: RC-T001

---

### 6. `_get_conditions_df()` 関数

#### 機能説明
InputConditions を DataFrame に変換。Snowflake 依存のため、`get_address_master_with_code()` をモック化。

#### テストケース

##### TC-M039: _get_conditions_df - 正常系（住所条件なし）
- **テスト関数名**: `test_get_conditions_df_without_address`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      keyword_search_method="company",
      keyword_search_word="test",
  )
  ```
- **Act**: `df = _get_conditions_df(conditions)`
- **Assert**: 
  ```python
  assert isinstance(df, pd.DataFrame)
  assert df.loc["集計開始日", 0] == "2025/01/01"
  assert df.loc["集計終了日", 0] == "2025/01/31"
  assert df.loc["都道府県", 0] == "指定なし"
  ```
- **期待値**: DataFrame に条件が正しく格納
- **RISK**: RC-E001

##### TC-M040: _get_conditions_df - 正常系（住所条件あり - モック）
- **テスト関数名**: `test_get_conditions_df_with_address_mocked`
- **Arrange**: 
  ```python
  # get_address_master_with_code をモック
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      prefecture_cd="13",
      city_cd=["13101"],
  )
  ```
- **モック**: 
  ```python
  @patch('app.lib.generate_analysis_result_data.get_address_master_with_code')
  def test_function(mock_get_address):
      # Mock DataFrame を返す
      mock_df = pd.DataFrame({
          'prefectures_name_kanji': ['東京都'],
          'shikuchoson_code': ['13101'],
          'shikugunchoson_name_kanji': ['千代田区'],
      })
      mock_get_address.return_value = mock_df
      # テスト実行
  ```
- **Assert**: 
  ```python
  assert "東京都" in df.loc["都道府県", 0]
  assert "千代田区" in df.loc["市区町村", 0]
  ```
- **期待値**: 住所が正しく格納
- **RISK**: RC-E001

##### TC-M041: _get_conditions_df - 異常系（空 DataFrame）
- **テスト関数名**: `test_get_conditions_df_with_empty_result`
- **Arrange**: 
  ```python
  conditions = InputConditions(
      start_date=date(2025, 1, 1),
      end_date=date(2025, 1, 31),
      keyword_search_word="存在しないワード",
  )
  ```
- **Act**: `df = _get_conditions_df(conditions)`
- **Assert**: 
  ```python
  assert isinstance(df, pd.DataFrame)
  assert len(df) > 0  # 検索条件は最低限格納
  ```
- **期待値**: DataFrame 構造は保持される
- **RISK**: RC-E001

---

## テスト実行計画

### Phase 1: 準備
1. `tests/test_layer2_models.py` を作成
2. `tests/test_layer2_const.py` を作成
3. `tests/test_layer2_utils.py` を作成
4. `tests/test_layer2_generate_analysis.py` を作成

### Phase 2: テスト実行
```bash
python -m pytest tests/test_layer2_*.py -v --cov=app/lib --cov-report=term-missing
```

### Phase 3: カバレッジ確認
- **目標**: 85% 以上のコード行カバレッジ
- **除外対象**: @st.cache_data/@st.cache_resource 付き関数（Layer3 テスト）

---

## マッピング: テストケース → リスク

| リスク ID | テストケース数 | テスト関数 |
|----------|--------------|--------|
| RC-D001 | 8 | TC-M001～TC-M019 |
| RC-D002 | 4 | TC-M020～TC-M024 |
| RC-D003 | 3 | TC-M025～TC-M027 |
| RC-B001 | 1 | TC-M007 |
| RC-E001 | 3 | TC-M031, TC-M039, TC-M041 |
| RC-T001 | 8 | TC-M028～TC-M038 |
| **合計** | **27** | - |

---

## 重要な注記

### 1. Dataclass Frozen の影響
`InputConditions` は `frozen=True` なので、インスタンス生成後の属性変更はできない。
テストでは、各テストケースで異なる条件のインスタンスを新規作成する必要がある。

### 2. 型ヒント vs 実装の相互作用
`models.py` では、`start_date: date` や `end_date: date` と型ヒントされているが、
`check` プロパティで `isinstance()` チェックを行っている。
異常系テスト（TC-M009 など）は、型チェックをバイパスする工夫（`typing.cast()` など）が必要な場合がある。

### 3. Snowflake 依存の処理
`_get_conditions_df()` は `get_address_master_with_code()` に依存するため、
このテストでは必ず `@patch` デコレータでモック化する。

### 4. キャッシング動作はレイヤー分離
- **Layer2**: 純粋関数の計算ロジックのみテスト
- **Layer3**: `@st.cache_data/@st.cache_resource` のキャッシング動作を検証

### 5. Pytest 実行コマンド例
```bash
# 全テスト実行
python -m pytest tests/test_layer2_*.py -v

# 特定のリスクをカバーするテスト実行
python -m pytest tests/test_layer2_models.py::test_check_returns_true_with_valid_address_condition -v

# カバレッジ付き実行
python -m pytest tests/test_layer2_*.py --cov=app/lib --cov-report=html
```

---

## テスト設計の実装規約

### ファイル構成
```
tests/
  test_layer2_models.py        # InputConditions, RenderOptions
  test_layer2_const.py         # 定数値検証
  test_layer2_utils.py         # json_serial, to_json など
  test_layer2_generate_analysis.py  # get_east_asian_width_count など
```

### テスト関数の命名規則
```
test_<function_name>_<condition>_<expected_result>

例:
test_check_returns_true_with_valid_address_condition
test_check_returns_false_when_no_search_condition
test_hash_md5_is_deterministic
```

### Docstring テンプレート
```python
def test_function_name():
    """テスト対象機能の説明
    
    テスト観点:
    - 正常系の動作確認
    - 異常系の例外処理確認
    - 境界値での動作確認
    """
```

### Assert パターン
```python
# 基本的な等値チェック
assert result == expected_value

# 型チェック
assert isinstance(result, expected_type)

# リストの内容チェック
assert expected_item in result

# 複数条件チェック
assert result == expected_value and len(result) == expected_length
```

---

## 実装時の参考情報

### モック化の例（Snowflake 依存関数）
```python
from unittest.mock import patch
import pandas as pd

@patch('app.lib.generate_analysis_result_data.get_address_master_with_code')
def test_get_conditions_df_with_address_mocked(mock_get_address):
    """住所条件を含む検索条件を DataFrame に変換する"""
    # Mock DataFrame を返す設定
    mock_df = pd.DataFrame({
        'prefectures_name_kanji': ['東京都'],
        'shikuchoson_code': ['13101'],
        'shikugunchoson_name_kanji': ['千代田区'],
        'address_code': ['ADDRESS001'],
    })
    mock_get_address.return_value = mock_df
    
    conditions = InputConditions(
        start_date=date(2025, 1, 1),
        end_date=date(2025, 1, 31),
        prefecture_cd="13",
        city_cd=["13101"],
    )
    
    df = _get_conditions_df(conditions)
    
    assert isinstance(df, pd.DataFrame)
    mock_get_address.assert_called_once_with(13)
```

### Pytest Parametrize の活用（複数条件テスト）
```python
@pytest.mark.parametrize("condition_dict,expected", [
    ({"prefecture_cd": "13", "city_cd": ["13101"]}, True),
    ({"prefecture_cd": "13", "city_cd": None}, False),
    ({"prefecture_cd": None, "city_cd": ["13101"]}, False),
])
def test_check_with_various_conditions(condition_dict, expected):
    """複数の住所条件パターンをテストする"""
    conditions = InputConditions(
        start_date=date(2025, 1, 1),
        end_date=date(2025, 1, 31),
        **condition_dict
    )
    assert conditions.check == expected
```

---

## テスト設計書の変更履歴

| 版 | 日時 | 変更内容 |
|----|------|--------|
| 1.0 | 2026-04-28 | 初版作成 - Layer2テスト対象25個の関数・定数を設計 |

---

## 付録: テスト対象の判定基準

### Layer2 テスト対象の条件
- ✅ 純粋関数（外部依存なし または モック可能）
- ✅ 単純なロジック（複数行の計算/判定）
- ✅ 入出力が明確
- ❌ @st.cache_data/@st.cache_resource → Layer3
- ❌ Streamlit UI 関数（st.* 呼び出し） → Layer1 AppTest
- ❌ キャッシングの TTL 検証 → Layer3

### モック必須の関数
- `get_address_master_with_code()` - Snowflake クエリ
- `PochiStorage.upload_from_string()` - GCS アップロード
- `PochiUserInfo().name` - Pochi ユーザー情報
