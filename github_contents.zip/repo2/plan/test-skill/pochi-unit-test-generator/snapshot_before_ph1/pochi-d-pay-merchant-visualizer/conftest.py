"""テストの共通設定・フィクスチャを定義するconftest.py。

このモジュールでは、テスト全体で使用する以下の共通設定を行います：
- sys.path設定：app/ディレクトリをsys.pathに追加し、from lib.xxx import yyy形式でインポート可能にする
- Streamlitのモック化：@st.cache_data/@st.cache_resourceをバイパスし、テスト実行時にst.*呼び出しを避ける
- 外部依存ライブラリのモック化：pochilib, streamflake, snowflakeをモック化
- フィクスチャの提供：InputConditions, RenderOptions, DataFrameなど、テストで頻繁に使用されるオブジェクト
"""

import json
import sys
from datetime import date
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

# =============================================================================
# sys.path設定：app/ディレクトリを追加
# =============================================================================

APP_DIR = Path(__file__).parent.parent / "app"
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))


# =============================================================================
# Streamlitのモック化処理
# =============================================================================

def _passthrough_decorator(func: Any = None, **kwargs: Any) -> Any:
    """@st.cache_data / @st.cache_resource をバイパスするデコレータ。

    cache_dataおよびcache_resourceデコレータをテスト時にバイパスすることで、
    キャッシュ機構に依存しないテスト実行を実現します。

    Args:
        func: デコレータ対象の関数（Noneの場合はデコレータファクトリ）
        **kwargs: デコレータのキーワード引数

    Returns:
        元の関数またはデコレータ関数
    """
    if func is not None:
        return func

    def decorator(f: Any) -> Any:
        return f

    return decorator


# Streamlitモック：テスト実行時にst.*呼び出しが実行されないようにする
_MOCK_STREAMLIT = MagicMock()
_MOCK_STREAMLIT.cache_data = _passthrough_decorator
_MOCK_STREAMLIT.cache_resource = _passthrough_decorator
_MOCK_STREAMLIT.session_state = {}


def _dialog_decorator(title: str = "", **kwargs: Any) -> Any:
    """@st.dialog をバイパスするデコレータ。

    Args:
        title: ダイアログタイトル
        **kwargs: その他のキーワード引数

    Returns:
        デコレータ関数
    """

    def decorator(func: Any) -> Any:
        return func

    return decorator


_MOCK_STREAMLIT.dialog = _dialog_decorator
_MOCK_STREAMLIT.fragment = _passthrough_decorator

# モック化するモジュール定義（always_mockリストおよびstreamlitデコレータ関連モジュール）
_MOCK_MODULES = {
    "streamlit": _MOCK_STREAMLIT,
    "streamlit.testing": MagicMock(),
    "streamlit.testing.v1": MagicMock(),
    "streamlit.runtime": MagicMock(),
    "streamlit.runtime.scriptrunner": MagicMock(),
    "streamlit.runtime.state": MagicMock(),
    "streamlit.runtime.state.session_state": MagicMock(),
    "streamlit.components": MagicMock(),
    "streamlit.components.v1": MagicMock(),
    "streamlit_antd_components": MagicMock(),
    "streamlit_folium": MagicMock(),
    "reporting_function": MagicMock(),
    "reporting_function._reporting_page": MagicMock(),
    "pochilib": MagicMock(),
    "pochilib.snowflake": MagicMock(),
    "pochilib.snowflake.sqlalchemy": MagicMock(),
    "pochilib.llm": MagicMock(),
    "pochilib.storage": MagicMock(),
    "snowflake": MagicMock(),
    "snowflake.connector": MagicMock(),
    "snowflake.connector.pandas_tools": MagicMock(),
    "snowflake.sqlalchemy": MagicMock(),
}

# アプリモジュールをプリロードする前にモックを適用
for module_name, mock_obj in _MOCK_MODULES.items():
    sys.modules[module_name] = mock_obj


# =============================================================================
# フィクスチャディレクトリ設定
# =============================================================================

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def load_fixture(path: str) -> dict:
    """フィクスチャファイルをJSONから読み込む。

    Args:
        path: fixtures/からの相対パス（例: "valid/input_conditions_basic.json"）

    Returns:
        dict: フィクスチャデータ

    Raises:
        FileNotFoundError: フィクスチャファイルが見つからない場合
    """
    fixture_path = FIXTURES_DIR / path
    if not fixture_path.exists():
        raise FileNotFoundError(f"Fixture not found: {fixture_path}")
    with open(fixture_path, encoding="utf-8") as f:
        return json.load(f)


# =============================================================================
# フィクスチャ：InputConditionsモデル
# =============================================================================

@pytest.fixture
def input_conditions_basic() -> Any:
    """最小限の必須フィールドを持つ基本的なInputConditionsインスタンス。

    Returns:
        InputConditions: 基本的な入力条件
    """
    from lib.models import InputConditions

    data = load_fixture("valid/input_conditions_basic.json")["data"]
    # 日付文字列をdateオブジェクトに変換
    data["start_date"] = date.fromisoformat(data["start_date"])
    data["end_date"] = date.fromisoformat(data["end_date"])
    if data.get("comparison_start_date"):
        data["comparison_start_date"] = date.fromisoformat(data["comparison_start_date"])
    if data.get("comparison_end_date"):
        data["comparison_end_date"] = date.fromisoformat(data["comparison_end_date"])
    return InputConditions(**data)


@pytest.fixture
def input_conditions_with_comparison() -> Any:
    """比較機能を有効にしたInputConditionsインスタンス。

    Returns:
        InputConditions: 比較機能付き入力条件
    """
    from lib.models import InputConditions

    data = load_fixture("valid/input_conditions_comparison.json")["data"]
    # 日付文字列をdateオブジェクトに変換
    data["start_date"] = date.fromisoformat(data["start_date"])
    data["end_date"] = date.fromisoformat(data["end_date"])
    if data.get("comparison_start_date"):
        data["comparison_start_date"] = date.fromisoformat(data["comparison_start_date"])
    if data.get("comparison_end_date"):
        data["comparison_end_date"] = date.fromisoformat(data["comparison_end_date"])
    return InputConditions(**data)


@pytest.fixture
def input_conditions_full() -> Any:
    """全フィールドを持つ完全なInputConditionsインスタンス。

    Returns:
        InputConditions: 完全な入力条件
    """
    from lib.models import InputConditions

    data = load_fixture("valid/input_conditions_full.json")["data"]
    # 日付文字列をdateオブジェクトに変換
    data["start_date"] = date.fromisoformat(data["start_date"])
    data["end_date"] = date.fromisoformat(data["end_date"])
    if data.get("comparison_start_date"):
        data["comparison_start_date"] = date.fromisoformat(data["comparison_start_date"])
    if data.get("comparison_end_date"):
        data["comparison_end_date"] = date.fromisoformat(data["comparison_end_date"])
    return InputConditions(**data)


@pytest.fixture
def input_conditions_map_search() -> Any:
    """マップ検索機能を使用したInputConditionsインスタンス。

    Returns:
        InputConditions: マップ検索付き入力条件
    """
    from lib.models import InputConditions

    data = load_fixture("valid/input_conditions_map_search.json")["data"]
    # 日付文字列をdateオブジェクトに変換
    data["start_date"] = date.fromisoformat(data["start_date"])
    data["end_date"] = date.fromisoformat(data["end_date"])
    if data.get("comparison_start_date"):
        data["comparison_start_date"] = date.fromisoformat(data["comparison_start_date"])
    if data.get("comparison_end_date"):
        data["comparison_end_date"] = date.fromisoformat(data["comparison_end_date"])
    return InputConditions(**data)


@pytest.fixture
def input_conditions_store_search() -> Any:
    """店舗検索機能を使用したInputConditionsインスタンス。

    Returns:
        InputConditions: 店舗検索付き入力条件
    """
    from lib.models import InputConditions

    data = load_fixture("valid/input_conditions_store_search.json")["data"]
    # 日付文字列をdateオブジェクトに変換
    data["start_date"] = date.fromisoformat(data["start_date"])
    data["end_date"] = date.fromisoformat(data["end_date"])
    if data.get("comparison_start_date"):
        data["comparison_start_date"] = date.fromisoformat(data["comparison_start_date"])
    if data.get("comparison_end_date"):
        data["comparison_end_date"] = date.fromisoformat(data["comparison_end_date"])
    return InputConditions(**data)


# =============================================================================
# フィクスチャ：RenderOptionsモデル
# =============================================================================

@pytest.fixture
def render_options_basic() -> Any:
    """デフォルト値のRenderOptionsインスタンス。

    Returns:
        RenderOptions: 基本的な描画オプション
    """
    from lib.models import RenderOptions

    data = load_fixture("valid/render_options_basic.json")["data"]
    return RenderOptions(**data)


@pytest.fixture
def render_options_all_enabled() -> Any:
    """全機能を有効にしたRenderOptionsインスタンス。

    Returns:
        RenderOptions: 全機能有効な描画オプション
    """
    from lib.models import RenderOptions

    data = load_fixture("valid/render_options_all_enabled.json")["data"]
    return RenderOptions(**data)


# =============================================================================
# フィクスチャ：サンプルデータ（pandas DataFrame）
# =============================================================================

@pytest.fixture
def merchant_data_df() -> Any:
    """加盟店データのpandas DataFrameフィクスチャ。

    Returns:
        pd.DataFrame: 加盟店データ
    """
    import pandas as pd

    data = load_fixture("valid/merchant_data_sample.json")
    return pd.DataFrame(data["data"])


@pytest.fixture
def merchant_data_empty_df() -> Any:
    """空の加盟店データDataFrame。

    Returns:
        pd.DataFrame: 空のDataFrame
    """
    import pandas as pd

    data = load_fixture("edge/merchant_data_empty.json")
    return pd.DataFrame(columns=data.get("columns", []))


@pytest.fixture
def merchant_data_large_df() -> Any:
    """大規模な加盟店データDataFrame。

    Returns:
        pd.DataFrame: 大規模加盟店データ
    """
    import pandas as pd

    data = load_fixture("edge/merchant_data_large.json")
    return pd.DataFrame(data["data"])


@pytest.fixture
def settlement_stats_sample() -> Any:
    """決済統計のサンプルデータ。

    Returns:
        dict: 決済統計データ
    """
    data = load_fixture("valid/settlement_stats_sample.json")
    return data["data"]


# =============================================================================
# フィクスチャ：エッジケースとエラー条件用
# =============================================================================

@pytest.fixture
def input_conditions_max_cities() -> Any:
    """最大数の市区町村を選択したInputConditionsインスタンス。

    Returns:
        InputConditions: 最大市区町村数の入力条件
    """
    from lib.models import InputConditions

    data = load_fixture("edge/input_conditions_max_cities.json")["data"]
    # 日付文字列をdateオブジェクトに変換
    data["start_date"] = date.fromisoformat(data["start_date"])
    data["end_date"] = date.fromisoformat(data["end_date"])
    if data.get("comparison_start_date"):
        data["comparison_start_date"] = date.fromisoformat(data["comparison_start_date"])
    if data.get("comparison_end_date"):
        data["comparison_end_date"] = date.fromisoformat(data["comparison_end_date"])
    return InputConditions(**data)


@pytest.fixture
def input_conditions_long_period() -> Any:
    """長期間を指定したInputConditionsインスタンス。

    Returns:
        InputConditions: 長期間の入力条件
    """
    from lib.models import InputConditions

    data = load_fixture("edge/input_conditions_long_period.json")["data"]
    # 日付文字列をdateオブジェクトに変換
    data["start_date"] = date.fromisoformat(data["start_date"])
    data["end_date"] = date.fromisoformat(data["end_date"])
    if data.get("comparison_start_date"):
        data["comparison_start_date"] = date.fromisoformat(data["comparison_start_date"])
    if data.get("comparison_end_date"):
        data["comparison_end_date"] = date.fromisoformat(data["comparison_end_date"])
    return InputConditions(**data)


@pytest.fixture
def input_conditions_special_chars() -> Any:
    """特殊文字を含むInputConditionsインスタンス。

    Returns:
        InputConditions: 特殊文字を含む入力条件
    """
    from lib.models import InputConditions

    data = load_fixture("edge/input_conditions_special_chars.json")["data"]
    # 日付文字列をdateオブジェクトに変換
    data["start_date"] = date.fromisoformat(data["start_date"])
    data["end_date"] = date.fromisoformat(data["end_date"])
    if data.get("comparison_start_date"):
        data["comparison_start_date"] = date.fromisoformat(data["comparison_start_date"])
    if data.get("comparison_end_date"):
        data["comparison_end_date"] = date.fromisoformat(data["comparison_end_date"])
    return InputConditions(**data)


@pytest.fixture
def input_conditions_same_dates() -> Any:
    """開始日と終了日が同じInputConditionsインスタンス。

    Returns:
        InputConditions: 同一日付の入力条件
    """
    from lib.models import InputConditions

    data = load_fixture("edge/input_conditions_same_dates.json")["data"]
    # 日付文字列をdateオブジェクトに変換
    data["start_date"] = date.fromisoformat(data["start_date"])
    data["end_date"] = date.fromisoformat(data["end_date"])
    if data.get("comparison_start_date"):
        data["comparison_start_date"] = date.fromisoformat(data["comparison_start_date"])
    if data.get("comparison_end_date"):
        data["comparison_end_date"] = date.fromisoformat(data["comparison_end_date"])
    return InputConditions(**data)


@pytest.fixture
def input_conditions_all_keyword_methods() -> Any:
    """すべてのキーワード検索方法を含むInputConditionsインスタンス。

    Returns:
        InputConditions: 全キーワード検索方法の入力条件
    """
    from lib.models import InputConditions

    data = load_fixture("edge/input_conditions_all_keyword_methods.json")["data"]
    # 日付文字列をdateオブジェクトに変換
    data["start_date"] = date.fromisoformat(data["start_date"])
    data["end_date"] = date.fromisoformat(data["end_date"])
    if data.get("comparison_start_date"):
        data["comparison_start_date"] = date.fromisoformat(data["comparison_start_date"])
    if data.get("comparison_end_date"):
        data["comparison_end_date"] = date.fromisoformat(data["comparison_end_date"])
    return InputConditions(**data)


# =============================================================================
# フィクスチャ：無効なデータ用（例外テスト用）
# =============================================================================

@pytest.fixture
def invalid_input_conditions_no_search_condition() -> dict:
    """検索条件がないInputConditionsデータ（例外テスト用）。

    Returns:
        dict: 無効な入力条件
    """
    return load_fixture("invalid/input_conditions_no_search_condition.json")["data"]


@pytest.fixture
def invalid_input_conditions_invalid_date_range() -> dict:
    """無効な日付範囲を持つInputConditionsデータ（例外テスト用）。

    Returns:
        dict: 無効な日付範囲
    """
    return load_fixture("invalid/input_conditions_invalid_date_range.json")["data"]


@pytest.fixture
def invalid_input_conditions_missing_required() -> dict:
    """必須フィールドが欠けたInputConditionsデータ（例外テスト用）。

    Returns:
        dict: 必須フィールド欠落データ
    """
    return load_fixture("invalid/input_conditions_missing_required.json")["data"]
