"""conftest.pyのフィクスチャが正しく動作するかを確認するテスト。"""

import pytest
from datetime import date


def test_input_conditions_basic_fixture(input_conditions_basic):
    """input_conditions_basicフィクスチャが正常に機能することを確認。

    テスト観点:
    - フィクスチャが正しく初期化されること
    - 必須フィールドがすべて設定されていること
    """
    assert input_conditions_basic.start_date == date(2024, 1, 1)
    assert input_conditions_basic.end_date == date(2024, 1, 31)
    assert input_conditions_basic.prefecture_cd == "40"


def test_input_conditions_with_comparison_fixture(input_conditions_with_comparison):
    """input_conditions_with_comparisonフィクスチャが正常に機能することを確認。

    テスト観点:
    - 比較機能が有効なフィクスチャが作成されること
    - 比較期間が設定されていること
    """
    assert input_conditions_with_comparison.enable_comparison is True
    assert input_conditions_with_comparison.comparison_start_date is not None
    assert input_conditions_with_comparison.comparison_end_date is not None


def test_render_options_basic_fixture(render_options_basic):
    """render_options_basicフィクスチャが正常に機能することを確認。

    テスト観点:
    - RenderOptionsフィクスチャが正しく初期化されること
    """
    assert hasattr(render_options_basic, 'enable_merchant_map')
    assert hasattr(render_options_basic, 'enable_graphs')


def test_merchant_data_df_fixture(merchant_data_df):
    """merchant_data_dfフィクスチャが正常に機能することを確認。

    テスト観点:
    - DataFrameが正しく読み込まれること
    - 予期されたカラムが存在すること
    """
    assert merchant_data_df is not None
    assert len(merchant_data_df) > 0


def test_merchant_data_empty_df_fixture(merchant_data_empty_df):
    """merchant_data_empty_dfフィクスチャが正常に機能することを確認。

    テスト観点:
    - 空のDataFrameが正しく作成されること
    - カラムが設定されていること
    """
    assert len(merchant_data_empty_df) == 0


@pytest.mark.parametrize("fixture_name,expected_type", [
    ("input_conditions_map_search", object),
    ("input_conditions_store_search", object),
])
def test_parameterized_input_conditions_fixtures(request, fixture_name, expected_type):
    """複数のInputConditionsフィクスチャが正常に機能することを確認。

    テスト観点:
    - 各フィクスチャが正しいタイプを返すこと
    """
    fixture = request.getfixturevalue(fixture_name)
    assert isinstance(fixture, expected_type)
