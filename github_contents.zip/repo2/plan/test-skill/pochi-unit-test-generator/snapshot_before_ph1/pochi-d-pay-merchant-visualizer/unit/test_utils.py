"""ユーティリティ関数の単体テスト。

このモジュールでは、utils.py で定義される純粋関数
（json_serial, to_json）をテストします。
"""

import json
from datetime import date, datetime

import pytest

from lib.utils import json_serial, to_json


class TestJsonSerial:
    """json_serial 関数のテスト。"""

    def test_json_serial_with_datetime(self):
        """datetime オブジェクトが ISO フォーマット文字列に変換される。

        テスト観点:
        - 正常系: datetime オブジェクトの JSON シリアライズ
        """
        # RISK: RC-T001
        obj = datetime(2025, 1, 15, 10, 30, 45)
        result = json_serial(obj)
        assert result == "2025-01-15T10:30:45"

    def test_json_serial_with_date(self):
        """date オブジェクトが ISO フォーマット文字列に変換される。

        テスト観点:
        - 正常系: date オブジェクトの JSON シリアライズ
        """
        # RISK: RC-T001
        obj = date(2025, 1, 15)
        result = json_serial(obj)
        assert result == "2025-01-15"

    def test_json_serial_with_integer(self):
        """整数が文字列に変換される。

        テスト観点:
        - 正常系: その他のオブジェクト型の変換
        """
        # RISK: RC-T001
        obj = 12345
        result = json_serial(obj)
        assert result == "12345"

    def test_json_serial_with_float(self):
        """浮動小数点数が文字列に変換される。

        テスト観点:
        - 正常系: float 型の変換
        """
        # RISK: RC-T001
        obj = 123.45
        result = json_serial(obj)
        assert result == "123.45"

    def test_json_serial_with_string(self):
        """文字列は文字列として変換される。

        テスト観点:
        - 正常系: str 型の変換（str() で文字列化）
        """
        # RISK: RC-T001
        obj = "test_string"
        result = json_serial(obj)
        assert result == "test_string"

    def test_json_serial_with_none(self):
        """None が文字列 'None' に変換される。

        テスト観点:
        - 異常系: None 値の処理
        """
        # RISK: RC-T001
        obj = None
        result = json_serial(obj)
        assert result == "None"

    def test_json_serial_with_datetime_microseconds(self):
        """マイクロ秒を含む datetime が正しく変換される。

        テスト観点:
        - 正常系: マイクロ秒を含む datetime のシリアライズ
        """
        # RISK: RC-T001
        obj = datetime(2025, 1, 15, 10, 30, 45, 123456)
        result = json_serial(obj)
        assert "2025-01-15T10:30:45" in result
        assert "123456" in result

    def test_json_serial_with_custom_object(self):
        """カスタムオブジェクトが文字列に変換される。

        テスト観点:
        - 異常系: 標準型以外のオブジェクト
        """
        # RISK: RC-T001
        class CustomClass:
            def __str__(self):
                return "custom_object"

        obj = CustomClass()
        result = json_serial(obj)
        assert result == "custom_object"


class TestToJson:
    """to_json 関数のテスト。"""

    def test_to_json_with_datetime_dict(self):
        """辞書に含まれる datetime が JSON 文字列として正しくシリアライズされる。

        テスト観点:
        - 正常系: datetime を含む辞書の JSON 変換
        """
        # RISK: RC-T001
        obj = {
            "timestamp": datetime(2025, 1, 15, 10, 30, 45),
            "name": "test",
            "value": 100,
        }
        result = to_json(obj)
        assert isinstance(result, str)
        assert "2025-01-15T10:30:45" in result
        assert '"name"' in result or "'name'" in result
        assert '"test"' in result or "'test'" in result

    def test_to_json_with_japanese_text(self):
        """日本語テキストが JSON 文字列として保持される。

        テスト観点:
        - 正常系: ensure_ascii=False で日本語が保持される
        """
        # RISK: RC-T001
        obj = {"name": "テスト"}
        result = to_json(obj)
        assert isinstance(result, str)
        assert "テスト" in result

    def test_to_json_with_date(self):
        """date オブジェクトが JSON 文字列として正しく変換される。

        テスト観点:
        - 正常系: date を含む辞書の JSON 変換
        """
        # RISK: RC-T001
        obj = {"date": date(2025, 1, 15)}
        result = to_json(obj)
        assert isinstance(result, str)
        assert "2025-01-15" in result

    def test_to_json_with_nested_dict(self):
        """ネストされた辞書が正しく JSON 文字列に変換される。

        テスト観点:
        - 正常系: ネストされたオブジェクトの JSON 変換
        """
        # RISK: RC-T001
        obj = {
            "outer": {
                "inner": "value",
                "timestamp": datetime(2025, 1, 15, 10, 30, 45),
            }
        }
        result = to_json(obj)
        assert isinstance(result, str)
        assert "outer" in result
        assert "inner" in result
        assert "2025-01-15T10:30:45" in result

    def test_to_json_with_list(self):
        """リストを含む辞書が正しく JSON 文字列に変換される。

        テスト観点:
        - 正常系: リストを含むオブジェクトの JSON 変換
        """
        # RISK: RC-T001
        obj = {
            "items": [1, 2, 3],
            "names": ["a", "b", "c"],
        }
        result = to_json(obj)
        assert isinstance(result, str)
        assert "items" in result
        assert "1" in result
        assert "a" in result

    def test_to_json_with_mixed_types(self):
        """複数の型を含む辞書が正しく JSON 文字列に変換される。

        テスト観点:
        - 正常系: 複合型のオブジェクトの JSON 変換
        """
        # RISK: RC-T001
        obj = {
            "string": "test",
            "integer": 42,
            "float": 3.14,
            "boolean": True,
            "null": None,
            "date": date(2025, 1, 15),
            "datetime": datetime(2025, 1, 15, 10, 30, 45),
            "list": [1, "two", 3.0],
        }
        result = to_json(obj)
        assert isinstance(result, str)
        # JSON としてパース可能であることを確認
        parsed = json.loads(result)
        assert parsed["string"] == "test"
        assert parsed["integer"] == 42
        assert parsed["float"] == 3.14
        assert parsed["boolean"] is True
        assert parsed["null"] is None

    def test_to_json_with_empty_dict(self):
        """空の辞書が正しく JSON 文字列に変換される。

        テスト観点:
        - 境界値: 空のオブジェクト
        """
        # RISK: RC-T001
        obj = {}
        result = to_json(obj)
        assert isinstance(result, str)
        assert result == "{}"

    def test_to_json_with_empty_list(self):
        """空のリストを含む辞書が正しく JSON 文字列に変換される。

        テスト観点:
        - 境界値: 空のリスト
        """
        # RISK: RC-T001
        obj = {"empty_list": []}
        result = to_json(obj)
        assert isinstance(result, str)
        assert "empty_list" in result
        assert "[]" in result

    def test_to_json_is_valid_json(self):
        """to_json の結果は有効な JSON 文字列である。

        テスト観点:
        - 正常系: 結果が JSON として解析可能
        """
        # RISK: RC-T001
        obj = {
            "name": "テスト",
            "date": date(2025, 1, 15),
            "value": 100,
        }
        result = to_json(obj)
        # JSON として解析可能であることを確認
        parsed = json.loads(result)
        assert isinstance(parsed, dict)
        assert parsed["name"] == "テスト"
        assert parsed["value"] == 100
