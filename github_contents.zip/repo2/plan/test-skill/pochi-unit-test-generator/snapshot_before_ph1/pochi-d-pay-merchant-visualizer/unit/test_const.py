"""定数値の単体テスト。

このモジュールでは、const.py で定義される定数値の整合性を
テストします。
"""

import pytest

from lib.const import (
    APP_NAME,
    DOWNLOAD_EXCEL_FILE_MERCHANT_LIMIT,
    GENDER_CODE_MAP,
    KEYWORD_SEARCH_LIMIT,
    MAP_DEFAULT_MAX_ROWS,
    MAP_MOREOVER_MAX_ROWS,
    MAX_SELECTED_CITY_COUNT,
    MAX_STORE_SEARCH_COUNT,
    MAX_USER_LIST_SIZE,
    NENDAI_CODE_MAP,
)


class TestConstantValues:
    """定数値の整合性テスト。"""

    def test_app_name_is_correct(self):
        """APP_NAME が正しい値である。

        テスト観点:
        - 正常系: PochiStorage で使用するアプリ名の確認
        """
        # RISK: RC-D003
        assert APP_NAME == "d-pay-merchant-visualizer"

    def test_max_selected_city_count_is_15(self):
        """MAX_SELECTED_CITY_COUNT が 15 である。

        テスト観点:
        - 正常系: 住所選択画面での市区町村数上限値の確認
        """
        # RISK: RC-D003
        assert MAX_SELECTED_CITY_COUNT == 15

    def test_max_store_search_count_is_15(self):
        """MAX_STORE_SEARCH_COUNT が 15 である。

        テスト観点:
        - 正常系: 店舗検索時の最大表示件数の確認
        """
        # RISK: RC-D003
        assert MAX_STORE_SEARCH_COUNT == 15

    def test_map_default_max_rows_is_5000(self):
        """MAP_DEFAULT_MAX_ROWS が 5000 である。

        テスト観点:
        - 正常系: マップ表示の最大件数（デフォルト）の確認
        """
        # RISK: RC-D003
        assert MAP_DEFAULT_MAX_ROWS == 5000

    def test_map_moreover_max_rows_is_50000(self):
        """MAP_MOREOVER_MAX_ROWS が 50000 である。

        テスト観点:
        - 正常系: マップ表示の最大件数（上限突破時）の確認
        """
        # RISK: RC-D003
        assert MAP_MOREOVER_MAX_ROWS == 50000

    def test_download_excel_file_merchant_limit_is_50000(self):
        """DOWNLOAD_EXCEL_FILE_MERCHANT_LIMIT が 50000 である。

        テスト観点:
        - 正常系: ダウンロード時に CSV のみに切り替える件数の確認
        """
        # RISK: RC-D003
        assert DOWNLOAD_EXCEL_FILE_MERCHANT_LIMIT == 50000

    def test_keyword_search_limit_is_50000(self):
        """KEYWORD_SEARCH_LIMIT が 50000 である。

        テスト観点:
        - 正常系: キーワード検索時の最大検索可能件数の確認
        """
        # RISK: RC-D003
        assert KEYWORD_SEARCH_LIMIT == 50000

    def test_max_user_list_size_is_1000000(self):
        """MAX_USER_LIST_SIZE が 1000000 である。

        テスト観点:
        - 正常系: ユーザーリストの最大件数の確認
        """
        # RISK: RC-D003
        assert MAX_USER_LIST_SIZE == 1000000

    def test_gender_code_map_keys_are_valid(self):
        """GENDER_CODE_MAP に期待するキーがすべて存在する。

        テスト観点:
        - 正常系: 性別コードマップのキーと値の整合性確認
        """
        # RISK: RC-D003
        expected_keys = {None, "1", "2"}
        assert set(GENDER_CODE_MAP.keys()) == expected_keys
        assert len(GENDER_CODE_MAP) == 3

    def test_gender_code_map_values_are_correct(self):
        """GENDER_CODE_MAP の値が正確である。

        テスト観点:
        - 正常系: 性別コードマップの値の確認
        """
        # RISK: RC-D003
        assert GENDER_CODE_MAP[None] == "選択しない"
        assert GENDER_CODE_MAP["1"] == "男性"
        assert GENDER_CODE_MAP["2"] == "女性"

    def test_nendai_code_map_keys_are_valid(self):
        """NENDAI_CODE_MAP に期待するキーがすべて存在する。

        テスト観点:
        - 正常系: 年代コードマップのキー数の確認
        """
        # RISK: RC-D003
        expected_keys = {"00", "01", "02", "03", "04", "05", "06", "07", "08"}
        assert set(NENDAI_CODE_MAP.keys()) == expected_keys
        assert len(NENDAI_CODE_MAP) == 9

    def test_nendai_code_map_values_are_correct(self):
        """NENDAI_CODE_MAP の値が正確である。

        テスト観点:
        - 正常系: 年代コードマップの値の確認
        """
        # RISK: RC-D003
        assert NENDAI_CODE_MAP["00"] == "10代未満"
        assert NENDAI_CODE_MAP["01"] == "10代"
        assert NENDAI_CODE_MAP["02"] == "20代"
        assert NENDAI_CODE_MAP["03"] == "30代"
        assert NENDAI_CODE_MAP["04"] == "40代"
        assert NENDAI_CODE_MAP["05"] == "50代"
        assert NENDAI_CODE_MAP["06"] == "60代"
        assert NENDAI_CODE_MAP["07"] == "70代"
        assert NENDAI_CODE_MAP["08"] == "80代以上"

    def test_nendai_code_map_completeness(self):
        """NENDAI_CODE_MAP が完全である。

        テスト観点:
        - 境界値: 全年代コードが定義されていることを確認
        """
        # RISK: RC-D003
        # 00～08 までが揃っていることを確認
        for i in range(9):
            code = str(i).zfill(2)
            assert code in NENDAI_CODE_MAP, f"年代コード '{code}' が存在すること"

    def test_constant_numeric_ordering(self):
        """数値定数の大小関係が妥当である。

        テスト観点:
        - 境界値: 数値定数の大小関係が論理的であることを確認
        """
        # RISK: RC-D003
        # デフォルトの最大表示件数 < 上限突破時の最大表示件数
        assert MAP_DEFAULT_MAX_ROWS < MAP_MOREOVER_MAX_ROWS
        # 店舗検索と市区町村選択の上限は同じ
        assert MAX_STORE_SEARCH_COUNT == MAX_SELECTED_CITY_COUNT
        # キーワード検索制限とダウンロード制限は同じ
        assert KEYWORD_SEARCH_LIMIT == DOWNLOAD_EXCEL_FILE_MERCHANT_LIMIT
        # ユーザーリスト最大件数は非常に大きい
        assert MAX_USER_LIST_SIZE > MAP_MOREOVER_MAX_ROWS
