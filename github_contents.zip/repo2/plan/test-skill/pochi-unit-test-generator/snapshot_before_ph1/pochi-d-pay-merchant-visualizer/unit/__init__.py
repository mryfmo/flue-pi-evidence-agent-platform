"""Layer2（ロジック単体テスト）のテストモジュール。

このモジュールは、models.py, const.py, utils.py, generate_analysis_result_data.py
の純粋関数とロジックをテストします。
"""
