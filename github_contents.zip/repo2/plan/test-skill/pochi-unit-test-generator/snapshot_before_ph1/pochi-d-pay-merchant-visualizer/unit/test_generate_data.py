"""ダウンロード関連純粋関数の単体テスト。

このモジュールでは、generate_analysis_result_data.py で定義される
純粋関数（get_east_asian_width_count など）をテストします。
"""

import sys
from datetime import date
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

# モック化が必要なモジュールを先に設定
sys.modules["reporting_function.sa_models"] = MagicMock()
sys.modules[
    "reporting_function.sa_models.vw_pochi_dbarai_city_store_master"
] = MagicMock()

from lib.generate_analysis_result_data import get_east_asian_width_count, _get_conditions_df
from lib.models import InputConditions


class TestGetEastAsianWidthCount:
    """get_east_asian_width_count 関数のテスト。"""

    def test_get_east_asian_width_count_with_full_width_chars(self):
        """全角文字のみの場合、幅が正しく計算される。

        テスト観点:
        - 正常系: 全角文字1文字の幅カウント（各文字は幅2）
        """
        # RISK: RC-T001
        text = "テスト"
        result = get_east_asian_width_count(text)
        assert result == 6  # 3 文字 × 2 = 6

    def test_get_east_asian_width_count_with_half_width_chars(self):
        """半角文字のみの場合、幅が正しく計算される。

        テスト観点:
        - 正常系: 半角文字のカウント（各文字は幅1）
        """
        # RISK: RC-T001
        text = "test"
        result = get_east_asian_width_count(text)
        assert result == 4  # 4 文字 × 1 = 4

    def test_get_east_asian_width_count_with_mixed_chars(self):
        """全角と半角が混在する場合、幅が正しく計算される。

        テスト観点:
        - 正常系: 混合文字のカウント
        """
        # RISK: RC-T001
        text = "テストabc123"
        result = get_east_asian_width_count(text)
        assert result == 12  # テスト(3×2) + abc(3×1) + 123(3×1) = 6 + 3 + 3 = 12

    def test_get_east_asian_width_count_with_empty_string(self):
        """空文字列の場合、幅が 0 である。

        テスト観点:
        - 異常系: 空文字列のカウント
        """
        # RISK: RC-E001
        text = ""
        result = get_east_asian_width_count(text)
        assert result == 0

    def test_get_east_asian_width_count_with_special_chars(self):
        """特殊文字の場合、幅が正しく計算される。

        テスト観点:
        - 異常系: 特殊文字のカウント（半角扱い）
        """
        # RISK: RC-T001
        text = "!@#$%"
        result = get_east_asian_width_count(text)
        assert result == 5  # 各特殊文字は半角扱い

    def test_get_east_asian_width_count_with_newline(self):
        """改行を含む場合、幅が正しく計算される。

        テスト観点:
        - 境界値: 改行文字を含むカウント
        """
        # RISK: RC-T001
        text = "テスト\nabc"
        result = get_east_asian_width_count(text)
        assert result == 10  # テスト(6) + \n(1) + abc(3) = 10

    def test_get_east_asian_width_count_with_numbers(self):
        """数字のみの場合、幅が正しく計算される。

        テスト観点:
        - 正常系: 数字（半角）のカウント
        """
        # RISK: RC-T001
        text = "12345"
        result = get_east_asian_width_count(text)
        assert result == 5

    def test_get_east_asian_width_count_with_japanese_numbers(self):
        """全角数字の場合、幅が正しく計算される。

        テスト観点:
        - 正常系: 全角数字のカウント
        """
        # RISK: RC-T001
        text = "１２３"
        result = get_east_asian_width_count(text)
        assert result == 6  # 3 文字 × 2 = 6

    def test_get_east_asian_width_count_with_single_char(self):
        """単一文字の場合、幅が正しく計算される。

        テスト観点:
        - 境界値: 1 文字の処理
        """
        # RISK: RC-T001
        text = "あ"
        result = get_east_asian_width_count(text)
        assert result == 2  # 全角1文字 = 幅2

    def test_get_east_asian_width_count_with_single_ascii_char(self):
        """単一の ASCII 文字の場合、幅が正しく計算される。

        テスト観点:
        - 境界値: 1 ASCII 文字の処理
        """
        # RISK: RC-T001
        text = "a"
        result = get_east_asian_width_count(text)
        assert result == 1


class TestGetConditionsDf:
    """_get_conditions_df 関数のテスト。"""

    def test_get_conditions_df_without_address(self):
        """住所条件なしの場合、DataFrame が正しく構築される。

        テスト観点:
        - 正常系: キーワード検索条件のみのデータフレーム
        """
        # RISK: RC-E001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="company",
            keyword_search_word="test",
        )
        df = _get_conditions_df(conditions)
        assert isinstance(df, pd.DataFrame)
        assert df.loc["集計開始日", 0] == "2025/01/01"
        assert df.loc["集計終了日", 0] == "2025/01/31"
        assert df.loc["都道府県", 0] == "指定なし"

    def test_get_conditions_df_basic_structure(self):
        """DataFrame の基本構造が正しい。

        テスト観点:
        - 正常系: 返却される DataFrame の構造確認
        """
        # RISK: RC-E001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="company",
            keyword_search_word="test",
        )
        df = _get_conditions_df(conditions)
        assert isinstance(df, pd.DataFrame)
        assert len(df) > 0
        assert df.shape[1] == 1  # 単一列（条件値）

    def test_get_conditions_df_contains_date_fields(self):
        """DataFrame に日付フィールドが含まれる。

        テスト観点:
        - 正常系: 必須の日付フィールドの確認
        """
        # RISK: RC-E001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="company",
            keyword_search_word="test",
        )
        df = _get_conditions_df(conditions)
        assert "集計開始日" in df.index
        assert "集計終了日" in df.index

    def test_get_conditions_df_date_format(self):
        """DataFrame の日付フォーマットが YYYY/MM/DD である。

        テスト観点:
        - 正常系: 日付フォーマットの確認
        """
        # RISK: RC-E001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="company",
            keyword_search_word="test",
        )
        df = _get_conditions_df(conditions)
        assert df.loc["集計開始日", 0] == "2025/01/01"
        assert df.loc["集計終了日", 0] == "2025/01/31"

    def test_get_conditions_df_with_keyword_search_method(self):
        """キーワード検索条件が設定される。

        テスト観点:
        - 正常系: キーワード検索方法フィールドの追加
        """
        # RISK: RC-E001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="store",
            keyword_search_word="テスト店舗",
        )
        df = _get_conditions_df(conditions)
        assert "検索方法" in df.index
        assert "検索ワード" in df.index
        assert df.loc["検索ワード", 0] == "テスト店舗"

    @patch("lib.generate_analysis_result_data.get_address_master_with_code")
    def test_get_conditions_df_with_gender(self, mock_get_address):
        """性別条件が設定される。

        テスト観点:
        - 正常系: 性別フィールドの追加
        """
        # RISK: RC-E001
        # Mock DataFrame を返す設定
        mock_df = pd.DataFrame(
            {
                "prefectures_name_kanji": ["東京都"],
                "shikuchoson_code": ["13101"],
                "shikugunchoson_name_kanji": ["千代田区"],
                "address_code": ["ADDRESS001"],
            }
        )
        mock_get_address.return_value = mock_df

        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
            gender_cd="1",
        )
        df = _get_conditions_df(conditions)
        assert "性別" in df.index
        assert "男性" in df.loc["性別", 0]

    @patch("lib.generate_analysis_result_data.get_address_master_with_code")
    def test_get_conditions_df_with_nendai(self, mock_get_address):
        """年代条件が設定される。

        テスト観点:
        - 正常系: 年代フィールドの追加
        """
        # RISK: RC-E001
        # Mock DataFrame を返す設定
        mock_df = pd.DataFrame(
            {
                "prefectures_name_kanji": ["東京都"],
                "shikuchoson_code": ["13101"],
                "shikugunchoson_name_kanji": ["千代田区"],
                "address_code": ["ADDRESS001"],
            }
        )
        mock_get_address.return_value = mock_df

        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
            nendai_cd_list=["01", "02"],
        )
        df = _get_conditions_df(conditions)
        assert "年代" in df.index

    @patch("lib.generate_analysis_result_data.get_address_master_with_code")
    def test_get_conditions_df_with_payment_method(self, mock_get_address):
        """決済方式条件が設定される。

        テスト観点:
        - 正常系: 決済方式フィールドの追加
        """
        # RISK: RC-E001
        # Mock DataFrame を返す設定
        mock_df = pd.DataFrame(
            {
                "prefectures_name_kanji": ["東京都"],
                "shikuchoson_code": ["13101"],
                "shikugunchoson_name_kanji": ["千代田区"],
                "address_code": ["ADDRESS001"],
            }
        )
        mock_get_address.return_value = mock_df

        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
            payment_method_list=["Cloud Pay(MPM)", "JPQR(MPM)"],
        )
        df = _get_conditions_df(conditions)
        assert "決済方式" in df.index

    @patch("lib.generate_analysis_result_data.get_address_master_with_code")
    def test_get_conditions_df_with_address_mocked(self, mock_get_address):
        """住所条件を含む場合、DataFrame に住所が含まれる。

        テスト観点:
        - 正常系: 住所条件付きのデータフレーム構築（モック）
        """
        # RISK: RC-E001
        # Mock DataFrame を返す設定
        mock_df = pd.DataFrame(
            {
                "prefectures_name_kanji": ["東京都"],
                "shikuchoson_code": ["13101"],
                "shikugunchoson_name_kanji": ["千代田区"],
                "address_code": ["ADDRESS001"],
            }
        )
        mock_get_address.return_value = mock_df

        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
        )

        df = _get_conditions_df(conditions)

        assert isinstance(df, pd.DataFrame)
        assert "都道府県" in df.index
        assert "市区町村" in df.index
        mock_get_address.assert_called_once_with(13)

    def test_get_conditions_df_default_values_for_missing_fields(self):
        """設定されていないフィールドは「指定なし」となる。

        テスト観点:
        - 異常系: 設定されていないフィールドのデフォルト値
        """
        # RISK: RC-E001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="company",
            keyword_search_word="test",
        )
        df = _get_conditions_df(conditions)
        assert df.loc["都道府県", 0] == "指定なし"
        assert df.loc["市区町村", 0] == "指定なし"
        assert df.loc["住所", 0] == "指定なし"
        assert df.loc["性別", 0] == "指定なし"

    def test_get_conditions_df_returns_dataframe_type(self):
        """返却値は pandas DataFrame である。

        テスト観点:
        - 正常系: 返却型の確認
        """
        # RISK: RC-E001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="company",
            keyword_search_word="test",
        )
        df = _get_conditions_df(conditions)
        assert isinstance(df, pd.DataFrame)
        assert not df.empty

    @patch("lib.generate_analysis_result_data.get_address_master_with_code")
    def test_get_conditions_df_with_big_jenre(self, mock_get_address):
        """業態条件が設定される。

        テスト観点:
        - 正常系: 業態フィールドの追加
        """
        # RISK: RC-E001
        # Mock DataFrame を返す設定
        mock_df = pd.DataFrame(
            {
                "prefectures_name_kanji": ["東京都"],
                "shikuchoson_code": ["13101"],
                "shikugunchoson_name_kanji": ["千代田区"],
                "address_code": ["ADDRESS001"],
            }
        )
        mock_get_address.return_value = mock_df

        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
            big_jenre_list=["飲食", "小売"],
        )
        df = _get_conditions_df(conditions)
        assert "業態" in df.index

    def test_get_conditions_df_with_january_dates(self):
        """1月の日付が正しくフォーマットされる。

        テスト観点:
        - 正常系: 月のフォーマット確認
        """
        # RISK: RC-E001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="company",
            keyword_search_word="test",
        )
        df = _get_conditions_df(conditions)
        assert df.loc["集計開始日", 0] == "2025/01/01"
        assert df.loc["集計終了日", 0] == "2025/01/31"

    def test_get_conditions_df_with_december_dates(self):
        """12月の日付が正しくフォーマットされる。

        テスト観点:
        - 正常系: 月のフォーマット確認（12月）
        """
        # RISK: RC-E001
        conditions = InputConditions(
            start_date=date(2024, 12, 1),
            end_date=date(2024, 12, 31),
            keyword_search_method="company",
            keyword_search_word="test",
        )
        df = _get_conditions_df(conditions)
        assert df.loc["集計開始日", 0] == "2024/12/01"
        assert df.loc["集計終了日", 0] == "2024/12/31"
