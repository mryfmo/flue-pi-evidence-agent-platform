"""InputConditions, RenderOptions の単体テスト。

このモジュールでは、models.py で定義される データクラスの
プロパティやメソッドをテストします。
"""

import re
from datetime import date

import pytest

from lib.models import InputConditions, RenderOptions


class TestInputConditionsCheck:
    """InputConditions.check プロパティのテスト。"""

    def test_check_returns_true_with_valid_address_condition(self, input_conditions_basic):
        """住所条件（prefecture_cd と city_cd）が設定されている場合 check が True を返す。

        テスト観点:
        - 正常系: 住所条件が両方揃っている場合の動作
        """
        # RISK: RC-D001
        result = input_conditions_basic.check
        assert result is True

    def test_check_returns_true_with_valid_keyword_condition(self):
        """キーワード検索条件が設定されている場合 check が True を返す。

        テスト観点:
        - 正常系: キーワード検索方法と検索語が揃っている場合の動作
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="company_store",
            keyword_search_word="テスト",
        )
        result = conditions.check
        assert result is True

    def test_check_returns_true_with_valid_map_condition(self):
        """地図検索条件が設定されている場合 check が True を返す。

        テスト観点:
        - 正常系: 緯度、経度、半径が揃っている場合の動作
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            map_search_latitude=35.6762,
            map_search_longitude=139.7674,
            map_search_radius_km=5.0,
        )
        result = conditions.check
        assert result is True

    def test_check_returns_true_with_valid_store_condition(self):
        """店舗検索条件が設定されている場合 check が True を返す。

        テスト観点:
        - 正常系: 店舗ID、緯度、経度、半径が揃っている場合の動作
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            selected_store_id="STORE001",
            store_center_latitude=35.6762,
            store_center_longitude=139.7674,
            store_search_radius_km=1.0,
        )
        result = conditions.check
        assert result is True

    def test_check_returns_true_with_valid_comparison_period(self):
        """比較期間が有効に設定されている場合 check が True を返す。

        テスト観点:
        - 正常系: 比較期間フラグが True で両日付が設定されている場合の動作
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
            enable_comparison=True,
            comparison_start_date=date(2024, 12, 1),
            comparison_end_date=date(2024, 12, 31),
        )
        result = conditions.check
        assert result is True

    def test_check_returns_true_with_full_conditions(self):
        """複数の付加条件が設定されている場合 check が True を返す。

        テスト観点:
        - 正常系: 住所条件に加えて性別、年代、業態が設定されている場合の動作
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
            gender_cd="1",
            nendai_cd_list=["01", "02"],
            big_jenre_list=["飲食"],
        )
        result = conditions.check
        assert result is True

    def test_check_returns_true_with_multiple_search_conditions(self):
        """複数の検索条件が同時に設定されている場合 check が True を返す。

        テスト観点:
        - 境界値: 複数条件のいずれかが満たされる場合（複合条件）
        """
        # RISK: RC-B001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
            map_search_latitude=35.6762,
            map_search_longitude=139.7674,
            map_search_radius_km=5.0,
        )
        result = conditions.check
        assert result is True

    def test_check_returns_false_when_no_search_condition(self):
        """検索条件がない場合 check が False を返す。

        テスト観点:
        - 異常系: どの検索条件も満たされていない場合の動作
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
        )
        result = conditions.check
        assert result is False

    def test_check_returns_false_when_comparison_enabled_but_comparison_start_date_is_none(
        self,
    ):
        """比較期間が有効だが comparison_start_date が None の場合 check が False を返す。

        テスト観点:
        - 異常系: 比較有効だが開始日が欠けている場合の動作
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
            enable_comparison=True,
            comparison_start_date=None,
            comparison_end_date=date(2024, 12, 31),
        )
        result = conditions.check
        assert result is False

    def test_check_returns_false_when_comparison_enabled_but_comparison_end_date_is_none(
        self,
    ):
        """比較期間が有効だが comparison_end_date が None の場合 check が False を返す。

        テスト観点:
        - 異常系: 比較有効だが終了日が欠けている場合の動作
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
            enable_comparison=True,
            comparison_start_date=date(2024, 12, 1),
            comparison_end_date=None,
        )
        result = conditions.check
        assert result is False

    def test_check_returns_false_when_prefecture_cd_only(self):
        """住所条件で prefecture_cd のみが設定されている場合 check が False を返す。

        テスト観点:
        - 異常系: prefecture_cd と city_cd 両方が必要な条件
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=None,
        )
        result = conditions.check
        assert result is False

    def test_check_returns_false_when_city_cd_only(self):
        """住所条件で city_cd のみが設定されている場合 check が False を返す。

        テスト観点:
        - 異常系: prefecture_cd と city_cd 両方が必要な条件
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd=None,
            city_cd=["13101"],
        )
        result = conditions.check
        assert result is False

    def test_check_returns_false_when_search_method_only(self):
        """キーワード検索で検索方法のみが設定されている場合 check が False を返す。

        テスト観点:
        - 異常系: 検索方法と検索語両方が必要な条件
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="company_store",
            keyword_search_word=None,
        )
        result = conditions.check
        assert result is False

    def test_check_returns_false_when_map_latitude_only(self):
        """地図検索で latitude のみが設定されている場合 check が False を返す。

        テスト観点:
        - 異常系: 緯度、経度、半径全てが必要な条件
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            map_search_latitude=35.6762,
            map_search_longitude=None,
            map_search_radius_km=None,
        )
        result = conditions.check
        assert result is False

    def test_check_returns_true_when_start_date_equals_end_date(self):
        """開始日と終了日が同じ場合 check が True を返す。

        テスト観点:
        - 境界値: 開始日 == 終了日の場合
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 15),
            end_date=date(2025, 1, 15),
            prefecture_cd="13",
            city_cd=["13101"],
        )
        result = conditions.check
        assert result is True

    def test_check_returns_true_when_radius_is_zero(self):
        """地図検索で半径が 0.0 の場合 check が True を返す。

        テスト観点:
        - 境界値: radius_km が 0.0 の場合（None ではない）
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            map_search_latitude=35.6762,
            map_search_longitude=139.7674,
            map_search_radius_km=0.0,
        )
        result = conditions.check
        assert result is True

    def test_check_returns_false_when_city_cd_is_empty_list(self):
        """住所条件で city_cd が空リストの場合 check が False を返す。

        テスト観点:
        - 境界値: 空リストは falsy 値として扱われる
        """
        # RISK: RC-D001
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=[],
        )
        result = conditions.check
        assert result is False


class TestInputConditionsHashMd5:
    """InputConditions.hash_md5 プロパティのテスト。"""

    def test_hash_md5_returns_valid_hash(self, input_conditions_basic):
        """MD5 ハッシュが正しい形式で返される。

        テスト観点:
        - 正常系: 32 文字の 16 進数文字列が返される
        """
        # RISK: RC-D002
        result = input_conditions_basic.hash_md5
        assert isinstance(result, str)
        assert len(result) == 32
        assert all(c in "0123456789abcdef" for c in result)

    def test_hash_md5_is_deterministic(self):
        """同一条件で生成されるハッシュは常に同じである。

        テスト観点:
        - 正常系: ハッシュの決定性（再現性）確認
        """
        # RISK: RC-D002
        conditions1 = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
        )
        conditions2 = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
        )
        hash1 = conditions1.hash_md5
        hash2 = conditions2.hash_md5
        assert hash1 == hash2

    def test_hash_md5_differs_with_different_conditions(self):
        """異なる条件で生成されるハッシュは異なる。

        テスト観点:
        - 異常系: 条件が異なるとハッシュも異なることを確認
        """
        # RISK: RC-D002
        conditions1 = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13101"],
        )
        conditions2 = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd="13",
            city_cd=["13102"],
        )
        hash1 = conditions1.hash_md5
        hash2 = conditions2.hash_md5
        assert hash1 != hash2

    def test_hash_md5_with_minimal_conditions(self):
        """最小限の条件でハッシュが生成される。

        テスト観点:
        - 境界値: 最小限の必須フィールドのみの場合
        """
        # RISK: RC-D002
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            keyword_search_method="company_store",
            keyword_search_word="test",
        )
        result = conditions.hash_md5
        assert isinstance(result, str)
        assert len(result) == 32

    def test_hash_md5_with_none_fields(self):
        """None フィールドが混在する場合ハッシュが生成される。

        テスト観点:
        - 異常系: None 値を含むオブジェクトのハッシング
        """
        # RISK: RC-D002
        conditions = InputConditions(
            start_date=date(2025, 1, 1),
            end_date=date(2025, 1, 31),
            prefecture_cd=None,
            city_cd=None,
            keyword_search_method="company",
            keyword_search_word="test",
        )
        result = conditions.hash_md5
        assert isinstance(result, str)
        assert len(result) == 32


class TestRenderOptions:
    """RenderOptions モデルのテスト。"""

    def test_render_options_default_values(self, render_options_basic):
        """デフォルト値が正しく設定されている。

        テスト観点:
        - 正常系: デフォルト値の確認
        """
        assert isinstance(render_options_basic, RenderOptions)
        assert render_options_basic.enable_merchant_map is False
        assert render_options_basic.enable_acctid_list_download is False
        assert render_options_basic.enable_analysis_data_download is False
        assert render_options_basic.enable_graphs is False

    def test_render_options_with_all_features_enabled(self, render_options_all_enabled):
        """全機能が有効になる場合。

        テスト観点:
        - 正常系: 全機能有効時の設定確認
        """
        assert isinstance(render_options_all_enabled, RenderOptions)
        assert render_options_all_enabled.enable_merchant_map is True
        assert render_options_all_enabled.enable_acctid_list_download is True
        assert render_options_all_enabled.enable_analysis_data_download is True
        assert render_options_all_enabled.enable_graphs is True

    def test_render_options_is_frozen(self):
        """RenderOptions は frozen dataclass である。

        テスト観点:
        - 異常系: インスタンス作成後の属性変更が不可能
        """
        render_options = RenderOptions(enable_merchant_map=True)
        with pytest.raises(AttributeError):
            render_options.enable_merchant_map = False

    def test_render_options_show_map_point_pin_default(self):
        """地点ピン表示フラグのデフォルト値は True。

        テスト観点:
        - 正常系: show_map_point_pin のデフォルト値確認
        """
        render_options = RenderOptions()
        assert render_options.show_map_point_pin is True

    def test_render_options_payment_method_list_none(self):
        """payment_method_list のデフォルト値は None。

        テスト観点:
        - 正常系: Optional フィールドのデフォルト値
        """
        render_options = RenderOptions()
        assert render_options.payment_method_list is None


class TestInputConditionsEdgeCases:
    """InputConditions の境界値テスト。"""

    def test_input_conditions_with_max_cities(self, input_conditions_max_cities):
        """最大数の市区町村を選択した場合 check が True を返す。

        テスト観点:
        - 境界値: 最大数の city_cd リスト
        """
        # RISK: RC-D001
        result = input_conditions_max_cities.check
        assert result is True

    def test_input_conditions_with_long_period(self, input_conditions_long_period):
        """長期間を指定した場合 check が True を返す。

        テスト観点:
        - 境界値: 36 ヶ月以上の期間
        """
        # RISK: RC-D001
        result = input_conditions_long_period.check
        assert result is True

    def test_input_conditions_with_special_chars(self, input_conditions_special_chars):
        """特殊文字を含む検索語で check が True を返す。

        テスト観点:
        - 境界値: 特殊文字を含む keyword_search_word
        """
        # RISK: RC-D001
        result = input_conditions_special_chars.check
        assert result is True

    def test_input_conditions_with_same_dates(self, input_conditions_same_dates):
        """開始日と終了日が同じ場合 check が True を返す。

        テスト観点:
        - 境界値: start_date == end_date
        """
        # RISK: RC-D001
        result = input_conditions_same_dates.check
        assert result is True

    def test_input_conditions_with_all_keyword_methods(self):
        """全キーワード検索方法が有効である。

        テスト観点:
        - 正常系: 全検索方法の確認
        """
        # RISK: RC-D001
        # 全検索方法を手動で確認
        for method in ["company_store", "company", "store", "address"]:
            conditions = InputConditions(
                start_date=date(2025, 1, 1),
                end_date=date(2025, 1, 31),
                keyword_search_method=method,
                keyword_search_word="テスト",
            )
            result = conditions.check
            assert result is True
