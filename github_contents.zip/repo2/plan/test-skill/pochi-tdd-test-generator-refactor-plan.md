# pochi-tdd-test-generator 改修計画

作成日: 2026-05-08  
対象スキル: `skills/test/pochi-tdd-test-generator/skills/run/SKILL.md`

---

## 現状の強み（改修対象外）

- RED/GREEN の責務分離が明確（テスト生成と実装を別スキルに分離）
- `test-mapping.json` を引き継ぎ成果物とするアーキテクチャはシンプルで追跡しやすい
- `--collect-only` のみで検証し pytest を実行しない判断はコード不在時の現実解として合理的
- fixtures/ の valid/invalid/edge 分類が Layer1/2 両方で共用できる設計は無駄がない

---

## 課題と改修内容

### 課題 1: サブエージェント依存が過剰（優先度: 高）

**問題**  
全 STEP が `pochi-test-onboarding:pochi-t2-tdd-workflow` に委譲されており、このエージェントが存在しない・インターフェースが変わるとスキル全体が動作不能になる。フォールバックの記述がない。

**改修案**  
各 STEP の冒頭でサブエージェントの存在確認を行い、存在しない場合は「直接実行モード（Claude Code 本体が処理）」へのフォールバックを定義する。

```markdown
> ⚠️ サブエージェント利用前提:
> `pochi-test-onboarding:pochi-t2-tdd-workflow` が利用可能な場合は Agent ツールで起動する。
> 利用不可の場合は Claude Code 本体が以下の手順に従って直接実行する（フォールバックモード）。
```

---

### 課題 2: Layer2 の関数シグネチャ予測が脆弱（優先度: 高）

**問題**  
STEP 6 で「名前に `parser` が含まれれば入力処理関数」という名前マッチングに頼っている。`plan.json` の `artifacts` に命名規則が守られていない場合、予測が大外れして `test-mapping.json` の `implementation_hint` が役に立たなくなる。

**改修案**  
`plan.json` に任意の `function_signatures` フィールドを追加できる拡張ポイントを定義し、存在する場合はそちらを優先参照する。

```json
// plan.json への任意フィールド追加例
{
  "artifacts": [...],
  "function_signatures": [
    {
      "module": "app/lib/parser.py",
      "functions": [
        { "name": "parse_csv", "signature": "(file_path: str) -> list[dict]" }
      ]
    }
  ]
}
```

SKILL.md の STEP 6 に以下のルールを追加する：

```markdown
■ function_signatures フィールドの優先参照
  plan.json に `function_signatures` フィールドが存在する場合、
  名前マッチングより優先してシグネチャを採用する。
  存在しない場合のみ名前マッチングフォールバックを使用する。
```

---

### 課題 3: `conftest.py` のマージ戦略が曖昧（優先度: 中）

**問題**  
「差分マージ」と書かれているが、具体的なマージアルゴリズムが定義されていない。既存の conftest.py が複雑な場合にサブエージェントが正しく判断できない恐れがある。

**改修案**  
マージ戦略を「追記専用」に単純化し、既存行は一切変更しないルールに明確化する。

```markdown
■ conftest.py の更新方針（改訂版）
  - 既存ファイルが存在する場合: 末尾追記のみ。既存行は一切変更しない。
    追記箇所は `# --- Added by pochi-tdd-test-generator {日時} ---` で明示する。
  - 既存ファイルが存在しない場合: 新規生成する。
```

---

### 課題 4: `test-ratio.json` の依存チェーン（優先度: 中）

**問題**  
STEP 6 が STEP 5 の出力（`test-ratio.json`）に依存しているが、STEP 5 が失敗した場合のフォールバック（デフォルト比率）の記述がない。

**改修案**  
STEP 5 内でデフォルト値を必ず書き込むことを保証するルールを追加する。

```markdown
■ test-ratio.json の保証
  STEP 5 開始時点で以下のデフォルト値を {app_path}/tests/.onboarding/test-ratio.json に書き込む。
  その後、risk-catalog.md の HIGH リスク数に応じて上書き更新する。
  （デフォルト: 正常系 40% / 異常系 40% / 境界値 20%）
  これにより、STEP 5 が途中失敗しても STEP 6 はデフォルト比率で続行できる。
```

---

### 課題 5: spec.json フォーマット前提が緩い（優先度: 中）

**問題**  
`data_contracts` / `business_rules` フィールドがない場合「ベストエフォートでマッピング」とあるが、許容基準がなく無言で品質が落ちる。

**改修案**  
フィールド不在時にユーザーへ明示的に警告し、続行/中断を選択させる。

```markdown
■ spec.json フォーマット検証（STEP 2 冒頭）
  以下の必須フィールドが存在するか確認する：
  - `data_contracts`: なければ警告を出し、ユーザーに続行確認を求める
  - `business_rules`: なければ Layer1 テストのビジネスルール観点が生成されない旨を通知する

  両フィールドが存在しない場合: 中断し、spec.json のフォーマット修正を促す。
  片方が存在しない場合: 警告のみで続行可（ベストエフォートで対応）。
```

---

### 課題 6: STEP 数が多く、並列化できる箇所がある（優先度: 低）

**問題**  
STEP 3（fixtures 生成）は STEP 5（Layer1）まで実際には使われないため、STEP 2 と並列実行が可能。現状は直列になっておりフロー全体が長い。

**改修案**  
STEP 2 と STEP 3 を並列実行可能と明記し、合計ステップ数を実質削減する。

```markdown
## STEP 2 & 3: 並列実行（contracts/ 生成 + fixtures 生成）

> 💡 STEP 2 と STEP 3 は互いに依存しないため、Agent ツールで同時起動してよい。
>    完了順は問わないが、両方が完了してから STEP 4 に進むこと。
```

---

## 改修優先順位まとめ

> ✅ 2026-05-10 全6課題の実装完了を確認済み（`skills/test/pochi-tdd-test-generator/skills/run/SKILL.md` を照合）

| # | 課題 | 優先度 | 工数感 | 状態 |
|---|---|---|---|---|
| 1 | サブエージェント不在フォールバック定義 | 高 | 中 | ✅ 完了 |
| 2 | Layer2 シグネチャ予測に拡張ポイント追加 | 高 | 小 | ✅ 完了 |
| 3 | conftest.py マージ戦略を追記専用に単純化 | 中 | 小 | ✅ 完了 |
| 4 | test-ratio.json デフォルト保証 | 中 | 小 | ✅ 完了 |
| 5 | spec.json フォーマット検証と中断条件の明示 | 中 | 小 | ✅ 完了 |
| 6 | STEP 2 & 3 の並列実行明記 | 低 | 小 | ✅ 完了 |

---

## 影響範囲

- 改修対象: `skills/test/pochi-tdd-test-generator/skills/run/SKILL.md`
- 関連スキル（変更なし): `pochi-spec-initializer`, `pochi-coding-agent`, `pochi-test-orchestrator`
- `plan.json` の `function_signatures` フィールドは任意追加のため、既存フォーマットへの後方互換性あり
