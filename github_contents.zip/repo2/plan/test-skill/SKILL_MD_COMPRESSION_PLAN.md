# SKILL.md 圧縮計画（pochi-unit-test-generator / pochi-test-orchestrator）

**作成日**: 2026-04-29
**対象**: `skills/test/pochi-unit-test-generator/skills/run/SKILL.md` / `skills/test/pochi-test-orchestrator/skills/run/SKILL.md`
**公式基準**: 500行以下（skill-best-practice.md）

---

## 前提：圧縮方針の3原則

1. **削除（A）**: Claude が一般知識として持っている、または docs/ に既存記載がある内容
2. **外部化（B）**: 特定ステップ実行時にのみ必要な詳細 → `prompts/` へ移動し SKILL.md は参照1行に置換
3. **残留（C）**: 禁止事項・制約・実行骨格など、毎回 Claude の目に触れる必要があるもの

> ⚠️ 禁止事項・制約を外部化すると品質が下がるリスクがある。これらは必ず SKILL.md に残す。

---

## 1. pochi-unit-test-generator

### 現状と分類

| セクション | 行番号 | 行数 | 分類 | 理由 |
|---|---|---|---|---|
| フロントマター・信頼境界注記 | 1-12 | 12 | C: 残留 | スキル認識・初期警告として必須 |
| スキル概要・生成対象表 | 14-37 | 24 | A: 削除 | Layer1/2の概念はdescriptionで説明済み |
| テストフレームワーク説明 | 38-49 | 12 | A: 削除 | Claude はpytestを知っている |
| STEP 1（ヒアリング・バリデーション・計画・config書き出し） | 51-134 | 84 | C: 残留 | 核となるフロー。毎回必須 |
| STEP 2（T0起動・スキップ判定・エラー対応） | 136-163 | 28 | C: 残留 | 起動指示・判定ロジック |
| STEP 2.5（モック方針確定） | 167-211 | 45 | C: 残留 | T0出力マージ・確認フロー |
| STEP 3（T1起動・チェックポイント・再実行フロー） | 214-252 | 39 | C: 残留 | 完了チェック・再実行分岐 |
| STEP 4（T4起動） | 256-268 | 13 | C: 残留 | 起動指示 |
| STEP 4.5（フィクスチャ型バリデーション） | 272-305 | 34 | C: 残留 | 自動検出ロジック・修正フロー |
| STEP 5（conftest.py生成） | 310-330 | 21 | C: 残留 | 起動指示・後処理 |
| STEP 6（Layer1生成） | 334-344 | 11 | C: 残留 | 起動指示 |
| STEP 7（Layer2設計） | 348-358 | 11 | C: 残留 | 起動指示 |
| STEP 8（Layer2実装） | 362-372 | 11 | C: 残留 | 起動指示 |
| STEP 8.5（品質検証・5チェック詳細） | 376-445 | 70 | B: 外部化 | 実行時のみ参照すれば十分 |
| STEP 9（テスト検証コマンド・エラー対応） | 448-474 | 27 | B: 外部化 | 実行時のみ参照すれば十分 |
| STEP 10（完了レポートテンプレート） | 477-538 | 62 | B: 外部化 | テンプレートは外部ファイルで管理 |
| 注意事項 | 542-561 | 20 | A: 削除 | 禁止事項はSTEP冒頭の⚠️注記でカバー済み |
| 前提条件（サブエージェント側要件表） | 563-573 | 11 | A: 削除 | スキル開発者向け情報。実行時不要 |

### 削減内訳

| 種別 | 対象 | 削減行数 |
|---|---|---|
| 削除（A） | スキル概要・テストFW説明・注意事項・前提条件 | **67行** |
| 外部化（B） | STEP 8.5 + STEP 9 + STEP 10 | **159行** |
| **削減合計** | | **226行** |

**573行 → 約347行**（公式基準500行以下を達成）

### 外部化先（新規作成3ファイル）

```
skills/test/pochi-unit-test-generator/skills/run/prompts/
├── step2_t0.md              （既存）
├── step3_t1.md              （既存）
├── step4_t4.md              （既存）
├── step5_conftest.md        （既存）
├── step6_layer1.md          （既存）
├── step7_layer2_design.md   （既存）
├── step8_layer2_impl.md     （既存）
├── step8_5_quality_check.md ★新規: STEP 8.5 の5チェック詳細（grepコマンド・判定ロジック・合格基準）
├── step9_verification.md    ★新規: STEP 9 のコマンド・エラー種別対応
└── step10_report.md         ★新規: 完了レポートのテンプレート全文
```

### SKILL.md の外部化後イメージ（STEP 8.5〜10）

```markdown
## STEP 8.5: 生成コード品質検証

> prompts/step8_5_quality_check.md に従って5チェックを実行すること。
> NG 時は STEP 8 のサブエージェントを再起動して修正（最大3回）。

## STEP 9: 生成テスト検証

> prompts/step9_verification.md に従って検証コマンドを実行すること。

## STEP 10: 完了レポート

> prompts/step10_report.md の形式で完了を報告すること。
```

---

## 2. pochi-test-orchestrator

### 現状と分類

| セクション | 行番号 | 行数 | 分類 | 理由 |
|---|---|---|---|---|
| フロントマター（name/description/triggers） | 1-17 | 17 | C: 残留 | スキル認識・トリガー定義 |
| タイトル・概説1行 | 20-22 | 3 | C: 残留 | スキル目的の即座把握 |
| When（起動条件・前提条件・起動しない条件） | 24-44 | 21 | C: 残留 | 誤起動防止の制約 |
| Do（確認・コマンド・パターン値対応表） | 46-67 | 22 | C: 残留 | 必須実行手順 |
| ステップ1（前処理スクリプト実行・骨格） | 69-74 | 6 | C: 残留 | 骨格指示 |
| ステップ2（generation_context.json読み込み手順） | 76-92 | 17 | B: 外部化 | 実行時のみ参照すれば十分 |
| ステップ3（参照ファイル読み込み手順） | 93-107 | 15 | B: 外部化 | 実行時のみ参照すれば十分 |
| ステップ4（サブエージェント呼び出し全文） | 108-238 | 131 | B: 外部化 | ACTION_PLAN P1-1で計画済み |
| ステップ5（品質ゲート・必須コマンド） | 240-251 | 12 | C: 残留 | 必須コマンド |
| エラーハンドリング（フォールバック方針） | 253-260 | 8 | C: 残留 | フォールバック方針 |
| Don't（禁止事項） | 262-282 | 21 | C: 残留 | 制約・禁止事項 |
| 品質基準の遵守 | 284-295 | 12 | C: 残留 | 毎回遵守が必須 |
| Inputs（入力ファイル一覧） | 297-314 | 18 | A: 削除 | docs/INSTALLATION.md に記載済み |
| Outputs（出力ファイル一覧・連携フロー） | 316-370 | 55 | A: 削除 | docs/ に記載済み |
| 4パターン体系（詳細解説・環境変数例・旧互換） | 372-451 | 80 | A: 削除 | Do節で骨格提示済み。詳細はdocs/QUICKSTART.md |
| Troubleshooting（詳細手順） | 454-517 | 64 | A: 削除 | docs/ADVANCED.md に記載済み |
| 安全対策 | 519-529 | 11 | C: 残留 | セキュリティ制約 |
| 使用例（フロー説明3例） | 531-564 | 34 | A: 削除 | docs/QUICKSTART.md で十分 |
| 参照ドキュメント（リンク集） | 566-579 | 14 | A: 削除 | When節・Don't節のリンクで代替 |
| 末尾1行 | 583 | 1 | A: 削除 | |

### 削減内訳

| 種別 | 対象 | 削減行数 |
|---|---|---|
| 削除（A） | Inputs / Outputs / 4パターン体系 / Troubleshooting / 使用例 / 参照ドキュメント | **266行** |
| 外部化（B） | ステップ2〜4 → prompts/subagent_call_template.md | **163行** |
| **削減合計** | | **429行** |

**583行 → 約154行**（公式基準500行以下を大幅達成）

### 外部化先（新規作成1ファイル）

```
skills/test/pochi-test-orchestrator/prompts/
└── subagent_call_template.md  ★新規: ステップ2〜4の詳細手順・プロンプトテンプレート全文
```

> ⚠️ 既存の `prompts/` はスキルルート直下（`skills/run/` の外）に存在する。`skills/run/prompts/` に新規作成すると2系統になるため、既存 `prompts/` に統一する。
> SKILL.md（`skills/run/SKILL.md`）からの相対参照は `../../prompts/subagent_call_template.md` となる。

### SKILL.md の外部化後イメージ（Instructions節）

```markdown
## Instructions

**以下の手順を逐語的に実行してください。**

### ステップ1: 前処理スクリプト実行
上記 Do 節のコマンドを実行してください。

### ステップ2〜4: コンテキスト読み込み・サブエージェント委譲
`../../prompts/subagent_call_template.md` を読み込み、記載の手順を実行してください。

### ステップ5: 品質ゲート実行（必須）
...（現行のまま残留）
```

---

## 実装順序

### pochi-unit-test-generator（573行 → 約347行）

```
Step1: 削除（A）— スキル概要・注意事項・前提条件セクションを削除（67行削減）
Step2: 外部化（B）— STEP 8.5 を prompts/step8_5_quality_check.md に移動し参照1行に置換
Step3: 外部化（B）— STEP 9 を prompts/step9_verification.md に移動し参照1行に置換
Step4: 外部化（B）— STEP 10 を prompts/step10_report.md に移動し参照1行に置換
Step5: 確認 — wc -l SKILL.md が 500 以下であること
```

### pochi-test-orchestrator（583行 → 約154行）

```
Step1: 削除（A）— Inputs / Outputs / 4パターン体系 / Troubleshooting / 使用例 / 参照ドキュメントを削除（266行削減）
Step2: 外部化（B）— ステップ2〜4を prompts/subagent_call_template.md に移動し Instructions節を参照2行に置換
Step3: 確認 — wc -l SKILL.md が 500 以下であること
```

---

## 検証チェックリスト

| # | 確認項目 | 合格基準 |
|---|---|---|
| 1 | 両スキルの SKILL.md 行数 | `wc -l` の結果が 500 以下 |
| 2 | prompts/ ファイルの存在確認 | 新規作成ファイルが存在する |
| 3 | スキル認識 | `/reload-plugins` 後にスキルが正常認識される |
| 4 | 禁止事項・制約の残留確認 | `grep "禁止\|厳禁\|必須" SKILL.md` でヒットする |
| 5 | 外部化先への参照記述 | 各 STEP に `prompts/xxx.md` への参照が記載されている |
