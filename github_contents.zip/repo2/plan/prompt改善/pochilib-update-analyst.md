# pochilib-update-analyst プロンプト改善 差分分析レポート

**分析日**: 2026-05-11  
**対象**: `/home/user/pochi-dp-developer-docs/skills/infra/pochilib-update-analyst` 配下の全プロンプトファイル  
**参照ベストプラクティス**: `claude-code-guide/official/prompting-best-practices.md`（全モデル共通の一般原則セクション）  
**適用モデル**: Claude Code 本体（メインエージェント）＋各子スキル

---

## 対象ファイル一覧

| ファイル | 役割 |
|---|---|
| `skills/run/SKILL.md` | メインスキルのエントリポイント（ワークフロー概要・バリデーション） |
| `prompts/analyst.md` | メインオーケストレーター詳細プロンプト（Step 1〜6 全手順） |
| `children/pochilib-usage-scanner/skills/run/SKILL.md` | 子スキル①：使用状況スキャン |
| `children/pochilib-changelog-analyzer/skills/run/SKILL.md` | 子スキル②：変更ログ解析 |
| `children/pochilib-impact-detector/skills/run/SKILL.md` | 子スキル③：影響分析 |

---

## スキル構造の特徴

親スキル（`pochilib-update-analyst`）が `analyst.md` で3つの子スキルを順次オーケストレートする階層構造。`skills/run/SKILL.md` がトリガーエントリポイントで、実行詳細は `prompts/analyst.md` に委譲されている。`analyst.md` は400行超の大規模プロンプトであり、出力JSONスキーマを全文インライン記述しているため、**コンテキスト消費が特に大きい**。

---

## 対応必要な差分

---

### 🔴 差分A：複数ドキュメント参照時に `<document>` タグ構造化がない

**根拠（prompting-best-practices.md 一般原則）**：
> 複数のドキュメントを使用する場合、各ドキュメントを `<document>` タグでラップし、`<source>`、`<document_content>` サブタグを明確化する。

**影響ファイルと箇所**：

| ファイル | 箇所 | 現状 |
|---|---|---|
| `prompts/analyst.md` | Step 2.5 でリリースノートファイル一覧を Skill へ渡す指示 | Markdownリスト（各ファイルパスを `- パス` で列挙） |
| `prompts/analyst.md` | Step 3 で changelog-analyzer に渡すリリースノートファイル指示例 | コードブロック内のMarkdownリスト列挙 |
| `prompts/analyst.md` | Step 5 で3つのJSONファイルを統合する指示 | Markdownリスト（ナンバリング） |
| `children/pochilib-impact-detector/skills/run/SKILL.md` | Step 2「以下の2ファイルを読み込みます」 | Markdownリストのみ |
| `children/pochilib-usage-scanner/skills/run/SKILL.md` | Step 2「pyproject.toml から読み込み」 | ファイルパスのインライン記述のみ |

**改善例（analyst.md Step 5 統合読み込み）**：
```xml
<!-- 現状 -->
1. {APP_REPOSITORY_PATH}/pochilib-upgrade-analysis/tmp/pochilib-usage-map.json
2. {APP_REPOSITORY_PATH}/pochilib-upgrade-analysis/tmp/changelog-analysis.json
3. {APP_REPOSITORY_PATH}/pochilib-upgrade-analysis/tmp/impact-report.json

<!-- 改善後 -->
<documents>
  <document index="1">
    <source>{APP_REPOSITORY_PATH}/pochilib-upgrade-analysis/tmp/pochilib-usage-map.json</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
  <document index="2">
    <source>{APP_REPOSITORY_PATH}/pochilib-upgrade-analysis/tmp/changelog-analysis.json</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
  <document index="3">
    <source>{APP_REPOSITORY_PATH}/pochilib-upgrade-analysis/tmp/impact-report.json</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
</documents>
```

---

### 🔴 差分B：JSONスキーマ例・指示例が `<example>` タグで囲まれていない

**根拠**：
> 例を `<example>` タグ（複数なら `<examples>` タグ）でラップすること。Claude が指示と区別できるようにする。

**影響ファイルと箇所**：

| ファイル | 箇所 | 現状 |
|---|---|---|
| `prompts/analyst.md` | Step 2「正式出力スキーマ（usage-map.json）」JSONブロック | コードブロックのみ |
| `prompts/analyst.md` | Step 3「正式出力スキーマ（changelog-analysis.json）」JSONブロック | コードブロックのみ |
| `prompts/analyst.md` | Step 2.5「ファイル一覧例（current_version=0.7.1、target_version=0.7.4 の場合）」 | コードブロックのみ |
| `prompts/analyst.md` | Step 3「changelog-analyzerへの指示例」 | コードブロックのみ |
| `children/pochilib-impact-detector/skills/run/SKILL.md` | Step 4「影響度判定ルール（CRITICAL/HIGH/MEDIUM/LOW）」 | 箇条書きのみ |
| `children/pochilib-usage-scanner/skills/run/SKILL.md` | Step 2「pyproject.toml の検索パターン」 | コードブロックのみ |

**改善例（analyst.md Step 2.5 ファイル一覧例）**：
```xml
<!-- 現状 -->
**例** (current_version=0.7.1、target_version=0.7.4 の場合):
選択されるファイル：
- `<スキルルート>/release-note/pochilib/pochilib-0.7.1.md`
- ...

<!-- 改善後 -->
<example label="ファイル選択例（current=0.7.1、target=0.7.4）">
  選択されるファイル（バージョン境界を含む）:
  - `<スキルルート>/release-note/pochilib/pochilib-0.7.1.md`
  - `<スキルルート>/release-note/pochilib/pochilib-0.7.2.md`
  - `<スキルルート>/release-note/pochilib/pochilib-0.7.3.md`
  - `<スキルルート>/release-note/pochilib/pochilib-0.7.4.md`
</example>
```

---

### 🔴 差分C：Step 2（usage-scanner）と Step 3（changelog-analyzer）が並列化できるのに逐次固定

**根拠**：
> 独立したツール呼び出しはすべて並列で実行するよう明示的に指示する。依存関係がない場合は同時に呼び出すことを優先する。

**影響ファイルと箇所**：

| ファイル | 箇所 | 現状 | 問題 |
|---|---|---|---|
| `prompts/analyst.md` | Step 2（usage-scanner）→ Step 2.5 → Step 3（changelog-analyzer）の順番 | 逐次実行を前提とした番号付き構成 | usage-scanner と changelog-analyzer は相互依存なし → 並列起動可能 |
| `children/pochilib-impact-detector/skills/run/SKILL.md` | Step 2「以下の2ファイルを読み込みます」 | 番号付きリスト → 逐次暗示 | usage-map.json と changelog-analysis.json は独立して読み込み可 |

> ✅ Step 2.5（リリースノートファイル特定）が Step 3 の前提になるため、  
> 正確には「Step 2 と（Step 2.5 + Step 3）」の並列化が可能。

**改善例（analyst.md）**：
```
<!-- 現状 -->
Step 2: 使用状況スキャン (pochilib-usage-scanner)
  ...（usage-scanner を起動）

Step 2.5: リリースノートファイルの特定
  ...

Step 3: 変更ログ解析 (pochilib-changelog-analyzer)
  ...

<!-- 改善後 -->
Step 2 と Step 2.5〜3 は並列実行可能（相互依存なし）：

並列実行グループ:
  [並列A] Step 2: 使用状況スキャン (pochilib-usage-scanner) を起動
  [並列B] Step 2.5 → Step 3: リリースノートファイル特定 → 変更ログ解析を順次実行

両グループ完了後 → Step 4（impact-detector）へ進む
```

---

### 🟡 差分D：大規模プロンプト（400行超）にXMLタグ構造化がない

**根拠**：
> XML タグは Claude が複雑なプロンプトを明確に解析するのに役立つ。`<instructions>`, `<context>`, `<rules>`, `<step>` などで各コンテンツタイプを分離する。長いドキュメントは上部に配置し、指示・クエリは後に置く。

**影響ファイルと箇所**：

| ファイル | 現状の構造 | 構造化すべき主要ブロック |
|---|---|---|
| `prompts/analyst.md` | Markdown見出し（## Step N:）のみで400行超 | 各Stepを `<step id="N">`, 禁止事項を `<constraints>`, 役割分離表を `<role_separation>` に |
| `skills/run/SKILL.md` | Markdown見出しのみ | バリデーション手順を `<validation>`, ワークフロー概要を `<workflow>` に |
| `children/pochilib-impact-detector/skills/run/SKILL.md` | Markdown見出しのみ | 影響度判定ルールを `<rules>`, 出力スキーマを `<output_schema>` に |
| `children/pochilib-usage-scanner/skills/run/SKILL.md` | Markdown見出しのみ | スキャン手順を `<instructions>`, 禁止検索パターンを `<patterns>` に |

**改善例（analyst.md Step 3.5 役割分離）**：
```xml
<!-- 現状 -->
### Step 3.5: 役割の分離確認

| 役割 | Skill | 行動 |
|------|-------|------|
| **changelog 解析（全件記録）** | ...

<!-- 改善後 -->
<role_separation>
  <role skill="pochilib-changelog-analyzer">
    リリースノートの全変更項目を、影響有無に関わらず漏れなく記録する（選別しない）
  </role>
  <role skill="pochilib-impact-detector">
    Step 3 で記録された全変更の中から、使用状況マップと関連するものを選別して影響度を判定する
  </role>
  <constraint>
    changelog 解析（Step 3）の段階で「このアプリに関係なさそう」という理由で項目を除外してはならない。
    選別・除外は必ず Step 4 (impact-detector) の段階で実施する。
  </constraint>
</role_separation>
```

---

### 🟡 差分E：JSONスキーマが `analyst.md` と子スキルSKILL.mdで重複定義されている

**根拠**：
> 不要な重複は避ける。共通の定義は一箇所にまとめ、各プロンプトからは参照のみにする。コンテキスト消費を最小化する。

**影響ファイルと箇所**：

| 重複内容 | `analyst.md` 内の箇所 | 重複先 |
|---|---|---|
| `pochilib-usage-map.json` の正式スキーマ（約30行のJSON） | Step 2「正式出力スキーマ（必須遵守）」 | `children/pochilib-usage-scanner/skills/run/SKILL.md` 内にも出力スキーマが定義されている可能性 |
| `changelog-analysis.json` の正式スキーマ（約30行のJSON） | Step 3「正式出力スキーマ（必須遵守）」 | `children/pochilib-changelog-analyzer/skills/run/SKILL.md` 内にも定義されている可能性 |
| 禁止事項（スキーマのフラット配置禁止等） | Step 2・Step 3 それぞれに重複掲載 | 子スキルのSKILL.md側にも記載がある場合、3箇所に分散 |

**改善例**：
```
<!-- 現状: analyst.md の Step 2 と Step 3 それぞれに全文スキーマを掲載 -->
**⚠️ 正式出力スキーマ（必須遵守）**:
...（30行のJSON）...
禁止事項: ...

<!-- 改善後: 子スキルのSKILL.mdでスキーマを定義し、analyst.mdからは参照のみ -->
usage-scanner はスキーマ定義（`children/pochilib-usage-scanner/skills/run/SKILL.md`）に従って
pochilib-usage-map.json を生成すること。
スキーマの詳細は子スキルのSKILL.mdを参照。

## analyst.md でのスキーマ確認観点（トップレベルキーのみ列挙）
- `scan_metadata`, `summary`, `repositories`, `cross_repository_analysis`, `alerts`, `skipped_repositories`
```

---

### 🟡 差分F：`skills/run/SKILL.md` と `prompts/analyst.md` の役割分担が不明確（重複）

**根拠**：
> 不要な重複は避ける。設計意図が明確でない二重管理は保守コストと誤解を生む。

**影響箇所**：

| 重複内容 | `skills/run/SKILL.md` | `prompts/analyst.md` |
|---|---|---|
| ワークフロー（Step 0〜6 の概要） | フローチャート形式で記載 | 同じ Step 0〜6 を詳細手順として再掲 |
| バリデーション手順（release-note/ の存在確認） | `## Validation Steps` セクションに記載 | Step 0-A / Step 0-B として詳細再掲 |
| エラーハンドリング表 | `## Error Handling` に記載 | 各 Step の「エラー処理」として再掲 |

**改善例**：
```
<!-- 現状: skills/run/SKILL.md にも analyst.md にもバリデーション手順が記載されている -->

<!-- 改善後: 役割を明確に分離 -->
skills/run/SKILL.md:
  → エントリポイント・トリガー・高レベルワークフロー概要・制約のみ記載
  → 詳細手順は prompts/analyst.md を参照すること明示

prompts/analyst.md:
  → 全詳細手順（Step 0〜6）を一元管理
  → スキーマ・エラーハンドリング・禁止事項の詳細
```

---

### 🟡 差分G：禁止事項の記述が理由薄く箇条書きのみの箇所がある

**根拠**：
> 指示の背後にあるコンテキストや動機を提供することで、Claude がゴールをより深く理解できる。「何をしないか」よりも「なぜか・何をすべきか」を伝える肯定形が効果的。

**影響ファイルと箇所**：

| ファイル | 箇所 | 現状 | 問題 |
|---|---|---|---|
| `prompts/analyst.md` | Step 2 スキーマ「禁止事項」（`scan_date` をフラット配置禁止等） | 禁止構造の列挙のみ。理由なし | なぜフラット配置が禁止なのか（下流スキルとのスキーマ整合性）が伝わらない |
| `prompts/analyst.md` | Step 2「ユーザーへの再質問は絶対に行わないこと」 | 太字の禁止指示のみ | 理由（Step 1-A で収集済みのため）は書かれているが、重要性の背景説明なし |
| `children/pochilib-changelog-analyzer/skills/run/SKILL.md` | 「このアプリに関係なさそう」による省略禁止 | ✅ 理由付きで記述されている | **対応不要** |

**改善例（analyst.md Step 2 スキーマ禁止事項）**：
```
<!-- 現状 -->
**禁止事項**: 以下の構造は正式スキーマではないため使用禁止:
- `scan_date`, `target_repository`, `current_version` をトップレベルにフラット配置すること

<!-- 改善後 -->
**禁止事項（理由付き）**: 以下の構造は使用禁止。
理由: pochilib-impact-detector（Step 4）は `repositories` オブジェクトを参照してリポジトリ別影響を判定するため、
スキーマが不一致だと impact-detector のパース処理が失敗する。

禁止構造:
- `scan_date`, `target_repository`, `current_version` をトップレベルにフラット配置すること
  → 正しくは `scan_metadata.scan_date` にネストする
- `repositories` を配列にすること
  → 正しくはリポジトリ名をキーとするオブジェクト
```

---

## 優先度マトリクス

| 優先度 | 差分 | 影響範囲 | 改善コスト |
|:---:|---|---|:---:|
| 🔴 高 | A：`<document>`タグ欠如 | 5ファイル | 低〜中 |
| 🔴 高 | B：`<example>`タグ欠如 | 4ファイル・6箇所 | 低 |
| 🔴 高 | C：Step 2&3 並列化可能なのに逐次固定 | `analyst.md` フロー全体 | 中 |
| 🟡 中 | D：XML構造化全般（400行超の大規模プロンプト） | 全ファイル | 高 |
| 🟡 中 | E：JSONスキーマの重複定義 | `analyst.md`（2箇所）＋子スキル | 中 |
| 🟡 中 | F：SKILL.md と analyst.md の役割重複 | 2ファイル | 中 |
| 🟡 中 | G：禁止理由の説明欠如 | `analyst.md` 2箇所 | 低 |

---

## ✅ ベストプラクティスに準拠できている点

| 観点 | 対応ファイル |
|---|---|
| 明確なロール設定（「あなたは影響分析の専門家です」） | `prompts/analyst.md` 冒頭 Role セクション |
| スコープ宣言（「レポート生成のみ・実装は行わない」）の明示 | `skills/run/SKILL.md`, `prompts/analyst.md` 冒頭 |
| バリデーション手順の事前実施（Step 0-A/0-B） | `skills/run/SKILL.md`, `prompts/analyst.md` |
| エラーハンドリング表の提供（状況→対応の対照表） | `skills/run/SKILL.md` |
| 役割分離の明示（changelog解析 vs impact判定）| `prompts/analyst.md` Step 3.5 |
| スキーマ整合性の事前確認（Step 4 冒頭でスキーマ検証）| `prompts/analyst.md` Step 4 |
| 内容整合性確認（リリースノート件数とJSONの突合）| `prompts/analyst.md` Step 4-B |
| 子スキルへの明示的なコンテキスト引き継ぎ指示 | `prompts/analyst.md` Step 2（「ユーザーへの再質問禁止」の理由付き） |
| Step 3.5 で処理責務の境界を表で明示 | `prompts/analyst.md` |

---

## 他スキルとの差分比較（このスキル固有の課題）

| 差分 | pochi-test-orchestrator | pochi-unit-test-generator | pochi-tdd-test-generator | **pochilib-update-analyst** |
|---|:---:|:---:|:---:|:---:|
| A：`<document>`タグ欠如 | ✅ | ✅ | ✅ | ✅（5ファイル） |
| B：`<example>`タグ欠如 | ✅ | ✅ | ✅ | ✅（JSONスキーマ例が特に大きい） |
| C：並列化が逐次固定 | ✅ | ✅ | ⚠️一部対応 | **固有**: Step 2&3 が並列化可能なのに逐次設計 |
| D：XML構造化 | ✅ | ✅ | ✅ | ✅（400行の `analyst.md` が特に重大） |
| E：重複定義 | ✅ | ✅ | ✅ | **固有**: JSONスキーマが `analyst.md` と子スキルで重複 |
| F：SKILL.md と詳細プロンプトの役割重複 | — | — | — | **固有**: `SKILL.md` と `analyst.md` でワークフロー・バリデーション・エラー処理が二重管理 |
| G：禁止理由の説明欠如 | ✅ | ✅ | ✅ | ✅ |

---

## 対応不要な差分（Opus 4.7専用のため除外）

| 差分 | 理由 |
|---|---|
| `effort` パラメータの設定（`high`/`xhigh`等） | Opus 4.7 固有のAPIパラメータ。このスキルは Claude Code 本体（モデル未指定）で実行される |
| 適応的思考（`thinking: {type: "adaptive"}`）の設定 | Opus 4.6/4.7 固有の機能 |
