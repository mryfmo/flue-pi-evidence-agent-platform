# pochi-tdd-test-generator プロンプト改善 差分分析レポート

**✅ 対応完了**: 2026-05-11  
**分析日**: 2026-05-11  
**対象**: `/home/user/pochi-dp-developer-docs/skills/test/pochi-tdd-test-generator` 配下の全プロンプトファイル  
**参照ベストプラクティス**: `claude-code-guide/official/prompting-best-practices.md`（全モデル共通の一般原則セクション）  
**適用モデル**: メインエージェント（Claude Code 本体）＋ `pochi-t2-tdd-workflow` 等のサブエージェント

---

## 対象ファイル一覧

| ファイル | 備考 |
|---|---|
| `skills/run/SKILL.md` | このスキル唯一のプロンプトファイル（agents/・prompts/ は存在しない） |

---

## スキル構造の特徴

`pochi-tdd-test-generator` は `pochi-unit-test-generator` と異なり、`skills/run/SKILL.md` の1ファイルに全指示が集約されている。STEP 1〜10 を1ファイルで網羅する大規模プロンプト（約600行）であるため、**構造化不足の影響が特に大きい**。

---

## 対応必要な差分

---

### ✅ 🔴 差分A：複数ドキュメント参照時に `<document>` タグ構造化がない

**根拠（prompting-best-practices.md 一般原則）**：
> 複数のドキュメントを使用する場合、各ドキュメントを `<document>` タグでラップし、`<source>`、`<document_content>` サブタグを明確化する。

**影響箇所（SKILL.md 内）**：

| STEP | 箇所 | 現状 |
|---|---|---|
| STEP 2 | spec.json + plan.json の読み込み指示 | Markdownリストでパスのみ列挙 |
| STEP 5（Layer1生成） | data-contracts.json, business-rules.json, risk-catalog.md の読み込み指示 | Markdownリストでパスのみ列挙 |
| STEP 6（Layer2設計） | spec.json, plan.json, test-viewpoints.json, fixtures/ の読み込み指示 | Markdownリストでパスのみ列挙 |
| STEP 7（Layer2実装） | unit-test-design.md の読み込み指示 | Markdownリストでパスのみ列挙 |
| STEP 9（test-mapping.json生成） | 生成テストファイル群の読み込み | `find` コマンドで列挙のみ |

**改善例（STEP 5）**：
```xml
<!-- 現状 -->
- {app_path}/tests/contracts/data-contracts.json を読み込む
- {app_path}/tests/contracts/business-rules.json を読み込む
- {app_path}/tests/contracts/risk-catalog.md を読み込む

<!-- 改善後 -->
<documents>
  <document index="1">
    <source>{app_path}/tests/contracts/data-contracts.json</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
  <document index="2">
    <source>{app_path}/tests/contracts/business-rules.json</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
  <document index="3">
    <source>{app_path}/tests/contracts/risk-catalog.md</source>
    <document_content>（Readツールで読み込む）</document_content>
  </document>
</documents>
```

---

### ✅ 🔴 差分B：コード例・実装例が `<example>` タグで囲まれていない

**根拠**：
> 例を `<example>` タグ（複数なら `<examples>` タグ）でラップすること。Claude が指示と区別できるようにする。3〜5つの例を含めることを推奨。

**影響箇所（SKILL.md 内）**：

| STEP | 箇所 | 現状 |
|---|---|---|
| STEP 6（Layer2設計） | 「予測した関数の想定シグネチャ例」 | コードブロックのみ、`<example>`タグなし |
| STEP 2 | data-contracts.json の boundary 設定例（`boundary "CsvInput"` 等） | インラインコードのみ |
| STEP 4（conftest.py生成） | `artifacts` フィールドへの任意フィールド追加例（JSON）| コードブロックのみ |
| STEP 9 | `test-mapping.json` のフォーマット例（JSON） | コードブロックのみ |
| STEP 8（検証） | 「期待される状態」「異常な状態」の具体例 | 箇条書きのみ |

**改善例（STEP 6 シグネチャ予測例）**：
```xml
<!-- 現状 -->
予測した関数の想定シグネチャ例:
  def parse_csv(file_path: str) -> list[dict]: ...
  def validate_amount(amount: float) -> bool: ...

<!-- 改善後 -->
<examples label="関数シグネチャ予測例">
  <example label="入力処理関数（parser系モジュール）">
    def parse_csv(file_path: str) -> list[dict]: ...
  </example>
  <example label="バリデーション関数（business_rules由来）">
    def validate_amount(amount: float) -> bool: ...
  </example>
</examples>
```

---

### ✅ 🔴 差分C：並列実行を促す記述が一部で不明確

**根拠**：
> 独立したツール呼び出しはすべて並列で実行するよう明示的に指示する。依存関係がない場合は同時に呼び出すことを優先する。

**影響箇所（SKILL.md 内）**：

| STEP | 箇所 | 現状 | 評価 |
|---|---|---|---|
| STEP 2 & 3 | 「STEP 2 と STEP 3 は互いに依存しないため、Agent ツールで同時起動してよい」 | ✅ 並列化を明示している | **適切（対応不要）** |
| STEP 5（Layer1） | data-contracts.json, business-rules.json, risk-catalog.md 読み込み | Markdownリスト→逐次暗示 | **改善必要** |
| STEP 6（Layer2設計） | spec.json, plan.json, test-viewpoints.json 読み込み | Markdownリスト→逐次暗示 | **改善必要** |

> ✅ STEP 2&3 の並列実行指示は良い実践例。STEP 5・6 内部のファイル読み込みについても同様の明示が必要。

**改善例（STEP 5）**：
```
<!-- 現状 -->
- {app_path}/tests/contracts/data-contracts.json を読み込む
- {app_path}/tests/contracts/business-rules.json を読み込む
- {app_path}/tests/contracts/risk-catalog.md を読み込む

<!-- 改善後 -->
以下のファイルを読み込む（相互依存なし→並列で一括読み込みすること）：
- {app_path}/tests/contracts/data-contracts.json
- {app_path}/tests/contracts/business-rules.json
- {app_path}/tests/contracts/risk-catalog.md
```

---

### ✅ 🟡 差分D：1ファイル600行の大規模プロンプトにXMLタグ構造化がない

**根拠**：
> XML タグは Claude が複雑なプロンプトを明確に解析するのに役立つ。`<instructions>`, `<context>`, `<rules>`, `<step>` などで各コンテンツタイプを分離する。長いドキュメントを上部に配置し、クエリ・指示を後に置く。

**影響箇所（SKILL.md 全体）**：

| セクション | 現状の構造 | 構造化すべき内容 |
|---|---|---|
| スキル全体（STEP 1〜10） | `## STEP N:` のMarkdown見出しのみ | 各 STEP を `<step id="N">` で囲む |
| 「注意事項」セクション | Markdownリスト | `<constraints>` に変換 |
| 「前提条件」セクション（サブエージェント対応要件） | Markdownテーブルのみ | `<prerequisites>` に変換 |
| サブエージェント呼び出し指示（各STEP内コードブロック） | コードブロック形式 | `<subagent_instruction>` で明示 |
| spec.json フォーマット検証（STEP 2冒頭） | 箇条書きのみ | `<validation_rules>` に変換 |

**改善例（STEP 8 注意事項セクション）**：
```xml
<!-- 現状 -->
## 注意事項
- **サブエージェント優先**: ...
- **T0 実行禁止**: ...
- **ImportError は修正不要**: ...

<!-- 改善後 -->
<constraints>
  <constraint id="subagent-first">
    サブエージェント優先: 各ステップで指定のカスタムサブエージェントを Agent ツールで起動することを優先する。
  </constraint>
  <constraint id="no-t0">
    T0 実行禁止: このスキルでは T0（既存コード解析）を実行しない。コードが存在しないため。
  </constraint>
  <constraint id="import-error-ok">
    ImportError は修正不要: コードが存在しないため発生する ImportError は想定内。
    テストコード起因の SyntaxError / NameError のみ修正すること。
  </constraint>
</constraints>
```

---

### ✅ 🟡 差分E：禁止理由の説明なしに禁止事項のみ列挙している箇所がある

**根拠**：
> 指示の背後にあるコンテキストや動機を提供することで、Claude がゴールをより深く理解できる。「何をしないか」よりも「なぜか・何をすべきか」を伝える肯定形が効果的。

**影響箇所（SKILL.md 内）**：

| STEP | 箇所 | 現状 | 問題 |
|---|---|---|---|
| 注意事項 | 「**pytest 実行禁止**: STEP 8 では `--collect-only` のみ実行する」 | 理由は補足されているが後続文が弱い | 「コードが存在しない状態でテストを実行すると全件 FAILED になるため混乱を招く」という記述はあるが、`<constraint>` などで明確に構造化されていない |
| STEP 7（Layer2実装） | 「■ 重要: テスト対象のモジュールはまだ実装されていない。ImportError が発生することを前提として...」 | 前提の説明はあるが「なぜそうするか」の背景説明なし | TDD の意図（RED→GREEN サイクル）の文脈が伝わりにくい |
| STEP 2 フォーマット検証 | 「spec.json のフォーマット修正を促す」で終わる | 修正方法の提示なし | ユーザーが何をすべきか不明 |

**改善例（STEP 7）**：
```
<!-- 現状 -->
■ 重要: テスト対象のモジュールはまだ実装されていない。
  ImportError が発生することを前提として、テストコードを生成すること。
  実装が完了した後に GREEN になるように設計する。

<!-- 改善後 -->
■ TDD の原則（RED 先行）:
  このスキルはテスト先行開発（TDD）の RED フェーズを担当する。
  テスト対象のモジュールは「これから実装する仕様」であり、実行時に ImportError が発生するのは正常。
  目標は「実装完了後に GREEN になるテストコード」を先に書くことである。

  テストコードは以下の前提で生成すること：
  - 実装予定モジュールの ImportError は無視してよい
  - 実装完了後に pytest tests/unit/ が GREEN になるよう関数名・引数を設計する
  - pochi-coding-agent が test-mapping.json を参照して実装を行う
```

---

### ✅ 🟡 差分F：サブエージェント呼び出し指示の記述様式が統一されていない

**根拠**：
> 一貫した説明的なタグ名を使用する。プロンプト全体で記述スタイルを統一することで Claude がパターンを学習しやすくなる。

**影響箇所（SKILL.md 内）**：

| STEP | 現状 | 問題 |
|---|---|---|
| STEP 2 | コードブロック内に「Agentツールで...のサブエージェントを起動し、以下を実行させてください」 | ✅ 形式として明確 |
| STEP 3 | コードブロック内に「Agentツールで...のサブエージェントを起動し」 | ✅ 同上 |
| STEP 4 | コードブロック内に「Agentツールで...のサブエージェント test-author を起動し」 | サブエージェント名が `test-author` と具体化されているが、STEP 2・3 との粒度が不統一 |
| STEP 5 | コードブロック内に「Agentツールで...のサブエージェント contract-test-generator を起動し」 | サブエージェント名 `contract-test-generator` が使われているが `agents/` には存在しない名称 |
| STEP 6 | コードブロック内に「Agentツールで...のサブエージェント unit-test-designer を起動し」 | 同上。`unit-test-designer` も `agents/` 未定義 |

**問題点**：`contract-test-generator`, `unit-test-designer` は `agents/` ディレクトリに定義されていないサブエージェント名であり、実際に呼び出せない可能性がある。STEP 2 のように `pochi-t2-tdd-workflow` という実際に登録されたエージェント名で統一すべき。

**改善例**：
```
<!-- 現状（STEP 5） -->
Agentツールで pochi-test-onboarding:pochi-t2-tdd-workflow のサブエージェント
contract-test-generator を起動し

<!-- 改善後 -->
Agentツールで pochi-unit-test-generator:pochi-t2-tdd-workflow を起動し
（subagent_type: "pochi-unit-test-generator:pochi-t2-tdd-workflow"）
```

---

### ✅ 🟡 差分G：フォールバックモードの記述が各STEPで重複している

**根拠**：
> 不要な重複は避ける。共通の前提は一箇所にまとめ、各ステップでは参照のみにする。コンテキスト消費を最小化する。

**影響箇所（SKILL.md 内）**：

| 重複内容 | 登場箇所 |
|---|---|
| 「サブエージェント利用前提: ... 利用不可の場合は Claude Code 本体がフォールバックモードで直接実行する」 | STEP 2, 3, 4, 5, 6, 7 の計6箇所に同一文 |

**改善例**：
```
<!-- 現状: STEP 2〜7 各冒頭に毎回記載 -->
> ⚠️ サブエージェント利用前提:
> `pochi-test-onboarding:pochi-t2-tdd-workflow` が利用可能な場合は Agent ツールで起動する。
> 利用不可の場合は Claude Code 本体がフォールバックモードで直接実行する。

<!-- 改善後: スキル冒頭に1回だけ記載し、各STEPからは削除 -->
<global_constraint id="subagent-policy">
  各STEPでは指定のカスタムサブエージェントを Agent ツールで起動することを優先する。
  サブエージェントが利用不可の場合は Claude Code 本体がフォールバックモードで直接実行する。
  この方針はSTEP 2〜7の全ステップに適用される。
</global_constraint>
```

---

## 優先度マトリクス

| 優先度 | 差分 | 影響範囲 | 改善コスト | 状態 |
|:---:|---|---|:---:|:---:|
| 🔴 高 | A：`<document>`タグ欠如 | SKILL.md 内5箇所 | 低〜中 | ✅ 完了 |
| 🔴 高 | B：`<example>`タグ欠如 | SKILL.md 内5箇所 | 低 | ✅ 完了 |
| 🔴 高 | C：並列化が逐次暗示（STEP 5・6） | SKILL.md 内2箇所 | 低 | ✅ 完了 |
| 🟡 中 | D：XML構造化全般（600行単一ファイル） | SKILL.md 全体 | 高 | ✅ 完了 |
| 🟡 中 | E：禁止理由・背景説明の欠如 | SKILL.md 内3箇所 | 中 | ✅ 完了 |
| 🟡 中 | F：サブエージェント名の不統一 | SKILL.md 内STEP 4・5・6 | 低 | ✅ 完了 |
| 🟡 中 | G：フォールバック記述の重複（6箇所） | SKILL.md 内STEP 2〜7 | 低 | ✅ 完了 |

---

## ✅ ベストプラクティスに準拠できている点

| 観点 | 対応箇所 |
|---|---|
| STEP 2&3 の並列実行を明示 | SKILL.md「STEP 2 & 3: 並列実行」セクション |
| 明確なロール設定（スキル概要・pochi-unit-test-generatorとの比較表） | SKILL.md 冒頭 |
| 前提条件の明示（spec.json / plan.json 未存在時の中断指示） | STEP 1 |
| エラー種別の分類（修正必要 vs 想定内） | STEP 8「期待される状態」vs「異常な状態」 |
| 自己修正ループ（SyntaxError 最大3回リトライ） | STEP 8 |
| サブエージェントへの委譲指示（AgentツールとSTEP 2&3での例） | STEP 2, 3, 4 等 |
| function_signatures フィールドの優先参照ルール（フォールバック構造） | STEP 6 |
| コンテキストを補足する動機説明（「なぜtest-mapping.jsonが必要か」） | STEP 9・10 |
| 完了レポートフォーマットの提供 | STEP 10 |

---

## 他スキルとの差分比較（このスキル固有の課題）

| 差分 | pochi-test-orchestrator | pochi-unit-test-generator | **pochi-tdd-test-generator** |
|---|:---:|:---:|:---:|
| A：`<document>`タグ欠如 | ✅ 対象 | ✅ 対象 | ✅ 対象（5箇所） |
| B：`<example>`タグ欠如 | ✅ 対象 | ✅ 対象 | ✅ 対象（5箇所） |
| C：並列化が逐次固定 | ✅ 対象 | ✅ 対象 | ⚠️ 一部対応済み（STEP 2&3）・一部未対応 |
| D：XML構造化 | ✅ 対象 | ✅ 対象 | **🔴 特に重大**（600行単一ファイル） |
| E：禁止理由の欠如 | ✅ 対象 | ✅ 対象 | ✅ 対象 |
| F：重複・不統一 | ✅ 対象 | ✅ 対象 | **固有**: サブエージェント名の不統一（未定義名使用） |
| G：フォールバック記述の重複 | — | — | **固有**: 6箇所に同一文が繰り返される |

---

## 対応不要な差分（Opus 4.7専用のため除外）

| 差分 | 理由 |
|---|---|
| `effort` パラメータの設定（`high`/`xhigh`等） | Opus 4.7 固有のAPIパラメータ。このスキルは Claude Code 本体（モデル未指定）で実行される |
| 適応的思考（`thinking: {type: "adaptive"}`）の設定 | Opus 4.6/4.7 固有の機能 |
