# pochi-test-orchestrator プロンプト改善 差分分析レポート

**分析日**: 2026-05-11  
**対象**: `/home/user/pochi-dp-developer-docs/skills/test/pochi-test-orchestrator` 配下の全プロンプトファイル  
**参照ベストプラクティス**: `claude-code-guide/official/prompting-best-practices.md`（全モデル共通の一般原則セクション）  
**適用モデル**: `claude-sonnet-4-6`（Opus専用の `effort` パラメータ関連差分は対象外）

---

## 対象ファイル一覧

| ファイル |
|---|
| `skills/test/pochi-test-orchestrator/skills/run/SKILL.md` |
| `skills/test/pochi-test-orchestrator/agents/test-case-specialist.md` |
| `skills/test/pochi-test-orchestrator/prompts/generate_test_cases_prompt.md` |
| `skills/test/pochi-test-orchestrator/prompts/subagent_call_template.md` |
| `skills/test/pochi-test-orchestrator/prompts/core/checkpoint_rules.md` |
| `skills/test/pochi-test-orchestrator/prompts/core/format_spec.md` |
| `skills/test/pochi-test-orchestrator/prompts/core/minimal_prompt.md` |
| `skills/test/pochi-test-orchestrator/prompts/core/quality_rules.md` |
| `skills/test/pochi-test-orchestrator/prompts/patterns/pattern_full.md` |
| `skills/test/pochi-test-orchestrator/prompts/patterns/pattern_partial.md` |
| `skills/test/pochi-test-orchestrator/prompts/reference_handling/file_list_template.md` |

---

## 対応必要な差分

### ✅ 🔴 差分A：複数ドキュメント参照時に `<document>` タグ構造化がない

**根拠（prompting-best-practices.md 一般原則）**：
> 複数のドキュメントを使用する場合、各ドキュメントを `<document>` タグでラップし、`<source>`、`<document_content>` サブタグを明確化する。

**影響ファイルと箇所**：

| ファイル | 箇所 | 現状 |
|---|---|---|
| `prompts/subagent_call_template.md` | ステップ4-2の呼び出しテンプレート「参照ファイルの場所」 | Markdownリストでパスのみ列挙 |
| `prompts/reference_handling/file_list_template.md` | `reference_files` の処理方法全体 | JSONパス配列の説明のみ、XMLタグ構造なし |
| `prompts/generate_test_cases_prompt.md` | 「前提」セクションの参照ファイルリスト | Markdownリスト列挙のみ |

**改善例**：
```xml
<!-- 現状 -->
- app_structure.md: {絶対パス}
- test-case-generation-guide.md: {絶対パス}

<!-- 改善後 -->
<documents>
  <document index="1">
    <source>{app_structure.mdの絶対パス}</source>
    <document_content>（ファイル参照機能で読み込む）</document_content>
  </document>
  <document index="2">
    <source>{test-case-generation-guide.mdの絶対パス}</source>
    <document_content>（ファイル参照機能で読み込む）</document_content>
  </document>
</documents>
```

---

### ✅ 🔴 差分B：フューショット例が `<example>` タグで囲まれていない

**根拠**：
> 例を `<example>` タグ（複数なら `<examples>` タグ）でラップすること。Claude が指示と区別できるようにする。3〜5つの例を含めることを推奨。

**影響ファイルと箇所**：

| ファイル | 箇所 | 現状 |
|---|---|---|
| `prompts/core/quality_rules.md` | 曖昧表現→具体値への置き換え例の表（10行） | Markdownテーブルのみ、`<example>`タグなし |
| `prompts/generate_test_cases_prompt.md` | 禁止カテゴリ表（禁止例↔代替表現） | Markdownテーブルのみ |
| `prompts/core/checkpoint_rules.md` | CP1「置き換え例」の表 | Markdownテーブルのみ |
| `prompts/patterns/pattern_full.md` | CP1「置き換え例」の表（pattern_full内に複製あり） | Markdownテーブルのみ |

**改善例**：
```xml
<!-- 現状 -->
| "適切にログインする" | "ユーザー名: 'test_user', パスワード: 'Pass1234' でログインする" |

<!-- 改善後 -->
<examples>
  <example>
    <bad>適切にログインする</bad>
    <good>ユーザー名: 'test_user', パスワード: 'Pass1234' でログインする</good>
  </example>
  <example>
    <bad>正しくデータが表示される</bad>
    <good>検索結果が15件表示され、先頭レコードのID='R001'である</good>
  </example>
</examples>
```

---

### ✅ 🔴 差分C：並列ツール呼び出しが逐次実行に固定されている

**根拠**：
> 独立したツール呼び出しはすべて並列で実行するよう明示的に指示する。順序立てて実行するのではなく、依存関係がない場合は同時に呼び出すことを優先する。

**影響ファイルと箇所**：

| ファイル | 箇所 | 現状 | 問題 |
|---|---|---|---|
| `prompts/subagent_call_template.md` | ステップ3「各絶対パスを**順番に**ファイル参照機能で開いて」 | 逐次処理を明示的に強制 | 独立したファイルでも並列化されない |

**改善例**：
```
<!-- 現状 -->
generation_context.jsonの`reference_files[]`配列内の**各絶対パスを順番に**ファイル参照機能で開いて内容を確認してください。

<!-- 改善後 -->
generation_context.jsonの`reference_files[]`配列内のファイルを参照してください。
ファイル間に依存関係がない場合は並列で一括読み込みしてください：
- 依存関係なし（例: app_structure.md と test-case-generation-guide.md）→ 並列で同時参照
- 依存関係あり（例: generation_context.json を読んでから参照パスを確定）→ 順序立てて参照
```

---

### ✅ 🟡 差分E：コンテキストの説明なしに禁止事項のみ列挙している箇所がある

**根拠**：
> 指示の背後にあるコンテキストや動機を提供することで、Claude がゴールをより深く理解できる。「何をしないか」よりも「何をすべきか・なぜか」を伝える肯定形が効果的。

**影響ファイルと箇所**：

| ファイル | 箇所 | 現状 | 問題 |
|---|---|---|---|
| `prompts/generate_test_cases_prompt.md` | 「❌ 期待結果・テスト手順に記載してはいけない実装内部情報」 | 禁止カテゴリ表のみで「なぜ禁止か」の説明なし | Claudeが文脈を理解せず機械的に適用してしまうリスク |
| `prompts/patterns/pattern_partial.md` | 「⚠️ PartialScenarioパターンのシナリオテスト禁止事項」 | 3項目すべて ❌ から始まる禁止列挙 | 同上 |
| `skills/run/SKILL.md` | `## Don't` 節全体 | ❌ マークの列挙のみ | 禁止理由が書かれていないため指示の重みが伝わりにくい |

**改善例**：
```
<!-- 現状 -->
❌ 期待結果・テスト手順に記載してはいけない実装内部情報
| セッションステートキー名 | st.session_state[...] |

<!-- 改善後 -->
テストケースはエンドユーザーがUIから観察できる内容のみを対象とします。
実装詳細を期待結果に含めると、内部実装が変わるたびにテストケースが壊れ、
保守コストが増大するためです。以下の情報は期待結果・テスト手順への記載を禁止します：

| 禁止カテゴリ | 禁止例 | 代わりに使う表現 |
...
```

---

### ✅ 🟡 差分F：`subagent_call_template.md` に `generate_test_cases_prompt.md` と重複する指示がある

**根拠**：
> 不要な重複は避ける。ファイル参照で済む内容を呼び出しテンプレートに貼り直さない。コンテキスト消費を最小化する。

**影響ファイルと箇所**：

| 重複内容 | 元定義ファイル | 重複箇所 |
|---|---|---|
| 「実装詳細」禁止カテゴリ一覧（7項目） | `prompts/generate_test_cases_prompt.md` | `prompts/subagent_call_template.md` ステップ4-2内に全文再掲 |

**改善例**：
```
<!-- 現状: subagent_call_template.md に7項目を全文再掲 -->
   - **「実装詳細」の具体的な判断基準**（以下はすべて期待結果・テスト手順への記載を禁止）:
     - セッションステートのキー名...
     - API戻り値の型...
     （省略）

<!-- 改善後: 参照のみに変更 -->
   - 実装詳細の判断基準は prompts_last_run.md（generate_test_cases_prompt.md）の
     「期待結果・テスト手順に記載してはいけない実装内部情報」セクションを参照すること
```

---

## 優先度マトリクス

| 優先度 | 差分 | 影響範囲 | 改善コスト |
|:---:|---|---|:---:|
| ✅ 🔴 高 | C：並列化が逐次固定 | `subagent_call_template.md` 1箇所 | 低 |
| ✅ 🔴 高 | A：`<document>`タグ欠如 | 3ファイル | 低〜中 |
| ✅ 🔴 高 | B：`<example>`タグ欠如 | 4ファイル | 低 |
| ✅ 🟡 中 | E：禁止理由の説明欠如 | 3ファイル | 中 |
| ✅ 🟡 中 | F：重複指示の削除 | `subagent_call_template.md` 1箇所 | 低 |

---

## 対応不要な差分（Opus 4.7専用のため除外）

| 差分 | 理由 |
|---|---|
| `effort` パラメータの設定（`high`/`xhigh`等） | Opus 4.7 固有のAPIパラメータ。`claude-sonnet-4-6` には存在しない |
| `effort` に関する思考深度のチューニング指示 | 同上 |
