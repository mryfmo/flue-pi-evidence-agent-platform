# Pochi worktree セットアップガイド

作成日: 2026-05-21
対象: Pochi開発者（チームメンバー全員）

> **このドキュメントの位置づけ**  
> worktreeを使った並列実装戦略の全体設計は `Pochi-AI駆動開発プロセス統合計画書.md`（§6-b）を参照。  
> このドキュメントは「初めてworktreeを使えるようにする」ための手順書に絞っている。

---

## 1. worktreeとは（30秒で理解）

1つのGitリポジトリから**複数の作業ディレクトリ**を持てる機能。`git clone` と違い、オブジェクトは共有するのでディスク消費が少ない。

```
<app-repo>/          ← main worktree（今のブランチ）
../.worktrees/
  └── task-1/        ← linked worktree（feature/task-1 ブランチ）
  └── task-2/        ← linked worktree（feature/task-2 ブランチ）
```

**Pochiでの使いどころ**: `pochi-coding-agent` のworktreeモードで、独立した機能を複数のサブエージェントに並列実装させる。

---

## 2. 前提確認

```bash
git --version        # 2.5以上であればworktree使用可能
git worktree --help  # ヘルプが表示されればOK
```

追加インストールは不要。Git本体の標準機能。

---

## 3. settings.json への許可設定（必須）

worktreeを使う**前に必ず実施**する。設定がないと並列実行中にpermission promptが頻発して自走が止まる（松本氏検証済み）。

対象のアプリリポジトリの `.claude/settings.json`（なければ `~/.claude/settings.json`）の `permissions.allow` に以下を追加する。

```json
{
  "permissions": {
    "allow": [
      "Bash(git rev-parse:*)",
      "Bash(git branch:*)",
      "Bash(git worktree add:*)",
      "Bash(git worktree remove:*)",
      "Bash(git worktree list:*)",
      "Bash(git checkout:*)",
      "Bash(git merge:*)",
      "Bash(cd:*)",
      "Write(.worktrees/**)",
      "Read(.worktrees/**)"
    ]
  }
}
```

> **`.worktrees/` の位置について**  
> worktreeディレクトリはリポジトリ外（`../` の隣）に置く設計のため、`Write(.worktrees/**)` はリポジトリルート起点の相対パスではなくホームディレクトリ起点で解釈される場合がある。  
> permission promptが出続ける場合は `~/.claude/settings.json`（グローバル設定）に追加する。

---

## 4. 手動での動作確認（1サイクル）

初めて使う前に、手動で1サイクル動かして環境を確認する。

### Step 1. リポジトリに移動

```bash
cd /path/to/your-pochi-app
```

### Step 2. worktreeを作成

```bash
REPO_ROOT=$(git rev-parse --show-toplevel)
WORKTREE_BASE="${REPO_ROOT}/../.worktrees/$(basename $REPO_ROOT)"
BASE_BRANCH=$(git branch --show-current)
mkdir -p "$WORKTREE_BASE"

git worktree add -b feature/test-task "$WORKTREE_BASE/test-task" "$BASE_BRANCH"
```

### Step 3. 一覧確認

```bash
git worktree list
```

以下のように表示されればOK。

```
/path/to/your-pochi-app           abc1234 [main]
/path/to/.worktrees/.../test-task def5678 [feature/test-task]
```

### Step 4. worktree内で作業・コミット

```bash
cd "$WORKTREE_BASE/test-task"
# 何か変更してコミット
git add <file>
git commit -m "test: worktree動作確認"
```

> **注意**: `git add . && git commit` のように `&&` で連結すると permission promptで拒否される場合がある。  
> `git add` と `git commit` は**個別のコマンドとして実行**すること（Claude Codeに実行させる場合も同様）。

### Step 5. メインブランチにマージ

```bash
cd "$REPO_ROOT"
git merge feature/test-task --no-edit
```

### Step 6. クリーンアップ

```bash
git worktree remove "$WORKTREE_BASE/test-task"
git branch -d feature/test-task
```

> **手動削除は禁止**: `rm -rf` でディレクトリを消すと管理情報が残る。必ず `git worktree remove` を使う。  
> 手で消してしまった場合は `git worktree prune` で管理情報を掃除する。

---

## 5. 確認チェックリスト

手動1サイクルが完了したら以下を確認する。

- [ ] `git worktree add` が正常に完了した
- [ ] worktree内でコミットができた
- [ ] `git merge` でマージできた（コンフリクトなし）
- [ ] `git worktree remove` でクリーンアップできた
- [ ] `git worktree list` に残存worktreeがない
- [ ] permission promptが出なかった（出た場合は §3 の設定を見直す）

---

## 6. よくあるトラブルと対処

| 症状 | 原因 | 対処 |
|---|---|---|
| `permission denied` が頻発する | settings.jsonの許可設定が不足 | §3 の設定を追加する |
| `fatal: '<branch>' is already checked out` | 同じブランチを複数worktreeでcheckoutしようとした | 新規ブランチ（`-b`オプション）で作成する |
| `git worktree list` に不明なworktreeが残る | 手動でディレクトリを消した | `git worktree prune` を実行する |
| `&&` 連結コマンドがpermission promptで止まる | Claude Codeのコマンド単位の許可制御 | `git add` と `git commit` を個別コマンドに分ける |
| `.git` がディレクトリでなくファイルになっている | linked worktreeの正常な状態 | 異常ではない。ツールが `.git/` を直接参照する場合は注意 |

---

## 7. pochi-coding-agent worktreeモードへの接続

手動確認が完了したら、Claude Codeスキル経由での並列実装が可能になる。

```
/pochi-coding-agent-worktree を起動
```

スキルの内部実装（フェーズ0〜3の自動化フロー）については `Pochi-AI駆動開発プロセス統合計画書.md`（§6-b）を参照。

---

## 8. 関連ドキュメント

| ドキュメント | 内容 |
|---|---|
| `Pochi-AI駆動開発プロセス統合計画書.md` §6-b | worktree並列実装戦略の全体設計・フェーズ0〜3の詳細フロー |
| `worktree/pochi-worktree-strategy.md` | 戦略の原典。Pochi固有の注意点（session_state・Snowflake接続）を含む |
| `worktree/RM-memo.md` | 松本氏による90ブランチ並列実装の検証記録 |
| `worktree/公式.md` | git worktreeの公式仕様まとめ |
| `worktree/clean-arch-refactoring.md` | Clean Architecture並列移行のメインスキル実装仕様 |
