# DESIGN.md 検証計画書（対象: d-pay-merchant）

参照元: `/home/user/pochi-dp-developer-docs/DESIGN.md` v1.0.0  
対象アプリ: `pochi-d-pay-merchant-visualizer-repository/app/`

---

## 目的

`DESIGN.md` v1.0.0 が整備されたことを受け、既存アプリ d-pay-merchant の現状の準拠状況を検証する。
CoDDおよびPochi-AI駆動開発プロセス統合計画書「施策1: DESIGN.md の導入」のPoC検証として、
Before の基準値を記録し、改修優先度の判断材料とすることを目的とする。

---

## 評価スコアリング

| 記号 | 意味 |
|------|------|
| ✅ | DESIGN.md のルールを満たしている |
| ⚠️ | 部分的に満たしている（改善の余地あり） |
| ❌ | 満たしていない（対応要検討） |
| N/A | 本アプリの構成では該当しない |

---

## 検証セクション1: サイドバー構成（原則①）

**DESIGN.md のルール**: `st.navigation` を必ず使う。構成は「機能ページ → ユーザーガイド3ページ」の順で固定。サイドバーに操作ウィジェットを置かない。

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 1-1 | `st.navigation` を使用しているか | `app/main.py` の実装を確認 | `st.navigation(pages)` が使われている | | |
| 1-2 | サイドバー構成の順序が正しいか | `app/main.py` の `pages` 辞書キー順を確認 | 機能ページ → `"ユーザガイド"` セクションの順 | | |
| 1-3 | ユーザーガイドが3ページ揃っているか | `app/main.py` の `pages["ユーザガイド"]` を確認 | 「このアプリについて」「データソースについて」「使い方がわからないときは」の3ページ | | |
| 1-4 | サイドバーに操作ウィジェットが置かれていないか | `grep -rn "st\.sidebar" app/app_pages/` で確認 | `st.sidebar.selectbox` 等の操作ウィジェットが存在しない | | |
| 1-5 | DESIGN.md 規定外のセクションが追加されていないか | `app/main.py` の全セクション名を確認 | 「開発者向けツール」等の規定外セクション有無を記録 | | |

```bash
# 確認コマンド
grep -n "st.navigation\|pages\[" app/main.py
grep -rn "st\.sidebar\." app/app_pages/ 2>/dev/null
```

---

## 検証セクション2: ユーザーガイドページ（原則②）

**DESIGN.md のルール**: 各ガイドページに規定の記載事項が揃っていること。アプリ全体の説明は機能ページでなくこのページに集約する。

### 2-1. 「このアプリについて」ページ（`app/app_pages/about_this_app.py`）

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 2-1-1 | アップデート情報セクションがあるか | `about_this_app.py` の `index()` 関数の構成確認 | アップデート情報・ユーザー向け予告が記載されている | | |
| 2-1-2 | 想定ユースケースが記載されているか | `sec1_usecase()` の内容確認 | 利用目的・入力・出力の使い方が具体的に記載 | | |
| 2-1-3 | 業務適用実績のあるユースケースが記載されているか | `sec2_actual()` の内容確認 | 部署・サービス・実務での利用実績が記載（またはコメントアウトで意図的に省略） | | |
| 2-1-4 | 注意事項が記載されているか | `sec3_cautions()` or 相当関数の確認 | データや利用の前提条件が記載されている | | |
| 2-1-5 | アプリ説明情報が機能ページに重複していないか | `visualization_tool.py` にアプリ全体説明がないか確認 | アプリ概要・背景説明が `about_this_app.py` に集約されている | | |

```bash
# 確認コマンド
grep -n "def sec\|def index" app/app_pages/about_this_app.py
grep -n "アップデート\|update_history\|更新履歴" app/app_pages/about_this_app.py
```

### 2-2. 「データソースについて」ページ（`app/app_pages/data_sources.py`）

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 2-2-1 | データソース（テーブル名）が記載されているか | `sec1_data_src()` の内容確認 | 使用している全データセット名が記載されている | | |
| 2-2-2 | 処理ロジックが記載されているか | `sec_2_process_logic()` の呼び出し有無 | 数値の定義・抽出条件等が記載（またはコメントアウトで意図的に省略） | | |
| 2-2-3 | 試験項目が記載されているか | `sec_3_testcase()` の内容確認 | 精度検証の条件・結果が記載されている | | |
| 2-2-4 | クレジット消費目安が記載されているか | `sec_4_costs()` の内容確認 | 1回あたりの典型的な消費クレジット目安が記載されている | | |

```bash
# 確認コマンド
grep -n "def sec\|def index" app/app_pages/data_sources.py
```

### 2-3. 「使い方がわからないときは」ページ（`app/app_pages/how_to_use.py`）

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 2-3-1 | 各機能の利用手順が記載されているか | `how_to_use.py` の内容確認 | 主要機能（住所検索・キーワード検索・地図検索等）の操作手順が記載 | | |

---

## 検証セクション3: 機能ページ冒頭の構成（原則③）

**DESIGN.md のルール**: 背景色は白（`surface: #FFFFFF`）。冒頭の順序は ① st.title → ② st.header → ③ st.markdown → ④ st.error（障害時のみ）→ ⑤ st.warning（注意事項のみ） で固定。

対象ファイル: `app/app_pages/visualization_tool.py`（`main()` 関数）

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 3-1 | `st.title` があり先頭にアイコンが1つついているか | `main()` の冒頭 `st.title(...)` を確認 | `st.title("🔍...")` のようにアイコン1つで始まる | | |
| 3-2 | アプリタイトルがギャラリー表示名と一致しているか | `main.py` の `title=` 引数と `st.title` の文字列を比較 | 両者が一致している | | |
| 3-3 | 冒頭の表示順序が規定通りか | `main()` の実装を上から確認 | title → (header) → markdown → error → warning の順 | | |
| 3-4 | 障害情報以外の `st.error` が冒頭に置かれていないか | `main()` 冒頭の `st.error` の有無・内容確認 | 障害情報のみ（ある場合）が冒頭に表示される | | |
| 3-5 | 注意事項以外の `st.warning` が冒頭に置かれていないか | `main()` 冒頭の `st.warning` の内容確認 | 重要なお知らせ等の注意事項のみ表示（優先度「中〜高」のもの） | | |

```bash
# 確認コマンド
grep -n "def main\|st\.title\|st\.header\|st\.markdown\|st\.error\|st\.warning" app/app_pages/visualization_tool.py | head -30
```

---

## 検証セクション4: 上→下の操作導線（原則④）

**DESIGN.md のルール**: 全ページで上→下の操作フロー。アウトプット（グラフ等）は左右分割可。操作ウィジェットの並列配置は原則禁止。

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 4-1 | 条件入力が先で結果表示が後になっているか | `visualization_tool.py` の処理フロー確認 | 入力フォーム → 検索ボタン → 結果表示の順 | | |
| 4-2 | 操作ウィジェットが `st.columns` で横並びになっていないか | `grep -n "st\.columns" app/app_pages/visualization_tool.py` | 操作ウィジェット（ボタン・チェックボックス等）の横並び配置がないか確認 | | |
| 4-3 | グラフ・テーブル等のアウトプットは左右分割が許容されているか | 結果表示部分の `st.columns` 使用状況確認 | アウトプット表示の `st.columns` は許容（違反ではない） | | |

```bash
# 確認コマンド
grep -n "st\.columns" app/app_pages/visualization_tool.py | head -20
```

---

## 検証セクション5: ステップ区切り（原則⑤）

**DESIGN.md のルール**: ステップタイトルは `st.subheader(..., divider="orange")` で統一。ステップタイトルはユーザーを主語にする。

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 5-1 | ステップ区切りが `divider="orange"` で統一されているか | `grep -rn 'divider' app/app_pages/` | 全ての `st.subheader` が `divider="orange"` を使用（`divider=True` は不適合） | | |
| 5-2 | `st.header` に `divider=True` が使われていないか | `grep -rn 'divider=True' app/app_pages/` | `divider=True`（青色デフォルト）でなく `divider="orange"` に統一されているか | | |
| 5-3 | ステップタイトルがユーザーを主語にしているか | 各 `st.subheader` の文字列を目視確認 | 「〜する」「〜を選択する」等のユーザー視点で記述されているか（「抽出実行」等の名詞形は要修正） | | |

```bash
# 確認コマンド
grep -rn "divider" app/app_pages/ 2>/dev/null | grep -v "__pycache__"
grep -rn "divider=True" app/app_pages/ 2>/dev/null | grep -v "__pycache__"
grep -rn "divider=\"orange\"" app/app_pages/ 2>/dev/null | grep -v "__pycache__"
```

---

## 検証セクション6: 情報優先度制御（原則⑥）

**DESIGN.md のルール**: 高優先度（必須情報）はデフォルト表示。中優先度はexpander/help=。低優先度（アップデート情報等）は機能ページに置かない。`st.expander` のタイトルには内容と対象ユーザーを記載。`st.caption` は補足に使用禁止（`help=` または `st.expander` を使う）。

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 6-1 | `st.caption` が補足説明に使われていないか | `grep -rn "st\.caption" app/app_pages/` | `app_pages/` 配下で `st.caption` が使われていない（`app_designer.py` は開発者向けツールのため除外判断） | | |
| 6-2 | `st.expander` のタイトルに内容説明が含まれているか | 各 `st.expander(...)` のタイトル文字列を確認 | 内容と（必要に応じて）想定ユーザーが記載されている | | |
| 6-3 | アップデート情報等が機能ページに置かれていないか | `visualization_tool.py` の `st.info` / `st.markdown` の内容確認 | 更新履歴・アップデート情報が機能ページに含まれていない | | |
| 6-4 | オプション機能が `st.expander` で適切に隠されているか | 詳細設定等の `st.expander` 使用状況確認 | 詳細設定（性別・年代等）が expander で隠されている | | |

```bash
# 確認コマンド
grep -rn "st\.caption" app/app_pages/ 2>/dev/null | grep -v "__pycache__"
grep -rn "st\.expander" app/app_pages/visualization_tool.py | head -10
```

---

## 検証セクション7: 処理フィードバック（原則⑦）

**DESIGN.md のルール**: 時間のかかる処理には必ず `st.spinner` を使う。完了時は `st.success`、エラー時は `st.error` でフィードバック。

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 7-1 | 検索処理に `st.spinner` が使われているか | `grep -n "st\.spinner" app/app_pages/visualization_tool.py` | メイン検索処理等の時間のかかる処理に `with st.spinner(...)` が実装されている | | |
| 7-2 | 完了時に `st.success` が使われているか | `grep -n "st\.success" app/app_pages/visualization_tool.py` | 処理完了通知が `st.success` で表示されている | | |
| 7-3 | エラー時に `st.error` が使われているか | `grep -n "st\.error" app/app_pages/visualization_tool.py` | エラー（0件・例外等）が `st.error` で表示されている | | |
| 7-4 | フィードバックなしで処理が完了する箇所がないか | 主要な処理フローを目視確認 | 時間のかかる処理でスピナーなしに放置されている箇所がない | | |

```bash
# 確認コマンド
grep -n "st\.spinner\|st\.success\|st\.error" app/app_pages/visualization_tool.py
```

---

## 検証セクション8: カラーパレット・アクセシビリティ

**DESIGN.md のルール**: デザイントークン定義の9色のみ使用。`primary #FF6E00` をテキスト色として使わない。`.streamlit/config.toml` の `primaryColor` を `#FF6E00` に合わせる。WCAG 2.1 AA 基準を満たす組み合わせのみ使用。

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 8-1 | `.streamlit/config.toml` に `primaryColor = "#FF6E00"` が設定されているか | `cat app/.streamlit/config.toml` | `primaryColor = "#FF6E00"` または `primaryColor = "#ff6e00"` が記載されている | | |
| 8-2 | カスタム CSS で独自カラーコードが使われていないか | `grep -rn "color:\|background-color:" app/static/` | デザイントークン外の独自カラーコードが CSS に存在しないか | | |
| 8-3 | `#FF6E00` をテキスト色（`color: #FF6E00`）として使っていないか | CSS / Markdown の `color:` 属性確認 | `primary` カラーがテキスト色として直接適用されていない | | |

```bash
# 確認コマンド
cat app/.streamlit/config.toml
grep -rn "primaryColor\|#FF6E00\|#ff6e00" app/.streamlit/ 2>/dev/null
grep -rn "color:" app/static/ 2>/dev/null | grep -v "__pycache__"
```

---

## 検証セクション9: フラットデザイン（深さ・エレベーション）

**DESIGN.md のルール**: `box-shadow` / `drop-shadow` 禁止。グラデーション禁止。`border-radius: 0px`（Streamlit デフォルト設定を除く）。

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 9-1 | カスタム CSS に `box-shadow` / `drop-shadow` がないか | `grep -rn "box-shadow\|drop-shadow" app/static/` | 発見されない | | |
| 9-2 | カスタム CSS に `gradient` がないか | `grep -rn "gradient" app/static/` | 発見されない | | |
| 9-3 | カスタム CSS に非デフォルトの `border-radius` がないか | `grep -rn "border-radius" app/static/` | フレームワーク由来以外の `border-radius` 指定がない | | |

```bash
# 確認コマンド
grep -rn "box-shadow\|drop-shadow\|gradient\|border-radius" app/static/ 2>/dev/null | grep -v "__pycache__"
```

---

## 検証セクション10: Do's and Don'ts 遵守状況

**DESIGN.md のルール**: 主要な禁止事項を横断的に確認する。

| # | チェック項目 | 確認方法 | 判定基準 | 評価 | メモ |
|---|------------|---------|---------|------|------|
| 10-1 | サイドバーに操作ウィジェットが置かれていないか（再確認） | `grep -rn "st\.sidebar\." app/app_pages/` | 発見されない | | |
| 10-2 | 機能ページに優先度「低」の情報が置かれていないか（再確認） | `visualization_tool.py` の情報種別確認 | アップデート情報・更新履歴が機能ページに混入していない | | |
| 10-3 | `st.caption` が補足に使われていないか（再確認） | `grep -rn "st\.caption" app/` | `visualization_tool.py` 等のメインページで使用されていない | | |
| 10-4 | 上→下以外の導線（操作ウィジェットの横並び）がないか（再確認） | `grep -n "st\.columns" app/app_pages/visualization_tool.py` | 入力ウィジェットの `st.columns` が必要最低限か確認 | | |
| 10-5 | `primary #FF6E00` がテキスト色として使用されていないか（再確認） | CSS / Python コードの `color:` 適用箇所 | テキストへの直接適用がない | | |

---

## 集計サマリー

| セクション | ✅ | ⚠️ | ❌ | N/A | 合計 |
|-----------|----|----|----|----|------|
| 1. サイドバー構成（原則①） | | | | | 5件 |
| 2-1. ユーザーガイド①「このアプリについて」 | | | | | 5件 |
| 2-2. ユーザーガイド②「データソースについて」 | | | | | 4件 |
| 2-3. ユーザーガイド③「使い方がわからないときは」 | | | | | 1件 |
| 3. 機能ページ冒頭の構成（原則③） | | | | | 5件 |
| 4. 上→下の操作導線（原則④） | | | | | 3件 |
| 5. ステップ区切り（原則⑤） | | | | | 3件 |
| 6. 情報優先度制御（原則⑥） | | | | | 4件 |
| 7. 処理フィードバック（原則⑦） | | | | | 4件 |
| 8. カラーパレット・アクセシビリティ | | | | | 3件 |
| 9. フラットデザイン | | | | | 3件 |
| 10. Do's and Don'ts | | | | | 5件 |
| **合計** | | | | | **45件** |

---

## 総合判定

| レベル | 条件 | 対応 |
|--------|------|------|
| **A（適合）** | ❌ が 0件 | 維持・定期レビューのみ |
| **B（概ね適合）** | ❌ が 1〜4件・いずれも低優先度 | 中期的に改善 |
| **C（改善優先）** | ❌ が 5件以上・または高優先度項目に ❌ | 近期に対応計画を策定 |

今回の判定: **（　）**

---

## ❌ 未達項目一覧（要対応）

| # | セクション | チェック項目 | 改善案 | 優先度 |
|---|-----------|------------|--------|--------|
| | | | | |

---

## ⚠️ 改善余地あり項目一覧

| # | セクション | チェック項目 | 改善案 | 優先度 |
|---|-----------|------------|--------|--------|
| | | | | |

---

## 事前調査で把握済みの課題（検証前の仮説）

実施前の静的コード調査で以下の懸念点を確認済み。検証時に優先的に確認すること。

| 懸念箇所 | ファイル・行 | 内容 |
|---------|------------|------|
| `divider=True` の使用 | `how_to_use.py` 各 `st.subheader` | `divider="orange"` でなく `divider=True`（デフォルト青）を使用。原則⑤違反の可能性 |
| `divider=True` の使用 | `data_sources.py:439` | `SEC_3_TITLE` の `st.subheader` が `divider=True` |
| `divider=True` の使用 | `visualization_tool.py:984,995,1012,1016` | `st.header` に `divider=True` を使用 |
| DESIGN.md 規定外セクション | `main.py` | 「開発者向けツール」セクションが DESIGN.md の規定構成に記載なし |
| `primaryColor` 未設定 | `.streamlit/config.toml` | `primaryColor` の記載なし。Streamlit デフォルト色が適用される可能性 |
| `st.caption` の使用 | `app_pages/app_designer.py:23,135,519` | 開発者向けツールページで `st.caption` を使用 |
| アップデート情報の欠如 | `about_this_app.py` | 「アップデート情報（ユーザー向け通知・予告）」セクションが存在しない |

---

## 検証メタ情報

| 項目 | 内容 |
|------|------|
| 検証日 | |
| 検証者 | |
| 参照ドキュメント | `DESIGN.md` v1.0.0（`/home/user/pochi-dp-developer-docs/DESIGN.md`） |
| 対象アプリ | d-pay-merchant（`pochi-d-pay-merchant-visualizer-repository`） |
| 対象ブランチ | |
| 次回レビュー予定 | |
