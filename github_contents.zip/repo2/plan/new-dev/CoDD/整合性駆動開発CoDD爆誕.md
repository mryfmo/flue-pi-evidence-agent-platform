# Prompt→Context→Harness、全部やった。要件だけ渡す、変わっても壊れない。整合性駆動開発CoDD爆誕

**公開日:** 2026/03/29  
**更新日:** 2026/04/01  
**著者:** おしお (shio_shoppaize)

> **! 2026/4/1 更新** — v1.2.0リリース。`codd assemble` のプロンプト改善（`package.json`等のプロジェクト設定ファイルを明示的に生成）、Claude Code Skill `codd-assemble` 追加。グリーンフィールド・パイプラインの全自動化を完了。

> **! 2026/3/29 19:00 更新** — 「5分でCoDDを体験する」のセクションを大幅改善。要件定義をプレーンテキストで渡すだけ（`codd init --requirements spec.md`）のフローに変更。Frontmatterやwave_configも完全自動生成されるようになった。

---

いつもと違ってポエム・エッセイである。

この2年でAI開発の手法は3回変わった。プロンプトエンジニアリング、コンテキストエンジニアリング、そしてハーネスエンジニアリング。

私は将軍として10人のAI部下を指揮し、そのすべてをリアルタイムで経験してきた。

3つすべてをやった上で、まだ誰も解決していない問題にぶつかった。それを解決するツールを作った。`pip install codd-dev` としてリリースした。

結果として、クライアントのLMSプロジェクトで、要件と制約だけを渡し、18の設計書、全コード、全テストをAIに生成させた。途中で設計判断が変わっても壊れなかった。今日はその話をする。

---

## これまでのあらすじ（3行で）

- 前回の記事で「ハーネスエンジニアリングはGit Workflowのローカル再実装だ」と書いた。
- さらにその前に「マルチエージェントの本質はコンテキスト設計である」と書いた。
- 今回はその先の話をする。

---

## 1. プロンプト→コンテキスト→ハーネス。進化の整理

まず、この2年間のAI開発方法論の変遷を整理する。

### プロンプトエンジニアリング（2023〜2024）

「AIにどう聞けば正しく答えるか」の時代。

1つのプロンプトにすべてを詰め込む。Few-shot, Chain-of-Thought, System Prompt最適化。やっていることは「1回の入力」の最適化。状態（State）がない。前の会話は忘れる。毎回ゼロから。

### コンテキストエンジニアリング（2024〜2025）

「AIにどんな文脈を渡せば正しく動くか」の時代。

`CLAUDE.md`、`AGENTS.md`、instructions。永続的な文脈をファイルに書いて、エージェントが毎回読む。プロンプトが「1回の入力」だったのに対して、コンテキストは「常にそこにある背景知識」になった。

Anthropicが「Effective Context Engineering for AI Agents」で「エージェントの根本課題はコンテキストの管理だ」と書いた通り、コンテキストの設計が品質の大半を決める。同社のBuilding Effective Agents（2024年12月）でも、最も成功しているAIエージェントの実装は単純でcomposableなパターンの組み合わせだと指摘されている。

### ハーネスエンジニアリング（2025〜2026）

「AIをどういうルールと制約で動かすか」の時代。

Mitchell Hashimotoが2026年2月に命名。Anthropicがhooksとskillsを公式化し、OpenAIがCodexにbackground automationsを入れ、Googleがagent skillsを発表した。

Hookで品質ゲートを設け、Skillで手順を標準化し、`CLAUDE.md`でルールを宣言する。前回の記事で書いた通り、やっていることの本質はGit Workflowのローカル再実装だが、「AIにもプロセス管理が必要」という認識が一般化した意義は大きい。

---

## 2. コンテキストエンジニアリングの限界

ここまでの3つは全て「AIをどう動かすか」の話だ。

- プロンプト = AIへの入力をどう作るか
- コンテキスト = AIが参照する背景知識をどう管理するか
- ハーネス = AIの実行をどうガードレールで囲むか

コンテキストエンジニアリングの話をもう少し掘り下げる。

`CLAUDE.md` は「全部入り背景知識」だ。プロジェクトの方針、ルール、制約、全部1ファイルに書く。小さいプロジェクトなら十分だ。

しかし、プロジェクトが大きくなったら？

コンテキストウィンドウには限界がある。`CLAUDE.md` に全部詰め込んでも、要件定義から基本設計、詳細設計、API仕様、DB設計、テスト戦略まで全部入れたら溢れる。そして溢れた情報はAIには見えない。見えない情報は存在しないのと同じだ。

この問題に対するアーキテクチャ的回答は、構造化された設計書群だ。

- 知識を構造化された文書群に分割する — 1ファイルに全部詰めるのではない
- フロントマターが「何を読めばいいか」を教える — 依存グラフが関連文書を特定する
- 必要な時に必要な文脈だけ渡す — 影響を受ける設計書だけ読めばいい

```
Prompt Engineering   → 1回のプロンプトに全部詰める
Context Engineering  → 1つのファイルに永続的に全部書く（限界あり）
???                  → 構造化された文書群 + 依存グラフで必要なものだけ渡す
```

`CLAUDE.md` が「全部入り背景知識」なら、構造化された設計書群は**「必要な時に必要な文脈だけ渡す仕組み」**だ。この「???」を埋めるのがCoDDだ。

---

## 3. で、もうひとつ誰も解いていない問題がある

話を戻す。全部、AIが今から何かを作る瞬間の話をしている。

では、作っている途中で何かが変わったら？

要件変更だけの話ではない。開発の過程で変わるものは山ほどある。

- 要件が追加・変更された → どの設計書が影響を受ける？
- API設計を見直した → 呼び出し側のコードとテストは？
- DB設計を変えた → マイグレーションは？RLSポリシーは？
- 技術選定が変わった → テスト戦略もインフラ設計も全部変わる
- 新しい制約が見つかった → どこまで波及する？

AIが設計書を書ける。コードも生成できる。テストも作れる。もうそれは分かった。

問題は、開発の途中で何かが変わった時に、どこまで壊れるか誰にも分からないことだ。

ハーネスエンジニアリングの3層を前回整理した。

| レイヤー | やること | 難易度 |
|---|---|---|
| セットアップ | hookやCLAUDE.mdの設定 | 簡単 |
| ワークフロー移植 | Git Workflowのローカル再実装 | 中 |
| 未踏領域 | 変更時に整合性をどう保つか | 難 |

世の中の記事の9割はレイヤー1〜2の話をしている。レイヤー3に踏み込んでいるプレイヤーは少ない。

---

## 4. 他のプレイヤーの取り組み

「仕様駆動」のOSSは急速に増えている。

**Spec Kit**（GitHub公式、83k+ stars）。仕様を先に書いてからコードを生成するアプローチ。Specify→Plan→Tasks→Implementの4フェーズ。拡張群にはV-Model、Verify、Syncがある。GitHub Blogで「仕様がコードに仕える」のではなく「コードが仕様に仕える」と宣言している。

**OpenSpec**（35k+ stars）。artifact dependency graphと/opsx:verifyを公開。Spec Kitを"heavyweight"と比較し、軽量路線を打ち出している。

**Google Conductor**。persistent Markdownでplan-before-buildを実現し、Automated Reviewsまで追加した。

**cc-spec-driven**。Claude Codeプラグインとして双方向依存追跡とquick impact analysisを前面に出している。

全て「仕様を先に書け」という点では一致している。そして全て、ひとつの問題を解いていない。

**仕様が変わった後の整合性をどう保つか。**

Spec KitもOpenSpecも「最初に仕様を書く方法」は教えてくれる。しかし要件変更が入った時に、どの設計書が影響を受けて、どのテストが壊れて、どのAPIを直すべきかは教えてくれない。

---

## 5. CoDD — Coherence-Driven Development（整合性駆動開発）の誕生

AIスロップ（AI slop：一見動くが品質が低く隠れた欠陥を抱えるコード）が問題視される中、AIのコード出力を設計書で制御する仕様駆動開発（SDD）のアプローチが登場した。しかし、途中で設計の判断が変わると、設計書群全体（コンテキスト）の整合性が壊れてしまうという課題があった。

誰も解かないなら、自分で解く。

**整合性駆動開発（CoDD: Coherence-Driven Development）** — 設計の整合性を保つことで開発を駆動する方法論だ。「要件だけ渡す、変わっても壊れない。」この未解決問題を解消するために提唱した。

```
Harness (CLAUDE.md, Hooks, Skills)  ← ルール、ガードレール、フロー
  └─ CoDD (方法論)                  ← ハーネスのフローに従って動く
       └─ 設計書 (docs/*.md)        ← CoDDが生成・維持する成果物
```

CoDDはハーネスエンジニアリングの一分野だ。前回の記事で整理した3層でいえば、レイヤー3「未踏領域の設計」に位置する。セットアップでもワークフロー移植でもない。変更時の整合性維持という、Git Workflowに対応するものがない問題を解く。

方法論としてはどのハーネスでも使える。CLIツール（`pip install codd-dev`）なので、Claude Code、GitHub Copilot、Cursor、何でも動く。ただしClaude Codeとは特に相性がいい。CoDDのコマンドをClaude CodeのSkillとして登録すれば、`/codd-scan` や `/codd-impact` がエージェントのワークフローに自然に組み込まれる。Hookと組み合わせれば、コミット前に自動で整合性チェックを走らせることもできる。

アーティファクト間の変更の波及（cross-artifact change impact analysis）を管理するClaude Codeプラグインとして `codd-dev` をリリースした。

やることは3つ:

1. **依存グラフの構築** — 設計書同士の依存関係をフロントマターで宣言し、グラフ化する
2. **変更影響分析** — どこかが変わったら、依存グラフを辿って影響範囲を特定する
3. **整合性の維持** — 影響を受ける設計書・コード・テストをAIが修正する

```bash
# 依存グラフを構築
codd scan

# 変更の影響範囲を特定
codd impact --diff HEAD~1
```

たったこれだけで「何が壊れたか」が分かる。

---

## 6. バイブコーディング vs ハーネス vs CoDD

ここまで読んで「結局どう違うの」と思っている人のために、評価軸で並べる。ちなみに「バイブコーディング」はAndrej Karpathyが2025年2月のツイートで命名した概念だ。「see things, say things, run things, and vibe」。つまり、コードを理解せずにAIに任せて走らせる開発スタイルを指す。

| 評価軸 | バイブコーディング | ハーネス（既存） | CoDD |
|---|---|---|---|
| 初速 | ◎ 最速。「作って」で動く | ○ セットアップ後は速い | △ 設計書先行。初速は遅い |
| 変更耐性 | ✕ 全部作り直し | △ ガードレールはあるが影響範囲は人間が追う | ◎ 依存グラフで自動特定 |
| 設計の追跡可能性 | ✕ なぜこうなったか誰も知らない | △ CLAUDE.mdにルールはある | ◎ フロントマターで依存宣言 |
| セットアップコスト | ◎ ゼロ | △ hook, CLAUDE.md, MCP設定 | △ init + 設計書のフロントマター |
| 大規模プロジェクト | ✕ 破綻する | ○ ルールで制御可能 | ◎ 依存グラフがスケールする |
| AI暴走リスク | ✕ 間違ったものを完璧に作る | ○ ガードレールで抑制 | ◎ 設計書から逸脱すると検知 |
| 向いている場面 | プロトタイプ、使い捨て | 中規模の継続開発 | 要件変更が頻繁な実案件 |

バイブコーディングが悪いわけではない。プロトタイプには最適だ。既存のハーネスエンジニアリングも、安定した要件の開発には十分だ。

問題は、開発の途中で何かが変わり続ける現実のプロジェクトで何が起きるかだ。要件追加、API設計の見直し、DB変更、技術選定の変更。全部「変更」だ。バイブコーディングは「作り直せ」になる。既存のハーネスは「人間が影響範囲を追え」になる。CoDDは「グラフを辿れば分かる」になる。

初速を取るか、耐久性を取るか。両方ほしいなら、プロトタイプはバイブで、本開発はCoDDで。これが私の結論だ。

---

## 7. CoDDの基本思想

### 導出原則（Derive, Don't Configure）

CoDDの核心は**「上流を見れば下流は自明」**という原則だ。

`system_design.md` に「Next.js + Supabase」と書いてあるなら、テスト戦略はvitest + Playwright。設定ファイルに書く必要はない。アーキテクチャが決まれば、テスト手法は導出される。

```
system_design.md に "Next.js + Supabase"
→ テスト戦略: vitest（単体）+ Playwright（E2E）。設定不要。

system_design.md に "FastAPI + Python"
→ テスト戦略: pytest + httpx。設定不要。

system_design.md に "CLI tool in Go"
→ テスト戦略: go test。設定不要。
```

世の中には設定ファイルが多すぎる。CoDDは設定を散らさない。要件定義と制約条件をインプットにして、必要最小限のハーネスとそのときのベストプラクティスに応じて、設計・実装・テストまで全部やってしまう。これが核心だ。

### V-Modelの完遂

V-Modelは理想的な開発モデルだ。要件定義→基本設計→詳細設計→実装→単体テスト→結合テスト→システムテスト。左側で設計し、右側で検証する。

V-Modelが現実で破綻する理由は明確で、変更時にどこまでドキュメントを直すべきか、人間には追えないからだ。

CoDDはその変更伝搬を自動化する。だからV-Modelが維持可能になる。

IPA共通フレームに準拠した検証構造:

```
左側（設計）                     右側（検証）
要件定義                    ←→  システムテスト / E2E
  基本設計                  ←→  結合テスト
    詳細設計（API/DB設計）  ←→  単体テスト
      実装
```

### Wave — 依存グラフに沿った実行順序

CoDDは設計書を「Wave」という単位で処理する。変更が依存グラフの上流から下流へ波のように伝搬していく — だからWaveだ。依存先がないもの（＝最上流）から順番に、1段ずつ下流へ向かって生成・更新していく。

```
Wave 1: 要件定義（依存先なし。最上流）
Wave 2: 基本設計（要件定義に依存）
Wave 3: 詳細設計・API設計（基本設計に依存）
Wave 4: テスト戦略・インフラ設計（詳細設計に依存）
```

Waveは2つの方向で使う。

- **生成（上流→下流）** — 要件定義を先に書かないと基本設計は書けない。基本設計がないとAPI設計は書けない。Wave 1から順に確定させていく
- **影響分析（下流→上流への問い合わせ）** — DB設計を変えた時、「この設計書に依存しているものは何か」を逆方向に辿って影響範囲を特定する

どちらの方向でも、正しい順序がある。その順序を依存グラフから自動で導出するのがWaveだ。

### フロントマターが唯一の正（Single Source of Truth）

CoDDの依存関係は、Markdownのフロントマターに宣言する。

```yaml
---
codd:
  node_id: "design:api-design"
  depends_on:
    - id: "design:system-design"
      relation: derives_from
    - id: "req:lms-requirements-v2.0"
      relation: implements
---
```

`graph.db` はキャッシュだ。`codd scan` で毎回再生成される。正本はフロントマター。設定ファイルを二重に持つと、CoDDの「上流を見れば下流は導出される」という原則が崩れる。

ここで重要なのは、フロントマターを人間が手動で書くわけではないということだ。AIが書く。設計書もフロントマターも依存宣言も、全部AIが生成する。人間がやるのは要件と制約を決めることだけだ。

---

## 8. 使い方（実践ウォークスルー）

今回は **「で、どうやって使うの？」** にフォーカスする。実際に37行の `spec.md` からTodoアプリを1本ビルドするまでの全ステップを、何が生成されるのかを実物で見せながら解説する。

### 前提: 必要なもの

CoDDはCLIツールだ。内部でAIを呼ぶために、AI CLIが事前にインストールされている必要がある。

| 必要なもの | 用途 |
| --- | --- |
| Python 3.10+ | CoDDの実行環境 |
| Claude Code CLI or Codex CLI | AIの呼び出し（`claude --print` or 互換コマンド） |
| Bash / zsh | コマンドの実行、シェルスクリプトでのフロー構築 |

CoDDの `ai_command` 設定でどのCLIを使うかを指定する。この記事ではClaude Code CLIを使う。

```bash
# Claude Code CLIが動くことを確認
claude --print "hello"
```

これが動けば準備OK。

### インストール

```bash
pip install codd-dev
```

### 基本ワークフロー

```bash
# プロジェクトにCoDDを初期化
codd init --project-name "my-project" --language "typescript"

# 設計書のフロントマターから依存グラフを構築
codd scan

# 変更の影響範囲を分析（直近1コミットとの差分）
codd impact --diff HEAD~1

# フロントマターの整合性を検証
codd validate
```

### コマンド一覧

| コマンド | 状態 | やること |
|---|---|---|
| `codd init` | 安定 | プロジェクト初期化（`--requirements` で要件定義を渡せる） |
| `codd scan` | 安定 | 依存グラフ構築 |
| `codd impact` | 安定 | 変更影響分析（Green/Amber/Gray帯域） |
| `codd validate` | 安定 | 設計書の品質検証（TODO検出、構造チェック等） |
| `codd generate` | 安定 | Wave順で設計書を生成 |
| `codd plan` | 安定 | Wave構成の自動設計（`--init`）・実行ステータス管理 |
| `codd implement` | 安定 | 設計書→コード生成（スプリント単位） |
| `codd review` | 安定 | AIによる設計書レビュー |
| `codd verify` | 実験的 | V-Model検証（型チェック+テスト→設計追跡） |
| `codd extract` | 実験的 | 既存コードから設計書を逆生成（brownfield対応） |
| `codd propagate` | 実験的 | ソースコード変更を設計書に伝播 |
| `codd restore` | 実験的 | 抽出結果から設計書を復元 |
| `codd assemble` | 安定 | スプリント断片を動くプロジェクトに統合 |
| `codd hooks` | 安定 | Gitフック統合の管理 |

`impact` が返す3帯域:

| 帯域 | 信頼度 | 意味 |
|---|---|---|
| Green | 高 | 確実に影響がある。AIが自動更新 |
| Amber | 中 | 確認が必要。人間が判断 |
| Gray | 低 | 間接的な影響の可能性。参考情報 |

### CLIとClaude Code Skillの使い分け

CoDDには2つの使い方がある。CLIとして直接叩くか、Claude Code Skillとして統合するか。

**CLI（どのエディタでも動く）**

```bash
codd scan
codd impact --diff HEAD~1
```

ターミナルで直接実行する。エディタやハーネスに依存しない。CI/CDパイプラインに組み込むのにも向いている。Cursor、Copilot、何でも使える。

**Claude Code Skill（推奨：開発ループに統合する）**

CoDDはClaude Code用のSkill（スラッシュコマンド）を同梱している。

```
/codd-init      → プロジェクト初期化
/codd-scan      → 依存グラフ構築
/codd-impact    → 変更影響分析
/codd-validate  → フロントマター整合性検証
/codd-generate  → Wave順で設計書生成
```

Skillを使うと、CLIデモと同じTaskFlow（タスク管理アプリ）の構築がこう変わる:

```
殿:  /codd-init
     → Claude: codd init --project-name "taskflow" --language "typescript" \
                 --requirements spec.md

殿:  /codd-generate
     → Claude: codd generate --wave 2 --path .
     → Claudeが生成された設計書を読み、スコープ確認、フロントマター検証
     → 「Wave 2の設計書を確認しました。Wave 3に進みますか？」

殿:  はい

殿:  /codd-generate
     → Claude: codd generate --wave 3 --path .

殿:  /codd-scan
     → Claude: codd scan --path .
     → 「7ドキュメント、15エッジ。警告なし。」

殿:  （要件を編集 — SSO対応と監査ログを追加）

殿:  /codd-impact
     → Claude: codd impact --path .
     → Green帯域: system-design、api-design、db-design、auth-designを自動更新
     → Amber帯域: 「test-strategyが影響を受けています。更新しますか？」
```

CLIとの違いはHITL（Human-in-the-Loop）ゲートが自動で入ること。`/codd-generate` はWave間で承認を求めて停止する。`/codd-impact` はGreen/Amber/Grayプロトコルに従い、安全な変更は自動更新、リスクのある変更は確認してから実行。人間は判断だけすればいい。

さらにhook機構と組み合わせると、こうなる:

```json
// .claude/settings.json
{
  "hooks": {
    "PostToolUse": [{
      "matcher": "Edit|Write",
      "hooks": [{
        "type": "command",
        "async": true,
        "command": "cd \"$CLAUDE_PROJECT_DIR\" && codd scan --path ."
      }]
    }]
  }
}
```

- **PostToolUse hook**: AIがファイルを編集するたびに `codd scan` が自動実行される。依存グラフが常に最新
- **pre-commit hook**: `codd validate` をgit hookに仕込めば、整合性が壊れた状態ではコミットできない

このhookを入れた瞬間、`codd scan` を手動で叩く必要は二度とない。依存グラフのメンテナンスは完全に透明になる。やることは「普通にコードを書く」「影響を知りたくなったら `/codd-impact` を叩く」。それだけだ。

CLIは「手動で叩く道具」、Skillは「開発ループに溶け込む仕組み」。CLIだけでもCoDDは使えるが、Skill + hookを入れると一貫性の維持を意識する必要すらなくなる。設定は一度だけ。あとはhookが全部やる。

### Step 1: spec.mdを書く

CoDDの入力はMarkdownで書いた要件定義。見出しと箇条書きで構造化しておくと、AIが意図を正確に拾いやすい。フロントマターもフォルダ構成もwave_configも書かない。txtでもmdでもdocでもいい。

```markdown
# TaskFlow — 要件定義

## 機能要件
- ユーザー認証（メール + Google OAuth）
- ワークスペース管理（チーム、ロール、招待）
- タスクCRUD（担当者、ラベル、期限）
- リアルタイム更新（WebSocket）
- ファイル添付（S3）
- 通知システム（アプリ内 + メール）

## 制約
- Next.js + Prisma + PostgreSQL
- ワークスペース分離はRLSで実現
- 全APIエンドポイントにレートリミット
```

### Step 2: CoDDを初期化（要件定義を渡すだけ）

```bash
pip install codd-dev
mkdir taskflow && cd taskflow && git init
codd init --project-name "taskflow" --language "typescript" \
  --requirements spec.md
```

CoDDがフロントマター（node_id, type, 依存メタデータ）を自動付与して `docs/requirements/requirements.md` に配置する。人間はフロントマターを触らない。

### Step 3: AIが設計書を生成する

`codd plan --init` でwave構成を自動設計し、`codd generate` でWave順に設計書を生成する。

```bash
codd plan --init          # 要件からwave構成を自動設計
codd generate --wave 1   # 受入基準・ADR（技術選定）を生成
codd generate --wave 2   # システム設計を生成
codd generate --wave 3   # 詳細設計を生成
codd generate --wave 4   # 実装計画を生成
```

AIが生成した各設計書には自動的にCoDDフロントマターが付与される。依存先（depends_on）もWave番号もAIが決定する。人間は手を入れない。

### Step 4: 依存グラフを構築

```bash
codd scan
```

```
Frontmatter: 7 documents in docs
Scan complete:
  Documents with frontmatter: 7
  Graph: 7 nodes, 15 edges
  Evidence: 15 total (0 human, 15 auto)
```

7本の設計書から15本のエッジ（依存関係）が抽出された。設定ファイルは1行も書いていない。AIが生成したフロントマターだけでグラフが構築される。

### Step 5: 要件を変える → 影響分析

ここが本番。PMから「SSO対応と監査ログ追加して」と言われた。`docs/requirements/requirements.md` を開いて2行足す:

```markdown
## 追加要件（v1.1）
- SAML SSO対応（エンタープライズ顧客向け）
- 監査ログ（全操作の記録・エクスポート）
```

たった2行。ファイルを保存して、CoDDに「何が壊れる？」と聞く:

```bash
codd impact    # 未コミットの変更を自動検知して影響分析
```

```
Changed files: 1
  - docs/requirements/requirements.md → req:taskflow-requirements

# CoDD Impact Report

## Green Band (high confidence, auto-propagate)

| Target                  | Depth | Confidence |
|-------------------------|-------|------------|
| design:system-design    | 1     | 0.90       |
| design:api-design       | 1     | 0.90       |
| detail:db-design        | 2     | 0.90       |
| detail:auth-design      | 2     | 0.90       |

## Amber Band (must review)

| Target                  | Depth | Confidence |
|-------------------------|-------|------------|
| test:test-strategy      | 2     | 0.90       |

## Gray Band (informational)

| Target                  | Depth | Confidence |
|-------------------------|-------|------------|
| plan:implementation     | 2     | 0.00       |
```

要件を2行変えただけで、7本中6本の設計書が影響を受けると判定された。

- **Green（4本）** — システム設計、API設計、DB設計、認証設計。SAML SSOを追加するなら認証設計は確実に変わる。監査ログならDBにテーブルが増える。APIにもエンドポイントが増える。全部自明な波及だ。
- **Amber（1本）** — テスト戦略。認証方式が増えたらテストも変わるかもしれない。人間が判断する領域。
- **Gray（1本）** — 実装計画。参考情報。設計が固まってからスプリントを組み替える。

人間がこれを頭で追ったら何分かかる？18本の設計書がある実プロジェクトなら？CoDDは0.1秒で答えを出す。7本でこの波及。18本だったら？

Green帯域の4本はAIが自動更新する。Amber帯域は人間に提示する。変更が怖くなくなる。

### パイプライン全体像

この記事の全体像となるフローは以下の通り構築される。

1. **`codd init --requirements spec.md`** — プロジェクトの初期化。要件定義を渡す。
2. **`codd plan --init`** — Wave構成の自動設計。依存関係グラフのメタデータを含むwave数を返す（今回は4）。
3. **`codd generate --wave 1〜N`** — 設計書群（Wave 1〜4）を依存チェーンに従って順次生成する。
4. **`codd validate`** — 品質ゲートを通す。
5. **`codd implement`** — 全タスクを一括でコード生成する。
6. **`codd assemble`** — 動くTodoアプリへの統合（TypeScript strict、エラーゼロ）。

**入力と出力の結果:**

- **入力:** `spec.md`（37行）
- **出力:** 設計書6本（1,353行）、コード102ファイル（6,445行）
- **結果:** ビルド成功（static export）

---

## 9. 後半: 内部の仕組み — STDIO経由のプロンプト注入

CoDDの根幹は驚くほどシンプルだ。`claude --print` とはClaude Code CLIの非対話モードであり、プロンプトをコマンドライン引数経由で渡し、結果を標準出力（STDIO）に返す。つまり **STDIO（標準入出力）経由のプロンプト注入** である。

AI自体はブラックボックスで、CLIの入出力だけがインターフェースだ。この1行がAI呼び出しの定義であり、`claude` の部分を別のCLIに差し替えれば、理論上はどのLLMでも動く。CoDDはAIの呼び出し方に依存しない。

ここで気づいてほしいのは、**CoDDのパイプライン全体でClaude Code CLIの対話モードを一度も使っていないこと**。これは意図的な設計だ。AIをSTDIO経由のバックエンドに押し込めることで、全ステップがシェルスクリプトで制御できる。だから前述のHITLパターンも、モデル切り替えも、全部シェルの世界で完結する。

### Harness as Codeとしてのシェルスクリプト

すべてのCoDDコマンドはCLIツールであるため、シェルスクリプトで自由に組み合わせることができる。マジックナンバーはない。Wave数もCoDDから返される。もし仕様が変わってWave構成やタスクの数が変わっても、スクリプトを書き換える必要は一切ない。

これこそが **Harness as Code** の具体例だ。`spec.md` を配置してこのスクリプトを実行すれば、あとは放っておいて寝ていればいい。設計書とコードがすべて生成される。我々がやっていることは、一時停止したい場所に `read` を挟むことだけだ。

---

## 10. 実案件での適用例 — クライアント向けLMS

CoDDは実案件で使っている。クライアント向けのLMS（Learning Management System）。Next.js + Supabase + Redisのマルチテナント型。

全設計書、全実装コード、全テストをAIがCoDDに従って生成した。実装者がやったのは要件と制約を決めたことだけだ。WaveごとにHITL（人間の確認）を入れることもできるし、全部任せて最後だけ見ることもできる。好みの問題だ。

```
docs/
├── requirements/       # 要件定義（唯一の人間の入力）
├── design/             # 基本設計（6ファイル、全てCoDD frontmatter付き）
├── detailed_design/    # 詳細設計（4ファイル）
├── governance/         # ADR（3ファイル）
├── plan/               # 実装計画
├── test/               # 受入基準、テスト戦略
├── operations/         # 運用手順書
└── infra/              # インフラ設計
```

18のMarkdownファイルが依存グラフで繋がっている。

開発を進める中で当然いろいろ変わる。最初に「RLSでテナント分離する」と決めたけど、詳細設計を掘っていくうちに「このテーブル構造だとRLSポリシーをこう変えた方がいい」となる。DB設計が変わればAPI設計も変わる。API設計が変わればテスト戦略も変わる。

これは要件変更ではない。設計を深掘りしていく過程で、当然起きる判断の更新だ。どんなプロジェクトでも起きる。

CoDDなしでこれをやると、「どの設計書を直すべきか」を人間が頭で追うことになる。18ファイルの依存関係を。

CoDDありだと、`codd impact` を叩けば影響を受ける設計書がリストアップされる。実際の出力はこうなる:

```
# CoDD Impact Report

Changed files: 1
  - docs/requirements/requirements.md → req:lms-requirements-v2.0

## Green Band (high confidence, auto-propagate)
| Target                  | Depth | Confidence |
|-------------------------|-------|------------|
| design:system-design    | 1     | 0.90       |
| design:api-design       | 1     | 0.90       |
| detail:db-design        | 2     | 0.90       |

## Amber Band (must review)
| Target                  | Depth | Confidence |
|-------------------------|-------|------------|
| detail:auth-design      | 2     | 0.90       |

## Gray Band (informational)
| Target                  | Depth | Confidence |
|-------------------------|-------|------------|
| test:test-strategy      | 2     | 0.00       |
```

要件定義を1箇所変えただけで、影響を受ける設計書が信頼度付きで全部出てくる。Greenは自動更新可能、Amberは人間の確認が必要、Grayは参考情報。AIがGreen帯域の設計書を自動更新し、Amber帯域を人間に提示する。

**変更が怖くなくなる。** これがCoDDの一番の価値だと思っている。設計判断を変えるコストが下がるから、「とりあえず仮で進めて、後で直す」ができる。仮決めのまま放置されて設計が腐る、というあの問題が起きない。

---

## 11. CoDDのこれから

2026/4/1 — v1.2.0リリース。`codd assemble` のプロンプト改善でプロジェクト設定ファイル（package.json、tsconfig.json等）の生成を明示化。Claude Code Skill `codd-assemble` 追加。グリーンフィールド・パイプラインの全自動化が完成。

v1.0.0で安定したコマンド: init, scan, impact, validate, generate, plan, implement, review, hooks。

直近のロードマップ:

- **意味付き依存タイプ** — requires、affects、verifies、implementsなど、依存の種類を区別する
- **Brownfield対応（codd extract）** — 実装済み（実験的）。既存コードベースから依存グラフ付き設計書を逆生成する
- **codd verifyの完成** — 設計書↔コード↔テストの整合性を自動検証する
- **codd propagateの安定化** — ソースコード変更を設計書に自動伝播する
- **複数ハーネスの統合例** — Claude Code、Copilot、Cursorでの動作実証

長期的に目指しているのは、TDD、BDD、DDDの横に並ぶ開発方法論としてのCoDD（Coherence-Driven Development）だ。テスト駆動でもない。振る舞い駆動でもない。ドメイン駆動でもない。**整合性駆動。** 何が変わっても設計が崩れない開発。

---

## まとめ

| 方法論 | 解く問題 | 時期 |
|---|---|---|
| プロンプトエンジニアリング | AIへの入力をどう作るか | 2023〜2024 |
| コンテキストエンジニアリング | AIの背景知識をどう管理するか | 2024〜2025 |
| ハーネスエンジニアリング | AIの実行をどう制御するか | 2025〜2026 |
| └─ CoDD | 変更時に設計の整合性をどう保つか | 2026〜 |

CoDDはハーネスエンジニアリングの一部だ。ハーネスの中で、まだ誰も手を付けていなかった「整合性維持」というレイヤーを担う。既存のハーネスが「AIをどう制御するか」なら、CoDDは「AIが作ったものをどう維持するか」を、同じハーネスの枠組みの中で解く。

仕様駆動のツールは「最初にどう作るか」を教えてくれる。CoDDは「途中で変わった時にどうするか」を解く。

Spec KitやOpenSpecが *"how do I start?"* に答えるなら、CoDDは *"how do I keep going when things change?"* に答える。
