# Pochi AI駆動開発プロセス戦略

作成日: 2026-05-18  
ステータス: 計画中

---

## 背景と目的

本ドキュメントは `plan/new-dev/design/` に収集した以下3本の外部知見をPochiの文脈に翻訳し、AI駆動開発プロセスの全体戦略を定義する。

| 参考ドキュメント | 主な示唆 |
|---|---|
| `DESIGN.md ベストプラクティス・レポート.md` | デザイントークンをファイル化し、AI生成UIの統一性を担保する手法 |
| `クラメソのデザインガイドをDESIGN.mdで実装してみた.md` | DESIGN.md導入でプロンプト長を約70%削減した実績・ハイブリッド運用の知見 |
| `CoDD/整合性駆動開発CoDD爆誕.md` | 設計書の依存グラフで変更時の整合性を自動追跡する方法論 |
| `etc/Everything As Code.md` | 「人間しか知らない情報をなくす」ことがAI駆動開発の前提条件という整理 |

### 現状の課題

Pochiスキル群（25スキル、5カテゴリ）はフェーズ別に整備されているが、3つの構造的課題がある。

1. **デザインルールがプロンプト依存**  
   `PochiアプリUIガイドライン`（7原則）は文書化されているが、AI生成時に毎回CLAUDE.mdからの参照指示を書く必要がある。デザイントークン（色・余白・フォント）がファイルとして存在しない。

2. **フェーズ間の整合性保証がない**  
   `spec.json` を変更しても `plan.json` や実装コードへの波及追跡が手動。API設計変更時にどのテストが影響を受けるかを人間が追う。

3. **知識がリポジトリ外に散在**  
   DB設計・業務フロー・議事録がGoogleスプレッドシート等に残り、AIがアクセス不能な「人間しか知らない情報」になっている。

---

## 戦略全体像：3層アーキテクチャ

```
┌─────────────────────────────────────────────────────────┐
│  Layer A: Everything As Code（知識の構造化）            │
│  DESIGN.md + spec.json + plan.json + docs/設計書        │
├─────────────────────────────────────────────────────────┤
│  Layer B: ハーネスエンジニアリング（制御の自動化）       │
│  CLAUDE.md + Hooks + Skills                             │
├─────────────────────────────────────────────────────────┤
│  Layer C: Coherence-Driven Development（整合性の維持）   │
│  codd-scan / codd-impact で変更を依存グラフに沿って追跡 │
└─────────────────────────────────────────────────────────┘
```

**方針**: Layer A（DESIGN.md）から始め、効果を確認しながら Layer B→C へ段階的に展開する。

---

## 施策1：DESIGN.md の導入（最優先・即効性あり）

### 何をするか

Pochiアプリ用のデザインシステムを `DESIGN.md` として1ファイルに集約し、プロジェクトルートに配置する。

```
pochi-dp-developer-docs/
└── DESIGN.md   ← 新規作成
```

### DESIGN.md の構成（9セクション標準形式）

```markdown
---
# デザイントークン（機械可読・W3C Design Token互換）
design_tokens:
  colors:
    primary:    "#1E88E5"   # 主要ボタン・強調
    background: "#F4F4F4"   # ページ全体の単一背景
    surface:    "#FFFFFF"   # カード・モーダル
    border:     "#DDDDDD"   # 区切り線（1px solid）
    text:       "#1A1C1E"   # 見出し・本文
    error:      "#D32F2F"   # バリデーションエラー
  spacing:
    base:    "8px"
    section: "24px"
  border_radius: "0px"      # フラットデザイン（角丸なし）
  typography:
    font_family: "Noto Sans JP, sans-serif"
---

## 1. ビジュアルテーマ
## 2. カラーパレットと役割
## 3. タイポグラフィ規則
## 4. コンポーネントスタイル（Streamlit固有）
## 5. レイアウト原則（UIガイドライン7原則の要約）
## 6. Do's and Don'ts
## 7. レスポンシブ動作
## 8. エージェント向けプロンプトガイド
```

### CLAUDE.md への追記

プロジェクト `CLAUDE.md`（`.claude/CLAUDE.md`）に以下を追記：

```markdown
### DESIGN.md の参照
UIやコンポーネントを生成・修正する際は、必ずリポジトリルートの `DESIGN.md` の
デザイントークンを参照し、厳格に従うこと。スキル呼び出し時にデザイン指定を
プロンプトで重複して書かない。
```

### 期待効果

| 現状 | 導入後 |
|------|--------|
| `pochi-ui-generator` 起動のたびに色・余白・禁止事項をプロンプトに書く | DESIGN.mdを参照するよう CLAUDE.md に書くだけで自動適用 |
| スキル呼び出しプロンプトが長い | 約70%削減（クラメソ実績） |
| Cursor等の他ツールで同じルールを使えない | ファイルを持ち込むだけで共有可能 |

### スキルとの位置付け

```
スキル（Claude Code固有）     DESIGN.md（ツール横断）
─────────────────────────     ─────────────────────
明示的呼び出しが必要         リポジトリに置くだけで参照
ロゴ・テンプレートなど       テキスト中心のデザインルール
ツール連携が必要な処理       色・余白・フォント等の宣言
```

**ハイブリッド運用**：ロゴ画像・PDF生成など「ファイルの実体が必要な処理」はスキルに残し、デザイントークンの正は DESIGN.md に寄せる。

---

## 施策2：Everything As Code — 設計書のリポジトリ化

### 各アプリリポジトリの標準ディレクトリ構成

```
<app-repo>/
├── DESIGN.md                      # デザインシステム（施策1）
├── docs/
│   ├── spec.json                  # 機能仕様（pochi-spec-initializer出力）
│   ├── spec.md                    # spec.jsonから自動生成
│   ├── plan.json                  # 実装計画
│   └── design/
│       ├── operation-flow.md      # 業務フロー（operation-flow-generator出力）
│       └── db-design.md           # DB・テーブル設計
├── tests/
│   └── contracts/                 # pochi-unit-test-generator出力
└── app/                           # Streamlitアプリ本体
```

### 生成フロー

```
interview-to-needs
       ↓ ヒアリング結果
operation-flow-generator
       ↓ 業務フロー.md → docs/design/operation-flow.md にコミット
hypothesis-generator
       ↓ 仮説.md → docs/design/ にコミット
pochi-spec-initializer
       ↓ spec.json + plan.json → docs/ にコミット
```

**目標**：人間しか知らない情報（議事録・業務フロー・DB設計の背景）をMarkdownとしてリポジトリに格納し、AIが任意のタイミングで参照できる状態にする。

---

## 施策3：CoDD による整合性の自動追跡（必要性を確認してから判断）

### 概要

CoDDの中核コマンドをPochiワークフローに統合し、設計変更時の影響範囲を自動で特定する。

```bash
codd scan    # 設計書の依存グラフを構築
codd impact  # 変更がどの設計書・コードに波及するか分析
```

### 優先適用シナリオ（効果が大きい順）

1. **spec.json の仕様変更時** — plan.json・実装コード・テストへの波及を自動特定
2. **Snowflake ビュー廃止時**（ALADIN-DWH収束等） — DB設計変更がアプリコードに与える影響を追跡
3. **pochilib バージョンアップ時** — ライブラリAPI変更が各アプリに与える影響を分析

### CoDD Frontmatter（spec.jsonへの追加項目）

```yaml
---
node_id: "spec:app-name-v1.0"
wave: 1
depends_on: []
source_files: ["app/*.py", "tests/"]
last_updated: "2026-05-18"
---
```

### 判定基準

DESIGN.md（施策1）と docs/ 標準化（施策2）が定着した後、以下の状況になったら着手する：

- spec.json の変更が月に2回以上発生している
- 変更影響の確認に1時間以上かかっているケースがある

---

## 強化後の開発フロー

### 全体フロー

```
Phase 0: 知識の構造化（施策2）
  interview-to-needs
  → operation-flow-generator  → docs/design/ にコミット
  → hypothesis-generator
                  ↓
Phase 1: 設計（既存スキルを使用）
  pochi-spec-initializer
  → spec.json + plan.json を docs/ にコミット
  + DESIGN.md 参照による画面設計（施策1）
                  ↓
Phase 2: 実装（既存スキルを使用）
  pochi-coding-agent
  → spec.md + plan.json + DESIGN.md を参照して実装
                  ↓
Phase 3: 変更対応（施策3 適用後）
  codd-impact
  → Green: plan.json・コードを自動更新
  → Amber: テスト・インフラを人間が確認
                  ↓
Phase 4: テスト（既存スキルを使用）
  pochi-unit-test-generator
  → pochi-test-orchestrator
  → pochi-e2e-test-generator
```

### UX改善フロー（強化版）

```
ux-review（現状分析）
  → DESIGN.md 更新（デザイントークンのチューニング）
  → pochi-spec-initializer（改善仕様書）
  → pochi-coding-agent（実装）
```

---

## 実装ロードマップ

### Step 1：即着手（今日〜今週）

| 施策 | 成果物 | 工数目安 |
|------|--------|----------|
| DESIGN.md 作成 | `pochi-dp-developer-docs/DESIGN.md` | 半日 |
| CLAUDE.md への参照ルール追記 | `.claude/CLAUDE.md` の更新 | 15分 |

**検証方法**：`pochi-ui-generator` を呼び出し、DESIGN.mdのデザイントークンが適用されているかUIガイドライン7原則チェックリストで確認する。

### Step 2：DESIGN.md 効果確認後（来週以降）

| 施策 | 成果物 | 工数目安 |
|------|--------|----------|
| pochi-skill-navigator のワークフロー図更新 | `skills/tools/pochi-skill-navigator/skills/run/SKILL.md` | 2時間 |
| docs/ テンプレート標準化 | アプリリポジトリ向けガイドライン文書 | 1日 |

### Step 3：必要性確認後に判断（来月以降）

| 施策 | 成果物 | 工数目安 |
|------|--------|----------|
| spec-initializer の CoDD frontmatter 対応 | SKILL.md 改修 | 1日 |
| PostToolUse Hook で codd scan 自動化 | `.claude/settings.json` 更新 | 半日 |
| codd-extract による Brownfield 設計書逆生成 | 既存アプリの docs/ 自動生成 | 継続 |

---

## 進化の比較表

| 観点 | 現状 | DESIGN.md導入後 | CoDD導入後 |
|------|------|-----------------|------------|
| UIデザイン一貫性 | プロンプト依存 | DESIGN.mdで常時保証 | 変わらず |
| 要件変更の影響把握 | 人間が手動追跡 | 手動追跡 | 自動で影響範囲を特定 |
| 設計書の可用性 | 一部リポジトリ外 | docs/に集約 | 依存グラフで構造化 |
| スキル間の接続 | skill-navigatorで案内 | ワークフローが明示化 | 変更伝播が自動化 |

---

## EaC記事とPochi戦略の対応マッピング

> 参照元記事：`plan/new-dev/etc/Everything As Code.md`（Zenn: よーすけ著）

### 記事の3課題 × Pochiの施策対応

| EaC記事の問題提起 | Pochi現状 | 対応施策 |
|---|---|---|
| ①AIに与える情報が圧倒的に足りない | spec.json/plan.jsonは整備済み。DBや業務フローはGSheetsに散在 | 施策2（docs/標準化） |
| ②AI中心の構造になっていない（情報分散・AI非可読形式） | ドキュメントの一部が外部ツール依存 | 施策2 + DESIGN.md（施策1） |
| ③エンジニア側のAI理解が足りない | CLAUDE.md・Skillガイドラインで整備済み。継続更新が必要 | Layer B（ハーネス）維持 |

### 記事の「設計書コード化3方法」× Pochiスキルの対応

| EaC記事の方法 | Pochi対応 | 実装状況 |
|---|---|---|
| 方法①GitBook（Markdown化） | docs/配下にMarkdown生成するSkillチェーン | 部分実装（spec.json→spec.md自動生成） |
| 方法②MCPツール（スプレッドシート検索） | pochilib経由のSnowflakeアクセス | 既存（Snowflake機能） |
| 方法③VectorDB+RAG | 未実装 | 中長期検討 |

---

## アプリ1本あたりのミニマムEaC構成

> EaC記事の「現実的な第一歩」（今の機能の設計書だけをMarkdown化してソースコードと同じディレクトリに置く）をPochiに対応させた最小定義。

```
<app-repo>/
├── DESIGN.md                          ← 共通デザインシステム（pochi-dp-developer-docsから参照）
└── docs/
    ├── spec.json                      ← pochi-spec-initializer が出力
    ├── spec.md                        ← 自動生成（手動編集禁止）
    ├── plan.json                      ← pochi-spec-initializer が出力
    └── design/
        └── operation-flow.md          ← operation-flow-generator が出力
```

この状態が「ミニマムEaC」。`pochi-coding-agent` が spec.json/plan.json/DESIGN.md を参照してコンテキストフルに動作できる最低条件。

### Skill出力先の標準化

現状、各スキルの出力先が統一されていない。以下を標準とする：

| スキル | 現状の出力先 | 標準化後の出力先 |
|---|---|---|
| pochi-spec-initializer | `pochi-spec-initializer/specs/features/[FEATURE-ID]/` | `docs/` |
| operation-flow-generator | 未定義 | `docs/design/operation-flow.md` |
| hypothesis-generator | 未定義 | `docs/design/hypothesis.md` |

---

## EaC成熟度チェックリスト

アプリリポジトリのEaC状態を自己評価するチェックリスト。

- [ ] `docs/spec.json` が存在する（pochi-spec-initializerで生成済み）
- [ ] `docs/design/operation-flow.md` が存在する（業務フローが可視化済み）
- [ ] `DESIGN.md` を参照できる（ルートまたはシンボリックリンク）
- [ ] `pochi-coding-agent` が spec.json/plan.json を入力として動作している
- [ ] Snowflakeスキーマ変更が `docs/design/db-design.md` に反映されている

**判定基準**：3項目以上 → EaC準拠。5項目全て → フル EaC 状態。

---

## 関連ドキュメント

- `plan/new-dev/design/DESIGN.md ベストプラクティス・レポート.md`
- `plan/new-dev/design/クラメソのデザインガイドをDESIGN.mdで実装してみた.md`
- `plan/new-dev/CoDD/整合性駆動開発CoDD爆誕.md`
- `plan/new-dev/etc/Everything As Code.md`
- `/pochi-document-for-developers-v2-repository/pochi_document/docs/manuals/PochiアプリUIガイドライン/PochiアプリUIガイドライン.md`
