# CoDD（整合性駆動開発）Claude Code Skill 設計書

## 全体アーキテクチャ

### ディレクトリ構造

```
project/
├── .claude/
│   └── commands/
│       ├── codd-init.md          # プロジェクト初期化
│       ├── codd-plan.md          # 設計計画の自動生成
│       ├── codd-generate.md      # Wave順設計書生成
│       ├── codd-validate.md      # 品質ゲート検証
│       ├── codd-implement.md     # コード生成
│       ├── codd-assemble.md      # 結合・ビルド準備
│       ├── codd-scan.md          # 依存グラフ構築
│       ├── codd-impact.md        # 変更影響分析・自動修正
│       └── codd-extract.md       # リバースエンジニアリング
├── CLAUDE.md                     # CoDDグローバルルール
├── docs/
│   ├── codd-graph.json           # 依存グラフ（自動生成）
│   ├── L1_requirements/          # Wave 1: 要件定義
│   ├── L2_architecture/          # Wave 2: アーキテクチャ
│   ├── L3_detailed_design/       # Wave 3: 詳細設計
│   ├── L4_test_strategy/         # Wave 4: テスト戦略
│   ├── L5_api_schema/            # Wave 5: API・スキーマ定義
│   └── L6_deployment/            # Wave 6: デプロイ・運用
├── src/
└── tests/
```

---

## CLAUDE.md（CoDDグローバルルール）

```markdown
# CoDD (Coherence-Driven Development) プロジェクトルール

## 基本原則
1. **導出原則 (Derive, Don't Configure)**: 上流ドキュメントから下流の技術選定・設計を自動導出する。冗長な設定ファイルを作らない。
2. **Wave階層 (L1→L6)**: 設計書はL1(要件)→L6(運用)の階層で段階的に詳細化する。上流の制約は下流に自動伝播する。
3. **依存グラフによる整合性維持**: すべてのドキュメントはFrontmatterで依存関係を宣言し、変更時はグラフを辿って影響範囲を特定・修正する。

## Frontmatter仕様
すべての設計書Markdownは以下のYAML Frontmatterを持つ:
```yaml
---
node_id: "L{wave}_{category}_{name}"
title: "ドキュメントタイトル"
wave: 1-6
status: "draft | review | approved | stale"
depends_on:
  - "依存する上流ドキュメントのnode_id"
constrained_by:
  - "制約を受けるドキュメントのnode_id"
source_files:
  - "紐づくソースコードパス"
  - "紐づくテストファイルパス"
last_updated: "ISO 8601日時"
checksum: "内容のSHA-256ハッシュ(先頭8桁)"
---
```

## トラフィックライト分類
- 🟢 **Green**: AIが自動更新可能（直接依存、変更内容が明確）
- 🟡 **Amber**: 人間の確認が必要（間接依存、設計判断を伴う）
- ⚪ **Gray**: 参考情報（直接変更不要だがコンテキストとして参照）

## 品質ゲート規則
以下を含むドキュメントは下流生成をブロックする:
- `TODO`, `TBD`, `FIXME`, `要検討` などの未決マーカー
- 空セクション（見出しのみで本文なし）
- `<!-- AI_META: ... -->` 等のメタコメント残留
- Frontmatterの必須フィールド欠落

## ファイル命名規則
- `docs/L{wave}_{category}/{snake_case_name}.md`
- 例: `docs/L1_requirements/user_stories.md`
- 例: `docs/L3_detailed_design/auth_module.md`
```

---

## Skill 1: `/codd-init`

**ファイル**: `.claude/commands/codd-init.md`

```markdown
---
description: "CoDDプロジェクトを初期化する。要件定義の平文からWave構成とFrontmatterを自動生成する。"
---

# CoDD プロジェクト初期化

## 入力
ユーザーから以下のいずれかが提供される:
- 要件定義の平文テキスト（$ARGUMENTS に記述）
- 要件定義ファイルへのパス（例: `spec.md`, `requirements.txt`）
- 口頭での要件説明

要件情報: $ARGUMENTS

## 実行手順

### Step 1: ディレクトリ構造の作成
以下のディレクトリを作成する:
```
docs/
├── L1_requirements/
├── L2_architecture/
├── L3_detailed_design/
├── L4_test_strategy/
├── L5_api_schema/
└── L6_deployment/
```

### Step 2: CLAUDE.md の配置
プロジェクトルートに CLAUDE.md が存在しない場合、CoDDグローバルルールを含む CLAUDE.md を生成する。
既に存在する場合は、CoDDルールセクションを追記する。

### Step 3: 要件定義ドキュメント (L1) の生成
提供された要件情報を解析し、以下のL1ドキュメントを生成する:

1. **`docs/L1_requirements/project_overview.md`** - プロジェクト概要、目的、スコープ
2. **`docs/L1_requirements/user_stories.md`** - ユーザーストーリー一覧
3. **`docs/L1_requirements/functional_requirements.md`** - 機能要件
4. **`docs/L1_requirements/non_functional_requirements.md`** - 非機能要件（性能、セキュリティ等）
5. **`docs/L1_requirements/constraints.md`** - 技術制約・ビジネス制約

各ドキュメントには適切なCoDD Frontmatterを付与する。

### Step 4: 初期依存グラフの生成
`docs/codd-graph.json` を生成する。形式:
```json
{
  "version": "1.0",
  "generated_at": "ISO 8601",
  "nodes": [
    {
      "node_id": "L1_req_project_overview",
      "path": "docs/L1_requirements/project_overview.md",
      "wave": 1,
      "status": "draft",
      "depends_on": [],
      "dependents": []
    }
  ],
  "edges": []
}
```

### Step 5: 技術スタックの導出（導出原則の適用）
要件から以下を自動導出し、`docs/L1_requirements/constraints.md` に記載:
- 推奨フレームワーク・言語
- 推奨テストフレームワーク（導出原則に基づく）
- 推奨デプロイ環境
- 導出根拠（なぜその技術が選ばれたか）

### Step 6: 初期化レポートの出力
以下をコンソールに出力:
- 生成されたファイル一覧
- 検出された要件数
- 次のステップの案内（`/codd-plan` の実行を推奨）

## 注意事項
- 要件が曖昧な場合は、具体的な質問をユーザーに返す（推測で進めない）
- 既存のdocsディレクトリがある場合は上書きせず、マージするか確認する
- Frontmatterのchecksumは生成時点の内容から算出する
```

---

## Skill 2: `/codd-plan`

**ファイル**: `.claude/commands/codd-plan.md`

```markdown
---
description: "L1要件定義を読み込み、Wave 2〜6でどの設計書をどの順番で生成するかの計画を自動設計する。"
---

# CoDD 設計計画の自動生成

## 入力
$ARGUMENTS: オプション引数（`--init` で初回計画、`--update` で計画更新）

## 前提条件
- `/codd-init` が完了し、`docs/L1_requirements/` にドキュメントが存在すること
- L1ドキュメントのstatusが `draft` 以上であること

## 実行手順

### Step 1: L1ドキュメントの全読み込み
`docs/L1_requirements/` 配下のすべてのMarkdownを読み込み、以下を抽出:
- 機能要件の一覧
- 非機能要件の一覧
- 技術制約
- ドメインエンティティの候補

### Step 2: Wave 2 (アーキテクチャ) の計画
要件から必要なアーキテクチャドキュメントを決定:
- `L2_arch_system_architecture.md` - システム全体構成図
- `L2_arch_tech_stack.md` - 技術スタック確定（L1の導出結果を正式化）
- `L2_arch_data_model.md` - データモデル概要
- `L2_arch_api_overview.md` - API設計概要
- `L2_arch_security.md` - セキュリティアーキテクチャ（非機能要件から導出）
- その他、要件に応じて追加

### Step 3: Wave 3 (詳細設計) の計画
機能要件をモジュール単位に分解し、各モジュールの詳細設計書を計画:
- 機能モジュールごとに1ファイル
- 依存関係（depends_on）をL2ドキュメントに設定
- データフロー、状態遷移、エラーハンドリングを含む

### Step 4: Wave 4 (テスト戦略) の計画
導出原則に基づき、テスト戦略を自動決定:
- L2の技術スタックからテストフレームワークを導出
- 各L3モジュールに対応するテスト設計書を計画
- E2E、統合、ユニットテストの範囲を定義

### Step 5: Wave 5 (API・スキーマ定義) の計画
- OpenAPI/GraphQLスキーマ定義
- DBマイグレーション定義
- 型定義ファイル

### Step 6: Wave 6 (デプロイ・運用) の計画
- CI/CD設定
- 環境設定
- 監視・ログ設計

### Step 7: 計画書の出力
`docs/codd-plan.md` として以下を生成:

```yaml
---
node_id: "codd_plan"
title: "CoDD Generation Plan"
wave: 0
status: "draft"
depends_on: ["L1_req_project_overview", "L1_req_functional_requirements", ...]
last_updated: "ISO 8601"
---
```

| Wave | node_id | ファイルパス | depends_on | 生成優先度 |
|------|---------|-------------|------------|-----------|
| 2 | L2_arch_system_architecture | docs/L2_architecture/system_architecture.md | [L1_req_*] | 1 |
| 2 | L2_arch_tech_stack | docs/L2_architecture/tech_stack.md | [L1_req_constraints] | 2 |
| ... | ... | ... | ... | ... |

### Step 8: 依存グラフの更新
`docs/codd-graph.json` に計画されたノードとエッジを追加（status: "planned"）

### Step 9: レビュー促進
計画の要約を出力し、ユーザーに以下を確認:
- 不足している設計書はないか
- Wave順序は適切か
- 次のステップ（`/codd-generate --wave 2` の実行）の案内
```

---

## Skill 3: `/codd-generate`

**ファイル**: `.claude/commands/codd-generate.md`

```markdown
---
description: "指定されたWaveの設計書を、上流ドキュメントの制約に基づいて順次生成する。"
---

# CoDD 設計書生成

## 入力
$ARGUMENTS: 生成対象の指定
- `--wave N` : Wave N のすべてのドキュメントを生成
- `--node NODE_ID` : 特定のノードのみ生成
- `--all` : 未生成のすべてのドキュメントをWave順に生成

## 前提条件
- `/codd-plan` が完了し、`docs/codd-plan.md` が存在すること
- 指定Waveの上流Wave（Wave N-1以下）がすべて `approved` または `review` statusであること
- 上流ドキュメントが品質ゲートを通過していること（`/codd-validate` 相当のチェック）

## 実行手順

### Step 1: 生成対象の特定
`docs/codd-plan.md` から指定されたWaveの生成対象ノードを抽出し、依存関係に基づいて生成順序を決定する（トポロジカルソート）。

### Step 2: 上流ドキュメントの読み込み
各生成対象ノードの `depends_on` に指定されたドキュメントをすべて読み込む。

### Step 3: 導出原則の適用
上流ドキュメントの内容から、以下を自動導出して生成に反映:

**L2生成時の導出例:**
- L1の技術制約 → 具体的なフレームワーク・ライブラリ選定
- L1の非機能要件 → アーキテクチャパターン（モノリス/マイクロサービス等）
- L1のユーザーストーリー → 必要なAPIエンドポイント概要

**L3生成時の導出例:**
- L2のデータモデル → 各モジュールのCRUD操作定義
- L2のAPI概要 → 各エンドポイントの詳細仕様
- L2のセキュリティ → 認証・認可の実装詳細

**L4生成時の導出例:**
- L2の技術スタック → テストフレームワーク（例: Next.js → vitest + Playwright）
- L3の各モジュール → テストケース一覧
- L1の非機能要件 → パフォーマンステスト要件

### Step 4: ドキュメント生成
各ドキュメントを以下の構造で生成:

```markdown
---
node_id: "{自動生成}"
title: "{タイトル}"
wave: {N}
status: "draft"
depends_on: ["{上流node_id}", ...]
constrained_by: ["{制約元node_id}", ...]
source_files: []
last_updated: "{ISO 8601}"
checksum: "{SHA-256先頭8桁}"
---

# {タイトル}

## 1. 概要
{上流ドキュメントからの導出根拠を明記}

## 2. 制約事項
{constrained_byから継承した制約}

## 3. 詳細内容
{Wave・カテゴリに応じた本文}

## 4. 決定事項と根拠
{設計判断とその理由}

## 5. 下流への影響
{このドキュメントが下流に与える制約の明記}
```

### Step 5: 依存グラフの更新
`docs/codd-graph.json` の対応ノードのstatusを `"draft"` に更新し、エッジ情報を確定する。

### Step 6: 即時バリデーション
生成直後に `/codd-validate` 相当の軽量チェックを実行:
- Frontmatter必須フィールドの存在確認
- TODO/TBDマーカーの検出
- 空セクションの検出
問題があれば即座に修正して再生成する。

### Step 7: 生成レポート
生成されたドキュメント一覧と、各ドキュメントの導出根拠サマリーを出力。

## 制約
- 上流ドキュメントに明記されていない情報を推測で追加しない
- 推測が必要な箇所は `[要確認: ...]` マーカーを付けてユーザーに判断を委ねる
- 1つのWaveの生成が完了するまで次のWaveに進まない
```

---

## Skill 4: `/codd-validate`

**ファイル**: `.claude/commands/codd-validate.md`

```markdown
---
description: "設計書の品質ゲート検証。未決事項・メタコメント・空セクション・Frontmatter不備を検出し、下流への悪影響を遮断する。"
---

# CoDD 品質ゲート検証

## 入力
$ARGUMENTS: 検証対象の指定
- `--wave N` : Wave N のすべてのドキュメントを検証
- `--node NODE_ID` : 特定ノードのみ検証
- `--all` : 全ドキュメントを検証
- `--fix` : 検出された問題を自動修正する（可能なもののみ）

## 実行手順

### Step 1: 対象ドキュメントの収集
指定された範囲の `.md` ファイルを `docs/` 配下から収集する。

### Step 2: Frontmatter検証
各ドキュメントのFrontmatterに対して以下をチェック:
- [ ] `node_id` が存在し、命名規則 `L{wave}_{category}_{name}` に準拠
- [ ] `title` が存在し、空でない
- [ ] `wave` が 1-6 の整数
- [ ] `status` が有効な値 (`draft`, `review`, `approved`, `stale`)
- [ ] `depends_on` が配列で、参照先のnode_idが実在する
- [ ] `last_updated` が有効なISO 8601形式
- [ ] `checksum` が現在の内容と一致する（改ざん・未更新検出）

### Step 3: コンテンツ品質チェック
本文に対して以下を検出:

**🔴 ブロッカー（下流生成を阻止）:**
- `TODO`, `TBD`, `FIXME`, `HACK`, `XXX`, `要検討`, `未定`, `後で`
- 空セクション（見出し直後に本文がない、または本文が1行以下）
- `<!-- AI_META:`, `<!-- PLACEHOLDER`, `<!-- GENERATED` 等のメタコメント
- `{placeholder}`, `${...}`, `<TBD>` 等のテンプレート残留

**🟡 警告（レビュー推奨）:**
- 「おそらく」「たぶん」「〜かもしれない」等の曖昧表現
- 同一セクション内での矛盾する記述
- 上流ドキュメントとの不整合（depends_onの内容との齟齬）

**ℹ️ 情報:**
- ドキュメントの文字数・セクション数
- 最終更新からの経過日数

### Step 4: 依存関係の整合性チェック
- depends_onに指定されたドキュメントが実在するか
- 循環依存がないか
- Waveの逆転がないか（L3がL1に直接依存しているが、L2を経由していない等）

### Step 5: 検証レポートの出力

```
╔══════════════════════════════════════════════════╗
║           CoDD Validation Report                  ║
╠══════════════════════════════════════════════════╣
║ 検証対象: Wave 2 (5 documents)                    ║
╠══════════════════════════════════════════════════╣
║ 🔴 Blockers:  2                                   ║
║ 🟡 Warnings:  3                                   ║
║ ℹ️  Info:      5                                   ║
╠══════════════════════════════════════════════════╣
║                                                    ║
║ [BLOCK] L2_arch_data_model.md                      ║
║   Line 45: TODO: リレーション設計を確定する          ║
║   Line 78: 空セクション "## 5. インデックス戦略"     ║
║                                                    ║
║ [WARN] L2_arch_security.md                         ║
║   Line 23: 曖昧表現 "おそらくJWTで十分"              ║
║                                                    ║
║ Gate Status: ❌ BLOCKED (2 blockers found)          ║
║ → Wave 3の生成は許可されません                       ║
╚══════════════════════════════════════════════════╝
```

### Step 6: 自動修正（--fix指定時）
修正可能な問題を自動修正:
- Frontmatterの欠落フィールド補完
- checksumの再計算
- メタコメントの除去
- 空セクションへの上流情報からの内容導出

修正不可能な問題（設計判断を伴うTODO等）はユーザーに対話的に確認する。
```

---

## Skill 5: `/codd-implement`

**ファイル**: `.claude/commands/codd-implement.md`

```markdown
---
description: "承認済みの設計書群からソースコード・テストコードを一括生成する。"
---

# CoDD コード実装

## 入力
$ARGUMENTS: 実装対象の指定
- `--module MODULE_NAME` : 特定モジュールのみ実装
- `--wave N` : Wave Nに対応するコードを生成
- `--all` : 全設計書からコードを生成
- `--tests-only` : テストコードのみ生成
- `--dry-run` : 生成計画のみ出力（ファイル作成しない）

## 前提条件
- 対象Waveの設計書がすべて `/codd-validate` を通過していること（ブロッカーゼロ）
- L2（技術スタック）が確定し、statusが `approved` であること

## 実行手順

### Step 1: 技術スタックの確認
`docs/L2_architecture/tech_stack.md` を読み込み、以下を確認:
- 言語・フレームワーク
- パッケージマネージャ
- テストフレームワーク（導出原則で自動決定済み）
- ディレクトリ構造規約

### Step 2: 実装対象の設計書読み込み
L3（詳細設計）、L4（テスト戦略）、L5（API・スキーマ）のドキュメントを読み込み、以下を抽出:
- モジュール構造とインターフェース
- データモデルとバリデーションルール
- APIエンドポイント仕様
- エラーハンドリング仕様
- テストケース一覧

### Step 3: コード生成
設計書の内容に忠実にコードを生成する。生成ルール:

1. **型定義・インターフェース** を最初に生成
2. **データアクセス層** を次に生成
3. **ビジネスロジック層** を生成
4. **API/ルーティング層** を生成
5. **テストコード** を生成（テスト戦略に準拠）

各ファイルの先頭にコメントで対応する設計書のnode_idを記載:
```typescript
/**
 * @codd_source L3_design_auth_module
 * @codd_generated 2025-01-15T10:30:00Z
 */
```

### Step 4: Frontmatterのsource_files更新
生成したソースファイルのパスを、対応する設計書のFrontmatter `source_files` に追記する。

### Step 5: 依存グラフの更新
`docs/codd-graph.json` にソースファイルノードを追加し、設計書→コードのエッジを記録。

### Step 6: 生成コードの自己検証
- 静的解析（lint）の実行
- 型チェックの実行
- テストの実行
- エラーがあれば設計書を参照して自動修正

### Step 7: 実装レポート
生成ファイル一覧、テスト結果、設計書とのカバレッジ率を出力。
```

---

## Skill 6: `/codd-assemble`

**ファイル**: `.claude/commands/codd-assemble.md`

```markdown
---
description: "生成されたコード断片を結合し、設定ファイルを生成してビルド可能な状態に組み上げる。"
---

# CoDD アセンブル（ビルド準備）

## 入力
$ARGUMENTS: オプション
- `--check` : アセンブル可能か事前チェックのみ
- `--force` : 既存の設定ファイルを上書き

## 実行手順

### Step 1: 技術スタックからの設定ファイル導出
L2_tech_stackの内容から、必要な設定ファイルを導出して生成:

| 技術スタック | 生成される設定ファイル |
|-------------|---------------------|
| Next.js + TypeScript | `package.json`, `tsconfig.json`, `next.config.js`, `.eslintrc.json` |
| FastAPI + Python | `pyproject.toml`, `requirements.txt`, `.flake8` |
| Supabase | `supabase/config.toml`, マイグレーションファイル |
| Docker | `Dockerfile`, `docker-compose.yml` |

### Step 2: エントリーポイントの生成
- アプリケーションのメインエントリーポイント
- ルーティング定義の統合
- ミドルウェアのセットアップ

### Step 3: 環境変数テンプレートの生成
L2_securityおよびL3の各モジュールから必要な環境変数を抽出し、`.env.example` を生成。

### Step 4: 依存関係のインストール確認
`package.json` / `requirements.txt` 等の依存関係を解決:
- パッケージマネージャの実行（`npm install` / `pip install`）
- バージョン競合の検出と解決

### Step 5: ビルド検証
- ビルドコマンドの実行
- テストの全実行
- エラーがあれば該当する設計書を参照して修正

### Step 6: アセンブルレポート
```
╔══════════════════════════════════════════════════╗
║           CoDD Assembly Report                    ║
╠══════════════════════════════════════════════════╣
║ Generated config files: 8                         ║
║ Total source files: 24                            ║
║ Total test files: 18                              ║
║ Build status: ✅ SUCCESS                          ║
║ Test status: ✅ 47/47 passed                      ║
║ Coverage: 89%                                     ║
╚══════════════════════════════════════════════════╝
```
```

---

## Skill 7: `/codd-scan`

**ファイル**: `.claude/commands/codd-scan.md`

```markdown
---
description: "プロジェクト全体を走査し、Frontmatterから依存グラフを構築・更新する。"
---

# CoDD 依存グラフスキャン

## 入力
$ARGUMENTS: オプション
- `--rebuild` : 既存グラフを破棄して完全再構築
- `--format {json|mermaid|dot}` : 出力形式（デフォルト: json + mermaid）
- `--show` : グラフの可視化（Mermaid形式で出力）

## 実行手順

### Step 1: ドキュメント走査
`docs/` 配下のすべての `.md` ファイルを走査し、Frontmatterを解析する。

### Step 2: ソースコード走査
`src/` および `tests/` 配下のファイルを走査し、`@codd_source` コメントを検出する。

### Step 3: グラフ構築
すべてのノード（ドキュメント + ソースファイル）と、以下のエッジを構築:
- `depends_on` による依存エッジ
- `constrained_by` による制約エッジ
- `source_files` による実装エッジ

### Step 4: グラフ検証
- 孤立ノード（どこからも参照されず、何も参照しないドキュメント）の検出
- 循環依存の検出
- Wave階層の逆転の検出
- 参照先が存在しないエッジの検出

### Step 5: checksum検証
各ドキュメントの現在の内容からchecksumを再計算し、Frontmatterの値と比較。
不一致があればstatusを `stale` に変更。

### Step 6: グラフ出力

**JSON形式** (`docs/codd-graph.json`):
```json
{
  "version": "1.0",
  "generated_at": "2025-01-15T10:30:00Z",
  "statistics": {
    "total_nodes": 28,
    "total_edges": 45,
    "stale_nodes": 2,
    "orphan_nodes": 0,
    "circular_dependencies": 0
  },
  "nodes": [...],
  "edges": [...]
}
```

**Mermaid形式** (コンソール出力):
```mermaid
graph TD
    L1_req_overview[📋 Project Overview] --> L2_arch_system[🏗 System Architecture]
    L1_req_functional[📋 Functional Req] --> L2_arch_system
    L2_arch_system --> L3_design_auth[📐 Auth Module]
    L2_arch_system --> L3_design_user[📐 User Module]
    L3_design_auth --> L4_test_auth[🧪 Auth Tests]
    L3_design_auth --> src/auth/[💻 auth/]
    
    style L1_req_overview fill:#e8f5e9
    style L2_arch_system fill:#e3f2fd
    style L3_design_auth fill:#fff3e0
```

### Step 7: スキャンレポート
ノード数、エッジ数、問題の有無、staleノード一覧を出力。
```

---

## Skill 8: `/codd-impact`

**ファイル**: `.claude/commands/codd-impact.md`

```markdown
---
description: "仕様変更時に依存グラフを辿って影響範囲を特定し、トラフィックライト分類でAI自動修正を実行する。"
---

# CoDD 変更影響分析・自動修正

## 入力
$ARGUMENTS: 変更の指定（以下のいずれか）
- `--node NODE_ID --change "変更内容の説明"` : 特定ノードの変更を宣言
- `--file PATH` : 変更されたファイルを指定（git diffから自動検出）
- `--interactive` : 対話形式で変更内容を入力

変更情報: $ARGUMENTS

## 実行手順

### Step 1: 変更元の特定
変更されたドキュメントまたはファイルを特定し、`docs/codd-graph.json` から対応するノードを検索。

### Step 2: 依存グラフのトラバース
変更元ノードから下流方向へグラフを辿り、影響を受けるすべてのノードを列挙。

### Step 3: トラフィックライト分類
影響を受ける各ノードを以下の基準で分類:

**🟢 Green（自動更新可能）:**
- 変更元から直接依存（1ホップ）
- 変更内容が構造的（フィールド名変更、型変更、エンドポイント追加等）
- 変更の適用方法が機械的に導出可能
- 例: データモデルのフィールド追加 → API定義の更新 → テストケースの追加

**🟡 Amber（人間の確認が必要）:**
- 変更元から間接依存（2ホップ以上）
- 変更内容がアーキテクチャレベルの判断を伴う
- 複数の設計選択肢がある
- 例: 認証方式の変更 → セキュリティ設計の見直し → 複数モジュールへの影響

**⚪ Gray（参考情報）:**
- 直接の変更は不要だが、コンテキストとして認識すべき
- 例: 非機能要件ドキュメントの参考情報

### Step 4: 影響分析レポートの出力

```
╔══════════════════════════════════════════════════════════════╗
║                CoDD Impact Analysis Report                    ║
╠══════════════════════════════════════════════════════════════╣
║ 変更元: L2_arch_data_model (データモデル)                      ║
║ 変更内容: "Userテーブルにroleフィールド(enum)を追加"             ║
╠══════════════════════════════════════════════════════════════╣
║                                                                ║
║ 🟢 Green - 自動更新対象 (4 nodes):                              ║
║   ├─ L3_design_auth_module.md     → role判定ロジック追加        ║
║   ├─ L3_design_user_module.md     → CRUD操作にroleフィールド追加 ║
║   ├─ L5_api_user_endpoints.md     → レスポンススキーマ更新       ║
║   └─ src/models/user.ts           → roleフィールド・型定義追加   ║
║                                                                ║
║ 🟡 Amber - 要確認 (2 nodes):                                   ║
║   ├─ L2_arch_security.md          → RBAC設計の見直し検討        ║
║   └─ L4_test_auth.md              → 権限テストシナリオの再設計   ║
║                                                                ║
║ ⚪ Gray - 参考 (1 node):                                       ║
║   └─ L1_req_non_functional.md     → セキュリティ要件の参照       ║
║                                                                ║
║ 推定作業量: Green=自動(〜5分), Amber=レビュー込み(〜30分)        ║
╚══════════════════════════════════════════════════════════════╝
```

### Step 5: ユーザー確認
Amber項目について、修正方針をユーザーに確認:
- 各Amberノードの修正オプションを提示
- ユーザーの判断を待つ

### Step 6: 自動修正の実行
確認後、以下の順序で修正を実行:

1. **Green ノードの自動更新**
   - 設計書のFrontmatter更新（checksum, last_updated, status→"draft"）
   - 本文の該当箇所を修正
   - 対応するソースコードの修正
   - 対応するテストコードの修正

2. **Amber ノードの修正**（ユーザー承認済みの方針に基づく）
   - 設計書の修正
   - ソースコード・テストの修正

3. **全修正後の整合性再チェック**
   - `/codd-validate --all` 相当の検証を実行
   - 修正によって新たな不整合が発生していないか確認

### Step 7: 依存グラフの更新
- 修正されたノードのchecksum再計算
- status更新（stale → draft）
- `docs/codd-graph.json` の更新

### Step 8: 修正サマリーの出力
変更されたファイル一覧、修正内容のdiff要約、テスト結果を出力。
```

---

## Skill 9: `/codd-extract`

**ファイル**: `.claude/commands/codd-extract.md`

```markdown
---
description: "既存コードベース（Brownfield）から静的解析で依存グラフ・設計書を逆生成するリバースエンジニアリング機能。"
---

# CoDD リバースエンジニアリング（設計書抽出）

## 入力
$ARGUMENTS: 対象の指定
- `--src PATH` : 解析対象のソースディレクトリ（デフォルト: `src/`）
- `--depth {shallow|deep}` : 解析深度（shallow=構造のみ, deep=ロジック含む）
- `--framework {auto|next|fastapi|...}` : フレームワーク指定（auto=自動検出）

## 実行手順

### Step 1: プロジェクト構造の静的解析
AIに依存せず、ファイルシステムの走査で以下を検出:
- ディレクトリ構造
- ファイル拡張子・言語の分布
- `package.json`, `pyproject.toml` 等の設定ファイル
- フレームワーク・ライブラリの特定

### Step 2: コード構造の解析
ソースコードを解析し、以下を抽出:
- モジュール・クラス・関数の一覧
- import/require文からのモジュール間依存関係
- APIルーティング定義（エンドポイント一覧）
- データモデル定義（ORM、型定義等）
- テストファイルとテスト対象の対応関係

### Step 3: 逆方向の設計書生成
抽出した情報から、CoDDのWave構造に沿った設計書を逆生成:

**L2相当（自動生成）:**
- `L2_arch_system_architecture.md` - 検出されたアーキテクチャ概要
- `L2_arch_tech_stack.md` - 使用技術スタック
- `L2_arch_data_model.md` - 検出されたデータモデル

**L3相当（自動生成）:**
- 各モジュールの詳細設計書
- API仕様書（検出されたエンドポイントから）

**L5相当（自動生成）:**
- APIスキーマ定義（コードから逆生成）
- DBスキーマ定義（マイグレーションから逆生成）

### Step 4: Frontmatterの付与
逆生成された各設計書にCoDD Frontmatterを自動付与し、`source_files` に対応するソースコードパスを記載。

### Step 5: 依存グラフの構築
`docs/codd-graph.json` を生成。ソースコード→設計書の逆方向エッジも含める。

### Step 6: ギャップ分析
既存コードと生成された設計書の間のギャップを報告:
- 設計書がないモジュール（テスト不足等）
- 使われていないコード（Dead code候補）
- 設計書はあるが実装が不完全な箇所

### Step 7: 抽出レポート
```
╔══════════════════════════════════════════════════════════════╗
║                CoDD Extract Report                            ║
╠══════════════════════════════════════════════════════════════╣
║ Framework detected: Next.js 14 + TypeScript                   ║
║ Source files analyzed: 156                                    ║
║ Modules detected: 12                                         ║
║ API endpoints detected: 34                                   ║
║ Data models detected: 8                                      ║
║ Test files found: 23 (coverage estimate: 67%)                ║
╠══════════════════════════════════════════════════════════════╣
║ Design docs generated: 18                                    ║
║ Dependency edges: 52                                         ║
║ Gaps found: 3 (modules without test coverage)                ║
╚══════════════════════════════════════════════════════════════╝
```

## 注意事項
- この機能はAIを使わず静的解析のみで動作する（AI非依存）
- 生成された設計書のstatusは `draft` で、人間のレビューが必要
- L1（要件定義）は自動生成しない（人間が記述すべき領域）
```

---

## スキル間の依存関係・推奨ワークフロー

```mermaid
graph TD
    A["/codd-init"] --> B["/codd-plan"]
    B --> C["/codd-generate --wave 2"]
    C --> D["/codd-validate --wave 2"]
    D -->|Pass| E["/codd-generate --wave 3"]
    D -->|Fail| C
    E --> F["/codd-validate --wave 3"]
    F -->|Pass| G["... (Wave 4-6)"]
    G --> H["/codd-implement"]
    H --> I["/codd-assemble"]
    
    J["仕様変更発生"] --> K["/codd-impact"]
    K --> L["Green: 自動修正"]
    K --> M["Amber: 人間レビュー"]
    L --> D2["/codd-validate"]
    M --> D2
    
    N["既存プロジェクト"] --> O["/codd-extract"]
    O --> B
    
    P["/codd-scan"] -.->|随時実行| Q["依存グラフ更新"]
    
    style A fill:#c8e6c9
    style B fill:#c8e6c9
    style C fill:#bbdefb
    style D fill:#fff9c4
    style H fill:#e1bee7
    style I fill:#e1bee7
    style K fill:#ffccbc
    style O fill:#d7ccc8
```

### Greenfield（新規プロジェクト）フロー
```
/codd-init → /codd-plan → /codd-generate (Wave 2→6) 
→ /codd-validate (各Wave後) → /codd-implement → /codd-assemble
```

### Brownfield（既存プロジェクト）フロー
```
/codd-extract → /codd-scan → /codd-plan (差分計画) 
→ 不足設計書の /codd-generate → /codd-validate
```

### 仕様変更対応フロー
```
/codd-impact → Green自動修正 + Amberレビュー 
→ /codd-validate → /codd-implement (差分) → /codd-assemble
```

---

この設計により、CoDDの3つのコア原則（導出原則・Wave階層・3つのコアアクション）がすべてClaude Codeのスキルとして実装可能になります。各スキルは独立して実行でき、かつワークフロー全体として整合性駆動の開発パイプラインを構成します。