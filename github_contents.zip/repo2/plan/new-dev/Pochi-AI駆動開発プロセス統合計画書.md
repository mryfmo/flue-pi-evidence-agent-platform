# Pochi AI駆動開発プロセス統合計画書

作成日: 2026-05-18
更新日: 2026-05-18（worktree並列実装戦略を統合）
ステータス: 計画中

---

## 目次

1. [背景と目的](#1-背景と目的)
2. [全体アーキテクチャ：3層構造](#2-全体アーキテクチャ3層構造)
3. [現在の開発フロー（As-Is）](#3-現在の開発フローas-is)
4. [強化後の開発フロー（To-Be）](#4-強化後の開発フローto-be)
5. [施策1：DESIGN.md の導入](#5-施策1designmd-の導入最優先即効性あり)
6. [施策2：Everything As Code — 設計書のリポジトリ化](#6-施策2everything-as-code--設計書のリポジトリ化)
7. [施策2-b：worktree並列実装戦略](#6-b-施策2-bworktree並列実装戦略layer-b-実装パターン)
8. [施策3：CoDD による整合性の自動追跡](#7-施策3codd-による整合性の自動追跡)
9. [役割分担](#8-役割分担)
10. [比較表：現状 vs 施策段階ごとの変化](#9-比較表現状-vs-施策段階ごとの変化)
11. [関連ドキュメント](#10-関連ドキュメント)
12. [初手タスクリスト](#11-初手タスクリスト幅広く浅く検証)

---

## 1. 背景と目的

### 参照した知見

本計画書は以下6ファイルの知見を統合して策定した。

| ファイル | 提供した知見 |
|---|---|
| `整合性駆動開発CoDD爆誕.md` | プロンプト→コンテキスト→ハーネス→CoDDという方法論の変遷。変更時の整合性維持がAI駆動開発の未解決問題であるという指摘 |
| `CoDD（整合性駆動開発）Claude Code Skill 設計書.md` | codd-init / codd-plan / codd-generate / codd-validate / codd-implement / codd-assemble / codd-scan / codd-impact / codd-extract の9スキル設計 |
| `Pochi-AI駆動開発プロセス戦略.md` | EaC・ハーネス・CoDDの3層アーキテクチャ。DESIGN.md→docs/標準化→CoDD の導入順序の判断 |
| `Everything As Code.md`（移動前） | 「人間しか知らない情報をなくす」ことがAI駆動開発の前提条件。設計書・業務フロー・インフラをリポジトリに集約する必要性 |
| `DESIGN.md ベストプラクティス・レポート.md` | DESIGN.mdの9セクション構成・記述ベストプラクティス・CLAUDE.mdとの役割分担 |
| `クラメソのデザインガイドをDESIGN.mdで実装してみた.md` | DESIGN.md導入でプロンプト長70%削減の実績。スキルとのハイブリッド運用の具体例 |

### 🎯 重要ポイント：DESIGN.md導入の本質的な目的

**「UI表現の判断を、人間の裁量からエージェントの自動判断へ移す」**

2026-05-15のCCネタ発掘会議事録より：開発者（細井さん）がTDD開発中にコーディングエージェントへ独自の指示（`st.caption`で常時表示）を行い、UIの表現方法が担当者の判断に依存してしまった。YTの指摘：「本来はヘルプ（`help=`ツールチップ）で表示すべきケースを、キャプションで常時表示してしまった。人依存にするとブレる。」

DESIGN.mdが解決すべきのは「プロンプト削減」や「ツール横断共有」だけでなく、**`st.caption`か`help=`か、`st.warning`か`st.info`か、といったStreamlit固有のUI表現の選択を、コーディングエージェントが自律的に正しく判断できるようにする**ことである。UIガイドライン（原則①〜⑦）の内容をDESIGN.mdのルールとして構造化し、エージェントに自動適用させることがこの計画の核心目的。

---

### 解決する問題

Pochiスキル群（27スキル・5カテゴリ）はフェーズ別に整備されているが、3つの構造的課題がある。

> **スキル数について**: marketplace.json登録数は37だが、archive/移行済みを除いた有効スキルは27。本計画書では有効スキル数27を使用する。

| 課題 | 現状 | 影響 |
|---|---|---|
| **①知識の散在** | DB設計・業務フロー・議事録がGoogleスプレッドシート等に残り、AIがアクセス不能 | pochi-coding-agentがコンテキスト不足で動作する |
| **①-b Snowflakeビュー情報の未活用** | アプリが参照するSnowflakeビューのカラム構造がAlation CSVにあるが、仕様策定時にAIがアクセスしていない | pochi-spec-initializerがDB構造を把握せずに仕様を生成するため、後工程でカラム不整合が発生する |
| **②デザインルールのプロンプト依存** | UIガイドライン7原則はあるが、AI生成時に毎回CLAUDE.mdからの参照指示を書く必要がある | スキル呼び出しプロンプトが長くなり、ツール横断で共有できない |
| **③変更時の整合性保証がない** | spec.jsonを変更しても、plan.json・実装コード・テストへの波及追跡が手動 | 要件変更のたびに人間が影響範囲を追う |

---

## 2. 全体アーキテクチャ：3層構造

```
┌─────────────────────────────────────────────────────────┐
│  Layer A: Everything As Code（知識の構造化）            │
│  DESIGN.md + docs/設計書（spec.json / plan.json /       │
│  operation-flow.md / db-design.md）                     │
├─────────────────────────────────────────────────────────┤
│  Layer B: ハーネスエンジニアリング（制御の自動化）       │
│  CLAUDE.md + Hooks + Skillsチェーン                     │
│  （既存27スキルはここに位置する）                        │
├─────────────────────────────────────────────────────────┤
│  Layer C: Coherence-Driven Development（整合性の維持）   │
│  codd-scan / codd-impact で変更を依存グラフに沿って追跡 │
└─────────────────────────────────────────────────────────┘
```

**方針**: Layer A（DESIGN.md）から始め、効果を確認しながら Layer B→C へ段階的に展開する。Layer A が整備されない限り、Layer C の依存グラフの対象となる設計書が存在しないため、独立して着手できない。

> **スキル数について**: 旧版で「既存25スキル」と表記していたものは転記ミス。正しくは「既存27スキル」（marketplace.json登録37から archive/移行済みを除いた有効数）。

### 2-1. CoDDのノード定義

CoDDの依存グラフにおけるノードは `docs/features/{FEATURE-ID}/spec.json` とする。

| 成果物 | CoDDノード扱い | 理由 |
|---|---|---|
| `spec.json` | ✅ ノード（正） | 依存・データスキーマ・UI仕様の Source of Truth |
| `plan.json` | ✅ ノード（派生） | spec.json から生成。spec変更時に更新対象 |
| `spec.md` | ❌ ミラー（グラフ非登録） | spec.json から自動生成。手動編集禁止 |
| `plan.md` | ❌ ミラー（グラフ非登録） | plan.json から自動生成。手動編集禁止 |
| `feature.md` | ❌ ミラー（グラフ非登録） | spec.json + plan.json の人間可読統合版。手動編集禁止 |

**フロントマター仕様（spec.json への追加形式）**:

```yaml
---
codd:
  node_id: "{FEATURE-ID}_spec"
  wave: 1
  depends_on: []          # 依存する node_id（例: "feature-002_spec"）
  source_files: ["app/*.py", "tests/"]
  last_updated: "YYYY-MM-DD"
---
```

---

## 3. 現在の開発フロー（As-Is）

```
pochi-spec-initializer（spec.json + plan.json生成）
  ↓
pochi-coding-agent（実装）
  ↓
pochi-unit-test-generator / pochi-test-orchestrator（テスト）
```

**問題点**:
- 業務フロー・DB設計がリポジトリ外（GSheets等）に残る
- 設計書の出力先が各スキルで統一されていない（spec-initializerは `pochi-spec-initializer/specs/features/[FEATURE-ID]/`）
- 変更発生時の影響範囲を人間が手動で追う

---

## 4. 強化後の開発フロー（To-Be）

```
pochi-spec-initializer
    → アプリコードを静的解析して参照ビューを特定（AI-072対応）
    → Alation CSVからカラム情報を抽出し db-context.md を生成
    → spec.json + plan.json → docs/features/{FEATURE-ID}/ にコミット
    + DESIGN.md 参照による画面設計（Layer A・施策1）
  → pochi-coding-agent（worktreeモード）
      ↓ フェーズ0: spec.json を並列化可能な単位に分割
      ↓ フェーズ1: タスク数分の git worktree を自動生成
      ↓ フェーズ2: 実装サブエージェントを並列実行（各エージェントが git commit まで完了）
      ↓ フェーズ3: 全ブランチをメインにマージ → worktree クリーンアップ
      （並列実装戦略の詳細は §6-b 参照）
  → codd-impact（変更発生時）
      → Green: git commit まで自動化（§7参照）
      → Amber: 担当者に明示的にアサイン
      → Gray: 参考情報
  → pochi-unit-test-generator → pochi-test-orchestrator → pochi-e2e-test-generator
```

---

## 5. 施策1：DESIGN.md の導入（最優先・即効性あり）

### 概要

Pochiアプリ用デザインシステムを `DESIGN.md` 1ファイルに集約し、プロジェクトルートに配置する。

```
pochi-dp-developer-docs/
└── DESIGN.md   ← 新規作成
```

### DESIGN.md の構成（9セクション標準形式）

YAMLフロントマターにデザイントークンを機械可読な形式で宣言し、Markdownボディに自然言語のルールを記述する（W3C Design Tokenを参考にした機械可読形式）。

```markdown
---
design_tokens:
  colors:
    primary:    "#1E88E5"   # 主要ボタン・強調
    background: "#F4F4F4"   # ページ全体の単一背景
    surface:    "#FFFFFF"   # カード・モーダル
    border:     "#DDDDDD"   # 区切り線（1px solid）
    text:       "#1A1C1E"   # 見出し・本文
    error:      "#D32F2F"   # バリデーションエラー
  spacing:
    base:    "8px"
    section: "24px"
  border_radius: "0px"      # フラットデザイン（角丸なし）
  typography:
    font_family: "Noto Sans JP, sans-serif"
---

## 1. ビジュアルテーマと雰囲気
## 2. カラーパレットと役割
## 3. タイポグラフィ規則
## 4. コンポーネントスタイル（Streamlit固有）
## 5. レイアウト原則（UIガイドライン7原則の要約）
## 6. 深さとエレベーション
## 7. Do's and Don'ts（禁止事項・アンチパターン）
## 8. レスポンシブ動作
## 9. エージェント向けプロンプトガイド
```

### DESIGN.md の配置と配布方針

| 項目 | 方針 |
|---|---|
| **中央正本** | `pochi-dp-developer-docs/DESIGN.md`（現状維持） |
| **各app repoへの配布** | コピー不要。各app repoの `.claude/CLAUDE.md` に参照指示を1行記述するだけで解決 |
| **エージェント参照方法** | CLAUDE.md 記載の参照パスをエージェントが起動時に読み込む（`pochi-coding-agent` / `pochi-ui-generator` ともに自動適用） |
| **将来の同期** | DESIGN.md に破壊的変更が発生した場合のみ、各app repoのCLAUDE.md参照先を更新 |

### CLAUDE.md への追記（各app repo用テンプレート）

```markdown
### DESIGN.md の参照
UIやコンポーネントを生成・修正する際は、必ずリポジトリルートの `DESIGN.md` の
デザイントークンを参照し、厳格に従うこと。スキル呼び出し時にデザイン指定を
プロンプトで重複して書かない。
```

### スキルとのハイブリッド運用

| 役割 | スキル | DESIGN.md |
|---|---|---|
| 対象 | ロゴ・PDF生成など実ファイルが必要な処理 | 色・余白・フォント等のテキスト宣言 |
| 発動 | 明示的な呼び出しが必要 | リポジトリに置くだけで参照される |
| ツール | Claude Code固有 | Cursor等ツール横断で共有可能 |

**ルール**: テキスト中心のデザインルールの正は DESIGN.md に寄せる。ロゴ等のバイナリアセットはスキル側に残す。

### 期待効果

| 現状 | 導入後 |
|---|---|
| pochi-ui-generator起動のたびに色・余白・禁止事項をプロンプトに書く | DESIGN.mdを参照するよう CLAUDE.md に1行書くだけで自動適用 |
| スキル呼び出しプロンプトが長い | **約70%削減（参考値）** |
| Cursor等の他ツールで同じルールを使えない | ファイルを持ち込むだけで共有可能 |

> **70%削減について**: クラスメソッド社がStreamlit + Claude Codeに近い構成で計測した1回の実測値（約11,520文字 → 約3,513文字）。Pochiのスキル構成・チーム規模・アプリ複雑度によって削減率は変動する。**Step 1完了後に実際のプロンプト行数をBefore/Afterで計測し、Pochi固有の効果を確認する**。

### DESIGN.md の更新ガバナンス

DESIGN.mdを「信頼できる単一情報源」とするために、以下の運用ルールをStep 1の成果物に含める。

| 観点 | ルール |
|---|---|
| **変更承認** | デザイントークンの変更はPRレビュー必須。破壊的変更（色・余白の変更）は開発者チャンネルで事前周知 |
| **バージョニング** | `DESIGN.md` のYAMLフロントマターに `version:` フィールドを設け、破壊的変更時にインクリメント |
| **Streamlit設定との同期** | `.streamlit/config.toml` の `primaryColor` 等はDESIGN.mdのデザイントークンと手動で一致させる（自動同期は施策3以降で検討） |
| **陳腐化防止** | UIスキル（pochi-ui-generator等）の出力でデザイン崩れが発生した場合、DESIGN.mdの更新を起票する |

### 施策1 完了ゲート

- [x] DESIGN.md が pochi-dp-developer-docs ルートに存在し、`version:` フィールドでバージョン管理されている
- [ ] 主要スキル（pochi-coding-agent / pochi-ui-generator）の起動プロンプトでデザイン指定の重複記述がゼロになる
- [ ] 3件の実案件で Before/After のプロンプト行数を計測し、削減効果を確認
- [ ] UIレビュー差し戻し（`st.caption` / `help=`、`st.warning` / `st.info` の表現ブレ）が月次で0件を維持

---

## 6. 施策2：Everything As Code — 設計書のリポジトリ化

### docs/ ディレクトリ構造の設計判断（Step 2着手前に確定が必要）

**重要**: spec.jsonの出力先を `docs/` 直下に統一する案には、複数フィーチャー並行開発時に `docs/spec.json` が1ファイルに競合するという構造的問題がある。現状の `pochi-spec-initializer/specs/features/[FEATURE-ID]/` はこの問題を回避している。

以下の3案を比較し、Step 2着手前に方針を確定する。

| 案 | ディレクトリ構成 | メリット | デメリット |
|---|---|---|---|
| **A: フィーチャー別**（推奨） | `docs/features/{FEATURE-ID}/spec.json` | 並行開発で競合しない。現状からの移行コスト小 | パスが長くなる |
| **B: フラット** | `docs/spec.json` | シンプル | フィーチャー並行開発で競合。単一機能アプリ限定 |
| **C: 現状維持** | `pochi-spec-initializer/specs/features/[FEATURE-ID]/` | 変更不要 | ドキュメントとコードが分離したまま |

**推奨: 案A**。現状のFEATURE-IDディレクトリ構造を活かしつつ、アプリリポジトリ内の `docs/` 配下に移動する。

### アプリ1本あたりのミニマムEaC構成（案A前提）

「今開発している機能の設計書だけMarkdown化してソースコードと同じディレクトリに置く」（EaC記事の現実的な第一歩）をPochiに対応させた最小定義。

```
<app-repo>/
├── DESIGN.md                              ← 共通（pochi-dp-developer-docsのCLAUDE.md参照経由）
└── docs/
    ├── features/
    │   └── {FEATURE-ID}/
    │       ├── spec.json                  ← 正本（pochi-spec-initializer生成・人間編集可）
    │       ├── spec.md                    ← 自動生成・手動編集禁止（spec.jsonのミラー）
    │       ├── plan.json                  ← 正本（pochi-spec-initializer生成・人間編集可）
    │       ├── plan.md                    ← 自動生成・手動編集禁止（plan.jsonのミラー）
    │       └── db-context.md              ← 自動生成（Alation CSV抽出）
    └── design/
        ├── operation-flow.md              ← operation-flow-generator が出力
        └── hypothesis.md                  ← hypothesis-generator が出力
```

> **ミラーファイルの生成タイミング**: `pochi-spec-initializer` が spec.json / plan.json 生成直後に Markdown変換して出力する。生成トリガーはスキル実行時のみ（自動ウォッチは施策3以降）。

この状態が「ミニマムEaC」。`pochi-coding-agent` が spec.json / plan.json / DESIGN.md を参照してコンテキストフルに動作できる最低条件。

### docs/ 配下の責務分離ルール

**判定基準**: 「複数フィーチャーで共通か、単一フィーチャー固有か」

| ディレクトリ | ファイル | 対象範囲 | 生成契機 | 並行開発の競合リスク |
|---|---|---|---|---|
| `docs/design/` | `operation-flow.md` | **アプリ全体**の業務フロー | アプリ初期立ち上げ時のみ | なし（1ファイル・変更頻度低） |
| `docs/design/` | `hypothesis.md` | **アプリ全体**の仮説・目的・制約 | アプリ初期立ち上げ時のみ | なし（1ファイル・変更頻度低） |
| `docs/features/{FEATURE-ID}/` | `spec.json` | **機能単位**の仕様 | 各フィーチャー開発時 | なし（FEATURE-ID分離） |
| `docs/features/{FEATURE-ID}/` | `plan.json` | **機能単位**のタスク分解 | spec.json凍結後 | なし |
| `docs/features/{FEATURE-ID}/` | `db-context.md` | **機能単位**のビュー・カラム情報 | pochi-spec-initializer実行時 | なし |

### Skill出力先の標準化

現状、各スキルの出力先が統一されていない。以下を標準とする（移行方針: 新規アプリから適用。既存アプリは任意移行）。

| スキル | 現状の出力先 | 標準化後の出力先 |
|---|---|---|
| pochi-spec-initializer | `pochi-spec-initializer/specs/features/[FEATURE-ID]/` | `docs/features/{FEATURE-ID}/` |
| operation-flow-generator | 未定義 | `docs/design/operation-flow.md` |
| hypothesis-generator | 未定義 | `docs/design/hypothesis.md` |

**既存スクリプト・スキルへの影響確認**: Step 2着手前に `pochi-spec-initializer` のSKILL.mdおよび `pochi-coding-agent` のSKILL.mdで参照パスがハードコードされていないかを確認し、必要に応じてパスを更新する。

### pochi-spec-initializer へのAlationビュー情報組み込み（AI-072対応）

**背景**: 2026-05-14のバグ振り返り会（AI-072）で提起された課題。アプリが参照するSnowflakeビューのカラム情報をAlation CSVから取得し、仕様策定フェーズに組み込むことで、後工程でのカラム不整合を防止する。

**実現方法（検討案）**:

| ステップ | 内容 |
|---|---|
| 1. ビュー特定 | `pochi-spec-initializer` 起動時に、アプリコードを静的解析して参照ビュー名を特定する |
| 2. カラム情報取得 | ローカルのAlationメタデータCSV（`plan/ALADIN-DWH/alation-meta/`）から対象ビューのカラム一覧を検索・抽出する |
| 3. コンテキスト注入 | 取得したカラム情報をspec.json生成プロンプトのコンテキストとして渡す |
| 4. 仕様への反映 | spec.jsonの `data_schema` セクションにビュー名・カラム名・型を明示的に記載する |

**出力先（案Aを前提）**:
```
docs/features/{FEATURE-ID}/
├── spec.json       ← data_schemaにビュー情報を含む
└── db-context.md   ← Alation CSVから抽出したビュー・カラム情報の人間可読サマリ
```

**ビュー特定の優先順位（コード未存在時のフォールバック）**:

| 優先度 | 情報ソース | 適用条件 |
|---|---|---|
| 1 | アプリコード静的解析 | `app/*.py` が存在する場合（既存アプリ・既実装機能） |
| 2 | DB設計文書 / 既存SQL | `docs/db-context.md` や `.sql` ファイルが存在する場合 |
| 3 | 人間による手動指定 | 新規アプリ・新規機能で参照ビューが未実装の場合 |

> **注意**: 新規機能仕様策定時はコードが存在しないため、優先度2〜3が主な手段となる。

**制約・注意事項**:
- Alation CSVは巨大なため、ビュー名を特定してから**ピンポイントで行を抽出**する（全件ロードは禁止）
- CSVの参照はスキル内部で`grep`相当の絞り込みを行い、LLMに全量を渡さない
- `db-context.md` のコミット可否・更新責任・鮮度基準は各app repoで文書化する（Alation CSVは機密情報を含む可能性があるため、コミット前にアクセス権限を確認）

**CoDD Layer Aとしての位置づけ**: このDB情報の取得・格納は「人間しか知らない情報をなくす」EaCの典型実装。Alation CSVというローカルリソースを使ってSnowflakeのスキーマ知識をリポジトリ上のコンテキストに変換する。施策3（CoDD）の `source_files` にこの `db-context.md` を登録することで、ビュー廃止時の影響追跡（codd-impact）にも連動する。

### 施策2 完了ゲート

- [ ] 新規アプリ1本以上で `docs/features/{FEATURE-ID}/` が標準出力先として機能している
- [ ] pochi-spec-initializer が app repo の `docs/` に出力先を指定可能（パラメータ化またはSKILL.md更新）
- [ ] `db-context.md` が Alation CSV から自動抽出され生成されることを3件以上で確認
- [ ] `db-context.md` のコミット可否・更新責任・鮮度基準を各app repoで文書化済み

---

## 6-b. 施策2-b：worktree並列実装戦略（Layer B 実装パターン）

> **出典**: `plan/new-dev/worktree/pochi-worktree-strategy.md`（2026-05-15 CCネタ発掘会 AI-075/AI-076 提起、YT）および `plan/new-dev/worktree/RM-memo.md`（松本氏 90ブランチ検証）

### 概要と目的

spec.json の仕様を**並列化可能な単位に分割**し、タスクごとに git worktree を生成して実装サブエージェントを並列実行する。各サブエージェントが `git commit` まで完了することで、仕様単位のコミット粒度が揃った実装が自動的に生成される。

**狙い**:
- 大きな仕様の一括コミットによる可視性低下を解消
- 直列処理を並列化して開発スピードを向上
- 6月の吉行チームへの訴求：「作った後は手離れ」「UIデザイン品質の担保」

### 前提：settings.json への許可設定

並列実行中に permission prompt が頻発して自走が止まらないよう、事前に以下を許可する（松本氏検証済み）。

```json
"allow": [
  "Bash(git rev-parse:*)",
  "Bash(git branch:*)",
  "Bash(git worktree add:*)",
  "Bash(git worktree remove:*)",
  "Bash(git worktree list:*)",
  "Bash(git checkout:*)",
  "Bash(git merge:*)",
  "Write(.worktrees/**)",
  "Read(.worktrees/**)"
]
```

### 実装フロー（フェーズ0〜3）

#### フェーズ0：仕様分析・タスク分割（メインエージェント）

`spec.json` を読み込み、並列化可能な単位に分割して `.claude/work/worktree-plan.md` に書き出す。

| 分割単位 | 並列化可否 | 備考 |
|---|:---:|---|
| 独立ページ（page_A / page_B） | ✅ 可 | session_state が分離されていれば衝突しない |
| 共通Snowflakeクエリ関数 | ❌ 先行 | 先にmainへコミットしてからworktree作成 |
| 独立した集計ロジック | ✅ 可 | 異なるビューを参照する場合は衝突しない |
| Streamlit UI コンポーネント | ⚠️ 要確認 | 同一ファイルに複数実装する場合は直列が安全 |

#### フェーズ1：worktree生成（メインエージェント）

```bash
REPO_ROOT=$(git rev-parse --show-toplevel)
WORKTREE_BASE="${REPO_ROOT}/../.worktrees/pochi-feature"
BASE_BRANCH=$(git branch --show-current)
mkdir -p "$WORKTREE_BASE"

git worktree add -b feature/task-1 "$WORKTREE_BASE/task-1" "$BASE_BRANCH"
git worktree add -b feature/task-2 "$WORKTREE_BASE/task-2" "$BASE_BRANCH"
# タスク数分だけ繰り返す
```

**注意**: 共通インフラ（共通関数・共通クエリ）はworktree作成**前**にコミット済みであること。

#### フェーズ2：並列実装（実装サブエージェント × N）

各サブエージェントに渡す指示：

```
対象タスク: {task_name}
worktreeディレクトリ: {worktree_base}/task-N
ブランチ名: feature/task-N
仕様書参照: docs/features/{FEATURE-ID}/spec.json

作業完了後に git commit まで実施すること。
コミットメッセージは「feat: {task_name} を実装」形式。
```

**並列実行数の目安**（松本氏の90ブランチ検証より）:

| タスク数 | 推奨並列数 | 備考 |
|:---:|:---:|---|
| 2〜4 | 2〜4 | 基本。全タスク並列でOK |
| 5〜10 | 4〜5 | バッチを2回に分ける |
| 10超 | バッチ4〜5単位 | 90ブランチ実績あり。許可設定の事前整備が必須 |

#### フェーズ3：マージ・クリーンアップ（メインエージェント）

```bash
cd "$REPO_ROOT"
git checkout "$BASE_BRANCH"
git merge feature/task-1 --no-edit
git merge feature/task-2 --no-edit
# worktree削除
git worktree remove "$WORKTREE_BASE/task-1"
git worktree remove "$WORKTREE_BASE/task-2"
git branch -d feature/task-1 feature/task-2
```

### Pochi固有の注意点

**session_state の衝突防止**: 並列実装したページが同一キーを使うとコンフリクトの温床になる。各ページのキーにページ名をプレフィックスとして付ける。

```python
# ✅ 推奨
st.session_state["page_a_search_conditions"] = ...
# ❌ 危険（他ページと衝突する可能性）
st.session_state["search_conditions"] = ...
```

**Snowflake接続**: 各サブエージェントが独立したセッションを持つ。pochilib の接続管理に従いエージェントごとに独立接続する（グローバルセッション共有は禁止）。

### pochi-coding-agent への組み込み方針

**推奨：方針A**（段階的アプローチ）
1. `pochi-coding-agent` に「worktreeモードフラグ」を追加（例: `use_worktree: true`）
2. worktreeモード時のみフェーズ0〜3のフローを実行
3. 安定後に独立スキル化を検討

スキル仕様の詳細は `plan/new-dev/worktree/clean-arch-refactoring.md`（メイン調整役）および `plan/new-dev/worktree/clean-arch-implementer.md`（サブエージェント仕様）を参照。

### git commit メッセージ規約

```
{type}: {仕様名 or タスク名} を実装

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
```

| type | 用途 |
|---|---|
| `feat` | 新機能実装 |
| `fix` | バグ修正 |
| `refactor` | リファクタリング（機能変更なし） |
| `test` | テストコード追加・修正 |

### 施策2-b 完了ゲート（フィジビリティ確認・AI-076対応）

- [ ] Pochi既存アプリで `git worktree add` が正常動作するか（ローカル検証済み）
- [ ] settings.json の事前許可設定で permission prompt 頻発が解消されることを確認
- [ ] worktreeブランチのマージ時にコンフリクトが発生するパターンを把握し、回避策をドキュメント化
- [ ] pochi-coding-agent に worktreeモードフラグを追加済み
- [ ] フィジビリティ確認結果を `plan/new-dev/worktree/feasibility-results.md` に記録済み

---

## 7. 施策3：CoDD による整合性の自動追跡

### CoDDとは

CoDD（Coherence-Driven Development / 整合性駆動開発）は、設計書同士の依存関係をMarkdownフロントマターで宣言し、変更時に依存グラフを辿って影響範囲を自動特定する方法論。`pip install codd-dev` で提供されるCLIツール。

> **codd-devパッケージのリスク評価**: 2026年4月時点でv1.2.0。init / scan / impact / validate / generate / plan / implement / review / hooks は「安定」、extract / propagate / restore は「実験的」。本番ワークフロー組み込み前に以下を実施する：
> - **PoC期間（Step 3前半）**: 既存Pochiアプリ1本に限定して試行し、動作確認レポートを作成する
> - **パフォーマンス基準**: `codd scan` が設計書50ファイル以上でも30秒以内に完了することを確認する
> - **撤退計画**: ツールが廃止・破綻した場合でも、Markdownフロントマターの依存グラフ宣言自体は残存し手動での影響分析に活用できる。codd-devへの依存はCLI実行部分のみに限定する

```
プロンプトエンジニアリング → 1回の入力を最適化（2023〜2024）
コンテキストエンジニアリング → 永続的な背景知識をファイルで管理（2024〜2025）
ハーネスエンジニアリング → Hookとスキルでルールと制御を整備（2025〜2026）
  └─ CoDD → 変更時の設計整合性を依存グラフで自動維持（2026〜）
```

### CoDDのコアアクション

```bash
codd scan            # 設計書のフロントマターから依存グラフを構築
codd impact          # 変更の影響範囲をGreen/Amber/Grayで特定
codd validate        # 品質ゲート検証（TODO検出・構造チェック）
```

### CoDD Frontmatter（設計書への追加項目）

```yaml
---
codd:
  node_id: "L1_requirements_spec"
  wave: 1
  depends_on: []
  source_files: ["app/*.py", "tests/"]
  last_updated: "2026-05-18"
---
```

### Pochiにおける優先適用シナリオ（効果が大きい順）

1. **spec.json の仕様変更時** — plan.json・実装コード・テストへの波及を自動特定
2. **Snowflake ビュー廃止時**（ALADIN-DWH収束等）— DB設計変更がアプリコードに与える影響を追跡
3. **pochilib バージョンアップ時** — ライブラリAPI変更が各アプリに与える影響を分析

### impact の3帯域

| 帯域 | 信頼度 | 意味 | Pochiでの対応 |
|---|---|---|---|
| 🟢 Green | 高 | 確実に影響がある | AIが自動更新 |
| 🟡 Amber | 中 | 確認が必要 | 人間が判断 |
| ⚪ Gray | 低 | 間接的な影響の可能性 | 参考情報として参照 |

#### 初期運用（Pochi PoC期間）における帯域の扱い

> **方針更新（2026-05-18）**: 旧版では「Phase 0は人間がPRを作成」としていたが、松本氏の90ブランチ並列実装検証（`plan/new-dev/worktree/RM-memo.md`）により `git commit` までの完全自動化が実現可能であることが実証された。settings.json の許可設定（§6-b 参照）を前提条件として、PoC期間から `git commit` まで自動化する方針に更新する。

| フェーズ | 帯域 | 対応 |
|---|---|---|
| **Phase 0（PoC・3ヶ月）** | 🟢 Green | **`git commit` まで自動化**（settings.json 許可設定を前提） |
| Phase 0 | 🟢 Green | PRの作成・マージは人間が実施（auto-merge は Phase 1以降） |
| Phase 1以降 | 🟢 Green | PR作成・マージも自動化（効果測定後に検討） |
| 全フェーズ | 🟡 Amber | 担当者へ明示的アサイン |
| 全フェーズ | ⚪ Gray | 参考情報（自動処理なし） |

### Pochi向けCoDD Skillセット（Claude Code Skill化）

codd-devのCLIコマンドをPochiのスキルチェーンに組み込む。CoDD Skill 設計書（`CoDD（整合性駆動開発）Claude Code Skill 設計書.md`）に9スキルの実装仕様が定義されている。

| スキル | 対応コマンド | 役割 |
|---|---|---|
| codd-scan | `codd scan` | 設計書のフロントマターから依存グラフを構築・更新 |
| codd-impact | `codd impact` | 変更影響分析・Green帯域の自動修正 |
| codd-validate | `codd validate` | 品質ゲート検証。次Wave生成の前提条件チェック |
| codd-generate | `codd generate --wave N` | Wave順で設計書を生成 |
| codd-extract | `codd extract` | 既存Pochiアプリから設計書を逆生成（Brownfield対応） |
| codd-init | `codd init` | プロジェクト初期化 |
| codd-plan | `codd plan` | 実装計画の生成 |
| codd-implement | `codd implement` | 承認済み設計書からコード生成 |
| codd-assemble | `codd assemble` | 成果物の組み立て |

### Hookとの統合（初期運用の方針）

> **初期運用では PostToolUse Hook は導入しない。**
>
> 理由:
> - ファイル編集のたびに codd scan が走ると開発体験を阻害する（30秒/回の遅延）
> - AI生成コードの不正確さにより誤ったグラフが構築されるリスクがある
>
> **初期運用ルール**: codd scan はフィーチャー完成時の手動実行、または pre-commit hook に限定する。
>
> PostToolUse Hook への組み込みは施策3 Phase 1（PoC完了後・6ヶ月以降）で効果測定をもとに検討する。

### 施策3 PoC完了ゲート

- [ ] 既存Pochiアプリ1本で spec.json にCoDD フロントマター追加が完了
- [ ] `codd scan` が設計書50ファイル以上でも30秒以内に完了（計測済み）
- [ ] `codd impact` でspec変更時の影響候補が正確に提示される（偽陽性率 < 20%）
- [ ] 撤退計画レビュー実施済み（フロントマターのみで手動追跡が可能であることを確認）

---

## 8. 役割分担

| オーナー | 担当 | 主な責任 |
|---|---|---|
| **DESIGN.mdオーナー** | （未定） | DESIGN.mdの変更承認・バージョン管理・各app repoへの変更周知 |
| **EaC出力先標準オーナー** | （未定） | docs/ パス定義・スキル出力先パラメータの標準化・維持 |
| **Alation CSV同期オーナー** | （未定） | CSV鮮度管理・更新スケジュール・コミット可否の確認 |
| **CoDD PoCオーナー** | （未定） | PoC対象アプリ選定・動作確認レポート作成・撤退判断 |

---

## 9. 比較表：現状 vs 施策段階ごとの変化

| 観点 | 現状（As-Is） | DESIGN.md導入後 | docs/標準化後 | CoDD導入後 |
|---|---|---|---|---|
| UIデザイン一貫性 | プロンプト依存 | DESIGN.mdで常時保証 | 変わらず | 変わらず |
| 設計書の可用性 | 一部リポジトリ外（GSheets等） | 変わらず | docs/に集約・AIアクセス可能 | 依存グラフで構造化 |
| 要件変更の影響把握 | 人間が手動追跡 | 手動追跡 | 手動追跡 | 自動で影響範囲を特定 |
| スキル間の接続 | skill-navigatorで案内 | ワークフローが明示化 | 出力先が統一 | 変更伝播が自動化 |

---

## 10. 関連ドキュメント

### このフォルダ内（CoDD/）

| ファイル | 位置づけ |
|---|---|
| `整合性駆動開発CoDD爆誕.md` | CoDDの方法論・思想の原典。施策3の理論的背景 |
| `CoDD（整合性駆動開発）Claude Code Skill 設計書.md` | 9スキルの実装仕様。施策3のStep 3で参照 |
| `DESIGN.md ベストプラクティス・レポート.md` | DESIGN.mdの書き方ガイド。施策1のStep 1で参照 |
| `クラメソのデザインガイドをDESIGN.mdで実装してみた.md` | DESIGN.md導入の実践例・ハイブリッド運用の参考 |
| `Pochi-AI駆動開発プロセス戦略.md` | 本計画書の前身。EaC・ハーネス・CoDDの3層整理 |
| `memo.md` | CoDD記事の転記メモ（参考） |

### worktreeフォルダ内（worktree/）— 施策2-b の実装仕様・実証データ

| ファイル | 位置づけ |
|---|---|
| `pochi-worktree-strategy.md` | **吸収済み**（§6-bに統合）。原典として残存 |
| `clean-arch-refactoring.md` | メイン調整役スキルの実装仕様（フェーズ0〜3の具体的コード）。§6-bから参照 |
| `clean-arch-implementer.md` | サブエージェント（実装エージェント）の詳細仕様。§6-bから参照 |
| `RM-memo.md` | 松本氏の90ブランチ並列実装検証記録。施策2-bおよび施策3の方針根拠 |
| `feasibility-results.md` | フィジビリティ確認結果（施策2-b完了ゲート確認後に作成） |

### 外部

| 参照先 | 位置づけ |
|---|---|
| `/home/user/project-management/02_tasks/action-items.md`（AI-072） | pochi-spec-initializerへのAlation CSV組み込みの起票元。施策2の拡張方針の根拠 |

---

## 11. 初手タスクリスト（幅広く浅く検証）

3施策を本格着手前に「動くかどうか・使えるかどうか」を小さなPoCで確かめるための初手タスク。

### 実行順序の目安

- **T-1 → T-2**（施策1。即効性最高・最優先）
- **T-3・T-4**（施策2。順序不問・並行可）
- **T-5 → T-6**（施策3。T-5が前提条件）

---

### 施策1: DESIGN.md

**~~T-1: DESIGN.md ドラフト作成 + 既存スキルへの試し当て~~ ✅ 完了（2026-05-18）**

- `pochi-dp-developer-docs/DESIGN.md` が存在し `version: "1.0.0"` フィールドでバージョン管理されていることを確認済み
- 施策1 完了ゲート 1項目目を達成

---

**~~T-4: git worktree 動作確認（手動1サイクル）~~ ✅ 完了（2026-05-18）**

確認結果は `plan/new-dev/worktree/feasibility-results.md` に記録済み。主要な結果を以下に転記する。

| 完了ゲート項目 | 結果 |
|---|:---:|
| `git worktree add` が正常動作するか | ✅ |
| worktree内でのコミットが可能か | ✅ |
| メインブランチへのマージ | ✅（`ort` strategy） |
| `git worktree remove` が正常動作するか | ✅ |
| settings.json の事前許可設定で permission prompt が解消されるか | 🔲 未確認 |

**発見された制約**: `git commit` を `&&` 連結の一括コマンドで実行すると permission prompt で**拒否**される。個別実行に分けることで回避可能。並列エージェントが自律的にコミットするには `settings.json` への許可設定追加が必要（完了ゲート 2項目目・未着手）。

**施策2-b 完了ゲートの現状**:
- [x] `git worktree add` が正常動作するか（ローカル検証済み）
- [ ] settings.json の事前許可設定で permission prompt 頻発が解消されることを確認 ← **次の着手点**
- [ ] worktreeブランチのマージ時にコンフリクトが発生するパターンを把握し、回避策をドキュメント化
- [ ] pochi-coding-agent に worktreeモードフラグを追加済み（`pochi-coding-agent-worktree` として独立スキル化・SKILL.md作成済み。marketplace.json / skills.json / README.md / pochi-skill-navigator への正式登録は未実施）
- [ ] フィジビリティ確認結果を `plan/new-dev/worktree/feasibility-results.md` に記録済み ← **完了**

**CCネタ発掘会（2026-05-15）との対応**:
- AI-075（worktree並列開発の検証）→ T-4完了により基本動作を確認済み
- AI-076（git commitまでClaudeに実施させるフィジビリティ確認）→ 個別実行では可能・`&&` 連結は不可という結論。settings.json 許可設定追加が残タスク

**6月初週の吉行チームへの訴求**（CCネタ発掘会 議事録より）に向けて、settings.json 許可設定確認 → 実 Pochi アプリでの並列実行テスト → session_state 衝突パターン確認、の順で検証を継続する。

---

**T-2: プロンプト行数 Before/After 計測**

- 既存の実案件スキル呼び出しログでデザイン指定部分の行数を計測
- DESIGN.md 参照後の行数と比較して削減率を数字で出す

**根拠**: 計画書は「約70%削減（参考値）」と注釈付きで記載し、**「Step 1完了後に Pochi 固有の効果を計測する」**と明記（§5 注釈）。完了ゲートの「3件の実案件で削減効果を確認」の1件目に相当。数値がなければ社内展開の説得材料にならない。

**期待アウトプット**: 行数比較メモ（Before / After 数値）

**DESIGN.md 現状（2026-05-20調査済み）**:

| 施策1 完了ゲート | 状態 |
|---|:---:|
| DESIGN.md がリポジトリルートに存在し `version: "1.0.0"` でバージョン管理 | ✅ |
| 主要スキル（pochi-coding-agent / pochi-ui-generator）起動プロンプトのデザイン指定重複がゼロ | 🔲 未着手 |
| 3件の実案件で Before/After プロンプト行数を計測し削減効果を確認（T-2） | 🔲 未実施 |
| UIレビュー差し戻し（`st.caption` / `help=`、`st.warning` / `st.info` の表現ブレ）が月次0件 | 🔲 観測中 |

**DESIGN.md 本体の状態**: 9セクション全て完成。デザイントークン（Pochiブランドオレンジ `#FF6E00` を primary に設定）・コンポーネントスタイル・Do's and Don'ts・エージェント向けプロンプトガイドを含む完全な仕様として整備済み。

**参考値**（クラメソ社 Streamlit × Claude Code 環境での計測）:
- スキル呼び出し版（毎回プロンプトに記述）: 約 11,520 文字
- DESIGN.md 参照版（ファイルに置くだけ）: 約 3,513 文字 → **約 70% 削減**
- Pochi 固有の削減率は T-2 実施後に確定する（スキル構成・アプリ複雑度により変動）

**CCネタ発掘会（2026-05-15）との対応**:
- DESIGN.md 導入の本質的目的：`st.caption` か `help=` か、`st.warning` か `st.info` か、といった Streamlit 固有の UI 表現選択を人間の裁量からエージェントの自動判断へ移すこと（UI-073 の根本原因への対処）
- アクションアイテム AI-073 / AI-074 との関係：UI 表現ブレの再発防止策として DESIGN.md が機能するかどうかが T-2 の計測対象に含まれる

---

### 施策2: EaC（docs/ 構造化）

**T-3: pochi-spec-initializer 出力先変更の影響調査**

- `skills/spec/pochi-spec-initializer/skills/run/SKILL.md` を読んで、出力先がハードコードされているか確認
- 変更に必要な箇所をリストアップするだけ（実変更はしない）
- 確認観点: パラメータ化できるか、SKILL.md の変更のみで対応できるか

**根拠**: §6 に「既存スクリプト・スキルへの影響確認: Step 2着手前に参照パスがハードコードされていないかを確認する」と明記。パスがハードコードされている場合、EaC 全体が動かないため施策2の着手可否判断に直結する。

**期待アウトプット**: 変更箇所リスト（Markdown メモ）

---

**T-4: git worktree 動作確認（手動1サイクル）**

- 任意の Pochi アプリリポジトリで `git worktree add` → コミット → `git worktree remove` を手動で1サイクル実行
- settings.json に許可設定（`Bash(git worktree add:*)` 等）を追加して permission prompt が消えるか確認

**根拠**: §6-b の完了ゲートに「Pochi既存アプリで `git worktree add` が正常動作するか（ローカル検証済み）」「settings.json の事前許可設定で permission prompt 頻発が解消されることを確認」が含まれる。並列実装戦略（フェーズ0〜3）は環境制約で動かないと全て机上の空論になる。

**期待アウトプット**: 動作確認ログ（成功/失敗とエラー内容）

---

### 施策3: CoDD

**T-5: codd-dev インストール + 基本コマンド動作確認**

- `pip install codd-dev` を実行してインストール可否を確認
- `codd --version` / `codd --help` / `codd init` を任意ディレクトリで実行して何が生成されるか観察
- 確認観点: バージョン・Pochi Python 環境との依存競合・エラーの有無

**根拠**: §7 に「codd-devパッケージのリスク評価」として一部コマンドが「実験的」と明記。インストール自体が通るか、Streamlit との依存関係が競合しないかは触れないとわからない。失敗なら施策3の方針見直しが必要。

**期待アウトプット**: インストールログ + `codd --version` 出力

---

**T-6: 既存 spec.json にフロントマター追加 → codd scan / codd impact 動作確認**

- 既存 Pochi アプリの spec.json 1ファイルにフロントマター（`node_id` / `depends_on` 等）を追加
- `codd scan` を実行して依存グラフが構築されるか確認
- `codd impact` でダミー変更の影響分析が出力されるか確認
- 確認観点: 偽陽性率・実行時間・出力の読みやすさ

**根拠**: §7 の完了ゲートに「`codd scan` が50ファイル以上でも30秒以内に完了」「偽陽性率 < 20%」という数値基準がある。実際に動かさないと計測できない。撤退計画（フロントマターのみで手動追跡が可能か）の確認も兼ねる。

**期待アウトプット**: `codd scan` / `codd impact` 出力ログ（実行時間・偽陽性数を記録）
