# worktree並列実装 E2E検証計画書

作成日: 2026-05-21
ステータス: 検証待ち
対象リポジトリ: `pochi-d-pay-merchant-visualizer-repository`
参照元: [Pochi-AI駆動開発プロセス統合計画書.md](./Pochi-AI駆動開発プロセス統合計画書.md) §6-b

---

## 目次

1. [検証の目的と位置づけ](#1-検証の目的と位置づけ)
2. [仮仕様（spec.json）](#2-仮仕様specjson)
3. [タスク分割（worktree-plan）](#3-タスク分割worktree-plan)
4. [E2E検証フロー（フェーズ0〜3 + push）](#4-e2e検証フローフェーズ03--push)
5. [確認ポイントと記録項目](#5-確認ポイントと記録項目)
6. [完了ゲートへの対応](#6-完了ゲートへの対応)

---

## 1. 検証の目的と位置づけ

### 何を確認するか

施策2-b「worktree並列実装戦略」のフィジビリティ確認として、以下をE2Eで検証する。

| 確認項目 | 期待する結果 |
|---|---|
| `git worktree add/remove` の正常動作 | ✅ 既確認（feasibility-results.md） |
| **settings.local.json の `Bash(git:*)` 許可でpermission promptが出ないか** | 今回確認する |
| **サブエージェント×Nが並列実行できるか** | 今回確認する |
| **`git commit` が個別実行でprompt不要か** | 今回確認する |
| **複数ブランチのマージでコンフリクトが発生するパターン** | 今回確認・記録する |
| **`git push` まで自動で完了するか** | 今回確認する |

### 既知の制約（T-4検証結果より）

- `git commit` を `&&` 連結で実行すると permission prompt で**拒否される**
- 個別コマンド実行では完了する
- `pochi-d-pay-merchant-visualizer-repository/.claude/settings.local.json` に `Bash(git:*)` が許可済み

### 今回の仮仕様の設計方針

**「実際のアプリ機能拡張として成立する、まあまあ大規模な仕様」** を使用する。
ダミーファイルではなく、d払い決済状況見える化ツール (`pochi-d-pay-merchant-visualizer-repository`) の
既存ページに対して、独立した3つの機能追加を並列実装する。

各タスクは **異なるファイルを主たる変更対象** とし、session_state キーも分離して衝突を防ぐ。

---

## 2. 仮仕様（spec.json）

出力先: `pochi-d-pay-merchant-visualizer-repository/docs/features/WORKTREE-DEMO-001/spec.json`

```json
{
  "feature_id": "WORKTREE-DEMO-001",
  "feature_name": "d払い決済状況見える化ツール 機能拡張バッチ（worktree並列実装検証用）",
  "version": "1.0.0",
  "status": "draft",
  "created": "2026-05-21",
  "description": "worktree並列実装戦略のE2E検証を兼ねた機能拡張。独立した3タスクを並列実装する。",
  "tasks": [
    {
      "task_id": "task-1",
      "task_name": "検索条件サマリ表示コンポーネントの追加",
      "description": "visualization_tool.py に、現在の検索条件を人間が読みやすい形式でサマリ表示するコンポーネントを追加する。検索ボタン押下後、地図・グラフの上部に条件サマリを折りたたみ式（st.expander）で表示する。",
      "target_files": [
        "app/app_pages/visualization_tool.py",
        "app/lib/components/search_summary.py（新規作成）"
      ],
      "parallelizable": true,
      "session_state_keys": ["task1_search_summary_expanded"],
      "implementation_detail": {
        "new_file": {
          "path": "app/lib/components/search_summary.py",
          "content_summary": "InputConditions を受け取り、設定された検索条件を日本語ラベルで箇条書き表示する components_search_summary(conditions: InputConditions) 関数を実装する。表示項目: 利用期間、比較期間（有効時）、都道府県/市区町村、性別、年代、業種、決済方式、キーワード検索条件（設定されたもののみ）。"
        },
        "visualization_tool_change": {
          "description": "components_search_summary をインポートし、検索ボタン押下後の結果表示ブロック冒頭に st.expander('検索条件サマリ') 内で呼び出す。"
        }
      },
      "acceptance_criteria": [
        "app/lib/components/search_summary.py が作成されている",
        "components_search_summary(conditions) 関数が InputConditions を受け取り、設定済み条件を st.write で列挙する",
        "visualization_tool.py が search_summary をインポートし、結果ブロック冒頭の st.expander 内で呼び出している",
        "conditions が None または check==False の場合に空表示になる（エラーなし）",
        "ruff check でエラーが出ない"
      ]
    },
    {
      "task_id": "task-2",
      "task_name": "how_to_use.py の機能説明コンテンツ拡充",
      "description": "how_to_use.py（使い方ページ）に、地図検索・店舗検索・キーワード検索の3機能の使い方を詳細に追記する。各機能に st.info / st.warning を用いたヒントボックスを追加し、PochiアプリUIガイドラインに従ったコンポーネント選択を行う。",
      "target_files": [
        "app/app_pages/how_to_use.py"
      ],
      "parallelizable": true,
      "session_state_keys": [],
      "implementation_detail": {
        "sections_to_add": [
          {
            "title": "地図検索機能の使い方",
            "content": "地図上をクリックして中心地点を指定し、半径（km）を設定することで周辺の加盟店を検索できる。st.info で「地図をクリックするとその地点を中心に検索します」と案内する。"
          },
          {
            "title": "店舗検索機能の使い方",
            "content": "特定の店舗を起点に周辺加盟店を分析できる機能の説明。store_search コンポーネントとの連携を説明。st.info で手順を列挙する。"
          },
          {
            "title": "キーワード検索機能の使い方",
            "content": "企業名・店舗名・住所によるキーワード検索の説明。keyword_search_method の4モード（company_store / company / store / address）を st.warning で注意事項とともに説明する。"
          },
          {
            "title": "比較期間機能の使い方",
            "content": "enable_comparison フラグを有効にした場合の比較期間設定方法と、グラフ表示の変化について説明する。"
          }
        ]
      },
      "acceptance_criteria": [
        "how_to_use.py に地図検索・店舗検索・キーワード検索・比較期間の4セクションが追加されている",
        "st.info / st.warning がUIガイドラインの用法（情報提供: st.info、注意喚起: st.warning）で使われている",
        "st.caption は補足説明の1行テキストに限定して使用している",
        "ruff check でエラーが出ない"
      ]
    },
    {
      "task_id": "task-3",
      "task_name": "about_this_app.py のメタ情報強化 + アプリ更新履歴セクション追加",
      "description": "about_this_app.py（このアプリについてページ）に、アプリの対象ユーザー・主要ユースケース・データ更新頻度・制約事項を構造化して追記する。さらに「更新履歴」セクションを新設し、主要バージョンの変更内容を st.table で一覧表示する。",
      "target_files": [
        "app/app_pages/about_this_app.py"
      ],
      "parallelizable": true,
      "session_state_keys": [],
      "implementation_detail": {
        "sections_to_add": [
          {
            "title": "対象ユーザー・ユースケース",
            "content": "エリアマーケティング担当者・加盟店開拓担当者・チャネル戦略チーム向けの主要ユースケースを箇条書きで記載する。"
          },
          {
            "title": "データ更新頻度・ラグ",
            "content": "Snowflakeビューのデータ更新タイミング（日次 or 月次）・反映ラグ・参照可能期間の説明を st.info で表示する。"
          },
          {
            "title": "制約事項・既知の制限",
            "content": "件数上限（地図表示: 5,000件、ダウンロード: 50,000件など）・住所選択の市区町村上限（15件）などの制約を st.warning で表示する。"
          },
          {
            "title": "更新履歴",
            "content": "バージョン・更新日・主な変更内容を3〜5件分 st.table で表示するテーブルを追加する。"
          }
        ],
        "update_history_data": [
          {"version": "v2.3.0", "date": "2026-05-21", "summary": "worktree並列実装検証バッチ（検索条件サマリ・使い方拡充・アプリ情報強化）"},
          {"version": "v2.2.0", "date": "2026-03-01", "summary": "店舗検索機能追加・地図検索の半径設定UI改善"},
          {"version": "v2.1.0", "date": "2025-12-01", "summary": "比較期間機能追加・グラフ表示改善"},
          {"version": "v2.0.0", "date": "2025-09-01", "summary": "キーワード検索機能追加・パフォーマンス改善"},
          {"version": "v1.0.0", "date": "2025-04-01", "summary": "初版リリース"}
        ]
      },
      "acceptance_criteria": [
        "about_this_app.py に対象ユーザー・データ更新頻度・制約事項・更新履歴の4セクションが追加されている",
        "更新履歴は st.table または st.dataframe で表示されている",
        "st.info（情報）・st.warning（注意・制約）がUIガイドラインに従って使われている",
        "ruff check でエラーが出ない"
      ]
    }
  ],
  "common_constraints": {
    "branch_base": "feature/ryota-suzuki-xf",
    "worktree_base_path": "/home/user/.worktrees/pochi-d-pay-merchant-worktree-demo",
    "commit_message_format": "feat: {task_name} を実装\n\nCo-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>",
    "session_state_prefix_rule": "各タスクのsession_stateキーにはtask_idをプレフィックスとして付ける（例: task1_xxx）",
    "ruff_check": "実装後に ruff check app/ を実行してエラーが0件であることを確認する",
    "ui_guideline": "st.caption は1行補足のみ。st.info は情報提供。st.warning は注意喚起。st.error はエラーのみ。"
  },
  "data_schema": {
    "referenced_views": [],
    "note": "今回の検証タスクはSnowflakeクエリを発行しない。既存の InputConditions・RenderOptions モデルの参照のみ。"
  }
}
```

---

## 3. タスク分割（worktree-plan）

出力先: `pochi-d-pay-merchant-visualizer-repository/.claude/work/worktree-plan.md`（フェーズ0で自動生成）

```markdown
# worktree-plan: WORKTREE-DEMO-001

生成日: 2026-05-21
ベースブランチ: feature/ryota-suzuki-xf
worktreeベースパス: /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo

## タスク一覧

| task_id | ブランチ名 | 主な変更ファイル | 並列化可否 |
|---|---|---|:---:|
| task-1 | feature/worktree-demo-task-1 | app/lib/components/search_summary.py（新規）, visualization_tool.py | ✅ |
| task-2 | feature/worktree-demo-task-2 | app/app_pages/how_to_use.py | ✅ |
| task-3 | feature/worktree-demo-task-3 | app/app_pages/about_this_app.py | ✅ |

## 並列化判定根拠

- task-1〜3 はすべて異なるファイルが主たる変更対象
- task-1 が visualization_tool.py を変更するが、task-2・3 は触れない → 衝突なし
- session_state キーはすべて task_id プレフィックスで分離済み → 衝突なし
- Snowflake クエリを新規追加しない → 共通インフラのコミット先行不要
- 全3タスクを並列実行可能と判定

## worktreeディレクトリ構成

.worktrees/pochi-d-pay-merchant-worktree-demo/
├── task-1/   ← feature/worktree-demo-task-1
├── task-2/   ← feature/worktree-demo-task-2
└── task-3/   ← feature/worktree-demo-task-3
```

---

## 4. E2E検証フロー（フェーズ0〜3 + push）

### フェーズ0: 仕様作成・タスク分割（メインエージェント）

1. `docs/features/WORKTREE-DEMO-001/` ディレクトリを作成し `spec.json` を出力する
2. spec.json を解析してタスク分割可否を判定する
3. `.claude/work/worktree-plan.md` を生成する

### フェーズ1: worktree生成（メインエージェント）

```bash
REPO_ROOT=$(git -C /home/user/pochi-d-pay-merchant-visualizer-repository rev-parse --show-toplevel)
WORKTREE_BASE="/home/user/.worktrees/pochi-d-pay-merchant-worktree-demo"
BASE_BRANCH="feature/ryota-suzuki-xf"

mkdir -p "$WORKTREE_BASE"
git -C "$REPO_ROOT" worktree add -b feature/worktree-demo-task-1 "$WORKTREE_BASE/task-1" "$BASE_BRANCH"
git -C "$REPO_ROOT" worktree add -b feature/worktree-demo-task-2 "$WORKTREE_BASE/task-2" "$BASE_BRANCH"
git -C "$REPO_ROOT" worktree add -b feature/worktree-demo-task-3 "$WORKTREE_BASE/task-3" "$BASE_BRANCH"
git -C "$REPO_ROOT" worktree list
```

### フェーズ2: 並列実装（サブエージェント × 3、同時起動）

#### サブエージェント1（task-1）への指示

```
あなたは pochi-d-pay-merchant-visualizer-repository の実装エージェントです。
以下の仕様に従い、指定のworktreeディレクトリで実装を完了してください。

**worktreeディレクトリ**: /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-1
**作業ブランチ**: feature/worktree-demo-task-1
**仕様書**: /home/user/pochi-d-pay-merchant-visualizer-repository/docs/features/WORKTREE-DEMO-001/spec.json の task-1

【実装内容】
1. /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-1/app/lib/components/search_summary.py を新規作成する
   - components_search_summary(conditions: InputConditions) 関数を実装する
   - InputConditions の各フィールドを日本語ラベルで表示する（Noneや未設定は省略）
   - 表示項目: 利用期間、比較期間（enable_comparison=True時のみ）、都道府県/市区町村（設定時）、性別、年代（設定時）、業種（設定時）、決済方式（設定時）、キーワード検索条件（設定時）
   - 引数が None の場合は何も表示しない

2. /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-1/app/app_pages/visualization_tool.py を編集する
   - `from lib.components.search_summary import components_search_summary` を追加
   - 検索結果の描画ブロック（conditions.check が True になった後）の冒頭に以下を追加:
     ```python
     with st.expander("🔍 検索条件サマリ", expanded=False):
         components_search_summary(conditions)
     ```

3. 実装後に以下を個別コマンドで実行する（&&連結は使わないこと）:
   - ruff check の実行（エラーが0件であることを確認）
   - git -C /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-1 add app/lib/components/search_summary.py
   - git -C /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-1 add app/app_pages/visualization_tool.py
   - git -C /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-1 commit -m "feat: 検索条件サマリ表示コンポーネントを追加

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>"

【参照してよいファイル】
- /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-1/app/lib/models.py（InputConditions の定義）
- /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-1/app/lib/const.py（GENDER_CODE_MAP, NENDAI_CODE_MAP）
- /home/user/pochi-dp-developer-docs/DESIGN.md（UIコンポーネント選択ルール）

【禁止事項】
- Snowflake クエリの新規追加
- session_state キーに "task1_" プレフィックスなしで書き込むこと
- &&連結でのコマンド実行
- worktreeディレクトリ外のファイル編集

git commit まで完了したら「task-1 完了」と報告してください。
```

#### サブエージェント2（task-2）への指示

```
あなたは pochi-d-pay-merchant-visualizer-repository の実装エージェントです。
以下の仕様に従い、指定のworktreeディレクトリで実装を完了してください。

**worktreeディレクトリ**: /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-2
**作業ブランチ**: feature/worktree-demo-task-2
**仕様書**: /home/user/pochi-d-pay-merchant-visualizer-repository/docs/features/WORKTREE-DEMO-001/spec.json の task-2

【実装内容】
/home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-2/app/app_pages/how_to_use.py を編集する

以下の4セクションを既存コンテンツの末尾（または適切な位置）に追加する:

1. **地図検索機能の使い方**
   - st.subheader("🗺️ 地図検索機能の使い方")
   - 地図をクリックして中心地点を指定 → 半径（km）を設定 → 検索ボタンで周辺加盟店を検索できる手順を説明
   - st.info("地図をクリックした地点を中心として、設定した半径内の加盟店を検索します。") で手順を案内

2. **店舗検索機能の使い方**
   - st.subheader("🏪 店舗検索機能の使い方")
   - 特定店舗を起点に周辺加盟店を分析する手順を st.info で列挙
   - 店舗名でのキーワード検索 → 対象店舗を選択 → 半径設定 → 検索の流れを説明

3. **キーワード検索機能の使い方**
   - st.subheader("🔍 キーワード検索機能の使い方")
   - 検索モード4種（企業+店舗名 / 企業名のみ / 店舗名のみ / 住所）を箇条書きで説明
   - st.warning("検索結果が多い場合は最大50,000件で打ち切られます。絞り込み条件と組み合わせてご利用ください。") で注意喚起

4. **比較期間機能の使い方**
   - st.subheader("📊 比較期間機能の使い方")
   - 「比較期間を有効にする」チェックボックスを有効にすると比較期間を設定できることを説明
   - グラフ表示時に基準期間と比較期間のデータが並列表示されることを st.info で案内

実装後に以下を個別コマンドで実行する（&&連結は使わないこと）:
- ruff check の実行
- git -C /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-2 add app/app_pages/how_to_use.py
- git -C /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-2 commit -m "feat: how_to_use に地図検索・店舗検索・キーワード検索・比較期間の説明を追加

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>"

【参照してよいファイル】
- /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-2/app/app_pages/how_to_use.py（現在の内容を確認してから追記）
- /home/user/pochi-dp-developer-docs/DESIGN.md（UIコンポーネント選択ルール）

【禁止事項】
- 既存コンテンツの削除・上書き（追記のみ）
- &&連結でのコマンド実行
- worktreeディレクトリ外のファイル編集

git commit まで完了したら「task-2 完了」と報告してください。
```

#### サブエージェント3（task-3）への指示

```
あなたは pochi-d-pay-merchant-visualizer-repository の実装エージェントです。
以下の仕様に従い、指定のworktreeディレクトリで実装を完了してください。

**worktreeディレクトリ**: /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-3
**作業ブランチ**: feature/worktree-demo-task-3
**仕様書**: /home/user/pochi-d-pay-merchant-visualizer-repository/docs/features/WORKTREE-DEMO-001/spec.json の task-3

【実装内容】
/home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-3/app/app_pages/about_this_app.py を編集する

以下の4セクションを既存コンテンツの末尾（または適切な位置）に追加する:

1. **対象ユーザー・主要ユースケース**
   - st.subheader("👥 対象ユーザー・主要ユースケース")
   - 対象ユーザー: エリアマーケティング担当者、加盟店開拓担当者、チャネル戦略チームを箇条書き
   - 主要ユースケース:
     - 特定エリアにおける d払い加盟店の分布・決済傾向の把握
     - 競合エリアとの比較分析（比較期間機能を活用）
     - 加盟店開拓の優先エリア選定

2. **データ更新頻度・参照可能期間**
   - st.subheader("📅 データ更新頻度・参照可能期間")
   - st.info でデータ更新タイミング（日次 or 月次）・反映ラグ・参照可能期間を説明
   - 「最新データの反映には最大1日のラグがある場合があります」旨を記載

3. **制約事項・既知の制限**
   - st.subheader("⚠️ 制約事項・既知の制限")
   - st.warning で以下の制約を箇条書き:
     - 地図表示: 最大5,000件（上限突破モード時は50,000件）
     - 分析データダウンロード: 最大50,000件でExcelからCSVに自動切り替え
     - ユーザーリストダウンロード: 最大100万件
     - 住所選択の市区町村: 最大15件まで
     - キーワード検索結果: 最大50,000件

4. **更新履歴**
   - st.subheader("📋 更新履歴")
   - 以下のデータを st.dataframe（またはst.table）で表示:
     | バージョン | 更新日 | 主な変更内容 |
     |---|---|---|
     | v2.3.0 | 2026-05-21 | worktree並列実装検証バッチ（検索条件サマリ・使い方拡充・アプリ情報強化） |
     | v2.2.0 | 2026-03-01 | 店舗検索機能追加・地図検索の半径設定UI改善 |
     | v2.1.0 | 2025-12-01 | 比較期間機能追加・グラフ表示改善 |
     | v2.0.0 | 2025-09-01 | キーワード検索機能追加・パフォーマンス改善 |
     | v1.0.0 | 2025-04-01 | 初版リリース |

実装後に以下を個別コマンドで実行する（&&連結は使わないこと）:
- ruff check の実行
- git -C /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-3 add app/app_pages/about_this_app.py
- git -C /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-3 commit -m "feat: about_this_app にユースケース・制約事項・更新履歴を追加

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>"

【参照してよいファイル】
- /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-3/app/app_pages/about_this_app.py（現在の内容を確認してから追記）
- /home/user/.worktrees/pochi-d-pay-merchant-worktree-demo/task-3/app/lib/const.py（制約値: MAP_DEFAULT_MAX_ROWS等）
- /home/user/pochi-dp-developer-docs/DESIGN.md（UIコンポーネント選択ルール）

【禁止事項】
- 既存コンテンツの削除・上書き（追記のみ）
- &&連結でのコマンド実行
- worktreeディレクトリ外のファイル編集

git commit まで完了したら「task-3 完了」と報告してください。
```

### フェーズ3: マージ・クリーンアップ（メインエージェント）

全サブエージェントから「完了」報告を受け取ったら実行する。

```bash
REPO_ROOT=/home/user/pochi-d-pay-merchant-visualizer-repository
WORKTREE_BASE=/home/user/.worktrees/pochi-d-pay-merchant-worktree-demo
BASE_BRANCH=feature/ryota-suzuki-xf

# マージ（コンフリクトが発生したら記録して手動解消）
git -C "$REPO_ROOT" checkout "$BASE_BRANCH"
git -C "$REPO_ROOT" merge feature/worktree-demo-task-1 --no-edit
git -C "$REPO_ROOT" merge feature/worktree-demo-task-2 --no-edit
git -C "$REPO_ROOT" merge feature/worktree-demo-task-3 --no-edit

# クリーンアップ
git -C "$REPO_ROOT" worktree remove "$WORKTREE_BASE/task-1"
git -C "$REPO_ROOT" worktree remove "$WORKTREE_BASE/task-2"
git -C "$REPO_ROOT" worktree remove "$WORKTREE_BASE/task-3"
git -C "$REPO_ROOT" branch -d feature/worktree-demo-task-1 feature/worktree-demo-task-2 feature/worktree-demo-task-3
```

### git push

```bash
git -C /home/user/pochi-d-pay-merchant-visualizer-repository push origin feature/ryota-suzuki-xf
```

---

## 5. 確認ポイントと記録項目

検証後に `plan/new-dev/worktree/feasibility-results.md` に追記する内容。

### permission prompt 確認マトリクス

| コマンド | permission prompt 発生 | 備考 |
|---|:---:|---|
| `git worktree add` | 🔲 | フェーズ1 |
| `git worktree list` | 🔲 | フェーズ1 |
| `git add <file>` | 🔲 | フェーズ2（サブエージェント内） |
| `git commit` （個別実行） | 🔲 | フェーズ2（サブエージェント内） |
| `git checkout` | 🔲 | フェーズ3 |
| `git merge --no-edit` | 🔲 | フェーズ3 |
| `git worktree remove` | 🔲 | フェーズ3 |
| `git branch -d` | 🔲 | フェーズ3 |
| `git push` | 🔲 | push |

### コンフリクト記録

| マージ対象 | コンフリクト発生ファイル | 原因 | 解消方法 |
|---|---|---|---|
| task-1 | なし（予定） | — | — |
| task-2 | なし（予定） | — | — |
| task-3 | なし（予定） | — | — |

### 並列実行の実測

| 項目 | 結果 |
|---|---|
| 並列サブエージェント数 | 3 |
| フェーズ2の所要時間 | 🔲 計測予定 |
| 全体（フェーズ0〜push）の所要時間 | 🔲 計測予定 |

---

## 6. 完了ゲートへの対応

施策2-b の完了ゲート（Pochi-AI駆動開発プロセス統合計画書.md §6-b）と本検証の対応。

| 完了ゲート項目 | 検証方法 | 結果 |
|---|---|:---:|
| `git worktree add` が正常動作するか | フェーズ1で確認 | ✅（T-4済み） |
| settings.json 許可設定で permission prompt が解消されるか | §5 マトリクスで確認 | 🔲 |
| マージ時のコンフリクトパターンを把握し回避策をドキュメント化 | §5 コンフリクト記録で確認 | 🔲 |
| pochi-coding-agent に worktreeモードフラグを追加済み | 正式登録（検証成功後に実施） | 🔲 |
| フィジビリティ確認結果を `feasibility-results.md` に記録済み | §5 の結果を追記 | 🔲 |

---

## 7. 実施結果と計画との差異（2026-05-21 実施後記録）

### 実際のコミット構成

```
f7a576e  feat: Add coverage summary, quality report, and specification documents for FEAT-WORKTREE-DEMO-001  ← メインブランチ直接
f03af2e  feat: app/lib/components/__init__.py を追加（worktree並列実装準備）                                 ← メインブランチ直接
3b1966c  feat: 検索条件サマリ表示コンポーネントを追加                                                        ← メインブランチ直接（task-1相当）
900e1b2  Merge branch 'feature/worktree-demo-task-2' into feature/ryota-suzuki-xf
2ae1110  Merge branch 'feature/worktree-demo-task-3' into feature/ryota-suzuki-xf
```

### task-1の計画乖離

| 項目 | 計画 | 実際 |
|---|---|---|
| ブランチ | `feature/worktree-demo-task-1` を作成 | 作成されず（ブランチなし） |
| 実装場所 | worktreeディレクトリ内 | メインブランチに直接コミット |
| マージコミット | あり | なし |
| 並列実行 | task-2・3と同時並列 | 先行してメインで完了 |

**推定原因**: コンポーネントパッケージの準備（`__init__.py` の空ファイル追加）をメインブランチで先行コミットした際に、そのままtask-1の実装（`search_summary.py` + `visualization_tool.py` 修正）もメインブランチで完了させてしまったと考えられる。

### task-2・task-3：計画通り ✅

- `feature/worktree-demo-task-2`（how_to_use.py）・`feature/worktree-demo-task-3`（about_this_app.py）はそれぞれworktreeブランチで実装され、順次マージされた。
- コンフリクトは発生しなかった（task-2・3は互いに異なるファイルのみ変更）。

### 次回への改善点

- **task-1もworktreeブランチで実施する**：`__init__.py` の先行追加が必要な場合でも、worktreeブランチ作成後にそのworktree内でコミットすること。
- **フェーズ1完了を確認してからフェーズ2を開始する**：worktree作成前にメインブランチを変更しないよう順序を明確にすること。
