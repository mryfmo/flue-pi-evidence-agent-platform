---
description: 既存のデータ取得関数を分析し、Clean Architectureに並列移行する
---

# Clean Architecture リファクタリング（メイン調整役）

## ロール定義

あなたは、Clean Architectureの専門家として、既存のStreamlitアプリをフレームワーク非依存な設計に移行します。複数の実装タスクを特定し、サブエージェントを並列実行して効率的にリファクタリングを進めます。

## 前提条件

このスキルを実行する前に、以下の分析エージェントを実行しておく必要があります：

1. **@data-function-inventory**: 全関数の技術的分類
   - 成果物: `docs/inventory/` ディレクトリ
   - 内容: 全ページ・全関数のリスト、カテゴリ別分類

2. **@usecase-analyzer**: ビジネスユースケースと技術実装の分析
   - 成果物: `docs/use-cases/` ディレクトリ
   - 内容: ユースケース、データフロー、関数の使用箇所

これらの分析結果を参照して、移行対象の関数と優先順位を決定します。

## 実行フロー

### フェーズ1: 分析・計画立案

**重要**: まず既存の分析結果ファイルの存在をチェックしてください。

1. **分析結果の確認**
   - `docs/inventory/by-category.md` の存在確認（なければユーザーに `@data-function-inventory` の実行を依頼）
   - `docs/use-cases/data-flows.md` の存在確認（なければユーザーに `@usecase-analyzer` の実行を依頼）
   - **既存ファイルがある場合**: それを読み込んで参照（再生成しない）
   - **ファイルがない場合**: ユーザーに前提条件の実行を促す

2. **既存分析結果の読み込み**
   - `docs/inventory/by-category.md` から全関数を確認
   - `docs/use-cases/data-flows.md` からデータフローを確認
   - `docs/use-cases/pages/*.md` から各関数の使用箇所を確認

3. **移行対象の選定**
   - データアクセス関数を優先的に選定
   - 各関数の依存関係を確認
   - 並列実行可能な単位に分割

4. **タスク分割**
   - 独立して移行可能な関数をグルーピング
   - 各タスクの優先度を決定（使用頻度、影響範囲を考慮）
   - 並列実行計画を立案

5. **計画書の作成**
   - `.claude/work/clean-arch-plan.md` の存在確認
   - **既存の計画書がある場合**: それを読み込んで確認、必要に応じて更新
   - **計画書がない場合**: 新規作成
   - 各タスクの内容、対象関数、期待される成果物を明記
   - 既存分析結果（`docs/inventory/`, `docs/use-cases/`）への参照リンクを含める

### フェーズ1.5: 共通インフラの作成

**重要**: 並列実行前に共通インフラ（キャッシュアダプター）を作成してください。

これにより、複数のサブエージェントが同時に同じファイルを作成しようとするファイル競合を防ぎます。

#### 作成するファイル

1. **キャッシュプロトコル** (`{data_access_root}/cache/cache_protocol.py`)
   - CacheProtocolインターフェースを定義
   - 型ヒントとdocstringを含める

2. **NoCacheアダプター** (`{data_access_root}/cache/no_cache.py`)
   - キャッシュなし実装（MCP/FastAPI/テスト用）

3. **StreamlitCacheアダプター** (`{data_access_root}/cache/streamlit_cache.py`)
   - Streamlit用キャッシュ実装
   - `st.cache_data`をラップ

4. **__init__.pyファイル**
   - `{data_access_root}/__init__.py`
   - `{data_access_root}/cache/__init__.py`
   - `{data_access_root}/repositories/__init__.py`
   - `{data_access_root}/models/__init__.py`

#### 確認事項

- 既存ファイルがある場合は再生成しない
- ディレクトリ構造が存在しない場合は作成
- 全ファイル作成後、git worktree準備フェーズへ進む

### フェーズ1.6: git worktree準備

**重要**: 並列実行前に各サブエージェント用のgit worktreeを作成します。

これにより、複数のサブエージェントが同時にファイルを編集してもコンフリクトが発生しません。

#### worktreeの作成手順

```bash
# リポジトリルートから実行
REPO_ROOT=$(git rev-parse --show-toplevel)
WORKTREE_BASE="${REPO_ROOT}/../.worktrees/clean-arch"

# ベースディレクトリ作成
mkdir -p "$WORKTREE_BASE"

# 現在のブランチ名を取得
BASE_BRANCH=$(git branch --show-current)

# 各サブエージェント用のworktreeを作成
# タスク1用
git worktree add -b clean-arch/task-1 "$WORKTREE_BASE/task-1" "$BASE_BRANCH"

# タスク2用
git worktree add -b clean-arch/task-2 "$WORKTREE_BASE/task-2" "$BASE_BRANCH"

# （必要に応じてtask-3, task-4も作成）
```

#### worktreeディレクトリ構造

```
../.worktrees/clean-arch/
├── task-1/           # サブエージェント1の作業ディレクトリ
├── task-2/           # サブエージェント2の作業ディレクトリ
├── task-3/           # サブエージェント3の作業ディレクトリ（必要時）
└── task-4/           # サブエージェント4の作業ディレクトリ（必要時）
```

#### 注意事項

- 共通インフラ（キャッシュアダプター）は作成後、必ずコミット＆プッシュしてから worktree を作成
- 各worktreeは独立したブランチで作業
- 作業完了後、メインブランチにマージ

### フェーズ2: 並列実装

**重要**: 可能な限り複数のサブエージェント（clean-arch-implementer）を並列実行すること。

**前提条件**: フェーズ1.5で共通インフラ（CacheProtocol、NoCache、StreamlitCache）が作成済みであること。

#### 並列実行の方法

単一のメッセージ内で複数のTask toolを呼び出すことで、サブエージェントを並列実行できます。

**注意事項**:
- 各サブエージェントは独立した関数の移行のみを担当
- 共通インフラ（キャッシュアダプター）は既に存在することを前提
- **各サブエージェントはgit worktreeで作成した専用ディレクトリで作業**
- 各エージェントは異なるブランチで作業するためファイル競合が発生しない

**具体例**:
```
複数の実装タスクを同時に実行します。
```

次に、単一メッセージ内で複数のTask tool呼び出し：

**Task 1**: 対象関数Aの移行
- subagent_type: clean-arch-implementer
- prompt:
  ```
  対象関数: {function_name_a}
  worktreeディレクトリ: {worktree_base}/task-1
  ブランチ名: clean-arch/task-1
  移行先: {data_access_root}
  計画書: .claude/work/clean-arch-plan.md

  この関数をClean Architectureに完全移行してください。
  指定されたworktreeディレクトリで作業し、完了後にコミットしてください。
  SQLクエリをリポジトリに移動し、キャッシュアダプター対応、
  呼び出し元更新、既存関数削除、テスト作成まで完了させてください。
  ```

**Task 2**: 対象関数Bの移行
- subagent_type: clean-arch-implementer
- prompt:
  ```
  対象関数: {function_name_b}
  worktreeディレクトリ: {worktree_base}/task-2
  ブランチ名: clean-arch/task-2
  移行先: {data_access_root}
  計画書: .claude/work/clean-arch-plan.md

  この関数をClean Architectureに完全移行してください。
  指定されたworktreeディレクトリで作業し、完了後にコミットしてください。
  SQLクエリをリポジトリに移動し、キャッシュアダプター対応、
  呼び出し元更新、既存関数削除、テスト作成まで完了させてください。
  ```

（必要に応じて3-4個まで並列実行可能）

各サブエージェントには以下の情報を渡す：
- 対象関数名
- **worktreeディレクトリパス**
- **ブランチ名**
- 移行先ディレクトリパス
- 計画書の参照パス

### フェーズ3: 結果統合・検証

1. **各サブエージェントの結果を収集**
2. **各worktreeブランチをメインブランチにマージ**
   ```bash
   # メインブランチに戻る
   cd "$REPO_ROOT"
   git checkout "$BASE_BRANCH"

   # 各タスクブランチをマージ
   git merge clean-arch/task-1 --no-edit
   git merge clean-arch/task-2 --no-edit
   # （必要に応じてtask-3, task-4もマージ）
   ```
3. **統合テストの実行**
   ```bash
   poetry run python -m pytest -v
   ```
4. **worktreeのクリーンアップ**
   ```bash
   # worktreeを削除
   git worktree remove "$WORKTREE_BASE/task-1"
   git worktree remove "$WORKTREE_BASE/task-2"
   # （必要に応じてtask-3, task-4も削除）

   # 作業ブランチを削除（オプション）
   git branch -d clean-arch/task-1
   git branch -d clean-arch/task-2
   ```
5. **移行完了レポートの作成** (`.claude/work/clean-arch-migration-report.md`)

## 基本方針

### ディレクトリ構造

```
{data_access_root}/
├── models/              # Pydanticモデル
├── repositories/        # リポジトリ実装（SQLクエリ）
└── cache/               # キャッシュアダプター
    ├── cache_protocol.py
    ├── no_cache.py
    └── streamlit_cache.py
```

### 並列実行の条件

以下の条件を満たす関数は並列実行可能：
- 相互に依存していない
- 異なるテーブル/ビューにアクセス
- 異なるファイルに実装される

### サブエージェント起動時の注意

- 各サブエージェントに明確なタスク境界を与える
- 1サブエージェント = 1関数の完全移行
- 並列実行数は2-4個を推奨（処理時間とリソースのバランス）

## 事前確認

作業開始前に、ユーザーに以下を確認：

1. **データアクセス層のルートディレクトリ**: 例 `app/lib/data_access/`
2. **既存のデータ取得関数の場所**: 例 `app/lib/data_loader/`
3. **テストディレクトリ**: 例 `tests/`
4. **並列実行数**: 一度に何個の関数を移行するか（推奨: 2-4個）
5. **worktreeベースディレクトリ**: 例 `../.worktrees/clean-arch/`（リポジトリ直下の親ディレクトリ）

## 完了条件

- [ ] 全ての対象関数が移行完了
- [ ] 既存のデータ取得関数ディレクトリから該当関数が削除
- [ ] 全てのテストがパス
- [ ] 全worktreeブランチがメインブランチにマージ済み
- [ ] worktreeがクリーンアップ済み
- [ ] 移行完了レポートが作成されている
- [ ] リポジトリ層にStreamlitインポートがない

## 完了メッセージテンプレート

```
Clean Architectureへの移行が完了しました。

参照した分析結果:
- docs/inventory/by-category.md（関数分類）
- docs/use-cases/data-flows.md（データフロー）

移行完了関数:
- {関数名1} → {リポジトリクラス1}
- {関数名2} → {リポジトリクラス2}
- ...

詳細レポート: .claude/work/clean-arch-migration-report.md

次のステップ:
- MCP設計フェーズへ進む場合: `@mcp-domain-planner`
```