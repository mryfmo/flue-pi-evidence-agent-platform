# Pochi向け Worktree対応戦略

> **作成日**: 2026-05-18  
> **背景**: 2026-05-15 CCネタ発掘会（AI-075/AI-076）にて、YTより提起  
> **目的**: git worktreeを活用した並列実装＋git commitまでClaudeに自動実施させる構想を体系化する

---

## 1. 構想の全体像

```
[仕様書 / spec.json]
        │
        ▼
[コーディングエージェント（メイン調整役）]
        │
        │ 仕様を並列化可能な単位に分割
        │ git worktree を仕様タスク単位で生成
        ▼
┌────────────────────────────────────────────┐
│  .worktrees/task-1   .worktrees/task-2  ...│  ← 並列実装
│  実装エージェント     実装エージェント      │
│  ↓ git commit        ↓ git commit          │
└────────────────────────────────────────────┘
        │
        │ 各worktreeブランチをメインにマージ
        ▼
[仕様単位でコミット粒度が整った実装]
```

**狙い:**
- 大きな仕様を一括コミットすることで視認性が悪化する問題を解消
- コーディングエージェントが直列処理していた作業を並列化し、開発スピードを向上
- Claudeがgit commitまで自動実施することで、6月の吉行チームへの訴求ポイントとする

---

## 2. フェーズ構成

### フェーズ0: 仕様分析・タスク分割（メインエージェント）

1. `spec.json` / 仕様書MD を読み込む
2. 機能単位・ページ単位など**並列化可能な単位**に分割する
   - 相互依存がない機能は並列対象
   - 共通コンポーネント（共通UI・共通Snowflakeクエリ）は先行して実装
3. タスク一覧を `.claude/work/worktree-plan.md` に書き出す

**Pochi固有の分割観点:**
| 分割単位 | 並列化可否 | 備考 |
|---|:---:|---|
| 独立ページ（page_A / page_B） | ✅ 可 | session_state が分離されていれば衝突しない |
| 共通Snowflakeクエリ関数 | ❌ 先行 | 共通関数は先にmainへコミットしてからworktree作成 |
| 独立した集計ロジック | ✅ 可 | 異なるビューを参照する場合は衝突しない |
| Streamlit UI コンポーネント | ⚠️ 要確認 | 同一ファイルに複数UI実装する場合は直列が安全 |

### フェーズ1: worktree生成（メインエージェント）

```bash
REPO_ROOT=$(git rev-parse --show-toplevel)
WORKTREE_BASE="${REPO_ROOT}/../.worktrees/pochi-feature"
BASE_BRANCH=$(git branch --show-current)

mkdir -p "$WORKTREE_BASE"

# タスク数分のworktreeを作成
git worktree add -b feature/task-1 "$WORKTREE_BASE/task-1" "$BASE_BRANCH"
git worktree add -b feature/task-2 "$WORKTREE_BASE/task-2" "$BASE_BRANCH"
# ...
```

**注意点:**
- 共通インフラ（共通関数・共通Snowflakeクエリ）は**worktree作成前にコミット済みであること**
- worktree作成後に共通部分を変更するとマージ時に必ずコンフリクトが発生する

### フェーズ2: 並列実装（実装サブエージェント × N）

各サブエージェントに以下を渡す：

```
対象タスク: {task_name}（例: page_A の新規実装）
worktreeディレクトリ: {worktree_base}/task-1
ブランチ名: feature/task-1
仕様書参照: {spec_path}

作業完了後に git commit まで実施すること。
コミットメッセージは「feat: {task_name} を実装」形式。
```

**サブエージェントの完了条件:**
- [ ] 指定されたworktreeディレクトリで作業している
- [ ] 実装が完了し動作確認済み（構文エラーなし）
- [ ] UIガイドライン準拠（Streamlitコンポーネント選択が正しい）
- [ ] Snowflakeクエリはpochilib経由で実装されている
- [ ] `git commit` まで完了している

**並列実行数の目安（松本氏の90ブランチ検証より）:**
| タスク数 | 推奨並列数 | 備考 |
|:---:|:---:|---|
| 2〜4 | 2〜4 | 基本。全タスク並列でOK |
| 5〜10 | 4〜5 | バッチを2回に分ける |
| 10超 | バッチ4〜5単位 | 90ブランチ事例あり。ただし許可プロンプトへの注意が必要 |

### フェーズ3: マージ・クリーンアップ（メインエージェント）

```bash
cd "$REPO_ROOT"
git checkout "$BASE_BRANCH"

# 各worktreeブランチをマージ（仕様単位でコミット粒度が保たれる）
git merge feature/task-1 --no-edit
git merge feature/task-2 --no-edit

# worktree削除
git worktree remove "$WORKTREE_BASE/task-1"
git worktree remove "$WORKTREE_BASE/task-2"

# 作業ブランチ削除（任意）
git branch -d feature/task-1
git branch -d feature/task-2
```

---

## 3. pochi-coding-agent への組み込み方針

### 選択肢

| 方針 | メリット | デメリット |
|---|---|---|
| **A. pochi-coding-agent にworktreeモードを追加** | 既存スキルをそのまま拡張 | SKILL.mdが肥大化する可能性 |
| **B. 新スキル `pochi-worktree-coding-agent` を作成** | 責務が明確、テストしやすい | 登録ファイルを多数更新が必要 |
| **C. 既存 clean-arch-refactoring.md を汎用化** | 松本氏の検証成果を直接活用 | Clean Architecture前提の記述を除去する作業が必要 |

**推奨: 方針A**（段階的アプローチ）
1. まず `pochi-coding-agent` に「worktreeモードフラグ」を追加（`use_worktree: true`）
2. worktreeモード時のみ、フェーズ0〜3のフローを実行
3. 安定したら独立スキル化を検討

---

## 4. Pochi固有の注意点

### Snowflake接続

worktree並列実行中は**各エージェントが独立したSnowflakeセッション**を持つ。
以下のアンチパターンを避ける：

```python
# ❌ 危険: グローバルセッションを複数エージェントで共有
_session = None  # グローバル変数

# ✅ 推奨: pochilib の接続管理に従い、エージェントごとに独立接続
from pochilib.snowflake import get_session
session = get_session()
```

### session_state の衝突

並列実装したページが同一の `st.session_state` キーを使用するとコンフリクトの温床になる。
**規約**: 各ページのsession_stateキーはページ名をプレフィックスとして付ける。

```python
# ✅ 推奨
st.session_state["page_a_search_conditions"] = ...
st.session_state["page_b_filter_options"] = ...

# ❌ 危険（他ページと衝突する可能性）
st.session_state["search_conditions"] = ...
```

### Streamlitキャッシュ

`@st.cache_data` は**プロセス内グローバルキャッシュ**。並列worktree実装中はキャッシュ競合は発生しないが、マージ後に同一キーが複数定義された場合に予期しない動作が起きる可能性がある。

---

## 5. git commit メッセージ規約

仕様単位でコミット粒度を揃えるため、以下の形式を統一する。

```
{type}: {仕様名 or タスク名} を実装

{変更内容の箇条書き（任意）}

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
```

**typeの選択:**
| type | 用途 |
|---|---|
| `feat` | 新機能実装 |
| `fix` | バグ修正 |
| `refactor` | リファクタリング（機能変更なし） |
| `test` | テストコード追加・修正 |

---

## 6. フィジビリティ確認チェックリスト（AI-076対応）

6月の吉行チームへの宣言前に以下を確認・記録する。

### 技術的フィジビリティ

- [ ] Pochi既存アプリで `git worktree add` が正常動作するか（ローカル検証）
- [ ] 複数worktreeでのClaude Code並列実行時にpermission promptsが頻発しないか  
  → `.claude/settings.json` への事前許可追加で解消可能かを確認
- [ ] worktreeブランチのマージ時にコンフリクトが発生するパターンを把握し、回避策をドキュメント化
- [ ] `git commit` まで自動化した際のコミットメッセージ品質（仕様名・タスクIDを含められるか）
- [ ] 松本氏検証の90ブランチ事例における上限・最適並列数の知見を吸収

### 運用フィジビリティ

- [ ] worktree作成・削除の権限をチームメンバー全員が持っているか確認
- [ ] `.worktrees/` ディレクトリを `.gitignore` に追加しているか確認
- [ ] CI/CDパイプラインがworktreeを含むディレクトリをスキャンしないか確認

### フィジビリティ確認結果記録場所

`plan/new-dev/worktree/feasibility-results.md`（検証後に作成）

---

## 7. 吉行チームへの訴求ポイント（AI-077 6月宣言用）

**コンセプト:**  
「UX評価統合型コーディングエージェント ＋ git commitまで自動化」

**訴求ポイント:**

1. **「作った後は手離れ」を実現**  
   コーディングエージェントが実装するだけでなく、worktree単位でgit commitまで完結。人間が介入しなくても仕様単位のコミット履歴が生成される。

2. **UIデザイン品質の担保**  
   UX評価スキルと連携し、コーディング→UX評価→修正のループを1スキルで実現。UIガイドライン準拠を機械的に保証。

3. **吉行チームKPIとの接続**  
   「Claude Codeをコミッターとして普及させる」KPIに直接貢献。  
   「このスキルを使って営業していいですか」という関係を目指す（"これ使って営業していいですかと彼らに言わせる" - 外山氏）。

4. **PochiアプリへのCC普及モデルケース**  
   worktree並列コミット実績を他チームへの導入事例として展開可能。

---

## 8. 参考資料

| ファイル | 内容 |
|---|---|
| `plan/new-dev/worktree/RM-memo.md` | 松本氏の実験メモ：permission設定・90ブランチ生成の実績 |
| `plan/new-dev/worktree/clean-arch-refactoring.md` | メインスキル参考実装（Clean Architecture向け） |
| `plan/new-dev/worktree/clean-arch-implementer.md` | サブエージェント参考実装（1worktreeで1タスクを完全実施） |
| `03_meetings/CCネタ発掘会/20260515_minutes.md` | 議事録（AI-075/076/077） |

---

## 9. スキル実装タスクリスト

> **凡例**: `[ ]` 未着手 / `[x]` 完了

### フェーズ0: 仕様分析・タスク分割

- [ ] `spec.json` / 仕様書MDの読み込み処理を実装する
- [ ] 並列化可能単位への分割ロジックを実装する（相互依存チェック含む）
- [ ] タスク一覧を `.claude/work/worktree-plan.md` へ書き出す処理を実装する

### フェーズ1: worktree生成

- [ ] `REPO_ROOT` / `WORKTREE_BASE` / `BASE_BRANCH` の変数設定を実装する
- [ ] タスク数分の `git worktree add -b feature/task-N` コマンド発行ロジックを実装する
- [ ] 共通インフラ（共通関数・Snowflakeクエリ）が先行コミット済みであることのチェックを実装する

### フェーズ2: 並列実装（サブエージェント）

- [ ] サブエージェントへ渡すプロンプトテンプレートを作成する
- [ ] worktreeディレクトリ・ブランチ名・仕様書パスの動的埋め込みを実装する
- [ ] サブエージェント完了条件チェックを実装する
  - [ ] 指定worktreeディレクトリで作業していること
  - [ ] 構文エラーなしで動作確認済みであること
  - [ ] UIガイドライン準拠（Streamlitコンポーネント選択）
  - [ ] Snowflakeクエリがpochilib経由で実装されていること
  - [ ] `git commit` まで完了していること

### フェーズ3: マージ・クリーンアップ

- [ ] 各worktreeブランチの `git merge --no-edit` 処理を実装する
- [ ] `git worktree remove` によるクリーンアップ処理を実装する
- [ ] 作業ブランチ削除（`git branch -d`）の処理を実装する（任意）

### pochi-coding-agent への組み込み（方針A）

- [ ] `use_worktree` フラグを `pochi-coding-agent` のSKILL.mdフロントマターに追加する
- [ ] worktreeモード時のみフェーズ0〜3を実行する分岐処理をSKILL.mdに記述する
- [ ] 動作検証：既存Pochiアプリで worktreeモードを試行し、結果を `feasibility-results.md` に記録する
