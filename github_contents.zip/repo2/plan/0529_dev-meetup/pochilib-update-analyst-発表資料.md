# pochilib-update-analyst

**Skill ID**: `pochilib-update-analyst` ／ カテゴリ: `infra`
**作者**: ryota-suzuki-xf

---

## pochilibアップデート、これまでどうしてた？

pochilibのバージョンアップ作業、みなさんどう対応していましたか？

**影響範囲の把握が大変**
どのアプリが影響を受けるか、リポジトリを1件ずつ開いて確認していた。

**リリースノートを全部読むのがつらい**
Breaking Changes がどこに書いてあるか分からず、ページ全体を読み込んでいた。

**修正漏れが本番で発覚する**
テストは通ったのに、本番で挙動が変わっていた。確認がすべての箇所に追いつかなかった。

**アップデートを後回しにしてしまう**
面倒だから後でやろうと思っているうちに、バージョンがどんどん古いままになっていた。

---

## 何を解決するか

pochilibのバージョンアップ時に発生する「影響範囲の特定・変更ログ解析・移行計画作成」の手作業をSkillが自動化します。

| | このSkillを使わない場合 | このSkillを使った場合 |
|---|---|---|
| 影響範囲の特定 | リポジトリを1件ずつ目視確認するため、見落としが発生しやすく修正漏れのリスクがある | 複数リポジトリを一括スキャン、自動で特定 |
| 変更ログの解析 | リリースノートを目視で読むため時間がかかり、重要な変更を見落とすリスクがある | 差分を自動JSON化、重要度も自動判定 |
| 移行計画の作成 | 影響箇所を手動で整理するため、抜け漏れや工数の過小見積もりが起きやすい | リスク評価つきの移行計画レポートを自動生成 |
| 大規模影響の検知 | 件数が多くなると確認が追いつかず、対応すべき影響を途中で見落としてしまう | CRITICAL件数・影響リポジトリ数で自動警告 |

---

## 仕組み：3つのSkillのオーケストレーション

このpochilib-update-analystは「統括役」です。実際の分析は別の3つの専門Skillが担います。

```
pochilib-update-analyst（統括）
  ├─ Step 1: ヒアリング（スキャン対象・目標バージョン）
  │
  ├─ Step 2: pochilib-usage-scanner
  │           → 各アプリリポジトリをスキャン
  │           → どのモジュール・APIをどこで使っているかを JSON に記録
  │
  ├─ Step 3: pochilib-changelog-analyzer
  │           → pochilibとStreamlitのリリースノート（.md）を読み込んでJSON化
  │           → Breaking Changes / 新機能 / セキュリティ修正を重要度付けでJSON化
  │
  ├─ Step 4: pochilib-impact-detector
  │           → Step 2・3の出力結果を突合
  │           → 実際に影響を受けるアプリ・ファイル・行番号を特定
  │           → 影響度を 🔴CRITICAL / 🟠HIGH / 🟡MEDIUM / 🟢LOW で判定
  │
  └─ Step 5-6: 統合レポート生成 → ユーザーへ報告
```

### 設計の工夫：役割の明確な分離

- **usage-scanner は「現状把握」担当**：アプリリポジトリをスキャンし、pochilibのどのモジュール・APIをどこで使っているかを記録する
- **changelog-analyzer は「全記録」担当**：リリースノートに書いてある変更をすべてJSONに落とす。選別しない
- **impact-detector が「選別・判定」担当**：usage-mapと突合して、実際に関係する変更だけを抽出・影響度判定する

> **補足**: Claude Code Skill のベストプラクティスと照らし合わせると、3分割にはこんなメリットがあります：
>
> - **SKILL.md を500行以下に保てる**：1つにまとめると肥大化しやすく、処理効率も下がる。分割することで各Skillが軽量に保たれる
> - **インプット・アウトプットが明確になる**：各Skillの責務が1つに絞られ、受け渡すデータ形式（JSON）が明確になる
> - **子Skillを単体でも再利用できる**：例えば「使用状況だけ調べたい」「リリースノートだけ解析したい」といった部分利用が可能になる

### データの流れ

| Skill | インプット | アウトプット（JSON） | アウトプット（レポート） |
|---|---|---|---|
| pochilib-usage-scanner | アプリリポジトリ群の `pyproject.toml` / `*.py` | `pochilib-usage-map.json` | `pochilib-usage-map-summary.md` |
| pochilib-changelog-analyzer | pochilibリリースノート `pochilib-X.Y.Z.md`、Streamlitリリースノート `streamlit-X.Y.Z.md` | `changelog-analysis.json` | `changelog-analysis-summary.md` |
| pochilib-impact-detector | `pochilib-usage-map.json` × `changelog-analysis.json` | `impact-report.json` | `impact-summary.md` |
| pochilib-update-analyst（統括） | 上記3つのJSON・レポート | — | `upgrade-analysis-summary.md`、`migration-overview.md` |

---

## 出力イメージ

```
# pochilib アップデート影響分析レポート
対象: pochi-d-pay-merchant-visualizer-repository
アップグレード: pochilib 0.7.0 → 0.7.7

## エグゼクティブサマリ

  ● CRITICAL  0件 ✅
  ● HIGH      0件 ✅
  ● MEDIUM    2件 ⚠️  （ウィジェット挙動変更・st.spinner挙動変更）
  ● LOW       3件 ℹ️  （影響なし）

  自動修正可能: 3件 / 手動確認必要: 2件
  推定対応工数: 1〜2時間（動作確認のみ）

## ⚠️ 重要な注意事項

  🟡 Streamlit 1.53.x ウィジェット同一性ロジック変更
     key指定ありの st.multiselect / st.number_input / st.selectbox で動作確認が必要

  🟡 st.spinner 挙動変更
     一時的な要素として扱われるよう変更（バグ修正の副産物。通常は問題にならない）

## 主要な変更点（0.7.0 → 0.7.7）

  v0.7.6  get_vertexai_chat_model 戻り値クラス変更          → なし（LLM未使用）
  v0.7.6  get_vertexai_embedding_model 戻り値クラス変更     → なし（未使用）
  v0.7.6  get_vertexai_anthropic_chat_model 廃止（削除）    → なし（未使用）
  v0.7.7  Streamlit 1.53.x ウィジェット同一性変更          → ⚠️ 要確認
  v0.7.7  st.spinner 挙動変更                               → ⚠️ 要確認
  v0.7.7  Streamlit 1.53.x 新機能追加（12件）               → なし（オプトイン）

次のステップ: migration-overview.md を基に移行作業を実施
```


---

## つまずいた点・工夫した点

**Streamlitリリースノートの取得を手動からghコマンドによる自動取得に切り替えた**
当初は公式Webページを目視で確認して情報を収集していたが、指定バージョンの変更内容が漏れることがあった。そこで `gh` コマンドで自動取得するスクリプトを用意し、Skill起動前にスクリプトを実行する方式に切り替え、変更内容を確実に取得できるようにした。

**Skillの責務を「分析専門」に絞った**
「このまま修正コードも生成できたら便利では？」という気持ちはあったが、分析と実装を混在させるとSkillの責務が曖昧になる。分析結果を受け取ったあとは `pochi-coding-agent` に渡すフローを想定している。

---

---

## 影響調査レポートのあとは？

`pochilib-update-analyst` が生成するレポートは「どこを直すか」を示す地図です。
実際の改修・実装はこのあと、以下のSkillを使って進めます。

### Step 1: 仕様策定 ── [`pochi-spec-initializer`](https://github.com/nttdocomo-com/pochi-developing-knowledge-for-vibecoding-repository/tree/main/001-requirements/spec-initializer-ryota-suzuki-xf)

影響を受けるアプリの修正仕様を固めます。

- `migration-overview.md` の修正内容を入力として渡す
- 質問ベースで仕様書（`spec.json`）と実装計画（`plan.json`）を自動生成
- 「何を・どう変えるか」を構造化した形で確定させてからコーディングに入れる

### Step 2: コーディング ── [`pochi-coding-agent`](https://github.com/nttdocomo-com/pochi-developing-knowledge-for-vibecoding-repository/tree/main/004-coding/coding-agent-ryota-suzuki-xf)

仕様書と実装計画をもとに、実際のコードを自動生成します。

- `spec.json` / `plan.json` を読み込んで実装を進める
- Worktree 上で安全に作業し、差分をレビューしてからマージ可能
- 影響箇所が多くても、計画に沿って漏れなく修正できる

### 全体フロー

```
pochilib-update-analyst
  ↓ migration-overview.md（修正計画）
pochi-spec-initializer
  ↓ spec.json / plan.json（仕様・実装計画）
pochi-coding-agent
  ↓ 実装・修正コード
```

---
