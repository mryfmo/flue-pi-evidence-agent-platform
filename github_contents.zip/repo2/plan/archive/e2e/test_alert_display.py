"""アラート表示テストページのE2Eテスト

このテストは、各種アラート（st.success, st.error, st.warning, st.info, st.exception）
が正しく表示され、BasePageのメソッドで検出できることを確認します。

テスト対象アプリ:
    tests/e2e/playwright/test_apps/test_alert_display_app.py
"""

import pytest
from playwright.sync_api import Page

from tests.e2e.playwright.pages.base_page import BasePage

# このテストはローカル専用（スタンドアロンアプリを使用）
pytestmark = pytest.mark.local_only


@pytest.fixture(scope="module")
def app_port():
    """テスト専用のポート番号を返す"""
    from tests.e2e.playwright.conftest import find_available_port

    return find_available_port()


@pytest.fixture(scope="module")
def app_server_extra_args() -> list[str]:
    """スタンドアロンアプリのパスを指定"""
    return []


@pytest.fixture
def app_page_path() -> str:
    """テスト対象ページのパスを返す"""
    return "/"


class TestAlertDisplay:
    """アラート表示テストクラス"""

    def test_success_alert_detection(self, app: Page):
        """Test-1: 成功アラートが正しく表示され、検出できることを確認

        テスト観点:
        - st.success()が正しく表示されること
        - expect_success()で検出できること
        - 他のアラートタイプと誤認しないこと
        """
        page = BasePage(app)

        # Successボタンをクリック
        page.click_button("✅ Success")

        # 成功メッセージが表示されることを確認
        page.expect_success("成功メッセージです")

        # エラー・例外が表示されていないことを確認
        page.verify_no_errors()

    def test_error_alert_detection(self, app: Page):
        """Test-2: エラーアラートが正しく表示され、検出できることを確認

        テスト観点:
        - st.error()が正しく表示されること
        - expect_error()で検出できること
        - verify_no_errors_and_exceptions()で検出されること
        """
        page = BasePage(app)

        # Errorボタンをクリック
        page.click_button("❌ Error")

        # エラーメッセージが表示されることを確認
        page.expect_error("エラーメッセージです")

        # verify_no_errors_and_exceptions()が失敗することを確認
        try:
            page.verify_no_errors_and_exceptions()
            pytest.fail(
                "verify_no_errors_and_exceptions()がエラーを検出できませんでした"
            )
        except AssertionError as e:
            assert "0" in str(e), f"期待するエラーメッセージが含まれていません: {e}"

    def test_warning_alert_detection(self, app: Page):
        """Test-3: 警告アラートが正しく表示され、検出できることを確認

        テスト観点:
        - st.warning()が正しく表示されること
        - expect_warning()で検出できること
        - エラー・例外とは区別されること
        """
        page = BasePage(app)

        # Warningボタンをクリック
        page.click_button("⚠️ Warning")

        # 警告メッセージが表示されることを確認
        page.expect_warning("警告メッセージです")

        # エラー・例外が表示されていないことを確認（警告は含まれない）
        page.verify_no_errors_and_exceptions()

    def test_exception_detection(self, app: Page):
        """Test-4: 例外が正しく表示され、検出できることを確認

        テスト観点:
        - st.exception()が正しく表示されること
        - expect_exception()で検出できること
        - verify_no_errors()で検出されること
        """
        page = BasePage(app)

        # Exceptionボタンをクリック（例外チェックを無効化）
        page.wait_for_not_running()
        button = page.get_button_by_label("💥 Exception")
        page.scroll_element_into_view_if_needed(button)
        button.click()
        page.wait_for_app_run(check_for_exceptions=False)

        # 例外が表示されることを確認
        page.expect_exception("test exception")

        # verify_no_errors()が失敗することを確認
        try:
            page.verify_no_errors()
            pytest.fail("verify_no_errors()が例外を検出できませんでした")
        except AssertionError:
            pass  # 期待通り

    def test_error_or_exception_mixed_detection(self, app: Page):
        """Test-5: expect_error_or_exception()がエラーを検出できることを確認

        テスト観点:
        - expect_error_or_exception()がst.error()を検出できること
        - メッセージフィルタリングが機能すること
        """
        page = BasePage(app)

        # Errorボタンをクリック
        page.click_button("❌ Error")

        # エラーまたは例外が表示されることを確認
        page.expect_error_or_exception("エラーメッセージです")

        # ネットワークエラーは存在しないので失敗するはず
        try:
            page.expect_error_or_exception("ネットワークエラー")
            pytest.fail("存在しないエラーが検出されてしまいました")
        except AssertionError as e:
            assert "見つかりませんでした" in str(e)

    def test_error_or_exception_detects_exception(self, app: Page):
        """Test-6: expect_error_or_exception()が例外を検出できることを確認

        テスト観点:
        - expect_error_or_exception()がst.exception()を検出できること
        - メッセージフィルタリングが機能すること
        """
        page = BasePage(app)

        # Exceptionボタンをクリック（例外チェックを無効化）
        page.wait_for_not_running()
        button = page.get_button_by_label("💥 Exception")
        page.scroll_element_into_view_if_needed(button)
        button.click()
        page.wait_for_app_run(check_for_exceptions=False)

        # エラーまたは例外が表示されることを確認
        page.expect_error_or_exception("test exception")

    def test_clear_removes_all_alerts(self, app: Page):
        """Test-7: Clearボタンですべてのアラートがクリアされることを確認

        テスト観点:
        - Clearボタンでアラートが消えること
        - verify_no_errors_and_exceptions()が成功すること
        """
        page = BasePage(app)

        # まずエラーを表示
        page.click_button("❌ Error")
        page.expect_error("エラーメッセージです")

        # Clearボタンをクリック
        page.click_button("🗑️ Clear")

        # エラー・例外が表示されていないことを確認
        page.verify_no_errors_and_exceptions()

    def test_wait_for_app_run_detects_exception(self, app: Page):
        """Test-8: wait_for_app_run()が例外を検出することを確認

        テスト観点:
        - wait_for_app_run(check_for_exceptions=True)が例外を検出すること
        - デフォルトで例外検出が有効であること
        """
        page = BasePage(app)

        # Exceptionボタンをクリック
        page.wait_for_not_running()
        button = page.get_button_by_label("💥 Exception")
        button.click()

        # wait_for_app_run()が例外を検出して失敗するはず
        try:
            page.wait_for_app_run()
            pytest.fail("wait_for_app_run()が例外を検出できませんでした")
        except AssertionError as e:
            assert "st.exception()" in str(e)

    def test_wait_for_app_run_detects_error_when_enabled(self, app: Page):
        """Test-9: wait_for_app_run(check_for_errors=True)がエラーを検出することを確認

        テスト観点:
        - wait_for_app_run(check_for_errors=True)がエラーを検出すること
        - デフォルトではエラー検出が無効であること
        """
        page = BasePage(app)

        # Errorボタンをクリック
        page.wait_for_not_running()
        button = page.get_button_by_label("❌ Error")
        button.click()

        # デフォルト（check_for_errors=False）では成功するはず
        page.wait_for_app_run(check_for_errors=False)

        # Errorボタンを再度クリック
        page.wait_for_not_running()
        button = page.get_button_by_label("❌ Error")
        button.click()

        # check_for_errors=Trueだと失敗するはず
        try:
            page.wait_for_app_run(check_for_errors=True)
            pytest.fail(
                "wait_for_app_run(check_for_errors=True)がエラーを検出できませんでした"
            )
        except AssertionError as e:
            assert "st.error()" in str(e)

    def test_info_alert_is_not_detected_as_error(self, app: Page):
        """Test-10: st.info()がエラーとして誤検出されないことを確認

        テスト観点:
        - st.info()が表示されていても、verify_no_errors_and_exceptions()が成功すること
        - エラーとの区別が正しく機能すること
        """
        page = BasePage(app)

        # Infoボタンをクリック
        page.click_button("ℹ️ Info")

        # エラー・例外が表示されていないことを確認（infoは含まれない）
        page.verify_no_errors_and_exceptions()