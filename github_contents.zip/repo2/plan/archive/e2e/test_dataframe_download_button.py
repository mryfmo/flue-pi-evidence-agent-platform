"""データフレームダウンロードボタン非表示のE2Eテスト"""

import pytest
from e2e_config import get_e2e_config
from playwright.sync_api import Page

from tests.e2e.playwright.pages.dataframe_download_button_test_page import (
    DataframeDownloadButtonTestPage,
)

# このテストはローカル専用（テスト専用ページを使用）
pytestmark = pytest.mark.local_only

# テスト専用のフィクスチャをインポート
pytest_plugins = ["tests.e2e.playwright.conftest_test_page"]


@pytest.fixture(scope="module")
def app_port():
    """テスト専用のポート番号を返す"""
    from tests.e2e.playwright.conftest import find_available_port

    return find_available_port()


@pytest.fixture(scope="module", autouse=True)
def app_server(dataframe_test_page_server, app_port):
    """デフォルトのapp_serverをオーバーライドしてテストページサーバーを使用

    このフィクスチャは、conftest.pyのデフォルトapp_serverフィクスチャを
    オーバーライドして、テスト専用ページのサーバーを起動します。

    Returns:
        tuple[AsyncSubprocess, int]: (サーバープロセス, ポート番号)
    """
    yield dataframe_test_page_server, app_port


@pytest.fixture
def test_page(page: Page, app_port: int) -> DataframeDownloadButtonTestPage:
    """データフレームダウンロードボタンテストページのPage Objectを返す

    Args:
        page: Playwrightページインスタンス
        app_port: Streamlitアプリのポート番号

    Returns:
        DataframeDownloadButtonTestPage: ページオブジェクト
    """
    # テスト専用ページを直接起動
    test_page_obj = DataframeDownloadButtonTestPage(page)

    e2e_config = get_e2e_config()
    url = e2e_config.get_url(path="", local_port=app_port)

    if e2e_config.is_remote:
        print(f"🌐 リモート環境に接続: {url}")

    # ページに移動
    response = page.goto(url)

    if response is None or response.status != 200:
        raise RuntimeError(f"ページの読み込みに失敗しました: {url}")

    print(f"ページの読み込みに成功しました: {url}", flush=True)

    # ページの読み込み完了を待機
    test_page_obj.verify_page_loaded()

    return test_page_obj


class TestDataframeDownloadButton:
    """データフレームダウンロードボタン非表示テストクラス

    テスト観点:
    - st.dataframeのダウンロードボタンが非表示になっているか
    - st.data_editorのダウンロードボタンが非表示になっているか
    - 他のツールバーボタン（検索、フルスクリーンなど）は表示されているか
    """

    def test_df001_dataframeのダウンロードボタンが非表示(
        self, test_page: DataframeDownloadButtonTestPage
    ):
        """DF-001: st.dataframeのダウンロードボタンが非表示であることを確認

        テスト観点:
        - st.dataframeのツールバーにダウンロードボタンが表示されていない
        - 他のツールバーボタン（検索、フルスクリーンなど）は正常に表示される
        - common.cssのCSSが正しく適用されている
        """
        # ページ全体のスクリーンショットを撮影（ツールバー表示前）
        test_page.take_screenshot("df001_01_page_overview")

        # データフレームにホバーしてツールバーを表示
        container = test_page.get_dataframe_container()
        container.hover()
        test_page.page.wait_for_timeout(500)

        # ツールバー表示後のスクリーンショットを撮影
        test_page.take_screenshot("df001_02_toolbar_visible")

        # st.dataframeのダウンロードボタンが非表示であることを確認
        test_page.verify_dataframe_download_button_hidden()

    def test_df002_data_editorのダウンロードボタンが非表示(
        self, test_page: DataframeDownloadButtonTestPage
    ):
        """DF-002: st.data_editorのダウンロードボタンが非表示であることを確認

        テスト観点:
        - st.data_editorのツールバーにダウンロードボタンが表示されていない
        - 他のツールバーボタン（検索、フルスクリーンなど）は正常に表示される
        - common.cssのCSSが正しく適用されている
        """
        # データエディタにホバーしてツールバーを表示
        container = test_page.get_data_editor_container()
        container.hover()
        test_page.page.wait_for_timeout(500)

        # ツールバー表示後のスクリーンショットを撮影
        test_page.take_screenshot("df002_data_editor_toolbar_visible")

        # st.data_editorのダウンロードボタンが非表示であることを確認
        test_page.verify_data_editor_download_button_hidden()