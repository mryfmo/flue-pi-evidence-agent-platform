"""Layer1: SelectorLabel データ契約テスト（FEAT-AC-001）。

テスト観点:
- UIラベルとselector変数の同一性（DC-001）
- 旧ラベル「登録住所」の非存在（BR-002 / AC-01 / AC-07）
- 有効ラベルの網羅性（DC-001 allowed_values）
"""

import json
from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent.parent / "fixtures"

# 仕様で定義された有効ラベル全19項目
EXPECTED_LABELS = [
    "性別・年代・法人",
    "住所",
    "契約支社",
    "サービス契約状態",
    "回線契約",
    "利用端末",
    "dカード",
    "ARPU",
    "d払い",
    "最終接点チャネル",
    "アカウント識別子リスト(CSV)を使う",
    "ポートアウト予兆リスト",
    "ポートアウト実績",
    "マイショップ",
    "ファンダム",
    "滞在エリア(地点指定)",
    "ユーザー同意設定",
    "アウトバウンド許諾の有無",
]

FORBIDDEN_LABELS = ["登録住所"]


class TestSelectorLabelContract:
    """SelectorLabel境界のデータ契約テスト。"""

    def test_valid_fixtures_all_contain_allowed_labels(self, valid_selector_labels):
        """有効fixturesの全ケースが許可ラベルのみ含む。

        テスト観点:
        - DC-001: selector変数はUIラベルと同一の文字列リストを保持する
        - RISK-001: 旧ラベル「登録住所」の残存検知
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel)
        for case in valid_selector_labels["cases"]:
            for label in case["selector"]:
                assert label in EXPECTED_LABELS, (
                    f"許可されていないラベルが含まれています: '{label}' "
                    f"(case: {case['id']})"
                )

    def test_forbidden_label_not_in_valid_fixtures(self, valid_selector_labels):
        """有効fixturesに「登録住所」が含まれない。

        テスト観点:
        - RISK-001: 旧ラベル「登録住所」の残存検知
        - AC-01: pills選択肢に「登録住所」が存在しない
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel)
        # RISK: RISK-001
        for case in valid_selector_labels["cases"]:
            for forbidden in FORBIDDEN_LABELS:
                assert forbidden not in case["selector"], (
                    f"廃止済みラベル '{forbidden}' が有効fixturesに含まれています: "
                    f"case={case['id']}"
                )

    def test_住所_is_in_expected_labels(self):
        """「住所」ラベルが有効ラベルに含まれる。

        テスト観点:
        - DC-001: 「住所」は有効なUIラベルである
        - AC-01: pills選択肢に「住所」が存在する
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel)
        assert "住所" in EXPECTED_LABELS

    def test_登録住所_is_not_in_expected_labels(self):
        """「登録住所」ラベルが有効ラベルに含まれない。

        テスト観点:
        - BR-002: 旧ラベルは廃止済みであること
        - RISK-001: 旧ラベルの使用を検知する
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel)
        # RISK: RISK-001
        assert "登録住所" not in EXPECTED_LABELS

    def test_expected_labels_count_is_18(self):
        """有効ラベルが正確に18項目である。

        テスト観点:
        - DC-002: 全選択肢が18項目であること（dポイント削除後）
        - AC-06: 各カテゴリの項目数が仕様通りであること
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel)
        assert len(EXPECTED_LABELS) == 18

    def test_selector_value_equals_ui_label(self, valid_selector_labels):
        """selector変数の値がUIラベルと同一である（1対1対応）。

        テスト観点:
        - DC-001: output == input（ラベルと同一の値が格納される）
        - BR-002: ラベル変更時はselector参照箇所も同期変更
        - RISK-002: selector変数と画面表示の不一致検知
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel)
        # RISK: RISK-002
        for case in valid_selector_labels["cases"]:
            for label in case["selector"]:
                # ラベルがそのままselector値として格納されること
                assert isinstance(label, str), f"selectorの値は文字列でなければならない: {label}"
                assert len(label) > 0, "空文字列はselectorの有効な値ではない"

    def test_invalid_empty_selector_is_recognized(self, invalid_selector_labels):
        """空のselectorはinvalid fixturesとして正しく定義されている。

        テスト観点:
        - BR-001: 抽出条件は最低1つ以上選択が必要
        - RISK: 未選択時のバグ検知
        """
        # BR: BR-001 (抽出条件は最低1つ以上選択)
        empty_cases = [
            case for case in invalid_selector_labels["cases"]
            if case["selector"] == []
        ]
        assert len(empty_cases) >= 1, "空selectorのinvalidケースが定義されていない"

    def test_invalid_登録住所_is_recognized(self, invalid_selector_labels):
        """旧ラベル「登録住所」はinvalid fixturesとして正しく定義されている。

        テスト観点:
        - BR-002: 旧ラベルは無効として認識される
        - RISK-001: 旧ラベルの存在を検知するテストが存在すること
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel)
        # RISK: RISK-001
        old_label_cases = [
            case for case in invalid_selector_labels["cases"]
            if "登録住所" in case["selector"]
        ]
        assert len(old_label_cases) >= 1, "旧ラベル「登録住所」のinvalidケースが定義されていない"

    @pytest.mark.parametrize("label", EXPECTED_LABELS)
    def test_each_valid_label_is_string(self, label):
        """各有効ラベルが文字列型である。

        テスト観点:
        - DC-001: selector変数はstring型のリスト
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel)
        assert isinstance(label, str)
        assert len(label) > 0


class TestAddressSectionVisibilityContract:
    """AddressSectionVisibility境界のデータ契約テスト。"""

    def test_住所_selector_triggers_address_section(self, valid_selector_labels):
        """「住所」を含むselectorが存在する。

        テスト観点:
        - DC-003: 「住所」選択時に住所セクション表示のトリガーとなる
        - AC-02: 住所選択後のセクション表示
        """
        # SPEC: data_contracts[2] (entity: AddressSectionVisibility)
        cases_with_address = [
            case for case in valid_selector_labels["cases"]
            if "住所" in case["selector"]
        ]
        assert len(cases_with_address) >= 1, "「住所」を含む有効ケースが存在しない"

    def test_non_address_selector_exists(self, valid_selector_labels):
        """「住所」を含まないselectorケースが存在する。

        テスト観点:
        - DC-003: 「住所」非選択時は住所セクションが非表示
        - AC-02: 住所非選択時のセクション非表示
        """
        # SPEC: data_contracts[2] (entity: AddressSectionVisibility)
        cases_without_address = [
            case for case in valid_selector_labels["cases"]
            if "住所" not in case["selector"]
        ]
        assert len(cases_without_address) >= 1, "「住所」を含まない有効ケースが存在しない"

    def test_edge_all_labels_includes_住所(self, edge_selector_labels):
        """全19項目選択ケースに「住所」が含まれる。

        テスト観点:
        - DC-003: 全選択時も住所セクションが表示される
        """
        # SPEC: data_contracts[2] (entity: AddressSectionVisibility)
        all_items_case = next(
            (c for c in edge_selector_labels["cases"] if c["id"] == "edge-001"), None
        )
        assert all_items_case is not None, "全19項目選択ケースが存在しない"
        assert "住所" in all_items_case["selector"]
