"""Layer1: CategoryStructure データ契約テスト（FEAT-AC-001）。

テスト観点:
- 5カテゴリの存在と命名（DC-002 / AC-05）
- 各カテゴリの項目内容（DC-002 / AC-06）
- expander廃止後の全19項目の網羅性（AC-04 / RISK-003）
"""

import pytest

EXPECTED_CATEGORIES = [
    {
        "label": "ユーザー属性",
        "items": ["性別・年代・法人", "住所", "契約支社"],
    },
    {
        "label": "契約・サービス",
        "items": ["サービス契約状態", "回線契約", "利用端末", "dカード", "ARPU"],
    },
    {
        "label": "行動・決済",
        "items": ["d払い", "最終接点チャネル"],
    },
    {
        "label": "特定リスト",
        "items": [
            "アカウント識別子リスト(CSV)を使う",
            "ポートアウト予兆リスト",
            "ポートアウト実績",
        ],
    },
    {
        "label": "その他",
        "items": [
            "マイショップ",
            "ファンダム",
            "滞在エリア(地点指定)",
            "ユーザー同意設定",
            "アウトバウンド許諾の有無",
        ],
    },
]

EXPECTED_CATEGORY_LABELS = [c["label"] for c in EXPECTED_CATEGORIES]


class TestCategoryStructureContract:
    """CategoryStructure境界のデータ契約テスト。"""

    def test_fixture_has_5_categories(self, valid_category_structure):
        """fixtureが5カテゴリを定義している。

        テスト観点:
        - DC-002: 5カテゴリに分類されること
        - AC-05: 5カテゴリの見出しが表示される
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        assert len(valid_category_structure["categories"]) == 5

    def test_fixture_total_items_is_18(self, valid_category_structure):
        """fixtureの合計項目数が18である。

        テスト観点:
        - DC-002: 全18項目が含まれる（dポイント削除後）
        - RISK-003: expander廃止後の項目消失を検知
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        # RISK: RISK-003
        assert valid_category_structure["total_items"] == 18

    @pytest.mark.parametrize("category", EXPECTED_CATEGORIES)
    def test_each_category_exists_in_fixture(self, valid_category_structure, category):
        """各カテゴリが fixtureに存在する。

        テスト観点:
        - DC-002: 5カテゴリの名称が仕様通りであること
        - AC-05: カテゴリ見出しが表示されること
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        fixture_labels = [c["label"] for c in valid_category_structure["categories"]]
        assert category["label"] in fixture_labels, (
            f"カテゴリ '{category['label']}' がfixtureに存在しない"
        )

    @pytest.mark.parametrize("category", EXPECTED_CATEGORIES)
    def test_each_category_items_match_spec(self, valid_category_structure, category):
        """各カテゴリの項目が仕様と一致する。

        テスト観点:
        - DC-002: カテゴリ内の項目が仕様通りであること
        - AC-06: 各カテゴリに定義された項目が全て含まれる
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        fixture_category = next(
            (c for c in valid_category_structure["categories"]
             if c["label"] == category["label"]),
            None,
        )
        assert fixture_category is not None
        for item in category["items"]:
            assert item in fixture_category["items"], (
                f"項目 '{item}' がカテゴリ '{category['label']}' に存在しない"
            )

    def test_住所_is_in_ユーザー属性_category(self, valid_category_structure):
        """「住所」が「ユーザー属性」カテゴリに含まれる。

        テスト観点:
        - DC-002: 「住所」は「ユーザー属性」カテゴリに属する
        - AC-06: カテゴリ分類の正確性
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        user_attr = next(
            c for c in valid_category_structure["categories"]
            if c["label"] == "ユーザー属性"
        )
        assert "住所" in user_attr["items"]

    def test_登録住所_is_not_in_any_category(self, valid_category_structure):
        """「登録住所」がどのカテゴリにも含まれない。

        テスト観点:
        - BR-002: 旧ラベルはどのカテゴリにも存在してはならない
        - RISK-001: 旧ラベルの残存検知
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        # RISK: RISK-001
        for category in valid_category_structure["categories"]:
            assert "登録住所" not in category["items"], (
                f"廃止済みラベル「登録住所」がカテゴリ '{category['label']}' に存在する"
            )

    def test_csv_upload_item_is_in_特定リスト(self, valid_category_structure):
        """「アカウント識別子リスト(CSV)を使う」が「特定リスト」カテゴリに含まれる。

        テスト観点:
        - DC-002: 特定リストカテゴリに CSV アップロード機能が含まれること
        - AC-06: expander廃止後も特定リスト項目が発見可能であること
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        specific_list = next(
            c for c in valid_category_structure["categories"]
            if c["label"] == "特定リスト"
        )
        assert "アカウント識別子リスト(CSV)を使う" in specific_list["items"]

    def test_all_items_are_unique_across_categories(self, valid_category_structure):
        """全カテゴリを通じて同一項目が重複しない。

        テスト観点:
        - DC-002: 各項目は1つのカテゴリにのみ属する
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        all_items = []
        for category in valid_category_structure["categories"]:
            all_items.extend(category["items"])
        assert len(all_items) == len(set(all_items)), "カテゴリ間で重複する項目がある"

    def test_all_items_count_matches_expected_labels(
        self, valid_category_structure, expected_all_labels
    ):
        """全カテゴリの項目数がexpected_all_labelsの件数と一致する。

        テスト観点:
        - DC-001 & DC-002: SelectorLabelとCategoryStructureの整合性
        - RISK-003: expander廃止による項目消失を検知
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel), data_contracts[1] (entity: CategoryStructure)
        # RISK: RISK-003
        all_items = []
        for category in valid_category_structure["categories"]:
            all_items.extend(category["items"])
        assert len(all_items) == len(expected_all_labels), (
            f"カテゴリ内項目数({len(all_items)})とSelectorLabel数({len(expected_all_labels)})が不一致"
        )
