"""Layer2: input_conditions コンポーネントのユニットテスト（FEAT-AC-001）。

テスト観点:
- pills選択肢の文言（「住所」統一・「登録住所」廃止）
- st.expander の廃止（常時フラット表示）
- 住所セクションの条件付き表示（BR-003）
- セクション見出しの文言（「🏠 住所」統一）
- カテゴリ構造の確認（5カテゴリ）

テスト方針:
  user_behavior_analysis_tools.py は多数の外部モジュール（mylib, sac 等）に依存するため、
  AppTest によるレンダリングテストではなく、ソースコードの静的解析によりUIの
  仕様適合性を検証する。これはコードレビューの自動化に相当し、
  実装内容を仕様に照らして確認する手法として有効である。
"""

import re
from pathlib import Path

import pytest

TARGET_FILE = (
    Path(__file__).parent.parent.parent.parent
    / "app"
    / "app_pages"
    / "user_behavior_analysis_tools.py"
)


@pytest.fixture(scope="module")
def source_code() -> str:
    """対象ファイルのソースコードを返す。"""
    return TARGET_FILE.read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def source_lines(source_code) -> list[str]:
    """対象ファイルの行リストを返す。"""
    return source_code.splitlines()


def _extract_pills_options(source_code: str) -> list[str]:
    """ソースコード中の st.pills / container.pills の options リストに含まれる文字列を全て抽出する。"""
    # "options=[ ... ]" ブロックを正規表現で抽出
    pattern = r'options=\[(.*?)\]'
    blocks = re.findall(pattern, source_code, re.DOTALL)
    labels = []
    for block in blocks:
        # 文字列リテラルを抽出
        labels.extend(re.findall(r'"([^"]+)"', block))
        labels.extend(re.findall(r"'([^']+)'", block))
    return labels


class TestPillsLabelAfterImprovement:
    """pills選択肢ラベルの文言テスト（改善A・C適用後の期待値）。"""

    def test_住所_が選択肢に含まれる(self, source_code):
        """pills選択肢に「住所」ラベルが存在する。

        テスト観点:
        - BR-002: UIラベルとselector変数の同期
        - AC-01: pills選択肢に「住所」として表示される
        """
        # BR: BR-002 (selector変数の値はUIラベルと同一)
        all_options = _extract_pills_options(source_code)
        assert "住所" in all_options, (
            f"「住所」がpills選択肢に存在しません。現在のoptions: {all_options}"
        )

    def test_登録住所_が選択肢に含まれない(self, source_code):
        """pills選択肢に「登録住所」ラベルが存在しない（廃止確認）。

        テスト観点:
        - BR-002: 旧ラベルの廃止
        - AC-01: 「登録住所」が選択肢に存在しない
        - RISK-001: 旧ラベル残存の検知
        """
        # BR: BR-002 (selector変数の値はUIラベルと同一のため、ラベル変更時は参照箇所を全て同期)
        # RISK: RISK-001
        all_options = _extract_pills_options(source_code)
        assert "登録住所" not in all_options, (
            "廃止済みラベル「登録住所」がpills選択肢に残存しています。"
        )

    def test_全18項目が選択肢に含まれる(self, source_code, expected_all_labels):
        """pills選択肢に全18項目が存在する（expander廃止後の網羅性確認）。

        テスト観点:
        - AC-04: expanderが存在せず全選択肢が常時表示
        - AC-06: 各カテゴリに定義された項目が全て含まれる
        - RISK-003: expander廃止による項目消失の検知
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel)
        # RISK: RISK-003
        all_options = _extract_pills_options(source_code)
        for label in expected_all_labels:
            assert label in all_options, (
                f"仕様に定義された選択肢「{label}」がpills選択肢に存在しません。"
            )

    @pytest.mark.parametrize("label", [
        "性別・年代・法人",
        "住所",
        "契約支社",
        "サービス契約状態",
        "アカウント識別子リスト(CSV)を使う",
        "ポートアウト予兆リスト",
    ])
    def test_主要ラベルが選択肢に含まれる(self, source_code, label):
        """主要な選択肢ラベルが個別に存在することを確認する。

        テスト観点:
        - DC-001: 各ラベルがUIに正しく表示される
        - AC-06: カテゴリ内の項目が正しく配置されている
        """
        # SPEC: data_contracts[0] (entity: SelectorLabel)
        all_options = _extract_pills_options(source_code)
        assert label in all_options, (
            f"ラベル「{label}」がpills選択肢に存在しません。"
        )


class TestExpanderAbsence:
    """expander廃止テスト（改善C適用後の期待値）。"""

    def test_詳細条件expanderが存在しない(self, source_code):
        """「より詳細な条件を使用する」expanderが存在しない。

        テスト観点:
        - AC-04: expanderが存在せず全選択肢が常時表示される
        - RISK-003: expander廃止による全選択肢の常時表示
        """
        # BR: BR-003 (expander廃止後は常に全表示)
        # RISK: RISK-003
        assert "より詳細な条件を使用する" not in source_code, (
            "廃止済みのexpander「より詳細な条件を使用する」がソースコードに残存しています。"
        )

    def test_詳細条件用pills_keyが廃止されている(self, source_code):
        """旧来の詳細条件用pillsキーが廃止されている。

        テスト観点:
        - AC-04: expanderとともに詳細条件pillsも廃止・再構成されている
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        assert "st_pills__target_conditions_selector_detailed" not in source_code, (
            "旧詳細条件pills key 'st_pills__target_conditions_selector_detailed' が残存しています。"
        )


class TestAddressSectionVisibility:
    """住所セクションの条件付き表示テスト（BR-003）。"""

    def test_住所セクションの条件式が正しい(self, source_code):
        """住所セクションの表示条件が「住所」を参照している。

        テスト観点:
        - BR-003: 「住所」選択時のみ住所セクションを表示
        - AC-02: 「住所」選択後のセクション表示
        - RISK-004: 住所セクション表示条件の破壊を検知
        """
        # BR: BR-003 (「住所」を選択した場合のみ、住所セクションを表示する)
        # RISK: RISK-004
        assert '"住所" in selector' in source_code, (
            "住所セクションの条件式 '\"住所\" in selector' が見つかりません。"
            "「登録住所」のままになっている可能性があります。"
        )

    def test_旧条件式_登録住所_が廃止されている(self, source_code):
        """旧住所セクションの条件式「登録住所」が廃止されている。

        テスト観点:
        - BR-003: 旧条件式の廃止
        - RISK-004: 旧条件式残存による住所セクション非表示バグの検知
        """
        # RISK: RISK-004
        assert '"登録住所" in selector' not in source_code, (
            "旧条件式 '\"登録住所\" in selector' がソースコードに残存しています。"
        )


class TestSectionHeaderAfterImprovement:
    """セクション見出し文言テスト（改善A適用後の期待値）。"""

    def test_住所セクションの見出しが_住所_である(self, source_code):
        """住所セクションの見出しが「🏠 住所」になっている。

        テスト観点:
        - BR-002: ラベル変更時はselector参照箇所を全て同期
        - AC-02: セクション見出しが「🏠 住所」で表示される
        - RISK-002: selector変数と画面表示の不一致を検知
        """
        # BR: BR-002 (selector変数の値はUIラベルと同一)
        # RISK: RISK-002
        assert "🏠 住所" in source_code, (
            "住所セクション見出し「🏠 住所」がソースコードに存在しません。"
        )

    def test_旧見出し_登録住所_が廃止されている(self, source_code):
        """旧住所セクション見出し「🏠 登録住所」が廃止されている。

        テスト観点:
        - BR-002: 旧見出しの廃止
        - RISK-002: 旧見出し残存による画面表示不整合の検知
        """
        # RISK: RISK-002
        assert "🏠 登録住所" not in source_code, (
            "廃止済みの見出し「🏠 登録住所」がソースコードに残存しています。"
        )


class TestCategoryStructureInSource:
    """カテゴリ構造のソースコード検証テスト（改善C適用後）。"""

    @pytest.mark.parametrize("category_label", [
        "ユーザー属性",
        "契約・サービス",
        "行動・決済",
        "特定リスト",
        "その他",
    ])
    def test_カテゴリ見出しが存在する(self, source_code, category_label):
        """5カテゴリの見出し文字列がソースコードに存在する。

        テスト観点:
        - AC-05: 5カテゴリそれぞれの前にst.caption（カテゴリ名）が表示される
        - DC-002: CategoryStructureが仕様通りに実装されている
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        assert category_label in source_code, (
            f"カテゴリ見出し「{category_label}」がソースコードに存在しません。"
        )

    def test_st_captionがinput_conditions内に存在する(self, source_code):
        """input_conditions 内に st.caption が使用されている。

        テスト観点:
        - AC-05: st.caption でカテゴリ名が表示される
        - NF-002: st.caption スタイルでカテゴリ見出しを実装
        """
        # SPEC: data_contracts[1] (entity: CategoryStructure)
        assert "st.caption(" in source_code, (
            "st.caption() がソースコードに存在しません。"
        )


class TestWarningOnEmptySelection:
    """未選択時の警告表示テスト（BR-001）。"""

    def test_未選択時のwarning実装が存在する(self, source_code):
        """未選択時に st.warning を表示するコードが存在する。

        テスト観点:
        - BR-001: 抽出条件は最低1つ以上選択が必要
        """
        # BR: BR-001 (抽出条件は最低1つ以上選択)
        assert "st.warning" in source_code, (
            "st.warning がソースコードに存在しません。BR-001の未選択時警告が実装されていません。"
        )

    def test_input_conditions関数が存在する(self, source_code):
        """input_conditions 関数がソースコードに定義されている。

        テスト観点:
        - AC-07: 既存の抽出機能が変更前後で同一動作すること
        """
        # BR: BR-001
        assert "def input_conditions(" in source_code, (
            "input_conditions 関数がソースコードに存在しません。"
        )
