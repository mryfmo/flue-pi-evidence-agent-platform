import json
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# プロジェクトルートをsys.pathに追加（app.* 形式でインポート可能にする）
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

FIXTURES_DIR = project_root / "tests" / "fixtures"


def _passthrough_decorator(*args, **kwargs):
    """st.cache_data / st.cache_resource を無効化するパススルーデコレータ。"""
    if len(args) == 1 and callable(args[0]):
        return args[0]

    def inner(func):
        return func

    return inner


@pytest.fixture(autouse=True)
def disable_streamlit_cache():
    """全テストでStreamlitキャッシュデコレータを無効化する。"""
    with (
        patch("streamlit.cache_data", side_effect=_passthrough_decorator),
        patch("streamlit.cache_resource", side_effect=_passthrough_decorator),
    ):
        yield


@pytest.fixture
def valid_selector_labels():
    """有効なselectorラベルのfixtures（valid/selector_labels.json）。"""
    path = FIXTURES_DIR / "valid" / "selector_labels.json"
    return json.loads(path.read_text(encoding="utf-8"))


@pytest.fixture
def invalid_selector_labels():
    """無効なselectorラベルのfixtures（invalid/selector_labels.json）。"""
    path = FIXTURES_DIR / "invalid" / "selector_labels.json"
    return json.loads(path.read_text(encoding="utf-8"))


@pytest.fixture
def edge_selector_labels():
    """エッジケースのselectorラベルfixtures（edge/selector_labels.json）。"""
    path = FIXTURES_DIR / "edge" / "selector_labels.json"
    return json.loads(path.read_text(encoding="utf-8"))


@pytest.fixture
def valid_category_structure():
    """有効なカテゴリ構造のfixtures（valid/category_structure.json）。"""
    path = FIXTURES_DIR / "valid" / "category_structure.json"
    return json.loads(path.read_text(encoding="utf-8"))


@pytest.fixture
def expected_all_labels():
    """仕様で定義された全19選択肢ラベルのリスト。"""
    path = FIXTURES_DIR / "valid" / "category_structure.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    labels = []
    for cat in data["categories"]:
        labels.extend(cat["items"])
    return labels


@pytest.fixture
def expected_categories():
    """仕様で定義された5カテゴリ構造のリスト。"""
    path = FIXTURES_DIR / "valid" / "category_structure.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    return data["categories"]