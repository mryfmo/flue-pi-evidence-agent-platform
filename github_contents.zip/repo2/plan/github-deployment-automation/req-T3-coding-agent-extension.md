# 要件定義書: pochi-coding-agent 拡張（ブランチ切り・push・PR作成）

対応タスク: T-3（coding-agent への GitHub 連携統合 〜2026-06-19）  
作成日: 2026-05-24  更新日: 2026-05-25（セキュリティレビュー対応: SEC-04/06/10/11/14 を反映、レビュー002.md 指摘対応・push+PR作成を github-push-and-pr-creator に分離）  
担当: RS

---

## 1. スキルメタデータ

| 項目 | 値 |
|---|---|
| スキルID | `pochi-coding-agent` |
| 種別 | 既存スキル拡張 |
| 対象ファイル | `skills/spec/pochi-coding-agent/skills/run/SKILL.md` |
| バージョン変更 | 1.0.0 → 1.1.0 |
| ブランチ名 | `feature/coding-agent-github-integration` |
| Issue | TBD |
| 期限 | 2026-06-19 |
| 依存タスク | Tdd（pochi-tdd-test-generator 実行）完成・`tests/.onboarding/test-mapping.json` が存在すること（推奨）、T-2.5（github-branch-creator 実装）完成・`github_branch` が plan.json に存在すること |
| 後続タスク | T-4（github-push-and-pr-creator）がコミット済みブランチを push + PR 作成する |

---

## 2. 概要

現行の `pochi-coding-agent`（spec.json/plan.json を読んで実装するCoding Agent）に対して、以下の参照処理を追加する。

**追加フェーズ（1箇所）**:

1. **実装開始前**: `github_branch` の存在確認（plan.json を読むのみ）・`test-mapping.json` の読み込み

**git 操作はこのスキルの担当外**。ブランチ作成・切り替えは `github-branch-creator`（T-2.5）、コミット・push・PR 作成は `github-push-and-pr-creator`（T-4）の責務。ユーザーが適切なブランチ上で本スキルを起動することを前提とする。

> **スクリプト化対象外**: このスキルは実装内容自体が Claude Code の判断に依存するため、Pythonスクリプトで操作を固定することはできない。git 操作を担わないことでリスクを排除する。

---

## 3. 現行ワークフロー（変更なし部分）

```
Task Select → Gather Context → Take Action（実装） → Verify Work
```

現行の5フェーズは変更しない。前後に GitHub 連携フェーズを追加する。

---

## 3-B. バリデーションルール

> **SEC-04 対応**: plan.json から読み取った値を Bash コマンドに直接埋め込むことは禁止する。
> 共通ガイドラインは `skill-requirements-overview.md` の「SEC-04」セクションを参照。

### plan.json フィールドの検証

| フィールド | 期待する型 | 許可パターン | 失敗時の動作 |
|---|---|---|---|
| `github_issue_number` | number | `/^[0-9]+$/` | エラー終了「github-issue-creator を先に実行してください」 |
| `github_branch` | string | `/^feature\/issue-[0-9]+$/`（最大100文字） | エラー終了「branch 名が不正です。github-branch-creator を確認してください」 |
| `github_pr_number` | number または null | `/^[0-9]+$/` または null | null の場合は PR 作成フェーズへ進む |

### PR 本文の生成（インジェクション対策）

```bash
# ❌ 禁止: spec.title を直接展開
--title "[Feature] ${SPEC_TITLE}（Closes #${ISSUE_NUMBER}）"

# ✅ 推奨: jq @json でエスケープ後、引数として渡す
SPEC_TITLE=$(jq -r '.title | @json' spec.json)
SUMMARY=$(jq -r '.summary | @json // "(サマリなし)"' task_result.json)
# PR 本文は /tmp ファイル経由
cat > /tmp/pr_body.md << 'HEREDOC'
# PR 本文（リテラル記述のため変数展開なし）
HEREDOC
# 動的な部分は jq で安全に生成して追記
jq -r '"Closes #\(.github_issue_number)"' plan.json >> /tmp/pr_body.md
```

---

## 4. 追加機能要件

### 4-1. 起動時（前提確認フェーズ）—— Task Select の前

> **実行主体**: Claude Code が plan.json / test-mapping.json をファイル読み取りで確認する。git コマンドは実行しない。

```
0. test-mapping.json の存在確認（Tdd フェーズとの連携）
   - tests/.onboarding/test-mapping.json が存在する場合: 読み込んで実装対象関数・ファイルを特定
   - 存在しない場合: 警告を出力「pochi-tdd-test-generator を先に実行することを推奨します」して続行
     （hard stop にしない: plan.json が揃っていれば実装は続行可能）

1. plan.json から github_branch を読む。バリデーション実施（3-B 参照）（SEC-04）

2-A. github_branch が存在しない場合:
     → エラー出力: 「github-branch-creator を先に実行してください（plan.json に github_branch が見つかりません）」
     → スキルを停止

2-B. github_branch が存在する場合（例: "feature/issue-42"）:
     → ユーザーが既に当該ブランチ上で作業していることを前提とする
     → 現在のブランチを確認し、不一致の場合は警告を表示して続行確認
     （git checkout は実行しない。ブランチ切り替えはユーザーが手動で行う）

3. 実装フェーズ（Task Select → ... → Verify Work）
   - test-mapping.json が存在する場合: implementation_hint を参照して実装対象の関数・ファイルを特定し、
     TDD RED テストが GREEN になることを目標に実装する
   - test-mapping.json がない場合: 従来通り plan.json の tasks を参照して実装する
```

### 4-2. 全タスク完了後（完了案内フェーズ）—— Verify Work の後

> **git コマンドは実行しない**。コミットはユーザーが手動で行う。

```
1. 完了サマリを出力:
   ✅ 実装完了
      次のステップ:
        1. git add -A && git commit -m "feat: Implement {spec.title} (Closes #{NNN})" を実行
        2. github-push-and-pr-creator を起動して push + PR 作成を行ってください
```

> **push・PR 作成は担当しない**: 後続の `github-push-and-pr-creator`（T-4）が担う。詳細は req-T4-github-push-and-pr-creator.md を参照。

---

## 5. plan.json への追加フィールド

| フィールド | 値の例 | 追記タイミング | 担当スキル |
|---|---|---|---|
| `github_branch` | `"feature/issue-42"` | T-2.5 実行時 | `github-branch-creator` |

（`github_issue_number` は T-2 で `github-issue-creator` が追記済み）
（`github_branch` は T-2.5 で `github-branch-creator` が追記済み）
（`github_pr_number` は T-4 で `github-push-and-pr-creator` が追記する）

---

## 6. 入力仕様（追加分）

| 入力 | 形式 | 必須 | 説明 |
|---|---|:---:|---|
| `plan.json` の `github_branch` | string | ✅ | T-2.5 で追記済みのブランチ名（例: `feature/issue-42`） |
| `plan.json` の `github_issue_number` | number | ✅ | T-2 で追記済みであること（コミットメッセージの `Closes #NNN` に使用） |
| `tests/.onboarding/test-mapping.json` | JSON ファイル | 推奨 | Tdd フェーズで `pochi-tdd-test-generator` が生成。`implementation_hint` を参照して実装対象関数を特定する |

> **認証不要**: このスキルはローカル git 操作（checkout・commit）のみ。push・PR 作成は `github-push-and-pr-creator` が担う。

---

## 7. 非機能要件

| 要件 | 内容 |
|---|---|
| 冪等性（ブランチ） | 既存ブランチがある場合は checkout のみ（-b オプションなし） |
| エラーハンドリング | checkout 失敗時はエラー終了。コミット失敗時は明確なメッセージで停止 |
| 認証不要 | git 操作を担わないため GitHub 認証は不要（SEC-08） |
| git操作なし | ブランチ切り替え・コミット・push はユーザーが手動で実施。スクリプト化対象外 |
| コマンドインジェクション対策 | plan.json の github_branch を読み取るのみ。allowlist チェックは参照確認のみ（SEC-04） |

---

## 8. 変更対象ファイル（実装時）

| ファイル | 更新内容 |
|---|---|
| `skills/spec/pochi-coding-agent/skills/run/SKILL.md` | ブランチ checkout フェーズ・コミットフェーズの手順を追記（push・PR は github-push-and-pr-creator に委譲） |
| `skills/spec/pochi-coding-agent/plugin.json` | version を 1.0.0 → 1.1.0 にインクリメント |
| `release-note.md` | `### Changed` に追記（v1.0.0 → v1.1.0: ブランチ切り・push・PR 作成機能を追加） |

> marketplace.json / skills.json は変更不要（スキルIDが変わらないため）  
> README.md の `/plugin install` コマンドリストも変更不要

---

## 9. 未解決事項（実装前に確認）

| ID | 項目 | Phase 1 暫定方針 |
|---|---|---|
| U-1 | checkout 失敗時の対応 | ブランチが存在しない場合はエラーメッセージを出力して停止。github-branch-creator を先に実行するよう案内する |
| SEC-04 | Bash コマンドテンプレートの確定 | 3-B の allowlist + `jq @json` パターンを採用 |

> push・PR 作成に関する未解決事項（コンフリクト対応・認証方式・base ブランチ等）は req-T4-github-push-and-pr-creator.md に移管。

---

## 10. 実装上の注意

> **このスキルは git コマンドを実行しない**。ブランチ切り替え・コミット・push はユーザーが手動で行う。

### 起動前にユーザーが実施すること

```bash
# 1. github-branch-creator でブランチを作成済みであること
# 2. 手動でブランチを切り替えてから本スキルを起動すること
git checkout feature/issue-NNN

# 本スキル起動 → 実装完了
```

### 実装完了後にユーザーが実施すること

```bash
# 1. コミット（コミットメッセージはスキルが提案する）
git add -A
git commit -m "feat: Implement {spec.title} (Closes #NNN)"

# 2. github-push-and-pr-creator を起動して push + PR 作成
```

> push・PR 作成の詳細は req-T4-github-push-and-pr-creator.md を参照。
