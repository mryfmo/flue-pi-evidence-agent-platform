# 要件定義書: github-pr-reviewer（新規スキル）

対応タスク: T-5（PR 自動コードレビュー・コメント投稿）  
作成日: 2026-05-25  
担当: RS

---

## 1. スキルメタデータ

| 項目 | 値 |
|---|---|
| スキルID | `github-pr-reviewer` |
| 表示名 | GitHub PR Reviewer |
| カテゴリ | `spec/` |
| 種別 | 新規スキル |
| バージョン | 1.0.0 |
| 正式ファイルパス | `skills/spec/github-pr-reviewer/skills/run/SKILL.md` |
| ブランチ名 | `feature/github-pr-reviewer` |
| Issue | TBD |
| 期限 | T-4 完成後 |
| 依存タスク | T-4（github-push-and-pr-creator）完成・`github_pr_number` が plan.json に存在すること |
| 後続フロー | 人間レビュアーが Approve → 自動マージ（T-7 / Phase 2） |

---

## 2. 概要

`github-push-and-pr-creator`（T-4）が作成した PR の diff を取得し、Claude Code がコードレビューを実施して GitHub PR にレビューコメントを自動投稿する。

人間レビュアーはコメントを確認して Approve するだけでよく、レビューの抜け漏れ・観点ブレを防止する。

**このスキルが担うこと**:
- PR diff の取得（`gh pr diff`）
- spec.json / plan.json を参照した仕様適合チェック
- セキュリティ・パフォーマンス・コーディング規約の観点でのレビュー
- `gh pr review --comment` でレビューコメントを PR に投稿

**このスキルが担わないこと**:
- Approve・マージの実行（人間が行う）
- テストの実行（CI が行う）

---

## 3. バリデーションルール

> **SEC-04 対応**: gh 操作は `scripts/github_pr_reviewer.py` が担う。Claude Code はスクリプトを Bash で呼び出すだけであり、gh コマンドを直接組み立てない。
> 共通ガイドラインは `skill-requirements-overview.md` の「SEC-04」セクションを参照。

### plan.json フィールドの検証（スクリプト内で実施）

| フィールド | 期待する型 | 許可パターン | 失敗時の動作 |
|---|---|---|---|
| `github_pr_number` | number | `/^[0-9]+$/`（最大10文字） | エラー終了「github-push-and-pr-creator を先に実行してください」 |
| `github_branch` | string | `/^feature\/issue-[0-9]+$/`（最大100文字） | エラー終了「branch 名が不正です」 |

### Claude Code の呼び出し方

```bash
# ✅ CCはスクリプトを呼び出すだけ
python skills/spec/github-pr-reviewer/scripts/github_pr_reviewer.py \
  --repo "$GITHUB_REPO" \
  --plan plan.json
```

---

## 4. 機能要件

> **実行主体**: Claude Code は `scripts/github_pr_reviewer.py` を Bash で呼び出す。gh コマンドの実行・バリデーション・エラーハンドリングはすべてスクリプト内で完結する。

```
1. Claude Code が Bash でスクリプトを呼び出す
   python skills/spec/github-pr-reviewer/scripts/github_pr_reviewer.py \
     --repo "$GITHUB_REPO" \
     --plan plan.json

2. スクリプト内処理（github_pr_reviewer.py）
   a. 前提確認
      - gh auth status → 未認証の場合はエラー終了（「gh auth login を実行してください」）
      - GITHUB_REPO 形式チェック（allowlist）→ パターン外はエラー終了（F-06対応）
      - subprocess.run(["gh", "repo", "view", GITHUB_REPO]) でリポジトリ存在確認（SEC-09）

   b. plan.json から以下を読み、バリデーション実施（3 参照）（SEC-04）
      - github_pr_number / github_branch

   c. PR の diff を取得
      subprocess.run(["gh", "pr", "diff", str(pr_number), "--repo", repo])

   d. 参照ファイルを読み込む
      - spec.json / plan.json / tests/.onboarding/test-mapping.json（存在する場合）

   e. Claude Code がレビューを実施（以下の観点）
      - 仕様適合: acceptance_criteria を満たしているか
      - テスト: test-mapping.json の対象関数に対応するテストが存在するか
      - セキュリティ: OWASP Top 10 / SQL インジェクション / 認証漏れ等
      - コーディング規約: アンチパターン違反
      - パフォーマンス: N+1 クエリ・不要な全件取得等

   f. レビューコメントを PR に投稿（--comment のみ。--approve / --request-changes は引数として存在しない）
      subprocess.run(["gh", "pr", "review", str(pr_number), "--repo", repo,
                      "--comment", "--body", comment_body])

   g. 監査ログを stdout に出力（SEC-10）

   h. 完了サマリを出力
      ✅ PR #MMM にレビューコメントを投稿しました
         指摘件数: N 件（重大: X 件 / 軽微: Y 件）
         URL: https://github.com/{GITHUB_REPO}/pull/MMM
         次のステップ: レビュアーがコメントを確認して Approve してください
```

---

## 5. レビューコメントのフォーマット

```markdown
## 🤖 自動コードレビュー結果

### ✅ 仕様適合チェック
- acceptance_criteria の充足: {OK / NG（理由）}

### 🔍 指摘事項（{N} 件）

#### [重大] {ファイル名}:{行番号} — {指摘タイトル}
{指摘内容}
**修正案**: {修正案}

#### [軽微] {ファイル名}:{行番号} — {指摘タイトル}
{指摘内容}

---
*このレビューは `github-pr-reviewer` スキルにより自動生成されました。  
plan.json: `{実行時に取得した plan.json の実パス}`*
```

---

## 6. 入力仕様

| 入力 | 形式 | 必須 | 説明 |
|---|---|:---:|---|
| `plan.json` の `github_pr_number` | number | ✅ | T-4 で追記済みの PR 番号 |
| `plan.json` の `github_branch` | string | ✅ | レビュー対象のブランチ名 |
| `spec.json` | JSON | ✅ | 仕様・受け入れ条件の参照に使用 |
| `tests/.onboarding/test-mapping.json` | JSON | 推奨 | テスト網羅チェックに使用 |
| `GITHUB_REPO` | 環境変数 | ✅ | 対象リポジトリ（例: `org/pochi-eats`） |

> **認証**: `gh auth login` 済みの状態を使用。認証方式の使い分けは `skill-requirements-overview.md` セクション 6 参照（SEC-02/03）。

---

## 7. 非機能要件

| 要件 | 内容 |
|---|---|
| 冪等性 | 再実行時は既存の自動レビューコメントを更新せず、新規コメントとして追記する（PR 上で履歴として残す） |
| Approve・Request Changes 禁止 | スキルは COMMENT のみ投稿。Approve / Request Changes は人間レビュアーが行う |
| コマンドインジェクション対策 | github_pr_number / github_branch を allowlist チェック後に使用（SEC-04） |
| 監査ログ | gh pr review でのコメント投稿操作を JSON 形式で stdout に出力（SEC-10） |

---

## 8. 新規作成ファイル（実装時）

| ファイル | 内容 |
|---|---|
| `skills/spec/github-pr-reviewer/skills/run/SKILL.md` | スキル本体（YAMLフロントマター必須） |
| `skills/spec/github-pr-reviewer/plugin.json` | name / description / version / keywords / license |

更新が必要な登録ファイル:

| ファイル | 更新内容 |
|---|---|
| `.claude-plugin/marketplace.json` | `plugins[]` に新エントリ追加 |
| `.claude/skills.json` | `skills[]` に新エントリ追加 |
| `README.md` | Skill一覧・`/plugin install` コマンドリスト・トリガーフレーズ例を追記 |
| `release-note.md` | `### Added` に追記 |
| `skills/tools/pochi-skill-navigator/skills/run/SKILL.md` | spec カテゴリのスキル一覧・キーワードマッピングを更新 |

---

## 9. 未解決事項（実装前に確認）

| ID | 項目 | Phase 1 暫定方針 |
|---|---|---|
| U-review-1 | レビュー観点の優先度・深さ | 仕様適合・セキュリティを必須観点とし、パフォーマンス・規約は警告レベルで投稿 |
| U-review-2 | 既存コメントの重複投稿 | 再実行時は新規コメントとして追記（更新・削除はしない）。Phase 2 で「最新のみ残す」オプションを検討 |
| U-review-3 | diff が大きすぎる場合の扱い | ファイル単位で分割してレビュー。1 PR あたり最大 50 ファイルを上限とし、超過時は警告を出して続行 |
| U-2 | GitHub 認証方式 | 各ユーザーの `gh auth login` 済みghセッションを使用。特別なトークン管理・PAT発行は不要（詳細: skill-requirements-overview.md セクション 6 参照） |

---

## 10. 実装例（スクリプト骨子）

> **注**: Claude Code は以下のスクリプトを Bash で呼び出す。スクリプトは `skills/spec/github-pr-reviewer/scripts/github_pr_reviewer.py` に配置する。

```python
import argparse, json, re, subprocess, sys
from pathlib import Path
from datetime import datetime, timezone

REPO_PATTERN = re.compile(r'^[a-zA-Z0-9\-\.]+/[a-zA-Z0-9\-\.]+$')
PR_NUMBER_PATTERN = re.compile(r'^[0-9]{1,10}$')
BRANCH_PATTERN = re.compile(r'^feature/issue-[0-9]+$')

def run(cmd: list, **kwargs):
    """subprocess.run のラッパー。shell=True は使用しない。"""
    return subprocess.run(cmd, capture_output=True, text=True, timeout=60, **kwargs)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--plan", required=True)
    args = parser.parse_args()

    if not REPO_PATTERN.match(args.repo):
        print("❌ GITHUB_REPO の形式が不正です", file=sys.stderr)
        raise SystemExit(1)

    plan = json.loads(Path(args.plan).read_text())
    pr_number = plan.get("github_pr_number")
    branch_name = plan.get("github_branch", "")

    if not PR_NUMBER_PATTERN.match(str(pr_number)):
        print("❌ github_pr_number が不正。github-push-and-pr-creator を先に実行してください", file=sys.stderr)
        raise SystemExit(1)
    if not BRANCH_PATTERN.match(branch_name):
        print("❌ github_branch が不正", file=sys.stderr)
        raise SystemExit(1)

    # PR diff を取得（--approve / --request-changes は引数として存在しない）
    diff_result = run(["gh", "pr", "diff", str(pr_number), "--repo", args.repo])
    if diff_result.returncode != 0:
        print(f"❌ diff 取得失敗。\n{diff_result.stderr.strip()[:500]}", file=sys.stderr)
        raise SystemExit(1)

    pr_diff = diff_result.stdout

    # レビューコメント生成は Claude Code が担う（スクリプトから戻り値として受け取る）
    # comment_body = <Claude Code によるレビュー結果>

    # コメント投稿（--comment のみ。--approve / --request-changes は使用不可）
    review_result = run([
        "gh", "pr", "review", str(pr_number),
        "--repo", args.repo,
        "--comment",
        "--body", comment_body,
    ])
    if review_result.returncode != 0:
        print(f"❌ コメント投稿失敗。\n{review_result.stderr.strip()[:500]}", file=sys.stderr)
        raise SystemExit(1)

    # 監査ログ（SEC-10）
    print(json.dumps({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "skill_name": "github-pr-reviewer",
        "operation": "gh pr review --comment",
        "target_repo": args.repo,
        "result": "success",
        "resource_id": pr_number,
    }))
    print(f"✅ PR #{pr_number} にレビューコメントを投稿しました")
```
