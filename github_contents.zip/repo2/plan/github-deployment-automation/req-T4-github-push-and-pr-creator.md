# 要件定義書: github-push-and-pr-creator（新規スキル）

対応タスク: T-4（push + PR 作成 〜T-3 完成後）  
作成日: 2026-05-25  
担当: RS

---

## 1. スキルメタデータ

| 項目 | 値 |
|---|---|
| スキルID | `github-push-and-pr-creator` |
| 表示名 | GitHub Push & PR Creator |
| カテゴリ | `spec/` |
| 種別 | 新規スキル |
| バージョン | 1.0.0 |
| 正式ファイルパス | `skills/spec/github-push-and-pr-creator/skills/run/SKILL.md` |
| ブランチ名 | `feature/github-push-and-pr-creator` |
| Issue | TBD |
| 期限 | T-3 完成後 |
| 依存タスク | T-3（pochi-coding-agent 拡張）完成・コミット済みであること、`github_branch` と `github_issue_number` が plan.json に存在すること |

---

## 2. 概要

`pochi-coding-agent`（T-3）がコミットまで完了したブランチを GitHub にプッシュし、dev ブランチへの PR を作成する。

このスキルを分離した理由:
- **責務の明確化**: 実装（coding-agent）と GitHub 操作（push・PR）は独立した関心事
- **再実行の局所化**: push 失敗・PR 作成失敗時にコーディング全体を再実行せず、このスキル単体で再試行できる
- **権限の最小化**: GitHub 認証が必要な操作をこのスキルに集約することで、coding-agent は認証不要のまま維持できる

---

## 3. バリデーションルール

> **SEC-04 対応**: git/gh 操作は `scripts/github_push_pr_creator.py` が担う。Claude Code はスクリプトを Bash で呼び出すだけであり、コマンドを直接組み立てない。
> 共通ガイドラインは `skill-requirements-overview.md` の「SEC-04」セクションを参照。

### plan.json フィールドの検証（スクリプト内で実施）

| フィールド | 期待する型 | 許可パターン | 失敗時の動作 |
|---|---|---|---|
| `github_issue_number` | number | `/^[0-9]+$/`（最大10文字） | エラー終了「github-issue-creator を先に実行してください」 |
| `github_branch` | string | `/^feature\/issue-[0-9]+$/`（最大100文字） | エラー終了「branch 名が不正です。github-branch-creator を確認してください」 |
| `github_pr_number` | number または null | `/^[0-9]+$/` または null | 既に設定済みの場合は PR 作成をスキップして終了（冪等性） |

### PR 本文の生成（インジェクション対策、スクリプト内で実施）

```python
# ✅ subprocess.run はリスト形式。シェル展開なし
# ✅ /tmp 固定パスは使用しない。mktemp でテンポラリファイルを生成
import tempfile, os
with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as f:
    f.write(pr_body_content)
    tmp_path = f.name
try:
    subprocess.run(["gh", "pr", "create", "--body-file", tmp_path, ...], ...)
finally:
    os.unlink(tmp_path)
# git push --force は引数として存在しない
```

### Claude Code の呼び出し方

```bash
# ✅ CCはスクリプトを呼び出すだけ
python skills/spec/github-push-and-pr-creator/scripts/github_push_pr_creator.py \
  --repo "$GITHUB_REPO" \
  --spec spec/features/FEAT-001/spec.json \
  --plan plan.json
```

---

## 4. 機能要件

> **実行主体**: Claude Code は `scripts/github_push_pr_creator.py` を Bash で呼び出す。git/gh コマンドの実行・バリデーション・エラーハンドリングはすべてスクリプト内で完結する。

```
1. Claude Code が Bash でスクリプトを呼び出す
   python skills/spec/github-push-and-pr-creator/scripts/github_push_pr_creator.py \
     --repo "$GITHUB_REPO" \
     --spec <spec.jsonパス> \
     --plan plan.json

2. スクリプト内処理（github_push_pr_creator.py）
   a. 前提確認
      - gh auth status → 未認証の場合はエラー終了（「gh auth login を実行してください」）
      - GITHUB_REPO 形式チェック（allowlist）→ パターン外はエラー終了（F-06対応）
      - subprocess.run(["gh", "repo", "view", GITHUB_REPO]) でリポジトリ存在確認（SEC-09）

   b. plan.json から以下を読み、バリデーション実施（3 参照）（SEC-04）
      - github_issue_number / github_branch / github_pr_number

   c. コミット済み確認
      - subprocess.run(["git", "status", "--porcelain"]) で未コミット変更を確認
      - 未コミットの場合: エラー終了「コミットを完了してから実行してください」

   d. git push origin を実行（subprocess.run リスト形式）
      - --force は引数として存在しない
      - push 失敗（コンフリクト等）→ エラー内容を表示して停止
      - push 失敗時は plan.json への github_pr_number 書き戻しを行わない（部分状態を避ける）

   e. PR を作成（github_pr_number が null の場合のみ）
      - PR 本文は tempfile.NamedTemporaryFile で生成し finally で削除（/tmp 固定パス禁止）
      - subprocess.run(["gh", "pr", "create", "--body-file", tmp_path, ...])

   f. PR 番号を plan.json の github_pr_number にアトミック書き込み（SEC-06）
      - mktemp を plan.json と同一ディレクトリに作成し rename

   g. 監査ログを stdout に出力（SEC-10）

   h. 完了サマリを出力
      ✅ PR #MMM を作成しました
         タイトル: [Feature] {spec.title}（Closes #{NNN}）
         URL: https://github.com/{GITHUB_REPO}/pull/MMM
         plan.json に github_pr_number: MMM を書き込みました
```

---

## 5. plan.json への追加フィールド

| フィールド | 値の例 | 追記タイミング | 担当スキル |
|---|---|---|---|
| `github_pr_number` | `99` | PR 作成完了後 | `github-push-and-pr-creator`（このスキル） |

（`github_issue_number` は T-2 で `github-issue-creator` が追記済み）
（`github_branch` は T-2.5 で `github-branch-creator` が追記済み）

---

## 6. 入力仕様

| 入力 | 形式 | 必須 | 説明 |
|---|---|:---:|---|
| `plan.json` の `github_branch` | string | ✅ | T-2.5 で追記済みのブランチ名（例: `feature/issue-42`） |
| `plan.json` の `github_issue_number` | number | ✅ | T-2 で追記済みであること（PR タイトル・本文の `Closes #NNN` に使用） |
| `spec.json` の `title` | string | ✅ | PR タイトルに使用。`jq @json` でエスケープ後に渡す（SEC-04） |
| `GITHUB_REPO` | 環境変数 | ✅ | 対象リポジトリ（例: `org/pochi-eats`）。`gh` コマンドの `--repo` フラグに渡す |

> **認証**: `gh auth login` 済みの状態を使用。認証方式の使い分けは `skill-requirements-overview.md` セクション 6 参照（SEC-02/03）。

---

## 7. 非機能要件

| 要件 | 内容 |
|---|---|
| 冪等性（PR 作成） | `github_pr_number` が plan.json に既にある場合は PR 作成をスキップして終了 |
| 冪等性（push） | 同一ブランチへの再 push はコンフリクトがなければ成功する。push 済みで PR 未作成の状態から再実行可能 |
| エラーハンドリング | push 失敗（競合・権限エラー）時は task status を `blocked` にして明確なメッセージで停止 |
| コンフリクト対応 | push 失敗時はブランチ・コミットをそのまま残す。ユーザーが手動で conflict 解決後にスキルを再実行する（SEC-14）。リモートブランチを削除してやり直す場合は `gh api -X DELETE repos/{GITHUB_REPO}/git/refs/heads/{BRANCH_NAME}` を手動実行すること |
| plan.json アトミック書き込み | tmp ファイルを plan.json と同一ディレクトリに作成して rename する（SEC-06） |
| コマンドインジェクション対策 | github_issue_number / github_branch を allowlist チェック後に使用。PR タイトル・本文は `jq @json` エスケープ + `/tmp` ファイル経由（SEC-04） |
| 監査ログ | git push / gh pr create 操作を JSON 形式で stdout に出力（SEC-10） |
| base ブランチ | `dev` ブランチが存在する前提（確認が必要: U-base） |

---

## 8. 新規作成ファイル（実装時）

| ファイル | 内容 |
|---|---|
| `skills/spec/github-push-and-pr-creator/skills/run/SKILL.md` | スキル本体（YAMLフロントマター必須） |
| `skills/spec/github-push-and-pr-creator/plugin.json` | name / description / version / keywords / license |

更新が必要な登録ファイル:

| ファイル | 更新内容 |
|---|---|
| `.claude-plugin/marketplace.json` | `plugins[]` に新エントリ追加 |
| `.claude/skills.json` | `skills[]` に新エントリ追加 |
| `README.md` | Skill一覧・`/plugin install` コマンドリスト・トリガーフレーズ例を追記 |
| `release-note.md` | `### Added` に追記 |
| `skills/tools/pochi-skill-navigator/skills/run/SKILL.md` | spec カテゴリのスキル一覧・キーワードマッピングを更新 |

---

## 9. 未解決事項（実装前に確認）

| ID | 項目 | Phase 1 暫定方針 |
|---|---|---|
| U-1 | コンフリクト発生時の対応フロー | push 失敗 → task status = blocked → ユーザーが手動で conflict 解決（rebase or merge）→ スキル再実行で push 再試行。plan.json への部分書き込みは行わない（SEC-14） |
| U-base | PR の `base` ブランチ | `dev` ブランチが存在する前提。存在しない場合の fallback を確認 |
| U-2 | GitHub 認証方式 | 各ユーザーの `gh auth login` 済みghセッションを使用。特別なトークン管理・PAT発行は不要（詳細: skill-requirements-overview.md セクション 6 参照） |
| SEC-06 | plan.json アトミック書き込みの実装 | tmp + rename パターンを全書き戻し箇所で適用 |

---

## 10. 実装例（スクリプト骨子）

> **注**: Claude Code は以下のスクリプトを Bash で呼び出す。スクリプトは `skills/spec/github-push-and-pr-creator/scripts/github_push_pr_creator.py` に配置する。

```python
import argparse, json, re, subprocess, sys, tempfile, os
from pathlib import Path
from datetime import datetime, timezone

REPO_PATTERN = re.compile(r'^[a-zA-Z0-9\-\.]+/[a-zA-Z0-9\-\.]+$')
ISSUE_NUMBER_PATTERN = re.compile(r'^[0-9]{1,10}$')
BRANCH_PATTERN = re.compile(r'^feature/issue-[0-9]+$')

def run(cmd: list, **kwargs):
    """subprocess.run のラッパー。shell=True は使用しない。"""
    return subprocess.run(cmd, capture_output=True, text=True, timeout=30, **kwargs)

def validate_inputs(repo, issue_number, branch_name):
    if not REPO_PATTERN.match(repo):
        print("❌ GITHUB_REPO の形式が不正です", file=sys.stderr)
        raise SystemExit(1)
    if not ISSUE_NUMBER_PATTERN.match(str(issue_number)):
        print("❌ github_issue_number が不正です", file=sys.stderr)
        raise SystemExit(1)
    if not BRANCH_PATTERN.match(branch_name):
        print("❌ github_branch が不正です", file=sys.stderr)
        raise SystemExit(1)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--spec", required=True)
    parser.add_argument("--plan", required=True)
    args = parser.parse_args()

    plan = json.loads(Path(args.plan).read_text())
    spec = json.loads(Path(args.spec).read_text())

    validate_inputs(args.repo, plan["github_issue_number"], plan["github_branch"])

    # 未コミット確認
    status = run(["git", "status", "--porcelain"])
    if status.stdout.strip():
        print("❌ 未コミットの変更があります。コミットを完了してから実行してください", file=sys.stderr)
        raise SystemExit(1)

    # push（--force は引数として存在しない）
    push = run(["git", "push", "origin", plan["github_branch"]])
    if push.returncode != 0:
        print(f"❌ push 失敗。\n{push.stderr.strip()[:500]}", file=sys.stderr)
        raise SystemExit(1)

    # PR 作成（冪等）
    if plan.get("github_pr_number") is None:
        pr_body = f"Closes #{plan['github_issue_number']}\n\n## 変更内容\n（サマリなし）"
        with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as f:
            f.write(pr_body)
            tmp_path = f.name
        try:
            result = run([
                "gh", "pr", "create",
                "--repo", args.repo,
                "--title", f"[Feature] {spec['title']} (Closes #{plan['github_issue_number']})",
                "--body-file", tmp_path,
                "--base", "dev",
                "--head", plan["github_branch"],
                "--json", "number", "--jq", ".number",
            ])
        finally:
            os.unlink(tmp_path)

        pr_number = int(result.stdout.strip())

        # アトミック書き込み（SEC-06、同一ディレクトリ）
        plan_path = Path(args.plan)
        tmp = plan_path.parent / f"plan.json.tmp_{os.getpid()}"
        plan["github_pr_number"] = pr_number
        tmp.write_text(json.dumps(plan, ensure_ascii=False, indent=2))
        tmp.replace(plan_path)

        # 監査ログ（SEC-10）
        print(json.dumps({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "skill_name": "github-push-and-pr-creator",
            "operation": "gh pr create",
            "target_repo": args.repo,
            "result": "success",
            "resource_id": pr_number,
        }))
        print(f"✅ PR #{pr_number} を作成しました")
```
