# 【セキュリティレビュー依頼】GitHub自動デプロイSkill設計

作成日: 2026-05-26  
担当: RS

Pochiアプリ開発の自動化パイプライン拡張として、GitHub操作（Issue作成〜PR自動レビュー）をClaude Codeスキル化する計画を設計しました。実装着手前にセキュリティ観点でのレビューをお願いしたいです。

設計書: `plan/github-deployment-automation/`（`skill-requirements-overview.md` が全体サマリ）


---

Skill含めた全体のロジック(仮)

```
spec initializerでspec.jsonを生成する
github-issue-creator(new)      : gh issue create → plan.jsonにissue番号を書き戻す
github-branch-creator(new)   : feature/issue-NNN をローカルに作成 → plan.jsonにbranch名を書き戻
pochi-tdd-test-generator(new) :テスト駆動開発用単体テストコード生成
pochi-coding-agent        : テストコードをもとにコーディング・コミット（ローカルのみ）
github-push-and-pr-creator(new): git push + gh pr create（base: dev）→ plan.jsonにPR番号を書き戻す
github-pr-reviewer(new)        : PR diffをAIレビュー → gh pr review --comment で投稿（approveはしない
人間レビュー・Approve → 自動マージ（dev）
devでシナリオテストなど人間テスト
dev→mainマージ
```

---

## 検討しているセキュリティ対策

- 認証: 各ユーザーの `gh auth login` 済みghセッションをそのまま使用（PAT管理・追加設定不要）。`fetch_streamlit_release_notes.py` と同方式
- 入力検証: issue番号・ブランチ名・spec.id・GITHUB_REPOをallowlist正規表現でスクリプト内チェック
- コマンドインジェクション: git/ghコマンドはPythonスクリプト経由・`subprocess.run(list形式)`のみ（`shell=True`禁止）
- 権限最小化: スキル別スコープ分離（T1: `issues:write`のみ、T4: `contents:write`+`pull-requests:write`、T5: `pull-requests:write`のみ）
- 破壊的操作防止: 多層防御: Pythonスクリプトにforce push/reset --hard等のコードを物理的に不在化 → settings.json deny → git pre-push hook → GitHub Branch Protection Rules
- plan.json整合性: フィールドオーナーシップ制（書き込みスキルを1つに限定）＋アトミック書き込み（tmp rename）
- 自動マージ条件: CI全パス＋セキュリティスキャン（Critical/High 0件）＋人間レビュー1名以上が必須。devブランチのみ・mainへの自動マージは禁止
- 監査ログ: JSON形式（timestamp/skill/operation/result）・GitHubコメントにスキル名とplan.jsonパスを埋め込み

---

## レビューしてほしい観点

1. **認証方式**: `gh auth login`（hosts.yml永続化）のみで運用する設計のリスク許容度。共有環境での利用制限など追加すべきガードはあるか
2. **コマンドインジェクション**: allowlistパターン・Pythonリスト実行の実装で十分か。spec.title/descriptionなどフリーテキストフィールドの扱いに抜け穴はないか
3. **自動マージ条件**: devへの自動マージ許容条件として「CI全パス＋人間レビュー1名」は妥当か
4. **部分状態（Partial State）**: push済み・PR未作成で停止した場合のリモートブランチ孤立への対策は十分か
5. **AIレビュー（T5）の信頼境界**: AIがghコメントを投稿するまでを許容範囲とした設計で問題ないか
6. **その他**: 上記以外で設計上の穴があれば指摘ください

コメントはこのファイルへの直接書き込みでも、Slackスレッドへの返信でも構いません。よろしくお願いします。

---

## レビューコメント欄

<!-- レビュアーはここにコメントを記入してください -->
