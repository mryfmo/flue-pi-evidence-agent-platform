# 要件定義書: github-issue-creator（新規スキル）

対応タスク: T-1（スキル設計 〜2026-06-05）・T-2（スキル実装 〜2026-06-12）  
作成日: 2026-05-24  更新日: 2026-05-25（セキュリティレビュー対応: SEC-04/06/09/10 を反映）  
担当: RS

---

## 1. スキルメタデータ

| 項目 | 値 |
|---|---|
| スキルID | `github-issue-creator` |
| 表示名 | GitHub Issue Creator |
| カテゴリ | `spec/` |
| 種別 | 新規スキル |
| バージョン | 1.0.0 |
| 正式ファイルパス | `skills/spec/github-issue-creator/skills/run/SKILL.md` |
| ブランチ名 | `feature/github-issue-creator` |
| Issue | TBD |
| 期限 | 2026-06-12 |
| 依存タスク | なし（パイプラインの先頭スキル） |

---

## 2. 概要

`pochi-spec-initializer` が生成した `spec.json`（frozen状態）を読み込み、GitHub Issue を自動登録する。
登録した Issue 番号（`#NNN`）を `plan.json` に書き戻すことで、後続の `pochi-coding-agent`（拡張）がブランチ名とPR本文を自動決定できるようにする。

**このスキルがない場合の現状課題（C-1）**: Issue・ブランチ・PRの紐付けが手動であり、コミット後にブランチ情報が失われる。

---

## 3. 入力仕様

| 入力 | 形式 | 必須 | 説明 |
|---|---|:---:|---|
| `spec/features/<id>/spec.json` | JSON（frozen） | ✅ | 機能仕様書。`status: "frozen"` であること |
| `spec/plans/<id>.json` または `plan.json` | JSON | ✅ | 書き戻し対象。`github_issue_number` が未設定であること |
| `GITHUB_REPO` | 環境変数 | ✅ | 対象リポジトリ（例: `org/pochi-eats`）。`gh` コマンドの `--repo` フラグに渡す |
| アプリパス | 引数またはカレントディレクトリ | ✅ | spec.json の探索起点 |

> **認証**: Claude Code が起動時に `gh auth status` を Bash で実行して認証状態を確認する。未認証の場合はエラー終了し「`gh auth login` を実行してください」とガイドする。`gh auth login` はスキル起動前にユーザーが一度だけ実施する環境準備（スキルの責務外）。認証方式の使い分けは `skill-requirements-overview.md` の「セクション 6 環境変数」を参照すること（SEC-02/SEC-03）。

### spec.json の参照フィールド

```
spec.id                  → Issue タイトルのプレフィックス
spec.title               → Issue タイトル
spec.overview            → Issue 本文の「概要」セクション
spec.requirements[]      → Issue 本文の「要件」セクション
  .id / .priority / .description
spec.acceptanceCriteria[]→ Issue 本文の「受入基準」セクション（チェックリスト形式）
  .id / .description
```

---

## 4. 出力仕様

### 4-1. GitHub Issue（登録結果）

```markdown
# [{spec.id}] {spec.title}

## 概要
{spec.overview}

## 要件
- [HIGH] REQ-001: ユーザーが○○できること
- [MID]  REQ-002: システムが○○すること

## 受入基準
- [ ] AC-001: ○○が表示されること
- [ ] AC-002: ○○が保存されること
```

- ラベル: `spec.requirements` の `priority` 値を小文字変換（例: `priority-high`）
  - ラベルが存在しない場合はラベルなしで登録（エラーにしない）

### 4-2. plan.json への書き戻し

```json
{
  "github_issue_number": 42
}
```

plan.json の既存フィールドを保持したまま `github_issue_number` のみ追記・更新する。

### 4-3. 標準出力（完了サマリ）

```
✅ Issue #42 を登録しました
   タイトル: [FEAT-001] ユーザー検索機能
   URL: https://github.com/org/pochi-eats/issues/42
   plan.json に github_issue_number: 42 を書き込みました
```

---

## 4-B. バリデーションルール

> **SEC-04 対応**: git/gh 操作は `scripts/github_issue_creator.py` が担う。Claude Code はスクリプトを Bash で呼び出すだけであり、gh コマンドを直接組み立てない。
> 共通ガイドラインは `skill-requirements-overview.md` の「SEC-04」セクションを参照。

### 入力フィールドの allowlist パターン（スクリプト内で検証）

| フィールド | 入力元 | 許可パターン | 最大長 |
|---|---|---|---|
| `spec.id` | spec.json | `/^[A-Z][A-Z0-9\-]*$/` | 50文字 |
| `spec.title` | spec.json | シェルメタ文字禁止（`$()`, バッククォート, `;&\|<>` 等） | 200文字 |
| `spec.requirements[].priority` | spec.json | `/^[A-Z0-9]+$/` | 50文字 |
| `GITHUB_REPO` | 環境変数 | `/^[a-zA-Z0-9\-\.]+\/[a-zA-Z0-9\-\.]+$/` | 200文字 |

### Claude Code の呼び出し方

```bash
# ✅ CCはスクリプトを呼び出すだけ。コマンド組み立て・バリデーションはスクリプト内で完結
python skills/spec/github-issue-creator/scripts/github_issue_creator.py \
  --repo "$GITHUB_REPO" \
  --spec spec/features/FEAT-001/spec.json \
  --plan plan.json
```

### バリデーション失敗時の動作

- 許可パターン外の値を検出: エラー終了し plan.json への書き戻しを行わない
- エラーメッセージにユーザー入力値をそのまま出力しない

---

## 5. 処理フロー

> **実行主体**: Claude Code は `scripts/github_issue_creator.py` を Bash で呼び出す。git/gh コマンドの実行・バリデーション・エラーハンドリングはすべてスクリプト内で完結する。

```
1. Claude Code が Bash でスクリプトを呼び出す
   python skills/spec/github-issue-creator/scripts/github_issue_creator.py \
     --repo "$GITHUB_REPO" \
     --spec <spec.jsonパス> \
     --plan <plan.jsonパス>

2. スクリプト内処理（github_issue_creator.py）
   a. 入力検証
      - gh auth status → 未認証の場合はエラー終了し「gh auth login を実行してください」とガイド
      - GITHUB_REPO が未設定 → エラー終了（フォールバックなし）（SEC-09）
      - GITHUB_REPO の形式チェック（allowlist）→ パターン外はエラー終了（F-06対応）
      - GITHUB_REPO の存在確認: gh repo view で確認。不在の場合はエラー終了（SEC-09）
      - spec.json が見つからない → エラー終了
      - spec.status が "frozen" でない → 警告を表示し続行確認（強制実行は許可）
      - spec.id / spec.title の allowlist チェック（4-B 参照）→ パターン外の値はエラー終了（SEC-04）

   b. 重複チェック
      - plan.json に github_issue_number が既にある
        → 「Issue #NNN が既に登録済みです。再登録しますか？」と確認
        → No の場合はスキップして終了

   c. Issue 本文の組み立て（spec.json の各フィールドから Markdown を生成）

   d. subprocess.run(cmd_list) で gh issue create を実行し Issue 番号を取得
      - ラベルが存在しない場合は --label を省略（gh はラベル不存在時にエラーを返す）
      - 失敗時は sanitized stderr を表示して終了

   e. plan.json に Issue 番号をアトミック書き込み（SEC-06）
      - mktemp を plan.json と同一ディレクトリに作成し rename

   f. 監査ログを stdout に出力（SEC-10）
      {"timestamp":"...","skill_name":"github-issue-creator","operation":"gh issue create",...}

   g. 完了サマリを出力（4-3 参照）
```

---

## 6. 非機能要件

| 要件 | 内容 |
|---|---|
| 認証 | Claude Code が起動時に `gh auth status` を Bash で実行して確認。未ログイン時はエラー終了し「`gh auth login` でログインしてください」とガイド（`gh auth login` 自体はスキル起動前の環境準備） |
| 冪等性 | `github_issue_number` が既存の場合は確認後にスキップ可能 |
| エラーハンドリング | `gh` コマンド失敗時は Issue 番号を書き戻さない（中途半端な状態にしない） |
| ラベル不存在時 | `--label` を省略してラベルなしで Issue 登録（エラーにしない） |
| コマンドインジェクション対策 | spec.json の全フィールドに allowlist バリデーションを実施。Bash 実行時は `jq @json` でエスケープ・引数配列方式を使用（SEC-04） |
| バリデーション失敗時 | エラー終了。plan.json への書き戻しを行わない（SEC-04） |
| GITHUB_REPO 存在確認 | 起動時に `gh repo view "$GITHUB_REPO"` で確認。未設定またはリポジトリ不在時はエラー終了（フォールバックなし）（SEC-09） |
| plan.json アトミック書き込み | tmp ファイル経由の rename パターンを使用（競合・部分書き込み防止）（SEC-06） |
| 監査ログ | gh issue create 操作を JSON 形式で stdout に出力（timestamp/skill_name/operation/target_repo/plan_json_path/result/resource_id）（SEC-10） |

---

## 7. SKILL.md フロントマター（案）

```yaml
---
name: github-issue-creator
description: >-
  spec.json（frozen状態）を読み込んで GitHub Issue を自動登録し、Issue 番号を plan.json に書き戻すスキル。
  pochi-spec-initializer の後、pochi-coding-agent の前に実行する。
  「GitHub Issue を登録して」「Issue を作成して」「github-issue-creator を起動」と言われたときに使用する。
allowed-tools: Read, Write, Edit, Bash
---
```

---

## 8. skills.json エントリ（案）

```json
{
  "id": "github-issue-creator",
  "name": "GitHub Issue Creator",
  "path": "skills/spec/github-issue-creator/skills/run/SKILL.md",
  "entrypoint_type": "prompt",
  "entrypoint_path": "skills/spec/github-issue-creator/skills/run/SKILL.md",
  "triggers": [
    "GitHub Issueを登録して",
    "Issueを作成して",
    "github-issue-creatorを起動"
  ],
  "auto_load": false
}
```

---

## 9. marketplace.json エントリ（案）

```json
{
  "name": "github-issue-creator",
  "source": "./skills/spec/github-issue-creator",
  "description": "spec.json を読んで GitHub Issue を登録し plan.json に Issue 番号を書き戻す"
}
```

---

## 10. plugin.json（案）

```json
{
  "name": "github-issue-creator",
  "description": "spec.json を読んで GitHub Issue を登録し、Issue 番号を plan.json に書き戻す新規スキル",
  "version": "1.0.0",
  "keywords": [],
  "license": "社内利用限定"
}
```

---

## 11. pochi-skill-navigator への追記（案）

### spec/ テーブルへの追記行

```markdown
| `github-issue-creator` | spec.json（frozen）を読み込んで GitHub Issue を自動登録し、Issue 番号を plan.json に書き戻す | 「GitHub Issueを登録して」「Issueを作成して」「github-issue-creatorを起動」 | spec.json + plan.json（frozen状態）＋ GITHUB_TOKEN/REPO 環境変数 | ❌ |
```

（単独実行 ❌ = pochi-spec-initializer で spec.json を frozen にしてから実行すること）

### キーワードマッピングへの追記行

```markdown
| GitHub Issue、Issue登録、issue-creator | `github-issue-creator`（spec.json frozen後）→ `pochi-coding-agent`（拡張・ブランチ切り） |
```

---

## 12. 実装時に更新が必要なファイル

| ファイル | 更新内容 |
|---|---|
| `skills/spec/github-issue-creator/skills/run/SKILL.md` | 新規作成（フロントマター + 本体） |
| `skills/spec/github-issue-creator/plugin.json` | 新規作成 |
| `.claude-plugin/marketplace.json` | `plugins[]` にエントリ追加 |
| `.claude/skills.json` | `skills[]` にエントリ追加 |
| `README.md` | Skill一覧テーブル・`/plugin install` コマンドリスト（2箇所）・トリガーテーブルに追記 |
| `skills/tools/pochi-skill-navigator/skills/run/SKILL.md` | spec/ テーブル・キーワードマッピング・ワークフロー更新 |
| `release-note.md` | `### Added` に追記 |
| `.claude/skills/SKILLS_MANAGEMENT.md` | 現在登録されているSkillsテーブルに追記（推奨） |

---

## 13. 未解決事項（実装前に確認）

| ID | 項目 | 暫定方針 |
|---|---|---|
| U-2 | 認証方式（CI/CD 環境での `GITHUB_TOKEN` / `GH_TOKEN` 設定） | 開発環境は `gh auth login` 済みの状態を使用。CI/CD は自動発行 `GITHUB_TOKEN` を優先（SEC-03）。詳細は `skill-requirements-overview.md` セクション 6 参照 |
| — | Issue ラベル事前作成の要否（`priority-high` 等） | ラベルなしでも登録可能な実装にする（`--label` 省略） |
| — | `GITHUB_REPO` の指定方法（引数 vs 環境変数 vs config ファイル） | 初期は環境変数で統一。`--repo` フラグに渡す |
| SEC-04 | Bash コマンドテンプレート（allowlist + `jq @json`）の最終確定 | 実装時に 4-B のパターンを基準として使用する |
| SEC-09 | GITHUB_REPO 存在チェックの実装方針 | `gh repo view "$GITHUB_REPO" --json name` で確認（未設定・不在時はエラー終了） |
