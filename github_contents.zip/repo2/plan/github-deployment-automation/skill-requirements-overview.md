# GitHub・デプロイ自動化 スキル要件定義 — 俯瞰サマリ

作成日: 2026-05-24  更新日: 2026-05-26（github-deployment-automation-plan.md の技術情報を統合・plan.md 廃止）  
出典: roadmap_20260522081047.html（To-Beパイプライン）・CC活用ネタ発掘会 第3回 議論ポイント（§2）  
担当: RS

---

## 0. 背景・目的

### 現状認識

Pochiスキル群によるAI駆動開発は以下のパイプラインを確立している。

```
[仕様書入力] → spec-initializer → coding-agent → コミット
```

しかし、**コミット以後のGitHub・デプロイ作業が手動**のため、開発完結の自動化達成度が約60%に留まっている。

| 段階 | 自動化度 | 定義 |
|---|---|---|
| **現状** | 60% | spec初期化 → coding → コミット（コード完成まで自動） |
| **本計画達成** | 80% | Issue作成 → ブランチ → PR → マージ（コンフリクトなし）→ devデプロイ |
| **将来** | 90%以上 | 本番デプロイまで自動・エラー自動復帰 |

### 共通認識（CCネタ発掘会 2026-05-22）

> 「GitHubとデプロイ作業の自動化が鍵。これができれば**8割AI駆動**と言える」
>
> 「残り2割 = 最後のOK承認 + spec-initializerへの入力ドキュメント作成（PDMチーム担当）」

### 狙い

Pochiアプリ開発の**全プロセスを完全自動化し、ヒューマン・イン・ザ・ループを「最終確認＆承認」のみに絞ること**。

### 現状課題

| # | 課題 | 影響度 | 原因 |
|---|---|---|---|
| **C-1** | Issue-ブランチ-PRの紐付けが手動 | 高 | GitHub API呼び出しスキルがない |
| **C-2** | コミット直後にブランチ情報が失われる | 高 | coding-agentがコミット内容を出力しない |
| **C-3** | マージ基準が明確でない | 中 | GitHub auto-mergeルールが未設定 |
| **C-4** | デプロイ環境の一貫性がない | 高 | デプロイスクリプトがapp repoごとにばらばら |
| **C-5** | 動作確認（UIテスト）を自動化できない | 高 | E2Eテスト・UIテストの統合がない |

### 活用可能な既存資産

| 資産 | 用途 |
|---|---|
| `pochi-spec-initializer` | Issue内容を仕様に変換。**逆方向でIssue生成が可能** |
| `pochi-coding-agent` | コード生成済み。**ブランチ・コミット・プッシュ処理を追加可能** |
| `pochi-unit-test-generator` | Layer 1・2テスト自動生成。**マージ前チェック実装可能** |
| `pochi-e2e-test-generator` | E2Eテスト。**本番前検証に活用可能** |
| GitHub Actions（既存app repos） | CI/CDトリガー。**スキルチェーンの終点** |

---

## 1. スキルチェーン全体フロー（To-Be）

> **実行主体**: 各スキルステップの git/gh 操作は、すべて Claude Code が Bash ツール経由で直接実行する。  
> 人間の介入点は H1・H2・H3 の3箇所。

```
【人間 H1】PDM — 仕様ドキュメント作成
  ↓
pochi-spec-initializer（既存・変更なし）
  → Claude Code が spec.json（frozen）/ plan.json / spec.md を生成
  ↓
github-issue-creator【新規スキル / T-1・T-2】
  → Claude Code が spec.json を読み込み、Bash で gh issue create を実行
  → GitHub Issue を登録し、plan.json に github_issue_number を書き戻す
  ↓
github-branch-creator【新規スキル / T-2.5】
  → Claude Code が plan.json から github_issue_number を読む
  → Bash で git checkout -b feature/issue-NNN を実行（ローカルブランチ作成）
  → plan.json に github_branch を書き戻す
  ↓
pochi-tdd-test-generator【既存スキル / Tdd】← ★ TDD テスト先行生成（コーディング直前）
  → ブランチ上で spec.json の data_contracts / business_rules から Layer1・2 の RED テストを生成
  → tests/contracts/, tests/unit/, tests/fixtures/ を出力
  → tests/.onboarding/test-mapping.json を出力（pochi-coding-agent の実装指針）
  ※ 前提: spec.json に data_contracts と business_rules フィールドが必須（pochi-spec-initializer が生成）
  ↓
pochi-coding-agent【既存スキル 拡張 / T-3】
  → Claude Code が plan.json から github_branch を読み、Bash で git checkout を実行
  → tests/.onboarding/test-mapping.json の implementation_hint を参照して実装対象関数を特定（推奨）
  → コード実装・コミット（RED テストが GREEN になることを目標）
  ↓
github-push-and-pr-creator【新規スキル / T-4】
  → Bash で git push origin feature/issue-NNN を実行
  → Bash で gh pr create を実行し GitHub PR を作成（base: dev）
  → plan.json に github_pr_number を書き戻す
  ↓
github-pr-reviewer【新規スキル / T-5】
  → tests/.onboarding/test-mapping.json を読み込みテスト網羅チェック（存在する場合）
  → PR の diff を取得し、コードレビューコメントを自動生成
  → gh pr review でレビューコメントを PR に投稿
  ↓
【人間 H2】レビュアー — レビューコメントを確認・Approve
  ↓
自動マージ（dev ブランチ）← T-7 / Phase 2
  ※ CI パス + Approve を条件に GitHub の自動マージ機能で dev にマージ
  ※ 自動マージの前提条件（Branch Protection Rules）は U-SEC-04 を参照
  ↓
【人間 H3】PDM が dev 確認 + OK 承認
  ↓
GitHub Actions CD — 本番デプロイ
```

---

## 2. スキル一覧表

| スキル | 種別 | カテゴリ | 対応タスク | 期限 | ブランチ名 |
|---|---|---|---|---|---|
| `github-issue-creator` | 新規 | `spec/` | T-1（設計）・T-2（実装） | 2026-06-12 | `feature/github-issue-creator` |
| `github-branch-creator` | 新規 | `spec/` | T-2.5（設計・実装） | T-2 完成後 | `feature/github-branch-creator` |
| `pochi-tdd-test-generator` | 既存（組み込み） | `test/` | Tdd（ブランチ作成後・コーディング直前） | T-3 着手前 | — |
| `pochi-coding-agent` | 拡張 | `spec/` | T-3（checkout・実装・コミットまで。push・PR は除外） | 2026-06-19 | `feature/coding-agent-github-integration` |
| `github-push-and-pr-creator` | 新規 | `spec/` | T-4（push + PR 作成） | T-3 完成後 | `feature/github-push-and-pr-creator` |
| `github-pr-reviewer` | 新規 | `spec/` | T-5（PR 自動コードレビュー） | T-4 完成後 | `feature/github-pr-reviewer` |

---

## 3. Issue 登録計画

各スキルに対して独立した Issue を作成する（スキルごとに独立したブランチ・PR）。

| # | Issue タイトル（案） | ブランチ名 | 期限 | 備考 |
|---|---|---|---|---|
| TBD | `[新規スキル] github-issue-creator: spec.json → GitHub Issue 登録` | `feature/github-issue-creator` | 2026-06-12 | 詳細: req-T1-github-issue-creator.md |
| TBD | `[新規スキル] github-branch-creator: issue 番号 → feature ブランチ作成` | `feature/github-branch-creator` | T-2 完成後 | 詳細: req-T2.5-github-branch-creator.md |
| TBD | `[既存スキル統合] pochi-tdd-test-generator: スキルチェーンへの組み込み（ブランチ上で TDD 先行テスト生成）` | — | T-3 着手前 | 詳細: req-Tdd-tdd-test-generator.md。spec.json に data_contracts / business_rules が必須 |
| TBD | `[拡張] pochi-coding-agent: 既存ブランチ checkout・実装・コミットの追加` | `feature/coding-agent-github-integration` | 2026-06-19 | 詳細: req-T3-coding-agent-extension.md |
| TBD | `[新規スキル] github-push-and-pr-creator: feature ブランチ push + dev への PR 作成` | `feature/github-push-and-pr-creator` | T-3 完成後 | 詳細: req-T4-github-push-and-pr-creator.md |
| TBD | `[新規スキル] github-pr-reviewer: PR diff の自動コードレビュー・コメント投稿` | `feature/github-pr-reviewer` | T-4 完成後 | 詳細: req-T5-github-pr-reviewer.md |

---

## 4. タスク依存関係

```
T-1（github-issue-creator 設計 〜06/05）
  ↓
T-2（github-issue-creator 実装 〜06/12）
  ↓
T-2.5（github-branch-creator 実装）
  ↓
Tdd（pochi-tdd-test-generator 実行）← ブランチ上で RED テストを先行生成。T-3 着手前に実施
  ↓
T-3（pochi-coding-agent 拡張 〜06/19）
  ↓
T-4（github-push-and-pr-creator 実装）
  ↓
T-5（github-pr-reviewer 実装）

※ T-9（GitHub 認証方式決定 〜06/30）は T-1 着手前に確認が望ましい
```

- T-2.5 の前提: `github_issue_number` が plan.json に存在すること（T-2 完成）
- Tdd の前提: `github_branch` が plan.json に存在すること（T-2.5 完成）、`spec.json` に `data_contracts` と `business_rules` フィールドが存在すること
- T-3 の前提: Tdd 完了・`tests/.onboarding/test-mapping.json` が存在すること（推奨）、`github_branch` が plan.json に存在すること
- T-4 の前提: `github_branch` が plan.json に存在すること（T-2.5 完成）、T-3 完了（コミット済み）
- T-5 の前提: `github_pr_number` が plan.json に存在すること（T-4 完成）

---

## 5. plan.json への追加フィールド（チェーン全体）

| フィールド | 追記タイミング | 追記スキル |
|---|---|---|
| `github_issue_number` | T-2 完成時 | `github-issue-creator` |
| `github_branch` | T-2.5 実行時 | `github-branch-creator` |
| `github_pr_number` | T-4 完成時 | `github-push-and-pr-creator`（新規） |

> **Tdd フェーズについて**: `pochi-tdd-test-generator` は plan.json への書き込みを行わない（読み込み専用）。
> 代わりに `tests/.onboarding/test-mapping.json` を出力し、`pochi-coding-agent`（実装の指針）と
> `github-pr-reviewer`（テスト網羅チェック）がそれぞれ参照する。
> test-mapping.json は plan.json とは独立したファイルであり、フィールドオーナーシップ管理の対象外。

---

## 6. 環境変数・認証方式（全スキル共通）

| 変数名 | 用途 | 設定必須 |
|---|---|---|
| `GITHUB_REPO` | 対象リポジトリ（例: `org/pochi-app`）。`gh` コマンドの `--repo` フラグに渡す | ✅ |

> **SEC-09**: スキル起動時に `gh repo view "$GITHUB_REPO"` でリポジトリの存在を確認する。未設定またはリポジトリが存在しない場合はエラー終了（フォールバックなし）。

> **認証方式**（SEC-02・SEC-03）
>
> このスキルチェーンは**個人開発マシン専用**。`gh auth login`（`~/.config/gh/hosts.yml` に永続化）を前提とする。
> `chmod 600 ~/.config/gh/hosts.yml` を必須とする。

---

## 7. セキュリティ要件（共通）

### SEC-04: コマンドインジェクション対策（共通バリデーションガイドライン）

各スキルの git/gh 操作は、**スキルごとに用意した Python スクリプト**が担う。
Claude Code は Bash ツール経由でそのスクリプトを呼び出すだけであり、git/gh コマンドを直接組み立てない。

**スクリプト化による保証**:

- `subprocess.run(cmd_list, ...)` のリスト形式で実行するため、シェル展開が発生しない
- スクリプトに存在しない操作（削除・force push 等）は物理的に実行不可能
- allowlist バリデーションをスクリプト内で一元管理し、F-03（`jq -r + @json` 誤用）・F-04（`/tmp` 固定パス）問題を構造的に排除する

**Claude Code の呼び出し方**:

```bash
# ✅ 推奨: スクリプトに引数を渡すだけ。コマンド組み立て・バリデーションはスクリプト内で完結
python skills/spec/github-issue-creator/scripts/github_issue_creator.py \
  --repo "$GITHUB_REPO" \
  --spec spec/features/FEAT-001/spec.json \
  --plan plan.json
```

**フィールド別 allowlist パターン**（各スクリプト内で検証）:

| フィールド | 入力元 | 許可パターン | 最大長 |
|---|---|---|---|
| `github_issue_number` | plan.json | `/^[0-9]+$/` | 10文字 |
| `github_branch` | plan.json | `/^feature\/issue-[0-9]+$/` | 100文字 |
| `spec.title` | spec.json | シェルメタ文字禁止（`$()`, バッククォート, `;&\|<>` 等） | 200文字 |
| `spec.id` | spec.json | `/^[A-Z][A-Z0-9\-]*$/` | 50文字 |
| `GITHUB_REPO` | 環境変数 | `/^[a-zA-Z0-9\-\.]+\/[a-zA-Z0-9\-\.]+$/` | 200文字 |

**スクリプト共通設計方針**（`fetch_streamlit_release_notes.py` を先例として踏襲）:

```python
# ✅ subprocess はリスト形式。shell=True は使用しない
result = subprocess.run(cmd_list, capture_output=True, text=True, timeout=30)

# ✅ stderr はサニタイズして出力（CWE-209対策）
sanitized_stderr = result.stderr.strip()[:500]

# ✅ /tmp 固定パスは使用しない。mktemp を使い trap でクリーンアップ
# ✅ plan.json のアトミック書き込みは同一ディレクトリの tmpfile + rename で行う

# ✅ パストラバーサル対策: --spec / --plan 引数はプロジェクトディレクトリ外を指せない
import pathlib

def validate_path(path_str: str, base_dir: pathlib.Path) -> pathlib.Path:
    """引数で受け取ったパスがプロジェクトディレクトリ外を指していないか検証する。"""
    resolved = (base_dir / path_str).resolve()
    if not str(resolved).startswith(str(base_dir.resolve()) + "/"):
        raise ValueError(f"パストラバーサル検出: {path_str!r}")
    if not resolved.exists():
        raise FileNotFoundError(f"ファイルが存在しません: {resolved}")
    return resolved

# 呼び出し例（各スクリプトの引数処理で必ず実施）
# base_dir = pathlib.Path(args.app_path).resolve()
# spec_path = validate_path(args.spec, base_dir)
# plan_path = validate_path(args.plan, base_dir)
```

### SEC-06: plan.json 完全性保護

`plan.json` はスキルチェーン間のデータ受け渡しの中核ファイルであり、書き込み権限の管理を厳格に行う。

**フィールドオーナーシップ（書き込み権限スキル）**:

| フィールド | 書き込みスキル | 読み取りスキル |
|---|---|---|
| `github_issue_number` | `github-issue-creator` のみ | `github-branch-creator`, `pochi-coding-agent`, `github-push-and-pr-creator` |
| `github_branch` | `github-branch-creator` のみ | `pochi-coding-agent`, `github-push-and-pr-creator` |
| `github_pr_number` | `github-push-and-pr-creator` のみ | `github-pr-reviewer` |

**アトミック書き込みの義務化**（競合・部分書き込み防止）:

```bash
# ✅ 必須: tmp ファイルを plan.json と同一ディレクトリに作成してアトミック書き込み
# （別ファイルシステムだと mv がアトミックにならないため同一ディレクトリ限定）
TMP=$(mktemp plan.json.XXXXXX)
jq --argjson v "$NEW_VALUE" '.github_issue_number = $v' plan.json > "$TMP"
mv "$TMP" plan.json
```

各スキルの実行前に、前提フィールドの型・範囲チェックを実施すること（未設定時はエラー終了）。

### SEC-08: GitHub 権限スコープマトリクス

各スキルが必要とする GitHub API 権限を定義する（最小権限原則）。

| スキル | 最小必要権限 | 不要な権限（除外） | 認証方式 |
|---|---|---|---|
| `github-issue-creator` | `issues: write` | `contents`, `admin` | gh auth login（hosts.yml） |
| `github-branch-creator` | なし（ローカル git のみ） | — | 不要 |
| `pochi-coding-agent` | なし（ローカル git のみ） | — | 不要 |
| `github-push-and-pr-creator` | `contents: write`, `pull-requests: write` | `admin` | gh auth login（hosts.yml） |
| `github-pr-reviewer` | `pull-requests: write` | `contents`, `admin` | gh auth login（hosts.yml） |

> **補足（SEC-08）**: `github-branch-creator` はローカルブランチ作成（`git checkout -b`）のみ、`pochi-coding-agent` はローカルコミットまでを担当するため GitHub 認証は不要。`git push` と PR 作成は `github-push-and-pr-creator` が、レビューコメント投稿は `github-pr-reviewer` が担う。

### SEC-10: 監査ログ方針

各スキルが GitHub 操作（Issue 作成・ブランチ作成・PR 作成・コメント投稿）を実行した際、以下の形式で標準出力にログを記録する。

> **ログ保持期間**: 最低 90 日。コンプライアンス要件がある場合はそれに準拠する。

```json
{
  "timestamp": "2026-06-20T10:30:00Z",
  "skill_name": "github-issue-creator",
  "operation": "gh issue create",
  "target_repo": "org/pochi-app",
  "target_resource": "Issue #42",
  "plan_json_path": "spec/plans/FEAT-001/plan.json",
  "result": "success",
  "resource_id": 42
}
```

加えて、GitHub 上の操作（Issue/PR/コメントの本文）には以下のフッターを記載する。`plan.json` のパスは実行時に動的に取得して埋め込むこと（ハードコーディング禁止）:

```
---
*このコンテンツは `github-issue-creator` スキルにより自動生成されました。  
plan.json: `{実行時に取得した plan.json の実パス}`*
```

### SEC-11: 破壊的 git 操作防止（3層防御）

このスキルチェーンが最も防ぎたい破壊的操作を以下に列挙する。

| 操作 | 影響 |
|------|------|
| `git push --force` / `-f` / `--force-with-lease` | リモート履歴の上書き |
| `git reset --hard` | コミット消失 |
| `git clean -fd` | 未追跡ファイル全削除 |
| `git branch -D` | ローカルブランチ強制削除 |
| `git push origin main` / `git push origin dev` | feature 以外のブランチへの誤 push |
| `git rebase` | 履歴書き換え |

これらを以下の多層防御で防ぐ。

#### Layer 1（最重要）: Pythonスクリプトのホワイトリスト設計

上記操作はスクリプトのコードに物理的に存在しない（SEC-04 による構造的保証）。
`github-push-and-pr-creator` スクリプトが呼び出す `git` コマンドは `git push origin <branch>` のみ。
`--force` / `-f` / `--force-with-lease` はスクリプトの引数として存在しないため Claude Code は実行不可能。

**スクリプト改修時の必須確認（コードレビューチェックリスト）**:

```bash
# --force 等の禁止コマンドがスクリプト内に混入していないか確認
grep -r "\-\-force\|\-\-reset\|clean -f\|rebase\|branch -D" \
  skills/spec/github-*/scripts/
```

このチェックを PR レビュー時に必ず実施し、出力が空であることを確認すること。

#### Layer 2（補助・必須）: git pre-push hook

アプリリポジトリに以下の pre-push hook を設置することで、スクリプト外から Claude Code が `git push` を直接実行した場合でも `--force` を検知してブロックする。

```bash
#!/bin/bash
# .git/hooks/pre-push
# feature/issue-* 以外のブランチへの push と --force を禁止する

remote="$1"
url="$2"

while IFS=' ' read -r local_ref local_sha remote_ref remote_sha; do
  branch="${remote_ref#refs/heads/}"

  # force push 検出（GIT_PUSH_OPTION_COUNT 経由）
  if [[ "${GIT_PUSH_OPTION_0:-}" == *force* ]]; then
    echo "❌ force push は禁止されています" >&2
    exit 1
  fi

  # feature/issue-* 以外への push を禁止
  if [[ ! "$branch" =~ ^feature/issue-[0-9]+$ ]]; then
    echo "❌ push 先ブランチが不正です: $branch（feature/issue-NNN のみ許可）" >&2
    exit 1
  fi
done

exit 0
```

インストール手順（アプリリポジトリのセットアップ時に一度だけ実施）:

```bash
cp .git/hooks/pre-push.sample .git/hooks/pre-push  # 既存 sample を上書き
# または上記スクリプトを直接 .git/hooks/pre-push として保存
chmod +x .git/hooks/pre-push
```

> **必須**: hook のインストールはリポジトリセットアップ時の必須手順とする。`--no-verify` による hook 迂回は運用上禁止とする。

#### Layer 3（最後の砦・必須）: GitHub Branch Protection Rules

`main` および `dev` ブランチへの直接 push と force push をサーバーサイドでブロックする。
詳細設定は U-SEC-04 を参照。**Phase 1 実装着手前に設定を完了すること**（後述）。

> **重要**: settings.json deny ルールを使用しないため、Branch Protection Rules がサーバーサイドの唯一の強制的防衛となる。T-1 着手前に必ず設定を完了すること。

---

## 8. 未解決事項（実装前に確認が必要なもの）

| ID | 項目 | Phase 1 での暫定方針 | 優先度 | 最終確定期限 |
|---|---|---|---|---|
| U-1 | コンフリクト発生時の対応フロー | blocked で停止・人間判定。push 失敗時は plan.json への github_pr_number 書き戻しを行わない（部分状態を避ける） | 中 | 〜06/19（T-3 実装前） |
| U-SEC-01 | spec.json frozen の技術的保証 | Phase 1 は「上書きしない運用ルール」のみ。Phase 2 で SHA-256 ハッシュ記録・後続スキル起動時照合を実装 | 低 | Phase 2 |
| U-SEC-02 | GITHUB_REPO ホワイトリスト機能 | Phase 1 はリポジトリ存在チェックのみ。Phase 2 で許可リスト機能を追加 | 低 | Phase 2 |
| U-SEC-04 | 自動マージの前提条件（Branch Protection Rules） | **Phase 1 実装着手前に設定を完了する**。main・dev への直接 push・force push をサーバーサイドでブロック。CI 全パス＋セキュリティスキャン Pass を必須とする方針（SEC-11 Layer 3 参照）。settings.json deny ルールを使用しないため、Branch Protection Rules がサーバーサイドの唯一の強制防衛となる | 重大 | **T-1 着手前**（Phase 1 必須） |
| U-SEC-05 | Git コミット署名（GPG/SSH signing） | Phase 1 は署名なし（暫定）。Phase 2 で検討 | 低 | Phase 2 |

---

## 9. 自動マージの条件定義（SEC-12）

自動マージを実行する場合、以下の前提条件を**すべて満たすこと**を必須とする。

| # | 条件 | 備考 |
|---|---|---|
| 1 | CI 全ジョブ Pass（Lint + Unit Test + Integration Test） | 1件でも失敗があれば自動マージ禁止 |
| 2 | セキュリティスキャン Pass（Critical / High 0 件） | 依存ライブラリスキャン含む |
| 3 | CODEOWNERS による自動レビュー or 人間レビュー承認（1名以上） | Phase 2 以降で GitHub App と連携 |
| 4 | Branch Protection Rules（下記設定を必須化） | リポジトリ管理者が設定 |

**必須 Branch Protection Rules 設定**:
- ✅ Require pull request reviews before merging（最低1名）
- ✅ Require status checks to pass before merging
- ✅ Require signed commits（Phase 2 以降）
- ✅ Do not allow bypassing the above settings

**自動マージの対象制限**:
- dev ブランチへのマージのみ対象
- **main / production ブランチへの自動マージは明示的に禁止**（手動承認必須）

---

## 10. デプロイ運用

### 現状の課題

| アプリ | デプロイ方式 | 問題 |
|---|---|---|
| Eats | 人間がdocker push | スクリプトがハードコード |
| d-pay-merchant | 人間がpython deploy.py | Makefileが手動 |
| その他 | 未定義 | TBD |

### 統一方針

**推奨**: `.github/workflows/deploy.yml` を全repoで標準化

```yaml
name: Deploy
on:
  push:
    branches:
      - dev    # Stagingデプロイ
      - main   # 本番デプロイ（手動承認必須）

# SEC-08: permissions ブロックでワークフロー単位に最小権限を明示
permissions:
  contents: read
  deployments: write

jobs:
  deploy-staging:
    if: github.ref == 'refs/heads/dev'
    runs-on: ubuntu-latest
    steps:
      # SEC-13: サードパーティ Actions は SHA でピン留め
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683  # v4.2.2
      - run: bash scripts/deploy-staging.sh
        env:
          STAGING_API_KEY: ${{ secrets.STAGING_API_KEY }}
      - run: pytest tests/smoke/ --staging
      - name: Notify Slack
        run: curl -X POST ${{ secrets.SLACK_WEBHOOK }}

  deploy-prod:
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production  # 手動承認ゲート
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683  # v4.2.2
      - run: bash scripts/deploy-prod.sh
      - run: pytest tests/health/ --prod
```

### GitHub Actions ワークフロー保護（SEC-13）

**CODEOWNERS 設定**（T-6 実装前に設定）:

```
# .github/CODEOWNERS
.github/workflows/ @security-team @infra-team
```

| ルール | 内容 |
|---|---|
| サードパーティ Actions のピン留め | `@v4` 等のタグ指定禁止。フル SHA でピン留め必須 |
| permissions ブロック最小化 | ワークフローファイルの先頭に `permissions` を明示。必要な権限のみ許可 |
| `pull_request_target` の禁止 | セキュリティリスクがあるため原則禁止。使用する場合はセキュリティチームの承認必須 |
| ワークフロー変更のレビュー | CODEOWNERS によりセキュリティ/インフラチームの承認を必須化 |

---

## 11. 認証方式の選択

| 方式 | メリット | デメリット | Pochi適用性 |
|---|---|---|---|
| **gh auth login（個人ghセッション）** | 追加設定不要・各ユーザーのトークンで実行 | hosts.yml 平文保存 | ✅（個人開発マシン向け・本スキルチェーンの採用方式） |
| **GitHub App** | スコープ最小化・アプリ単位管理 | セットアップ複雑 | ✅（本番推奨） |
| **GitHub Actions Token（OIDC）** | CI/CD内でセキュア・自動更新 | CI/CD内のみ | ✅（自動化向け推奨） |

**方針**: 各ユーザーが `gh auth login` 済みのghセッションをそのまま使用する（`~/.config/gh/hosts.yml` に永続化）。特別なトークン管理・PAT発行は不要。`chmod 600 ~/.config/gh/hosts.yml` を必須とする。

詳細な認証ポリシーは本ドキュメント §6 を参照。

---

## 12. 実装フェーズスケジュール

### Phase 1：GitHubブランチ・PR自動化（最優先・即効性高）

**目標**: coding-agentがコミット後にGitHubリモートへプッシュし、PRを自動作成

| ステップ | 内容 | 担当 | 完了期限 |
|---|---|---|---|
| **1-1** | github-issue-creatorスキル設計 | RS | 2026-06-05 |
| **1-2** | github-issue-creatorスキルの実装 | RS | 2026-06-12 |
| **1-3** | github-branch-creator・pochi-coding-agent拡張 | RS | 2026-06-19 |
| **1-4** | github-push-and-pr-creator・github-pr-reviewer実装 | RS | 2026-06-26 |

### Phase 2：テスト・マージ自動化（高優先）

**目標**: PR作成後、テスト実行 → 自動マージまでを自動化

| ステップ | 内容 | 担当 | 完了期限 |
|---|---|---|---|
| **2-1** | GitHub Actions CI/CDパイプラインの定義 | RS | 2026-07-03 |
| **2-2** | auto-mergeルール設定（コンフリクトなし + テスト全グリーン → 自動マージ） | 管理者 | 2026-07-10 |

### Phase 3：デプロイ自動化（中優先）

**目標**: dev・本番環境への自動デプロイ（確認後）

| ステップ | 内容 | 担当 | 完了期限 |
|---|---|---|---|
| **3-1** | デプロイスクリプト統一化・GitHub Actionsラッパー作成 | インフラ | 2026-07-17 |
| **3-2** | Smokeテスト自動実行（Playwright等） | RS | 2026-07-24 |
| **3-3** | PDM向けdev確認・本番承認UI実装（Slack button MVP） | TBD | 2026-08-07 |
| **3-4** | E2Eテスト統合（本番前ゲート） | RS | 2026-08-14 |

### Phase 4：運用監視・安定化（低優先・Phase 1〜3 完了後）

| ステップ | 内容 | 担当 | 完了期限 |
|---|---|---|---|
| **4-1** | エラーハンドリングマニュアル作成 | RS | 2026-08-21 |
| **4-2** | デプロイ失敗時の自動通知・ロールバック | インフラ | 2026-09-04 |

### マイルストーン

```
2026年
6月: Phase 1 完了（ブランチ・PR自動化）
7月: Phase 2 完了（テスト・マージ自動化）
8月: Phase 3 完了（デプロイ自動化・Slack承認）
9月: Phase 4 完了（運用監視・安定化）
```

---

## 13. パイプライン比較図（As-Is → To-Be）

```
【現状：60%自動化】
PDM
 ↓
spec-initializer ✅ → plan.json ✅ → coding-agent ✅ → コミット ✅
 ↓【ここから手動】
ブランチ切り 🔴 → push 🔴 → PR作成 🔴 → マージ 🔴 → デプロイ 🔴 → UI確認 🔴 → 本番 🔴


【目標：80%自動化】
PDM（仕様書作成のみ）
 ↓
spec-initializer ✅ → spec.json + plan.json 出力
 ↓
github-issue-creator ✅（新規）→ Issue登録 → plan.jsonにIssue番号を追記
 ↓
github-branch-creator ✅（新規）→ feature/issue-NNNブランチ作成
 ↓
pochi-tdd-test-generator ✅ → RED テスト先行生成
 ↓
coding-agent ✅（拡張）→ 既存ブランチ checkout・実装・コミット
 ↓
github-push-and-pr-creator ✅（新規）→ push + PR作成
 ↓
github-pr-reviewer ✅（新規）→ 自動コードレビュー
 ↓
【人間がレビュー確認 + Approve】🟡
 ↓
auto-merge ✅（コンフリクトなし）→ CD Staging ✅ → Smokeテスト ✅
 ↓
【PDMがdev確認 + OK承認】🟡
 ↓
CD Prod ✅ → ヘルスチェック ✅ → 完了
```

---

## 14. 各要件定義書へのリンク

| ファイル | 内容 |
|---|---|
| [req-Tdd-tdd-test-generator.md](./req-Tdd-tdd-test-generator.md) | pochi-tdd-test-generator（既存スキル）のスキルチェーン統合要件 |
| [req-T1-github-issue-creator.md](./req-T1-github-issue-creator.md) | github-issue-creator スキル（新規）の詳細要件 |
| [req-T2.5-github-branch-creator.md](./req-T2.5-github-branch-creator.md) | github-branch-creator スキル（新規）の詳細要件 |
| [req-T3-coding-agent-extension.md](./req-T3-coding-agent-extension.md) | pochi-coding-agent 拡張の詳細要件（checkout・実装・コミットまで） |
| [req-T4-github-push-and-pr-creator.md](./req-T4-github-push-and-pr-creator.md) | github-push-and-pr-creator スキル（新規）の詳細要件（push + PR 作成） |
| [req-T5-github-pr-reviewer.md](./req-T5-github-pr-reviewer.md) | github-pr-reviewer スキル（新規）の詳細要件（PR 自動コードレビュー） |
