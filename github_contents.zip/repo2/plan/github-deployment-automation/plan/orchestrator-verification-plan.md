# github-deployment-orchestrator 検証計画

## Context

`github-deployment-orchestrator` は、仕様策定からGitHub Issue作成・ブランチ作成・TDDテスト生成・実装・コミット・PR作成・AIレビューまでを1コマンドで全自動実行する統括スキルである。

本計画は、同スキルを実際のアプリリポジトリ（`pochi-d-pay-merchant-visualizer-repository`）に対して実行し、エンドツーエンドで正しく動作することを検証するための手順をまとめたものである。

**対象スキル**: `/home/user/pochi-dp-developer-docs/.claude/skills/github-deployment-orchestrator/SKILL.md`  
**対象アプリ**: `/home/user/pochi-d-pay-merchant-visualizer-repository`  
**出力先**: `/home/user/pochi-dp-developer-docs/plan/github-deployment-automation/plan/`

---

## 検証の前提条件

### 既知の情報

| 項目 | 状態 |
|---|---|
| GitHub CLI 認証 | `ryota-suzuki-xf` でログイン済み |
| `GITHUB_REPO` | `nttdocomo-com/pochi-d-pay-merchant-visualizer-repository`（settings.local.jsonに定義） |
| 既存 spec.json | `spec/features/FEAT-WORKTREE-DEMO-002/spec.json`（status: frozen） |
| 既存 plan.json | `spec/plans/FEAT-WORKTREE-DEMO-002.json`（github_issue_number 等は未記録） |
| 前回検証（FEAT-RANKING-001） | 2026-05-26 完了。バグ5件を検出・修正済み |

### 前提チェック（Phase 0 の確認項目）

1. `gh auth status` → ログイン状態の確認
2. `GITHUB_REPO` 環境変数の確認（セッション内で export が必要な場合あり）
3. `gh repo view "$GITHUB_REPO"` → リポジトリ存在確認
4. `git rev-parse --is-inside-work-tree` → git リポジトリ確認

---

## 検証シナリオ

今回は **既存の frozen spec.json（FEAT-WORKTREE-DEMO-002）** を使用して、Phase 1（仕様策定）をスキップしたパイプライン実行を検証する。

**機能概要**: d払い決済状況見える化ツール 大規模改修（グラフキャッシュ・地図UI改善・Excelエクスポート・競合分析・パフォーマンスダッシュボード）

### 使用する spec.json / plan.json

| ファイル | パス |
|---|---|
| spec.json | `spec/features/FEAT-WORKTREE-DEMO-002/spec.json` |
| plan.json | `spec/plans/FEAT-WORKTREE-DEMO-002.json` |

---

## フェーズ別検証項目

### Phase 0: 前提チェック

| ID | 検証項目 | 期待結果 |
|---|---|---|
| V-P0-01 | `gh auth status` が成功する | `ryota-suzuki-xf` でログイン済みと表示 |
| V-P0-02 | `GITHUB_REPO` が設定されている | `nttdocomo-com/pochi-d-pay-merchant-visualizer-repository` が返る |
| V-P0-03 | `gh repo view $GITHUB_REPO` が成功する | リポジトリ情報が表示される |
| V-P0-04 | git リポジトリ内で実行されている | `true` が返る |
| V-P0-05 | アプリパス確認プロンプトが表示される | `/home/user/pochi-d-pay-merchant-visualizer-repository` を入力 |

### Phase 1: 仕様策定（スキップ確認）

| ID | 検証項目 | 期待結果 |
|---|---|---|
| V-P1-01 | frozen spec.json を検出してスキップされる | `FEAT-WORKTREE-DEMO-002` の spec.json を検出しスキップ案内が表示される |
| V-P1-02 | Phase 2 に自動進行する | ユーザー操作なしで次フェーズへ |

### Phase 2: GitHub Issue 作成

| ID | 検証項目 | 期待結果 |
|---|---|---|
| V-P2-01 | plan.json に `github_issue_number` が存在しないため Issue 作成が実行される | `github-issue-creator` スクリプトが起動される |
| V-P2-02 | Issue が GitHub 上に作成される | Issue #NNN が作成される |
| V-P2-03 | plan.json の `github_issue_number` が更新される | `spec/plans/FEAT-WORKTREE-DEMO-002.json` に番号が書き込まれる |
| V-P2-04 | （冪等性）再実行時は Issue 作成がスキップされる | `github_issue_number` 存在でスキップメッセージが表示される |

### Phase 3: ブランチ作成

| ID | 検証項目 | 期待結果 |
|---|---|---|
| V-P3-01 | plan.json に `github_branch` が存在しないためブランチ作成が実行される | `github-branch-creator` スクリプトが起動される |
| V-P3-02 | feature ブランチが作成・チェックアウトされる | `feature/issue-NNN` ブランチが作成される |
| V-P3-03 | plan.json の `github_branch` が更新される | `spec/plans/FEAT-WORKTREE-DEMO-002.json` にブランチ名が書き込まれる |
| V-P3-04 | （冪等性）再実行時はブランチ作成がスキップされる | `github_branch` 存在でスキップメッセージが表示される |

### Phase 4: TDDテスト先行生成

| ID | 検証項目 | 期待結果 |
|---|---|---|
| V-P4-01 | `tests/.onboarding/test-mapping.json` が存在しないため `pochi-tdd-test-generator` が起動される | ヒアリングが開始される |
| V-P4-02 | ヒアリング後 test-mapping.json が生成される | `tests/.onboarding/test-mapping.json` が作成される |
| V-P4-03 | （冪等性）再実行時はテスト生成がスキップされる | test-mapping.json 存在でスキップされる |

### Phase 5: 実装（pochi-coding-agent-github）

| ID | 検証項目 | 期待結果 |
|---|---|---|
| V-P5-01 | `pochi-coding-agent-github` が起動される | 実装コード生成が開始される |
| V-P5-02 | 実装が完了し Phase 6 に自動進行する | 不明点なしで完了、task_result.json が生成される |
| V-P5-03 | 解決不能エラー時に停止メッセージが表示される | `⚠️ pochi-coding-agent-github が問題を解決できず停止しました。` と再開方法が表示される |

### Phase 6: コミット

| ID | 検証項目 | 期待結果 |
|---|---|---|
| V-P6-01 | `github-commit-creator` スクリプトが実行される | コミットが作成される |
| V-P6-02 | コミットメッセージに仕様タイトルと Issue 番号が含まれる | `feat: d払い決済状況見える化ツール 大規模改修 (Closes #NNN)` の形式 |
| V-P6-03 | 変更なしの場合はコミットをスキップして次フェーズへ進む | スキップメッセージが表示され Phase 7 に進む |

### Phase 7: Push & PR 作成

| ID | 検証項目 | 期待結果 |
|---|---|---|
| V-P7-01 | plan.json に `github_pr_number` が存在しないため PR 作成が実行される | `github-push-and-pr-creator` スクリプトが起動される |
| V-P7-02 | ブランチが push され PR が作成される | PR #NNN が作成される |
| V-P7-03 | PR の base ブランチが `dev` である | `base: dev` が確認される |
| V-P7-04 | plan.json の `github_pr_number` が更新される | `spec/plans/FEAT-WORKTREE-DEMO-002.json` に番号が書き込まれる |
| V-P7-05 | （冪等性）再実行時は PR 作成がスキップされる | `github_pr_number` 存在でスキップされる |

### Phase 8: AIコードレビュー

| ID | 検証項目 | 期待結果 |
|---|---|---|
| V-P8-01 | `fetch-diff` コマンドで PR diff が取得される | diff が正しく取得される（最大50ファイル）|
| V-P8-02 | 5観点（仕様適合・テスト網羅・セキュリティ・規約・パフォーマンス）でレビューが実施される | 各観点のコメントが生成される |
| V-P8-03 | `post-review` コマンドで GitHub PR にレビューコメントが投稿される | PR #NNN にコメントが投稿される |
| V-P8-04 | review_comment.tmp.md が削除される | 一時ファイルが残らない（前回 B-05 として修正済み） |
| V-P8-05 | `--comment` のみ使用（approve/request-changes は使用しない） | レビューコメントのみ投稿される |

### 完了確認

| ID | 検証項目 | 期待結果 |
|---|---|---|
| V-END-01 | 完了メッセージが表示される | `✅ github-deployment-orchestrator が全フェーズを完了しました。` と Issue/ブランチ/PR番号が表示される |

---

## エラーシナリオ検証

| ID | シナリオ | 期待動作 |
|---|---|---|
| V-ERR-01 | `GITHUB_REPO` 未設定で起動 | Phase 0 で停止、`export GITHUB_REPO=org/repo-name` を案内 |
| V-ERR-02 | 未 frozen の spec.json でのみ Issue 作成を試みる | `github-issue-creator` が spec.json バリデーションエラーを返す |
| V-ERR-03 | Phase 途中でキャンセル後に再実行 | 完了済みフェーズがスキップされ、未完了フェーズから再開される |

---

## 検証実施手順

```bash
# 1. アプリリポジトリに移動
cd /home/user/pochi-d-pay-merchant-visualizer-repository

# 2. GITHUB_REPO 環境変数を確認・設定（必要に応じて）
echo $GITHUB_REPO
# → 未設定の場合
export GITHUB_REPO=nttdocomo-com/pochi-d-pay-merchant-visualizer-repository

# 3. github-deployment-orchestrator を起動
# Claude Code のプロンプトで以下を入力：
# /github-deployment-orchestrator

# 4. Phase 0 でアプリパスを指定（プロンプトが表示された場合）
# /home/user/pochi-d-pay-merchant-visualizer-repository

# 5. Phase 1 は frozen spec.json により自動スキップされることを確認

# 6. Phase 4（TDDテスト生成）のヒアリングに応答
# - カバレッジ目標: 80%
# - モック方針: Snowflake・Streamlit UI は外部依存としてモック

# 7. Phase 5（実装）の対話に随時応答

# 8. 全フェーズ完了後、GitHub PR を確認
gh pr view --repo $GITHUB_REPO
```

---

## チェックリスト（実施後に記録）

```
[ ] V-P0-01: gh auth status 成功
[ ] V-P0-02: GITHUB_REPO 設定確認
[ ] V-P0-03: リポジトリ存在確認
[ ] V-P0-04: git リポジトリ確認
[ ] V-P1-01: Phase 1 スキップ確認
[ ] V-P2-01〜03: Issue 作成・plan.json 更新
[ ] V-P3-01〜03: ブランチ作成・plan.json 更新
[ ] V-P4-01〜02: TDDテスト生成
[ ] V-P5-01〜02: 実装完了
[ ] V-P6-01〜02: コミット作成・メッセージ形式確認
[ ] V-P7-01〜04: Push・PR 作成・plan.json 更新
[ ] V-P8-01〜05: AIレビュー実施・コメント投稿・一時ファイル削除
[ ] V-END-01: 完了メッセージ確認
```

---

## 前回検証（FEAT-RANKING-001）からの既知の修正点

以下は 2026-05-26 の前回検証で発見・修正済みのバグ。今回の検証では修正が機能しているかを確認する。

| バグID | 内容 | 修正済み |
|---|---|---|
| B-01 | f-string 構文の Python 3.10 非互換 | ✅ |
| B-02 | `gh pr create --json` フラグ未サポート | ✅ |
| B-03 | plan.json パス不一致（spec/features vs spec/plans） | 要確認 |
| B-04 | `github_pr_number` 書き戻し失敗（B-03 の影響） | 要確認 |
| B-05 | `review_comment.tmp.md` 削除権限拒否 | ✅ |

**B-03・B-04 は今回の検証で対応済みかを重点的に確認すること。**

---

## 参考リンク

- SKILL.md: `/home/user/pochi-dp-developer-docs/.claude/skills/github-deployment-orchestrator/SKILL.md`
- 前回検証計画: `/home/user/pochi-dp-developer-docs/plan/github-deployment-automation/plan/skill-verification-plan.md`
- spec.json: `/home/user/pochi-d-pay-merchant-visualizer-repository/spec/features/FEAT-WORKTREE-DEMO-002/spec.json`
- plan.json: `/home/user/pochi-d-pay-merchant-visualizer-repository/spec/plans/FEAT-WORKTREE-DEMO-002.json`

---

## 実行記録：FEAT-WORKTREE-DEMO-002（2026-05-27）

### 実行概要

| 項目 | 値 |
|---|---|
| 実行日 | 2026-05-27 |
| 対象フィーチャー | FEAT-WORKTREE-DEMO-002「d払い決済状況見える化ツール 大規模改修」 |
| GitHub Issue | #302 |
| 作成ブランチ | `feature/issue-302` |
| 作成PR | #303（base: dev） |
| 担当ユーザー | ryota-suzuki-xf |
| 実装ファイル数 | 63ファイル（+9,474行） |

### フェーズ別実行結果

| フェーズ | 結果 | 所要時間の目安 | 備考 |
|---|---|---|---|
| Phase 0: 前提チェック | ✅ 完了 | 即時 | GITHUB_REPO は `export` が必要（inline指定は効かない） |
| Phase 1: 仕様策定 | ✅ 完了（新規生成） | 長時間 | spec.jsonが未存在のため新規作成。スキーマ違反を複数回修正 |
| Phase 2: Issue作成 | ✅ 完了 | 即時 | Issue #302 を作成 |
| Phase 3: ブランチ作成 | ✅ 完了 | 即時 | `feature/issue-302` を origin/dev ベースで作成 |
| Phase 4: TDDテスト先行生成 | ✅ 完了 | 長時間 | contracts・unit・fixtures・test-mapping.json を一括生成 |
| Phase 5: 実装 | ✅ 完了 | 長時間（コンテキスト引継ぎ3回） | T-001〜T-006全タスク実装。コンテキスト上限により3回中断・再開 |
| Phase 6: コミット | ✅ 完了 | 即時 | 63ファイルをコミット |
| Phase 7: Push & PR作成 | ✅ 完了 | 即時 | PR #303 を作成 |
| Phase 8: AIコードレビュー | ✅ 完了 | 中程度 | ruffエラー9件を検出→即時修正→追加コミット（6d390e5）→レビューコメント投稿 |

### チェックリスト（実施後記録）

```
[x] V-P0-01: gh auth status 成功
[x] V-P0-02: GITHUB_REPO 設定確認（export で明示的に設定が必要）
[x] V-P0-03: リポジトリ存在確認
[x] V-P0-04: git リポジトリ確認
[x] V-P1-01: Phase 1 は spec.json 未存在のため新規生成（スキップではなく実行）
[x] V-P2-01〜03: Issue #302 作成・plan.json 更新
[x] V-P3-01〜03: ブランチ feature/issue-302 作成・plan.json 更新
[x] V-P4-01〜02: TDDテスト生成（contracts/unit/fixtures + test-mapping.json）
[x] V-P5-01〜02: 実装完了（T-001〜T-006）
[x] V-P6-01〜02: コミット作成（ebcce9c + 修正 6d390e5）
[x] V-P7-01〜04: Push・PR #303 作成・plan.json 更新
[x] V-P8-01〜05: AIレビュー実施・ruffエラー指摘・修正・コメント投稿
[x] V-END-01: 全フェーズ完了
```

### 前回バグ（B-03・B-04）の状況

| バグID | 内容 | 今回の状況 |
|---|---|---|
| B-03 | plan.json パス不一致 | ✅ 解消。`app/spec/plans/` のパスで一貫して扱えた |
| B-04 | `github_pr_number` 書き戻し失敗 | ✅ 解消。plan.json への書き戻しは正常に機能 |

---

## 今回の実行で新たに発見した問題・課題感

### 対応ステータス（2026-05-27 更新）

- [x] 問題1: spec.json スキーマ違反の繰り返し発生
- [x] 問題2: コンテキスト上限によるPhase 5の3回中断
- [x] 問題3: GITHUB_REPO のinline指定が効かない
- [x] 問題4: github_issue_creator.py のパストラバーサル制限が厳しすぎる
- [x] 問題5: ruffエラーがPhase 8まで持ち越された
- [x] 問題6: app/spec/ サブディレクトリ配置の非直感性

### ✅ 問題1: spec.json スキーマ違反が繰り返し発生した（対応済み）

**状況**: Phase 1（pochi-spec-initializer）でspec.jsonを生成する際、`additionalProperties: false` のスキーマに対してフィールド名のケース違いや不正フィールドが複数回発生し、validate_spec.py を通るまでに反復修正が必要だった。

具体的に発生したエラー：
- `non_goals` → `nonGoals`、`use_cases` → `useCases`、`ui_ux` → `uiUx` など snake_case と camelCase の混在
- `github_base_branch` という不正フィールドを plan.json に混入
- `references` フィールドが配列形式になっていた（オブジェクト形式が正しい）
- `verification_type: "manual"` が無効値（`unit/integration/e2e/load` のみ許可）
- AC-007・AC-008・NF-04 がどのタスクにも参照されておらずカバレッジ不足

**課題**: スキーマ定義がAgentのコンテキスト外に存在するため、生成時に参照できずに後から違反が発覚する。生成プロンプトにスキーマ要件のサマリーを埋め込む、あるいはspec/plan生成直後に即座にvalidateを走らせてフィードバックループを短縮する仕組みが必要。

**改善案**: `pochi-spec-initializer` の SKILL.md に camelCase/オブジェクト形式等の必須フィールド一覧を「フォーマット注意事項」として明示する。

**対応実施内容（2026-05-27）**:
- `pochi-spec-initializer/SKILL.md` にフォーマット注意事項を追加
	- camelCase基本（例外: `non_functional`）
	- `references` はオブジェクト必須
	- `verification_type` は `unit/integration/e2e/load` のみ
- `pochi-spec-initializer/prompts/initializer.md` の snake_case誘導を削除し、即時バリデーション手順を追加

---

### 問題2: コンテキスト上限によりPhase 5（実装）が3回中断した

**状況**: T-001〜T-006の6タスクは実装量が多く、1セッションのコンテキスト内に収まらなかった。ユーザーが「再開」と入力するたびにコンテキストサマリーから再開する形になり、計3回の中断・再開が発生した。

**課題**: 実装タスクが多い場合、コンテキスト切れはほぼ確実に発生する。現在のスキル設計では「再開」の手順が明示されていない。

**改善案**:
- coding-agent に入る前に、タスクの実装順序と中断時の再開ポイント（どのタスクまで完了したかのstate）を `task_results/` ディレクトリに保存するよう明示する
- SKILL.md に「コンテキスト上限時の再開方法」のセクションを追加し、ユーザーが「再開」と入力した場合の挙動を記述する

**対応方針（2026-05-27 更新）**: カスタムサブエージェントによるコンテキスト分離

現状の問題構造:
- orchestrator（SKILL.md）と pochi-coding-agent-github（SKILL.md）が同一コンテキストを共有
- orchestrator が coding-agent を「手順に従って起動」する形のため、全タスクが1セッションに集中する
- タスク数が多いと必然的にコンテキスト上限に達する

対応方針:
- orchestrator が `Agent` ツールを使い、**タスク単位でカスタムサブエージェントを起動**する形に変更する
- 各サブエージェントは独立したコンテキストで1タスクだけ実装し、plan.json の status を更新して終了する
- orchestrator は次の pending タスクで再度サブエージェントを起動するループを回す
- コンテキスト上限・セッション再起動時も orchestrator が plan.json を参照して pending タスクから再開できる

実行前提の整合性（必須）:
- orchestrator の `allowed-tools` に `Agent` を追加する（未追加だとサブエージェント起動が実行不能）
- サブエージェント呼び出しは1タスク1回を原則とし、同一タスクの並列実行は禁止する（競合防止）

状態保存仕様（再開性の担保）:
- 保存先: `{app_path}/spec/features/[FEATURE-ID]/task_results/progress.json`
- 更新タイミング: タスク開始時、タスク完了時、中断直前、テスト実行後
- 最低保持フィールド:
	- `feature_id`
	- `current_task_id`
	- `completed_task_ids`
	- `in_progress_task_id`
	- `last_modified_files`
	- `last_test_result`
	- `next_action`
	- `updated_at`
- 再開時は `plan.json` の status と `progress.json` を照合し、`in_progress` があれば最優先で再開、なければ次の `pending` を実行する

サブエージェント I/O 契約（固定）:
- 入力（orchestrator → subagent）:
	- `feature_id`
	- `task_id`
	- `artifacts`
	- `references`（requirements / acceptance_criteria / non_functional）
- 出力（subagent → orchestrator）:
	- `final_status`（`completed` / `blocked`）
	- `changed_files`
	- `test_result`
	- `next_action`
	- `error_summary`（失敗時のみ）
- orchestrator はこの出力を `task_results/[TASK-ID].json` と `progress.json` に反映してから次タスクへ進む

**対応作業**:

| ファイル | 操作 | 内容 |
|---|---|---|
| `.claude/agents/pochi-coding-agent-github-task.md` | 新規作成 | 1タスク専用サブエージェント（pochi-coding-agent-github の1タスク分ロジックを切り出し） |
| `.claude/skills/github-deployment-orchestrator/SKILL.md` | 修正 | Phase 5 を「Agent tool でサブエージェントを1タスクずつ起動するループ」に変更し、`allowed-tools` に `Agent` を追加 |
| `{app_path}/spec/features/[FEATURE-ID]/task_results/progress.json` | 新規作成（運用生成） | 中断復帰用の進捗スナップショット（state保存） |

実装方針:
- `pochi-coding-agent-github-task` は `AskUserQuestion` 禁止（仕様凍結済み前提）
- orchestrator が `in_progress` タスクを検出した場合（前回の中断）はそのタスクから再開する
- 既存の `pochi-coding-agent-github` SKILL.md は単独起動用として残す

---

### ✅ 問題3: GITHUB_REPO の渡し方に制約がある（対応済み）

**状況**: `GITHUB_REPO=org/repo python script.py` のようなinline環境変数指定がスクリプトに伝わらず、`export GITHUB_REPO=...` を事前に実行する必要があった。

**課題**: SKILL.md の「Phase 0」では `GITHUB_REPO` の設定方法が曖昧で、ユーザーが混乱しやすい。

**改善案**: SKILL.md の Phase 0 に `export GITHUB_REPO=...` が必要な旨を明記し、設定確認コマンド `echo $GITHUB_REPO` の出力に応じて自動 export するロジックをスクリプト側に組み込む。

**対応実施内容（2026-05-27）**:
- `github-deployment-orchestrator/SKILL.md` の Phase 0 に inline指定の注意点と `export` 手順を追記
- `github-issue-creator/SKILL.md` にも同様の注意事項を追記

---

### ✅ 問題4: github_issue_creator.py のパストラバーサル制限が厳しすぎる（対応済み）

**状況**: spec.jsonとplan.jsonを orchestrator の `/spec/` ディレクトリにコピーしてから `github_issue_creator.py` に渡そうとしたところ、アプリディレクトリ外のパスとして拒否された。アプリ配下の `app/spec/` パスを直接渡す必要があった。

**課題**: スキルの設計上はorchestrator内のspec/ディレクトリを共有ストレージとして使う想定だが、各サブスクリプトが独自のパストラバーサルチェックを持つため、orchestratorの想定パスが通らない。

**改善案**: 各サブスクリプトのパス検証ロジックを統一するか、orchestrator の spec/ ディレクトリを `--app-path` に関係なく許容するオプションを追加する。

**対応実施内容（2026-05-27）**:
- `github_issue_creator.py` に `--allow-external-root` オプションを追加
- `--app-path` 外でも、明示許可したルート配下のみ `--spec` / `--plan` を受け入れるよう変更
- `github-deployment-orchestrator/SKILL.md` と `github-issue-creator/SKILL.md` の実行例を更新

---

### ✅ 問題5: AIコードレビューがruffエラーを検出したが、修正は手動対応になった（対応済み）

**状況**: Phase 8（AIコードレビュー）でruffエラー11件（未使用インポート2件・末尾空白・ソート順など）が指摘された。これらはPhase 5の実装時に混入したもので、Phase 8で初めて検出された。修正はその場で手動で行い、追加コミット＆プッシュをした。

**課題**: Phase 5（coding-agent）の実装完了後にruff checkが自動実行されておらず、品質チェックが Phase 8 まで遅延した。

**改善案**:
- `pochi-coding-agent-github` の完了条件に「`ruff check` が全ファイルでパスすること」を追加し、実装ループ内でruffを自動実行させる
- Phase 6（コミット前）にもruffチェックをhookとして組み込む

**対応実施内容（2026-05-27）**:
- `github-deployment-orchestrator/SKILL.md` に以下を追加
	- Phase 5 完了条件として `ruff check .` を必須化（失敗時は停止）
	- Phase 6 コミット前に `ruff check .` を再実行するゲートを追加
- `pochi-coding-agent-github/SKILL.md` に以下を追加
	- Phase 5 共通手順として `ruff check .` → `ruff check . --fix`（1回）→ `ruff check .` の品質ゲートを必須化
	- 解消不能時は blocked で停止し、task_result.json に記録する運用を明示

---

### ✅ 問題6: spec.json / plan.json の app/ サブディレクトリへの配置が非直感的（対応済み）

**状況**: スキル仕様上、生成物は `{app_path}/spec/` 配下に置かれるため、リポジトリルートから見ると `app/spec/features/FEAT-WORKTREE-DEMO-002/spec.json` になる。一方、orchestrator の設計ではルートの `spec/` を想定しているような記述があり、混乱が生じた。

**改善案**: SKILL.md の「アプリパス」の説明において、`{app_path}` が `<repo_root>/app` を指す場合の具体的なパス例を明示する。

**対応実施内容（2026-05-27）**:
- `github-deployment-orchestrator/SKILL.md` に「アプリパス解決の具体例」を追加
- `{app_path}=<repo_root>` と `{app_path}=<repo_root>/app` の両ケースを明記し、`spec/` 基準が `{app_path}` 配下であることを明文化

---

## 総合評価

| 観点 | 評価 | コメント |
|---|---|---|
| エンドツーエンドの動作 | ✅ 動作する | 全8フェーズが完走し、PR・レビューコメントが正常に投稿された |
| 冪等性 | ✅ 概ね機能 | Issue/Branch/PRの重複作成は防止できた |
| スキーマ準拠 | ⚠️ 要改善 | spec.json/plan.json の生成時にスキーマ違反が多発。バリデーションフィードバックループの短縮が急務 |
| コンテキスト耐性 | ⚠️ 要改善 | 大規模フィーチャーでは確実にコンテキスト上限に達する。再開プロトコルの整備が必要 |
| コード品質の保証 | ⚠️ 要改善 | ruffエラーが Phase 8 まで持ち越された。実装フェーズ内での自動チェックが必要 |
| ユーザー操作量 | ⚠️ 多い | スキーマ修正・再開3回・ruff修正など、完全自動化には至っていない |
