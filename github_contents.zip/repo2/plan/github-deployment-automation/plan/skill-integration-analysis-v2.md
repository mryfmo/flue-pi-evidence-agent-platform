# GitHub デプロイ自動化スキル群 統合方式分析（第2版）

作成日: 2026-05-26  
対象スキル群: github-deployment-automation パイプライン（S-1〜S-5 + pochi-coding-agent-github）

---

## 1. 対象スキルの特性分類

| # | スキル | 実装形態 | GitHub API | LLM 使用 | 実行時間目安 | 特記事項 |
|---|---|---|---|---|---|---|
| S-1 | `github-issue-creator` | Prompt + Python script | ✅ | ❌ | 〜10s | アトミック書き込み・SEC-04〜10 |
| S-2 | `github-branch-creator` | Prompt + Python script | ❌（git のみ） | ❌ | 〜5s | ブランチ名を `feature/issue-NNN` に限定（SEC-05） |
| S-3 | `pochi-coding-agent-github` | Prompt（フルエージェント型） | ❌ | ✅（重い）| 5〜30 分 | 「過去履歴参照禁止」宣言あり・Task ツール禁止 |
| S-2.5 | `github-commit-creator` | Prompt + Python script | ❌（git のみ） | ❌ | 〜5s | spec.json title 優先・plan.json fallback |
| S-4 | `github-push-and-pr-creator` | Prompt + Python script | ✅ | ❌ | 〜30s | 冪等性あり（PR 既存時はスキップ） |
| S-5 | `github-pr-reviewer` | Prompt（半エージェント型）+ Python script | ✅ | ✅ | 〜5 分 | fetch-diff / post-review の 2 サブコマンド構成 |

---

## 2. データ依存関係（パイプラインの構造）

各ステップは前ステップが `plan.json` に書き込んだフィールドを読み取る。**全ステップが直列依存であり、並列化の余地はゼロ。**

```
pochi-spec-initializer（前提）
  ↓
S-1 github-issue-creator
  → plan.json に github_issue_number, github_repo を書き込む
    ↓
S-2 github-branch-creator
  → plan.json の github_issue_number を読み取り
  → plan.json に github_branch を書き込む
      ↓
S-3 pochi-coding-agent-github
  → plan.json の github_branch を読み取り（ブランチ一致確認）
  → plan.json の tasks[].status を更新
        ↓
S-2.5 github-commit-creator
  → plan.json の github_branch, github_issue_number を読み取り
          ↓
S-4 github-push-and-pr-creator
  → plan.json の github_branch, github_issue_number, github_repo を読み取り
  → plan.json に github_pr_number を書き込む
            ↓
S-5 github-pr-reviewer
  → plan.json の github_pr_number, github_branch, github_repo を読み取り
```

---

## 3. 既存リポジトリの統合パターン調査

本リポジトリ（`pochi-dp-developer-docs`）に存在する統合方式の実装例を調査した。

| パターン | 代表スキル | 構造 | 子タスク実行方式 |
|---|---|---|---|
| シーケンシャル統合（Prompt 型） | `pochilib-update-analyst` | 親 SKILL.md が子スキル 3 つを順番に呼び出す | SKILL.md 内の指示でスキルを起動 |
| 統合診断（並列サブエージェント） | `pochi-skill-tier-checker` | 1 スキルが 3 カスタムサブエージェントを並列実行 | `.claude/agents/` の定義ファイルを参照 |
| 推薦ナビゲーション | `pochi-skill-navigator` | スキルを実行せず、適切なスキルを推薦するだけ | なし |

**重要な観察**: `pochi-skill-tier-checker` がサブエージェントを採用しているのは、3 つの診断タスクが**互いに独立していて並列実行できる**から。本パイプラインは全ステップが直列依存のため、このパターンを採用しても性能上の恩恵はない。

---

## 4. 統合方式の比較分析

### 方式 A: オーケストレーター Skill（1 発実行）

新しい SKILL.md 1 枚を追加し、S-1〜S-5 を順番に呼び出す。既存スキルは変更しない。

```
github-deploy-pipeline（新規 SKILL.md）
  → S-1 github-issue-creator を起動
  → S-2 github-branch-creator を起動
  → S-3 pochi-coding-agent-github を起動  ←★長時間・中断ポイント要
  → S-2.5 github-commit-creator を起動
  → S-4 github-push-and-pr-creator を起動
  → S-5 github-pr-reviewer を起動
```

### 方式 B: 全統合（1 つの Skill に合体）

6 スキル全ロジックを 1 枚の SKILL.md に統合。

### 方式 C: 1 Skill + カスタムサブエージェント複数

新規スキル 1 つがトリガーとなり、`.claude/agents/` に定義した複数のエージェントに処理を委譲。

### 方式 D: カスタムサブエージェントのみ（スキルなし）

全処理をカスタムエージェントに委譲し、ユーザーは直接起動しない。

---

## 5. 評価軸別比較表

| 評価軸 | A: オーケストレーター Skill | B: 1 Skill に統合 | C: 1 Skill + サブエージェント複数 | D: サブエージェントのみ |
|---|:---:|:---:|:---:|:---:|
| **ユーザー操作の簡潔さ** | ◎ | ◎ | ◎ | △（直接起動不可） |
| **実装コスト** | ◎（SKILL.md 1 ファイル追加） | △（全ロジック移植） | △（エージェント定義 6 本新規作成） | ✕（最高） |
| **個別スキルの単独再実行** | ◎（既存スキルをそのまま残す） | ✕（全体流し直しのみ） | ◎ | ◎ |
| **既存スキルへの変更** | ◎（一切不要） | ✕（全スキルのロジックを重複維持） | △（エージェント定義に書き直し） | ✕（全書き直し） |
| **sequential パイプラインへの適合** | ◎ | ○ | △（オーバースペック・並列化の恩恵なし） | △（同上） |
| **既存リポジトリパターンとの一致** | ◎（`pochilib-update-analyst` と同構造） | ✕（採用例なし） | △（部分一致） | ✕ |
| **SKILL.md の肥大化リスク** | ◎ | ✕（400 行超が必至） | ◎ | ◎ |
| **S-3 長時間実行への対応** | ○（SKILL.md に中断ポイント案内を明記） | ✕（全体が止まる・UX 最悪） | ○（エージェント分離） | ○ |
| **途中失敗時の再開** | ○（個別スキルで該当ステップから再実行案内） | ✕（障害箇所の特定も困難） | ○ | ○ |
| **総合** | **◎ 推奨** | **✕** | **△** | **✕** |

---

## 6. 却下理由詳細

### 方式 B（全統合）を却下する理由

- 6 スキル分のロジックを 1 枚に統合すると SKILL.md が 400 行超になり、プロンプト品質が著しく低下する
- 変更影響範囲が全体に及び、保守コストが最大
- 「PR 作成だけしたい」「Issue だけ作りたい」という部分実行のユースケースが完全に消滅する
- 既存リポジトリに採用例がなく、一貫性を損なう

### 方式 C・D（カスタムサブエージェント）を採用しない理由

- サブエージェント並列実行が有効なのは**独立タスクを並列化できる場合**（`pochi-skill-tier-checker` の診断 3 並列がその例）
- 本パイプラインは全ステップが直列依存のため、サブエージェントを使っても **性能上の恩恵がゼロ**
- 複数のエージェント定義ファイル（6 本）の新規作成・管理コストが実装コスト・保守コストともに最大
- sequential 処理へのサブエージェント適用は「設計の複雑化」のみをもたらすオーバースペック

---

## 7. 推奨: 方式 A（オーケストレーター Skill）

### 採用理由（3点）

**① sequential 依存のパイプラインにサブエージェント化は不要**  
全ステップが前ステップの `plan.json` フィールド（Issue 番号 → ブランチ名 → コミット → PR 番号）に依存しており、並列化の余地がない。並列実行を前提とするサブエージェントパターンを適用しても恩恵はゼロで、複雑さのみが増す。

**② 既存の成功パターン（`pochilib-update-analyst`）と同構造**  
「子スキルを順番に呼び出す Prompt 型 SKILL.md」は `pochilib-update-analyst`（3 子スキルを sequential 実行）で実証済み。追加コスト最小・リポジトリの一貫性を維持できる。

**③ 個別スキルの単独再実行が保たれる**  
実運用で最も多い使い方は「Step 7（PR レビュー）だけ再実行」「Step 4（実装）だけ再実行」など。統合しても個別スキルが残るため、この柔軟性が損なわれない。

### S-3 長時間実行問題の対策

SKILL.md の Step 4 に以下を明記する：

> **★ 実装の完了確認**: `pochi-coding-agent-github` は実装完了まで数分〜30 分かかります。  
> 実装が完了したら、続けて `github-commit-creator` を起動してください。

---

## 8. 実装スコープ（方式 A を採用した場合）

### 新規作成ファイル

| ファイル | 内容 |
|---|---|
| `skills/spec/github-deploy-pipeline/skills/run/SKILL.md` | オーケストレーター本体（Step 0〜7、Error Handling） |
| `skills/spec/github-deploy-pipeline/plugin.json` | スキルメタデータ |

### 更新ファイル

| ファイル | 更新内容 |
|---|---|
| `.claude-plugin/marketplace.json` | `github-deploy-pipeline` エントリ追加 |
| `.claude/skills.json` | `github-deploy-pipeline` エントリ追加 |
| `README.md` | Skill 一覧・install コマンド 2 箇所に追記 |
| `release-note.md` | `### Added` に追記 |
| `skills/tools/pochi-skill-navigator/skills/run/SKILL.md` | spec カテゴリ・キーワード・ワークフロー更新 |

### SKILL.md フロントマター（案）

```yaml
---
name: github-deploy-pipeline
description: >-
  spec.json（frozen）から GitHub Issue 作成・ブランチ作成・実装・コミット・push・PR 作成・PR レビューまでの
  GitHub デプロイパイプラインを一括実行します。
  「デプロイパイプラインを実行して」「GitHub パイプラインを起動」「github-deploy-pipeline を起動」
  などと言われたときに使用する。
allowed-tools: Read, Write, Bash, Edit, Glob, Grep
---
```

### ユーザー操作フローの変化

| 現行（7 コマンド） | 方式 A 導入後（1 コマンド） |
|---|---|
| `github-issue-creator を起動して` | `デプロイパイプラインを実行して` |
| `github-branch-creator を起動して` | （内部で自動実行） |
| `Coding Agent を起動して` | （内部で自動実行） |
| `コミットして` | （内部で自動実行） |
| `github-push-and-pr-creator を起動して` | （内部で自動実行） |
| `PR をレビューして` | （内部で自動実行） |

---

## 9. 参考: 既存オーケストレーション実装との構造比較

| 項目 | `pochilib-update-analyst` | `github-deploy-pipeline`（案） |
|---|---|---|
| 子タスク数 | 3（usage-scanner / changelog-analyzer / impact-detector） | 6（S-1〜S-5 + S-2.5） |
| 実行方式 | 順次（直列） | 順次（直列） |
| 中間データ | `reports/*.md`、`tmp/*.json` | `plan.json`（各スキルがフィールドを追記） |
| 子スキルの独立再実行 | ✅ 可能 | ✅ 可能 |
| サブエージェント | なし | なし |
| SKILL.md 構成 | STEP 0〜6 の番号付きフロー | STEP 0〜7 の番号付きフロー |
