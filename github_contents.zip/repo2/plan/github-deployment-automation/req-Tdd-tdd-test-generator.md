# 要件定義書: pochi-tdd-test-generator（既存スキル / スキルチェーン統合）

対応タスク: Tdd（TDD テスト先行生成。pochi-spec-initializer 完了後・github-issue-creator 着手前）  
作成日: 2026-05-25  
担当: RS

---

## 1. スキルメタデータ

| 項目 | 値 |
|---|---|
| スキルID | `pochi-tdd-test-generator` |
| 表示名 | Pochi TDD Test Generator |
| カテゴリ | `test/` |
| 種別 | **既存スキル**（スキルチェーンへの統合）|
| バージョン | 1.4.0（変更なし） |
| 正式ファイルパス | `skills/test/pochi-tdd-test-generator/skills/run/SKILL.md` |
| ブランチ名 | —（スキル自体の変更なし。統合要件の定義のみ） |
| Issue | TBD |
| 依存タスク | T-2.5（github-branch-creator 実装）完成・`github_branch` が plan.json に存在すること、spec.json に `data_contracts` と `business_rules` が存在すること |

---

## 2. スキルチェーン内での位置づけ

```
pochi-spec-initializer
  → spec.json（frozen）/ plan.json / spec.md を生成
  ↓
github-issue-creator（T-1・T-2）
  ↓
github-branch-creator（T-2.5）
  → feature/issue-NNN ブランチをローカルに作成
  ↓
★ pochi-tdd-test-generator  ← このスキル（Tdd フェーズ）
  → ブランチ上で RED テストを先行生成（コーディング直前）
  ↓
pochi-coding-agent（T-3）← test-mapping.json を参照して実装。テスト GREEN を確認
  ↓
github-push-and-pr-creator（T-4）← push・PR 作成
  ↓
github-pr-reviewer（T-5）← PR へのコードレビューコメント自動生成
```

**このスキルは「テストファーストを実現する起点」**。feature ブランチが切れた後・コーディングの直前に Layer1・2 の RED テストをブランチ上に生成し、後続の pochi-coding-agent が同じブランチ上で RED テストを GREEN にする形で実装を進める TDD サイクルを実現する。

---

## 3. 入力仕様

| 入力 | 形式 | 必須 | 説明 |
|---|---|:---:|---|
| `app_path` | 引数またはカレントディレクトリ | ✅ | プロジェクトルートパス（tests/ ディレクトリの作成先） |
| `spec.json` | JSON ファイル | ✅ | pochi-spec-initializer が生成したもの。`data_contracts` と `business_rules` フィールドが必須 |
| `plan.json` | JSON ファイル | ✅ | `artifacts`（フレームワーク検出用）、`tasks[].id`（test-mapping.json のタスクID紐付け用） |

### spec.json の必須フィールド（スキル実行前に確認）

| フィールド | 用途 | 欠落時の動作 |
|---|---|---|
| `data_contracts` | Layer1 テスト（データ契約テスト）の生成 | スキル停止 |
| `business_rules` | Layer2 テスト（ビジネスルール検証）の生成 | スキル停止 |

> **重要**: `pochi-spec-initializer` が spec.json を生成する際、`data_contracts` と `business_rules` を含むことが本フローの前提。欠落している場合はスキルチェーンを進める前に spec.json を修正すること。

---

## 4. 出力仕様

| 出力先 | 内容 | 後続スキルでの用途 |
|---|---|---|
| `tests/contracts/` | Layer1 データ契約テスト（`test_*_schema.py`）、データ契約定義 JSON 群 | `pochi-coding-agent` が GREEN を確認して push |
| `tests/unit/` | Layer2 単体テスト（`test_*.py`、RED 状態） | `pochi-coding-agent` が GREEN を確認して push |
| `tests/fixtures/` | valid / invalid / edge のテストデータセット + manifest.json | テスト実行時に参照 |
| `tests/conftest.py` | モック戦略・sys.path 設定（plan.json の artifacts ベース） | pytest 共通設定 |
| `tests/.onboarding/test-mapping.json` | テストファイル×実装関数の対応表（implementation_hint 付き） | **pochi-coding-agent が実装・GREEN 確認時に参照** |
| `tests/.onboarding/unit-test-design.md` | Layer2 設計書（AAAパターン） | 設計確認用 |

### test-mapping.json の形式

```json
{
  "generated_at": "<ISO8601>",
  "spec_json": "<spec_json_path>",
  "plan_json": "<plan_json_path>",
  "tests": [
    {
      "test_file": "tests/contracts/test_{boundary}_schema.py",
      "test_name": "test_{boundary}_valid_schema",
      "task_id": "T-XX-002",
      "implementation_hint": "実装すべきファイルパス・関数名・仕様参照先を具体的に記載",
      "spec_reference": "data_contracts[N] (entity: {entity名})"
    }
  ]
}
```

`implementation_hint` は pochi-coding-agent が実装する関数・ファイルを特定するための指針。具体的なパス・関数名・引数・返り値を含む。

---

## 5. pochi-coding-agent との連携方式

pochi-tdd-test-generator は plan.json への書き込みを行わない（読み込み専用）。  
連携はファイルシステム経由: `tests/.onboarding/test-mapping.json` を通じて行う。

| 操作 | pochi-tdd-test-generator | pochi-coding-agent |
|---|---|---|
| plan.json | 読み込みのみ（artifacts, tasks） | 読み書き（github_branch, github_pr_number） |
| test-mapping.json | **書き込み**（生成・出力） | 読み込みのみ（implementation_hint 参照） |
| tests/contracts/, tests/unit/ | **書き込み**（RED テスト生成） | 変更しない |

**pochi-coding-agent での参照手順（推奨）**:
1. `tests/.onboarding/test-mapping.json` が存在するか確認
2. 存在する場合: `tests[].implementation_hint` を読んで実装対象関数・ファイルを特定
3. 各 RED テストが GREEN になるよう実装を進める
4. test-mapping.json が存在しない場合: 警告を出して従来通り plan.json から実装

---

## 6. 処理フロー概要（スキル内部）

```
STEP 1: ユーザーからの情報収集
         （app_path / spec_json_path / plan_json_path を確認。自動検出あり）
STEP 2: tests/contracts/ 生成（spec.json → 6ファイル）
STEP 3: tests/fixtures/ 生成（valid / invalid / edge）
STEP 4: tests/conftest.py 生成
STEP 5: Layer1 テスト生成（test_{boundary}_schema.py）
STEP 6: Layer2 設計書生成（unit-test-design.md）
STEP 7: Layer2 テスト生成（tests/unit/test_*.py）
STEP 7.5: RED テスト品質チェック（形式的アサーション禁止パターンの検出）
STEP 8: pytest --collect-only で収集可能性確認（ImportError は許容、RED 期待）
STEP 9: test-mapping.json 生成（coding-agent 向け実装指針）
STEP 9.5: contracts/ バリデーション
STEP 10: 完了レポート出力
```

> **注意**: このスキルは pytest 実行（`pytest` コマンド）を行わない。`--collect-only` で収集のみ確認。
> 実際の pytest 実行は pochi-unit-test-reporter（T-5）が担う。

---

## 7. 非機能要件（スキルチェーン統合観点）

| 要件 | 内容 |
|---|---|
| 実行タイミング | コードが存在しない状態（開発初期）で実行する。既存コードへの後付けは `pochi-unit-test-generator` を使う |
| 冪等性 | 同じ spec.json で再実行した場合、テストファイルを上書き生成する（conftest.py は末尾追記のみ） |
| RED 状態の保持 | 生成されたテストは ImportError を起こして当然（コード不在）。スキルが RED を修正しようとしない |
| 認証不要 | GitHub API は使用しない。ローカルファイル操作のみ |
| plan.json 不変 | plan.json への書き込みは行わない（フィールドオーナーシップ対象外） |

---

## 8. 実行前チェックリスト（スキルチェーン運用）

以下を満たしてから Tdd フェーズを実行すること:

- [ ] `pochi-spec-initializer` が完了し、spec.json が生成済みであること
- [ ] spec.json に `data_contracts` フィールドが存在すること
- [ ] spec.json に `business_rules` フィールドが存在すること
- [ ] plan.json が存在し、`artifacts` フィールドが含まれること
- [ ] T-2.5（github-branch-creator）が完了し、feature/issue-NNN ブランチに checkout 済みであること
- [ ] `app_path` 配下に tests/ ディレクトリが作成可能であること（または既に存在）

---

## 9. スキルチェーン内での未解決事項

| ID | 項目 | 暫定方針 |
|---|---|---|
| U-Tdd-1 | pochi-spec-initializer が data_contracts / business_rules を必ず出力するか | 現状は spec.json の内容に依存。spec-initializer 側での出力保証は別途確認が必要 |
| U-Tdd-2 | test-mapping.json の task_id が plan.json の tasks[].id と一致しない場合の対応 | 現行スキルは null を設定して続行。coding-agent との連携精度に影響する可能性あり |
