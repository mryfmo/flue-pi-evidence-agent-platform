# 要件定義書: github-branch-creator（新規スキル）

対応タスク: T-2.5（スキル設計・実装、github-issue-creator 完成後）  
作成日: 2026-05-24  更新日: 2026-05-25（セキュリティレビュー対応: SEC-04/05/06 を反映、レビュー002.md 指摘対応）  
担当: RS

---

## 1. スキルメタデータ

| 項目 | 値 |
|---|---|
| スキルID | `github-branch-creator` |
| 表示名 | GitHub Branch Creator |
| カテゴリ | `spec/` |
| 種別 | 新規スキル |
| バージョン | 1.0.0 |
| 正式ファイルパス | `skills/spec/github-branch-creator/skills/run/SKILL.md` |
| ブランチ名 | `feature/github-branch-creator` |
| Issue | TBD |
| 依存タスク | T-2（github-issue-creator 実装）完成・`github_issue_number` が plan.json に存在すること |

---

## 2. 概要

`github-issue-creator` が plan.json に書き戻した `github_issue_number` を読み込み、`feature/issue-NNN` ブランチをローカルに作成するスキル。ブランチ名を plan.json に書き戻すことで、後続の `pochi-coding-agent` が正しいブランチで実装を始められるようにする。

**分離の理由**: ブランチ作成はコード実装とは独立した Git 操作であり、パイプライン上でも独立したステップとして明確にすべき（ロードマップ To-Be の「ブランチ切り」ステップに対応）。

**スキルの責務は「ローカルブランチ作成のみ」**。push は `pochi-coding-agent` が担う。

---

## 3. パイプライン上の位置

```
github-issue-creator
  ↓ plan.json に github_issue_number を書き込む
github-branch-creator  ← このスキル
  ↓ plan.json に github_branch を書き込む
pochi-tdd-test-generator（Tdd）← RED テスト先行生成（任意）
  ↓ tests/.onboarding/test-mapping.json を出力
pochi-coding-agent（T-3）← 実装のみ
  ↓
github-push-and-pr-creator（T-4）← push・PR 作成
  ↓ plan.json に github_pr_number を書き込む
github-pr-reviewer（T-5）← PR へのコードレビューコメント自動生成
```

---

## 4. 入力仕様

| 入力 | 形式 | 必須 | 説明 |
|---|---|:---:|---|
| `plan.json` の `github_issue_number` | number | ✅ | T-2 で追記済みの Issue 番号 |
| アプリパス | 引数またはカレントディレクトリ | ✅ | plan.json の探索起点 |

> **認証不要**: ローカルブランチ作成のみのため GitHub 認証は不要。Claude Code が Bash ツール経由で `git checkout -b` コマンドを直接実行する。

---

## 5. 出力仕様

### 5-1. plan.json への書き戻し

```json
{
  "github_branch": "feature/issue-42"
}
```

plan.json の既存フィールドを保持したまま `github_branch` のみ追記・更新する。

### 5-2. 標準出力（完了サマリ）

```
✅ ブランチ feature/issue-42 を作成しました
   次のステップ: pochi-coding-agent を起動して実装を開始してください
```

---

## 5-B. バリデーションルール

> **SEC-04/05 対応**: git 操作は `scripts/github_branch_creator.py` が担う。Claude Code はスクリプトを Bash で呼び出すだけであり、git コマンドを直接組み立てない。
> 共通ガイドラインは `skill-requirements-overview.md` の「SEC-04」セクションを参照。

### ブランチ名の生成ルール（SEC-05）

| ルール | 内容 |
|---|---|
| 生成方式 | `feature/issue-{github_issue_number}` のみ。**タイトル文字列は使用しない** |
| 許可パターン | `/^feature\/issue-[0-9]+$/`（自動生成パターン固定のため、これ以外を許容しない） |
| 最大長 | Git 上限 256バイト（運用上限: 100文字） |
| 特殊文字禁止 | `..` `~` `^` `:` `\` スペース（Git の checkout エラー原因） |

### github_issue_number のバリデーション（SEC-04、スクリプト内で実施）

```python
# allowlist チェック: 正の整数のみ許可
if not re.match(r'^[0-9]+$', issue_number):
    print("❌ github_issue_number の値が不正です", file=sys.stderr)
    raise SystemExit(1)
```

### 重複チェックと冪等性確保（SEC-05、スクリプト内で実施）

```python
# ローカルブランチの重複チェック
result = subprocess.run(
    ["git", "branch", "--list", branch_name],
    capture_output=True, text=True
)
if branch_name in result.stdout:
    # 既存ブランチへ checkout
    subprocess.run(["git", "checkout", branch_name], ...)
else:
    subprocess.run(["git", "checkout", "-b", branch_name], ...)
# git branch -D は関数として存在しない
```

### Claude Code の呼び出し方

```bash
# ✅ CCはスクリプトを呼び出すだけ
python skills/spec/github-branch-creator/scripts/github_branch_creator.py \
  --plan plan.json
```

---

## 6. 処理フロー

> **実行主体**: Claude Code は `scripts/github_branch_creator.py` を Bash で呼び出す。git コマンドの実行・バリデーション・エラーハンドリングはすべてスクリプト内で完結する。

```
1. Claude Code が Bash でスクリプトを呼び出す
   python skills/spec/github-branch-creator/scripts/github_branch_creator.py \
     --plan plan.json

2. スクリプト内処理（github_branch_creator.py）
   a. 入力検証
      - plan.json が見つからない → エラー終了
      - plan.json に github_issue_number が存在しない → エラー終了（「github-issue-creator を先に実行してください」と案内）
      - github_issue_number が `/^[0-9]+$/` に一致しない → エラー終了（SEC-04）

   b. ブランチ名を決定
      - branch_name = "feature/issue-{github_issue_number}"（タイトル文字列は使用しない）（SEC-05）
      - 生成したブランチ名が許可パターン・最大長を満たすことを確認（SEC-05）

   c. 重複チェック（SEC-05）
      - subprocess.run(["git", "branch", "--list", branch_name]) でローカルブランチを確認
      - plan.json に github_branch が既にある場合も同様に確認
      - 既存の場合: subprocess.run(["git", "checkout", branch_name]) → plan.json の値を確認して正常終了
      - 新規の場合: subprocess.run(["git", "checkout", "-b", branch_name])
      - git branch -D は関数として存在しない

   d. plan.json に github_branch をアトミック書き込み（SEC-06）
      - mktemp を plan.json と同一ディレクトリに作成し rename

   e. 完了サマリを出力（5-2 参照）
```

---

## 7. 非機能要件

| 要件 | 内容 |
|---|---|
| 認証不要 | ローカルブランチ作成のみのため GitHub API も `gh` コマンドも不要。Claude Code が Bash で `git` コマンドのみ実行する |
| 冪等性 | 同名ブランチが既にある場合は checkout のみ行い正常終了する（SEC-05） |
| エラーハンドリング | git コマンド失敗時は plan.json に書き戻さない |
| ブランチ名バリデーション | github_issue_number から機械的に生成（タイトル不使用）。生成後に `/^feature\/issue-[0-9]+$/` で完全一致チェックを実施（SEC-05） |
| コマンドインジェクション対策 | github_issue_number は `/^[0-9]+$/` のみ許可（SEC-04）。引数配列で git に渡す |
| plan.json アトミック書き込み | tmp ファイル経由の rename パターンを使用（競合・部分書き込み防止）（SEC-06） |

---

## 8. SKILL.md フロントマター（案）

```yaml
---
name: github-branch-creator
description: >-
  plan.json の github_issue_number を読んで feature/issue-NNN ブランチをローカルに作成し、
  ブランチ名を plan.json に書き戻すスキル。
  github-issue-creator の後、pochi-coding-agent の前に実行する。
  「ブランチを作成して」「github-branch-creatorを起動」「featureブランチを切って」と言われたときに使用する。
allowed-tools: Read, Write, Edit, Bash
---
```

---

## 9. skills.json エントリ（案）

```json
{
  "id": "github-branch-creator",
  "name": "GitHub Branch Creator",
  "path": "skills/spec/github-branch-creator/skills/run/SKILL.md",
  "entrypoint_type": "prompt",
  "entrypoint_path": "skills/spec/github-branch-creator/skills/run/SKILL.md",
  "triggers": [
    "ブランチを作成して",
    "github-branch-creatorを起動",
    "featureブランチを切って"
  ],
  "auto_load": false
}
```

---

## 10. marketplace.json エントリ（案）

```json
{
  "name": "github-branch-creator",
  "source": "./skills/spec/github-branch-creator",
  "description": "plan.json の issue 番号から feature/issue-NNN ブランチを作成し plan.json に書き戻す"
}
```

---

## 11. plugin.json（案）

```json
{
  "name": "github-branch-creator",
  "description": "plan.json の github_issue_number から feature ブランチをローカルに作成するスキル",
  "version": "1.0.0",
  "keywords": [],
  "license": "社内利用限定"
}
```

---

## 12. pochi-skill-navigator への追記（案）

### spec/ テーブルへの追記行

```markdown
| `github-branch-creator` | plan.json の github_issue_number を読んで feature/issue-NNN ブランチをローカルに作成し、ブランチ名を plan.json に書き戻す | 「ブランチを作成して」「github-branch-creatorを起動」「featureブランチを切って」 | plan.json（github_issue_number あり） | ❌ |
```

（単独実行 ❌ = github-issue-creator で issue 番号が plan.json に書き込まれてから実行すること）

### キーワードマッピングへの追記行

```markdown
| ブランチ作成、branch-creator、featureブランチ | `github-branch-creator`（github_issue_number 必須）→ `pochi-coding-agent`（実装） |
```

---

## 13. 実装時に更新が必要なファイル

| ファイル | 更新内容 |
|---|---|
| `skills/spec/github-branch-creator/skills/run/SKILL.md` | 新規作成（フロントマター + 本体） |
| `skills/spec/github-branch-creator/plugin.json` | 新規作成 |
| `.claude-plugin/marketplace.json` | `plugins[]` にエントリ追加 |
| `.claude/skills.json` | `skills[]` にエントリ追加 |
| `README.md` | Skill一覧テーブル・`/plugin install` コマンドリスト（2箇所）・トリガーテーブルに追記 |
| `skills/tools/pochi-skill-navigator/skills/run/SKILL.md` | spec/ テーブル・キーワードマッピング・ワークフロー更新 |
| `release-note.md` | `### Added` に追記 |
| `.claude/skills/SKILLS_MANAGEMENT.md` | 現在登録されているSkillsテーブルに追記（推奨） |
