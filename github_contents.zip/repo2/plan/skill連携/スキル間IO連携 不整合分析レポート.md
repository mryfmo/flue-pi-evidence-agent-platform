# スキル間IO連携 不整合分析レポート

作成日: 2026-04-14

## 対象スキル

| # | スキル | カテゴリ | 役割 |
|---|---|---|---|
| 1 | pochi-spec-initializer | spec | 仕様書（spec.json / plan.json）生成 |
| 2 | pochi-coding-agent | spec | 仕様に基づく実装 |
| 3 | pochi-test-strategy-initializer | test | テスト戦略初期化 |
| 4 | pochi-unit-test-generator | test | L1/L2テスト生成（既存コード向け） |
| 5 | pochi-tdd-test-generator | test | TDD先行L1/L2テスト生成（仕様書向け） |
| 6 | pochi-integration-test-designer | test | L3結合テスト設計書生成 |
| 7 | pochi-integration-test-generator | test | L3結合テストコード生成 |
| 8 | pochi-e2e-test-designer | test | L4 E2Eテスト設計書生成 |
| 9 | pochi-e2e-test-generator | test | L4 E2Eテストコード生成 |
| 10 | pochi-e2e-base-verifier | test | BasePage検証テスト配置 |
| 11 | pochi-coverage-fixer | test | カバレッジ計測・不足テスト自動生成 |

---

## 全スキルIO一覧

### 1. pochi-spec-initializer（仕様書生成）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | ユーザー提供の議事録・PRD等 | 任意 | |
| **IN** | `migration.json` | マイグレーション時必須 | |
| **OUT** | `{app_path}/spec/features/{FEATURE-ID}/spec.json` | | フェーズ2 |
| **OUT** | `{app_path}/spec/features/{FEATURE-ID}/spec.md` | | フェーズ2 |
| **OUT** | `{app_path}/spec/plans/{FEATURE-ID}.json` | | フェーズ2 |
**分岐条件:**
- 通常モード vs マイグレーションモード: テンプレート・質問が異なる

---

### 2. pochi-coding-agent（実装）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | `pochi-spec-initializer/specs/features/{FEATURE-ID}/spec.json` | 必須 | |
| **IN** | `pochi-spec-initializer/plans/{FEATURE-ID}.json` | 必須 | |
| **IN** | `tests/.onboarding/test-mapping.json` | TDD時必須 | |
| **OUT** | plan.jsonの`artifacts[]`で指定されたファイル | | 実装コード |
| **OUT** | `pochi-spec-initializer/specs/features/{FEATURE-ID}/task_results/{TASK-ID}.json` | | 常時 |
| **OUT** | `pochi-spec-initializer/specs/features/{FEATURE-ID}/task_results/{TASK-ID}_test_output.txt` | | TDD時のみ |
| **OUT** | `pochi-spec-initializer/specs/features/{FEATURE-ID}/task_results/{TASK-ID}_mismatch_report.md` | | blocked時のみ |

**分岐条件:**
- `test-mapping.json` 存在 → TDDモード（RED→実装→GREEN→回帰テスト）
- `test-mapping.json` 非存在 → 通常モード（実装のみ、テスト実行なし）
- GREEN失敗時: 最大3回修正ループ → 解消しなければ `blocked` + `mismatch_report.md` 生成
- 回帰テスト失敗時: 最大1回修正 → 解消しなければ `blocked`

---

### 3. pochi-test-strategy-initializer（テスト戦略初期化）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | ユーザーヒアリングのみ | | 既存ファイル参照なし |
| **OUT** | `{app_path}/tests/.onboarding/test-strategy-config.json` | | STEP 4 |
| **OUT** | `{app_path}/tests/conftest.py` | | STEP 5 |

**分岐条件:**
- `framework = "streamlit"`: conftest.py に `_passthrough_decorator` パターン
- `framework = "flask"`: conftest.py に `app.test_client()` パターン
- `framework = "cli"` / その他: conftest.py に `sys.path` のみ
- `e2e_enabled = true`: `test-strategy-config.json` に `layers.L4_e2e` セクション追加

---

### 4. pochi-unit-test-generator（L1/L2テスト生成）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | `{app_path}/tests/.onboarding/test-strategy-config.json` | 必須 | 未存在時はスキル終了 |
| **IN** | `{app_path}/app/**/*.py`（既存コード） | 必須 | T0解析対象 |
| **IN** | `{app_path}/{entrypoint}` | 必須 | T0解析のスタート地点 |
| **OUT** | `{app_path}/tests/.onboarding/module-inventory.json` | | STEP 2 |
| **OUT** | `{app_path}/tests/.onboarding/draft-contracts/` | | STEP 2 |
| **OUT** | `{app_path}/tests/contracts/data-contracts.json` | | STEP 3 |
| **OUT** | `{app_path}/tests/contracts/business-rules.json` | | STEP 3 |
| **OUT** | `{app_path}/tests/contracts/test-viewpoints.json` | | STEP 3 |
| **OUT** | `{app_path}/tests/contracts/scenarios.json` | | STEP 3 |
| **OUT** | `{app_path}/tests/contracts/domain-rules.md` | | STEP 3 |
| **OUT** | `{app_path}/tests/contracts/risk-catalog.md` | | STEP 3 |
| **OUT** | `{app_path}/tests/fixtures/{valid,invalid,edge}/` | | STEP 4 |
| **OUT** | `{app_path}/tests/fixtures/manifest.json` | | STEP 4 |
| **OUT** | `{app_path}/tests/conftest.py` | | STEP 5（上書き更新） |
| **OUT** | `{app_path}/tests/contracts/test_*_schema.py`（L1） | | STEP 6 |
| **OUT** | `{app_path}/tests/.onboarding/test-ratio.json` | | STEP 6 |
| **OUT** | `{app_path}/tests/.onboarding/unit-test-design.md` | | STEP 7 |
| **OUT** | `{app_path}/tests/unit/test_*.py`（L2） | | STEP 8 |

**分岐条件:**
- `test-strategy-config.json` 未存在 → スキル終了
- `tests/contracts/` 既存 → 上書き確認をユーザーに提示
- boundary フィールドあり → `test_{boundary_name}_schema.py` 生成
- boundary フィールド未定義 → 固定3ファイル（`test_input_schema.py` / `test_output_schema.py` / `test_business_rules.py`）生成
- risk-catalog HIGH > 30% → test-ratio.json の異常系比率を50%に引き上げ

---

### 5. pochi-tdd-test-generator（TDD先行L1/L2テスト）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | `{app_path}/tests/.onboarding/test-strategy-config.json` | 必須 | 未存在時はスキル終了 |
| **IN** | `{spec_json_path}`（ユーザー指定） | 必須 | 未発見時はスキル終了 |
| **IN** | `{plan_json_path}`（ユーザー指定） | 必須 | 未発見時はスキル終了 |
| **OUT** | `{app_path}/tests/contracts/data-contracts.json` | | STEP 2 |
| **OUT** | `{app_path}/tests/contracts/business-rules.json` | | STEP 2 |
| **OUT** | `{app_path}/tests/contracts/test-viewpoints.json` | | STEP 2 |
| **OUT** | `{app_path}/tests/contracts/scenarios.json` | | STEP 2 |
| **OUT** | `{app_path}/tests/contracts/domain-rules.md` | | STEP 2 |
| **OUT** | `{app_path}/tests/contracts/risk-catalog.md` | | STEP 2 |
| **OUT** | `{app_path}/tests/fixtures/{valid,invalid,edge}/` | | STEP 3 |
| **OUT** | `{app_path}/tests/fixtures/manifest.json` | | STEP 3 |
| **OUT** | `{app_path}/tests/conftest.py` | | STEP 4 |
| **OUT** | `{app_path}/tests/.onboarding/test-ratio.json` | | STEP 5 |
| **OUT** | `{app_path}/tests/contracts/test_*_schema.py`（L1 RED） | | STEP 5 |
| **OUT** | `{app_path}/tests/.onboarding/unit-test-design.md` | | STEP 6 |
| **OUT** | `{app_path}/tests/unit/test_*.py`（L2 RED） | | STEP 7 |
| **OUT** | `{app_path}/tests/.onboarding/test-mapping.json` | | STEP 9 |

**分岐条件:**
- plan.json に artifacts フィールドあり → conftest.py のフレームワーク・importパスを自動決定
- plan.json に artifacts 未指定 → デフォルト設定（streamlit / `{app_path}/app/`）
- spec.json に boundary あり → `test_{boundary_name}_schema.py` 生成
- spec.json に boundary 未指定 → デフォルト名で生成
- SyntaxError / NameError 検出 → 最大3回修正（ImportError は修正不要＝RED期待）

---

### 6. pochi-integration-test-designer（L3設計書）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | `{app_path}/tests/.onboarding/test-strategy-config.json` | 必須 | |
| **IN** | `{app_path}/tests/.onboarding/module-inventory.json` | 必須 | 不在時は内部でT0→T1→T4を実行可 |
| **IN** | `{app_path}/tests/contracts/data-contracts.json` | 必須 | 同上 |
| **IN** | `{app_path}/tests/contracts/business-rules.json` | 必須 | 同上 |
| **IN** | `{app_path}/tests/contracts/test-viewpoints.json` | 必須 | 同上 |
| **IN** | `{app_path}/tests/contracts/risk-catalog.md` | 必須 | 同上 |
| **IN** | `{app_path}/app/**/*.py`（既存コード） | 必須 | |
| **OUT** | `{app_path}/tests/.onboarding/integration-test-design.md` | | STEP 4 |

**分岐条件:**
- `module-inventory.json` 存在 → STEP 2 スキップ → STEP 3 へ直進
- `module-inventory.json` 未存在 + ユーザーが [A] → スキル終了（unit-test-generator 先行を案内）
- `module-inventory.json` 未存在 + ユーザーが [B] → 本スキル内でT0→T1→T4を実行
- `integration-test-design.md` 既存 → `.bak` バックアップして上書き

---

### 7. pochi-integration-test-generator（L3テストコード）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | `{app_path}/tests/.onboarding/integration-test-design.md` | 必須 | 未存在時はスキル終了 |
| **IN** | `{app_path}/tests/.onboarding/module-inventory.json` | 必須 | |
| **IN** | `{app_path}/tests/contracts/data-contracts.json` | 必須 | |
| **IN** | `{app_path}/tests/contracts/risk-catalog.md` | 必須 | |
| **IN** | `{app_path}/app/**/*.py`（既存コード） | 必須 | |
| **OUT** | `{app_path}/tests/integration/conftest.py` | | STEP 3 |
| **OUT** | `{app_path}/tests/conftest.py` | | STEP 3（未存在時のみ） |
| **OUT** | `{app_path}/tests/integration/test_*_integration.py` | | STEP 4 |

**分岐条件:**
- `integration-test-design.md` 未存在 → スキル終了
- `tests/conftest.py` 未存在 → 共通 conftest.py も生成
- `tests/integration/` に既存ファイル → ユーザーに [A]上書き / [B]差分追加 / [C]中止 を選択
- `framework = "streamlit"` → conftest.py に `mock_streamlit_cache` フィクスチャ追加

---

### 8. pochi-e2e-test-designer（L4設計書）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | `{app_path}/tests/.onboarding/test-strategy-config.json` | 必須 | e2e_enabled確認 |
| **IN** | `pochi-spec-initializer/specs/features/*/spec.json` | 任意（優先度1） | TDDフロー時 |
| **IN** | `plan.json` | 任意（優先度1） | spec.jsonと同時使用 |
| **IN** | `{app_path}/tests/.onboarding/integration-test-design.md` | 任意（優先度2） | 重複排除用 |
| **IN** | `{app_path}/tests/.onboarding/e2e-design-context.json` | 任意 | 設計コンテキスト（新パス） |
| **IN** | `{app_path}/app_structure.md` | 推奨（優先度3） | |
| **IN** | `{app_path}/tests/.onboarding/diffs/` | Partial時必須（優先度4） | Git差分 |
| **OUT** | `{app_path}/tests/.onboarding/e2e-test-design-functional.md` | | STEP 5 |
| **OUT** | `{app_path}/tests/.onboarding/e2e-test-design-scenario.md` | | STEP 5 |
| **OUT** | `{app_path}/tests/.onboarding/e2e-quality-report.md` | | STEP 6 |
| **OUT** | `{app_path}/tests/.onboarding/e2e-design-context.json` | | STEP 1 |

**分岐条件:**
- `test-strategy-config.json` 未存在 → スキル終了
- `e2e_enabled: false` → スキル終了
- パターン A（Full）→ 全機能テスト設計書を新規生成
- パターン B（Partial）→ 差分のみ更新

---

### 9. pochi-e2e-test-generator（L4テストコード）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | `{app_path}/tests/.onboarding/e2e-test-design-functional.md` | 推奨（優先度1） | |
| **IN** | `{app_path}/tests/.onboarding/e2e-test-design-scenario.md` | 推奨（優先度2） | |
| **IN** | `{app_path}/tests/.onboarding/e2e-design-context.json` | 任意 | |
| **IN** | `{app_path}/tests/.onboarding/e2e-generation-context.json` | 任意 | 本スキル内部用 |
| **IN** | `{app_path}/tests/.onboarding/test-strategy-config.json` | 任意 | |
| **IN** | `{app_path}/app_structure.md` | 推奨 | UI要素情報 |
| **OUT** | `{app_path}/tests/e2e/conftest.py` | | |
| **OUT** | `{app_path}/tests/e2e/e2e_config.py` | | |
| **OUT** | `{app_path}/tests/e2e/pages/base_page.py` | | |
| **OUT** | `{app_path}/tests/e2e/pages/{page}_page.py` | | |
| **OUT** | `{app_path}/tests/e2e/test_{feature}.py` | | |
| **OUT** | `{app_path}/tests/.onboarding/e2e-generation-context.json` | | |
| **OUT** | `{app_path}/tests/.onboarding/e2e-validation/test_validation_report.md` | | オプション |

**分岐条件:**
- 新形式設計書なし → 旧形式（`test_cases_integration.md` / `test_cases_scenario.md`）にフォールバック
- 旧形式もなし → `test_cases.md` にフォールバック（最終手段）
- STEP 4.5 検証実行時 → `test_validation_report.md` 生成

---

### 10. pochi-e2e-base-verifier（BasePage検証）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | `{app_path}/tests/e2e/pages/base_page.py` | 必須 | 未存在時はスキル終了 |
| **IN** | `{app_path}/tests/e2e/conftest.py` | 必須 | |
| **IN** | `{app_path}/tests/e2e/e2e_config.py` | 必須 | |
| **IN** | `plan/ALADIN-WDH/test_alert_display.py`（スキルリポジトリ内） | 必須 | ソースファイル |
| **IN** | `plan/ALADIN-WDH/test_dataframe_download_button.py`（スキルリポジトリ内） | 必須 | ソースファイル |
| **OUT** | `{app_path}/tests/e2e/test_alert_display.py` | | STEP 4 |
| **OUT** | `{app_path}/tests/e2e/test_dataframe_download_button.py` | | STEP 4 |
| **OUT** | `{app_path}/tests/e2e/pages/dataframe_download_button_test_page.py` | | STEP 5 |
| **OUT** | `{app_path}/tests/e2e/test_apps/test_alert_display_app.py` | | STEP 6（オプション） |

**分岐条件:**
- `base_page.py` 未存在 → スキル終了（e2e-test-generator 先行を案内）
- 配置先ファイル既存 → ユーザー確認を取得

---

### 11. pochi-coverage-fixer（カバレッジ改善）

| 種別 | パスパターン | 必須 | 備考 |
|---|---|---|---|
| **IN** | `{app_path}/tests/.onboarding/test-strategy-config.json` | 任意 | カバレッジ目標値取得 |
| **IN** | `{app_path}/tests/.onboarding/coverage-gaps.json` | 任意 | T3実行済み時 |
| **IN** | `{app_path}/tests/conftest.py` | 必須 | 品質チェック対象 |
| **IN** | `{app_path}/tests/**/*.py`（既存テスト） | 必須 | カバレッジ計測対象 |
| **IN** | `{app_path}/app/` or `{app_path}/src/`（実装コード） | 必須 | カバレッジ計測対象 |
| **IN** | `{app_path}/setup.cfg` | 任意 | カバレッジ除外設定 |
| **OUT** | `{app_path}/tests/conftest.py`（修正版） | | フェーズ1（エラー検出時のみ） |
| **OUT** | `{app_path}/tests/unit/test_{module}_unit.py` | | フェーズ3 |
| **OUT** | `{app_path}/tests/integration/test_{module}_integration.py` | | フェーズ3 |
| **OUT** | `{app_path}/tests/coverage-report.md` | | フェーズ4（常時） |
| ~~**IN/OUT**~~ | ~~`{app_path}/tests/.onboarding/test-progress.json`~~ | 任意 | ~~存在時のみ更新~~ → **廃止済みファイル。生成元スキルなし（2026-04-14）** |

**分岐条件:**
- `coverage-gaps.json` 存在 → フェーズ2-1〜2-3スキップ → フェーズ3直行
- `coverage-gaps.json` 未存在 → フェーズ1（完全チェック）→ フェーズ2-1（pytest --cov）実行
- カバレッジ40%未満 + Stmts≥50 → 優先度1でテスト生成
- 改善後 < 目標60% → フェーズ3へ循環（最大3サイクル）
- `test-progress.json` 存在 → 更新 / 未存在 → 新規作成なし（実質常に未存在のため分岐は発動しない）

---

## 依存関係フロー図

```
pochi-spec-initializer
  ├──→ pochi-coding-agent              [spec.json, plan.json] ⚠️ パス不一致（不整合1）
  └──→ pochi-tdd-test-generator       [spec.json, plan.json] (手動パス入力)

pochi-test-strategy-initializer        ← test-strategy-config.json の唯一の正規生成元（2026-04-14 一本化）
  ├──→ pochi-unit-test-generator       [test-strategy-config.json]
  ├──→ pochi-tdd-test-generator       [test-strategy-config.json]
  ├──→ pochi-integration-test-designer [test-strategy-config.json]
  ├──→ pochi-e2e-test-designer         [test-strategy-config.json]
  ├──→ pochi-e2e-test-generator        [test-strategy-config.json]
  └──→ pochi-coverage-fixer            [test-strategy-config.json]

pochi-unit-test-generator
  ├──→ pochi-integration-test-designer [module-inventory.json, contracts/*]
  └──→ pochi-integration-test-generator [module-inventory.json, contracts/*]

pochi-tdd-test-generator
  └──→ pochi-coding-agent              [test-mapping.json]

pochi-integration-test-designer
  ├──→ pochi-integration-test-generator [integration-test-design.md]
  └──→ pochi-e2e-test-designer          [integration-test-design.md] (任意)

pochi-e2e-test-designer
  └──→ pochi-e2e-test-generator        [e2e-test-design-functional.md, e2e-test-design-scenario.md]

pochi-e2e-test-generator
  └──→ pochi-e2e-base-verifier         [base_page.py, conftest.py, e2e_config.py]

(不在) pochi-test-coverage-analyzer
  └──→ pochi-coverage-fixer            [coverage-gaps.json] ⚠️ 生成元スキル不在
```

---

## 検出された不整合

### 不整合1（重大）: spec.json / plan.json のパス不一致

| スキル | 参照パス |
|---|---|
| **pochi-spec-initializer** (OUT) | `{app_path}/spec/features/{FEATURE-ID}/spec.json` |
| **pochi-coding-agent** (IN) | `pochi-spec-initializer/specs/features/{FEATURE-ID}/spec.json` |
| **pochi-e2e-test-designer** (IN) | `pochi-spec-initializer/specs/features/*/spec.json` |

**2つの不一致:**
- **ディレクトリ名**: `spec/` vs `specs/`（末尾のsの有無）
- **基準パス**: `{app_path}/spec/` vs `pochi-spec-initializer/specs/`（基準ディレクトリが異なる）

plan.jsonも同様:
| スキル | 参照パス |
|---|---|
| **pochi-spec-initializer** (OUT) | `{app_path}/spec/plans/{FEATURE-ID}.json` |
| **pochi-coding-agent** (IN) | `pochi-spec-initializer/plans/{FEATURE-ID}.json` |

> **影響**: coding-agent / e2e-test-designer が起動時に spec.json / plan.json を参照できず、実行が即座に失敗する可能性が高い。

---

### ~~不整合2（重大）: test-progress.json のライフサイクル矛盾~~ ✅ 解消済み（2026-04-14）

| スキル | 記述内容 |
|---|---|
| ~~**pochi-spec-initializer**~~ | ~~STEP 11 で `test-progress.json` を生成する~~ → **フェーズ2.5削除により生成しなくなった** |
| **pochi-coverage-fixer** | 「作成責務は上流スキル（**unit-test-generator / tdd-test-scaffolder**）が担う」と記載 |
| **pochi-unit-test-generator** | 「**test-progress.json は廃止されました**」と明記 |
| **pochi-tdd-test-generator** | `test-progress.json` に関する言及なし（生成も参照もしない） |

**対応**: `pochi-spec-initializer` のフェーズ2.5削除により、`test-progress.json` を生成するスキルがなくなった。`pochi-coverage-fixer` の `test-progress.json` 参照（存在時のみ更新）は残存しているが、廃止ファイルとして実害はない。

> `pochi-coverage-fixer` の IO表の `test-progress.json` 行は廃止済みの名残。将来的に削除が望ましい。

---

### ~~不整合3（重大）: test-strategy-config.json の構造的不一致~~ ✅ 解消済み（2026-04-14）

**原因**: `pochi-spec-initializer` のフェーズ2.5（STEP10・11）で `test-strategy-config.json` / `test-progress.json` を生成していたが、内容が `pochi-test-strategy-initializer` の生成物と構造的に異なっていた（`mock_strategy` セクション欠落・`L3_integration.framework` 不一致）。

**対応**: `pochi-spec-initializer` の責務を仕様書生成（`spec.json` / `spec.md` / `plan.json`）のみに限定し、フェーズ2.5を丸ごと削除した。テスト戦略ファイルの生成は `pochi-test-strategy-initializer` に一本化。

> `test-strategy-config.json` / `test-progress.json` は `pochi-spec-initializer` の OUT から除外された。

---

### 不整合4（中程度）: conftest.py の多重上書き

`{app_path}/tests/conftest.py` を生成・修正するスキル:

| 順序 | スキル | 処理 |
|---|---|---|
| 1 | pochi-test-strategy-initializer | STEP 5 で新規生成 |
| 2 | pochi-unit-test-generator | STEP 5 でT0解析結果を反映して**上書き** |
| 3 | pochi-tdd-test-generator | STEP 4 で生成 |
| 4 | pochi-integration-test-generator | STEP 3 で未存在時のみ生成 |
| 5 | pochi-coverage-fixer | フェーズ1 でエラー修正 |

> **影響**: 
> - unit-test-generator が上書きなのかマージなのか明記がないため、test-strategy-initializer で設定したフィクスチャが喪失するリスクあり
> - tdd-test-scaffolder も同様に上書きの可能性あり

---

### 不整合5（軽度）: tdd-test-scaffolder の spec.json パス自動検出なし

| 項目 | 内容 |
|---|---|
| spec-initializer の出力パス | `{app_path}/spec/features/{FEATURE-ID}/spec.json` |
| tdd-test-scaffolder の入力方法 | ユーザーに `spec_json_path` を手動入力させる |

> **影響**: spec-initializer の出力パスを自動検出する仕組み（Glob等）が記載されていないため、ユーザーがパスを正確に把握している必要がある

---

### 不整合6（軽度）: coverage-gaps.json の生成元スキル不在

| 項目 | 内容 |
|---|---|
| 参照スキル | pochi-coverage-fixer |
| 参照ファイル | `{app_path}/tests/.onboarding/coverage-gaps.json` |
| 記載の生成元 | pochi-test-coverage-analyzer（T3） |
| 実態 | `skills/test/` に該当スキルが存在しない |

> **影響**: coverage-gaps.json がある前提の分岐（フェーズ2-1〜2-3スキップ）が常に発動せず、必ずフル計測が実行される（機能的には問題ないが、設計意図と乖離）

---

### 不整合7（軽度）: pochi-e2e-base-verifier の SKILL.md 配置ガイドライン違反

| 項目 | 内容 |
|---|---|
| 正式パス（ガイドライン） | `skills/test/pochi-e2e-base-verifier/skills/run/SKILL.md` |
| 実態 | `skills/run/SKILL.md` は8行のスタブ。本体はルート直下の `SKILL.md`（300行以上） |
| ガイドライン | CLAUDE.md に「skills/run/SKILL.md が正式」「トップレベルには作成しない」と規定 |

> **影響**: プラグインシステムが `skills/run/SKILL.md` のみをキャッシュへコピーするため、8行のスタブしか認識されず本体が読み込まれない可能性がある

---

## 不整合サマリー

| # | 重大度 | 不整合内容 | 影響するスキル |
|---|---|---|---|
| 1 | **重大** | spec.json / plan.json のパス不一致（`spec/` vs `specs/`、基準パスの相違） | spec-initializer ↔ coding-agent, e2e-test-designer |
| 2 | ~~重大~~ ✅解消 | ~~test-progress.json のライフサイクル矛盾~~ → spec-initializer のフェーズ2.5削除により生成元がなくなり矛盾解消。coverage-fixer の参照行は廃止済みの名残として残存 | - |
| 3 | ~~重大~~ ✅解消 | ~~test-strategy-config.json の構造的不一致~~ → spec-initializer のフェーズ2.5を削除し、test-strategy-initializer に一本化 | - |
| 4 | 中程度 | conftest.py の多重上書き（マージか上書きかの明記なし） | strategy-initializer, unit-test-generator, tdd-scaffolder, integration-generator, coverage-fixer |
| 5 | 軽度 | tdd-test-scaffolder が spec.json パスを自動検出しない | spec-initializer → tdd-test-scaffolder |
| 6 | 軽度 | coverage-gaps.json の生成元スキル（T3）が不在 | coverage-fixer |
| 7 | 軽度 | pochi-e2e-base-verifier の SKILL.md 配置がガイドライン違反 | e2e-base-verifier |
