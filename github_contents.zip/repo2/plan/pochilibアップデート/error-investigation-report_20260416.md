# 原因調査レポート: pochilibアップデートに伴うStreamlitエラー

**作成日**: 2026-04-16
**作成者**: 鈴木 亮太（RS）
**調査情報ソース**: プロセス表明会議 2026-04-16 議事録（鈴木・松本による議論）

---

## 1. 概要

pochilibを0.7.4から0.7.7へバージョンアップした際、対象アプリ（ID変換器）を起動するとStreamlitのエラーが発生した。調査の結果、このエラーは **Streamlit 1.50.0 における `st.write` の `**kwargs` 正式削除（PR #12375、コミット `8db7f41b2`）** が引き金となり、**コード上に長期間潜在していたバグ**が顕在化したものと判明した。`**kwargs` は以前からdeprecatedであり実質的に無視されていたが、正式削除されたことで TypeError として表面化した。

---

## 2. 発生事象

| 項目 | 内容 |
|------|------|
| **対象アプリ** | ID変換器（pochilib 0.7.4 → 0.7.7 アップグレード） |
| **症状** | アップグレード後の起動時にStreamlitエラーが発生 |
| **エラー原因箇所** | `st.write(use_container_width=True, ...)` の記述 |
| **エラー内容** | `st.write` に `use_container_width` という引数が存在しないとして TypeError が発生 |

---

## 3. 直接原因

pochilib 0.7.7 が依存するStreamlitのバージョンが **1.48.1 から 1.50.0 以降** に引き上げられた。Streamlit 1.50.0 で `st.write` のシグネチャから `**kwargs` が正式削除されたため、コード内の `st.write(use_container_width=True, ...)` という記述が TypeError として検知されるようになった。

**該当変更（Streamlit PR #12375 / コミット `8db7f41b2`）:**

```python
# 変更前 (〜1.49.x)
def write(self, *args: Any, unsafe_allow_html: bool = False, **kwargs: Any) -> None:

# 変更後 (1.50.0〜)
def write(self, *args: Any, unsafe_allow_html: bool = False) -> None:
```

---

## 4. 根本原因 — なぜ長期間気づかれなかったのか

### 4.1 `**kwargs` はdeprecated後も長期間 warning のみだった

`st.write` の `**kwargs` は正式削除（1.50.0）以前から deprecated 扱いだったが、渡しても **warning ログが出るだけでエラーにはならなかった**。このため、`st.write(use_container_width=True, ...)` という誤った記述はコード上に残り続けた。

### 4.2 なぜ動いていたか（`**kwargs` 時代のメカニズム）

Streamlit 1.49.x 以前では `**kwargs` がシグネチャに残っていたため、余分なキーワード引数はすべて受け取り可能だった。ただし受け取った `**kwargs` の中身は何もしない（無視するだけ）実装だったため、`use_container_width=True` を渡しても実際には機能していなかった（＝意図した動作をしていない潜在バグ）。

```
# 1.49.x 以前の動作
st.write(df, use_container_width=True)
  → **kwargs で use_container_width を受け取るが何もしない（warning のみ）
  → エラーにはならずアプリは起動する
  → use_container_width は実際には無効（機能していない）
```

### 4.3 バグが顕在化したタイミング

Streamlit **1.50.0** の PR #12375 で `**kwargs` とそれに付随する warning 処理が**完全削除**された。これにより、余分なキーワード引数を渡すと TypeError が発生するようになった。

### 4.4 バグの混入時期

コミット履歴より、`st.write(use_container_width=True, ...)` の記述は **2025年3月18日**（上田氏によるコミット）に混入した。この時点のStreamlitは 1.48 系であり、`**kwargs` が deprecated warning のみで通過していたためエラーは発生せず潜在バグとなっていた。

---

## 5. バージョン履歴と影響範囲

```
pochilib 0.7.4  →  Streamlit 1.48.1  →  **kwargs あり（warning のみ）  →  エラーなし（潜在バグ）
pochilib 0.7.7  →  Streamlit 1.50.0〜 →  **kwargs 完全削除             →  TypeError 発生
```

| pochilib | Streamlit | `st.write **kwargs` | `use_container_width=True` 渡した場合 |
|----------|-----------|---------------------|---------------------------------------|
| 0.7.4 | 1.48.1 | deprecated（残存） | warning のみ、エラーなし（潜在バグ） |
| 0.7.7 | 1.50.0〜 | 完全削除（PR #12375） | **TypeError 発生** |

---

## 6. 影響調査スキルで検知できなかった理由

pochilibアップデート時に使用している**影響調査スキル**（リリースノートを参照してアプリへの影響を報告するもの）では、今回のエラーを事前に検知することができなかった。その理由は以下の通り。

1. **pochilib のリリースノートには記載されない**: 今回の破壊的変更は Streamlit 側の変更であり、pochilib のリリースノートには「Streamlit バージョン引き上げ」としか記載されない

2. **影響調査スキルが参照するリリースノートの記述粒度の問題**: スキルは pochilib のリリースノートをベースに影響を判定する設計のため、Streamlit 内部の個別 PR レベルの変更（`**kwargs` 削除）まで追跡できない

3. **`**kwargs` のdeprecatedは warning であり、既存コードの誤りとして検出されない**: deprecated になった時点でリリースノートに記載されても、コード上はエラーにならないため「影響あり」として報告されにくい。完全削除（breaking change）の時点で初めて問題が表面化する性質を持つ

### 6.1 リリースノートに情報があった場合の検知可能性（2026-04-16 追記）

`pochilib-0.7.7.md` に Streamlit 1.50.0 の `**kwargs` 削除情報（`**kwargs has been removed from st.write (#12375, #12374).`）が記載されていた場合、スキルは「問題あり（CRITICAL）」として検知できていたと判断できる。

スキルは以下の3層で検知を行う設計になっており、いずれかで引っかかる。

| 検知層 | 処理内容 | 今回の変更への適用 |
|---|---|---|
| **changelog-analyzer** | `⚠️破壊的変更` セクションまたは "removed"/"削除" キーワードで `breaking_changes` / `severity: critical` として記録 | 「⚠️破壊的変更」セクションに記載 or "removed" を含む文章であれば検知可能 |
| **usage-scanner** | `st.write\s*\(` パターンでコード内の `st.write` 呼び出しを検出 | `st.write(use_container_width=True, ...)` を使用箇所として検出可能 |
| **impact-detector** | changelog の「st.write から `**kwargs` 削除」と usage の「st.write にキーワード引数」を突合し CRITICAL 判定 | 両者が揃えば CRITICAL として impact-report.json に記録 |

**根本的な問題は情報の欠落**であり、スキルのロジック自体に欠陥があったわけではない。pochilib リリースノートに Streamlit 内部の破壊的変更が転記される仕組みがなければ、スキルがどれだけ高精度でも検知できない。

---

## 6.2 MEDIUM指摘との関係（2026-04-15 調査・2026-04-16 統合）

**調査対象**: `reports-002/impact-summary.md` の MEDIUM指摘 と `reports-002/issue.md` の改修内容

### MEDIUM指摘の内容

- **内容**: `key` を指定している `st.multiselect` / `st.selectbox` / `st.number_input` において、ウィジェットの同一性（identity）の判定から `options` / `min` / `max` が除外されるようになった（Streamlit 1.53.0）
- **対応指示**: 動作確認のみ（コード修正要と判定されていない）
- **理由**: APIの呼び出し方（コード）は変わらず、影響の有無は実際に動かさないと判断できないため
- **結果**: `issue.md` のチェックリストにより、手動テストで問題なしと確認済み

### イシュー（issue.md）で実際に対応した改修

- **内容**: `st.write(..., use_container_width=True)` → `st.dataframe(..., width='stretch')` に置換
- **対象ファイル**: `app/lib/view_output_data.py` / `app/lib/view_input_data.py`
- **エラーの種類**: 引数が存在しないためランタイムエラーでクラッシュ

### 両者の関係

MEDIUM指摘（ウィジェット同一性の変更）とイシューの改修（`use_container_width` 削除）は**別の問題**である。MEDIUM指摘は手動テストで問題なしと確認され、コード修正は不要だった。イシューの改修はMEDIUM指摘とは無関係に発生した別の問題への対応である。

### スキルが改修を検知できなかった原因（詳細）

- `pochilib-upgrade-analyst` スキルのStreamlit情報は `release-note/` ディレクトリ内のMarkdownファイルが**唯一の情報源**
- `pochilib-0.7.7.md` には `use_container_width` の削除に関する記載が**存在しない**
- そのため `pochilib-changelog-analyzer` がこの変更を読み取れず、影響分析に含まれなかった

### 確認できた事実・確認できなかった事実

| 項目 | 事実 |
|---|---|
| `use_container_width` がどのStreamlitバージョンで削除されたか | **不明**（リリースノートに記載なし） |
| スキルが持つStreamlitバージョン情報の範囲 | `pochilib-0.7.7.md` 内に 1.53.0 および 1.53.1 の情報が記載されている |
| 1.53.1の記載内容 | バグ修正のみ。破壊的変更（引数削除等）のセクションは存在しない |
| MEDIUM指摘の手動テスト結果 | `issue.md` のチェックリストにより、問題なしと確認済み |

---

## 7. 再発防止策

会議内で松本氏・鈴木氏から以下の対策案が提案された。

### 7.1 リンター（静的解析）の整備 ★推奨

pyright 等のリンターを `.vscode/settings.json` に設定しておくことで、存在しない引数へのアクセスをコミット前に検知できる。

```json
// .vscode/settings.json 例
{
  "python.analysis.typeCheckingMode": "basic",
  "python.analysis.diagnosticSeverityOverrides": {
    "reportArgumentType": "warning",
    "reportCallIssue": "error"
  }
}
```

- Claude Code はVSCode上のリンターエラー一覧を自動的に読み取れるため、設定するだけで精度が大幅に向上する
- 松本氏の見解: 「Claude Codeが精度が悪いバグを生み出す」の約半分はリンター未設定が原因と推測される

### 7.2 Streamlitソースコードの差分調査（補完手段）

GitHubからStreamlitリポジトリをローカルにクローンし、リリースタグ間の差分を確認する方法。

```bash
# 例: Streamlit 1.48.1 → 1.53.0 の差分確認
git clone https://github.com/streamlit/streamlit.git /tmp/streamlit-src
cd /tmp/streamlit-src
git diff v1.48.1..v1.53.0 -- lib/streamlit/elements/write.py
```

- GitHub API（レート制限あり）よりもローカルgitコマンドの方が高速・安全
- ただし差分量が多いため、リリースノートに載っていない変更の事前全量把握は現実的には難しい

#### 7.2.1 gh CLI / GitHub API によるリリースノート取得（2026-04-16 追記）

git diff に加え、**GitHub Releases のリリースノート**を `gh` CLI（GitHub CLI）で直接取得する方法が有効。

**背景**
- Streamlit のリリースノートは GitHub Releases に格納されており、リポジトリ内に CHANGELOG ファイルは存在しない
- git タグのアノテーション（`git cat-file -p 1.53.0`）にはリリースノート本文は含まれていない（タグメッセージは "Streamlit 1.53.0" のみ）
- `gh` CLI は GitHub API のラッパーであり、認証済みであれば API レート制限を気にせず使える

**コマンド例**

```bash
# リリース一覧確認
gh release list --repo streamlit/streamlit

# 特定バージョンのリリースノートを取得
gh release view 1.50.0 --repo streamlit/streamlit

# Breaking Changes セクションのみ抽出
gh release view 1.50.0 --repo streamlit/streamlit | grep -A 20 "Breaking Changes"
```

**git diff との使い分け**

| 方法 | 内容 | 用途 |
|------|------|------|
| `git diff v1.49.0..v1.50.0 -- <file>` | コードの差分（生の変更） | 特定ファイルの詳細変更把握 |
| `gh release view 1.50.0 --repo streamlit/streamlit` | Breaking Changes / New Features 等カテゴリ別のノート | 全体の変更把握・影響スクリーニング |

→ **まず `gh release view` で Breaking Changes を確認し、気になる変更があれば `git diff` でコード詳細を確認する**、という2段階アプローチが効率的。

### 7.3 テストシナリオの整備

アップグレード後にアプリのメインシナリオを手動 or 自動で一周することで、今回のようなエラーを検知できる。今回も手動テストで検知できていた。

### 7.4 方針のまとめ（コスト・効果バランス）

| 対策 | 検知タイミング | コスト | 推奨度 |
|------|--------------|--------|--------|
| リンター整備 | 実装・コミット時 | 低 | ★★★ |
| 手動/自動テスト | アップグレード後 | 中 | ★★☆ |
| ソースコード差分調査 | アップグレード前 | 高 | ★☆☆ |

松本氏の意見: 「事前に100%を把握しようとしすぎず、動かして後から調査・修正する方針（90%防止 + 10%ごめんなさい）」が現実的なコストバランスとして有効。

---

## 8. 参考情報

- **バグ混入コミット**: 2025-03-18（上田氏）
- **エラー発生確認日**: 2026-04-16（pochilib 0.7.7 アップグレード後）
- **議論参加者**: 鈴木 亮太、松本 竜矢、外山 雄介、長谷川 暁秀
- **Streamlit 破壊的変更**: PR #12375 / コミット `8db7f41b2`（`st.write **kwargs` 完全削除、v1.49.0 → v1.50.0）
- **関連ドキュメント**: pochilib 0.7.7 リリースノート、Streamlit v1.50.0 Changelog

---

最終更新日: 2026-04-16
