# 変更ログ解析サマリ

**解析日時**: 2026-04-07
**対象バージョン**: 0.7.4 → 0.7.7
**解析バージョン**: 0.7.5 / 0.7.6 / 0.7.7

---

## バージョン別変更概要

### 0.7.5（機能追加）

- **LLMモデル強化**: Gemini 2.5-flash/pro 対応、思考機能（thinkingBudget）、Google検索グラウンディング
- **廃止予定**:
  - `gemini-2.0-flash-001` → `gemini-2.0-flash` への移行推奨
  - `gemini-2.0-flash-lite-001` → `gemini-2.0-flash-lite` への移行推奨
  - `get_vertexai_anthropic_chat_model` 廃止予定

### 0.7.6（破壊的変更あり）

- **返却クラス変更**:
  - `get_vertexai_chat_model`: `ChatVertexAI` → `ChatGoogleGenerativeAI`
  - `get_vertexai_embedding_model`: `VertexAIEmbeddings` → `GoogleGenerativeAIEmbeddings`
- **廃止確定**: `get_vertexai_anthropic_chat_model` が完全削除

### 0.7.7（Streamlit 1.53.1 対応）

- **Streamlit バージョン**: 1.48.1 → 1.53.1
- **挙動変更（既存アプリへの影響あり）**:
  - `st.multiselect` / `st.number_input` / `st.selectbox`: `key` 指定時のウィジェット同一性からoptions/min/maxを除外
  - `st.spinner`: 一時的な要素として扱われるようになった
- **バグ修正**: `st.spinner` + コンテナのクラッシュ修正、`SnowflakeConnection.close()` 修正

---

## 破壊的変更一覧

| 影響度 | 変更内容 | バージョン |
|--------|---------|----------|
| ⚫ CRITICAL | `get_vertexai_anthropic_chat_model` 削除 | 0.7.6 |
| 🔴 HIGH | `get_vertexai_chat_model` 返却クラス変更（ChatVertexAI → ChatGoogleGenerativeAI） | 0.7.6 |
| 🟠 MEDIUM | `get_vertexai_embedding_model` 返却クラス変更 | 0.7.6 |
| 🟠 MEDIUM | `st.multiselect` / `st.selectbox` / `st.number_input` ウィジェット同一性変更 | 0.7.7 |
| 🟡 LOW | `st.spinner` 挙動変更 | 0.7.7 |

---

## 廃止 API 一覧

| API | 代替 | 確定状況 |
|-----|-----|--------|
| `get_vertexai_anthropic_chat_model` | なし | **削除済み（0.7.6〜）** |
| `gemini-2.0-flash-001` | `gemini-2.0-flash` | 廃止予定（0.7.5〜） |
| `gemini-2.0-flash-lite-001` | `gemini-2.0-flash-lite` | 廃止予定（0.7.5〜） |
