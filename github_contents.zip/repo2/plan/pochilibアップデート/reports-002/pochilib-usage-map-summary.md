# pochilib 使用状況サマリ

**スキャン日時**: 2026-04-07
**対象リポジトリ**: pochi-id-converter-repository
**スキャンファイル数**: 9ファイル

---

## リポジトリ別サマリ

| リポジトリ | pochilib バージョン | 使用モジュール | 廃止API |
|-----------|-------------------|--------------|--------|
| pochi-id-converter-repository | 0.7.4 | snowflake, user_interface_support, base, environment | なし |

---

## モジュール使用状況（全体）

| モジュール | インポート数 | メソッド呼び出し数 | 主要メソッド |
|-----------|------------|----------------|-----------|
| **snowflake** | 2 | 6 | generate_pochi_snowflake_connector, sf_sqlalchemy_tools.create_table |
| **user_interface_support** | 6 | 8 | detect_encoding, DogHarness, generate_gallery_back_button |
| **base (PochiStorage/PochiUserInfo)** | 2 | 3 | PochiStorage, PochiUserInfo, set_user_name |
| **environment** | 1 | 1 | PochiEnvironment.docker_image_tag |

---

## 廃止予定 API 使用状況

✅ **廃止予定 API の使用は検出されませんでした**

---

## アップグレード優先順位

| 順位 | リポジトリ | 現在版 | 目標版 | 優先度 | 理由 |
|-----|-----------|-------|-------|-------|-----|
| 1 | pochi-id-converter-repository | 0.7.4 | 0.7.7 | MEDIUM | LLM不使用のため影響は主にStreamlit挙動変更のみ |

---

## 特記事項

- `_WinterStreamFlow` は型ヒント専用のインポートで実行時不使用
- `DogHarness.view_dog_harness()` は現在コメントアウト中
- LLM機能（get_aoai_chat_model等）は使用していない
