## 手動テスト中に発見したエラーと修正内容

### 発生エラー

手動テスト（基本契約番号（01）→アカウント識別子の変換）実施中に以下のエラーが発生。

```
TypeError: WriteMixin.write() got an unexpected keyword argument 'use_container_width'

File "/home/user/pochi-id-converter-repository/app/lib/view_output_data.py", line 190, in view_output_data
    st.write(st.session_state["get_output"].head(100), use_container_width=True)
```

また、ログに以下の警告も出力されていた。

```
Please replace `use_container_width` with `width`.
`use_container_width` will be removed after 2025-12-31.
For `use_container_width=True`, use `width='stretch'`.
```

### 原因

Streamlit 1.53.1（pochilib 0.7.7 に同梱）で `use_container_width` 引数が `st.write()` から削除された。

### 修正内容

| ファイル | 修正前 | 修正後 |
|---------|--------|--------|
| `app/lib/view_output_data.py:190` | `st.write(..., use_container_width=True)` | `st.dataframe(..., width='stretch')` |
| `app/lib/view_input_data.py:297` | `st.dataframe(..., use_container_width=True)` | `st.dataframe(..., width='stretch')` |

`view_input_data.py` はエラーは未発生だったが、同一パターンのため合わせて修正。

### 修正コミット

c488bee `fix: use_container_width を width='stretch' に置換（Streamlit 1.53.1対応）`