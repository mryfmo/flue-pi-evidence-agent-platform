# 影響分析サマリ

**解析日時**: 2026-04-07
**対象リポジトリ**: pochi-id-converter-repository
**アップグレード**: 0.7.4 → 0.7.7
**総合リスク**: 🟢 LOW

---

## 影響サマリ

| 影響度 | 件数 |
|--------|-----|
| ⚫ CRITICAL | 0 |
| 🔴 HIGH | 0 |
| 🟠 MEDIUM | 1 |
| 🟡 LOW | 1 |
| ✅ 影響なし | 3 |

---

## 影響なしの理由（主要破壊的変更）

pochi-id-converter-repository は **LLM機能を一切使用していない**ため、0.7.5〜0.7.6 の主要な破壊的変更（LLM関連）の影響を受けません：

- `get_vertexai_chat_model` 返却クラス変更 → **影響なし**
- `get_vertexai_anthropic_chat_model` 削除 → **影響なし**
- `gemini-2.0-flash-001` 廃止 → **影響なし**

---

## 要確認事項

### 🟠 MEDIUM: Streamlit ウィジェット同一性の変更

**バージョン**: 0.7.7（Streamlit 1.53.0）

`key` を指定している場合、以下のウィジェットのウィジェット同一性の判定方法が変わります：
- `st.multiselect`（options を同一性に含めない）
- `st.number_input`（min/max を同一性に含めない）
- `st.selectbox`（options を同一性に含めない）

**対応**: アプリ内で key 指定の上記ウィジェットを使用している箇所を動作確認してください。

### 🟡 LOW: st.spinner 挙動変更

**バージョン**: 0.7.7（Streamlit 1.53.0）

`st.spinner` が一時的な要素として扱われるようになりました。なお、スピナー内でのコンテナ使用時のクラッシュバグは同バージョンで修正されています。

**対応**: st.spinner 使用箇所の動作確認（多くのケースで問題なし）。

---

## アップグレード推奨

✅ **アップグレード推奨**

LLM非使用アプリのため、影響は最小限です。Streamlit の挙動変更に関して簡単な動作確認を行えば、安全にアップグレードできます。

### アップグレード前チェック

- [ ] `st.multiselect` / `st.selectbox` / `st.number_input` に `key` を使用している箇所を確認
- [ ] `st.spinner` 使用箇所を確認

### アップグレード後チェック

- [ ] ID変換処理（01_IDを変換する.py）の動作確認
- [ ] ファイルアップロード機能（view_input_data.py）の動作確認
- [ ] Snowflakeコネクタ接続確認
