# pochilib アップグレード移行計画

## 目的

pochi-id-converter-repository の pochilib を 0.7.4 から 0.7.7 にアップグレードする。

## 背景

pochilib 0.7.7 は Streamlit 1.53.1 への対応（バグ修正含む）が主な変更点。
本アプリはLLM機能を使用していないため、0.7.5〜0.7.6 の LLM 関連破壊的変更の影響は受けない。
Streamlit の挙動変更（ウィジェット同一性）について動作確認を行えば安全にアップグレードできる。

## 要求事項

### 機能要件

1. **pyproject.toml の pochilib バージョン更新** (HIGH)
   - 対象: `/home/user/pochi-id-converter-repository/app/pyproject.toml`
   - 内容: `pochilib = "0.7.4"` → `pochilib = "0.7.7"` に変更
   - 自動修正: 可能

2. **poetry update の実行** (HIGH)
   - 対象: `/home/user/pochi-id-converter-repository/app/`
   - 内容: `poetry update pochilib` を実行してdependenciesを更新
   - 自動修正: 可能

3. **ウィジェット同一性変更の動作確認** (MEDIUM)
   - 対象: `st.multiselect` / `st.selectbox` / `st.number_input` で `key` を指定している箇所
   - 内容: `key` 指定時のウィジェット同一性変更（options/min/maxを同一性に含めない）による挙動変化を確認
   - 自動修正: 不可（動作確認が必要）

4. **st.spinner 使用箇所の動作確認** (LOW)
   - 対象: `st.spinner` を使用しているすべての箇所
   - 内容: 一時的な要素として扱われるようになった挙動変化を確認
   - 自動修正: 不可（動作確認が必要）

### 非機能要件

1. **後方互換性の維持**
   - ID変換機能の正常動作を維持する

2. **テスト戦略**
   - アップグレード後の手動動作確認（Snowflake接続、ファイルアップロード、ID変換処理）

3. **段階的移行**
   - pyproject.toml 修正 → poetry update → 動作確認の順で実施

## 受入基準

1. **REQ-001: pochilib バージョン更新**
   - テストコマンド: `poetry show pochilib`
   - 成功基準: バージョンが 0.7.7 と表示される

2. **REQ-002: Snowflake 接続確認**
   - テストコマンド: アプリ起動後、ID変換処理を実行
   - 成功基準: エラーなく完了する

3. **REQ-003: ファイルアップロード確認**
   - テストコマンド: アプリ起動後、ファイルアップロードを実行
   - 成功基準: エンコード自動判定が正常動作する

## 参照資料

- `reports/impact-report.json` - 詳細影響分析
- `reports/changelog-analysis.json` - 変更ログ解析
- `reports/pochilib-usage-map.json` - 使用状況マップ
- リリースノート: `/home/user/pochi-dp-developer-docs/skills/infra/pochilib-upgrade-analyst/release-note/`

## 推定工数

- **総工数**: 1〜2時間
- **自動修正**: 2件（pyproject.toml 修正、poetry update）
- **手動対応**: 2件（動作確認）

## リスク評価

- 🟢 総合リスクは LOW
- LLM関連の破壊的変更は本アプリに影響なし
- Streamlit挙動変更は軽微（バグ修正を含むため安定性が向上する面もある）

## アップグレード優先度

1. **pochi-id-converter-repository** (LOW)
   - 理由: LLM未使用、Streamlit挙動変更のみ確認が必要
   - 推定工数: 1〜2時間

## 推奨アプローチ

1. `pyproject.toml` の `pochilib` バージョンを `0.7.7` に更新
2. `poetry update pochilib` を実行
3. アプリを起動して手動動作確認
   - ID変換処理の動作確認
   - ファイルアップロードの動作確認
   - Snowflake接続の動作確認
4. 問題がなければアップグレード完了
