# pochilib-upgrade-analyst スキルアーキテクチャ

**作成日**: 2026-04-14  
**対象スキル**: `skills/infra/pochilib-upgrade-analyst/`  
**目的**: 起動から最終成果物までの処理・サブスキル・中間生成物・ロジックの全容をドキュメント化

---

## 1. スキル全体概要

`pochilib-upgrade-analyst` は **オーケストレーター型スキル** です。
自身は分析を行わず、3つのサブスキルを順番に起動して結果を統合します。

```
種別: プロンプト型スキル（SKILL.md で Claude が指示を解釈・実行）
カテゴリ: infra
サブスキル数: 3（pochilib-usage-scanner / pochilib-changelog-analyzer / pochilib-impact-detector）
```

> **オーケストレーターとは**  
> SKILL.md に記述された 6 ステップの指示を Claude が読み取り、
> 各サブスキルの SKILL.md を参照→Pythonスクリプトを実行→結果を統合する役割を担います。

---

## 2. 全体ワークフロー図

```
ユーザー
  │
  │ /pochilib-upgrade-analyst:run
  ▼
┌────────────────────────────────────────────┐
│    pochilib-upgrade-analyst (SKILL.md)     │
│    オーケストレーター                        │
│                                            │
│  Step 1-A ◀── AskUserQuestion              │
│    ├─ スキャン対象リポジトリ                │
│    └─ 目標バージョン                        │
│                                            │
│  Step 1-B                                  │
│    └─ pyproject.toml から現バージョン自動検出│
│                                            │
│  Step 2 ────────────────────────────────┐  │
│    pochilib-usage-scanner               │  │
│    (Pythonスクリプト実行)               │  │
│                                         │  │
│  Step 3 ────────────────────────────┐   │  │
│    pochilib-changelog-analyzer      │   │  │
│    (Pythonスクリプト実行)           │   │  │
│                                     │   │  │
│  Step 4 ──────────────────────┐     │   │  │
│    pochilib-impact-detector   │     │   │  │
│    (Pythonスクリプト実行)     │     │   │  │
│                               │     │   │  │
│  Step 5: 統合レポート生成     │     │   │  │
│  Step 6: ユーザーへ報告       │     │   │  │
└───────────────────────────────┘─────┘───┘──┘
                                │     │   │
    中間生成物の流れ             │     │   │
    ─────────────────────────── │ ────│───│──
                                ▼     ▼   ▼
                         [impact-report]  [usage-map]
                                     [changelog]
```

---

## 3. ステップ詳細

### Step 1-A: ヒアリング（AskUserQuestion）

Claude が `AskUserQuestion` を使って以下を確認:

| 質問 | 形式 | 補足 |
|---|---|---|
| スキャン対象リポジトリ | テキスト入力 | 複数可（カンマ区切り） |
| 目標バージョン | テキスト入力 | 例: 0.7.7 |

> **注意**: 優先度・デッドラインはヒアリングから削除済みです。  
> これらは Step 6 のレポート文章生成時にコンテキストとして使われるだけであり、  
> Step 2〜5 の Python スクリプト側の処理ロジック（severity 計算・マッチング・工数推定）には一切影響しません。

### Step 1-B: 現バージョン自動検出

各リポジトリの `app/pyproject.toml` または `pyproject.toml` を参照:

```
検索パターン:
  pochilib\s*=\s*["']([^"']+)["']
  pochilib\s*=\s*\{\s*version\s*=\s*["']([^"']+)["']
```

---

## 4. サブスキル1: pochilib-usage-scanner

### 役割
各アプリリポジトリの Python ファイルを **静的解析** して、pochilib の使用状況を把握する。

### 実行形式
```
種別: Pythonスクリプト型
エントリポイント: children/pochilib-usage-scanner/skill_entry.py
```

### 処理フロー

```
skill_entry.py::main()
  │
  ├─ check_environment()
  │    └─ POCHI_SKILL_ACTIVE 環境変数チェック（任意）
  │
  ├─ get_user_input(state)
  │    └─ 環境変数 POCHILIB_REPOSITORIES / POCHILIB_BASE_PATH
  │       なければ対話形式で入力
  │
  ├─ validate_repositories()
  │    └─ リポジトリパスの存在確認
  │
  ├─ scan_repositories()
  │    └─ for each リポジトリ:
  │         RepositoryScanner(repo_path).scan()
  │           ├─ Phase 1: get_python_files() → .py ファイル一覧
  │           │     ※ default_config.json の除外設定に従い __pycache__ / .venv / tests/ 等の
  │           │       標準ディレクトリを除いた全 .py ファイルを対象とする（ほぼ全ソースコード）
  │           ├─ Phase 2-4: for each ファイル:
  │           │     PatternDetector.detect_all(content, file_path)
  │           │       ├─ detect_imports()    → import文を検出・分類
  │           │       ├─ detect_method_calls() → API呼び出しを検出
  │           │       └─ detect_deprecated_usage() → 廃止パターンを検出
  │           └─ Phase 5: pyproject.toml からバージョン抽出
  │
  └─ generate_reports()
       ├─ VersionAnalyzer: バージョン整合性チェック
       └─ ReportBuilder.build_json_report() → pochilib-usage-map.json
```

### 検出パターン設定（detection_patterns.json）

#### インポートパターン
```
from pochilib import
from pochilib.llm import
from pochilib.snowflake import
from pochilib.gcp import
from pochilib.environment import
from pochilib.user_interface_support import
import pochilib
```

#### メソッドパターン（モジュール別）

| モジュール | 検出対象API |
|---|---|
| llm | `get_aoai_chat_model`, `get_vertexai_chat_model`, `get_bedrock_chat_model`, `LLMConfig`, `ChatMessage` 等 |
| snowflake | `generate_pochi_snowflake_connector`, `execute_query`, `SnowflakeConnector` 等 |
| gcp | `PochiStorage`, `PochiUserInfo`, `PochiProjectInfo`, `upload_file` 等 |
| environment | `get_environment`, `get_secret`, `load_env` 等 |
| user_interface_support | `create_sidebar`, `show_loading`, `show_error` 等 |

#### 廃止パターン（deprecated_patterns）

| パターン | 種別 | 重要度 | 代替 |
|---|---|---|---|
| `gemini-2.0-flash-001` | deprecated_model | warning | `gemini-2.0-flash` |
| `cost_check\s*\(` | removed_function | **critical** | なし（削除） |
| `gemini-1.5-pro-001` | deprecated_model | warning | `gemini-1.5-pro` |
| `gemini-1.5-flash-001` | deprecated_model | warning | `gemini-1.5-flash` |
| `old_connector\s*\(` | deprecated_function | warning | `generate_pochi_snowflake_connector()` |

### 出力ファイル

| ファイル | 内容 | 後工程での使用箇所 |
|---|---|---|
| `reports/pochilib-usage-map.json` | リポジトリ別 imports / method_calls / deprecated_usage / modules_usage の構造化データ | Step 4（impact-detector）の `_match_change_to_usage()` で `usage.module` / `usage.function` として参照。changelog の変更とアプリの使用箇所を突合する際の入力 |

---

## 5. サブスキル2: pochilib-changelog-analyzer

### 役割
スキル自身が管理するリリースノート（Markdown）を読み込み、バージョン別の変更内容を構造化JSONに変換する。

> **注意**: リリースノートは `pochi-common-func-repository` ではなく、  
> **スキル内の `release-note/` ディレクトリ**に格納されています。  
> `skills/infra/pochilib-upgrade-analyst/release-note/pochilib-0.7.2.md` 〜 `pochilib-0.7.7.md`
>
> **リリースノートの内容構成**:  
> 各ファイルは pochilib の変更だけでなく、依存する Streamlit のバージョンアップ詳細も含む複合ドキュメントです。  
> changelog-analyzer は `section_mappings.json` のセクション見出しマッチングで pochilib 関連の変更を抽出し、Streamlit 固有の詳細記述は `other_changes` として分類します。

### 実行形式
```
種別: Pythonスクリプト型
エントリポイント: children/pochilib-changelog-analyzer/skill_entry.py
```

### 処理フロー（5フェーズ）

```
skill_entry.py::main()
  │
  ├─ Phase 1: 環境チェック
  │    ├─ Python 3.10 以上確認
  │    └─ 設定ファイル読み込み（3ファイル）
  │         ├─ config/default_config.json
  │         ├─ config/section_mappings.json   ← セクション見出し→変更タイプ変換表
  │         └─ config/severity_rules.json     ← キーワード分類定義
  │
  ├─ Phase 2: 初期化とユーザー入力
  │    └─ 環境変数 CHANGELOG_INPUT_PATH（なければ対話入力）
  │         対象: skills/infra/pochilib-upgrade-analyst/release-note/ ディレクトリ
  │               ※ pochi-common-func-repository ではなくスキル内に同梱
  │
  ├─ Phase 3: ファイル読み込み
  │    └─ FileLoader.load()
  │         ├─ ディレクトリ指定時: .md ファイルを全件取得
  │         └─ ファイル名からバージョン番号を抽出（例: pochilib-0.7.1.md → "0.7.1"）
  │
  ├─ Phase 4: パースと分析
  │    ├─ for each ファイル:
  │    │     MarkdownParser.parse(content, version)
  │    │       ├─ _extract_sections(): ## / ### ヘッダーを検出してセクション分割
  │    │       ├─ _map_section(): section_mappings.json で section_type を決定
  │    │       └─ _parse_bullet_points(): 箇条書き → BulletPoint オブジェクト（階層構造）
  │    │
  │    ├─ ChangeAnalyzer.analyze(parsed)
  │    │    └─ 各変更テキストに対してキーワードスキャン:
  │    │         is_breaking   ← breaking_change_keywords に含まれるか
  │    │         is_deprecation← deprecation_keywords に含まれるか
  │    │         is_security   ← security_keywords に含まれるか
  │    │         → フラグ + section_type で severity を決定
  │    │
  │    └─ MigrationPathBuilder.build_paths(versions_data)
  │         └─ 全バージョンペアに対して:
  │               ├─ 中間バージョンの破壊的変更を集計
  │               ├─ 複雑度推定: simple / medium / complex
  │               └─ 移行ステップ・警告メッセージを生成
  │
  └─ Phase 5: レポート生成
       └─ ReportBuilder.build_json_report() → changelog-analysis.json
```

### セクション見出し → 変更タイプ変換（section_mappings.json）

| Markdown見出し | section_type | 代表的な変更内容 |
|---|---|---|
| `⚠️破壊的変更` | `breaking_changes` | 削除・互換性のない変更 |
| `🗑️廃止予定` | `deprecations` | 将来削除予定のAPI |
| `🎉新機能` | `new_features` | 機能追加 |
| `🐛バグ修正` | `bug_fixes` | バグ修正 |
| `🔒セキュリティ修正` | `security_fixes` | 脆弱性対応 |
| `📦依存関係更新` | `dependency_updates` | ライブラリバージョン変更 |
| `🔧内部改善` | `internal_changes` | リファクタリング等 |
| `📚ドキュメント` | `documentation` | ドキュメント更新 |
| `🧪テスト` | `tests` | テスト追加・修正 |

> 部分一致（絵文字除去後）でもマッチ。英語表記（`Breaking Changes` 等）にも対応。

### キーワード分類（severity_rules.json）

| キーワード分類 | 例 |
|---|---|
| breaking_change_keywords | "破壊的変更", "削除", "removed", "breaking change", "incompatible" |
| security_keywords | "脆弱性", "CVE", "security fix", "XSS", "SQL injection" |
| deprecation_keywords | "廃止予定", "deprecated", "will be removed" |
| dependency_keywords | "依存関係", "bump", "upgrade", "update" |

### 複雑度推定ロジック（MigrationPathBuilder）

「現バージョン → 目標バージョン」間の破壊的変更数を集計し、移行の大変さを 3 段階で格付けする。

```
breaking_count = 移行範囲内の破壊的変更数合計
deprecation_count = 廃止予定数合計

if breaking_count <= 0 and deprecation_count <= 2:
    → "simple"
elif breaking_count <= 2 and deprecation_count <= 5:
    → "medium"
else:
    → "complex"
```

**結果の出力先と用途**:
- 出力先: `changelog-analysis.json` の `migration_paths[].estimated_complexity`
- Step 4（impact-detector）が参照し、Step 5 の統合レポート（`upgrade-analysis-summary.md`）で「段階的移行推奨」等の判断材料として使用される

```mermaid
flowchart TD
    A[バージョン範囲の変更を集計] --> B{"breaking_count <= 0\nかつ deprecation_count <= 2 ?"}
    B -- Yes --> C["'simple'"]
    B -- No --> D{"breaking_count <= 2\nかつ deprecation_count <= 5 ?"}
    D -- Yes --> E["'medium'"]
    D -- No --> F["'complex'"]
```

### 出力ファイル

| ファイル | 内容 | 後工程での使用箇所 |
|---|---|---|
| `reports/changelog-analysis.json` | バージョン別変更の構造化データ + migration_paths | Step 4（impact-detector）の `_extract_changes()` でバージョン範囲内の変更一覧として使用。`migration_paths[].estimated_complexity` は Step 5 の統合レポートで移行難度の判断材料として使用 |

---

## 6. サブスキル3: pochilib-impact-detector

### 役割
Step2（usage-map）と Step3（changelog）の出力を突合して、各リポジトリへの影響を分析する。

### 実行形式
```
種別: Pythonスクリプト型
エントリポイント: children/pochilib-impact-detector/skill_entry.py
引数: --current-version / --target-version / --usage-map / --changelog / --output / --summary
```

### 処理フロー

```
skill_entry.py::main()
  │
  ├─ 入力ファイル読み込み
  │    ├─ pochilib-usage-map.json（Step2出力）
  │    └─ changelog-analysis.json（Step3出力）
  │
  ├─ SeverityCalculator() 初期化
  │    └─ severity_rules.yaml を読み込み
  │
  ├─ ImpactAnalyzer(severity_calculator).analyze()
  │    ├─ _extract_changes(): バージョン範囲（current → target）内の変更を抽出
  │    ├─ for each リポジトリ:
  │    │     _detect_repo_impacts()
  │    │       └─ for each 使用箇所 × 変更:
  │    │             _match_change_to_usage()
  │    │               ├─ モジュール名 / 関数名がマッチするか確認
  │    │               ├─ マッチした場合: SeverityCalculator.calculate_severity() を呼び出し
  │    │               └─ IMP-XXX形式の issue を生成
  │    │
  │    ├─ _generate_upgrade_priority(): severity 順ソート → rank 付け
  │    └─ _check_escalations(): エスカレーション条件チェック
  │
  └─ ReportGenerator()
       └─ generate_json_report() → impact-report.json
```

---

## 7. 判定ロジック詳細

### 7-1. 影響度（Severity）の決定フロー

`calculate_severity(change_type, code_pattern, context)` は以下の 3 段階で severity を決定します。

```
入力: change_type  （変更の種別。例: "removed_function"）
      code_pattern （実際のコードスニペット。カスタムルールのマッチングに使用）
      context      （補足情報。省略可）

  ↓
① カスタムルール（code_pattern を正規表現でマッチング）— 最優先
  ↓ マッチしなければ
② 変更タイプルール（change_type を辞書引き）
  ↓ 定義がなければ
③ デフォルト → MEDIUM 固定
```

```mermaid
flowchart TD
    A["SeverityCalculator.calculate_severity()"] --> B{"① custom_rules[] に\n正規表現マッチ?"}
    B -- マッチ --> C[そのルールの severity を返す]
    B -- マッチなし --> D{"② change_type_rules[] に\nchange_type が存在?"}
    D -- 存在する --> E[severity と auto_fixable を返す]
    D -- 存在しない --> F["③ デフォルト: 'MEDIUM' を返す"]
```

#### 戻り値フィールド

| フィールド | 常に含まれる | 内容 |
|---|---|---|
| `severity` | ✅ | `CRITICAL` / `HIGH` / `MEDIUM` / `LOW` |
| `reason` | ✅ | 判定理由の文字列 |
| `auto_fixable` | ✅ | `pochilib-auto-upgrader` に委託できるか |
| `priority` | ✅ | 数値（1=最高優先、4=最低） |
| `color` | ✅ | 🔴🟠🟡🟢（レポートの視覚表示） |
| `custom_rule` | カスタムルール時のみ | マッチしたルール名 |
| `migration` | カスタムルール時のみ | 自動修正レシピ（type / pattern / replacement 等） |

> **重要**: `migration` フィールドはカスタムルールにマッチした場合のみ付与されます。  
> `change_type_rules` にマッチした場合は含まれません。

#### ① カスタムルール — 現在定義されている 3 つ

| ルール名 | 正規表現 | severity | auto_fixable | 補足 |
|---|---|---|---|---|
| `gemini_2_0_flash_001_deprecation` | `gemini-2\.0-flash-001` | MEDIUM | true | v0.7.0 廃止予定、v0.8.0 削除。migration で `gemini-2.0-flash` への置換レシピ付き |
| `cost_check_removal` | `cost_check\(` | CRITICAL | false | v0.7.0 で完全削除済み。代替なし。手動対応が必要 |
| `timeout_in_seconds_default_change` | `get_vertexai_chat_model\([^)]*\)` | HIGH | true | デフォルト値が 300→120 に変更。明示的指定の追加で対応可 |

> **カスタムルールが優先される理由**: 同じ API でも個別事情（廃止時期・代替の有無・migration レシピ）が異なるため、  
> 汎用の `change_type_rules` より先に適用することで正確な情報を返せる。  
> 例: `gemini-2.0-flash-001` は `change_type_rules` でも `deprecated_model = MEDIUM` だが、  
> カスタムルールが先にマッチするため `migration`（置換レシピ）フィールドが結果に付与される。

#### ③ デフォルト — フェイルセーフ

新しい `change_type` が changelog に現れてもルール更新前に処理が止まらないよう、  
どのルールにも該当しない場合は `MEDIUM` を返します。

#### 具体例

**例1: `cost_check(` を含むコードを渡した場合**

```
calculate_severity(
    change_type="removed_function",
    code_pattern="result = cost_check(model, tokens)"
)
→ ① custom_rules: "cost_check\\(" がマッチ ✅
→ severity: CRITICAL / auto_fixable: false / migration: { type: "manual" }
→ ② ③ は実行されない
```

**例2: `get_vertexai_chat_model(...)` を含むコードを渡した場合**

```
calculate_severity(
    change_type="deprecated_model",
    code_pattern='model = get_vertexai_chat_model(model="gemini-1.5-pro")'
)
→ ① custom_rules: gemini_2_0_flash_001_deprecation → マッチしない
              cost_check_removal → マッチしない
              timeout_in_seconds_default_change: "get_vertexai_chat_model\([^)]*\)" → マッチ ✅
→ severity: HIGH（change_type_rules の deprecated_model = MEDIUM より高い）
→ auto_fixable: true / migration: { type: "parameter_addition", ... }
```

**例3: 未知の change_type が来た場合**

```
calculate_severity(
    change_type="new_unknown_change",
    code_pattern=None
)
→ ① code_pattern が None のためスキップ
→ ② change_type_rules に "new_unknown_change" が存在しない
→ ③ デフォルト: severity: MEDIUM / auto_fixable: false
```

### 7-2. 変更タイプ（change_type）一覧

変更タイプは **Markdownセクション見出し** から自動決定されます。

| change_type | Severity | auto_fixable | 説明 |
|---|---|---|---|
| `removed_function` | CRITICAL | false | 関数が完全削除された |
| `breaking_change` | CRITICAL | false | 互換性のない変更 |
| `default_value_change_with_behavior_impact` | HIGH | true | デフォルト値変更で動作が変わる |
| `deprecated_parameter` | MEDIUM | true | パラメータが廃止予定 |
| `dependency_update_compatible` | LOW | false | 互換性のある依存更新 |

### 7-3. auto_fixable フラグの意味

```
auto_fixable = true  → 後続スキル（pochilib-auto-upgrader）が機械的に修正可能
auto_fixable = false → 人間の判断・手動修正が必要
```

> **重要**: auto_fixable は「このスキルが自動修正する」という意味ではありません。
> 後続スキル `pochilib-auto-upgrader` への委託可否を宣言するフラグです。

### 7-4. auto_fix_patterns（自動修正パターン種別）

| パターン | 例 |
|---|---|
| `model_name_replacement` | モデルID文字列の置換（例: `hukakachi` → `pigeon-azure`） |
| `import_path_change` | インポートパスの変更 |
| `parameter_rename` | 引数名の変更 |
| `explicit_default_value` | デフォルト値を明示的に指定 |

### 7-5. カスタムルール（custom_rules）

特定の API 変更に対する個別ルール:

| ルール名 | 正規表現パターン | 対象 |
|---|---|---|
| `gemini_2_0_flash_001_deprecation` | `gemini-2\.0-flash-001` | Geminiモデル廃止 |
| `cost_check_removal` | `cost_check\s*\(` | cost_check 関数削除 |
| `timeout_in_seconds_default_change` | `generate_pochi_snowflake_connector` | タイムアウトデフォルト変更 |

### 7-6. アプリコードの修正要否判定ロジック

アプリコードの修正が必要かどうかは、以下の **3段階フィルタリング** で決まります。

```
ImpactAnalyzer._match_change_to_usage(change, usage, module, function, code_snippet)
  │
  ├─ ① モジュールマッチング（スキップ条件）
  │    change.module（影響を受けるモジュール）が
  │    usage.module（アプリが使用しているモジュール）に含まれないなら → None（修正不要）
  │
  ├─ ② 関数/クラスマッチング（スキップ条件）
  │    change.item（影響を受ける関数名）が
  │    usage.function にも code_snippet にも含まれないなら → None（修正不要）
  │
  └─ ③ 両方マッチした場合 → issue を生成（修正対象）
       └─ SeverityCalculator で severity / auto_fixable / migration を決定
```

```mermaid
flowchart TD
    A["_match_change_to_usage()"] --> B{"① モジュールマッチング\nchange.module が\nusage.module に含まれる?"}
    B -- No --> C["None（修正不要）\nnon_impacted_apis に記録"]
    B -- Yes --> D{"② 関数/クラスマッチング\nchange.item が\nusage.function or\ncode_snippet に含まれる?"}
    D -- No --> C
    D -- Yes --> E[issue を生成（修正対象）]
    E --> F["SeverityCalculator で\nseverity / auto_fixable / migration を決定"]
```

#### 修正要・不要の分岐まとめ

| 条件 | 判定 | 意味 |
|---|---|---|
| モジュールがマッチしない | **修正不要** | そのモジュール自体を使っていない |
| 関数名がコード内に存在しない | **修正不要** | 変更された関数を呼び出していない |
| モジュール・関数の両方がマッチ | **修正対象** | アプリが影響を受ける箇所を使用中 |

#### fix_required フィールドの値

`impact-report.json` の各 issue に含まれる `fix_required` の決定ルール:

| change_type | fix_required | 理由 |
|---|---|---|
| `removed_function` | **true** | 削除済み関数を呼び出しているため、コード修正は必須 |
| `breaking_change` | **true** | 互換性のない変更のため、動作保証のために修正必須 |
| `default_value_change_with_behavior_impact` | **true** | 動作が変わるため明示的な指定が必要（ただし auto_fixable=true） |
| `deprecated_parameter` | **false** | 今すぐ壊れるわけではないが将来削除予定（auto_fixable=true） |
| `dependency_update_compatible` | **false** | poetry update で自動解決。コード変更不要 |

#### non_impacted_apis（修正不要と判定された場合）

モジュール/関数マッチングで **マッチしなかった** 変更は `non_impacted_apis` として記録されます。
レポートに「影響なし」と明示されるため、スコープ外として安心して除外できます。

```
例: v0.7.0 で write_pandas_fixed が削除されたが、
    アプリが write_pandas_fixed を import / 呼び出していない
    → モジュール/関数マッチング で None を返す
    → non_impacted_apis に記録（"影響なし"）
```

#### 検証コマンドの自動生成

issue ごとに `verification` フィールドが付与され、修正後の確認コマンドが提示されます:

```python
# migration.type が "regex_replace" の場合:
verification = {
    "test_command": f"grep -rn '{pattern}' .",
    "success_criteria": "マッチ数が0であること"
}

# その他（手動判断が必要な場合）:
verification = {
    "test_command": "# 手動検証が必要",
    "success_criteria": "機能が正常に動作すること"
}
```

---

### 7-7. 工数推定ロジック（effort_estimation）

```yaml
CRITICAL: base=8.0h + per_issue=4.0h
HIGH:     base=2.0h + per_issue=1.0h
MEDIUM:   base=0.5h + per_issue=0.5h
LOW:      base=0.0h + per_issue=0.1h

auto_fixable_reduction: 0.9  # 自動修正可能な場合は工数を90%削減
```

---

### 7-8. 判定結果のデータフロー

`SeverityCalculator` が返す各値が、後続のどの処理・どのレポートフィールドに流れるかを示します。

```mermaid
flowchart TD
    MC["_match_change_to_usage()\n（マッチした場合のみ）"] --> SC["SeverityCalculator\n.calculate_severity()"]

    SC -->|"severity\n(CRITICAL/HIGH/MEDIUM/LOW)"| EE["effort_estimation\n工数計算\nbase + per_issue × 件数"]
    SC -->|"auto_fixable\n(true/false)"| AF["auto_fixable_reduction\n工数を 90% 削減\n（true のみ）"]
    SC -->|"auto_fixable (true)"| FP["auto_fix_patterns\n修正種別を付与\n(model_name_replacement 等)"]
    SC -->|"fix_required\n(change_type から決定)"| IS["issue オブジェクト生成\n(IMP-XXX)"]

    AF --> EE
    EE --> RG
    FP --> IS
    IS --> RG["ReportGenerator\ngenerate_json_report()"]

    MC2["_generate_upgrade_priority()\nseverity 順ソート → rank 付け"] --> RG
    MC3["_check_escalations()\nエスカレーション条件チェック"] --> RG

    RG -->|"impacts[].issues[]"| IR["impact-report.json"]
    RG -->|"summary.severity_counts\nsummary.auto_fixable_count"| IR
    RG -->|"priority_action_list[]"| IR
    IR --> S5["Step5: 統合レポート生成\n(upgrade-analysis-summary.md\n migration-overview.md)"]
```

> **読み方**: `SeverityCalculator` の戻り値（`severity` / `auto_fixable` / `fix_required`）は
> それぞれ独立したルートで後続処理に渡り、最終的に `ReportGenerator` で統合されて
> `impact-report.json` の各フィールドに格納される。

---

## 8. エスカレーションルール

以下の条件に該当する場合、ユーザーへのエスカレーションを推奨:

| 条件 | 優先度 | 内容 |
|---|---|---|
| CRITICAL 件数 >= 5 | urgent | 緊急対応が必要 |
| 影響リポジトリ数 >= 10 | high | 大規模影響 |
| security_fix を含む | high | セキュリティ対応の優先実施 |

---

## 9. 中間生成物とファイルスキーマ

### 中間生成物の流れ

```
[Step2出力]                [Step3出力]
pochilib-usage-map.json    changelog-analysis.json
        │                           │
        └─────────┬─────────────────┘
                  ▼
        [Step4入力] pochilib-impact-detector
                  │
                  ▼
          impact-report.json
                  │
                  ▼
        [Step5: 統合]
          upgrade-analysis-summary.md
          migration-overview.md        ← pochi-spec-initializer への入力
```

### pochilib-usage-map.json スキーマ

```json
{
  "repositories": {
    "<リポジトリ名>": {
      "path": "<リポジトリパス>",
      "pochilib_version": "<現バージョン>",
      "files_scanned": ["<ファイルパス>", ...],
      "imports": [
        { "statement": "...", "file": "...", "line": 10, "module_category": "llm" }
      ],
      "method_calls": [
        { "function": "get_aoai_chat_model", "file": "...", "line": 46, "module": "llm" }
      ],
      "deprecated_usage": [
        { "file": "...", "line": 80, "code": "...", "type": "removed_function", "severity": "critical" }
      ],
      "modules_usage": {
        "llm": { "import_count": 1, "call_count": 3, "files": ["..."] }
      }
    }
  }
}
```

### changelog-analysis.json スキーマ

```json
{
  "versions": {
    "0.7.0": {
      "version": "0.7.0",
      "breaking_changes": [ { "text": "...", "is_breaking": true } ],
      "deprecations": [...],
      "new_features": [...],
      "security_fixes": [...],
      "dependency_updates": [...],
      "metadata": {
        "total_changes": 12,
        "has_breaking_changes": true,
        "breaking_count": 5
      }
    }
  },
  "migration_paths": {
    "0.5.2_to_0.7.7": {
      "from_version": "0.5.2",
      "to_version": "0.7.7",
      "has_breaking_changes": true,
      "estimated_complexity": "complex",
      "recommended_path": ["0.5.2", "0.6.0", "0.7.0", "0.7.7"],
      "migration_steps": [...]
    }
  }
}
```

### impact-report.json スキーマ

```json
{
  "analysis_metadata": {
    "analysis_date": "...",
    "current_versions": { "<リポジトリ名>": "<バージョン>" },
    "target_version": "0.7.7"
  },
  "summary": {
    "total_repositories": 2,
    "severity_counts": { "CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 2 },
    "auto_fixable_count": 1,
    "manual_fix_required": 2
  },
  "impacts": [
    {
      "repository": "<名前>",
      "overall_severity": "HIGH",
      "issues": [
        {
          "issue_id": "IMP-001",
          "severity": "HIGH",
          "category": "deprecated_target_value",
          "file": "...",
          "line": 52,
          "fix_required": true,
          "auto_fixable": false,
          "fix_instruction": "..."
        }
      ]
    }
  ],
  "priority_action_list": [
    { "priority": 1, "repository": "...", "action": "...", "severity": "HIGH" }
  ]
}
```

---

## 10. 最終成果物ファイル一覧

| ファイル | 生成ステップ | 用途 |
|---|---|---|
| `reports/pochilib-usage-map.json` | Step 2 (usage-scanner) | 使用状況マップ（Step 4 の入力） |
| `reports/changelog-analysis.json` | Step 3 (changelog-analyzer) | 変更ログ構造化データ（Step 4 の入力） |
| `reports/impact-report.json` | Step 4 (impact-detector) | 影響分析詳細（Step 5 の入力） |
| `reports/upgrade-analysis-summary.md` | Step 5 (統合) | **最終成果物** — 総合サマリ（人間可読） |
| `reports/migration-overview.md` | Step 5 (統合) | **最終成果物** — pochi-spec-initializer 用入力資料 |

> **注意**: `*-summary.md`（`pochilib-usage-map-summary.md` / `changelog-analysis-summary.md` / `impact-summary.md`）は出力されません。  
> これらはパイプラインに不要な人間可読用補助ドキュメントであり、2026-04-15 の改修で出力対象から除外されました。

---

## 11. スキルファイル一覧

### オーケストレーター

| ファイル | 役割 |
|---|---|
| `skills/infra/pochilib-upgrade-analyst/skills/run/SKILL.md` | 6ステップのワークフロー定義（Claude が読んで実行） |
| `skills/infra/pochilib-upgrade-analyst/plugin.json` | スキルメタデータ（name/version/author/status） |

### pochilib-usage-scanner

| ファイル | 役割 |
|---|---|
| `children/pochilib-usage-scanner/skill_entry.py` | エントリポイント。環境チェック→入力→スキャン→レポート生成 |
| `children/pochilib-usage-scanner/core/scanner.py` | `RepositoryScanner`: ファイル収集・スキャン実行 |
| `children/pochilib-usage-scanner/core/pattern_detector.py` | `PatternDetector`: import/メソッド/廃止APIを一括検出 |
| `children/pochilib-usage-scanner/core/version_analyzer.py` | バージョン不整合検出 |
| `children/pochilib-usage-scanner/config/detection_patterns.json` | 検出パターン定義（import/method/deprecated） |
| `children/pochilib-usage-scanner/config/module_definitions.json` | pochilibモジュール定義 |
| `children/pochilib-usage-scanner/config/default_config.json` | デフォルト設定（除外ディレクトリ等） |

### pochilib-changelog-analyzer

| ファイル | 役割 |
|---|---|
| `children/pochilib-changelog-analyzer/skill_entry.py` | エントリポイント。5フェーズで処理 |
| `children/pochilib-changelog-analyzer/core/markdown_parser.py` | `MarkdownParser`: Markdown → `ParsedChangelog` |
| `children/pochilib-changelog-analyzer/core/change_analyzer.py` | `ChangeAnalyzer`: キーワードスキャンで severity 付与 |
| `children/pochilib-changelog-analyzer/core/migration_path_builder.py` | `MigrationPathBuilder`: 移行パス・複雑度を生成 |
| `children/pochilib-changelog-analyzer/core/file_loader.py` | `FileLoader`: Markdownファイル読み込み |
| `children/pochilib-changelog-analyzer/config/section_mappings.json` | Markdownセクション見出し → change_type 変換表 |
| `children/pochilib-changelog-analyzer/config/severity_rules.json` | キーワード分類定義 |

### pochilib-impact-detector

| ファイル | 役割 |
|---|---|
| `children/pochilib-impact-detector/skill_entry.py` | エントリポイント。argparseで入力受取→分析→レポート |
| `children/pochilib-impact-detector/src/severity_calculator.py` | `SeverityCalculator`: 2段階で影響度を判定 |
| `children/pochilib-impact-detector/src/impact_analyzer.py` | `ImpactAnalyzer`: usage_map × changelog を突合 |
| `children/pochilib-impact-detector/src/report_generator.py` | `ReportGenerator`: JSON + Markdown を出力 |
| `children/pochilib-impact-detector/config/severity_rules.yaml` | 変更タイプ→影響度・自動修正可否・工数の定義 |

---

## 12. 次のステップ（後続スキル）

このスキルの完了後、以下のスキルを実行することを推奨:

### 移行ガイド生成
```
/pochilib-migration-generator
```
`impact-report.json` を元に、アプリ別の詳細移行ガイドを生成します。

### 自動バージョン更新
```
/pochilib-auto-upgrader
```
`pyproject.toml` の pochilib バージョン自動書き換えと `poetry update` を実行します。

### 移行仕様書生成
```
pochi-spec-initializer を起動し、migration-overview.md を資料として仕様書を作成
```
`migration-overview.md` を入力として、移行作業の仕様書を生成します。
