# Pochilib 変更ログ解析レポート

**解析日時**: 2026-04-14  
**データソース**: pochi-common-func-repository (git log)  
**解析バージョン範囲**: v0.5.2 → v0.7.7  
**⚠️注意**: v0.7.7はgit上の最新タグ(v0.7.1)を超えているため、v0.7.7の変更内容は現時点で未確認

---

## バージョン別変更サマリ

### v0.6.0 ― Snowflake接続改善 + Custom Job廃止

| カテゴリ | 件数 | 主な内容 |
|---|---|---|
| 破壊的変更 | 1 | Snowflake key-pair認証への変更 |
| 新機能 | 3 | cache_column_metadata, Snowflake key-pair, get_secret改善 |
| 削除 | 3 | `PochiEnvironment.environment_kind='job'`, `initiate_for_custom_job()`, `PochiUserInfo._jwt_audience_id` |
| 依存更新 | 1 | streamlit 1.40.0 → 1.41.0 |

**重要削除**: カスタムジョブ（Vertex AI Custom Job）関連の全機能が削除されました。

---

### v0.6.1 ― Snowflake Connector 更新

| カテゴリ | 件数 | 主な内容 |
|---|---|---|
| 依存更新 | 1 | snowflake-connector-python ^3.7.1 → ^3.15.0 |

---

### v0.6.3 ― dogharness改善 + VertexAI追加

| カテゴリ | 件数 | 主な内容 |
|---|---|---|
| 新機能 | 4 | シンdogharness, VertexAI chat, VertexAI embedding, AOAI embedding |
| バグ修正 | 2 | gallery_back_button URLドメイン対応, ホスト名取得修正 |

---

### v0.7.0 ― **重要: 多数の破壊的変更**

| カテゴリ | 件数 | 主な内容 |
|---|---|---|
| 🔴 破壊的変更 | 5 | write_pandas_fixed削除, cost_check削除, target値変更, タイムアウトデフォルト変更, snowflake脆弱性対処 |
| 廃止予定 | 2 | hukakachi target, additional_headers |
| 新機能 | 3 | Claude (VertexAI), LLMログ, コストラベル |
| セキュリティ修正 | 1 | snowflake-connector-python脆弱性 |
| 依存更新 | 5 | langchain系全更新 |

#### 破壊的変更の詳細

| ID | 変更内容 | 影響するAPI | 移行方法 |
|---|---|---|---|
| BC-0.7.0-01 | `write_pandas_fixed` 削除 | `write_pandas_fixed()` | `snowflake.connector.pandas_tools.write_pandas` を使用 |
| BC-0.7.0-02 | `cost_check` 削除 | `cost_check()` | 呼び出し箇所をコードから削除 |
| BC-0.7.0-03 | `get_aoai_chat_model` の `target` デフォルト値変更 | `get_aoai_chat_model(target=...)` | `target='hukakachi'` を明示指定、または `'pigeon-azure'` に変更 |
| BC-0.7.0-04 | Snowflakeタイムアウトデフォルト値 → None | `generate_pochi_snowflake_connector` | タイムアウト依存なら明示的に指定 |
| BC-0.7.0-05 | snowflake脆弱性対処に伴うコード削除 | 内部実装 | 対応不要（内部実装のみ） |

---

### v0.7.1 ― streamlit 更新

| カテゴリ | 件数 | 主な内容 |
|---|---|---|
| 依存更新 | 1 | streamlit → 1.46.1 |

---

## 移行パスの推奨

### pochi-llm-code-refactor-repository（v0.5.2 → v0.7.7）

```
v0.5.2 → v0.6.0 → v0.6.1 → v0.6.3 → v0.7.0 → v0.7.1 → v0.7.7
```

**複雑度**: 高（破壊的変更が多数含まれる）  
**必須対応項目**:
1. カスタムジョブ関連コードの確認・削除
2. `write_pandas_fixed` 使用箇所の置き換え（本アプリでは使用なし）
3. `cost_check` 使用箇所の削除（本アプリでは使用なし）
4. `get_aoai_chat_model` の `target` パラメータ確認（`target='hukakachi'` を使用中）
5. snowflake-connector-python 3.15.0 以上への更新

### pochi-open-predictor-repository（v0.7.6 → v0.7.7）

```
v0.7.6 → v0.7.7
```

**複雑度**: 低（1マイナーバージョンアップ）  
⚠️ **注意**: v0.7.7のリリースノートが未確認のため、インストール可能かどうか事前に確認が必要

---

## ⚠️ 重要アラート

> **v0.7.7は未確認バージョン**: pochi-common-func-repositoryのgit上の最新安定タグはv0.7.1です。  
> v0.7.7はプライベートPyPI上に存在する可能性はありますが、git履歴では確認できません。  
> `poetry add pochilib==0.7.7` を実行する前に、バージョンの存在確認を推奨します。
