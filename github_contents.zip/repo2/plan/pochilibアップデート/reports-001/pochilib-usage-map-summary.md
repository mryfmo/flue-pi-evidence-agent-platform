# Pochilib 使用状況スキャンレポート

**スキャン日時**: 2026-04-14  
**スキャン対象**: 2リポジトリ  
**目標バージョン**: v0.7.7

---

## リポジトリ別サマリ

| リポジトリ | 現バージョン | アップグレード要否 | 使用モジュール | 廃止API |
|---|---|---|---|---|
| pochi-open-predictor-repository | 0.7.6 | ✅ 必要（マイナー） | environment, snowflake, user_interface_support | なし |
| pochi-llm-code-refactor-repository | 0.5.2 | ⚠️ 必要（大幅変更） | llm, gcp, user_interface_support | 1件 |

---

## モジュール使用状況（全体）

| モジュール | 使用リポジトリ数 | インポート数 | 主な使用シンボル |
|---|---|---|---|
| `environment` / `PochiEnvironment` | 2 | 5 | PochiEnvironment |
| `user_interface_support` | 2 | 5 | generate_gallery_back_button |
| `snowflake` | 1 | 5 | generate_pochi_snowflake_connector |
| `gcp` / `PochiStorage` | 1 | 2 | PochiStorage, _utilities |
| `llm` | 1 | 1 | get_aoai_chat_model |
| `PochiUserInfo` | 2 | 3 | PochiUserInfo |

---

## 廃止予定API使用の警告

### ⚠️ pochi-llm-code-refactor-repository

| ファイル | 行 | 現在の使用 | 推奨移行先 |
|---|---|---|---|
| `📝SQLリファクタリングGPT.py` | 52 | `target='hukakachi'` | `target='pigeon-azure'` |

**詳細**: `get_aoai_chat_model` の `target` パラメータのデフォルト値が v0.7.0 で `"hukakachi"` から `"pigeon-azure"` に変更されました。
明示的に `target='hukakachi'` を指定しているため現在は動作しますが、付加価値基盤（hukakachi）が将来的に廃止される際に影響を受けます。

---

## アップグレード優先順位

### 1位: `pochi-llm-code-refactor-repository`（優先度: 高）
- **理由**: v0.5.2からv0.7.7への大幅なアップグレード。Custom Job関連の削除、`write_pandas_fixed`の削除、`_domain_prefix`の削除、LLM APIの変更など多数の破壊的変更が含まれる
- **使用API**: `PochiStorage`, `PochiUserInfo`, `get_aoai_chat_model`, `_utilities`, `generate_gallery_back_button`

### 2位: `pochi-open-predictor-repository`（優先度: 低）
- **理由**: v0.7.6からv0.7.7への1マイナーバージョンアップ。後方互換性が保たれている可能性が高い
- **使用API**: `PochiEnvironment`, `PochiUserInfo`, `generate_pochi_snowflake_connector`, `generate_gallery_back_button`

---

## バージョン分布の警告

2リポジトリ間でpochilibバージョンに **2マイナーバージョン以上の乖離** があります。
- 最新: 0.7.6（pochi-open-predictor）
- 最古: 0.5.2（pochi-llm-code-refactor）
- 乖離: 約2マイナーバージョン + 4パッチバージョン
