# Pochilib アップグレード分析 総合サマリレポート

**実施日**: 2026-04-14  
**目標バージョン**: v0.7.7  
**優先度**: 高（今週中）  
**対象リポジトリ**: 2リポジトリ（ランダム選定）

---

## エグゼクティブサマリ

| 指標 | 値 |
|---|---|
| 分析対象 | 2リポジトリ |
| アップグレード要否 | 全2件が対象 |
| 最高影響度 | 🟠 HIGH（CRITICAL件数: 0） |
| 手動修正必要箇所 | 2箇所 |
| 自動修正可能 | 1件（poetry update で解決） |
| **今週中の作業見込み** | **pochi-llm-code-refactor: 1〜2日、pochi-open-predictor: 数時間** |

**全体的な判断**: CRITICALな問題はなく、今週中の対応は十分可能です。ただし `pochi-llm-code-refactor-repository` は `target='hukakachi'` のコード修正と接続先変更の確認が必要なため、関係者への事前確認を推奨します。

---

## リポジトリ別結果

### 1. pochi-llm-code-refactor-repository

| 項目 | 値 |
|---|---|
| 現バージョン | 0.5.2 |
| 目標バージョン | 0.7.7 |
| バージョンギャップ | 大（2マイナーバージョン） |
| 総合影響度 | 🟠 **HIGH** |
| 手動修正必要 | 1件（IMP-001: target='hukakachi'） |
| 要確認 | 1件（IMP-003: _utilities使用） |
| 自動解決 | 2件（IMP-002, IMP-004） |

**必須対応**: `get_aoai_chat_model` の `target='hukakachi'` を `'pigeon-azure'` に変更

### 2. pochi-open-predictor-repository

| 項目 | 値 |
|---|---|
| 現バージョン | 0.7.6 |
| 目標バージョン | 0.7.7 |
| バージョンギャップ | 小（1パッチバージョン） |
| 総合影響度 | 🟢 **LOW** |
| 手動修正必要 | 0件 |
| 要確認 | 1件（IMP-005: v0.7.7の存在確認） |

**必須確認**: v0.7.7 がプライベートPyPIに存在するかどうかの事前確認

---

## 変更ログハイライト（v0.5.2 → v0.7.7）

### 破壊的変更（v0.6.0〜v0.7.0で発生）

| バージョン | 変更内容 | pochi-llm-code-refactor への影響 |
|---|---|---|
| v0.6.0 | Custom Job関連機能の削除 | ✅ 影響なし（使用していない） |
| v0.6.0 | Snowflake key-pair認証への変更 | ✅ 影響なし（使用していない） |
| v0.6.1 | snowflake-connector-python ^3.15.0 | ✅ 自動解決（poetry update） |
| v0.7.0 | `write_pandas_fixed` 削除 | ✅ 影響なし（使用していない） |
| v0.7.0 | `cost_check` 削除 | ✅ 影響なし（使用していない） |
| v0.7.0 | `get_aoai_chat_model` targetデフォルト変更 | ⚠️ **要対応**（`target='hukakachi'` を明示使用中） |
| v0.7.1 | streamlit 1.46.1 | ✅ 自動解決（poetry update） |

---

## 推奨アクション（今週中の対応）

### Step 1（今日〜明日）: コード修正
```
対象: pochi-llm-code-refactor-repository
ファイル: app/📝SQLリファクタリングGPT.py:46行目付近
変更: TARGET = "hukakachi" → TARGET = "pigeon-azure"
確認事項: pigeon-azure の接続設定（シークレット）が本番環境に設定済みか
```

### Step 2（コード修正後）: バージョン更新
```
cd /home/user/pochi-llm-code-refactor-repository/app
# pyproject.toml の pochilib = "0.5.2" → "0.7.7" に変更
poetry update pochilib
# 動作確認: streamlit run, _utilities の動作テスト
```

### Step 3（並行）: v0.7.7の存在確認
```
cd /home/user/pochi-open-predictor-repository/app
poetry add pochilib==0.7.7  # バージョン存在確認
# 成功したら pyproject.toml を更新
```

---

## ⚠️ 重要なリスク

1. **v0.7.7は未確認バージョン**: git上の最新タグはv0.7.1。v0.7.7がPyPIに存在しない場合、目標バージョンの再設定が必要。

2. **pigeon-azure切り替えの影響**: `hukakachi` から `pigeon-azure` への切り替えは、Azure側の接続先・シークレット設定の変更を伴う場合があります。インフラチームへの確認を推奨。

---

## 出力ファイル一覧

| ファイル | 内容 |
|---|---|
| `pochilib-usage-map.json` | 各リポジトリのpochilib使用箇所詳細（機械可読） |
| `pochilib-usage-map-summary.md` | 使用状況サマリ（人間可読） |
| `changelog-analysis.json` | v0.5.2〜v0.7.7の変更ログ構造化データ |
| `changelog-analysis-summary.md` | 変更ログサマリ（人間可読） |
| `impact-report.json` | 影響分析レポート詳細（機械可読） |
| `impact-summary.md` | 影響分析サマリ（人間可読） |
| `upgrade-analysis-summary.md` | このファイル（総合サマリ） |
| `migration-overview.md` | pochi-spec-initializer 用入力資料 |
