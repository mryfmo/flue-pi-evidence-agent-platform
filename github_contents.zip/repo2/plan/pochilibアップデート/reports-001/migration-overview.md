# Pochilib移行概要 - pochi-spec-initializer用入力資料

**作成日**: 2026-04-14  
**作成スキル**: pochilib-upgrade-analyst  
**目的**: pochi-spec-initializer / pochilib-migration-generator への入力資料

---

## 移行概要

### 基本情報

| 項目 | 値 |
|---|---|
| 移行元 | pochilib 0.5.2 / 0.7.6 |
| 移行先 | pochilib 0.7.7 |
| 対象リポジトリ数 | 2 |
| 優先度 | 高（今週中） |

---

## アプリ別移行仕様

### アプリ1: pochi-llm-code-refactor-repository

**目的**: SQL最適化・リファクタリングのためのLLMチャットアプリ  
**リポジトリパス**: `/home/user/pochi-llm-code-refactor-repository/app`  
**現バージョン**: 0.5.2 → **目標**: 0.7.7

#### 必須変更項目

| # | 変更カテゴリ | ファイル | 変更内容 | 難易度 |
|---|---|---|---|---|
| 1 | コード修正（必須） | `app/📝SQLリファクタリングGPT.py` L46 | `TARGET = "hukakachi"` → `"pigeon-azure"` | 低 |
| 2 | 依存更新（自動） | `app/pyproject.toml` | `pochilib = "0.5.2"` → `"0.7.7"` | 低 |
| 3 | 動作確認（必須） | `app/📝SQLリファクタリングGPT.py` L41 | `_utilities` の使用箇所を動作確認 | 中 |
| 4 | 動作確認（推奨） | Streamlit UI全般 | streamlit 1.40.0→1.46.1の変更影響を確認 | 低 |

#### 変更が不要な項目（影響なし）

- `write_pandas_fixed`: 使用なし
- `cost_check`: 使用なし
- Custom Job関連: 使用なし
- `generate_gallery_back_button`: 後方互換性あり
- `PochiStorage.upload_from_string()`: APIに変更なし
- `PochiUserInfo`: APIに変更なし

#### 接続先変更に関する注意

`target='pigeon-azure'` への変更は以下を前提とします:
- Azure OpenAIのエンドポイントが `pigeon-azure` 向けに設定済みであること
- 必要なシークレット（APIキー等）がSecret Managerに登録済みであること
- 付加価値基盤（hukakachi）からpigeon-azureへの切り替えについてインフラチームと合意済みであること

---

### アプリ2: pochi-open-predictor-repository

**目的**: 機械学習を使用した予測モデルのアプリ  
**リポジトリパス**: `/home/user/pochi-open-predictor-repository/app`  
**現バージョン**: 0.7.6 → **目標**: 0.7.7

#### 必須変更項目

| # | 変更カテゴリ | ファイル | 変更内容 | 難易度 |
|---|---|---|---|---|
| 1 | 事前確認（必須） | — | v0.7.7がプライベートPyPIに存在するか確認 | 低 |
| 2 | 依存更新（自動） | `app/pyproject.toml` | `pochilib = "0.7.6"` → `"0.7.7"` | 低 |

#### 変更が不要な項目（影響なし）

- コードの変更は不要（v0.7.6で既に最新API対応済み）
- 使用中のAPI（PochiEnvironment, PochiUserInfo, generate_pochi_snowflake_connector, generate_gallery_back_button）はすべて後方互換性あり

---

## pochi-spec-initializer への入力サマリ

```yaml
migration_request:
  deadline: "今週中"
  priority: "高"
  repositories:
    - name: "pochi-llm-code-refactor-repository"
      path: "/home/user/pochi-llm-code-refactor-repository/app"
      from_version: "0.5.2"
      to_version: "0.7.7"
      manual_fixes:
        - file: "app/📝SQLリファクタリングGPT.py"
          line: 46
          change: "TARGET変数を'hukakachi'から'pigeon-azure'に変更"
          risk: "接続先変更のため要事前確認"
      auto_fixes:
        - "poetry update pochilib"
      verification:
        - "pigeon-azure接続設定確認"
        - "_utilities使用箇所の動作テスト"
        - "Streamlit UI動作確認"
        
    - name: "pochi-open-predictor-repository"
      path: "/home/user/pochi-open-predictor-repository/app"
      from_version: "0.7.6"
      to_version: "0.7.7"
      manual_fixes: []
      auto_fixes:
        - "pyproject.toml バージョン更新"
        - "poetry update pochilib"
      verification:
        - "v0.7.7 PyPI存在確認"
        - "poetry install の成功確認"
```

---

## 次のステップ

このレポートを基に以下のスキルを実行することを推奨します:

### 移行ガイド生成
```
/pochilib-migration-generator
```
`impact-report.json` を元に、アプリ別の詳細移行ガイドを生成します。

### 自動バージョン更新
```
/pochilib-auto-upgrader
```
pyproject.toml の pochilib バージョン自動書き換えと `poetry update` を実行します。
