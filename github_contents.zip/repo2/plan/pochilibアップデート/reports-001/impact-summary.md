# Pochilib アップグレード影響分析レポート

**分析日時**: 2026-04-14  
**目標バージョン**: v0.7.7  
**優先度**: 高（今週中）

---

## 全体サマリ

| 項目 | 値 |
|---|---|
| 分析リポジトリ数 | 2 |
| 影響ありリポジトリ数 | 2 |
| 🔴 CRITICAL | 0件 |
| 🟠 HIGH | 1件 |
| 🟡 MEDIUM | 2件 |
| 🟢 LOW | 2件 |
| 自動修正可能 | 1件 |
| 手動修正必要 | 2件 |

---

## リポジトリ別影響サマリ

### pochi-llm-code-refactor-repository（v0.5.2 → v0.7.7）

**総合影響度**: 🟠 **HIGH**  
**アップグレード複雑度**: 高（v0.5.2は2マイナーバージョン遅れ）

| Issue | 影響度 | 対象ファイル | 内容 | 自動修正 |
|---|---|---|---|---|
| IMP-001 | 🟠 HIGH | `📝SQLリファクタリングGPT.py:52` | `target='hukakachi'` を廃止 | ❌ 手動 |
| IMP-002 | 🟡 MEDIUM | `pyproject.toml` | snowflake-connector-python 3.15.0以上に更新必要 | ✅ 自動 |
| IMP-003 | 🟡 MEDIUM | `📝SQLリファクタリングGPT.py:41` | `_utilities` (プライベートAPI) 直接使用の確認 | ❌ 要確認 |
| IMP-004 | 🟢 LOW | Streamlit | 1.40.0 → 1.46.1への大幅更新。UI動作確認が必要 | ✅ 自動 |

#### 修正が必要なコード（IMP-001）

```python
# 現在のコード（📝SQLリファクタリングGPT.py:46-52）
def init_chat_model():
    OPENAI_API_VERSION = "2024-06-01"
    CHAT_DEPLOYMENT_NAME = "gpt-4o"
    TARGET = "hukakachi"  # ← 廃止予定
    MODEL_SS_KEY = "chat_model"
    get_aoai_chat_model(
        api_version=OPENAI_API_VERSION, deployment=CHAT_DEPLOYMENT_NAME, target=TARGET, key=MODEL_SS_KEY
    )
```

```python
# 修正後
def init_chat_model():
    OPENAI_API_VERSION = "2024-06-01"
    CHAT_DEPLOYMENT_NAME = "gpt-4o"
    TARGET = "pigeon-azure"  # ← pigeon-azureに変更
    MODEL_SS_KEY = "chat_model"
    get_aoai_chat_model(
        api_version=OPENAI_API_VERSION, deployment=CHAT_DEPLOYMENT_NAME, target=TARGET, key=MODEL_SS_KEY
    )
```

> ⚠️ **注意**: `pigeon-azure` への切り替えには、Azure側の接続設定（シークレット等）が正しく設定されていることの確認が必要です。

---

### pochi-open-predictor-repository（v0.7.6 → v0.7.7）

**総合影響度**: 🟢 **LOW**  
**アップグレード複雑度**: 低（1パッチバージョンアップ）

| Issue | 影響度 | 対象ファイル | 内容 | 自動修正 |
|---|---|---|---|---|
| IMP-005 | 🟢 LOW | `pyproject.toml` | v0.7.7の存在確認が必要 | ❌ 要確認 |

> ⚠️ **v0.7.7の存在確認**: pochi-common-func-repositoryのgitタグ上の最新版はv0.7.1です。v0.7.7はプライベートPyPIに存在する可能性はありますが、事前に `poetry add pochilib==0.7.7` で確認することを推奨します。

---

## 推奨アクション（優先順位順）

### 優先度1: pochi-llm-code-refactor-repository の手動修正

```bash
# 1. get_aoai_chat_model の target 修正
# 📝SQLリファクタリングGPT.py の TARGET = "hukakachi" を "pigeon-azure" に変更

# 2. pyproject.toml のバージョン更新
cd /home/user/pochi-llm-code-refactor-repository/app
# pyproject.toml の pochilib = "0.5.2" → "0.7.7" に変更
poetry update pochilib

# 3. 動作確認
# - _utilities 使用箇所の動作テスト
# - Streamlit UIの確認（1.46.1の変更点に注意）
```

### 優先度2: pochi-open-predictor-repository のバージョン確認

```bash
# v0.7.7 の存在確認
cd /home/user/pochi-open-predictor-repository/app
poetry add pochilib==0.7.7
# ↑成功すれば pyproject.toml を更新して poetry lock
```

---

## 影響なしと判定されたAPI

| API | 理由 |
|---|---|
| `write_pandas_fixed` | 2リポジトリともに使用なし |
| `cost_check` | 2リポジトリともに使用なし |
| `PochiEnvironment.environment_kind='job'` | 2リポジトリともに使用なし |
| `_domain_prefix` | 2リポジトリともに使用なし |
| pochi-open-predictor の全API | v0.7.6で既に対応済み |
