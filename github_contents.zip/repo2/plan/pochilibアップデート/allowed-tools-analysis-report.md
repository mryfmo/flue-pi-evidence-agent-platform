# allowed-tools 設定分析レポート

**作成日**: 2026-05-13  
**対象スキル**: pochilib-update-analyst（+ 子スキル3）/ pochi-coding-agent / pochi-spec-initializer / test系3スキル（e2e除く）  
**分析者**: ryota-suzuki-xf（Claude Code との対話による分析）

---

## 1. 分析の背景と目的

`security-risk-analysis-pochilib-update-analyst.md`（第2・3回分析）にて、SKILL.md の `allowed-tools` フロントマターフィールドが「プロンプト指示」ではなく「Claude Code ハーネス（実行環境）レベルで技術的に強制される制御機構」であることが確認された。

> `allowed-tools` はLLMへの指示ではなく、**Claude Codeハーネスレベルで実装**されており、LLMの判断を経由せずブロックするため、プロンプトインジェクションや確率的誤動作の影響を受けない。

現在、対象スキル全てで `allowed-tools` が未設定であり、プロンプトインジェクション経由の誤動作リスクが残存している。本レポートでは各スキルのSKILL.mdを精査し、**最小権限原則**に基づく推奨設定値を決定する。

---

## 2. 調査方法

各スキルの `skills/run/SKILL.md` を読み込み、以下を確認した：

- フロントマターの現在の内容（allowed-toolsフィールドの有無）
- ワークフロー全体で使用されるツール（ステップ記述・Tool Constraintsセクション）
- 設計意図として「禁止」とされているツール

公式ドキュメント `claude-code-guide/official/skills.md`（289〜300行目）で `allowed-tools` の構文を確認済み。

---

## 3. 対象スキル一覧

| # | スキル | SKILL.mdパス |
|---|---|---|
| 1 | pochilib-update-analyst（親） | `skills/infra/pochilib-update-analyst/skills/run/SKILL.md` |
| 2 | pochilib-changelog-analyzer（子） | `skills/infra/pochilib-update-analyst/children/pochilib-changelog-analyzer/skills/run/SKILL.md` |
| 3 | pochilib-usage-scanner（子） | `skills/infra/pochilib-update-analyst/children/pochilib-usage-scanner/skills/run/SKILL.md` |
| 4 | pochilib-impact-detector（子） | `skills/infra/pochilib-update-analyst/children/pochilib-impact-detector/skills/run/SKILL.md` |
| 5 | pochi-coding-agent | `skills/spec/pochi-coding-agent/skills/run/SKILL.md` |
| 6 | pochi-spec-initializer | `skills/spec/pochi-spec-initializer/skills/run/SKILL.md` |
| 7 | pochi-unit-test-generator | `skills/test/pochi-unit-test-generator/skills/run/SKILL.md` |
| 8 | pochi-tdd-test-generator | `skills/test/pochi-tdd-test-generator/skills/run/SKILL.md` |
| 9 | pochi-test-orchestrator | `skills/test/pochi-test-orchestrator/skills/run/SKILL.md` |

---

## 4. 各スキルの詳細分析

---

### 4-1. pochilib-update-analyst（親スキル）

#### 現在のフロントマター

```yaml
---
name: pochilib-update-analyst
description: >-
  pochilibアップデートの影響分析を統括し、3つのSkillを連携させて
  包括的な影響分析レポートを生成します。
  「pochilibアップグレード分析を開始」「pochilibバージョンアップ影響調査」などで起動。
---
```

#### 使用ツールの根拠

| ツール | 使用箇所 | 根拠 |
|---|---|---|
| `Glob` | Step 0-A: リリースノートファイルの存在確認 | `**/fetch_streamlit_release_notes.py` の探索 |
| `Read` | Step 0-A/0-B: リリースノート読み込み、Step 1-B: pyproject.toml読み込み | ワークフロー内に明示 |
| `Write` | Step 5: 統合レポート出力 | ワークフロー内に明示 |
| `AskUserQuestion` | Step 1-A: スキャン対象・目標バージョンのヒアリング | ワークフロー内に明示 |
**使用しないツール（技術的にブロックすべき）**: `Bash`（外部コマンド実行・最大リスク）、`Edit`、`Agent`、`TaskCreate`

> **補足（Skillについて）**: 子スキル（pochilib-usage-scanner等）の起動はSKILL.mdのプロンプト指示で制御されるものであり、`allowed-tools` の制御対象ではない。公式ドキュメント（skills.md 292行目）によると、`allowed-tools` はファイル操作・シェル実行などのハードウェアアクセス系ツールを対象とする。`Skill` を `allowed-tools` に書いても無視される。

#### 推奨 allowed-tools

```yaml
allowed-tools: Read, Write, Glob, AskUserQuestion
```

> **補足**: セキュリティリスク分析レポートのSection 9.2では `Skill` を含む設定値が提案されていたが、`Skill` は `allowed-tools` の有効な指定対象ではないため除外した。

---

### 4-2. pochilib-changelog-analyzer（子スキル）

#### 現在のフロントマター

```yaml
---
skill_id: pochilib-changelog-analyzer
name: pochilib-changelog-analyzer
title: Pochilib Changelog Analyzer
version: 1.0.0
description: >-
  ローカルに保存されたリリースノート（Markdownファイル）を解析し、...
---
```

#### 使用ツールの根拠

| ツール | 使用箇所 | 根拠 |
|---|---|---|
| `Read` | STEP 2: リリースノートMDファイルの読み込み | ワークフロー内に明示（read_file） |
| `Glob` | STEP 2: ディレクトリ内の .md ファイル列挙 | ワークフロー内に明示（file_search） |
| `Write` | STEP 5: changelog-analysis.json / changelog-analysis-summary.md 生成 | ワークフロー内に明示（create_file） |
| `AskUserQuestion` | STEP 1: リリースノートパス・APP_REPOSITORY_PATHヒアリング | ワークフロー内に明示 |

**使用しないツール**: `Bash`、`Edit`、`Grep`、`Skill`、`Agent`

設計原則として「外部接続なし（Snowflake、GCS、LLM APIへのアクセスなし）・静的解析のみ」が明記されており、Grep不要（ファイル列挙はGlobで完結）。

#### 推奨 allowed-tools

```yaml
allowed-tools: Read, Write, Glob, AskUserQuestion
```

---

### 4-3. pochilib-usage-scanner（子スキル）

#### 現在のフロントマター

```yaml
---
skill_id: pochilib-usage-scanner
name: pochilib-usage-scanner
version: 1.0.0
description: >-
  複数のStreamlitアプリリポジトリをスキャンして、Pochilibモジュールの使用状況を把握し...
---
```

#### 使用ツールの根拠

| ツール | 使用箇所 | 根拠 |
|---|---|---|
| `Read` | STEP 2-1: pyproject.toml 読み込み | ワークフロー内に明示（read_file） |
| `Grep` | STEP 2-2: インポートパターン・廃止API・メソッド呼び出しパターンのスキャン | ワークフロー内に明示（grep_search） |
| `Glob` | STEP 2-2 前処理: Pythonファイルの検索 | STEP 2-2の全ファイルスキャンに必要 |
| `Write` | STEP 4: pochilib-usage-map.json / summary.md 生成 | ワークフロー内に明示（create_file） |
| `AskUserQuestion` | STEP 1: スキャン対象リポジトリ・ベースパスのヒアリング | ワークフロー内に明示 |

**使用しないツール**: `Bash`、`Edit`、`Skill`、`Agent`

設計原則として「外部接続なし・静的解析のみ（Glob、Grep、Readのみ使用）」が明記されている。

#### 推奨 allowed-tools

```yaml
allowed-tools: Read, Write, Glob, Grep, AskUserQuestion
```

---

### 4-4. pochilib-impact-detector（子スキル）

#### 現在のフロントマター

```yaml
---
skill_id: pochilib-impact-detector
name: pochilib-impact-detector
version: 1.0.0
description: >-
  pochilib-usage-scannerとpochilib-changelog-analyzerの出力を突合し、
  バージョンアップデート時の具体的な影響を分析します。...
---
```

#### 使用ツールの根拠

| ツール | 使用箇所 | 根拠 |
|---|---|---|
| `Read` | STEP 2: pochilib-usage-map.json / changelog-analysis.json 読み込み | ワークフロー内に明示（read_file） |
| `Write` | STEP 5: impact-report.json / impact-summary.md 生成 | ワークフロー内に明示（create_file） |
| `AskUserQuestion` | STEP 1: APP_REPOSITORY_PATH・バージョン情報のヒアリング | ワークフロー内に明示 |

**使用しないツール**: `Bash`、`Edit`、`Glob`、`Grep`、`Skill`、`Agent`

2つのJSONファイルをReadで読み込み、分析してWriteで出力するだけのシンプルな構成。GlobもGrepも設計上不要。

#### 推奨 allowed-tools

```yaml
allowed-tools: Read, Write, AskUserQuestion
```

> 全対象スキルの中で最も制限が厳しい設定（3ツールのみ）。Glob/Grepを除外できる理由は、ファイルパスが前段スキルから確定済みで検索が不要なため。

---

### 4-5. pochi-coding-agent

#### 現在のフロントマター

```yaml
---
name: pochi-coding-agent
description: >-
  仕様駆動開発フレームワークのCoding Agent(実装フェーズ専用エージェント)として動作し、spec.json/plan.jsonのみを参照して実装を自動化します。...
---
```

#### 使用ツールの根拠

SKILL.md の「Tool Constraints」セクション（line 245-261）に明示：

| ツール | 使用箇所 | 根拠 |
|---|---|---|
| `Read` | spec.json/plan.json/既存コードの読み込み | Tool Constraintsに明示 |
| `Write` | 実装ファイルの新規作成 | Tool Constraintsに明示 |
| `Edit` | plan.jsonのstatusフィールド更新のみ（厳格制限） | Tool Constraintsに明示 |
| `Bash` | `pytest {対応テストファイル} -q` でテスト実行 | Tool Constraintsに明示 |
| `Glob` | test-mapping.json等のファイル検索（TDDモード判定） | Tool Constraintsに明示 |
| `Grep` | 対応テストファイルの検索・パターンマッチング | Tool Constraintsに明示 |

**使用しないツール（設計上禁止）**: `AskUserQuestion`（仕様凍結のため一切禁止）、`Agent`/`Task`（サブエージェント起動禁止）、`Skill`、`EnterPlanMode`

#### 推奨 allowed-tools

```yaml
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
```

> **重要**: Bashは `pytest` 実行のために必須であり除外不可。ただし本スキルは全スキル中で最も攻撃面が広い設定（Bash許可）となる。プロンプトインジェクション対策として、`.claude/settings.json` へのdenyリスト追加を強く推奨（Section 5参照）。

---

### 4-6. pochi-spec-initializer

#### 現在のフロントマター

```yaml
---
name: pochi-spec-initializer
description: >-
  仕様駆動開発フレームワークのInitializer(仕様策定専用エージェント)として動作し、質問ベースで仕様書と実装計画を生成します。...
---
```

#### 使用ツールの根拠

SKILL.md の「Tool Constraints」セクション（line 233-244）および起動時宣言（line 95-116）に明示：

| ツール | 使用箇所 | 根拠 |
|---|---|---|
| `AskUserQuestion` | フェーズ1: 要件収集（最大5問まで） | Tool Constraintsに明示 |
| `Write` | フェーズ2: spec.json / spec.md / plan.json の生成 | Tool Constraintsに明示 |
| `Read` | フェーズ1: 既存資料（議事録・PRD・設計書等）の読み込み | 起動時宣言部分に明示 |
| `Glob` | フェーズ1: 既存資料の検索 | 起動時宣言部分に明示 |
| `Grep` | フェーズ1: 既存資料の内容検索 | 起動時宣言部分に明示 |

**使用しないツール（設計上禁止）**: `Bash`（コマンド実行禁止が設計の核心）、`Edit`（仕様外コード編集禁止）、`Agent`/`Task`、`Skill`、`NotebookEdit`

#### 推奨 allowed-tools

```yaml
allowed-tools: Read, Write, Glob, Grep, AskUserQuestion
```

> **補足（SKILL.md内の矛盾について）**: ワークフロー本文（164行・174行）では `check_coverage.py`・`generate_quality_report.py` の実行が能動的な表現で記載されており、217-231行にはbashコードブロックも存在する。しかし Tool Constraints（233-244行）では `ExecuteCommandTool（= Bash）` を明示的に禁止している。これはSKILL.md内部の矛盾であり、これらスクリプトは「ユーザーが手動で実行する参考コマンド」として記載されていると解釈できる。Tool Constraintsが優先されるため、本推奨値からの `Bash` 除外は正しい。ただしSKILL.mdのワークフロー記述は別途修正が望ましい。

---

### 4-7. pochi-unit-test-generator

#### 現在のフロントマター

```yaml
---
name: pochi-unit-test-generator
description: >-
  pochi-test-onboarding なしで Layer1（データ契約テスト）と Layer2（ロジック単体テスト）のみを
  単独で高速生成するスキル。...
---
```

#### 使用ツールの根拠

| ツール | 使用箇所 | 根拠 |
|---|---|---|
| `AskUserQuestion` | STEP 1: app_path/entrypoint/カバレッジ目標等のヒアリング（最大2往復） | ワークフロー内に明示 |
| `Read` | 複数STEP: module-inventory.json / contract files / conftest.py / テストファイルの読み込み | ワークフロー内に多数明示 |
| `Write` | STEP 1: skill-config.json生成 | ワークフロー内に明示 |
| `Glob` | STEP 2: module-inventory.json検索、STEP 4.5: fixtureファイル一覧 | ワークフロー内に明示 |
| `Bash` | STEP 1: app_path検証（`ls`）、STEP 4.5: fixture一覧（`ls`）、不要ファイル削除（`rm`）、品質チェック（`grep`）、pytest実行 | ワークフロー内に明示 |
| `Edit` | STEP 4.5: fixtureの型不一致を自動修正 | ワークフロー内に明示 |
| `Agent` | STEP 2/3/4/5以降: T0/T1/T2/T4の専門サブエージェント起動（4種） | ワークフロー内に明示 |

**使用しないツール**: `Skill`、`TaskCreate/TaskUpdate`

#### 推奨 allowed-tools

```yaml
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, AskUserQuestion, Agent
```

> Agentツールを許可することで間接的にサブエージェントによるファイル書き込みが発生する。これはスキルの設計上必須であり、4種の専門エージェント（T0/T1/T2/T4）への委譲なしに機能しない。

---

### 4-8. pochi-tdd-test-generator

#### 現在のフロントマター

```yaml
---
name: pochi-tdd-test-generator
description: >-
  仕様書（spec.json / plan.json）から Layer1・Layer2 の RED テスト（TDD先行テスト）を生成するスキル。...
---
```

#### 使用ツールの根拠

| ツール | 使用箇所 | 根拠 |
|---|---|---|
| `AskUserQuestion` | STEP 1: spec/planパス・カバレッジ・モック方針ヒアリング | ワークフロー内に明示 |
| `Read` | 複数STEP: spec.json / plan.json / 生成済みcontractファイルの読み込み | ワークフロー内に明示 |
| `Glob` | STEP 1: spec.json/plan.jsonの自動検出 | ワークフロー内に明示 |
| `Bash` | STEP 4: conftest.py生成エラーチェック、STEP 7.5: 品質チェック（`grep`）、STEP 8: `pytest --collect-only`、STEP 9: テストファイル発見 | ワークフロー内に明示 |
| `Agent` | STEP 2/3/5/6/7/8: T2-TDDワークフロー・T4-fixtures-managerサブエージェントの起動 | ワークフロー内に明示 |

**使用しないツール**: `Edit`、`Skill`

#### 推奨 allowed-tools

```yaml
allowed-tools: Read, Write, Glob, Bash, AskUserQuestion, Agent
```

> **修正（2026-05-13）**: 初版では「このスキル自身はWriteを直接使用しない」と記載していたが、実装確認により誤りと判明。STEP 5（353行）で `tests/.onboarding/test-ratio.json` を、STEP 9（642-662行）で `tests/.onboarding/test-mapping.json` をそれぞれ直接 `Write` で生成している。`Write` は必須ツールであり追加した。

---

### 4-9. pochi-test-orchestrator

#### 現在のフロントマター

```yaml
---
name: pochi-test-orchestrator
description: >-
  Pochiアプリのテストケースを FullIntegration / FullScenario /
  PartialIntegration / PartialScenario の4パターンで自動生成・更新する。...
triggers:
  - Pochiのテストケースを生成して
  - ...
---
```

#### 使用ツールの根拠

| ツール | 使用箇所 | 根拠 |
|---|---|---|
| `AskUserQuestion` | Do: スコープ（full/partial）・テスト種別のヒアリング | ワークフロー内に明示 |
| `Bash` | STEP 1: オーケストレータスクリプト実行（環境変数付き）、STEP 5: quality_gate.py実行 | ワークフロー内に明示 |
| `Read` | subagent_call_template.md / quality_report.md / test_cases.md の読み込み | ワークフロー内に明示 |
| `Edit` | STEP 5: quality gate失敗時のtest_cases.md直接修正（最大3回リトライ） | ワークフロー内に明示 |
| `Agent` | STEP 2-4: テストケース生成サブエージェントへの委譲（subagent_call_template.md経由） | ワークフロー内に明示 |

**使用しないツール**: `Write`（テストケースはEditで直接修正）、`Glob`、`Grep`、`Skill`

#### 推奨 allowed-tools

```yaml
allowed-tools: Read, Edit, Bash, AskUserQuestion, Agent
```

---

## 5. 推奨設定値サマリー

| # | スキル | 推奨 allowed-tools | Bash | Agent |
|---|---|---|:---:|:---:|
| 1 | pochilib-update-analyst | `Read, Write, Glob, AskUserQuestion` | ❌ | ❌ |
| 2 | pochilib-changelog-analyzer | `Read, Write, Glob, AskUserQuestion` | ❌ | ❌ |
| 3 | pochilib-usage-scanner | `Read, Write, Glob, Grep, AskUserQuestion` | ❌ | ❌ |
| 4 | pochilib-impact-detector | `Read, Write, AskUserQuestion` | ❌ | ❌ |
| 5 | pochi-coding-agent | `Read, Write, Edit, Bash, Glob, Grep` | ✅ | ❌ |
| 6 | pochi-spec-initializer | `Read, Write, Glob, Grep, AskUserQuestion` | ❌ | ❌ |
| 7 | pochi-unit-test-generator | `Read, Write, Edit, Bash, Glob, Grep, AskUserQuestion, Agent` | ✅ | ✅ |
| 8 | pochi-tdd-test-generator | `Read, Write, Glob, Bash, AskUserQuestion, Agent` | ✅ | ✅ |
| 9 | pochi-test-orchestrator | `Read, Edit, Bash, AskUserQuestion, Agent` | ✅ | ✅ |

### セキュリティ観点での分類

**レベル1（最小権限）**: Bash/Agent不要 → 4スキル（#1〜4 infra系 + #6 spec-initializer）  
**レベル2（Bash許可・Agent不要）**: Bash必要だがサブエージェント起動なし → 1スキル（#5 coding-agent）  
**レベル3（Bash + Agent許可）**: サブエージェントに実作業を委譲 → 3スキル（#7〜9 test系）

---

## 6. 実装時の注意事項

### 6-1. Bash許可スキルへの補完対策

Bash を `allowed-tools` に含むスキル（#5, 7, 8, 9）は、`allowed-tools` によるBlash封鎖ができない。プロンプトインジェクション経由で悪意あるBashコマンドが実行されるリスクに対して、`.claude/settings.json` への `permissions.deny` 設定を補完対策として推奨する。

```json
{
  "permissions": {
    "deny": [
      "Bash(gh release create:*)",
      "Bash(gh release delete:*)",
      "Bash(gh release upload:*)",
      "Bash(gh repo create:*)",
      "Bash(git push:*)"
    ]
  }
}
```

### 6-2. allowed-tools 設定後の動作確認

各スキルに `allowed-tools` を追加した後、以下を確認すること：

1. `/reload-plugins` でプラグインを再読み込み
2. キャッシュに設定が反映されているか確認（`~/.claude/plugins/cache/pochi-internal-skills/<skill-name>/*/skills/run/SKILL.md`）
3. スキルを起動し、制限されたツールが実際にブロックされるか確認

キャッシュに古い内容が残る場合は `plugin.json` の `version` をインクリメントして再インストールを実施する。

### 6-3. 子スキルの allowed-tools について

`pochilib-changelog-analyzer`、`pochilib-usage-scanner`、`pochilib-impact-detector` は子スキルであり、`Skill` ツール経由で親スキルから呼び出される。これらの `allowed-tools` 設定は子スキルが起動している文脈のみに適用される（親スキルの文脈とは独立）。

---

---

## 7. 実装後チェック結果（2026-05-13）

各スキルの SKILL.md を精査し、Section 4 の推奨値との整合性を検証した。

| # | スキル | 検証結果 | 修正内容 |
|---|---|---|---|
| 1 | pochilib-update-analyst | ✅ 正しい | Step 1-B で pyproject.toml を Read（Readは必要） |
| 2 | pochilib-changelog-analyzer | ✅ 正しい | 変更なし |
| 3 | pochilib-usage-scanner | ✅ 正しい | 変更なし |
| 4 | pochilib-impact-detector | ✅ 正しい | 変更なし |
| 5 | pochi-coding-agent | ✅ 正しい | 変更なし |
| 6 | pochi-spec-initializer | ✅ 正しい（補足追加） | SKILL.md内の矛盾（Bash参照記述）について注記追加 |
| 7 | pochi-unit-test-generator | ✅ 正しい | Grep許可は安全側として妥当 |
| 8 | pochi-tdd-test-generator | **❌ 修正済み** | `Write` が欠落 → `Read, Write, Glob, Bash, AskUserQuestion, Agent` に修正 |
| 9 | pochi-test-orchestrator | ✅ 正しい | 変更なし |

*本レポートは 2026-05-13 時点の各 SKILL.md 実装に基づく。スキルのワークフロー改修時は再評価を行うこと。*
