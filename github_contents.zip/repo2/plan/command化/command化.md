# スキル構造に関する調査まとめ

## 調査背景

`skills/{カテゴリ名}/{skill名}/skills/run/SKILL.md` という深い階層が必須かどうかを調査した。

---

## 公式が定めるスキルの配置構造

### スタンドアロン（プロジェクト固有）

| スコープ | パス |
|---|---|
| Personal | `~/.claude/skills/<skill-name>/SKILL.md` |
| Project | `.claude/skills/<skill-name>/SKILL.md` |

### プラグイン内

```
<plugin-root>/
  .claude-plugin/plugin.json   ← マニフェスト（必須）
  skills/
    <skill-name>/
      SKILL.md                 ← スキルの本体（必須）
```

**ポイント：`skills/<任意名>/SKILL.md` という2段階が最小単位。**

---

## pochi リポジトリの現状

`marketplace.json` の `source` はプラグインルートを指している：

```json
{ "source": "./skills/tools/pochi-skill-navigator" }
```

実際のファイルパス：

```
skills/tools/pochi-skill-navigator/   ← プラグインルート
  plugin.json
  skills/
    run/                              ← "run" という意味の薄い名前
      SKILL.md
```

`run/` はスキル名として機能しており、`/pochi-skill-navigator:run` で呼び出される。

---

## 各構造の比較

### ① 現行：`skills/run/SKILL.md`（深い・冗長）

```
skills/tools/pochi-skill-navigator/skills/run/SKILL.md   （6階層）
```

- `run` というディレクトリ名に意味がない
- 階層が深く読みにくい

### ② `skills/<plugin名>/SKILL.md`（名前を意味のあるものに変更）

```
skills/tools/pochi-skill-navigator/skills/pochi-skill-navigator/SKILL.md   （6階層）
```

- スキル名が明確になる
- 階層の深さは変わらない

### ③ `commands/<name>.md`（最もフラット）

```
skills/tools/pochi-skill-navigator/commands/pochi-skill-navigator.md   （4階層）
```

- 最も階層が浅い
- `skills/run/` という冗長なネストが消える
- ファイル1枚で完結

---

## `commands/` と `skills/` の違い

公式ドキュメントの明言：

> **カスタムコマンドはスキルにマージされました。**  
> `.claude/commands/deploy.md` と `.claude/skills/deploy/SKILL.md` の両方が `/deploy` を作成し、同じように機能します。

| 観点 | `commands/<name>.md` | `skills/<name>/SKILL.md` |
|---|---|---|
| スラッシュコマンドになるか | ✅ | ✅ |
| YAMLフロントマター対応 | ✅ | ✅ |
| 自動呼び出し（description活用） | ✅ | ✅ |
| サポートファイル用サブディレクトリ | ❌ | ✅ |
| 同名競合時の優先度 | 低い | 高い |
| 公式推奨 | 旧形式・動作は保証 | ✅ **推奨** |

`commands/` は「スキルの旧形式・簡易版」であり、別物ではない。

---

## 結論

### CLAUDE.md のルール（`skills/run/SKILL.md`）が必須な理由

pochi 独自のインストール・キャッシュ機構が `skills/run/SKILL.md` というパスを前提としているため、**リポジトリ内では変更不可**。

### 公式仕様上の最小構造

`skills/<任意名>/SKILL.md` であれば動作する。`run` という名前自体は必須ではない。

### 構造をシンプルにしたい場合

`commands/<name>.md` 方式が最もフラットだが、サポートファイルが使えないため複雑なスキルには不向き。pochi の各スキルはすでに `core/`, `prompts/` をプラグインルート直下に持つため、`commands/` に移行しても機能面での制約は少ない。
