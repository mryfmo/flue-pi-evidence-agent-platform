# Snowflake接続スキル セキュリティ調査結果

調査日: 2026-04-09

## 調査対象

| # | スキル | パス |
|---|--------|------|
| 1 | db-impact-analyzer | `skills/archive/db-impact-analyzer/snowflake_env/query_history.py` |
| 2 | fu/snowflake-explorer | `plan/ALADIN-WDH/fu/snowflake-explorer/snowflake_explorer.py` |
| 3 | docomo/snowflake-explorer | `.claude/skills/snowflake-explorer/scripts/` （@docomo-data-analytics-cc-skills） |

---

## 総合比較表

| 観点 | db-impact-analyzer | fu/snowflake-explorer | docomo/snowflake-explorer |
|------|:---:|:---:|:---:|
| 任意SQL実行 | 🟢 不可 | 🔴 **可能** | 🟢 不可 |
| 破壊的操作（構造上） | 🟢 不可 | 🔴 **可能** | 🟢 不可 |
| 外部入力バリデーション | 🔴 なし | 🔴 なし（roleのみ許可リスト） | 🟢 ホワイトリスト正規表現 `^[A-Za-z0-9_.]+$` |
| SQLエスケープ方式 | 🔴 f-string直接埋め込み（シングルクォートで囲むのみ） | 🔴 f-string直接埋め込み（quote()はダブルクォートで囲むのみ） | 🟢 SQLAlchemy `text()` + bindparams |
| SQLインジェクションリスク | 🔴 あり | 🔴 **高** | 🟢 最小 |
| LIMIT値の制限 | 🔴 なし | 🔴 なし | 🟢 あり（`min(max(v, 1), 200)`）※show_table_info.pyのみ上限なし |
| 破壊的操作の防止措置 | 🟢 コード構造上不可 | 🔴 プロンプト指示のみ（`Don't` セクション） | 🟢 コード構造上不可 |

---

## 各スキルの詳細

### 1. db-impact-analyzer

**ファイル**: `skills/archive/db-impact-analyzer/snowflake_env/query_history.py`

#### 接続フロー

```
fetch_query_history(view_names, days)  # 34行目
  ├── generate_pochi_snowflake_connector()  # 56行目（引数なし・認証のみ）
  ├── psc.timeout = 600                     # 65行目
  ├── psc.connect()                         # 66行目
  └── cnx.get_records_and_fetchall(sql)     # 158, 192, 223行目
```

#### 実行SQL

コード内にハードコーディングされた **SELECT文のみ** 3種類：

- VIEWアクセス履歴照会（78〜102行目）
- アプリ全体クエリ数取得（105〜118行目）
- ユーザー別VIEWアクセス数取得（121〜143行目）

外部から受け取れるパラメータは `view_names`（VIEW名リスト）と `days`（整数）のみ。

#### サニタイズ・バリデーション

```python
# 75行目: シングルクォートで囲むのみ。エスケープ処理なし
view_name_placeholders = ", ".join(f"'{v}'" for v in view_names)
```

- VIEW名のバリデーション: **なし**（カンマ区切りの分割・空白トリムのみ）
- days のバリデーション: `int()` 変換のみ（負数・上限チェックなし）
- SQLインジェクション対策: **不十分**（シングルクォートで囲むだけで内部のシングルクォートをエスケープしない）

**脆弱性の具体例**:
```
入力: VIEW_A' OR '1'='1
展開: IN ('VIEW_A' OR '1'='1') → フィルター条件が無効化される
```

#### 総評

- Claude Code が任意SQLを実行する口はなく、**構造上は読み取り専用**
- ただし VIEW名入力に対するSQLインジェクション対策が不十分

---

### 2. fu/snowflake-explorer

**ファイル**: `plan/ALADIN-WDH/fu/snowflake-explorer/snowflake_explorer.py`

#### 接続フロー

```
generate_pochi_snowflake_connector(role=role)  # 17行目（roleを引数に渡す）
  └── cnx.get_records_and_fetchall(sql)         # 21行目（sqlをそのまま実行）
```

#### コマンド構成

| コマンド | 内容 | リスク |
|----------|------|--------|
| `query "<SQL>"` | **任意のSQLを直接実行** | 🔴 最大 |
| `distinct <table> <column>` | DISTINCT値取得（SELECT文生成） | ⚠️ 中 |
| `sample <table>` | サンプルデータ取得（SELECT * 生成） | ⚠️ 中 |

#### サニタイズ・バリデーション

```python
# 34〜38行目: quote() によるダブルクォートで囲むのみ
def quote(name: str) -> str:
    parts = name.split(".")
    return ".".join(f'"{p}"' if not p.startswith('"') else p for p in parts)
```

- `query` コマンド: バリデーション**完全になし**。任意SQLがそのまま実行される
- `table` / `column`: `quote()` でダブルクォートで囲むのみ（内部のダブルクォートのエスケープなし）
- `limit`: `type=int` で数値変換のみ（上限チェックなし）
- `role`: `choices=["PIGEON_GCP_ROLE", "EXTRACTION_GROUP_ROLE", "DPAY_NETWORK_ROLE"]` で**許可リスト制御**（唯一適切な対策）

#### 破壊的操作の防止

SKILL.md の `Don't` セクションに記載（プロンプト指示のみ）：
```
❌ UPDATE / INSERT / DELETE / DROP などの書き込み系SQLは実行しない
```
→ **コードレベルでは一切防いでいない**。最終防衛線はSnowflakeロールの権限設定。

#### 総評

- `query` コマンドで任意SQLを実行できる設計のため、3つの中で**最もリスクが高い**
- 破壊的操作が通るかどうかはSnowflakeロール権限次第

---

### 3. docomo/snowflake-explorer

**ファイル**: `.claude/skills/snowflake-explorer/scripts/` 配下の6スクリプト

#### スクリプト一覧

| スクリプト | 機能 | 実行SQL |
|-----------|------|---------|
| `search_tables.py` | テーブル・ビュー検索 | SELECT（INFORMATION_SCHEMA） |
| `get_table_columns.py` | カラム情報取得 | SHOW COLUMNS |
| `get_schemas.py` | スキーマ一覧取得 | SHOW SCHEMAS |
| `search_catalog_columns.py` | Alationカタログ カラム検索 | SELECT |
| `search_catalog_views.py` | Alationカタログ ビュー検索 | SELECT |
| `show_table_info.py` | テーブル詳細情報表示 | SHOW COLUMNS / SHOW PRIMARY KEYS / SELECT * |

全スクリプトで **SELECT / SHOW のみ**。`query "<任意SQL>"` の口は存在しない。

#### サニタイズ・バリデーション

**`sanitize_sql_identifier()` 関数**（search_tables.py等 4ファイルに実装）:

```python
def sanitize_sql_identifier(identifier: str) -> str:
    if not re.match(r"^[A-Za-z0-9_.]+$", identifier):
        raise ValueError(f"不正なSQL識別子です: {identifier}")
    return identifier
```

**パラメータ化クエリ**（search_tables.py, search_catalog_*.py）:

```python
# キーワード等の任意文字列はbindparamsで渡す（SQL直結なし）
params = {"kw": f"%{keyword}%", "schema_name": schema}
sql = text("... WHERE col ILIKE :kw AND TABLE_SCHEMA = :schema_name ...")
df = pd.read_sql(sql, conn, params=params)
```

**LIMIT値の制御**（search_catalog_*.py）:

```python
effective_limit = min(max(display_limit, 1), 200)  # 1〜200に強制
```

#### 軽微な問題点

- `sanitize_sql_identifier()` が4ファイルに重複実装（共通モジュール化が望ましい）
- `show_table_info.py` の LIMIT値に上限チェックなし（他スクリプトは `min/max` 制御あり）

#### 総評

- **3つの中で最も安全な設計**
- 識別子はホワイトリスト検証、値はパラメータ化クエリで対策済み
- 構造上、破壊的操作は不可能

---

## まとめ・リスク順位

```
リスク高 ────────────────────────────── リスク低
fu/snowflake-explorer > db-impact-analyzer > docomo/snowflake-explorer
```

- **fu/snowflake-explorer**: 任意SQL実行が可能。プロンプト指示のみで破壊的操作を制限しており、コードレベルの防御なし
- **db-impact-analyzer**: 構造上は読み取り専用だが、SQLインジェクション対策が不十分
- **docomo/snowflake-explorer**: ホワイトリスト検証 + パラメータ化クエリで最も堅牢
