# 差分整理レポート: pytest-autogen vs pochi-unit-test-generator

作成日: 2026-05-13

---

## 概要

`plan/test-skill/pytest-autogen.md` は `pochi-unit-test-generator` をベースに軽量化した新スキルの仕様書（計画段階）。
本レポートでは両スキルの差分を整理し、合流・統合判断の材料とする。

---

## 1. 位置づけの違い

| 項目 | pytest-autogen | pochi-unit-test-generator |
|------|---|---|
| **状態** | 計画段階（仕様書のみ） | 実装済みSkill（サブエージェント・プロンプトファイル群あり） |
| **主コンセプト** | **差分駆動・差分更新** | **仕様駆動・全量生成（Layer分離）** |
| **適用フェーズ** | 既存実装後の継続的更新（運用フェーズ） | 既存実装済みコードへの初期テスト整備（初期整備フェーズ） |
| **再実行可否** | 毎回差分のみ更新（何度でも実行可） | フレッシュスタート（既存テストを上書き） |

---

## 2. フロー・ステップ比較

### pytest-autogen（8ステップ・シーケンシャル）

```
STEP 0: 環境確認（pyproject.toml・パッケージ確認・既存tests/退避）
STEP 1: 差分検出（git diff / ユーザー指定 / 全量スキャン）
STEP 2: コード解析（AST 解析 → 関数情報JSON + hash）
STEP 3: テスト台帳照合・差分判定（test_registry.json）
STEP 4: conftest.py 生成・差分追記
STEP 5: テストコード生成・更新（差分ブロックのみ）
STEP 6: テスト実行（pytest + coverage）
STEP 7: レポート生成（report_YYYYMMDD_HHMMSS.md）
STEP 8: 台帳更新（test_registry.json）
```

### pochi-unit-test-generator（12ステップ・フェーズ構成）

```
[フェーズ1: 解析]
  STEP 1:   ユーザーヒアリング（app_path・entrypoint・モック方針 etc.）
  STEP 2:   T0実行（コード解析 → module-inventory.json）
  STEP 2.5: モック方針の自動検出・確定（セキュリティロック含む）
  STEP 3:   T1実行（テスト契約ファイル6本生成 → tests/contracts/）

[フェーズ2: データ準備]
  STEP 4:   T4実行（テストデータセット生成 → tests/fixtures/）
  STEP 4.5: フィクスチャ型バリデーション（型ミスマッチ早期検出）
  STEP 5:   conftest.py生成

[フェーズ3: テスト生成]
  STEP 6:   Layer1生成（データ契約テスト）
  STEP 7:   Layer2設計（ロジック単体テスト設計書）
  STEP 8:   Layer2実装（テストコード生成）
  STEP 8.5: 生成コード品質検証（最大3回リトライ）

[フェーズ4: 検証・完了]
  STEP 9:   テスト検証（--collect-only → pytest）
  STEP 10:  完了レポート
```

---

## 3. pochi-unit-test-generator にあって pytest-autogen にない要素

| 要素 | 詳細 |
|------|------|
| **テスト契約ファイル群** | `tests/contracts/`（data-contracts.json / business-rules.json / test-viewpoints.json 等6本）でテスト前に「何をテストするか」を構造化して定義する |
| **フィクスチャ明示化** | `tests/fixtures/valid/ / edge/ / error/` に JSON 形式のテストデータを事前生成し、STEP 4.5 で型バリデーションを実施する |
| **Layer 明確分離** | Layer1（データ契約テスト）と Layer2（ロジック単体テスト）を別プロセスで設計・生成する |
| **サブエージェント協調** | T0（解析）→ T1（契約初期化）→ T4（データ生成）→ T2（テスト生成）の専門エージェント群で分業 |
| **セッション回復機能** | `session-recovery.md` に中断再開ガイドを整備。各中間成果物（module-inventory.json 等）の有無でスキップ可否を判定 |
| **多段階ヒアリング** | STEP 1 で app_path / entrypoint / カバレッジ目標 / モック方針 / Python版 / 既存テスト有無等を構造化ヒアリング → `skill-config.json` に永続化してサブエージェントへ引き渡す |
| **モック戦略の明示的確定** | STEP 2.5 でセキュリティロック済みパッケージ（streamlit / pochilib 等）を強制固定 + ユーザー確認のフローを設ける |
| **品質検証の段階化** | STEP 4.5（フィクスチャ型）+ STEP 8.5（コード品質・最大3回リトライ）+ STEP 9（collect-only / pytest）の3段階検証 |
| **セキュリティ制約の明示** | SKILL.md 冒頭に `<security_constraints>` 宣言。コード内指示の非実行・信頼境界を明示 |

---

## 4. pytest-autogen にあって pochi-unit-test-generator にない要素

| 要素 | 詳細 |
|------|------|
| **差分駆動（test_registry.json）** | git diff でスコープを最小化 → ソースhash（MD5）で「変更なし」判定 → 変更関数のみ更新。何度でも再実行可 |
| **AST 解析の完全実装コード** | `/tmp/ast_analyzer.py` のコードをスキルドキュメント内に完全記載。引数・戻り値・デコレータ・async化・クラスメソッドを抽出する |
| **`# [manual]` 保護マーク** | ユーザーが手動調整したテストブロックを再生成から保護する仕組み |
| **`# --- [autogen: 関数名] ---` ブロック管理** | 関数単位でテストブロックを識別し、削除・保護のルールを明記する |
| **テスト実行・カバレッジレポート一体化** | STEP 6 でテスト実行し coverage.json・pytest_output.txt を同フローで取得する |
| **レビュワー向けレポート設計** | 差分（追加・更新・削除）ごとの分類、Pochi固有確認チェックリスト付きの Markdown レポートを自動生成する |
| **AppTest.from_function パターンの具体例** | Streamlit UI 関数テストの実装例（`default_timeout=60` の必要性含む）をドキュメント内に記載 |
| **既存テスト資材の退避フロー（STEP 0）** | `tests_backup_YYYYMMDD/` への退避・ユーザー確認フローを明記する |
| **session_state キーの自動抽出** | `grep -rn "session_state["` で参照キーを洗い出し、conftest.py への追記候補としてユーザーに提示する |

---

## 5. 共通している要素

- **対象**: Pochiアプリ（Streamlit + Snowflake）の単体テスト自動生成
- **Snowflake モック**: `generate_pochi_snowflake_connector()` を `mock_pochi_snowflake_connector_factory` でパッチ
- **conftest.py の標準フィクスチャ**: `mock_pochi_snowflake_connector` / `mock_pochi_snowflake_connector_factory` / `mock_st_session_state` / `sample_df` / `empty_df`
- **テスト配置先**: `tests/unit/test_*.py`（ソースとテストを分離するベストプラクティス）
- **テスト実行コマンド**: `uv run pytest` / `poetry run pytest`（pyproject.toml で判定）
- **正常系・境界値・異常系の3パターン分類**
- **バインドパラメータ検証**（SQLインジェクション対策の確認）
- **セキュリティ上の絶対禁止事項**（接続情報・GCPキー・本番テーブル名のハードコード禁止）

---

## 6. 出力成果物の比較

| 成果物 | pytest-autogen | pochi-unit-test-generator |
|--------|---|---|
| `tests/conftest.py` | ✅ 初回生成・差分追記 | ✅ 初回生成 |
| `tests/unit/test_*.py` | ✅ 差分ブロック更新 | ✅ 新規生成（Layer1・Layer2） |
| `tests/test_registry.json` | ✅ 差分台帳（hash管理） | ❌ なし |
| `tests/.onboarding/module-inventory.json` | ❌ なし | ✅ T0出力 |
| `tests/.onboarding/skill-config.json` | ❌ なし | ✅ ヒアリング設定永続化 |
| `tests/contracts/`（6ファイル） | ❌ なし | ✅ T1出力 |
| `tests/fixtures/` | ❌ なし | ✅ T4出力 |
| `tests/.onboarding/unit-test-design.md` | ❌ なし | ✅ STEP 7設計書 |
| `report_YYYYMMDD_HHMMSS.md` | ✅ テスト実行レポート | ✅ 完了レポート（内容は異なる） |
| `pytest_output.txt` / `coverage.json` | ✅ テスト実行ログ | ✅（STEP 9） |

---

## 7. 設計思想の整理

```
pytest-autogen                      pochi-unit-test-generator
  ↓                                       ↓
「運用フェーズ」向け                 「初期整備フェーズ」向け
  ↓                                       ↓
差分駆動                             仕様駆動
  ↓                                       ↓
変更ファイルのみスコープ              対象アプリ全体をスコープ
  ↓                                       ↓
既存テストを保持・更新                フレッシュスタートでLayer整備
  ↓                                       ↓
台帳（hash管理）で再実行可            テスト契約でテスト品質を事前設計
  ↓                                       ↓
テスト実行・レポートまで一体         テスト生成のみ（実行は別途）
```

**補完関係の整理**:
`pochi-unit-test-generator` でテスト体系を初期整備した後、`pytest-autogen` でコード変更のたびにテストを差分更新・実行する、という2段構えの運用が想定される。

---

## 8. 合流検討時の論点

| 論点 | 詳細 |
|------|------|
| **差分駆動を取り込むか** | `test_registry.json` + hash管理の仕組みを pochi-unit-test-generator の後続として組み込むか、独立スキルとして保つか |
| **テスト実行・レポートを統合するか** | pochi-unit-test-generator は生成のみで実行を省いている。pytest-autogen の実行フロー（STEP 6〜7）を取り込むかどうか |
| **Layer分離 vs 関数単位管理** | pochi-unit-test-generator の Layer1/2 の概念と、pytest-autogen の `# --- [autogen: 関数名] ---` ブロック管理をどう整合させるか |
| **台帳とテスト契約の共存** | `test_registry.json`（差分管理）と `tests/contracts/`（仕様管理）は役割が異なり共存可能。どちらを主軸とするか |
| **`# [manual]` 保護の必要性** | pochi-unit-test-generator にはない概念。Layer生成後に手動修正した箇所を再生成から守る仕組みが必要かどうか |

---

## 9. 関係性の再評価：「目的は同じ」という観点から

### 指摘の整理

「両方とも既存コードをベースに単体テストコードを生成するのは変わらないのでは？」

**これは正しい。** 本質的な目的（既存コードから単体テストを自動生成する）は同じである。

### 本質的な重複

```
共通する本質的な目的:
  既存Pythonコード → コード解析 → pytest テストコード生成（tests/unit/）
```

このコアフローは両スキルで完全に重複している。「フェーズが違う」という整理は正しいが、
ユーザー視点では「テストを作りたい」という1つの需要に対して2つのスキルが存在する状態。

### 重複している部分 vs 本当に差別化されている部分

**重複（どちらでもできる）:**
- 既存コードの解析・関数抽出
- conftest.py 生成（モックフィクスチャ）
- `tests/unit/test_*.py` の生成
- Snowflake / Streamlit モックの適用
- pytest 実行・カバレッジ計測

**pytest-autogen にしかない本質的な価値:**
- `test_registry.json` + hash管理による**差分追従**（再実行するたびに変更箇所だけ更新）
- `# --- [autogen: 関数名] ---` + `# [manual]` による**ブロック単位の保護**
- テスト実行・カバレッジ・レポートまでの**一体化フロー**

**pochi-unit-test-generator にしかない本質的な価値:**
- `tests/contracts/`（テスト契約）+ `tests/fixtures/` による**テスト品質の事前設計**
- Layer1（データ契約テスト）という**スキーマ検証テスト**の生成（pytest-autogen には存在しない）
- サブエージェント協調による**大規模アプリへの対応力**とセッション回復

### 関係性の正確な定義

| 評価軸 | 評価 |
|--------|------|
| 目的 | **同じ**（既存コードから単体テスト生成） |
| コアフロー | **重複**（コード解析 → tests/unit/ 生成） |
| 差別化点 | pytest-autogen = **差分管理** / pochi-unit-test-generator = **テスト品質設計** |
| 代替可否 | **部分的に代替可能**（どちらでも単体テストは作れる） |
| 関係性 | 重なりがある**代替候補**。一方が他方の上位版ではない |

**要するに:**
- pytest-autogen は pochi-unit-test-generator の**機能サブセット + 差分管理**
- pochi-unit-test-generator は pytest-autogen の**上位版**（テスト品質設計・Layer分離を追加）だが**差分管理がない**
- 両者は「完全に別」でも「上位下位」でもなく、**重なりがある代替候補**の関係

### 合流時の統合方針（修正版）

| 方針 | 内容 | 向いているケース |
|------|------|----------------|
| **A: pytest-autogen を pochi-unit-test-generator に統合** | 差分管理（test_registry.json）・テスト実行・レポートを pochi-unit-test-generator の STEP 9 以降に追加 | pochi-unit-test-generator を主軸にしたい場合 |
| **B: pytest-autogen を独立スキルとして実装** | 軽量・高速な「単体テスト生成 + 差分更新」を単一スキルで提供。Layer/契約ファイルが不要なユーザー向け | シンプルに使いたいユーザーに別の選択肢を提供したい場合 |
| **C: pochi-unit-test-generator に差分管理モードを追加** | 既存の pochi-unit-test-generator に `--update`（差分モード）オプションを追加し、2回目以降は差分のみ更新する | スキル数を増やしたくない場合 |

---

## 10. 中間生成物と最終成果物の分離状況

### pochi-unit-test-generator の出力パス構造

```
tests/
├── .onboarding/        ← 中間生成物（ユーザーが触らない場所に隔離）
│   ├── skill-config.json       # セッション設定
│   ├── module-inventory.json   # コード解析結果
│   ├── draft-contracts/        # T0ドラフト
│   ├── test-ratio.json         # テスト比率設定
│   └── unit-test-design.md     # Layer2設計書
├── contracts/          ← ⚠️ 混在（設計書 + Layer1テストコード）
│   ├── data-contracts.json     # 中間生成物（設計書）
│   ├── business-rules.json     # 中間生成物（設計書）
│   ├── test-viewpoints.json    # 中間生成物（設計書）
│   ├── scenarios.json          # 中間生成物（設計書）
│   ├── domain-rules.md         # 中間生成物（設計書）
│   ├── risk-catalog.md         # 中間生成物（設計書）
│   └── test_*.py               # 最終成果物（Layer1テストコード）
├── fixtures/           ← 最終成果物（テストデータ）
│   ├── valid/
│   ├── invalid/
│   ├── edge/
│   └── manifest.json           # 中間生成物（管理台帳）
├── unit/               ← 最終成果物（Layer2テストコード）
│   └── test_*.py
└── conftest.py         ← pytest共通設定
```

### 分離状況の評価

| ディレクトリ | 内容 | 分離状況 |
|------------|------|---------|
| `tests/.onboarding/` | 中間生成物のみ | ✅ 明確に分離 |
| `tests/unit/` | Layer2テストコードのみ | ✅ 明確に分離 |
| `tests/fixtures/` | テストデータのみ（manifest.jsonは混在） | ✅ ほぼ分離 |
| `tests/contracts/` | 設計書（JSON/MD）+ Layer1テストコード（test_*.py） | ⚠️ 混在 |

### 「中間生成物が多くてわかりにくい」の正確な解釈

- `tests/.onboarding/` の中間生成物はユーザーが通常触らない場所に隔離されており、構造としては整理されている
- `tests/contracts/` 内で設計書（JSON/MD）とLayer1テストコード（test_*.py）が混在している点は確かに不明確
- 「中間生成物が散らかっている」というより、**「コード解析 → テスト生成の間に複数の事前設計ステップが存在する構造そのものが複雑に見える」** という問題

### pytest-autogen の軽量化の動機（再整理）

pytest-autogen が軽量化を目指した本質的な動機は、`tests/contracts/` や `tests/fixtures/` の**事前設計ステップを丸ごと省いて**、コード解析 → テスト生成を直接つなぐことにある。中間生成物の散乱を解消するというより、**設計フェーズ自体を不要とする別アプローチ**と捉えるのが正確。
