---
name: pytest-autogen
description: >
  Pochiアプリ（Streamlit + Snowflake）のソースコードを解析し、pytest テストコードを
  差分ベースで自動生成・更新・実行し、レビュワー向けレポートを出力する Skill。
  既存テストは保持し、変更・追加・削除された関数に対してのみ差分更新する。
triggers:
  - "pytestを自動生成"
  - "テストを自動生成"
  - "テストコードを生成"
  - "テストを更新して実行"
  - "全ファイルのテストを"
---

# pytest-autogen Skill

## このSkillが行うこと

> フロー図は [`flow.html`](./flow.html) をブラウザで開いて確認してください。
>
> **メンテナンス注意**: このSKILLのSTEP構成・アウトプット・フローを変更した際は、必ず `flow.html` も追従して修正すること。

**各STEPのアウトプットまとめ**

| STEP | アウトプット | 次のSTEPでの使われ方 |
|------|------------|-------------------|
| STEP 0 | 実行コマンド・testsパス・退避済み資材 | 全STEPのパス・コマンドの基準になる |
| STEP 1 | 変更された `.py` ファイル一覧 | STEP 2のコード解析対象 |
| STEP 2 | 関数情報JSON（名前・引数・戻り値・hash） | STEP 3の台帳照合に使用 |
| STEP 3 | 新規/変更/削除/変更なしの分類リスト | STEP 5のテスト生成・更新・削除の判断基準 |
| STEP 4 | `tests/conftest.py`（初回生成 or 差分追記） | STEP 5で生成するテストが共通で使うモック等の準備コードを提供 |
| STEP 5 | `tests/unit/test_*.py` | STEP 6のpytest実行対象 |
| STEP 6 | `pytest_output.txt` / `coverage.json` | STEP 7のレポート素材 |
| STEP 7 | `report_YYYYMMDD_HHMMSS.md` | レビュワーへの共有・STEP 8の完了確認 |
| STEP 8 | 更新済み `test_registry.json` | 次回STEP 3の台帳照合に使用 |

---

## 前提とするPochiプロジェクト構造

> **注意**: 以下はPochiアプリに共通する典型的な構造の例であり、アプリによって異なる場合がある。
> Skillを実行する前に実際のプロジェクト構造を確認し、各パスを読み替えること。

```
{project-root}/
├── app/                          # アプリ本体（ほぼ全アプリ共通）
│   ├── main.py                   # エントリポイント（set_page_config → run_navi）
│   ├── app_pages/                # Streamlit マルチページ（st.navigation）
│   │   └── {page_name}/          # ページごとにサブディレクトリを持つ場合もある
│   ├── lib/                      # 共有ライブラリ（アプリによって data_access/, domain/ 等の名称もある）
│   │   ├── data_access/          # Snowflakeクエリ・データ取得
│   │   ├── domain/               # ビジネスロジック
│   │   └── {utility_modules}.py
│   ├── pyproject.toml            # 依存関係（poetry または uv）
│   └── run_app.sh
└── tests/                        # ★このSkillが生成するテストは常にここに配置
    ├── conftest.py               # 初回のみ生成
    ├── test_registry.json        # Skillが維持する管理台帳
    └── unit/                     # 単体テスト
        └── test_*.py
```

> **既存の `app/tests/` について**: アプリによっては `app/tests/` に既存テストが存在する場合がある。
> このSkillが生成するテストはリポジトリルート直下の `tests/unit/` に統一して配置し、既存テストには手を加えない。
> ソースコードとテストを分離するpytestのベストプラクティスに沿った構成。

**テストファイルの命名規則**
ソースファイルのパスのうち、`app/` を除いたパス区切りを `_` に変換する。
- `app/lib/query_collect.py` → `tests/unit/test_lib_query_collect.py`
- `app/lib/data_access/shop.py` → `tests/unit/test_lib_data_access_shop.py`
- `app/app_pages/common/etl.py` → `tests/unit/test_app_pages_common_etl.py`

---

## 実行手順

### STEP 0: 環境確認

まずパッケージマネージャーを確認し、必要なライブラリが揃っているかチェックする。
インストールが必要な場合はユーザーに伝えて対応を委ねる。

**① パッケージマネージャーの判定**
```bash
# pyproject.toml を確認して環境を判定する
# [tool.uv] があれば Phase4（uv）、[tool.poetry] があれば Phase3（poetry）
cat app/pyproject.toml
```

| 環境 | 判定基準 | テスト実行コマンド |
|------|---------|-----------------|
| Phase4（uv） | `[tool.uv]` が存在 | `uv run pytest` |
| Phase3（poetry） | `[tool.poetry]` が存在 | `poetry run pytest` |

また `testpaths` の設定からtestsディレクトリの場所も確認する。

```bash
# testpaths の確認（pyproject.toml 内）
grep -A3 "testpaths" app/pyproject.toml
# → ["../tests"] ならパターンA（リポジトリルート直下）
# → ["tests"] または未記載ならパターンB（app/tests/）
```

**② 必要なライブラリの確認**
```bash
# Phase4（uv）の場合
uv run python -m pytest --version
uv run python -m pytest_mock --version 2>/dev/null || echo "pytest-mock: NOT FOUND"
uv run python -c "import pytest_cov" 2>/dev/null || echo "pytest-cov: NOT FOUND"

# Phase3（poetry）の場合
poetry run python -m pytest --version
poetry run python -c "import pytest_mock" 2>/dev/null || echo "pytest-mock: NOT FOUND"
poetry run python -c "import pytest_cov" 2>/dev/null || echo "pytest-cov: NOT FOUND"
```

不足しているライブラリがあればユーザーに以下を案内して、インストール完了後に次のステップへ進む。

```
# Phase4（uv）の場合
uv add pytest pytest-mock pytest-cov

# Phase3（poetry）の場合
poetry add pytest pytest-mock pytest-cov
```

**③ 既存の `tests/` ディレクトリの確認**

```bash
ls tests/ 2>/dev/null || echo "tests/: NOT FOUND"
```

`tests/` が存在する場合、`tests/test_registry.json` の有無でこのSkillが管理しているかどうかを判定する。

| 状態 | 対応 |
|------|------|
| `tests/` が存在しない | そのまま次のSTEPへ進む |
| `tests/test_registry.json` が存在する | このSkillが管理済みの領域。そのまま次のSTEPへ進む |
| `tests/test_registry.json` が存在しない | 既存の資材あり。**以下の退避フローを実行する** |

**既存資材の退避フロー**

`tests/test_registry.json` がなく、かつ `tests/` 配下にファイルが存在する場合は、
このSkillが管理していない既存資材とみなし、ユーザーに確認の上で退避する。

```bash
# 退避先の命名規則: tests_backup_YYYYMMDD/
BACKUP_DIR="tests_backup_$(date +%Y%m%d)"
echo "以下のファイルを ${BACKUP_DIR}/ に退避します:"
ls tests/
```

ユーザーに退避してよいか確認し、承認を得た場合のみ実行する。

```bash
mv tests/ "${BACKUP_DIR}/"
echo "退避完了: ${BACKUP_DIR}/"
```

> 退避したディレクトリは削除しない。不要になった場合はユーザーが判断して削除する。

---

### STEP 1: 差分検出

以下の優先順で変更対象ファイルを特定する。

**① git がある場合（推奨）**
```bash
git diff --name-only HEAD
git diff --name-only --cached
```

対象: `app/lib/`, `app/app_pages/` 配下の `.py` ファイルのみ。
（アプリによって `app/data_access/`, `app/domain/` 等の名称の場合もあるため、STEP 0で確認した構造に合わせる）

**② ユーザーが対象ファイルを明示した場合**
指定されたファイルのみを対象とする。

**③ 全量スキャン指示の場合**
ソースコードが配置されているディレクトリ配下の全 `.py` ファイルを対象とする。
（`tests/`, `.claude/`, `__pycache__`, `old_files/`, `tools/` は除外）

---

### STEP 2: コード解析（AST）

> **AST（Abstract Syntax Tree／抽象構文木）とは？**  
> Pythonコードをテキストとして読むのではなく、「どんな関数が定義されているか」「引数は何か」「返り値の型は何か」といった構造情報をツリー形式で取り出す仕組みです。  
> これを使うことで、コードを実行せずに関数の一覧・引数や戻り値の定義・変更の有無を機械的に把握できます。  
> このSkillではAST解析によって「どの関数のテストを新規生成・更新・削除すべきか」を判定しています。

**入出力例**

例えば以下のような関数が `app/lib/query_collect.py` に定義されているとする。

```python
def get_vw_data(select_date: str) -> pd.DataFrame:
    """指定日付のVWデータを取得する"""
    psc = generate_pochi_snowflake_connector()
    ...
```

AST解析を実行すると次のようなJSONが得られる。

```json
{
  "file": "app/lib/query_collect.py",
  "hash": "a3f1c2d4e5b6...",
  "signatures": [
    {
      "type": "function",
      "name": "get_vw_data",
      "args": ["select_date"],
      "returns": "pd.DataFrame",
      "docstring": "指定日付のVWデータを取得する",
      "decorators": [],
      "lineno": 10,
      "is_async": false
    }
  ]
}
```

> **`hash` とは？**  
> ファイルの内容全体を一定の計算式で変換して一意の値にしたもの。  
> ファイルの内容が同じなら同じhashになるが、1文字でも変わると全く異なる値になる。  
> Skillはこの値をSTEP 3で台帳と比較することで、「前回から変わったかどうか」を瞬時に判定している。
> ファイルが変わっていなければhashは一致するので、テストを再生成せずスキップできる。

このJSONをSTEP 3の台帳と突き合わせることで、「新規追加」「関数の定義変更」「削除」を判定する。

変更ファイルごとに `/tmp/ast_analyzer.py` を書き出して実行する。

```python
# /tmp/ast_analyzer.py
import ast, json, sys, hashlib
from pathlib import Path

def extract_signatures(filepath: str) -> dict:
    source = Path(filepath).read_text(encoding="utf-8")
    file_hash = hashlib.md5(source.encode()).hexdigest()
    tree = ast.parse(source)
    signatures = []

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name.startswith("__") and node.name.endswith("__"):
                continue
            signatures.append({
                "type": "function",
                "name": node.name,
                "args": [a.arg for a in node.args.args if a.arg != "self"],
                "returns": ast.unparse(node.returns) if node.returns else None,
                "docstring": (ast.get_docstring(node) or "")[:300],
                "decorators": [ast.unparse(d) for d in node.decorator_list],
                "lineno": node.lineno,
                "is_async": isinstance(node, ast.AsyncFunctionDef),
            })
        elif isinstance(node, ast.ClassDef):
            methods = []
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if not (item.name.startswith("__") and item.name.endswith("__")):
                        methods.append({
                            "name": item.name,
                            "args": [a.arg for a in item.args.args if a.arg != "self"],
                            "returns": ast.unparse(item.returns) if item.returns else None,
                            "lineno": item.lineno,
                        })
            signatures.append({
                "type": "class",
                "name": node.name,
                "methods": methods,
                "lineno": node.lineno,
            })

    return {"file": filepath, "hash": file_hash, "signatures": signatures}

if __name__ == "__main__":
    result = extract_signatures(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
```

```bash
python /tmp/ast_analyzer.py app/lib/query_collect.py
```

---

### STEP 3: テスト台帳の照合と差分判定

> **テスト台帳（`tests/test_registry.json`）とは？**  
> 「どのソースファイルの、どの関数のテストを、どのテストファイルに書いたか」をSkillが記録しておくための管理ファイル。  
> Skillはこの台帳を見ることで、前回の実行から何が変わったかを判断し、必要な箇所だけテストを更新できる。  
> 台帳がなければSkillは「何も知らない状態」になり、全関数を新規扱いで再生成してしまう。  
> 台帳はSkillが自動で作成・更新するため、**人が手動で編集する必要はない**。

`tests/test_registry.json` を読み込み、4分類に振り分ける。

```jsonc
{
  "version": 1,
  "last_updated": "2025-01-01T00:00:00",
  "entries": {
    "app/lib/query_collect.py": {
      "test_file": "tests/unit/test_lib_query_collect.py",
      "source_hash": "abc123",
      "tested_functions": ["get_vw_data", "run_query"]
    }
  }
}
```

| 分類 | 条件 | 対応 |
|------|------|------|
| **新規** | 台帳に存在しない関数 | テストを追加生成 |
| **変更** | hashが変わった + 関数名・引数・戻り値が変わった関数 | テストを更新 |
| **削除** | 台帳にあるがソースに存在しない関数 | 対応テストブロックを削除 |
| **変更なし** | hashが一致 | 既存テストを保持（触らない） |

---

### STEP 4: conftest.py の生成・差分追記

**初回**（`tests/conftest.py` が存在しない場合）は全文を生成する。

**2回目以降**（`tests/conftest.py` が存在する場合）は以下の差分チェックを行う。

1. STEP 2のコード解析結果から、テスト対象ファイル内の `session_state` 参照キーを収集する。
   ```bash
   grep -rn "session_state\[" app/lib/ app/app_pages/
   ```
2. 既存の `conftest.py` に含まれていないキーがあれば、追記候補として**ユーザーに提示し確認を得てから追記する**。
3. `# [manual]` コメントがある箇所は保護し、絶対に上書きしない。
4. 追記は既存コードの末尾に付け足すのみ。既存の記述は一切変更しない。

> 追記が必要かどうかの判断はSkillが自動で行うが、**実際の書き込みはユーザー承認後のみ**実施する。

生成・追記する内容は以下の「テスト共通の準備コード（各テスト関数から呼び出して使い回せるモックや共通データ）」を含むこと：

```python
# tests/conftest.py
import pytest
import pandas as pd
from unittest.mock import MagicMock, patch, AsyncMock


# ============================================================
# Pochi Snowflake 接続モック
# pochilib.snowflake.generate_pochi_snowflake_connector() の
# 接続オブジェクトをモックする
# ============================================================

@pytest.fixture
def mock_pochi_snowflake_connector():
    """
    generate_pochi_snowflake_connector() が返すオブジェクトのモック。
    
    Pochiの標準接続パターン:
        psc = generate_pochi_snowflake_connector()
        with psc.connect() as cnx:
            result = cnx.get_records_and_fetchall_with_params(sql, bind_params)
        df = result.fetch_pandas_all()
    
    Usage:
        def test_example(mock_pochi_snowflake_connector):
            psc, cnx, result_mock = mock_pochi_snowflake_connector
            result_mock.fetch_pandas_all.return_value = pd.DataFrame(...)
    """
    result_mock = MagicMock()
    result_mock.fetch_pandas_all.return_value = pd.DataFrame()

    cnx_mock = MagicMock()
    cnx_mock.get_records_and_fetchall_with_params.return_value = result_mock
    cnx_mock.get_records_and_fetchall.return_value = result_mock
    cnx_mock.get_dataframe_from_sqlalchemy_stmt.return_value = pd.DataFrame()
    cnx_mock.__enter__ = MagicMock(return_value=cnx_mock)
    cnx_mock.__exit__ = MagicMock(return_value=False)

    psc_mock = MagicMock()
    psc_mock.connect.return_value = cnx_mock

    with patch(
        "pochilib.snowflake.generate_pochi_snowflake_connector",
        return_value=psc_mock
    ):
        yield psc_mock, cnx_mock, result_mock


@pytest.fixture
def mock_pochi_snowflake_connector_factory():
    """
    テストファイル内のモジュールパスを指定してパッチするファクトリ。
    
    Usage:
        def test_example(mock_pochi_snowflake_connector_factory):
            psc, cnx, result_mock = mock_pochi_snowflake_connector_factory(
                "app.lib.query_collect"  # パッチ対象のモジュールパス
            )
            result_mock.fetch_pandas_all.return_value = pd.DataFrame(...)
    """
    def _factory(module_path: str):
        result_mock = MagicMock()
        result_mock.fetch_pandas_all.return_value = pd.DataFrame()

        cnx_mock = MagicMock()
        cnx_mock.get_records_and_fetchall_with_params.return_value = result_mock
        cnx_mock.get_records_and_fetchall.return_value = result_mock
        cnx_mock.get_dataframe_from_sqlalchemy_stmt.return_value = pd.DataFrame()
        cnx_mock.__enter__ = MagicMock(return_value=cnx_mock)
        cnx_mock.__exit__ = MagicMock(return_value=False)

        psc_mock = MagicMock()
        psc_mock.connect.return_value = cnx_mock

        patcher = patch(
            f"{module_path}.generate_pochi_snowflake_connector",
            return_value=psc_mock
        )
        patcher.start()
        return psc_mock, cnx_mock, result_mock

    yield _factory


# ============================================================
# Streamlit session_state モック
# ============================================================

@pytest.fixture
def mock_st_session_state():
    """
    st.session_state をモックする。
    PochiアプリはDB接続結果などをsession_stateにキャッシュするため、
    テストでも事前にsession_stateに値をセットして使用する。

    Usage:
        def test_example(mock_st_session_state):
            mock_st_session_state["env_identifier"] = "_DEV"
    """
    with patch("streamlit.session_state", {}) as mock_state:
        yield mock_state


# ============================================================
# サンプル DataFrame
# ============================================================

@pytest.fixture
def sample_df():
    """汎用サンプルDataFrame（正常系テスト用）"""
    return pd.DataFrame({
        "col_a": ["value1", "value2", "value3"],
        "col_b": [1, 2, 3],
        "col_c": [1.1, 2.2, 3.3],
    })


@pytest.fixture
def empty_df():
    """空DataFrame（境界値テスト用）"""
    return pd.DataFrame()
```

---

### STEP 5: テストコードの生成・更新

#### テスト分類と生成方針

Pochiアプリの関数は以下の3種類に分類してテストを生成する。

| 関数の種類 | 判定基準 | テスト方法 |
|------------|---------|-----------|
| **Snowflakeクエリ関数** | `generate_pochi_snowflake_connector` を使用 | `mock_pochi_snowflake_connector_factory` でモック |
| **StreamlitUI関数** | `st.` を多用する、ページ描画ロジック | `AppTest.from_function` を使用（Pochi公式推奨） |
| **ユーティリティ関数** | pandas/numpy処理、純粋なデータ変換 | モックなしのシンプルなテスト |

#### Snowflakeクエリ関数のテストパターン（最重要）

Pochiの標準クエリパターン（バインドパラメータ）に合わせたテストを生成する。

```python
# --- [autogen: get_vw_data] --------------------------------
class TestGetVwData:
    """get_vw_data のテスト"""

    def test_正常系_データが返る(self, mock_pochi_snowflake_connector_factory):
        """正常なデータが返ってくることを確認"""
        import pandas as pd
        psc, cnx, result_mock = mock_pochi_snowflake_connector_factory(
            "app.lib.query_collect"
        )
        result_mock.fetch_pandas_all.return_value = pd.DataFrame({
            "年月": ["2024-01-01"],
            "ARPU": [1000.0],
        })

        from app.lib.query_collect import get_vw_data
        result = get_vw_data("2024-01-01")

        assert isinstance(result, pd.DataFrame)
        assert len(result) > 0
        # バインドパラメータが使われていることを確認（SQLインジェクション対策）
        cnx.get_records_and_fetchall_with_params.assert_called_once()

    def test_正常系_空データ(self, mock_pochi_snowflake_connector_factory):
        """空のデータが返ってきても正常に動作することを確認"""
        import pandas as pd
        psc, cnx, result_mock = mock_pochi_snowflake_connector_factory(
            "app.lib.query_collect"
        )
        result_mock.fetch_pandas_all.return_value = pd.DataFrame()

        from app.lib.query_collect import get_vw_data
        result = get_vw_data("2024-01-01")

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0

    def test_異常系_DB接続エラー(self, mock_pochi_snowflake_connector_factory):
        """DB接続エラー時に例外が伝播することを確認"""
        psc, cnx, result_mock = mock_pochi_snowflake_connector_factory(
            "app.lib.query_collect"
        )
        psc.connect.side_effect = Exception("Snowflake connection failed")

        from app.lib.query_collect import get_vw_data
        with pytest.raises(Exception):
            get_vw_data("2024-01-01")
# --- [/autogen: get_vw_data] -------------------------------
```

#### Streamlit UI関数のテストパターン

Pochi基盤チーム推奨の `AppTest.from_function` を使用する。

```python
# --- [autogen: show_analysis_page] -------------------------
class TestShowAnalysisPage:
    """show_analysis_page のテスト（AppTest.from_function 使用）"""

    def test_正常系_ページが描画される(self):
        """ページがエラーなく描画されることを確認"""
        from streamlit.testing.v1 import AppTest

        def _app():
            from app.lib.display_tabs.display_tabs_view import show_analysis_page
            show_analysis_page()

        at = AppTest.from_function(_app, default_timeout=60)
        at.run()
        assert not at.exception

    def test_正常系_ボタン操作後のsession_state(self):
        """ボタンクリック後にsession_stateが更新されることを確認"""
        from streamlit.testing.v1 import AppTest

        def _app():
            import streamlit as st
            from app.lib.display_tabs.display_tabs_view import show_analysis_page
            show_analysis_page()

        at = AppTest.from_function(_app, default_timeout=60)
        at.run()
        assert not at.exception
        # ボタンやウィジェット操作を追加してsession_stateを検証
        # at.button[0].click().run()
        # assert at.session_state["key"] == expected_value
# --- [/autogen: show_analysis_page] ------------------------
```

#### ユーティリティ関数のテストパターン

```python
# --- [autogen: sort_dataframe] -----------------------------
class TestSortDataframe:
    """sort_dataframe のテスト"""

    def test_正常系_ソート済みデータが返る(self, sample_df):
        from app.lib.utility.sort_dataframe import sort_dataframe
        result = sort_dataframe(sample_df, by="col_b")
        assert result["col_b"].is_monotonic_increasing

    def test_異常系_空DataFrameを渡す(self, empty_df):
        from app.lib.utility.sort_dataframe import sort_dataframe
        result = sort_dataframe(empty_df, by="col_b")
        assert len(result) == 0
# --- [/autogen: sort_dataframe] ----------------------------
```

#### テストファイルの構造

```python
# tests/unit/test_lib_query_collect.py
# ============================================================
# pytest-autogen により管理されるファイル
# 手動編集箇所は # [manual] コメントで保護される
# ============================================================
import os
import sys
import pytest

# パス設定: リポジトリルートの app/ をパスに追加
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../app")))

# --- [autogen: 関数名] --- から --- [/autogen: 関数名] --- の間に自動生成コードを配置
```

#### 削除・保護のルール

- 削除対象: `# --- [autogen: 関数名] ---` 〜 `# --- [/autogen: 関数名] ---` のブロックを除去
- 保護対象: `# [manual]` コメントが付いているブロックは更新しない

**再生成の基本ルール（STEP 3の台帳照合が主役）**

Skillは毎回すべてのブロックを再生成するわけではない。
**ソースコードのhashが変わっていない関数のブロックは原則再利用（触らない）**。

```
ソースのhash変化なし  →  既存テストブロックをそのまま保持
ソースのhash変化あり
  └ 関数名・引数・戻り値が変わった  →  該当ブロックのみ更新（autogenブロック内を再生成）
  └ 関数名・引数・戻り値は変わっていない  →  既存テストブロックをそのまま保持
ソースから関数が削除   →  対応ブロックを削除
```

**`# [manual]` が必要なケース**

「関数の引数や戻り値は変わっていないが、テストの期待値やロジックを手動で細かく調整した」場合、
hashが変わった別の関数の更新時に誤って上書きされるリスクがある。
そういった場合に `# [manual]` で明示的に保護する。

```python
# --- [autogen: get_vw_data] --------------------------------
# [manual]  ← 関数の引数・戻り値が変わったときもSkillに上書きさせたくない場合に追記
class TestGetVwData:
    """get_vw_data のテスト（手動調整済み）"""

    def test_正常系_データが返る(self, mock_pochi_snowflake_connector_factory):
        psc, cnx, result_mock = mock_pochi_snowflake_connector_factory(
            "app.lib.query_collect"
        )
        result_mock.fetch_pandas_all.return_value = pd.DataFrame({
            "年月": ["2024-01-01"],
            "ARPU": [1234.5],   # ← 実際のデータに合わせて手動で修正した値
        })
        result = get_vw_data("2024-01-01")
        assert result["ARPU"].iloc[0] == 1234.5  # ← 手動で追加したアサーション
# --- [/autogen: get_vw_data] -------------------------------
```

> `# [manual]` は「ソースが変わってもSkillに触らせたくない」場合の追加保護。
> 通常（ソースが変わっていない）は `# [manual]` がなくても既存テストは保持される。

---

### STEP 6: テスト実行

このSkillが生成するテストは常に `tests/unit/` に配置されているため、実行パスは固定。
パッケージマネージャーはSTEP 0で確認した内容に合わせる。

```bash
cd {project-root}   # リポジトリルートで実行する

# Phase4（uv）の場合
uv run --directory app pytest tests/unit/ \
  -v \
  --tb=short \
  --cov=app \
  --cov-report=term-missing \
  --cov-report=json:tests/test_results/coverage.json \
  2>&1 | tee tests/test_results/pytest_output.txt

# Phase3（poetry）の場合
cd app && poetry run pytest ../tests/unit/ \
  -v \
  --tb=short \
  --cov=. \
  --cov-report=term-missing \
  --cov-report=json:../tests/test_results/coverage.json \
  2>&1 | tee ../tests/test_results/pytest_output.txt

echo "Exit code: $?"
```

> `pyproject.toml` に `addopts` が設定されている場合はそちらが優先されるため、重複オプションに注意。

---

### STEP 7: レポート生成

`app/tests/test_results/report_YYYYMMDD_HHMMSS.md` に以下の構成でMarkdownレポートを出力する。

```markdown
# テスト実行レポート

**実行日時**: {{TIMESTAMP}}
**対象ブランチ**: {{BRANCH}}
**実行コマンド**: `uv run pytest app/tests/ -v --tb=short --cov=app/lib`

---

## サマリー

| 項目 | 件数 |
|------|------|
| テスト総数 | - |
| ✅ 成功 | - |
| ❌ 失敗 | - |
| ⚠️ エラー | - |
| カバレッジ (app/lib) | -% |

**総合判定**: ✅ PASSED / ❌ FAILED

---

## 今回の差分（変更されたテスト）

### ➕ 追加されたテスト
### ✏️ 更新されたテスト
### 🗑️ 削除されたテスト

---

## ❌ 失敗・エラー詳細

（失敗ごとに、エラーメッセージと考えられる原因を記載）

---

## カバレッジレポート (app/lib)

| ファイル | カバレッジ | 未カバー行 |
|---------|----------|----------|

> 70%未満のファイルは ⚠️ で表示

---

## 成功テスト一覧

<details>
<summary>成功した N 件を表示</summary>
（テーブル形式）
</details>

---

## レビュワーへのアクションアイテム

- [ ] （失敗テストの対応方針）

---

## Pochi固有の確認事項

- [ ] Snowflakeクエリ関数でバインドパラメータが使われていることを確認（SQLインジェクション対策）
- [ ] `generate_pochi_snowflake_connector` が正しくモックされていることを確認
- [ ] Snowflake接続情報（パスワード、秘密鍵等）がテストコードに含まれていないことを確認
```

---

### STEP 8: 台帳の更新

レポート生成後、`tests/test_registry.json` を最新の状態に更新する。

---

## Pochi固有の注意事項

### Snowflake接続のモックについて

Pochiの標準接続パターンは `generate_pochi_snowflake_connector()` を使う。テストでは以下のようにパッチする。

```python
# テスト対象モジュールのパスでパッチすること（pochilib側ではなく）
with patch("app.lib.query_collect.generate_pochi_snowflake_connector") as mock_gen:
    mock_psc = MagicMock()
    mock_gen.return_value = mock_psc
    # ...
```

### session_stateの扱い

Pochiアプリは処理の中で `st.session_state` を参照する関数が多い。
テスト時はアプリが起動していないため session_state が空の状態になっており、
事前に必要なキーをセットしておかないと `KeyError` でテストが落ちる。

**よくあるパターン: `env_identifier`（環境識別子）**

例えば `pochi-sogo-arpu-analysis-repository` の `query_collect.py` では、
クエリ対象のテーブル名の末尾に `env_identifier` を付け足すことで
本番/開発のテーブルを切り替えている。

```python
# app/lib/query_collect.py（実際のコード）
table_name = (
    "USERDB_B_P01_LAK.USER_MP001_01.POCHI_APP_ARPU_MIN_GRAN_AGGREGATION"
    + st.session_state["env_identifier"]  # 本番: "" / 開発: "_DEV"
)
```

このため、`get_vw_data()` をテストするには事前に `env_identifier` をセットする必要がある。

```python
# テストコード例
import streamlit as st

def test_正常系_データが返る(self, mock_pochi_snowflake_connector_factory):
    # session_stateを事前にセット（これがないとKeyErrorで落ちる）
    st.session_state["env_identifier"] = "_DEV"

    psc, cnx, result_mock = mock_pochi_snowflake_connector_factory(
        "app.lib.query_collect"
    )
    result_mock.fetch_pandas_all.return_value = pd.DataFrame({"年月": ["2024-01-01"]})

    result = get_vw_data("2024-01-01")
    assert isinstance(result, pd.DataFrame)
```

**テスト対象の関数がどのキーを参照しているか確認する方法**

```bash
# 対象ファイル内の session_state 参照をすべて洗い出す
grep -n "session_state" app/lib/query_collect.py
```

参照しているキーを漏れなくセットすること。セットし忘れると `KeyError` になる。

### SQLインジェクション対策の検証

Pochiのアンチパターンドキュメントに従い、テストでバインドパラメータの使用を検証する。

```python
# f文字列や文字列結合でのSQL生成が行われていないことを間接的に確認
cnx.get_records_and_fetchall_with_params.assert_called_once()
# get_records_and_fetchall（バインドなし）は呼ばれていないこと
cnx.get_records_and_fetchall.assert_not_called()
```

### 絶対に含めてはいけないもの

- Snowflakeの接続情報（アカウント名、ユーザー名、パスワード、秘密鍵）
- GCPのサービスアカウントキー
- Secret Managerのシークレット名
- 本番環境のテーブル名（ハードコード）

---

## 実行のトリガー例

```
「pytestを自動生成・実行してレポートを出して」
「app/lib/query_collect.py のテストを更新して実行して」
「全ファイルのテストを再スキャンして実行して」
「lib/utility/sort_dataframe.py のテストを生成して」
```

---

## 注意事項

- `tests/conftest.py` は初回のみ生成。その後は触らない。
- 既存の `app/tests/` 配下のテストファイルには手を加えない。
- `# [manual]` コメントで保護されたブロックは更新しない。
- Snowflake接続情報はテストコードに絶対に含めない。
- テスト実行はコーディング環境（Cloud Workstations）で行い、本番環境では実行しない。
- `AppTest.from_function` を使う場合、`default_timeout=60` を必ず設定する（Pochi推奨）。