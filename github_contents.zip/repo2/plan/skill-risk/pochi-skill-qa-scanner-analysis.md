# pochi-skill-qa-scanner 調査レポート

**調査日**: 2026-05-11  
**対象ファイル**:
- `.claude/skills/pochi-skill-qa-scanner/SKILL.md`
- `.claude/agents/skill-qa-runner.md`
- `.claude/agents/skill-vuln-scanner.md`
- `.claude/agents/skill-docs-checker.md`
- `plan/skill-risk/スキルリスク管理ガイド.md`

---

## 1. pochi-skill-qa-scanner の全体構造

3つのサブエージェントを並列実行し、5ステップで統合診断する。

```
STEP 0: 対象スキル選択（skills.json の一覧表示 → 番号 or A で全件）
STEP 1: 3サブエージェントを並列起動
STEP 2: 統合レポート生成
STEP 3: Tier 自動判定（Tier 1〜3）
STEP 4: 展開前チェックシート生成（Phase 1〜5）
STEP 5: レポート保存（output/ 配下に qa-scan-*.md + risk-check-*.md）
```

---

## 2. 各サブエージェントのチェック観点

### サブエージェントA: skill-qa-runner（動作テスト12項目 + 設計品質8項目）

#### 動作テスト

| チェック | 観点 |
|---|---|
| チェック0 | 正式スキルファイル探索（`skills/<category>/<id>/skills/run/SKILL.md` の存在） |
| チェック1 | 必須パラメータ定義（`Input`/`Parameter`セクション） |
| チェック2 | 参照スキルの存在確認 |
| チェック3 | Input パス形式の正しさ |
| チェック4 | Input ディレクトリの存在 |
| チェック5 | Output パス形式の正しさ |
| チェック5-B | `skills/run/SKILL.md` の存在（スキルシステム起動ファイル） |
| チェック5-C | `enabledPlugins` への登録確認 |
| チェック6 | エラーなし完了（実行テスト） |
| チェック7 | 完了到達（クラッシュ・タイムアウトなし） |
| チェック8 | Output ディレクトリの存在 |
| チェック9 | output/ にファイル生成済みか |
| チェック10 | output/ に空ファイルがないか |

#### 設計品質

| チェック | 観点 |
|---|---|
| Q1 | YAML Frontmatter（`---` + `name` + `description`） |
| Q2 | `input_schema` 定義の有無 |
| Q3 | 推奨4セクション構成（Overview/Workflow/Rules/Output） |
| Q4 | Chain of Thought（重複見出しなし + 番号付きステップ） |
| Q5 | Validation Steps セクションの有無 |
| Q6 | Error Handling セクションの有無 |
| Q7 | 外部アセット（prompts//assets/）活用（200行超の場合） |
| Q8 | 段階的開示（description 20文字+ / 本文50行+） |

---

### サブエージェントB: skill-vuln-scanner（OWASP/CWE ベース、8カテゴリ）

外部接続コードを自動検出してから、該当カテゴリのみチェックする。

| カテゴリ | 観点 | 項目数 |
|---|---|:---:|
| A: 入力バリデーション | SQLインジェクション防止・パラメータ化クエリ・LIMIT上限等 | 7 |
| B: 認証・資格情報 | ハードコードなし・安全なトークン取得・認証情報ログ漏洩防止 | 5 |
| C: 通信・セッション | HTTPS強制・SSL証明書検証・タイムアウト | 5 |
| D: エラーハンドリング | 裸の `except:` 禁止・機密情報漏洩防止 | 5 |
| E: 破壊的操作防止 | 任意SQL実行・`shell=True`・パストラバーサル | 7 |
| F: データ保護 | .gitignore・LLMプロンプトインジェクション・データ最小化 | 6 |
| G: 依存ライブラリ | `yaml.load` SafeLoader・`eval`/`exec` 禁止・バージョン固定 | 6 |
| H: 権限・並行処理 | 最小権限・排他制御・環境変数サニタイズ | 5 |

重大度は **HIGH / MEDIUM / LOW** の3段階。

---

### サブエージェントC: skill-docs-checker（整合性12項目）

| ID | 観点 |
|---|---|
| D-1 | フロントマター必須フォーム（name/description/トリガーフレーズ） |
| D-2 | Progressive Disclosure（段階的開示） |
| D-3 | `plugin.json` 必須フィールド（name/description/version/keywords/license） |
| D-4 | `marketplace.json` エントリ整合性 |
| D-5 | `skills.json` エントリ整合性（path/triggers/auto_load等） |
| D-6 | `name` 一致性（marketplace.json / skills.json / plugin.json の3ファイル横断） |
| D-7 | 正式スキルファイル配置（`skills/<category>/<id>/skills/run/SKILL.md`） |
| D-8 | `README.md` 登録（3箇所: 一覧/install/一括インストール） |
| D-9 | `SKILLS_MANAGEMENT.md` 登録 |
| D-10 | SKILL.md 推奨セクション構成（4セクション） |
| D-11 | トリガーフレーズ定義（skills.json + SKILL.md 両方） |
| D-12 | 簡潔さ原則（冗長記述なし） |

---

## 3. 総合評価の判定基準

| 評価 | 条件 |
|---|---|
| ✅ 合格 | 動作テスト ≥ 10/12 かつ HIGH脆弱性 = 0 かつ 整合性 ≥ 9/12 |
| ⚠️ 要改善 | HIGH脆弱性 = 0 かつ上記未満 |
| ❌ 要対応 | HIGH脆弱性 1件以上 or 動作テスト < 8/12 |

---

## 4. スキルリスク管理ガイドとの乖離

### 4.1 ガイドファイルを参照していない

`plan/skill-risk/スキルリスク管理ガイド.md` を Read で読み込む指示がどこにもない。

SKILL.md には「スキルリスク管理ガイド §3.1」「スキルリスク管理ガイド §11」という名称の言及はあるが、ファイルを動的に読まずにガイドの内容を SKILL.md 内にハードコードして代替している。

ガイドが更新されても QA スキャナーに自動反映されない乖離リスクがある。

---

### 4.2 Tier 判定ロジックの差異

| 観点 | スキルリスク管理ガイド §3.1 | pochi-skill-qa-scanner STEP 3 |
|---|---|---|
| 判定方法 | フローチャート（読取のみ→Tier1、ファイル生成/編集→Tier2、外部システム操作→Tier3） | キーワードマッチング（SKILL.mdの文字列を検索） |
| Tier 3 判定キーワード | git push / git commit --amend / DB INSERT/UPDATE/DELETE / 外部API POST/PUT/DELETE / poetry update / Slack実送信 | ほぼ同等 |
| Tier 2 判定キーワード | ファイル生成・編集（git管理下で取り消し可能）/ ローカル git commit | `Write`/`Edit`ツール記述 /「ファイルを生成」等のキーワード / `git commit` |
| Tier 1 判定 | ファイル・データの読取のみ | 上記いずれも未検出 |
| `/tmp` 等git管理外への一時出力 | Tier 2（条件付き: 出力先・影響範囲をSKILL.mdに明記が必要） | **考慮なし** |
| git管理外への書き込み | Tier 3 | **考慮なし** |

---

### 4.3 チェックシートの差異

| 観点 | ガイド §9.3 早見表 | QA scanner STEP 4 |
|---|---|---|
| Tier別の必須項目絞り込み | あり（Tier 1は約12項目のみ必須、Tier 3は全項目必須） | **なし（Tier問わず同一項目を全出力）** |
| 2.1 Tier分類完了の判定基準 | ガイド §5 の Tier分類一覧に登録済みであること | `plugin.json` の `"tier"` フィールドの有無のみ |

---

## 5. まとめ

- Tier判定自体は**実施している**
- ガイドの判定フローを**動的に読み込まず**にキーワードマッチングで代替しているため、ガイド更新が追従しない
- **Tier別の必須チェック項目絞り込み**（ガイド §9.3 早見表）がチェックシートに未反映
- `/tmp` 等git管理外への書き込みケースなど、ガイドの細かい判定が抜け落ちている
