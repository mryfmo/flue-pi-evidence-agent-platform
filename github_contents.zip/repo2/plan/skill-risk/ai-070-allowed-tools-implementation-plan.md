# AI-070 実施計画：pochi-skill-tier-checker の allowed-tools フロントマター追加

**作成日**: 2026-05-17  
**ステータス**: 実施中  
**関連タスク**: AI-070（スキルのYAMLフロントマターに `allowed_tools` を必須化）  
**関連ドキュメント**:
- `plan/skill-risk/tier-process-optimization-plan.md`（最適化計画全体）
- `.claude/skills/pochi-skill-tier-checker/SKILL.md`（修正対象）

---

## 1. 背景

AI-070「スキルの YAMLフロントマターに `allowed_tools` を必須化し、機械的なティア分けの仕組みを組み込む」の完了条件のうち、フロントマターへの `allowed-tools` 追加が未対応のまま残っている。

参照実装として、`pochi-spec-initializer` が唯一 `allowed-tools` を記載済みのスキルである（v1.2.0）。

---

## 2. 現状の完了状態

| 完了条件 | 状態 | 備考 |
|---|---|---|
| T-1: セキュリティ診断定義.md の新規作成 | ✅ 完了 | `.claude/skills/pochi-skill-tier-checker/セキュリティ診断定義.md` として作成済み（v1.0） |
| T-2-1: SKILL.md に STEP -1 を追加 | ✅ 完了 | 起動直後に2ファイルを Read する STEP -1 を実装済み |
| SKILL.md フロントマターに `allowed-tools` フィールドを追加 | ❌ **未対応** | 今回の実施対象 |
| tier-checker を起動して STEP -1 の動作確認 | ⬜ 手動確認要 | 実装完了後に手動実施 |

---

## 3. 修正対象ファイル

**1ファイルのみ**

| ファイル | 変更内容 |
|---|---|
| `.claude/skills/pochi-skill-tier-checker/SKILL.md` | フロントマターに `allowed-tools` フィールドを追加 |

---

## 4. 変更内容の詳細

### 4.1 追加する `allowed-tools` の値

SKILL.md 本文で使用しているツールを網羅すると以下の通り：

| ツール | 使用箇所 |
|---|---|
| `Read` | STEP -1（定義ドキュメント読み込み）、STEP 0（skills.json）、STEP 0.5（SKILL.md） |
| `Write` | STEP 4（チェックシート保存）、STEP 5（QAレポート保存） |
| `Glob` | STEP 1（スキルディレクトリのパス解決） |
| `Bash` | STEP 6（git add / commit / push） |

したがって追加するフィールド：

```yaml
allowed-tools: Read, Write, Glob, Bash
```

### 4.2 変更前後

**変更前（現行フロントマター）:**

```yaml
---
name: pochi-skill-tier-checker
description: >-
  Skillの品質テスト・セキュリティ診断・公式ドキュメント整合性を3つのカスタムサブエージェントで統合診断する。
  「スキルをQAスキャンして」「skill-tier-checkerを起動」「Skillの品質診断して」「Skillのセキュリティと品質をチェックして」
  「公式ドキュメントとの整合性をチェックして」「Skillを総合診断して」などと言われたときに起動する。
---
```

**変更後:**

```yaml
---
name: pochi-skill-tier-checker
description: >-
  Skillの品質テスト・セキュリティ診断・公式ドキュメント整合性を3つのカスタムサブエージェントで統合診断する。
  「スキルをQAスキャンして」「skill-tier-checkerを起動」「Skillの品質診断して」「Skillのセキュリティと品質をチェックして」
  「公式ドキュメントとの整合性をチェックして」「Skillを総合診断して」などと言われたときに起動する。
allowed-tools: Read, Write, Glob, Bash
---
```

変更箇所は `---` の直前に1行を追加するのみ。

---

## 5. ティア判定への影響

`allowed-tools` の内容に基づく機械的ティア判定（AI-070 の本来の目的）：

| 検出ツール | 最大ティア |
|---|---|
| Read のみ | Tier 1 |
| Write / Glob / Grep | Tier 2 |
| **Bash（git操作）** | **Tier 2** |
| Bash（外部API・Webhook）| Tier 3 |

→ `pochi-skill-tier-checker` は **Tier 2**（書き込み系）に機械的に分類される。

---

## 6. 検証手順

1. SKILL.md のフロントマターを目視確認
   - `name` / `description` / `allowed-tools` の3フィールドが存在すること
   - `allowed-tools` の記法が `pochi-spec-initializer` と同形式（カンマ区切り）であること
2. `/reload-plugins` を実行し、スキルが正常に認識されることを確認
3. `pochi-skill-tier-checker` を起動し、STEP -1 の動作（定義ドキュメントの読み込み）を確認

---

## 7. 参考：フロントマター記法（既存実装）

`skills/spec/pochi-spec-initializer/skills/run/SKILL.md` より：

```yaml
---
name: pochi-spec-initializer
description: >-
  仕様駆動開発フレームワークのInitializerとして動作し、質問ベースで仕様書と実装計画を生成します。
allowed-tools: Read, Write, Glob, Grep, AskUserQuestion
---
```

キー名は `allowed-tools`（ハイフン区切り）、値はカンマ区切りのツール名リスト。
