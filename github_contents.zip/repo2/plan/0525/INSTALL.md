# Report Creator Claude Code Production Bundle

This bundle installs `report-creator` as a project-level Claude Code production workflow with four layers:

1. Skill: `.claude/skills/report-creator/SKILL.md`
2. Workflow documentation: `docs/PRODUCTION_WORKFLOW.md`
3. SubAgents: `.claude/agents/report-*.md`
4. Hooks and permission policy: `.claude/hooks/*.py` and `.claude/settings.json`

## Install into a project

From the root of the target repository, copy or merge the `.claude` directory from this bundle:

```bash
cp -R /path/to/report-creator-claude-code-production/.claude ./.claude
```

If the project already has `.claude/settings.json`, merge the `permissions` and `hooks` sections rather than overwriting existing policy. Deny rules should remain stricter than allow rules.

## Validate the bundle before use

```bash
python3 tools/validate_production_bundle.py
python3 .claude/skills/report-creator/scripts/validate_skill_package.py
python3 .claude/skills/report-creator/scripts/smoke_test.py --work-dir /tmp/report-creator-smoke
```

Expected results:

```text
PRODUCTION BUNDLE VALIDATION PASSED
PASS
SMOKE TEST PASSED
```

## Use

Start Claude Code from the project root and invoke:

```text
/report-creator [input_file?] [document_type?] [target?]
```

Examples:

```text
/report-creator ./docs/meeting-notes.md discussion mixed
/report-creator ./docs/analysis.md analysis engineer
/report-creator roadmap bizlead
```

## Production behavior

- Report Spec JSON is written under `.report-creator/specs/`.
- HTML is written under `reports/generated/`.
- Tool audit events are appended to `.report-creator/audit/tool-events.jsonl`.
- The Stop hook blocks final completion until machine validation passes and all required SubAgents return `decision: pass`.
- Network access is denied for this production workflow.
- Arbitrary Bash is blocked while the workflow is active; only bundled report validation/rendering scripts are allowed.

## Intentionally aborting a run

If a run must be cancelled, record the reason in your project issue tracker or change log, then remove the active state file:

```bash
rm .report-creator/state/<session-id>.json
```

This is an explicit abort path, not a silent bypass.
