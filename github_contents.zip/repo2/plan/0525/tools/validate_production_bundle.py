#!/usr/bin/env python3
"""Validate the report-creator Claude Code production bundle."""
from __future__ import annotations

import contextlib
import importlib.util
import io
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
REQUIRED_FILES = [
    ".claude/settings.json",
    ".claude/skills/report-creator/SKILL.md",
    ".claude/skills/report-creator/scripts/validate_spec.py",
    ".claude/skills/report-creator/scripts/render_report.py",
    ".claude/skills/report-creator/scripts/validate_report.py",
    ".claude/agents/report-input-auditor.md",
    ".claude/agents/report-quality-reviewer.md",
    ".claude/agents/report-compliance-reviewer.md",
    ".claude/hooks/report_creator_prompt_expansion.py",
    ".claude/hooks/report_creator_pretool_guard.py",
    ".claude/hooks/report_creator_posttool_audit.py",
    ".claude/hooks/report_creator_stop_gate.py",
    "docs/PRODUCTION_WORKFLOW.md",
    "docs/OPERATIONS_RUNBOOK.md",
    "docs/DESIGN_DECISIONS.md",
]
REQUIRED_SETTINGS_HOOKS = ["UserPromptExpansion", "PreToolUse", "PostToolUse", "PostToolUseFailure", "Stop"]
REQUIRED_AGENTS = ["report-input-auditor", "report-quality-reviewer", "report-compliance-reviewer"]
_MODULE_CACHE: dict[str, Any] = {}


def fail(message: str) -> None:
    print("PRODUCTION BUNDLE VALIDATION FAILED")
    print(f"- {message}")
    raise SystemExit(1)


def load_hook_module(script: str) -> Any:
    if script in _MODULE_CACHE:
        return _MODULE_CACHE[script]
    path = ROOT / ".claude" / "hooks" / script
    spec = importlib.util.spec_from_file_location(script.replace(".", "_"), path)
    if spec is None or spec.loader is None:
        fail(f"cannot load hook module: {script}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _MODULE_CACHE[script] = module
    return module


def run_hook(script: str, event: dict[str, Any], project_dir: Path) -> tuple[int, str, str]:
    module = load_hook_module(script)
    old_stdin = sys.stdin
    old_env = os.environ.get("CLAUDE_PROJECT_DIR")
    stdout = io.StringIO()
    stderr = io.StringIO()
    try:
        os.environ["CLAUDE_PROJECT_DIR"] = str(project_dir)
        sys.stdin = io.StringIO(json.dumps(event, ensure_ascii=False))
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            rc = int(module.main() or 0)
    finally:
        sys.stdin = old_stdin
        if old_env is None:
            os.environ.pop("CLAUDE_PROJECT_DIR", None)
        else:
            os.environ["CLAUDE_PROJECT_DIR"] = old_env
    return rc, stdout.getvalue().strip(), stderr.getvalue().strip()


def parse_json_output(stdout: str) -> dict[str, Any]:
    if not stdout:
        return {}
    try:
        return json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise AssertionError(f"Hook stdout is not JSON: {stdout}") from exc


def permission_decision(stdout: str) -> str | None:
    data = parse_json_output(stdout)
    return (data.get("hookSpecificOutput") or {}).get("permissionDecision")


def validate_static() -> None:
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).exists():
            fail(f"missing required file: {rel}")

    try:
        settings = json.loads((ROOT / ".claude" / "settings.json").read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f"settings.json is invalid JSON: {exc}")

    hooks = settings.get("hooks") or {}
    for event_name in REQUIRED_SETTINGS_HOOKS:
        if event_name not in hooks:
            fail(f"settings.json missing hook event: {event_name}")

    permissions = settings.get("permissions") or {}
    deny = "\n".join(permissions.get("deny") or [])
    for tool in ["WebFetch", "WebSearch", "Bash(curl *)", "Bash(wget *)"]:
        if tool not in deny:
            fail(f"settings.json missing deny rule: {tool}")

    skill = (ROOT / ".claude" / "skills" / "report-creator" / "SKILL.md").read_text(encoding="utf-8")
    for agent in REQUIRED_AGENTS:
        if f"Agent({agent})" not in skill or agent not in skill:
            fail(f"SKILL.md does not require/preapprove agent: {agent}")
    if "Bash(python3 *)" in skill:
        fail("SKILL.md contains overbroad Bash(python3 *) permission")
    if "hooks:" in skill.split("---", 2)[1]:
        fail("SKILL.md should not carry production hooks in skill frontmatter; hooks belong in .claude/settings.json")

    for agent in REQUIRED_AGENTS:
        body = (ROOT / ".claude" / "agents" / f"{agent}.md").read_text(encoding="utf-8")
        if f"name: {agent}" not in body:
            fail(f"agent file has missing or mismatched name: {agent}")
        if "disallowedTools: Bash, Edit, Write, WebFetch, WebSearch" not in body:
            fail(f"agent is not explicitly read-only enough: {agent}")


def validate_hooks() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        project = Path(tmp)
        sid = "test-session"
        base_event = {"session_id": sid, "cwd": str(project), "permission_mode": "default"}

        rc, out, err = run_hook(
            "report_creator_prompt_expansion.py",
            {**base_event, "hook_event_name": "UserPromptExpansion", "command_name": "report-creator", "command_args": "analysis mixed", "prompt": "/report-creator analysis mixed"},
            project,
        )
        if rc != 0:
            fail(f"prompt expansion hook failed: {err}")
        if "additionalContext" not in out:
            fail("prompt expansion hook did not emit additionalContext")
        state_path = project / ".report-creator" / "state" / f"{sid}.json"
        if not state_path.exists():
            fail("prompt expansion hook did not create active state")

        dangerous = {**base_event, "hook_event_name": "PreToolUse", "tool_name": "Bash", "tool_input": {"command": "curl https://example.com"}}
        rc, out, err = run_hook("report_creator_pretool_guard.py", dangerous, project)
        if rc != 0 or permission_decision(out) != "deny":
            fail("pretool guard did not deny network Bash")

        allowed_cmd = f"python3 {ROOT}/.claude/skills/report-creator/scripts/validate_spec.py --spec x --document-type analysis --target mixed"
        allowed = {**base_event, "hook_event_name": "PreToolUse", "tool_name": "Bash", "tool_input": {"command": allowed_cmd}}
        rc, out, err = run_hook("report_creator_pretool_guard.py", allowed, project)
        if rc != 0 or permission_decision(out) != "allow":
            fail("pretool guard did not allow bundled validator command")

        web = {**base_event, "hook_event_name": "PreToolUse", "tool_name": "WebSearch", "tool_input": {"query": "anything"}}
        rc, out, err = run_hook("report_creator_pretool_guard.py", web, project)
        if rc != 0 or permission_decision(out) != "deny":
            fail("pretool guard did not deny WebSearch")

        bad_write = {**base_event, "hook_event_name": "PreToolUse", "tool_name": "Write", "tool_input": {"file_path": str(project / "README.md"), "content": "x"}}
        rc, out, err = run_hook("report_creator_pretool_guard.py", bad_write, project)
        if rc != 0 or permission_decision(out) != "deny":
            fail("pretool guard did not deny uncontrolled write")

        for command, stdout_text in [
            ("python3 validate_spec.py", "SPEC VALIDATION PASSED\n"),
            ("python3 render_report.py", str(project / "reports" / "generated" / "analysis_20260101000000.html") + "\n"),
            ("python3 validate_report.py", "VALIDATION PASSED\n"),
        ]:
            event = {**base_event, "hook_event_name": "PostToolUse", "tool_name": "Bash", "tool_input": {"command": command}, "tool_response": {"stdout": stdout_text, "stderr": "", "interrupted": False, "isImage": False}}
            rc, out, err = run_hook("report_creator_posttool_audit.py", event, project)
            if rc != 0:
                fail(f"posttool audit hook failed: {err}")

        for agent in REQUIRED_AGENTS:
            event = {**base_event, "hook_event_name": "PostToolUse", "tool_name": "Agent", "tool_input": {"subagent_type": agent}, "tool_response": {"status": "completed", "content": [{"type": "text", "text": "decision: pass"}]}}
            rc, out, err = run_hook("report_creator_posttool_audit.py", event, project)
            if rc != 0:
                fail(f"posttool audit hook failed for {agent}: {err}")

        state = json.loads(state_path.read_text(encoding="utf-8"))
        if not state.get("spec_validated") or not state.get("html_validated") or not state.get("last_rendered_html"):
            fail("posttool audit hook did not update validation state")
        if set(state.get("subagents_completed") or []) != set(REQUIRED_AGENTS):
            fail("posttool audit hook did not record all required subagents")
        decisions = state.get("subagent_decisions") or {}
        if any(decisions.get(agent) != "pass" for agent in REQUIRED_AGENTS):
            fail("posttool audit hook did not record pass decisions for all required subagents")

        # A non-pass reviewer decision must keep the Stop gate closed.
        state["subagent_decisions"][REQUIRED_AGENTS[0]] = "revise"
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        rc, out, err = run_hook("report_creator_stop_gate.py", {**base_event, "hook_event_name": "Stop"}, project)
        if rc != 0 or '"decision": "block"' not in out:
            fail("stop gate did not block a non-pass subagent decision")
        state["subagent_decisions"][REQUIRED_AGENTS[0]] = "pass"
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

        rc, out, err = run_hook("report_creator_stop_gate.py", {**base_event, "hook_event_name": "Stop"}, project)
        if rc != 0:
            fail(f"stop gate failed: {err}")
        if out:
            fail("stop gate blocked a fully completed run")
        state = json.loads(state_path.read_text(encoding="utf-8"))
        if state.get("active"):
            fail("stop gate did not mark completed run inactive")


def main() -> int:
    validate_static()
    validate_hooks()
    print("PRODUCTION BUNDLE VALIDATION PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
