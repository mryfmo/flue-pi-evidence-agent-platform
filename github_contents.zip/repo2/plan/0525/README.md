# report-creator-claude-code-production

Production-grade Claude Code bundle for creating self-contained Japanese HTML reports.

The package deliberately separates responsibilities:

- **Skill**: user-facing `/report-creator` command and report generation contract.
- **Workflow**: deterministic phases, artifacts, validation gates, and failure handling.
- **SubAgents**: isolated input audit, quality review, and compliance review.
- **Hooks**: deterministic runtime enforcement, auditing, and stop-gate control.

Use `INSTALL.md` first. Read `docs/PRODUCTION_WORKFLOW.md` for the operating model.
