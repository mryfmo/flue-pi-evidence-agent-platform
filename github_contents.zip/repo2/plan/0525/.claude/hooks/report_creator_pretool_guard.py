#!/usr/bin/env python3
"""PreToolUse guard for the report-creator production workflow."""
from __future__ import annotations

import json
import os
import re
import shlex
import sys
from pathlib import Path
from typing import Any

ALLOWED_SUBAGENTS = {"report-input-auditor", "report-quality-reviewer", "report-compliance-reviewer"}
ALLOWED_SCRIPT_NAMES = {
    "validate_spec.py",
    "render_report.py",
    "validate_report.py",
    "validate_skill_package.py",
    "smoke_test.py",
}
SENSITIVE_PATH_PARTS = {
    ".env",
    "secrets",
    "secret",
    "credentials",
    "credential",
    ".aws",
    ".ssh",
    "id_rsa",
    "id_ed25519",
    "private_key",
    "token",
}
DANGEROUS_BASH_PATTERNS = [
    r"\brm\s+-rf\b",
    r"\bsudo\b",
    r"\bchmod\s+777\b",
    r"\bchown\b",
    r"\bcurl\b",
    r"\bwget\b",
    r"\bnc\b",
    r"\bnetcat\b",
    r"\bssh\b",
    r"\bscp\b",
    r"\brsync\b",
    r"\bpip\s+install\b",
    r"\bnpm\s+install\b",
    r"\bbrew\s+install\b",
    r"\bapt(-get)?\s+install\b",
    r"\bpython3?\s+-c\b.*\b(http|socket|subprocess|os\.system)\b",
]


def project_root(event: dict[str, Any]) -> Path:
    return Path(os.environ.get("CLAUDE_PROJECT_DIR") or event.get("cwd") or os.getcwd()).resolve()


def load_state(root: Path, sid: str) -> dict[str, Any] | None:
    path = root / ".report-creator" / "state" / f"{sid}.json"
    if not path.exists():
        return None
    try:
        state = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    return state if state.get("active") else None


def decision(kind: str, reason: str, *, additional_context: str | None = None) -> int:
    output: dict[str, Any] = {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": kind,
            "permissionDecisionReason": reason,
        }
    }
    if additional_context:
        output["hookSpecificOutput"]["additionalContext"] = additional_context
    print(json.dumps(output, ensure_ascii=False))
    return 0


def deny(reason: str) -> int:
    return decision("deny", reason)


def allow(reason: str) -> int:
    return decision("allow", reason)


def is_sensitive_path(value: str) -> bool:
    lowered = value.lower().replace("\\", "/")
    parts = set(Path(lowered).parts)
    return any(part in lowered or part in parts for part in SENSITIVE_PATH_PARTS)


def is_within(child: Path, parent: Path) -> bool:
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def path_from_input(root: Path, value: str) -> Path:
    p = Path(value).expanduser()
    if not p.is_absolute():
        p = root / p
    return p.resolve(strict=False)


def allowed_write_path(root: Path, file_path: str) -> bool:
    p = path_from_input(root, file_path)
    allowed_roots = [
        root / ".report-creator" / "specs",
        root / ".report-creator" / "work",
        root / ".report-creator" / "audit",
        root / "reports" / "generated",
    ]
    return any(is_within(p, allowed.resolve(strict=False)) for allowed in allowed_roots)


def command_mentions_report_creator(command: str) -> bool:
    return "report-creator" in command or "report_creator" in command or any(name in command for name in ALLOWED_SCRIPT_NAMES)


def script_basename_from_command(command: str) -> str | None:
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    for part in parts:
        name = Path(part).name
        if name in ALLOWED_SCRIPT_NAMES:
            return name
    return None


def bash_is_allowed(command: str) -> bool:
    first_script = script_basename_from_command(command)
    if first_script not in ALLOWED_SCRIPT_NAMES:
        return False
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    if not parts:
        return False
    executable = Path(parts[0]).name
    return executable in {"python", "python3"}


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except json.JSONDecodeError:
        return 0

    root = project_root(event)
    sid = str(event.get("session_id") or "unknown-session")
    state = load_state(root, sid)
    tool_name = str(event.get("tool_name") or "")
    tool_input = event.get("tool_input") or {}
    active = bool(state)

    # Do not affect unrelated Claude Code work in the same project.
    if not active:
        return 0

    if tool_name in {"WebFetch", "WebSearch"}:
        return deny("report-creator production mode does not permit network access or web search.")

    if tool_name == "Read":
        file_path = str(tool_input.get("file_path") or "")
        if file_path and is_sensitive_path(file_path):
            return deny(f"Sensitive file read blocked during report generation: {file_path}")
        return 0

    if tool_name in {"Write", "Edit"}:
        file_path = str(tool_input.get("file_path") or "")
        if not file_path:
            return deny("File write/edit blocked because no file_path was provided.")
        if is_sensitive_path(file_path):
            return deny(f"Sensitive file write/edit blocked: {file_path}")
        if not allowed_write_path(root, file_path):
            return deny(
                "report-creator may write only under .report-creator/{specs,work,audit}/ "
                "or reports/generated/. Requested path: " + file_path
            )
        return 0

    if tool_name == "Agent":
        subagent = str(tool_input.get("subagent_type") or "")
        if subagent not in ALLOWED_SUBAGENTS:
            return deny(f"Only report-creator production subagents are permitted. Requested: {subagent or '<missing>'}")
        return 0

    if tool_name == "Bash":
        command = str(tool_input.get("command") or "")
        for pattern in DANGEROUS_BASH_PATTERNS:
            if re.search(pattern, command, flags=re.IGNORECASE | re.DOTALL):
                return deny(f"Bash command blocked by report-creator production guard: pattern {pattern}")
        if bash_is_allowed(command):
            return allow("Allowed report-creator validation/rendering script.")
        if command_mentions_report_creator(command):
            return deny("Only python3 execution of bundled report-creator scripts is allowed in production mode.")
        return deny("Arbitrary Bash is blocked while report-creator production mode is active. Use Read/Write or bundled validators/renderers only.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
