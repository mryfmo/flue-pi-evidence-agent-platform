#!/usr/bin/env python3
"""PostToolUse and failure audit logger for report-creator production workflow."""
from __future__ import annotations

import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def project_root(event: dict[str, Any]) -> Path:
    return Path(os.environ.get("CLAUDE_PROJECT_DIR") or event.get("cwd") or os.getcwd()).resolve()


def state_path(root: Path, sid: str) -> Path:
    return root / ".report-creator" / "state" / f"{sid}.json"


def load_state(root: Path, sid: str) -> dict[str, Any] | None:
    path = state_path(root, sid)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def save_state(root: Path, sid: str, state: dict[str, Any]) -> None:
    path = state_path(root, sid)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def text_from_response(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        parts = []
        for key in ("stdout", "stderr", "text", "output"):
            v = value.get(key)
            if isinstance(v, str):
                parts.append(v)
        if "content" in value and isinstance(value["content"], list):
            for item in value["content"]:
                if isinstance(item, dict) and isinstance(item.get("text"), str):
                    parts.append(item["text"])
        return "\n".join(parts)
    if isinstance(value, list):
        return "\n".join(text_from_response(v) for v in value)
    return ""




def parse_decision(text: str) -> str | None:
    match = re.search(r"^\s*decision\s*:\s*(pass|revise|block)\s*$", text, flags=re.IGNORECASE | re.MULTILINE)
    if not match:
        return None
    return match.group(1).lower()


def first_blocker_or_reason(text: str) -> str | None:
    for label in ("reason", "blockers", "required_changes"):
        match = re.search(rf"^\s*{label}\s*:\s*(.+)$", text, flags=re.IGNORECASE | re.MULTILINE)
        if match:
            value = match.group(1).strip()
            if value and value.lower() != "none" and value != "なし":
                return value[:500]
    return None


def compact_event(event: dict[str, Any]) -> dict[str, Any]:
    tool_input = event.get("tool_input") or {}
    tool_response = event.get("tool_response")
    compact: dict[str, Any] = {
        "ts": now_iso(),
        "event": event.get("hook_event_name"),
        "tool": event.get("tool_name"),
        "duration_ms": event.get("duration_ms"),
    }
    if isinstance(tool_input, dict):
        for key in ("command", "file_path", "subagent_type", "description"):
            if key in tool_input:
                value = str(tool_input.get(key))
                compact[key] = value[:500]
    if event.get("error"):
        compact["error"] = str(event.get("error"))[:500]
    response_text = text_from_response(tool_response)
    if response_text:
        compact["response_excerpt"] = response_text[:500]
    return compact


def update_state_from_event(root: Path, sid: str, event: dict[str, Any]) -> None:
    state = load_state(root, sid)
    if not state or not state.get("active"):
        return

    state.setdefault("events", []).append(compact_event(event))
    # Keep state bounded.
    state["events"] = state["events"][-100:]

    tool_name = str(event.get("tool_name") or "")
    tool_input = event.get("tool_input") or {}
    response_text = text_from_response(event.get("tool_response"))

    if tool_name == "Bash" and isinstance(tool_input, dict):
        command = str(tool_input.get("command") or "")
        if "validate_spec.py" in command and "SPEC VALIDATION PASSED" in response_text:
            state["spec_validated"] = True
            state["spec_validated_at"] = now_iso()
        if "render_report.py" in command:
            html_candidates = [line.strip() for line in response_text.splitlines() if line.strip().endswith(".html")]
            if html_candidates:
                state["last_rendered_html"] = html_candidates[-1]
                state["html_rendered_at"] = now_iso()
        if "validate_report.py" in command and "VALIDATION PASSED" in response_text:
            state["html_validated"] = True
            state["html_validated_at"] = now_iso()

    if tool_name == "Agent" and isinstance(tool_input, dict):
        subagent = str(tool_input.get("subagent_type") or "")
        if subagent:
            completed = set(state.get("subagents_completed") or [])
            completed.add(subagent)
            state["subagents_completed"] = sorted(completed)
            state.setdefault("subagent_decisions", {})[subagent] = parse_decision(response_text) or "unknown"
            reason = first_blocker_or_reason(response_text)
            if reason:
                state.setdefault("subagent_notes", {})[subagent] = reason
            state[f"{subagent}_completed_at"] = now_iso()

    save_state(root, sid, state)


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except json.JSONDecodeError:
        return 0

    root = project_root(event)
    sid = str(event.get("session_id") or "unknown-session")
    audit_dir = root / ".report-creator" / "audit"
    audit_dir.mkdir(parents=True, exist_ok=True)
    audit_path = audit_dir / "tool-events.jsonl"
    with audit_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(compact_event(event), ensure_ascii=False) + "\n")

    update_state_from_event(root, sid, event)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
