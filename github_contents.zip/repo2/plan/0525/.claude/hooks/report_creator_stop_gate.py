#!/usr/bin/env python3
"""Stop gate for report-creator production workflow."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def project_root(event: dict[str, Any]) -> Path:
    return Path(os.environ.get("CLAUDE_PROJECT_DIR") or event.get("cwd") or os.getcwd()).resolve()


def state_path(root: Path, sid: str) -> Path:
    return root / ".report-creator" / "state" / f"{sid}.json"


def load_state(root: Path, sid: str) -> dict[str, Any] | None:
    path = state_path(root, sid)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def save_state(root: Path, sid: str, state: dict[str, Any]) -> None:
    path = state_path(root, sid)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def block(reason: str) -> int:
    print(json.dumps({"decision": "block", "reason": reason}, ensure_ascii=False))
    return 0


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except json.JSONDecodeError:
        return 0

    root = project_root(event)
    sid = str(event.get("session_id") or "unknown-session")
    state = load_state(root, sid)
    if not state or not state.get("active"):
        return 0

    missing = []
    if not state.get("spec_validated"):
        missing.append("validate_spec.py has not passed")
    if not state.get("last_rendered_html"):
        missing.append("render_report.py has not produced an HTML path")
    if not state.get("html_validated"):
        missing.append("validate_report.py has not passed")

    completed = set(state.get("subagents_completed") or [])
    required = set(state.get("required_subagents") or [])
    decisions = state.get("subagent_decisions") or {}
    notes = state.get("subagent_notes") or {}
    missing_subagents = sorted(required - completed)
    for subagent in missing_subagents:
        missing.append(f"required subagent has not completed: {subagent}")
    for subagent in sorted(required & completed):
        decision = decisions.get(subagent, "unknown")
        if decision != "pass":
            suffix = f" ({notes.get(subagent)})" if notes.get(subagent) else ""
            missing.append(f"required subagent did not return decision: pass: {subagent}={decision}{suffix}")

    if missing:
        return block(
            "Report Creator production gate is incomplete. Complete these gates before final answer: "
            + "; ".join(missing)
            + ". To intentionally abort, remove the active state file under .report-creator/state/ after recording the reason."
        )

    state["active"] = False
    state["status"] = "complete"
    state["completed_at"] = now_iso()
    save_state(root, sid, state)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
