#!/usr/bin/env python3
"""Activate report-creator production state when /report-creator expands."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REQUIRED_SUBAGENTS = ["report-input-auditor", "report-quality-reviewer", "report-compliance-reviewer"]


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def project_root(event: dict[str, Any]) -> Path:
    return Path(os.environ.get("CLAUDE_PROJECT_DIR") or event.get("cwd") or os.getcwd()).resolve()


def state_path(root: Path, session_id: str) -> Path:
    return root / ".report-creator" / "state" / f"{session_id}.json"


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except json.JSONDecodeError:
        return 0

    command_name = str(event.get("command_name") or "")
    if command_name != "report-creator" and not command_name.endswith(":report-creator"):
        return 0

    root = project_root(event)
    sid = str(event.get("session_id") or "unknown-session")
    path = state_path(root, sid)
    path.parent.mkdir(parents=True, exist_ok=True)
    (root / ".report-creator" / "audit").mkdir(parents=True, exist_ok=True)
    (root / ".report-creator" / "specs").mkdir(parents=True, exist_ok=True)
    (root / "reports" / "generated").mkdir(parents=True, exist_ok=True)

    state = {
        "session_id": sid,
        "active": True,
        "status": "active",
        "started_at": now_iso(),
        "command_name": command_name,
        "command_args": event.get("command_args", ""),
        "prompt": event.get("prompt", ""),
        "required_subagents": REQUIRED_SUBAGENTS,
        "subagents_completed": [],
        "spec_validated": False,
        "html_validated": False,
        "last_rendered_html": None,
        "events": [],
    }
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    context = (
        "Report Creator production profile is active. Required gates: "
        "report-input-auditor, validate_spec.py, render_report.py, validate_report.py, "
        "report-quality-reviewer, report-compliance-reviewer. "
        "Write specs under .report-creator/specs/ and HTML under reports/generated/. "
        "Do not silently degrade if any gate is unavailable or fails."
    )
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "UserPromptExpansion",
            "additionalContext": context,
        }
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
