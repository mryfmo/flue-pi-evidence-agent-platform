# Invocation, Title, Input, and Output Rules

This file preserves the original skill's invocation, title-generation, input, and output behavior. The original used `$1`, `$2`, and `$3` as semantic labels. In Claude Code, positional shorthand is zero-based, so this refactor uses named arguments and maps the original semantics as follows:

| Original semantic label | Claude Code named argument | Meaning |
|---|---|---|
| `$1` | `$input_file` / `$0` | 入力ファイルのフルパス（省略時はユーザーとの会話内容のみから生成） |
| `$2` | `$document_type` / `$1` | 資料種別（省略時は `summary`） |
| `$3` | `$target` / `$2` | ターゲット（省略時は `general`） |

## Original preserved content

```markdown
---
name: report-creator
description: ロードマップ・回答資料・分析報告資料・提案資料・振り返り資料・状況共有資料・議論整理資料の7種類のHTMLドキュメントを生成するスキル。資料種別とターゲット（閲覧者ペルソナ）を引数で指定することで内容・言葉遣い・強調箇所を自動調整する。引数省略時はサマリレポートとして誰にでもわかりやすい形式で生成する。
argument-hint: "/path/to/draft.md 種別(roadmap/proposal/analysis/pitch/retro/status/discussion) ターゲット(bizlead/engineer/mixed)"
---

## 引数の意味

| 引数 | 説明 |
|------|------|
| `$1` | 入力ファイルのフルパス（省略時はユーザーとの会話内容のみから生成） |
| `$2` | 資料種別（省略時は `summary`）: `roadmap` / `proposal` / `analysis` / `pitch` / `retro` / `status` / `discussion` |
| `$3` | ターゲット（省略時は `general`）: `bizlead` / `engineer` / `mixed` / `general` |

**引数をすべて省略した場合**: 資料種別 `summary`・ターゲット `general` として扱い、誰にでも伝わるサマリレポートを生成する。

## タイトルの決め方

タイトルは引数で指定せず、以下の優先順位で自動生成する。

1. `$1` で指定された入力ファイルの冒頭・見出しから内容を読み取り、資料の主旨を端的に表すタイトルを考える
2. ユーザーとの会話で言及されたテーマ・目的から導く
3. いずれも手がかりがない場合は資料種別＋生成日をベースにする（例: `分析トライアル報告 2026-05-21`）

タイトルは「読んだ人がその資料を探しやすい」具体性を持たせる。種別名の直訳（「ロードマップ」など）だけにならないよう、内容の主語・テーマを含める。

## 利用するデータ

* `$1` で指定されたフルパスのファイル — 資料の元ネタとなる下書きや箇条書きメモ

`$1` が省略された場合はユーザーとの会話内容から推論して生成する。

## 出力先

* `$1` と同じディレクトリに `{種別}_{YYYYMMDDHHmmss}.html` の形式で出力する
  * 例: `/path/to/analysis_20260521143000.html`
* `$1` が省略された場合はカレントディレクトリに出力する
* タイムスタンプにより既存ファイルを上書きしない

---
```

## Refactored operating rules

- Preserve the original default: when all arguments are omitted, generate `summary` + `general`.
- Preserve the original source behavior: when `input_file` is omitted, infer content from the conversation.
- Preserve the original output behavior: write beside `input_file`, otherwise write to the current working directory.
- Preserve the original filename format: `{document_type}_{YYYYMMDDHHmmss}.html`.
- Preserve the original title policy: derive a specific, searchable title from the input heading/opening, then the conversation theme, then a document-type/date fallback.
- Avoid generic titles that only repeat the type, such as `ロードマップ` or `分析資料`.
