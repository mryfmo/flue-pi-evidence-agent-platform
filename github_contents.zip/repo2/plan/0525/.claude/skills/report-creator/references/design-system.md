# HTML Design System

This file preserves the original HTML design requirements and maps them to the bundled renderer's Report Spec block types.

```markdown
## HTMLデザイン仕様

生成するHTMLは以下の要件を満たすこと。スタイルはインラインCSSまたは`<style>`タグで完結させ、外部CDN参照は不要とする。

### 全資料共通

- フォント: `system-ui, -apple-system, sans-serif`
- 背景: `#f5f7fa`、カード: `#ffffff`、シャドウ: `0 2px 8px rgba(0,0,0,0.08)`
- カラーパレット:
  - プライマリ: `#1a56db`（青）
  - 成功: `#057a55`（緑）
  - 警告: `#d97706`（黄橙）
  - 危険: `#e02424`（赤）
  - ニュートラル: `#374151`
  - サブテキスト: `#6b7280`
- PC閲覧想定（最小幅 900px）

### ターゲット別の視覚的工夫

| ターゲット | 視覚的特徴 |
|------------|------------|
| `general` | 余白広め・文字量少なめ・大きなアイコンやバッジで直感的に。専門用語なし |
| `bizlead` | KPIを大きな数字カードで冒頭に配置。フォントサイズ大きめ。テキスト量を絞る |
| `engineer` | コードブロック・テーブル・箇条書きを多用。情報密度を高める。`<details>`折りたたみを活用 |
| `mixed` | 2カラムまたはタブ切り替えでペルソナ別セクションを分離。サマリー先行・詳細後続 |

### 資料種別別の視覚的工夫

| 種別 | 視覚的特徴 |
|------|------------|
| `summary` | シンプルなカードレイアウト。「一言まとめ」を大きく冒頭に |
| `roadmap` | フェーズを横型タイムラインバー（Flexbox）で視覚化。マイルストーンはダイヤモンドマーカー |
| `proposal` | ✅/⚠️/❌ 結論バッジを大きく冒頭に配置。対比表（できること vs できないこと）を使用 |
| `analysis` | 数値ハイライトカード（大きな数字＋ラベル）。発見事項はアイコン付きカードで整理 |
| `pitch` | ストーリー感のある縦フロー。問題→解決→行動の流れをビジュアルで強調 |
| `retro` | Keep/Problem/Try を3カラム並列カードで表示 |
| `status` | ステータスバッジ（🟢/🟡/🔴）を冒頭に大きく表示。進捗バーを使用 |
| `discussion` | 合意事項を緑カード・未解決QAを赤/黄カードで色分け。論点ごとに折りたたみ（`<details>`）で議論の経緯を格納 |

### ヘッダー・フッター

- ヘッダー: 資料種別バッジ・タイトル・ターゲット表示・生成日
- フッター: 「このドキュメントはAIが生成しました」の注記と生成日時

---
```

## Renderer mapping

Use these Report Spec block types to satisfy the original visual requirements:

| Original requirement | Preferred Report Spec representation |
|---|---|
| KPIを大きな数字カードで冒頭に配置 | top-level `metrics` |
| 横型タイムラインバー / フェーズ | `timeline` block |
| マイルストーンはダイヤモンドマーカー | `timeline` block; renderer CSS adds milestone markers |
| できること vs できないこと | `comparison` block or `table` block |
| 数字・グラフ・表 | `metrics`, `table`, `cards` |
| Keep / Problem / Try 3カラム | `kpt` block or `cards` block |
| 進捗バー | `progress` block or status table |
| 論点ごとの折りたたみ | `details` block |
| 2カラムまたはタブ切り替え | `two_column` block or `details` sections |
| コードブロック | `code` block |

## Dependency and safety rules

- The final HTML must be a single file.
- CSS must be embedded in `<style>`.
- Do not reference external CSS, fonts, scripts, images, CDNs, iframes, object embeds, or network resources.
- Use text labels along with color/status icons so meaning is not conveyed by color alone.
- Include print-friendly styles.
