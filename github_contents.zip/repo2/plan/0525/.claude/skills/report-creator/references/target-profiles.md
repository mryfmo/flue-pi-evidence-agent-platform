# Target Profiles

This file preserves the original target persona and adjustment rules. Apply the selected target consistently across wording, section depth, emphasis, omissions, and visual density.

```markdown
## ターゲットペルソナと調整方針

`$3`（ターゲット引数）の値によって、資料の重点・言葉遣い・強調箇所を以下のように変える。

### `general`（デフォルト・引数省略時）

- **想定読者**: 技術的な前提知識を問わない不特定の関係者全員
- **言葉遣い**: 平易な日本語。技術用語は使う場合に括弧で補足必須
- **構成原則**: 結論→背景→詳細の順。各セクションは短く、要点を箇条書きで
- **視覚的方針**: 余白を広く取る。文字量を絞る。図・カード・バッジで直感的に伝える
- **絶対に入れる**: 「一言でいうと何か」「誰が何をすればよいか」

### `bizlead`（事業責任者・意思決定者）

- **関心事**: コスト・期間・リスク・事業インパクト・承認判断の根拠
- **言葉遣い**: 非技術的用語を優先。技術ワードには括弧で平易な補足を付ける
- **強調**: サマリーを冒頭に置く。数字・期間・効果を目立たせる
- **省略可能**: 実装詳細・技術アーキテクチャの深い説明
- **絶対に入れる**: 「なぜやるか（事業的意義）」「いつまでに（期間）」「リスクと対策」

### `engineer`（エンジニア・技術担当者）

- **関心事**: 技術的な実現可能性・実装方針・インタフェース・制約・工数感
- **言葉遣い**: 技術用語をそのまま使用。専門性を尊重した文体
- **強調**: 技術アーキテクチャ・データフロー・APIインタフェース・制約事項
- **省略可能**: 事業背景の詳細説明（1〜2行で十分）
- **絶対に入れる**: 「どう動くか（仕組み）」「何が難しいか（技術課題）」「次のアクション」

### `mixed`（事業側＋技術側の混在）

- **関心事**: 双方が同じ資料を読むため、階層構造で使い分ける
- **構成原則**: サマリー層（非技術）→ 詳細層（技術）の2段構成
- **言葉遣い**: 冒頭は平易、詳細セクションは技術的に書き分ける
- **絶対に入れる**: エグゼクティブサマリー（非技術向け）＋技術詳細セクション（折りたたみ可）

---
```

## Refactored application notes

- `general`: prioritize plain Japanese, short sections, and clear ownership/action.
- `bizlead`: keep implementation detail subordinate to cost, period, risk, impact, and approval criteria.
- `engineer`: include architecture, data flow, interfaces, constraints, effort, and next technical actions.
- `mixed`: use a two-layer structure: non-technical executive summary first, technical detail later, with `<details>` where useful.
