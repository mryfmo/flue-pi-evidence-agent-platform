# Report Creator Skill Manifest

This directory is the Skill component of the `report-creator` Claude Code production bundle. It remains focused on invocation, report rules, deterministic rendering, and validation. Production operation also requires project-level SubAgents, Hooks, and settings.

## Claude Code placement

Project production placement:

```text
.claude/skills/report-creator/SKILL.md
```

Project production companion files:

```text
.claude/agents/report-input-auditor.md
.claude/agents/report-quality-reviewer.md
.claude/agents/report-compliance-reviewer.md
.claude/hooks/report_creator_prompt_expansion.py
.claude/hooks/report_creator_pretool_guard.py
.claude/hooks/report_creator_posttool_audit.py
.claude/hooks/report_creator_stop_gate.py
.claude/settings.json
```

## Responsibilities

| Path | Responsibility |
|---|---|
| `SKILL.md` | Claude Code entrypoint, production contract, argument normalization, workflow, and final response contract. |
| `INSTALL.md` | Skill validation and invocation notes. |
| `references/invocation-title-output.md` | Argument semantics, title generation, input source, output path rules, and Claude Code positional correction. |
| `references/target-profiles.md` | Target persona and audience-specific adjustment rules. |
| `references/document-blueprints.md` | Report-type purposes, required sections, and per-target sub-requirements. |
| `references/design-system.md` | Self-contained HTML design system, visual requirements, header/footer, and dependency rules. |
| `references/evidence-quality.md` | Generation notes, safety, evidence separation, and validation gates. |
| `templates/report_spec.schema.json` | Machine-readable Report Spec contract. |
| `scripts/validate_spec.py` | Standard-library Report Spec validator used before rendering. |
| `scripts/render_report.py` | Deterministic HTML renderer using only Python standard library. |
| `scripts/validate_report.py` | Generated HTML validator; checks self-contained output and required section coverage. |
| `scripts/smoke_test.py` | End-to-end smoke test for all supported document types. |
| `scripts/validate_skill_package.py` | Package-level structure and original-requirement coverage test. |
| `examples/analysis_mixed_spec.json` | Example Report Spec for manual review and regression testing. |
| `coverage/coverage-audit.md` | Coverage audit against the previously presented modular ZIP. |
| `coverage/original-skill-source.md` | Original single-file source preserved for traceability. |

## Design notes

- `SKILL.md` uses official Claude Code frontmatter fields only.
- `disable-model-invocation: true` keeps the skill manual-only because it writes files.
- `allowed-tools` pre-approves the required report scripts and production SubAgents. It does not function as a denylist.
- Hard restrictions live in `.claude/settings.json` and `.claude/hooks/`.
- Supporting files are referenced explicitly so Claude can load detailed material only when relevant.
- Validation is split into spec validation, deterministic rendering, generated HTML validation, and SubAgent review gates.
