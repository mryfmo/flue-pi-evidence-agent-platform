#!/usr/bin/env python3
"""Validate a generated report-creator HTML file.

Checks the properties that matter most for this skill: single-file HTML,
Japanese language metadata, embedded CSS, no executable/external dependencies,
required document-type coverage, and AI-generated footer notice.
"""

from __future__ import annotations

import argparse
import re
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

REQUIRED_SECTION_KEYWORDS = {
    "summary": ["一言", "背景", "現状", "成果", "課題", "ネクスト"],
    "roadmap": ["サマリー", "背景", "タイムライン", "優先", "リスク", "ネクスト"],
    "proposal": ["結論", "問い", "実現", "制約", "コスト", "ネクスト"],
    "analysis": ["サマリー", "背景", "手法", "発見", "考察", "限界", "ネクスト"],
    "pitch": ["問題", "理想", "提案", "効果", "投資", "なぜ今", "CTA"],
    "retro": ["対象", "Keep", "Problem", "Try", "数字", "総評"],
    "status": ["ステータス", "進捗", "直近", "課題", "マイルストーン", "共有"],
    "discussion": ["サマリー", "合意", "論点", "未解決", "前提", "ネクスト"],
}

DISALLOWED_TAGS = {"script", "iframe", "object", "embed", "canvas", "svg"}
EXTERNAL_ATTRS = {"src", "href", "action", "poster", "data"}
EXTERNAL_VALUE_PREFIXES = ("http://", "https://", "//", "data:", "javascript:")
CSS_EXTERNAL_PATTERNS = [r"@import\s+url", r"url\s*\("]


class ReportHTMLValidator(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.errors: list[str] = []
        self.has_html_lang_ja = False
        self.style_count = 0
        self.footer_text_parts: list[str] = []
        self._tag_stack: list[str] = []
        self._in_footer = False
        self._in_style = False
        self.style_text_parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag_lower = tag.lower()
        self._tag_stack.append(tag_lower)
        if tag_lower in DISALLOWED_TAGS:
            self.errors.append(f"disallowed tag: <{tag_lower}>")
        if tag_lower == "html":
            attr_map = {name.lower(): value for name, value in attrs}
            if attr_map.get("lang", "").lower().startswith("ja"):
                self.has_html_lang_ja = True
        if tag_lower == "style":
            self.style_count += 1
            self._in_style = True
        if tag_lower == "footer":
            self._in_footer = True
        for name, value in attrs:
            name_lower = name.lower()
            if name_lower.startswith("on"):
                self.errors.append(f"inline event handler is not allowed: {name_lower}")
            if name_lower in EXTERNAL_ATTRS and value:
                normalized = value.strip().lower()
                if normalized.startswith(EXTERNAL_VALUE_PREFIXES):
                    self.errors.append(f"external or executable resource in {tag_lower}.{name_lower}: {value}")
        if tag_lower == "link":
            self.errors.append("external <link> resources are not allowed")

    def handle_endtag(self, tag: str) -> None:
        tag_lower = tag.lower()
        if tag_lower == "style":
            self._in_style = False
        if tag_lower == "footer":
            self._in_footer = False
        if self._tag_stack:
            self._tag_stack.pop()

    def handle_data(self, data: str) -> None:
        if self._in_footer:
            self.footer_text_parts.append(data)
        if self._in_style:
            self.style_text_parts.append(data)


def validate_html(html: str, document_type: str) -> list[str]:
    errors: list[str] = []
    lowered = html.lower()
    if "<!doctype html" not in lowered:
        errors.append("missing <!doctype html>")

    parser = ReportHTMLValidator()
    parser.feed(html)
    errors.extend(parser.errors)

    if not parser.has_html_lang_ja:
        errors.append("missing Japanese lang attribute")
    if parser.style_count != 1:
        errors.append(f"expected exactly one embedded <style> block, found {parser.style_count}")

    style_text = "\n".join(parser.style_text_parts)
    for pattern in CSS_EXTERNAL_PATTERNS:
        if re.search(pattern, style_text, flags=re.IGNORECASE):
            errors.append(f"external CSS dependency pattern found: {pattern}")

    footer_text = "".join(parser.footer_text_parts).lower()
    if "このドキュメントはaiが生成しました" not in footer_text:
        errors.append("missing AI-generated footer notice")

    if document_type not in REQUIRED_SECTION_KEYWORDS:
        errors.append(f"unsupported document_type: {document_type}")
    else:
        missing = [keyword for keyword in REQUIRED_SECTION_KEYWORDS[document_type] if keyword not in html]
        if missing:
            errors.append("required section keyword(s) not found: " + ", ".join(missing))

    return errors


def fail(message: str) -> None:
    raise SystemExit(f"VALIDATION FAILED: {message}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate report-creator HTML output.")
    parser.add_argument("--html", required=True, help="Generated HTML file")
    parser.add_argument("--document-type", required=True, choices=sorted(REQUIRED_SECTION_KEYWORDS))
    args = parser.parse_args()

    html_path = Path(args.html)
    if not html_path.exists():
        fail(f"file does not exist: {html_path}")
    html = html_path.read_text(encoding="utf-8")

    errors = validate_html(html, args.document_type)
    if errors:
        print("VALIDATION FAILED")
        for error in errors:
            print(f"- {error}")
        return 1

    print("VALIDATION PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
