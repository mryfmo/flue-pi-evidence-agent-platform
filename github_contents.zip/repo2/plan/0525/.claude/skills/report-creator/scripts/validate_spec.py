#!/usr/bin/env python3
"""Validate a Report Spec JSON file before rendering.

The validator intentionally uses only Python's standard library. It implements
structural checks that mirror templates/report_spec.schema.json closely enough
for Claude Code use, without requiring jsonschema to be installed.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

VALID_TYPES = {"summary", "roadmap", "proposal", "analysis", "pitch", "retro", "status", "discussion"}
VALID_TARGETS = {"general", "bizlead", "engineer", "mixed"}
TOP_LEVEL_KEYS = {
    "document_type",
    "target",
    "title",
    "summary",
    "status",
    "metrics",
    "sections",
    "actions",
    "assumptions",
    "source_notes",
}
SECTION_KEYS = {"heading", "lead", "blocks"}

BLOCK_REQUIRED_KEYS: dict[str, set[str]] = {
    "paragraph": {"type", "text"},
    "bullets": {"type", "items"},
    "table": {"type", "headers", "rows"},
    "cards": {"type", "cards"},
    "timeline": {"type", "items"},
    "details": {"type", "summary", "blocks"},
    "key_values": {"type", "items"},
    "progress": {"type", "items"},
    "comparison": {"type"},
    "kpt": {"type"},
    "two_column": {"type"},
    "code": {"type"},
}

BLOCK_ALLOWED_KEYS: dict[str, set[str]] = {
    "paragraph": {"type", "text"},
    "bullets": {"type", "items"},
    "table": {"type", "headers", "rows"},
    "cards": {"type", "cards"},
    "timeline": {"type", "items"},
    "details": {"type", "summary", "blocks"},
    "key_values": {"type", "items"},
    "progress": {"type", "items"},
    "comparison": {"type", "can", "cannot", "conditions", "columns"},
    "kpt": {"type", "keep", "problem", "try"},
    "two_column": {"type", "left_title", "right_title", "left", "right"},
    "code": {"type", "language", "code", "text"},
}

REQUIRED_SECTION_KEYWORDS = {
    "summary": ["一言", "背景", "現状", "成果", "課題", "ネクスト"],
    "roadmap": ["サマリー", "背景", "タイムライン", "優先", "リスク", "ネクスト"],
    "proposal": ["結論", "問い", "実現", "制約", "コスト", "ネクスト"],
    "analysis": ["サマリー", "背景", "手法", "発見", "考察", "限界", "ネクスト"],
    "pitch": ["問題", "理想", "提案", "効果", "投資", "なぜ今", "CTA"],
    "retro": ["対象", "Keep", "Problem", "Try", "数字", "総評"],
    "status": ["ステータス", "進捗", "直近", "課題", "マイルストーン", "共有"],
    "discussion": ["サマリー", "合意", "論点", "未解決", "前提", "ネクスト"],
}


def is_non_empty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def check_string_list(value: Any, path: str, errors: list[str], *, min_items: int = 0) -> None:
    if not isinstance(value, list):
        errors.append(f"{path}: must be an array")
        return
    if len(value) < min_items:
        errors.append(f"{path}: must contain at least {min_items} item(s)")
    for index, item in enumerate(value):
        if not isinstance(item, str):
            errors.append(f"{path}[{index}]: must be a string")


def check_block_list(value: Any, path: str, errors: list[str]) -> None:
    if not isinstance(value, list):
        errors.append(f"{path}: must be an array")
        return
    for index, block in enumerate(value):
        check_block(block, f"{path}[{index}]", errors)


def check_card_list(value: Any, path: str, errors: list[str]) -> None:
    if not isinstance(value, list):
        errors.append(f"{path}: must be an array")
        return
    for index, card in enumerate(value):
        if not isinstance(card, dict):
            errors.append(f"{path}[{index}]: must be an object")
            continue
        unknown = set(card) - {"title", "body", "badge"}
        if unknown:
            errors.append(f"{path}[{index}]: unknown key(s): {', '.join(sorted(unknown))}")
        for key in ("title", "body"):
            if key not in card or not isinstance(card[key], str):
                errors.append(f"{path}[{index}].{key}: must be a string")
        if "badge" in card and not isinstance(card["badge"], str):
            errors.append(f"{path}[{index}].badge: must be a string")


def check_object_list(value: Any, path: str, errors: list[str], allowed: set[str], required: set[str]) -> None:
    if not isinstance(value, list):
        errors.append(f"{path}: must be an array")
        return
    for index, item in enumerate(value):
        item_path = f"{path}[{index}]"
        if not isinstance(item, dict):
            errors.append(f"{item_path}: must be an object")
            continue
        missing = required - set(item)
        unknown = set(item) - allowed
        if missing:
            errors.append(f"{item_path}: missing key(s): {', '.join(sorted(missing))}")
        if unknown:
            errors.append(f"{item_path}: unknown key(s): {', '.join(sorted(unknown))}")
        for key, value2 in item.items():
            if key in allowed and not isinstance(value2, str):
                errors.append(f"{item_path}.{key}: must be a string")


def check_table_rows(value: Any, path: str, errors: list[str]) -> None:
    if not isinstance(value, list):
        errors.append(f"{path}: must be an array")
        return
    for row_index, row in enumerate(value):
        if not isinstance(row, list):
            errors.append(f"{path}[{row_index}]: must be an array")
            continue
        for cell_index, cell in enumerate(row):
            if not isinstance(cell, (str, int, float, bool)) and cell is not None:
                errors.append(f"{path}[{row_index}][{cell_index}]: must be scalar text")


def check_comparison_columns(value: Any, path: str, errors: list[str]) -> None:
    if not isinstance(value, list):
        errors.append(f"{path}: must be an array")
        return
    for index, item in enumerate(value):
        item_path = f"{path}[{index}]"
        if not isinstance(item, dict):
            errors.append(f"{item_path}: must be an object")
            continue
        missing = {"title", "items"} - set(item)
        unknown = set(item) - {"title", "items"}
        if missing:
            errors.append(f"{item_path}: missing key(s): {', '.join(sorted(missing))}")
        if unknown:
            errors.append(f"{item_path}: unknown key(s): {', '.join(sorted(unknown))}")
        if "title" in item and not isinstance(item["title"], str):
            errors.append(f"{item_path}.title: must be a string")
        if "items" in item:
            check_string_list(item["items"], f"{item_path}.items", errors)


def check_block(block: Any, path: str, errors: list[str]) -> None:
    if not isinstance(block, dict):
        errors.append(f"{path}: must be an object")
        return
    block_type = block.get("type")
    if block_type not in BLOCK_REQUIRED_KEYS:
        errors.append(f"{path}.type: unsupported block type {block_type!r}")
        return

    missing = BLOCK_REQUIRED_KEYS[block_type] - set(block)
    unknown = set(block) - BLOCK_ALLOWED_KEYS[block_type]
    if missing:
        errors.append(f"{path}: missing key(s): {', '.join(sorted(missing))}")
    if unknown:
        errors.append(f"{path}: unknown key(s): {', '.join(sorted(unknown))}")

    if block_type == "paragraph" and not isinstance(block.get("text"), str):
        errors.append(f"{path}.text: must be a string")
    elif block_type == "bullets":
        check_string_list(block.get("items"), f"{path}.items", errors)
    elif block_type == "table":
        check_string_list(block.get("headers"), f"{path}.headers", errors, min_items=1)
        check_table_rows(block.get("rows"), f"{path}.rows", errors)
    elif block_type == "cards":
        check_card_list(block.get("cards"), f"{path}.cards", errors)
    elif block_type == "timeline":
        check_object_list(block.get("items"), f"{path}.items", errors, {"label", "title", "body"}, {"label", "title", "body"})
    elif block_type == "details":
        if not isinstance(block.get("summary"), str):
            errors.append(f"{path}.summary: must be a string")
        check_block_list(block.get("blocks"), f"{path}.blocks", errors)
    elif block_type == "key_values":
        check_object_list(block.get("items"), f"{path}.items", errors, {"key", "value"}, {"key", "value"})
    elif block_type == "progress":
        check_object_list(block.get("items"), f"{path}.items", errors, {"label", "value", "note"}, {"label", "value"})
    elif block_type == "comparison":
        for key in ("can", "cannot", "conditions"):
            if key in block:
                check_string_list(block[key], f"{path}.{key}", errors)
        if "columns" in block:
            check_comparison_columns(block["columns"], f"{path}.columns", errors)
    elif block_type == "kpt":
        for key in ("keep", "problem", "try"):
            if key in block:
                check_string_list(block[key], f"{path}.{key}", errors)
    elif block_type == "two_column":
        for key in ("left_title", "right_title"):
            if key in block and not isinstance(block[key], str):
                errors.append(f"{path}.{key}: must be a string")
        for key in ("left", "right"):
            if key in block:
                check_block_list(block[key], f"{path}.{key}", errors)
    elif block_type == "code":
        if "language" in block and not isinstance(block["language"], str):
            errors.append(f"{path}.language: must be a string")
        if "code" in block and not isinstance(block["code"], str):
            errors.append(f"{path}.code: must be a string")
        if "text" in block and not isinstance(block["text"], str):
            errors.append(f"{path}.text: must be a string")


def validate_spec(spec: Any, *, expected_document_type: str | None = None, expected_target: str | None = None) -> list[str]:
    errors: list[str] = []
    if not isinstance(spec, dict):
        return ["spec: must be a JSON object"]

    missing = {"document_type", "target", "title", "sections"} - set(spec)
    unknown = set(spec) - TOP_LEVEL_KEYS
    if missing:
        errors.append("spec: missing required key(s): " + ", ".join(sorted(missing)))
    if unknown:
        errors.append("spec: unknown top-level key(s): " + ", ".join(sorted(unknown)))

    document_type = spec.get("document_type")
    target = spec.get("target")
    if document_type not in VALID_TYPES:
        errors.append(f"document_type: must be one of {', '.join(sorted(VALID_TYPES))}")
    if target not in VALID_TARGETS:
        errors.append(f"target: must be one of {', '.join(sorted(VALID_TARGETS))}")
    if expected_document_type and document_type != expected_document_type:
        errors.append(f"document_type: expected {expected_document_type!r}, got {document_type!r}")
    if expected_target and target != expected_target:
        errors.append(f"target: expected {expected_target!r}, got {target!r}")
    if not is_non_empty_string(spec.get("title")):
        errors.append("title: must be a non-empty string")

    if "summary" in spec and not isinstance(spec["summary"], str):
        errors.append("summary: must be a string")
    if "status" in spec and not isinstance(spec["status"], str):
        errors.append("status: must be a string")
    if "metrics" in spec:
        check_object_list(spec["metrics"], "metrics", errors, {"label", "value", "note"}, {"label", "value"})
    if "actions" in spec:
        check_object_list(spec["actions"], "actions", errors, {"owner", "action", "due", "status"}, {"owner", "action", "due"})
    if "assumptions" in spec:
        check_string_list(spec["assumptions"], "assumptions", errors)
    if "source_notes" in spec:
        check_string_list(spec["source_notes"], "source_notes", errors)

    sections = spec.get("sections")
    if not isinstance(sections, list) or not sections:
        errors.append("sections: must be a non-empty array")
    else:
        headings: list[str] = []
        for index, section in enumerate(sections):
            path = f"sections[{index}]"
            if not isinstance(section, dict):
                errors.append(f"{path}: must be an object")
                continue
            missing_section = {"heading"} - set(section)
            unknown_section = set(section) - SECTION_KEYS
            if missing_section:
                errors.append(f"{path}: missing key(s): {', '.join(sorted(missing_section))}")
            if unknown_section:
                errors.append(f"{path}: unknown key(s): {', '.join(sorted(unknown_section))}")
            heading = section.get("heading")
            if not is_non_empty_string(heading):
                errors.append(f"{path}.heading: must be a non-empty string")
            else:
                headings.append(heading)
            if "lead" in section and not isinstance(section["lead"], str):
                errors.append(f"{path}.lead: must be a string")
            if "blocks" in section:
                check_block_list(section["blocks"], f"{path}.blocks", errors)

        if document_type in REQUIRED_SECTION_KEYWORDS:
            joined_headings = "\n".join(headings)
            missing_keywords = [keyword for keyword in REQUIRED_SECTION_KEYWORDS[document_type] if keyword not in joined_headings]
            if missing_keywords:
                errors.append("sections: heading keyword(s) missing for document_type " + str(document_type) + ": " + ", ".join(missing_keywords))

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a Report Spec JSON file before rendering.")
    parser.add_argument("--spec", required=True, help="Path to Report Spec JSON")
    parser.add_argument("--document-type", choices=sorted(VALID_TYPES), help="Expected document_type")
    parser.add_argument("--target", choices=sorted(VALID_TARGETS), help="Expected target")
    args = parser.parse_args()

    spec_path = Path(args.spec)
    if not spec_path.exists():
        raise SystemExit(f"SPEC VALIDATION FAILED: file does not exist: {spec_path}")
    try:
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"SPEC VALIDATION FAILED: invalid JSON: {exc}") from exc

    errors = validate_spec(spec, expected_document_type=args.document_type, expected_target=args.target)
    if errors:
        print("SPEC VALIDATION FAILED")
        for error in errors:
            print(f"- {error}")
        return 1
    print("SPEC VALIDATION PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
