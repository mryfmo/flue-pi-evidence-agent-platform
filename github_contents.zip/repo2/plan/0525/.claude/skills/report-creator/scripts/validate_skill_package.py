#!/usr/bin/env python3
"""Validate the report-creator skill package structure and requirement coverage."""
from __future__ import annotations

from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
REQUIRED_FILES = [
    "SKILL.md",
    "MANIFEST.md",
    "INSTALL.md",
    "references/invocation-title-output.md",
    "references/target-profiles.md",
    "references/document-blueprints.md",
    "references/design-system.md",
    "references/evidence-quality.md",
    "templates/report_spec.schema.json",
    "scripts/validate_spec.py",
    "scripts/render_report.py",
    "scripts/validate_report.py",
    "scripts/smoke_test.py",
]
REQUIRED_PHRASES = [
    "入力ファイルの冒頭・見出しから内容を読み取り",
    "読んだ人がその資料を探しやすい",
    "種別名の直訳",
    "summary`・ターゲット `general",
    "技術アーキテクチャ・データフロー・APIインタフェース・制約事項",
    "エグゼクティブサマリー（非技術向け）＋技術詳細セクション（折りたたみ可）",
    "ゴール・主要タスク・依存関係・担当領域・マイルストーン",
    "ダイヤモンドマーカー",
    "事業上の意味合いで表現",
    "アーキテクチャ・データフロー・利用技術・インタフェース設計",
    "KPI・仮説検証・異常値・傾向",
    "統計的有意性・信頼区間・モデル精度指標",
    "相関・因果の区別を明確に",
    "共感→問題提起→解決策→行動喚起",
    "事実と評価を分けて記述",
    "合意件数・未解決件数・アクションアイテム数",
    "問い → 出た意見・仮説 → 暫定結論",
    "ブロック要因",
    "読んで判断できる",
    "system-ui, -apple-system, sans-serif",
    "#f5f7fa",
    "#1a56db",
    "コードブロック・テーブル・箇条書きを多用",
    "2カラムまたはタブ切り替え",
    "「多い」「早い」ではなく数値・期間・割合で表現する",
    "このドキュメントはAIが生成しました",
    "report-input-auditor",
    "report-quality-reviewer",
    "report-compliance-reviewer",
    "Production contract",
]
OFFICIAL_FRONTMATTER_KEYS = {
    "name",
    "description",
    "when_to_use",
    "argument-hint",
    "arguments",
    "disable-model-invocation",
    "user-invocable",
    "allowed-tools",
    "model",
    "effort",
    "context",
    "agent",
    "hooks",
    "paths",
    "shell",
}


def parse_frontmatter(skill_text: str) -> dict[str, object]:
    if not skill_text.startswith("---"):
        return {}
    parts = skill_text.split("---", 2)
    if len(parts) < 3:
        return {}
    frontmatter = parts[1]
    parsed: dict[str, object] = {}
    current_key: str | None = None
    for raw_line in frontmatter.splitlines():
        line = raw_line.rstrip()
        if not line.strip():
            continue
        if not raw_line.startswith(" ") and ":" in line:
            key, value = line.split(":", 1)
            key = key.strip()
            parsed[key] = value.strip()
            current_key = key
        elif current_key and line.strip().startswith("-"):
            parsed.setdefault(current_key, [])
    return parsed


def main() -> int:
    issues: list[str] = []
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).exists():
            issues.append(f"missing_file:{rel}")

    skill_path = ROOT / "SKILL.md"
    skill = skill_path.read_text(encoding="utf-8") if skill_path.exists() else ""
    if not skill.startswith("---"):
        issues.append("missing_frontmatter")
    if "name: report-creator" not in skill:
        issues.append("missing_name")
    if "disable-model-invocation: true" not in skill:
        issues.append("missing_manual_invocation_guard")
    if "Bash(python3 *)" in skill:
        issues.append("overbroad_python_allowed_tool")
    if len(skill.splitlines()) > 500:
        issues.append("skill_md_over_500_lines")

    frontmatter = parse_frontmatter(skill)
    unknown_keys = sorted(set(frontmatter) - OFFICIAL_FRONTMATTER_KEYS)
    for key in unknown_keys:
        issues.append(f"non_official_frontmatter_key:{key}")

    corpus = "\n".join(
        p.read_text(encoding="utf-8", errors="ignore")
        for p in ROOT.rglob("*")
        if p.is_file() and p.suffix in {".md", ".py", ".json"}
    )
    for phrase in REQUIRED_PHRASES:
        if phrase not in corpus:
            issues.append(f"missing_required_phrase:{phrase}")

    sensitive_patterns = {
        "requests": r"\brequests\b",
        "urllib": r"\burllib\b",
        "os_system": r"os\.system",
        "shell_true": r"shell\s*=\s*True",
        "eval": r"\beval\s*\(",
    }
    for script_name in ["render_report.py", "validate_report.py", "validate_spec.py"]:
        body = (ROOT / "scripts" / script_name).read_text(encoding="utf-8")
        for label, pattern in sensitive_patterns.items():
            if re.search(pattern, body):
                issues.append(f"forbidden_pattern:{script_name}:{label}")

    if issues:
        print("FAIL")
        for issue in issues:
            print("-", issue)
        return 1
    print("PASS")
    print(f"checked_files={len(REQUIRED_FILES)} checked_phrases={len(REQUIRED_PHRASES)} skill_lines={len(skill.splitlines())}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
