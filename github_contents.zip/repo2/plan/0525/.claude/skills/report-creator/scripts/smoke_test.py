#!/usr/bin/env python3
"""Run end-to-end smoke tests for all report-creator document types."""
from __future__ import annotations

import argparse
import json
import shutil
import tempfile
from pathlib import Path
from typing import Any

from render_report import render_html, unique_output_path
from validate_report import validate_html
from validate_spec import REQUIRED_SECTION_KEYWORDS, validate_spec


def make_spec(document_type: str, target: str = "mixed") -> dict[str, Any]:
    sections: list[dict[str, Any]] = []
    for keyword in REQUIRED_SECTION_KEYWORDS[document_type]:
        if document_type == "retro" and keyword in {"Keep", "Problem", "Try"}:
            sections.append(
                {
                    "heading": keyword,
                    "blocks": [
                        {
                            "type": "kpt",
                            "keep": ["継続すべき取り組みを記載"],
                            "problem": ["改善すべき課題を記載"],
                            "try": ["次回試す施策を記載"],
                        }
                    ],
                }
            )
        else:
            sections.append(
                {
                    "heading": f"{keyword} セクション",
                    "blocks": [
                        {
                            "type": "paragraph",
                            "text": f"{keyword} に関する検証用本文です。具体値がない箇所はTBDとして扱います。",
                        }
                    ],
                }
            )
    return {
        "document_type": document_type,
        "target": target,
        "title": f"{document_type} smoke test",
        "summary": "スモークテスト用のサンプルレポートです。",
        "metrics": [
            {"label": "検証項目", "value": str(len(sections)), "note": "生成セクション数"},
        ],
        "sections": sections,
        "actions": [
            {"owner": "担当未定", "action": "人間による最終確認", "due": "期限未定", "status": "要確認"},
        ],
        "assumptions": ["自動生成されたスモークテスト用Spec"],
        "source_notes": ["scripts/smoke_test.py"],
    }


def run(work_dir: Path, keep: bool = False) -> list[str]:
    errors: list[str] = []
    work_dir.mkdir(parents=True, exist_ok=True)
    for document_type in sorted(REQUIRED_SECTION_KEYWORDS):
        run_dir = work_dir / document_type
        staging_dir = run_dir / "staging"
        final_dir = run_dir / "final"
        staging_dir.mkdir(parents=True, exist_ok=True)
        final_dir.mkdir(parents=True, exist_ok=True)
        spec_path = run_dir / "report_spec.json"
        spec = make_spec(document_type)
        spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")

        spec_errors = validate_spec(spec, expected_document_type=document_type, expected_target="mixed")
        if spec_errors:
            errors.extend(f"{document_type}: spec: {error}" for error in spec_errors)
            continue

        html = render_html(spec)
        staged_path = unique_output_path(staging_dir, document_type)
        staged_path.write_text(html, encoding="utf-8")
        html_errors = validate_html(html, document_type)
        if html_errors:
            errors.extend(f"{document_type}: html: {error}" for error in html_errors)
            continue

        final_path = unique_output_path(final_dir, document_type)
        final_path.write_text(staged_path.read_text(encoding="utf-8"), encoding="utf-8")
        if not final_path.exists() or final_path.stat().st_size == 0:
            errors.append(f"{document_type}: final promotion failed")

    if errors or keep:
        return errors
    shutil.rmtree(work_dir, ignore_errors=True)
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Run end-to-end smoke tests for report-creator.")
    parser.add_argument("--work-dir", help="Directory for generated smoke-test files")
    parser.add_argument("--keep", action="store_true", help="Keep generated smoke-test files")
    args = parser.parse_args()

    if args.work_dir:
        work_dir = Path(args.work_dir).expanduser()
        cleanup = False
    else:
        work_dir = Path(tempfile.mkdtemp(prefix="report-creator-smoke-"))
        cleanup = not args.keep

    errors = run(work_dir, keep=args.keep or not cleanup)
    if errors:
        print("SMOKE TEST FAILED")
        for error in errors:
            print(f"- {error}")
        print(f"work_dir={work_dir}")
        return 1
    print("SMOKE TEST PASSED")
    if args.keep or args.work_dir:
        print(f"work_dir={work_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
