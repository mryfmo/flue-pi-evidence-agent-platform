#!/usr/bin/env python3
"""Render a self-contained Japanese HTML report from a Report Spec JSON file.

The script intentionally uses only Python's standard library and writes a single
HTML file with embedded CSS. It escapes all provided text.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from datetime import datetime
from html import escape
from pathlib import Path
from typing import Any, Iterable

from validate_spec import validate_spec

VALID_TYPES = {"summary", "roadmap", "proposal", "analysis", "pitch", "retro", "status", "discussion"}
VALID_TARGETS = {"general", "bizlead", "engineer", "mixed"}

TYPE_LABELS = {
    "summary": "サマリ",
    "roadmap": "ロードマップ",
    "proposal": "実現性検討",
    "analysis": "分析報告",
    "pitch": "提案資料",
    "retro": "振り返り",
    "status": "状況共有",
    "discussion": "議論整理",
}

TARGET_LABELS = {
    "general": "一般向け",
    "bizlead": "事業責任者向け",
    "engineer": "エンジニア向け",
    "mixed": "事業・技術混在向け",
}

@dataclass
class RenderContext:
    document_type: str
    target: str
    generated_at: datetime


def text(value: Any) -> str:
    return escape(str(value or ""), quote=True)


def as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def render_paragraph(block: dict[str, Any], ctx: RenderContext) -> str:
    return f"<p>{text(block.get('text'))}</p>"


def render_bullets(block: dict[str, Any], ctx: RenderContext) -> str:
    items = "".join(f"<li>{text(item)}</li>" for item in as_list(block.get("items")))
    return f"<ul>{items}</ul>" if items else ""


def render_table(block: dict[str, Any], ctx: RenderContext) -> str:
    headers = as_list(block.get("headers"))
    rows = as_list(block.get("rows"))
    thead = "".join(f"<th scope=\"col\">{text(h)}</th>" for h in headers)
    body_rows = []
    for row in rows:
        cells = "".join(f"<td>{text(cell)}</td>" for cell in as_list(row))
        body_rows.append(f"<tr>{cells}</tr>")
    return f"<div class=\"table-wrap\"><table><thead><tr>{thead}</tr></thead><tbody>{''.join(body_rows)}</tbody></table></div>"


def render_cards(block: dict[str, Any], ctx: RenderContext) -> str:
    cards = []
    for card in as_list(block.get("cards")):
        if not isinstance(card, dict):
            continue
        badge = card.get("badge")
        badge_html = f"<span class=\"mini-badge\">{text(badge)}</span>" if badge else ""
        cards.append(
            "<article class=\"info-card\">"
            f"<div class=\"info-card-head\"><h3>{text(card.get('title'))}</h3>{badge_html}</div>"
            f"<p>{text(card.get('body'))}</p>"
            "</article>"
        )
    return f"<div class=\"card-grid\">{''.join(cards)}</div>" if cards else ""


def render_timeline(block: dict[str, Any], ctx: RenderContext) -> str:
    items = []
    for item in as_list(block.get("items")):
        if not isinstance(item, dict):
            continue
        items.append(
            "<article class=\"timeline-item\">"
            f"<div class=\"timeline-label\">{text(item.get('label'))}</div>"
            f"<h3>{text(item.get('title'))}</h3>"
            f"<p>{text(item.get('body'))}</p>"
            "</article>"
        )
    return f"<div class=\"timeline\">{''.join(items)}</div>" if items else ""


def render_key_values(block: dict[str, Any], ctx: RenderContext) -> str:
    items = []
    for item in as_list(block.get("items")):
        if not isinstance(item, dict):
            continue
        items.append(f"<dt>{text(item.get('key'))}</dt><dd>{text(item.get('value'))}</dd>")
    return f"<dl class=\"key-values\">{''.join(items)}</dl>" if items else ""


def render_details(block: dict[str, Any], ctx: RenderContext) -> str:
    inner = render_blocks(as_list(block.get("blocks")), ctx)
    return f"<details><summary>{text(block.get('summary'))}</summary><div class=\"details-body\">{inner}</div></details>"


def render_progress(block: dict[str, Any], ctx: RenderContext) -> str:
    items = []
    for item in as_list(block.get("items")):
        if not isinstance(item, dict):
            continue
        label = text(item.get("label"))
        value_raw = str(item.get("value", "0")).replace("%", "")
        try:
            value = max(0, min(100, float(value_raw)))
        except ValueError:
            value = 0
        note = text(item.get("note"))
        items.append(
            "<div class=\"progress-row\">"
            f"<div class=\"progress-meta\"><span>{label}</span><span>{value:g}%</span></div>"
            f"<div class=\"progress-track\"><div class=\"progress-fill\" style=\"width:{value:g}%\"></div></div>"
            + (f"<div class=\"progress-note\">{note}</div>" if note else "")
            + "</div>"
        )
    return f"<div class=\"progress-list\">{''.join(items)}</div>" if items else ""


def render_comparison(block: dict[str, Any], ctx: RenderContext) -> str:
    columns = as_list(block.get("columns")) or [
        {"title": "できること", "items": as_list(block.get("can"))},
        {"title": "できないこと", "items": as_list(block.get("cannot"))},
        {"title": "条件", "items": as_list(block.get("conditions"))},
    ]
    rendered = []
    for col in columns:
        if not isinstance(col, dict):
            continue
        items = "".join(f"<li>{text(item)}</li>" for item in as_list(col.get("items")))
        rendered.append(f"<article class=\"comparison-card\"><h3>{text(col.get('title'))}</h3><ul>{items}</ul></article>")
    return f"<div class=\"comparison-grid\">{''.join(rendered)}</div>" if rendered else ""


def render_kpt(block: dict[str, Any], ctx: RenderContext) -> str:
    groups = [("Keep", block.get("keep")), ("Problem", block.get("problem")), ("Try", block.get("try"))]
    cards = []
    for title, values in groups:
        items = "".join(f"<li>{text(item)}</li>" for item in as_list(values))
        cards.append(f"<article class=\"kpt-card\"><h3>{title}</h3><ul>{items}</ul></article>")
    return f"<div class=\"kpt-grid\">{''.join(cards)}</div>"


def render_two_column(block: dict[str, Any], ctx: RenderContext) -> str:
    left = render_blocks(as_list(block.get("left")), ctx)
    right = render_blocks(as_list(block.get("right")), ctx)
    left_title = text(block.get("left_title", "サマリー"))
    right_title = text(block.get("right_title", "詳細"))
    return (
        "<div class=\"two-column\">"
        f"<article><h3>{left_title}</h3>{left}</article>"
        f"<article><h3>{right_title}</h3>{right}</article>"
        "</div>"
    )


def render_code(block: dict[str, Any], ctx: RenderContext) -> str:
    language = text(block.get("language", ""))
    code_text = text(block.get("code", block.get("text", "")))
    label = f"<div class=\"code-label\">{language}</div>" if language else ""
    return f"<div class=\"code-block\">{label}<pre><code>{code_text}</code></pre></div>"


BLOCK_RENDERERS = {
    "paragraph": render_paragraph,
    "bullets": render_bullets,
    "table": render_table,
    "cards": render_cards,
    "timeline": render_timeline,
    "details": render_details,
    "key_values": render_key_values,
    "progress": render_progress,
    "comparison": render_comparison,
    "kpt": render_kpt,
    "two_column": render_two_column,
    "code": render_code,
}


def render_blocks(blocks: Iterable[Any], ctx: RenderContext) -> str:
    html_parts: list[str] = []
    for block in blocks:
        if not isinstance(block, dict):
            continue
        renderer = BLOCK_RENDERERS.get(str(block.get("type")))
        if renderer:
            html_parts.append(renderer(block, ctx))
    return "\n".join(part for part in html_parts if part)


def render_metrics(metrics: list[Any]) -> str:
    cards = []
    for metric in metrics:
        if not isinstance(metric, dict):
            continue
        note = metric.get("note")
        note_html = f"<div class=\"metric-note\">{text(note)}</div>" if note else ""
        cards.append(
            "<article class=\"metric-card\">"
            f"<div class=\"metric-value\">{text(metric.get('value'))}</div>"
            f"<div class=\"metric-label\">{text(metric.get('label'))}</div>"
            f"{note_html}"
            "</article>"
        )
    return f"<section class=\"metrics\" aria-label=\"主要指標\">{''.join(cards)}</section>" if cards else ""


def render_actions(actions: list[Any]) -> str:
    if not actions:
        return ""
    rows = []
    for action in actions:
        if not isinstance(action, dict):
            continue
        rows.append(
            "<tr>"
            f"<td>{text(action.get('owner', '担当未定'))}</td>"
            f"<td>{text(action.get('action'))}</td>"
            f"<td>{text(action.get('due', '期限未定'))}</td>"
            f"<td>{text(action.get('status', '未着手'))}</td>"
            "</tr>"
        )
    if not rows:
        return ""
    return (
        "<section class=\"section actions\"><h2>ネクストアクション</h2>"
        "<div class=\"table-wrap\"><table><thead><tr>"
        "<th scope=\"col\">担当</th><th scope=\"col\">アクション</th><th scope=\"col\">期限</th><th scope=\"col\">状態</th>"
        f"</tr></thead><tbody>{''.join(rows)}</tbody></table></div></section>"
    )


def render_note_list(title: str, notes: list[Any], class_name: str) -> str:
    if not notes:
        return ""
    items = "".join(f"<li>{text(note)}</li>" for note in notes)
    return f"<section class=\"section {class_name}\"><h2>{text(title)}</h2><ul>{items}</ul></section>"


def render_sections(sections: list[Any], ctx: RenderContext) -> str:
    rendered = []
    for section in sections:
        if not isinstance(section, dict):
            continue
        lead = section.get("lead")
        lead_html = f"<p class=\"section-lead\">{text(lead)}</p>" if lead else ""
        blocks_html = render_blocks(as_list(section.get("blocks")), ctx)
        rendered.append(
            "<section class=\"section\">"
            f"<h2>{text(section.get('heading'))}</h2>"
            f"{lead_html}{blocks_html}"
            "</section>"
        )
    return "\n".join(rendered)


def status_badge(status: str | None, document_type: str) -> str:
    if not status and document_type != "status":
        return ""
    label = status or "ステータス未設定"
    css = "status-neutral"
    lowered = label.lower()
    if lowered in {"green", "順調", "🟢 順調"}:
        label = "🟢 順調"
        css = "status-green"
    elif lowered in {"yellow", "要注意", "🟡 要注意"}:
        label = "🟡 要注意"
        css = "status-yellow"
    elif lowered in {"red", "要対応", "🔴 要対応"}:
        label = "🔴 要対応"
        css = "status-red"
    return f"<div class=\"status-badge {css}\">{text(label)}</div>"


def css() -> str:
    return """
:root {
  --primary: #1a56db;
  --success: #057a55;
  --warning: #d97706;
  --danger: #e02424;
  --text: #374151;
  --subtext: #6b7280;
  --bg: #f5f7fa;
  --card: #ffffff;
  --border: #e5e7eb;
  --shadow: 0 2px 8px rgba(0,0,0,0.08);
}
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
  margin: 0;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.65;
}
.container { max-width: 1120px; margin: 0 auto; padding: 32px 24px 48px; }
.hero {
  background: linear-gradient(135deg, #ffffff 0%, #eef4ff 100%);
  border: 1px solid var(--border);
  border-radius: 24px;
  padding: 32px;
  box-shadow: var(--shadow);
  margin-bottom: 24px;
}
.badge-row { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 16px; align-items: center; }
.badge, .mini-badge {
  display: inline-flex;
  align-items: center;
  border-radius: 999px;
  padding: 4px 10px;
  background: #dbeafe;
  color: #1e40af;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: .02em;
}
.target { background: #ecfdf5; color: #065f46; }
.date { background: #f3f4f6; color: var(--subtext); }
h1 { font-size: clamp(28px, 4vw, 44px); line-height: 1.15; margin: 0 0 16px; }
h2 { font-size: 22px; margin: 0 0 14px; }
h3 { font-size: 16px; margin: 0 0 8px; }
p { margin: 0 0 12px; }
ul { margin-top: 0; padding-left: 1.4em; }
.summary { font-size: 18px; color: #1f2937; margin: 0; }
.status-badge { margin-top: 16px; display: inline-flex; padding: 10px 14px; border-radius: 12px; font-weight: 800; }
.status-green { background: #d1fae5; color: #065f46; }
.status-yellow { background: #fef3c7; color: #92400e; }
.status-red { background: #fee2e2; color: #991b1b; }
.status-neutral { background: #f3f4f6; color: #374151; }
.metrics { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 24px; }
.metric-card, .section, .info-card, .timeline-item {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 18px;
  box-shadow: var(--shadow);
}
.metric-card { padding: 20px; }
.metric-value { font-size: 30px; line-height: 1.1; font-weight: 850; color: var(--primary); }
.metric-label { margin-top: 6px; font-weight: 700; }
.metric-note { margin-top: 6px; color: var(--subtext); font-size: 13px; }
.section { padding: 24px; margin-bottom: 18px; }
.section-lead { color: var(--subtext); font-weight: 600; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; margin: 12px 0; }
.info-card { padding: 16px; box-shadow: none; }
.info-card-head { display: flex; justify-content: space-between; gap: 8px; align-items: flex-start; }
.timeline { display: flex; gap: 14px; overflow-x: auto; padding: 4px 0 8px; }
.timeline-item { min-width: 220px; padding: 16px; position: relative; box-shadow: none; }
.timeline-label { color: var(--primary); font-weight: 800; font-size: 13px; margin-bottom: 8px; }
.table-wrap { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 14px; }
th, td { border-bottom: 1px solid var(--border); padding: 10px 8px; text-align: left; vertical-align: top; }
th { background: #f9fafb; color: #111827; font-weight: 800; }
.key-values { display: grid; grid-template-columns: minmax(120px, 220px) 1fr; gap: 8px 16px; }
.key-values dt { font-weight: 800; color: #111827; }
.key-values dd { margin: 0; }

.timeline-item::before {
  content: "";
  position: absolute;
  top: -7px;
  left: 24px;
  width: 12px;
  height: 12px;
  background: var(--primary);
  transform: rotate(45deg);
  border-radius: 2px;
}
.progress-list { display: grid; gap: 12px; }
.progress-meta { display: flex; justify-content: space-between; font-weight: 800; margin-bottom: 4px; }
.progress-track { height: 12px; background: #e5e7eb; border-radius: 999px; overflow: hidden; }
.progress-fill { height: 100%; background: var(--primary); border-radius: 999px; }
.progress-note { color: var(--subtext); font-size: 13px; margin-top: 4px; }
.comparison-grid, .kpt-grid, .two-column { display: grid; gap: 14px; }
.comparison-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.kpt-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.two-column { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.comparison-card, .kpt-card, .two-column > article { border: 1px solid var(--border); border-radius: 16px; padding: 16px; background: #ffffff; }
.kpt-card:nth-child(1) { border-top: 5px solid var(--success); }
.kpt-card:nth-child(2) { border-top: 5px solid var(--danger); }
.kpt-card:nth-child(3) { border-top: 5px solid var(--primary); }
.code-block { background: #111827; color: #f9fafb; border-radius: 14px; overflow: hidden; margin: 12px 0; }
.code-label { background: #374151; color: #d1d5db; padding: 6px 10px; font-size: 12px; font-weight: 800; }
.code-block pre { margin: 0; padding: 14px; overflow-x: auto; }
.code-block code { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace; }

details { border: 1px solid var(--border); border-radius: 14px; padding: 12px 14px; background: #fbfdff; margin: 12px 0; }
summary { cursor: pointer; font-weight: 800; }
.details-body { padding-top: 10px; }
.assumptions { border-left: 6px solid var(--warning); }
.source-notes { border-left: 6px solid var(--primary); }
footer { color: var(--subtext); font-size: 12px; text-align: center; margin-top: 32px; }
@media (max-width: 900px) {
  .container { padding: 20px 14px 36px; }
  .hero { padding: 24px; }
  .timeline { flex-direction: column; }
  .timeline-item { min-width: unset; }
  .key-values { grid-template-columns: 1fr; }
  .comparison-grid, .kpt-grid, .two-column { grid-template-columns: 1fr; }
}
@media print {
  body { background: #fff; }
  .container { max-width: none; padding: 0; }
  .hero, .section, .metric-card, .info-card, .timeline-item { box-shadow: none; break-inside: avoid; }
}
""".strip()


def render_html(spec: dict[str, Any]) -> str:
    document_type = str(spec.get("document_type", "summary"))
    target = str(spec.get("target", "general"))
    if document_type not in VALID_TYPES:
        raise ValueError(f"Invalid document_type: {document_type}")
    if target not in VALID_TARGETS:
        raise ValueError(f"Invalid target: {target}")
    title = str(spec.get("title") or f"{TYPE_LABELS[document_type]}")
    now = datetime.now()
    ctx = RenderContext(document_type=document_type, target=target, generated_at=now)
    generated_label = now.strftime("%Y-%m-%d %H:%M:%S")
    summary = spec.get("summary")
    summary_html = f"<p class=\"summary\">{text(summary)}</p>" if summary else ""
    html = f"""<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{text(title)}</title>
  <style>{css()}</style>
</head>
<body>
  <div class="container">
    <header class="hero">
      <div class="badge-row">
        <span class="badge">{text(TYPE_LABELS[document_type])}</span>
        <span class="badge target">{text(TARGET_LABELS[target])}</span>
        <span class="badge date">生成日時: {text(generated_label)}</span>
      </div>
      <h1>{text(title)}</h1>
      {summary_html}
      {status_badge(spec.get('status'), document_type)}
    </header>
    {render_metrics(as_list(spec.get('metrics')))}
    <main>
      {render_sections(as_list(spec.get('sections')), ctx)}
      {render_actions(as_list(spec.get('actions')))}
      {render_note_list('前提・未確定事項', as_list(spec.get('assumptions')), 'assumptions')}
      {render_note_list('ソース・生成メモ', as_list(spec.get('source_notes')), 'source-notes')}
    </main>
    <footer>
      このドキュメントはAIが生成しました。内容は必要に応じて人間が確認してください。<br>
      Generated at {text(generated_label)}
    </footer>
  </div>
</body>
</html>
"""
    return html


def unique_output_path(output_dir: Path, document_type: str) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    base = output_dir / f"{document_type}_{timestamp}.html"
    if not base.exists():
        return base
    for idx in range(1, 1000):
        candidate = output_dir / f"{document_type}_{timestamp}_{idx}.html"
        if not candidate.exists():
            return candidate
    raise RuntimeError("Could not create a unique output filename")


def main() -> int:
    parser = argparse.ArgumentParser(description="Render a self-contained HTML report from a Report Spec JSON file.")
    parser.add_argument("--spec", required=True, help="Path to Report Spec JSON")
    parser.add_argument("--output-dir", default=".", help="Directory where the HTML report should be written")
    args = parser.parse_args()

    spec_path = Path(args.spec).expanduser()
    output_dir = Path(args.output_dir).expanduser()
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    errors = validate_spec(spec)
    if errors:
        print("SPEC VALIDATION FAILED")
        for error in errors:
            print(f"- {error}")
        return 1
    html = render_html(spec)
    output_path = unique_output_path(output_dir, str(spec.get("document_type", "summary")))
    output_path.write_text(html, encoding="utf-8")
    print(output_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
