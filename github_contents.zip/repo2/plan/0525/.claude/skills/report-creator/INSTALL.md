# Install and Validate `report-creator`

This Skill is designed for the project-level production bundle at the repository root:

```text
.claude/skills/report-creator/
.claude/agents/report-input-auditor.md
.claude/agents/report-quality-reviewer.md
.claude/agents/report-compliance-reviewer.md
.claude/hooks/*.py
.claude/settings.json
```

A Skill-only copy can run the renderer and validators, but it does not provide the production controls. For production use, install the entire bundle rather than copying only this directory.

## Validate the Skill package

From the project root:

```bash
python3 .claude/skills/report-creator/scripts/validate_skill_package.py
python3 .claude/skills/report-creator/scripts/smoke_test.py --work-dir /tmp/report-creator-smoke
```

Expected result:

```text
PASS
SMOKE TEST PASSED
```

## Validate a generated spec manually

```bash
python3 .claude/skills/report-creator/scripts/validate_spec.py \
  --spec .claude/skills/report-creator/examples/analysis_mixed_spec.json \
  --document-type analysis \
  --target mixed
```

## Render and validate an example

```bash
HTML_PATH=$(python3 .claude/skills/report-creator/scripts/render_report.py \
  --spec .claude/skills/report-creator/examples/analysis_mixed_spec.json \
  --output-dir /tmp/report-creator-output)

python3 .claude/skills/report-creator/scripts/validate_report.py \
  --html "$HTML_PATH" \
  --document-type analysis
```

## Invoke

```text
/report-creator [input_file?] [document_type?] [target?]
```

Production output locations:

- Spec JSON: `.report-creator/specs/`
- HTML: `reports/generated/`
- Audit log: `.report-creator/audit/tool-events.jsonl`
