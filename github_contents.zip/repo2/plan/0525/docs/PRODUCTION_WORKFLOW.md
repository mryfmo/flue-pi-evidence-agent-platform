# Report Creator Production Workflow

## Purpose

Generate exactly one self-contained Japanese HTML report from trusted source material or conversation context, with deterministic validation, isolated review, and auditable execution.

## Control-layer model

| Layer | Production responsibility | Failure mode handled |
|---|---|---|
| Workflow | Defines the required sequence, artifacts, gates, retry path, and final response contract. | Prevents ad hoc execution and incomplete delivery. |
| Skill | Provides the Claude Code `/report-creator` entrypoint and compact standing instructions. | Prevents prompt drift and keeps report rules reusable. |
| SubAgents | Perform isolated input, quality, and compliance review without polluting the main context. | Catches weak evidence, hallucination risk, target mismatch, and compliance issues. |
| Hooks | Deterministically enforce runtime policy and audit tool use. | Prevents unsafe Bash, network calls, uncontrolled writes, and premature completion. |

## Required phases

1. **Invocation**
   - User invokes `/report-creator`.
   - `UserPromptExpansion` hook creates an active run state under `.report-creator/state/`.

2. **Argument normalization**
   - Resolve `input_file`, `document_type`, and `target`.
   - Use defaults only when no valid argument is provided.

3. **Source read and input audit**
   - Read the input file or conversation context.
   - Run `report-input-auditor`.
   - Stop on `block`; revise assumptions on `revise`.

4. **Report Spec drafting**
   - Write `.report-creator/specs/report_spec_{document_type}_{timestamp}.json`.
   - Preserve uncertainty as `TBD`, `要確認`, `担当未定`, or `期限未定`.

5. **Spec validation**
   - Run `validate_spec.py`.
   - Do not render until this passes.

6. **Deterministic rendering**
   - Run `render_report.py`.
   - Output one HTML file under `reports/generated/`.

7. **HTML validation**
   - Run `validate_report.py`.
   - Fix the spec and rerun from phase 5 if validation fails.

8. **SubAgent review gates**
   - Run `report-quality-reviewer`.
   - Run `report-compliance-reviewer`.
   - On `revise`, update the spec and rerun phases 5 through 8.
   - On `block`, stop and report the blocker.

9. **Final response**
   - Include HTML path, spec path, title, document type, target, assumptions, unresolved caveats, machine gate results, and subagent gate results.
   - Do not paste full HTML unless explicitly requested.

## Required artifacts

| Artifact | Location | Owner |
|---|---|---|
| Report Spec JSON | `.report-creator/specs/` | Skill/main agent |
| HTML report | `reports/generated/` | Renderer |
| Tool audit log | `.report-creator/audit/tool-events.jsonl` | PostToolUse hook |
| Active/completed state | `.report-creator/state/` | Hooks |

## Stop gate

The Stop hook blocks completion until all of the following are true for the active session:

- `validate_spec.py` passed.
- `render_report.py` produced an HTML path.
- `validate_report.py` passed.
- `report-input-auditor` completed and returned `decision: pass`.
- `report-quality-reviewer` completed and returned `decision: pass`.
- `report-compliance-reviewer` completed and returned `decision: pass`.

This gate makes incomplete production runs visible instead of relying on the model to remember every step.

## Retry policy

Any failed machine validation or reviewer `revise` decision requires this loop:

```text
update Report Spec → validate spec → render HTML → validate HTML → quality review → compliance review
```

Do not patch generated HTML by hand. The Report Spec is the source of truth.
