# Operations Runbook

## Normal run

1. Start Claude Code from the project root.
2. Invoke `/report-creator ...`.
3. Confirm final response lists all required gates as passed.
4. Review `reports/generated/<file>.html`.
5. Archive or commit `.report-creator/specs/<file>.json` when traceability is required.

## Gate failure

| Failure | Response |
|---|---|
| Input auditor returns `block` | Do not generate. Ask for better source material or narrower scope. |
| Spec validation fails | Fix Report Spec only; rerun validation. |
| HTML validation fails | Fix Report Spec or renderer input; rerender. Do not hand-edit HTML. |
| Quality reviewer returns `revise` | Update structure/content, rerun all downstream gates. |
| Compliance reviewer returns `block` | Remove unsafe content or unsupported claim, rerun all downstream gates. |
| Stop hook blocks | Complete the listed missing gates, including any non-`pass` SubAgent decision, or explicitly abort by removing the active state file after recording the reason. |

## Audit locations

- Tool event log: `.report-creator/audit/tool-events.jsonl`
- Session state: `.report-creator/state/<session-id>.json`
- Specs: `.report-creator/specs/`
- Reports: `reports/generated/`

## Policy adjustments

Edit `.claude/settings.json` only through project review. Preserve these principles:

- Deny rules are stricter than allow rules.
- Report generation does not need web access.
- Arbitrary Bash is not required for production report creation.
- SubAgents are read-only reviewers.
