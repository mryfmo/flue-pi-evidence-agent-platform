# Production Design Decisions

## Why not Skill-only?

A Skill can tell Claude what to do, but it cannot by itself guarantee that runtime behavior follows the policy. Claude Code's `allowed-tools` pre-approves matching tools; it is not a denylist. Therefore, production control requires permissions and hooks outside the Skill.

## Why include Hooks?

Hooks are deterministic. They run at lifecycle events and can block or audit behavior regardless of whether the model remembered a rule. This bundle uses them for command guarding, state tracking, audit logging, and stop gating.

## Why include SubAgents?

The main agent is responsible for generation. Review responsibilities are separated into read-only SubAgents so that input audit, quality review, and compliance review happen in isolated contexts with narrow tools.

## Why use Report Spec as source of truth?

Generated HTML is deterministic output from the Report Spec. Corrections should happen in the Spec, then be revalidated and rerendered. This preserves traceability and prevents unreviewed manual HTML drift.

## Why deny network access?

The workflow creates a report from provided source material or conversation context. Network access is not required and creates unnecessary exfiltration and reproducibility risk.
