# 代替VIEW候補 調査レポート

**作成日**: 2026-04-10  
**調査対象**: summary-report_20260330.md の「移行先VIEW未確定」アプリ・VIEW全件  
**調査方法**: snowflake-explorer / search_catalog_views.py（Alationカタログ検索）

---

## 1. 調査概要

summary-report_20260330.md に記載された対応アプリのうち、以下のパターンのVIEWを対象に代替候補を調査した。

| パターン | 説明 |
|---|---|
| 削除(代替無し) | 明示的に代替なし |
| 残留(方針検討中) | 移行先「ー（確認中）」 |
| 断捨離(ADM/DWH層代替) | 移行先「ー（別管理）」 |
| 個別マスタ別途 | 移行先「ー（別管理）」 |
| 検討中(内容吟味) | 移行先「ー（別管理）」 |
| リファクタ(ALADIN) | 移行先「ー（別管理）」 |
| dMC廃止 | 代替なし（別管理） |

---

## 2. 代替候補が見つかったVIEW

### 2-1. L_MR_000スキーマへの移行で対応できるケース（同名VIEWが存在）

以下のVIEWは **スキーマを `D_MR_000` → `L_MR_000` に変更するだけで対応できる可能性が高い**。  
ただしカラム定義の差分確認は必要。

| 廃止VIEW（D_MR_000） | 代替候補VIEW | スキーマ | 論理名 | 更新頻度 |
|---|---|---|---|---|
| `VW_ADW_DNCL_SALESOUTLET_DETAILS_MASTER` | `VW_ADW_DNCL_SALESOUTLET_DETAILS_MASTER` | **L_MR_000** | VW_ADW_DNCL_販売店詳細マスター | 日次 |
| `VW_ADW_DNCL_SALESOUTLET_MASTER` | `VW_ADW_DNCL_SALESOUTLET_MASTER` | **L_MR_000** | VW_ADW_DNCL_販売店マスター | 日次 |
| `VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER` | `VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER` | **L_MR_000** | VW_ADW_DNCL_祝日マスター | 日次 |
| `VW_ADW_DNHL_HOPE_ORDER_BASIC_KI` | `VW_ADW_DNHL_HOPE_ORDER_BASIC_KI` | **L_MR_000** | VW_ADW_DNHL_見込オーダー基本履歴(会員) | 日次 |
| `VW_ADW_DNHL_HOPE_ORDER_SUBJECT_KI` | `VW_ADW_DNHL_HOPE_ORDER_SUBJECT_KI` | **L_MR_000** | VW_ADW_DNHL_見込オーダー対象履歴(会員) | 日次 |
| `VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER` | `VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER` | **L_MR_000** | VW_ADM_MECL_アクション別料金マスター | 月次(毎月1日、6日) |
| `VW_ADM_DNCL_COMNID_INTEGRATION` | `VW_ADM_DNCL_COMNID_INTEGRATION` | **L_MR_000** | VW_ADM_DNCL_共通IDグループ統合 | 日次 |

**Alationカタログ URL（参考）:**
- L_MR_000 SALESOUTLET_DETAILS: https://nttdocomo.ap.alationcloud.com/app/table/54932/overview
- L_MR_000 SALESOUTLET_MASTER: https://nttdocomo.ap.alationcloud.com/app/table/54484/overview
- L_MR_000 PUBLIC_HOLIDAY_MASTER: https://nttdocomo.ap.alationcloud.com/app/table/55013/overview
- L_MR_000 HOPE_ORDER_BASIC_KI: https://nttdocomo.ap.alationcloud.com/app/table/54487/overview
- L_MR_000 HOPE_ORDER_SUBJECT_KI: https://nttdocomo.ap.alationcloud.com/app/table/55067/overview
- L_MR_000 CLASSIFIEDBYACTION_FEE_MASTER: https://nttdocomo.ap.alationcloud.com/app/table/54181/overview
- L_MR_000 COMNID_INTEGRATION: https://nttdocomo.ap.alationcloud.com/app/table/55116/overview

---

### 2-2. 別VIEWへの移行が必要なケース

| 廃止VIEW | 対応方針 | 代替候補VIEW | スキーマ | 論理名 | 備考 |
|---|---|---|---|---|---|
| `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 残留(方針検討中) | `VW_ADW_DNCD_SALESOUTLET_MASTER` | D_MR_000 | VW_ADW_DNCD_販売店マスター | ALADINの販売店マスタ。カラム差分要確認 |
| `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 残留(方針検討中) | `VW_ADW_DNCL_SALESOUTLET_AGGREGATION_MASTER` | L_MR_000 | VW_ADW_DNCL_販売店集約マスター | 上記の代替候補その2 |
| `VW_ADM_DNCD_DEALER_DETAILS_MASTER` | 残留(方針検討中) | `VW_ADM_DNCD_DEALER_DETAILS_MASTER` | D_MR_000 | VW_ADM_DNCD_販売店詳細マスター | Alation上で現在も公開中・削除期限未設定。継続利用可能か要確認 |
| `VW_ADW_MECL_BASIC_CONTRACT` | リファクタ(ALADIN) | D_CM_000新設VIEW（別管理） | D_CM_000 | ー | 月次契約系はD_CM_000新設VIEWへの移行を別途検討中 |
| `VW_ADW_DNHL_GROUP_BASIC_HISTORY` | リファクタ(ALADIN) | `VW_ADW_DNHL_COMNID_CONFIGURATION_INTEGRATION` | L_MR_000 | VW_ADW_DNHL_共通IDグループ構成統合履歴 | グループ加入履歴の代替候補。カラム差分要確認 |
| `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` | 削除(代替無し) | `VW_ADM_DNCL_SERVICE_USE_PROFILE` | L_MR_000 | VW_ADM_DNCL_サービス利用プロファイル（日次） | 過去90日分・日次カレント。カラム対応要確認 |
| `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` | 削除(代替無し) | `VW_ADM_MECL_SERVICE_USE_PROFILE` | L_MR_000 | VW_ADM_MECL_サービス利用プロファイル（月次） | 過去37ヶ月分・月次カレント。カラム対応要確認 |
| `VW_DTT_DNHD_DOCOMO_SPORTSKUJI_SERVICE_USE` | 残留(リファクタ有り) | `VW_DTT_DNHL_SERVICE_MEMBER` | L_MR_000 | VW_DTT_DNHL_サービス会員 | ドコモスポーツくじのサービス会員VIEW（レポート移行先と一致） |
| `VW_ADW_MECL_CLAIM_ELABORATED` | リファクタ(MoBills) | MoBills系請求VIEW（要個別確認） | ー | ー | 請求系VIEWが50件ヒット。MoBills移行先を個別確認要 |

**Alationカタログ URL（参考）:**
- D_MR_000 SALESOUTLET_MASTER: https://nttdocomo.ap.alationcloud.com/app/table/6170/overview
- L_MR_000 SALESOUTLET_AGGREGATION_MASTER: https://nttdocomo.ap.alationcloud.com/app/table/54582/overview
- D_MR_000 DEALER_DETAILS_MASTER: https://nttdocomo.ap.alationcloud.com/app/table/5959/overview
- L_MR_000 COMNID_CONFIGURATION_INTEGRATION: https://nttdocomo.ap.alationcloud.com/app/table/54863/overview
- L_MR_000 SERVICE_USE_PROFILE (日次): https://nttdocomo.ap.alationcloud.com/app/table/55080/overview
- L_MR_000 SERVICE_USE_PROFILE (月次): https://nttdocomo.ap.alationcloud.com/app/table/54756/overview
- L_MR_000 DTT_SERVICE_MEMBER: https://nttdocomo.ap.alationcloud.com/app/table/54441/overview

---

## 3. 代替候補が見つからなかったVIEW

| 廃止VIEW | 対応方針 | 影響アプリ | 理由 |
|---|---|---|---|
| `VUSER_CUST_INFO` | dMC廃止 | 配信対象者抽出、滞在施設みえる化、d払いNW見える化 | dMC廃止。性別・年代・住所・同意・許諾を横断統合するVIEWはAlationに存在しない |
| `VUSER_SO_CONTRACT_CURRENT` | dMC廃止 | 滞在施設みえる化 | dMC廃止。光/home5G/homeでんわ契約有無フィルタの後継なし |
| `VW_PGN_MECD_STARTDASH_BASIC_ATTRIBUTE_AREA_OTHER` | 削除(代替無し) | Snowcampゼロ次分析(MI部) | 「婚姻有無」「子供有無」属性を持つVIEWがAlationにヒットなし |
| `VW_ADM_DNCL_HUMAN_BASIC` | 断捨離(ADM) | 契約状態抽出 | 「法人/個人区分」専用VIEWの後継なし（契約系VIEWのカラムとして含まれている可能性はある） |
| `VW_ADM_DNCD_BASE_NUMBER_ACCTID_CONVERSION_MASTER` | 残留(方針検討中) | データ活用広告配信向け広告ID変換 | L_MR_000に後継候補見つからず。別途確認要 |
| `VW_ADW_MECL_SERVICE_BASIC` | リファクタ(ALADIN) / VIEW統合 | データ活用広告配信向け広告ID変換 | 統合予定だが後継VIEW未確定 |
| `VW_ADW_MECL_SERVICE_BASIC_2` | VIEW統合 | データ活用広告配信向け広告ID変換 | VW_ADW_MECL_SERVICE_BASICと統合予定だが未確定 |
| `VW_ADW_MECL_SERVICE_BASIC_3` | VIEW統合 | データ活用広告配信向け広告ID変換 | VW_ADW_MECL_SERVICE_BASICと統合予定だが未確定 |
| `VW_ADW_DNCL_STAFF_DETAILS` | 検討中(内容吟味) | 事業OP九州アプリ | スタッフ数分析専用VIEWの後継なし |
| `VW_ADW_DNCD_ADDRESS_MASTER` | 残留(方針検討中) | 事業OP九州アプリ、最寄りドコモショップ検索、総合ARPU分析 | 住所系VIEWは複数存在するが同等のADW層VIEWを特定できず（要個別確認） |
| `VW_ADW_DNCD_ADDRESS_AGGREGATION_MASTER` | 残留(方針検討中) | 事業OP九州アプリ | 同上 |

---

## 4. アプリ別 対応状況サマリー

| App | アプリ名 | 廃止VIEW | 代替候補 |
|:---:|---|---|---|
| 2 | テレマ施策効果確認アプリ | `VW_ADW_DNCL_SALESOUTLET_DETAILS_MASTER` | ✅ L_MR_000に同名VIEW |
| 2 | テレマ施策効果確認アプリ | `VW_ADW_DNCL_SALESOUTLET_MASTER` | ✅ L_MR_000に同名VIEW |
| 2 | テレマ施策効果確認アプリ | `VW_ADW_DNHL_HOPE_ORDER_BASIC_KI` | ✅ L_MR_000に同名VIEW |
| 2 | テレマ施策効果確認アプリ | `VW_ADW_DNHL_HOPE_ORDER_SUBJECT_KI` | ✅ L_MR_000に同名VIEW |
| 2 | テレマ施策効果確認アプリ | `VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER` | ✅ L_MR_000に同名VIEW |
| 3 | DSフムフム | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 🔶 `VW_ADW_DNCD_SALESOUTLET_MASTER`（要差分確認） |
| 3 | DSフムフム | `VW_ADW_DNCL_CATALOG_LIST` | 要調査 |
| 3 | DSフムフム | `VW_ADW_DNHL_GROUP_BASIC_HISTORY` | 🔶 `VW_ADW_DNHL_COMNID_CONFIGURATION_INTEGRATION`（要差分確認） |
| 4 | 加盟店送客 | `VW_ADM_DNCL_COMNID_INTEGRATION` | ✅ L_MR_000に同名VIEW |
| 5 | 時系列分析アプリ | `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` | 🔶 `VW_ADM_DNCL/MECL_SERVICE_USE_PROFILE`（要カラム確認） |
| 7 | 滞在施設みえる化 | `VW_ADM_DNCD_DEALER_DETAILS_MASTER` | 🔶 D_MR_000に継続公開中（期限要確認） |
| 7 | 滞在施設みえる化 | `VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER` | ✅ L_MR_000に同名VIEW |
| 7 | 滞在施設みえる化 | `VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER` | ✅ L_MR_000に同名VIEW |
| 7 | 滞在施設みえる化 | `VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER` | 要調査 |
| 7 | 滞在施設みえる化 | `VW_ADM_DNCL_COMNID_INTEGRATION` | ✅ L_MR_000に同名VIEW |
| 7 | 滞在施設みえる化 | `VUSER_CUST_INFO` | ❌ 代替なし（dMC廃止） |
| 7 | 滞在施設みえる化 | `VUSER_SO_CONTRACT_CURRENT` | ❌ 代替なし（dMC廃止） |
| 8 | 事業OP九州アプリ | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 🔶 `VW_ADW_DNCD_SALESOUTLET_MASTER`（要差分確認） |
| 8 | 事業OP九州アプリ | `VW_ADW_DNCD_ADDRESS_AGGREGATION_MASTER` | ❌ 特定できず（要個別確認） |
| 8 | 事業OP九州アプリ | `VW_ADW_DNCD_ADDRESS_MASTER` | ❌ 特定できず（要個別確認） |
| 8 | 事業OP九州アプリ | `VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER` | ✅ L_MR_000に同名VIEW |
| 8 | 事業OP九州アプリ | `VW_ADW_DNCL_STAFF_DETAILS` | ❌ 代替なし |
| 8 | 事業OP九州アプリ | `VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER` | 要調査 |
| 11 | KGI/KPI課題分析 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 🔶 `VW_ADW_DNCD_SALESOUTLET_MASTER`（要差分確認） |
| 12 | 広告ID変換 | `VW_ADM_DNCL_COMNID_INTEGRATION` | ✅ L_MR_000に同名VIEW |
| 12 | 広告ID変換 | `VW_ADM_DNCD_BASE_NUMBER_ACCTID_CONVERSION_MASTER` | ❌ 特定できず |
| 12 | 広告ID変換 | `VW_ADW_MECL_SERVICE_BASIC/2/3` | ❌ 統合後VIEW未確定 |
| 12 | 広告ID変換 | `VW_DTT_DNHD_DOCOMO_SPORTSKUJI_SERVICE_USE` | ✅ `VW_DTT_DNHL_SERVICE_MEMBER`（L_MR_000） |
| 15 | d払い決済状況見える化 | `VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER` | 要調査 |
| 16 | ID変換器 | `VW_ADM_DNCL_COMNID_INTEGRATION` | ✅ L_MR_000に同名VIEW |
| 17 | 最寄りドコモショップ検索 | `VW_ADM_DNCD_DEALER_DETAILS_MASTER` | 🔶 D_MR_000に継続公開中（期限要確認） |
| 17 | 最寄りドコモショップ検索 | `VW_ADW_DNCD_ADDRESS_MASTER` | ❌ 特定できず（要個別確認） |
| 18 | お客様の声みえる化 | `VW_ADM_DNCL_COMNID_INTEGRATION` | ✅ L_MR_000に同名VIEW |
| 1 | 契約状態抽出 | `VW_ADM_DNCL_COMNID_INTEGRATION` | ✅ L_MR_000に同名VIEW |
| 1 | 契約状態抽出 | `VW_ADM_DNCL_HUMAN_BASIC` | ❌ 代替なし |
| 23 | 店舗NPSアンケート分析 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 🔶 `VW_ADW_DNCD_SALESOUTLET_MASTER`（要差分確認） |
| 24 | 総合ARPU分析 | `VW_ADW_DNCD_ADDRESS_MASTER` | ❌ 特定できず（要個別確認） |
| 25 | 来店促進分析 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 🔶 `VW_ADW_DNCD_SALESOUTLET_MASTER`（要差分確認） |
| 27 | DS代理店/店舗販売状況 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 🔶 `VW_ADW_DNCD_SALESOUTLET_MASTER`（要差分確認） |
| 28 | 手数料シミュレータ | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 🔶 `VW_ADW_DNCD_SALESOUTLET_MASTER`（要差分確認） |
| 29 | Snowcampゼロ次分析 | `VW_PGN_MECD_STARTDASH_BASIC_ATTRIBUTE_AREA_OTHER` | ❌ 代替なし（婚姻・子供属性VIEW不在） |
| 2 | テレマ施策効果確認アプリ | `VW_ADW_DNCL_PRODUCT_ATTRIBUTE_MASTER` | 要調査 |
| 14 | ロイヤルカスタマー分析 | `VW_ADW_MECL_CLAIM_ELABORATED` | 🔶 MoBills系請求VIEW（要個別確認） |

---

---

## 6. カラムレベル代替候補調査（❌VIEWのキーカラム）

**調査日**: 2026-04-10  
**調査方法**: snowflake-explorer / search_catalog_columns.py（Alationカタログ検索）  
**対象**: セクション3で「代替候補なし（❌）」と判定したVIEW

---

### 6-1. VUSER_CUST_INFO（D_MA_000 / dMC廃止）

アプリ「配信対象者抽出」「滞在施設みえる化」「d払いNW見える化」で使用

| キーカラム | カラム論理名 | 代替候補VIEW | スキーマ | 代替カラム | 評価 |
|---|---|---|---|---|---|
| `BLK_ACNT_FLG` | ブラックアカウント認定フラグ | `VW_DMC_HNCL_CUSTOMER_ATTRIBUTE_INFORMATION` | L_MR_000 | `BLACK_ACCOUNT_CERTIFICATION_FLAG` | 🔶 同義カラムあり。VIEW論理名「VW_DMC_HNCL_顧客属性情報」 |
| `DACNT_PSN_FLG` | dアカウント保有フラグ | `VUSER_KAIIN_INFO` | D_MA_000 | `DACNT_PSN_FLG` | 🔶 同名・同義カラム。会員属性情報VIEW経由で取得可能 |
| `LINE_CTR_STT` | 回線契約状態 | `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE` | L_MR_000 | `LINE_CONTRACT_STATUS_CODE` | 🔶 同義カラムあり。「VW_ADM_DNCL_共通顧客属性」 |
| `LINE_CTR_STT` | 回線契約状態 | `VW_ADM_DNCL_DACCOUNT_MANAGEMENT` | L_MR_000 | `LINE_CONTRACT_STATUS` | 🔶 同義カラムあり。「VW_ADM_DNCL_dアカウント管理」 |
| `LINE_CTR_STT` | 回線契約状態 | `VSO_USER_INFO` | D_MA_000 | `LINE_CTR_STT_LINE_SIDE` | 🔶 SO・ユーザー情報VIEWに回線側の回線契約状態あり |
| `CTRR_AGE` / `RGRD_UTLR_AGE` | 青少年除外用の年齢 | ❌ PROCDB_B_P01_LAK内に直接の代替なし | - | - | ❌ `青少年ユーザフラグ`はUSPCDB_N_P01_LAK（別DB）にのみ存在 |
| `MAIL_NON_DELI_LTST_YM` | メール不達最新年月 | `VW_DMC_HNCL_CUSTOMER_ATTRIBUTE_INFORMATION` | L_MR_000 | `MAIL_NONDELIVERY_LATEST_NENGETSU` | 🔶 同義カラムあり。「VW_DMC_HNCL_顧客属性情報」 |
| `CTRR_ATR_CD` | 契約者属性コード | `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE` | L_MR_000 | `CONTRACTOR_ZOKUSEI_CODE` | 🔶 「VW_ADM_DNCL_共通顧客属性」に同義カラムあり |
| `DCM_LIGT_CTR_STT` | ドコモ光契約状態 | `VDICE_MEMBER_PROFILE_BASIC_INFORMATION` | D_MA_000 | `LINE_STATUS_CODE_CV` | 🔶 会員プロファイルのドコモ光契約状態あり |
| `DCM_ETRC_CTR` | ドコモでんき契約状態 | `VDICE_MEMBER_PROFILE_BASIC_INFORMATION` | D_MA_000 | `DOCOMO_DENKI_CONTRACT_STATUS_CODE` | 🔶 会員プロファイルにでんき契約状態あり（より詳細） |
| `AHM_CTR_STT` | ahamo契約状態 | `VSO_USER_INFO` | D_MA_000 | `GB_CTR_FLG` / `SC_CTR_FLG` | 🔶 SO・ユーザー情報にahamo契約フラグあり |

**結論**: VUSER_CUST_INFOのキーカラムは単一VIEWでは代替不可。複数VIEWのJOINが必要。  
最有力の代替候補GROUP:
- 青少年除外年齢 → PROCDB_B_P01_LAKには代替なし（機能縮小が必要）
- それ以外のカラムは`VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE`（L_MR_000）+ `VW_DMC_HNCL_CUSTOMER_ATTRIBUTE_INFORMATION`（L_MR_000）の組み合わせで対応可能性あり

---

### 6-2. VUSER_SO_CONTRACT_CURRENT（D_MA_000 / dMC廃止）

アプリ「滞在施設みえる化」で使用（ドコモ光・home5G・homeでんわ等の契約有無フィルタ）

| キーカラム | カラム論理名 | 代替候補VIEW | スキーマ | 代替カラム | 評価 |
|---|---|---|---|---|---|
| `DCM_LIGT_CTR` | ドコモ光契約 | `VSO_USER_INFO` | D_MA_000 | `DCM_LIGT_CTR` | 🔶 SO・ユーザー情報に同名カラムあり |
| `HOME5G_CTR` | ルータ(home5G)契約 | `VSO_USER_INFO` | D_MA_000 | `RT_CTR` (ルータ契約) | 🔶 SO・ユーザー情報にhome5G契約フラグあり |
| `HOME5G_CTR` | home5G契約 | `VW_ADW_DNCL_MB_CONTRACT_SERVICE` | L_MR_ADW | `HOME5G_CONTRACT_STATUS_FLAG` | 🔶 L_MR_ADWスキーマの「VW_ADW_DNCL_携帯-契約サービス」にあり |
| `AHM_CTR_STT` | ahamo契約状態 | `VSO_USER_INFO` | D_MA_000 | `GB_CTR_FLG` / `SC_CTR_FLG` | 🔶 SO・ユーザー情報にahamo契約フラグあり |
| `DCM_ETRC_CTR` | ドコモでんき契約 | `VSO_USER_INFO` | D_MA_000 | `DCM_ETRC_CTR` | 🔶 SO・ユーザー情報に同名カラムあり |
| `LINE_CTR_STT` | 回線契約状態 | `VSO_USER_INFO` | D_MA_000 | `LINE_CTR_STT_LINE_SIDE` | 🔶 SO・ユーザー情報に回線契約状態あり |

**結論**: VUSER_SO_CONTRACT_CURRENTのキーカラムは`VSO_USER_INFO`（D_MA_000）でほぼ代替可能。  
- `VSO_USER_INFO` は「SO・ユーザー情報」で同等の契約フラグを保持  
- ただし `VUSER_SO_CONTRACT_CURRENT` もD_MA_000のdMC廃止VIEW群の一つであり、`VSO_USER_INFO` も同様の廃止リスクがあるかどうかの確認が必要

---

### 6-3. VW_PGN_MECD_STARTDASH_BASIC_ATTRIBUTE_AREA_OTHER（D_MR_000 / 削除）

アプリ「Snowcampゼロ次分析」で使用（婚姻有無・子供有無のデモグラ分析）

| キーカラム | カラム論理名 | 代替候補VIEW | スキーマ | 代替カラム | 評価 |
|---|---|---|---|---|---|
| `MARRIAGE_STATUS_CODE` | 婚姻状態コード | `VW_PGN_MECL_USER_VISUALIZE` | L_MR_000 | `MARRIAGE_STATUS` | ✅ 「VW_PGN_MECL_ユーザー可視化」に婚姻状態コードあり |
| `CHILDREN_CODE` | 子供有無コード | `VDICE_MEMBER_PROFILE_BASIC_INFORMATION` | D_MA_000 | `PRESUMPTION_CHILDREN_*_CODE` | 🔶 推定値（年齢別）のみ。1つの集約コードは存在しない |
| `CHILDREN_ELEMENTARYSCHOOLSTUDENTS_CODE` | 小学生子供有無 | `VDICE_MEMBER_PROFILE_BASIC_INFORMATION` | D_MA_000 | `PRESUMPTION_CHILDREN_ELEMENTARYSCHOOLSTUDENTS_FLAG` | 🔶 推定値で存在 |
| `HOME5G_CONTRACT_STATUS_FLAG` | home5G契約状態フラグ | `VW_PGN_MECL_USER_VISUALIZE` | L_MR_000 | `RESERVE_10`（home5G契約状態） | 🔶 「VW_PGN_MECL_ユーザー可視化」に同義カラムあり |

**結論**: 
- 婚姻状態: `VW_PGN_MECL_USER_VISUALIZE`（L_MR_000）に代替カラムあり → **✅ 代替可能**
- 子供有無: 単一コードの代替なし。推定値（年齢別・`VDICE_MEMBER_PROFILE_BASIC_INFORMATION`）は存在するが、集計方法の変更が必要  

**Alationカタログ URL（参考）:**
- L_MR_000 VW_PGN_MECL_USER_VISUALIZE: `VW_PGN_MECL_ユーザー可視化`（婚姻状態・home5G含む）

---

### 6-4. VW_ADM_DNCL_HUMAN_BASIC（L_MR_000 / 断捨離ADM）

アプリ「契約状態抽出」で使用（爆アゲセレクション 個人/法人区分判定）

| キーカラム | カラム論理名 | 代替候補VIEW | スキーマ | 代替カラム | 評価 |
|---|---|---|---|---|---|
| `CONTRACTOR_ZOKUSEI_CODE` | 契約者属性コード（個人/法人） | `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE` | L_MR_000 | `CONTRACTOR_ZOKUSEI_CODE` | ✅ 「VW_ADM_DNCL_共通顧客属性」に同名・同義カラムあり |
| `CONTRACTOR_ZOKUSEI_CODE` | 契約者属性コード | `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` | D_MR_000 | `CONTRACTOR_ATTRIBUTE_CODE` | 🔶 「VW_DIC_MECD_顧客契約統合(携帯)」にも同義カラムあり |
| `COMPANY_ETC_CODE` | 会社等コード | ❌ 特定できず | - | - | ❌ 同義カラムなし（CONTRACTOR_ZOKUSEI_CODEで代用可能か要確認） |

**結論**: 法人/個人区分の核心である`CONTRACTOR_ZOKUSEI_CODE`は`VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE`（L_MR_000）で代替可能。  
→ **❌ → 🔶 に格上げ候補**。VIEW_HUMAN_BASICの廃止でも契約者属性コードは取得継続可能。

**Alationカタログ URL（参考）:**  
- L_MR_000 VW_ADM_DNCL_共通顧客属性: 契約者属性コード・回線契約状態・住所コードなど含む統合VIEW

---

### 6-5. VW_ADM_DNCD_BASE_NUMBER_ACCTID_CONVERSION_MASTER（D_MR_000 / 残留方針検討中）

アプリ「広告ID変換」で使用（基番↔アカウント識別子の変換）

| キーカラム | カラム論理名 | 代替候補VIEW | スキーマ | 代替カラム | 評価 |
|---|---|---|---|---|---|
| `BASCID` | 基本契約番号 | `VW_ADM_DNCL_BASE_NUMBER_ACCTID_MASTER` | L_MR_000 | `BASCID` / `KK_BASCID` | ✅ 「VW_ADM_DNCL_基番アカ識マスター」に同名カラムあり |
| `ACCTID` | アカウント識別子 | `VW_ADM_DNCL_BASE_NUMBER_ACCTID_MASTER` | L_MR_000 | `ACCTID` / `KK_ACCTID` | ✅ 同名カラムあり |
| `COMNID` | 共通IDグループ番号 | `VW_ADM_DNCL_BASE_NUMBER_ACCTID_MASTER` | L_MR_000 | `COMNID` / `KK_COMNID` | ✅ 同名カラムあり |
| `LINE_CONTRACT_STATUS` | 回線契約状態 | `VW_ADM_DNCL_BASE_NUMBER_ACCTID_MASTER` | L_MR_000 | `LINE_CONTRACT_STATUS` | ✅ 同名カラムあり |
| `ACCTID_VALID_FLAG` | アカウントID有効フラグ | `VW_ADM_DNCL_BASE_NUMBER_ACCTID_MASTER` | L_MR_000 | `ACCTID_VALID_FLAG` / `KK_ACCTID_VALID_FLAG` | ✅ 同名カラムあり |

**結論**: `VW_ADM_DNCL_BASE_NUMBER_ACCTID_MASTER`（L_MR_000、論理名「VW_ADM_DNCL_基番アカ識マスター」）が直接の後継候補。主要キーカラムがほぼ全て対応。  
→ **❌ → ✅ に格上げ**。スキーマがD_MR_000 → L_MR_000に変更されるが、カラム名は同一。

---

### 6-6. ❌のまま変わらないVIEW（住所系・スタッフ系）

| 廃止VIEW | キーカラム | 検索結果 | 結論 |
|---|---|---|---|
| `VW_ADW_DNCL_STAFF_DETAILS` | スタッフ数・スタッフ詳細 | 「スタッフ」検索でヒットなし（「先行指標(スタッフ)」はKPIデータ） | ❌ 代替なし |
| `VW_ADW_DNCD_ADDRESS_MASTER` | 住所コード変換 | 「住所コード」はVUSER_CUST_INFOなどに存在するが、ADW層の住所マスタ相当VIEWは特定できず | ❌ 要個別確認 |
| `VW_ADW_DNCD_ADDRESS_AGGREGATION_MASTER` | 住所集約（都道府県コード→都道府県名変換） | 「都道府県」カラムはVUSER_CUST_INFOにCTRR_ADRE_PREF_CDなどあり | 🔶 VUSER_CUST_INFOがあれば代替可能だが、VUSER_CUST_INFO自体も廃止対象 |

---

## 7. カラムレベル対応まとめ（アプリ別）

| App | アプリ名 | 廃止VIEW | キーカラム | 代替候補（カラムレベル） | 判定変更 |
|:---:|---|---|---|---|---|
| 26 | 配信対象者抽出 | `VUSER_CUST_INFO` | BLK_ACNT_FLG（ブラック除外） | `VW_DMC_HNCL_CUSTOMER_ATTRIBUTE_INFORMATION` → `BLACK_ACCOUNT_CERTIFICATION_FLAG` | ❌ → 🔶 |
| 26 | 配信対象者抽出 | `VUSER_CUST_INFO` | LINE_CTR_STT（回線契約） | `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE` → `LINE_CONTRACT_STATUS_CODE` | ❌ → 🔶 |
| 26 | 配信対象者抽出 | `VUSER_CUST_INFO` | CTRR_AGE/RGRD_UTLR_AGE（青少年） | PROCDB_B_P01_LAK内に代替なし | ❌ 機能縮小 |
| 26 | 配信対象者抽出 | `VUSER_CUST_INFO` | MAIL_NON_DELI_LTST_YM（メール不達） | `VW_DMC_HNCL_CUSTOMER_ATTRIBUTE_INFORMATION` → `MAIL_NONDELIVERY_LATEST_NENGETSU` | ❌ → 🔶 |
| 7 | 滞在施設みえる化 | `VUSER_CUST_INFO` | CTRR_ATR_CD（法人除外） | `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE` → `CONTRACTOR_ZOKUSEI_CODE` | ❌ → 🔶 |
| 7 | 滞在施設みえる化 | `VUSER_SO_CONTRACT_CURRENT` | DCM_LIGT_CTR（ドコモ光） | `VSO_USER_INFO` → `DCM_LIGT_CTR` | ❌ → 🔶 |
| 7 | 滞在施設みえる化 | `VUSER_SO_CONTRACT_CURRENT` | HOME5G_CTR（home5G） | `VSO_USER_INFO` → `RT_CTR` | ❌ → 🔶 |
| 7 | 滞在施設みえる化 | `VUSER_SO_CONTRACT_CURRENT` | DCM_ETRC_CTR（でんき） | `VSO_USER_INFO` → `DCM_ETRC_CTR` | ❌ → 🔶 |
| 9 | d払いNW見える化 | `VUSER_CUST_INFO` | SEX_CODE/NENDAI_CODE（性別・年代） | `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE` 等 | ❌ → 🔶 |
| 29 | Snowcampゼロ次分析 | `VW_PGN_MECD_STARTDASH...` | MARRIAGE_STATUS_CODE（婚姻） | `VW_PGN_MECL_USER_VISUALIZE` → `MARRIAGE_STATUS` | ❌ → ✅ |
| 29 | Snowcampゼロ次分析 | `VW_PGN_MECD_STARTDASH...` | CHILDREN_CODE（子供有無） | `VDICE_MEMBER_PROFILE_BASIC_INFORMATION` → `PRESUMPTION_CHILDREN_*_CODE`（推定値） | ❌ → 🔶 |
| 1 | 契約状態抽出 | `VW_ADM_DNCL_HUMAN_BASIC` | CONTRACTOR_ZOKUSEI_CODE（法人/個人） | `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE` → `CONTRACTOR_ZOKUSEI_CODE` | ❌ → ✅ |
| 12 | 広告ID変換 | `VW_ADM_DNCD_BASE_NUMBER_ACCTID_CONVERSION_MASTER` | BASCID/ACCTID/COMNID | `VW_ADM_DNCL_BASE_NUMBER_ACCTID_MASTER`（L_MR_000）→ 同名カラム | ❌ → ✅ |
| 8 | 事業OP九州アプリ | `VW_ADW_DNCL_STAFF_DETAILS` | スタッフ数 | 代替なし | ❌ 変わらず |
| 8,17,24 | 各アプリ | `VW_ADW_DNCD_ADDRESS_MASTER/AGGREGATION_MASTER` | 住所コード変換 | 直接の代替VIEWなし | ❌ 変わらず（要個別確認） |

---

## 5. 凡例・次のアクション

| マーク | 意味 |
|---|---|
| ✅ | 代替VIEW確定（L_MR_000に同名または明確な後継） |
| 🔶 | 候補あり・カラム差分確認が必要 |
| ❌ | 代替なし（機能縮小または別途対応が必要） |
| 要調査 | 今回の検索でヒットせず・追加調査が必要 |

### 優先アクション

1. **✅ 案件（L_MR_000移行）**: `get_table_columns.py` でD_MR_000とL_MR_000のカラム差分を確認し、問題なければスキーマ変更のみで対応
2. **🔶 案件（VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER）**: 6アプリで共通利用。`VW_ADW_DNCD_SALESOUTLET_MASTER`とのカラム差分確認を最優先で実施
3. **❌ 案件（dMC廃止系）**: `VUSER_CUST_INFO`・`VUSER_SO_CONTRACT_CURRENT` は機能縮小での対応を確定させる
4. **要調査案件**: `VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER`・`VW_ADW_DNCD_ADDRESS_MASTER` 等を追加検索
