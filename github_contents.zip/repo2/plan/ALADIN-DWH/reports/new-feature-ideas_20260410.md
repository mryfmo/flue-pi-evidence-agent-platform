# ❌アプリ 新機能拡張アイデア 変更仕様書

**作成日**: 2026-04-10  
**作成者**: Claude Code (snowflake-explorer / ux-review)  
**背景**: `alternative-view-research_20260410.md` で「代替なし（❌）」と判定されたVIEWを使用するアプリについて、既存VIEW（L_MR_000系）を活用した新機能拡張案を整理する。

---

## エグゼクティブサマリー

| 判定 | App | アプリ名 | 方針 |
|:---:|:---:|---|---|
| 🔄 | 1 | 契約状態抽出 | **廃止VIEWへの直接依存なし**→VIEW切り替えのみで対応（リスク低） |
| 🔄 | 26 | 配信対象者抽出 | 青少年フィルタのみ削除 ＋ メール不達/法人フィルタ追加 |
| ✨ | 29 | Snowcampゼロ次分析 | 婚姻状態はL_MR_000で代替、子供有無は年齢別区分に転換 |
| ✨ | 7 | 滞在施設みえる化 | dMCフィルタ廃止 → 回線種×イエナカサービス分析に機能転換 |
| ⚠️ | 8 | 事業OP九州アプリ | スタッフ数タブ削除、住所集計は都道府県単位に粒度を下げる |

---

## Snowflakeカタログ調査結果（代替VIEWカラム確認）

### VW_PGN_MECL_USER_VISUALIZE（L_MR_000）— ユーザー可視化VIEW

廃止VIEWの代替として利用可能な主要カラム:

| 廃止VIEW | 廃止カラム | 代替カラム | 型 | コード値例 |
|---|---|---|---|---|
| VW_PGN_MECD_STARTDASH... | MARRIAGE_STATUS_CODE | **MARRIAGE_STATUS** | VARCHAR(1) | 0:その他/1:未婚/2:既婚/z:NULL |
| VW_PGN_MECD_STARTDASH... | CHILDREN_CODE（単一コード） | **CHILDREN_ATTRIBUTE_PRESCHOOL** | VARCHAR(1) | 0:無効/1:有効/z:NULL |
| VW_PGN_MECD_STARTDASH... | - | **CHILDREN_ATTRIBUTE_PRIMARY_SCHOOL** | VARCHAR(1) | 0:無効/1:有効/z:NULL |
| VW_PGN_MECD_STARTDASH... | - | **CHILDREN_ATTRIBUTE_JUNIOR_HIGH_SCHOOL** | VARCHAR(1) | 0:無効/1:有効/z:NULL |
| VW_PGN_MECD_STARTDASH... | - | **CHILDREN_ATTRIBUTE_HIGH_SCHOOL** | VARCHAR(1) | 0:無効/1:有効/z:NULL |
| VW_PGN_MECD_STARTDASH... | - | **CHILDREN_ATTRIBUTE_UNIVERSITY** | VARCHAR(1) | 0:無効/1:有効/z:NULL |
| VUSER_CUST_INFO | SEX_CODE/NENDAI_CODE | **GENDER** | VARCHAR(1) | 1:男性/2:女性 |
| VUSER_CUST_INFO | SEX_CODE/NENDAI_CODE | **ANAGE** | VARCHAR(2) | 00:0-9歳/01:10-19歳... |
| VUSER_CUST_INFO | - | **LINE_ISP_TYPE** | VARCHAR(2) | 4:ahamo/5:irumo/6:eximo |

> **重要**: `VW_PGN_MECL_USER_VISUALIZE`は性別・年代・婚姻状態・子供属性（年齢別5区分）・回線ISP種別・各種サービス契約状態・許諾フラグを包括的に提供。廃止されるdMC系VIEWの多くのカラムを1つのVIEWで代替できる。

---

### VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE（L_MR_000）— 共通顧客属性VIEW

| 廃止VIEW | 廃止カラム | 代替カラム | 型 | コード値例 |
|---|---|---|---|---|
| VUSER_CUST_INFO | LINE_CTR_STT（回線契約状態） | **LINE_CONTRACT_STATUS_CODE** | VARCHAR(1) | 0:未契約/1:契約中 |
| VUSER_CUST_INFO | CTRR_ATR_CD（契約者属性） | **CONTRACTOR_ZOKUSEI_CODE** | VARCHAR(1) | 1:男性/2:女性/3:法人 |
| VW_ADM_DNCL_HUMAN_BASIC | CONTRACTOR_ZOKUSEI_CODE | **CONTRACTOR_ZOKUSEI_CODE** | VARCHAR(1) | 同上（完全一致） |
| VUSER_CUST_INFO | 年代 | **DK_NENDAI_CODE** | VARCHAR(15) | 00:10代未満/01:10代... |
| - | - | **DK_AREA_CODE** | VARCHAR(1) | 1:北海道〜9:九州沖縄 |

---

### VW_DMC_HNCL_CUSTOMER_ATTRIBUTE_INFORMATION（L_MR_000）— 顧客属性情報VIEW

| 廃止VIEW | 廃止カラム | 代替カラム | 型 | コード値例 |
|---|---|---|---|---|
| VUSER_CUST_INFO | BLK_ACNT_FLG | **BLACK_ACCOUNT_CERTIFICATION_FLAG** | NUMBER(38,0) | 0:認定なし/1:認定あり |
| VUSER_CUST_INFO | AHM_CTR_STT | **AHAMO_CNTRCT_STATUS** | VARCHAR(1) | 0:契約なし/1:契約あり |
| VUSER_CUST_INFO | MAIL_NON_DELI_LTST_YM | **MAIL_NONDELIVERY_LATEST_NENGETSU** | （要確認） | - |

---

## アプリ別 変更仕様書

---

### App 1: 契約状態抽出
**優先度**: 高（最小変更でリスク解消）

#### 現状分析
- リバースモデリングで確認した結果、`VW_ADM_DNCL_HUMAN_BASIC`への直接依存はコード上では検出されず
- 現行データソースは`PROCDB_B_P01_LAK.D_MR_000`配下の3VIEWに限定
- ただし今後、属性フィルタ機能を追加する際はL_MR_000系への移行が必要

#### 失われる機能
- 法人/個人区分フィルタ（VW_ADM_DNCL_HUMAN_BASIC → CONTRACTOR_ZOKUSEI_CODE）
- ただし**代替候補確定済み**: `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE.CONTRACTOR_ZOKUSEI_CODE`

#### 新機能案（追加案）
**「契約者区分フィルタ」の追加**
- データソース: `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE`（L_MR_000）
- 新カラム: `CONTRACTOR_ZOKUSEI_CODE`（1:男性/2:女性/3:法人/9:その他）
- UI: 既存のフィルタ条件にチェックボックスとして追加
- 用途: 法人回線を除外した個人向け施策の精度向上

#### UX改善提案（ux-review評価より）
1. **入力モード統一**: Code入力と検索入力の分岐UIを、検索→Code変換のシングルフローに統一
2. **進捗可視化**: `st.progress_bar`でSQL実行の進捗を表示
3. **AND/OR条件UIの独立化**: 結果確認ページに混在するAND/OR条件をメインページのサイドバーに移動

#### 実装タスク
1. `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE`のクエリを`function/`配下に追加
2. メインページに「法人/個人区分」フィルタを追加
3. 入力モードのUX統一（検索→Codeの1フロー化）

---

### App 26: 配信対象者抽出
**優先度**: 高（最小リスクで機能維持＋新フィルタ追加）

#### 現状分析（UX評価より）
- **7タブ構成**で20以上のexpanderと多数のウィジェット。スクロール必須で条件全体の把握困難
- 青少年除外フィルタ（CTRR_AGE/RGRD_UTLR_AGE）が`query_helper.py:651`に実装
- タブリセット問題: ウィジェット変化時にタブ選択が初期化される既知バグ

#### 失われる機能
- **青少年フィルタ（CTRR_AGE/RGRD_UTLR_AGE）のみ削除**
  - UIから「青少年除外」チェックボックスを削除
  - `query_helper.py:651`の年齢フィルタ条件を削除

#### 新機能案（追加案）

**① メール不達除外フィルタ追加**
- データソース: `VW_DMC_HNCL_CUSTOMER_ATTRIBUTE_INFORMATION`（L_MR_000）
- カラム: `MAIL_NONDELIVERY_LATEST_NENGETSU`
- UI追加場所: タブ「2. 登録・許諾」→「メール不達除外（直近N年以内に不達のあるユーザーを除外）」
- 効果: メール不達者を事前に除外し、配信効率と到達率を向上

**② 契約者区分（個人/法人）フィルタ追加**
- データソース: `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE`（L_MR_000）
- カラム: `CONTRACTOR_ZOKUSEI_CODE`（1:男性/2:女性/3:法人）
- UI追加場所: タブ「1. ユーザー情報」→「契約者区分」セクション
- 効果: 法人契約者を除外することで、個人向け施策の精度向上

**③ ブラックアカウント除外フラグの明示化**
- データソース: `VW_DMC_HNCL_CUSTOMER_ATTRIBUTE_INFORMATION`（L_MR_000）
- カラム: `BLACK_ACCOUNT_CERTIFICATION_FLAG`
- 現状: 除外されているか不明（コード確認要）
- 追加案: 「ブラックアカウント除外（推奨）」チェックボックスをUIに追加

#### UX改善提案（ux-review評価より）
1. **タブリセット問題の根本解決**: `st.form`の導入でタブ変更時の不要なrerun防止
2. **排反チェックの事前制御**: ISPの「対象/除外」で矛盾選択をUIレベルで防止（選択済み項目をグレーアウト）
3. **条件サマリーの常時表示**: 設定中の条件をサイドバーに常時表示し、全体像を把握しやすくする

#### 実装タスク
1. `query_helper.py:651`の青少年フィルタ条件を削除
2. `query_helper.py`にメール不達フィルタ・法人除外フィルタ条件を追加
3. UIの「登録・許諾」タブに「メール不達除外」を追加
4. UIの「ユーザー情報」タブに「契約者区分」を追加
5. ブラックアカウント除外のUI明示化

---

### App 29: Snowcampゼロ次分析
**優先度**: 高（婚姻状態は即座に代替確定、子供属性は新規機能に転換）

#### 現状分析（UX評価より）
- 入力UIは分析名・日付・検索方法（3択）のシンプルな構成
- 廃止VIEW（`VW_PGN_MECD_STARTDASH_BASIC_ATTRIBUTE_AREA_OTHER`）への依存は`summary_sql`内で婚姻状態（MARRIAGE_STATUS_CODE）・子供有無（CHILDREN_CODE）の集計に使用
- LEFT OUTER JOINで主テーブルと結合しているため、廃止時はNULLが返りサイレントエラーになるリスク

#### 失われる機能と代替案

**婚姻状態の分析**
- 廃止: `MARRIAGE_STATUS_CODE` from `VW_PGN_MECD_STARTDASH_BASIC_ATTRIBUTE_AREA_OTHER`
- **代替確定**: `VW_PGN_MECL_USER_VISUALIZE.MARRIAGE_STATUS`（L_MR_000）
- コード値マッピング: 旧→新で 0/1 対応確認が必要

**子供有無の分析**（転換）
- 廃止: `CHILDREN_CODE`（単一コード。0:なし/1:あり等）
- **新機能**: 年齢別子供属性フラグ（5区分）に分割
  - `CHILDREN_ATTRIBUTE_PRESCHOOL`（就学前）
  - `CHILDREN_ATTRIBUTE_PRIMARY_SCHOOL`（小学生）
  - `CHILDREN_ATTRIBUTE_JUNIOR_HIGH_SCHOOL`（中学生）
  - `CHILDREN_ATTRIBUTE_HIGH_SCHOOL`（高校生）
  - `CHILDREN_ATTRIBUTE_UNIVERSITY`（大学生）
- 分析価値: 子供の年齢層別の購買傾向がより詳細に分析可能

#### 新機能案（追加案）

**① 婚姻状態フィルタの継続（VIEW切り替え）**
- `functions/sql.py`のsummary_sqlで参照VIEWを`VW_PGN_MECL_USER_VISUALIZE`に変更
- カラム名を`MARRIAGE_STATUS_CODE` → `MARRIAGE_STATUS`に変更

**② 年齢別子供属性分析の追加**
- 単一コード「子供有無」を廃止し、年齢別フラグ5列に拡張
- UIのデモグラタブを「ライフステージ絞り込み」に改名
- 棒グラフ表示を「子供有無：あり/なし」から「子供年齢層：就学前/小/中/高/大」の分布表示に変更

**③ 新軸: サービス利用傾向フィルタ（新機能）**
- データソース: `VW_ADM_MECL_SERVICE_USE_PROFILE`（L_MR_000、過去37ヶ月分）
- 購買対象者がどのドコモサービスを利用しているかの横断分析を追加
- 用途: ゼロ次分析の対象者のサービス利用プロファイルを活用した施策立案

#### UX改善提案（ux-review評価より）
1. **廃止VIEWの明示的エラーハンドリング**: NULLデータ返却時の具体的なエラーメッセージを追加
2. **デバッグ出力の削除**: `display_fig()`内のst.write()デバッグ出力を削除
3. **プレビュー機能**: データ量の事前見積もり（件数確認）機能を追加し、タイムアウト防止

#### 実装タスク
1. `functions/sql.py`のsummary_sqlで婚姻状態クエリを`VW_PGN_MECL_USER_VISUALIZE`に変更
2. 子供属性カラムを年齢別5区分に変更
3. UIのデモグラタブを「ライフステージ絞り込み」に改名
4. `VW_ADM_MECL_SERVICE_USE_PROFILE`を活用した新軸分析の追加
5. デバッグ出力の削除・エラーハンドリング強化

---

### App 7: 滞在施設みえる化
**優先度**: 中（機能転換の規模が大きい、段階的実施を推奨）

#### 現状分析（UX評価より）
- 現在のデータソースは**Redshift `sdash.USER_VISUALIZATION`**（DICE環境のSnowflakeとは別）
- `VUSER_CUST_INFO`・`VUSER_SO_CONTRACT_CURRENT`への直接依存はコード上で検出されず
- Redshift VIEWの`USER_VISUALIZATION`が廃止されるまでは動作維持可能
- 11カテゴリのタブが存在するが、現行はdMC系VIEW経由の顧客属性データが中心

#### 失われる機能
- dMCフィルタ（性別・年代での絞り込み）
- 光/home5G/ahamo契約有無フィルタ
- ブラックアカウント除外

#### 新機能案 — 「ドコモサービスポートフォリオ分析」への機能転換

**① 回線種別分析の追加**
- データソース: `VW_PGN_MECL_USER_VISUALIZE.LINE_ISP_TYPE`（L_MR_000）
- コード値: 4:ahamo / 5:irumo / 6:eximo / 7,8:ahamo大盛り
- 新軸: ターゲットグループの「料金プラン構成」を全体平均と比較
- 用途: ahamo/irumo移行ユーザーの施設滞在傾向分析

**② イエナカサービス契約状況分析の追加**
- データソース: `VW_PGN_MECL_USER_VISUALIZE`（L_MR_000）
  - `VW_ADW_DNCL_MB_CONTRACT_SERVICE`（L_MR_ADW）: home5G契約状態
- 新タブ: 「イエナカ分析」（ドコモ光/home5G/でんき/homeでんわの保有率比較）
- 用途: 光+home5G同時保有者の滞在施設傾向分析、でんき契約者向けの施策立案

**③ dポイントステージ別分析**
- データソース: `VW_PGN_MECL_USER_VISUALIZE.DPOINT_APPLY_STAGE`（L_MR_000）
- コード値: 7:1つ星〜B:5つ星
- 新軸: ターゲットの「dポイントエンゲージメント」を可視化

#### UX改善提案（ux-review評価より）
1. **フェーズ分離**: 「ユーザー指定」→「分析実行」→「結果確認」の3フェーズを明確に分離（ステップインジケータ導入）
2. **タブUI最適化**: 11タブの長い日本語ラベルをアイコン化または短縮
3. **プログレスバー改善**: SQL単位での進捗表示（現在は並列Visualizer単位のみ）

#### 実装タスク（段階的推奨）
**Phase 1（短期）**: 回線種別タブを`VW_PGN_MECL_USER_VISUALIZE`で追加
**Phase 2（中期）**: イエナカサービス分析タブを新設
**Phase 3（長期）**: dMC廃止後の全体VIEWリファクタリング

---

### App 8: 事業OP九州アプリ
**優先度**: 低（代替不可機能あり、影響範囲確認が先決）

#### 現状分析（UX評価より）
- `VW_ADW_DNCD_ADDRESS_AGGREGATION_MASTER`への依存がMNP・契約者数の2つのSQLに埋込み
- `VW_ADW_DNCL_STAFF_DETAILS`への依存は店舗指標タブの適正店舗数計算に使用
- 両VIEWが廃止されると主要機能（MNP集計・スタッフ分析）が動作不能になる

#### 失われる機能
- スタッフ数分析（`VW_ADW_DNCL_STAFF_DETAILS` → 代替なし）
- 精細エリアマッピング（市区町村コード変換、`VW_ADW_DNCD_ADDRESS_MASTER` → 代替不確定）

#### 対応方針

**① スタッフ数タブの廃止**
- 「店舗指標」タブから「スタッフ数（スタッフ適正率）」の表示を削除
- 代替として「販売店グループ別集計」を追加（以下参照）

**② MNP・契約者数の住所集計は都道府県単位に粒度を下げる**
- 廃止: 市区町村コード変換（ADDRESS_AGGREGATION_MASTER経由）
- 変更後: 都道府県コードでの集計に変更
  - `VW_ADW_DNCL_SALESOUTLET_MASTER`（L_MR_000）の地域コードを活用
- 影響: 市区町村単位のヒートマップ機能が都道府県単位に粗くなる

**③ 新機能: 販売店グループ別パフォーマンス比較**
- データソース: `VW_ADW_DNCL_SALESOUTLET_AGGREGATION_MASTER`（L_MR_000）
- 機能: 代理店グループ単位でのMNP純増・来客数のランキング表示
- UI: 新タブ「代理店グループ分析」を追加（既存の商圏分析タブを補完）

**④ 新機能: 祝日前後の来客変動カレンダー**
- データソース: `VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER`（L_MR_000）✅移行可
- 機能: 祝日前後の来客数変動を月次カレンダービューで可視化
- UIライブラリ: `streamlit_calendar`または`plotly`カレンダービュー

#### UX改善提案（ux-review評価より）
1. **廃止VIEWへの依存を視覚的に明示**: 開発者向けのデータ依存ダッシュボードを追加
2. **フラグメント制御の整理**: @fragment使用箇所を最小化し、状態管理を単純化
3. **比較機能UI**: 都道府県平均・商圏平均の切り替えを、タブではなくトグルボタンで1ステップ化

#### 実装タスク（優先度順）
1. `VW_ADW_DNCL_STAFF_DETAILS`依存箇所（get_staff_num_data）を削除・タブ廃止
2. MNPクエリの住所結合を都道府県単位に変更（ADDRESS_MASTERのJOINを削除）
3. `VW_ADW_DNCL_SALESOUTLET_AGGREGATION_MASTER`を使った代理店グループ分析タブを追加
4. 祝日カレンダービューを新設

---

## 実装ロードマップ

### Phase 1: Quick Wins（1〜2週間）— リスク最小・即効性高

| タスク | App | 工数目安 |
|---|:---:|---|
| App 1: VW切り替え確認・VIEW参照の明示化 | 1 | 0.5日 |
| App 26: 青少年フィルタ削除（query_helper.py:651） | 26 | 0.5日 |
| App 26: メール不達除外フィルタ追加 | 26 | 1日 |
| App 29: 婚姻状態VIEWをVW_PGN_MECL_USER_VISUALIZEに切り替え | 29 | 1日 |
| App 8: スタッフ数タブの削除 | 8 | 0.5日 |

**期待効果**: 廃止VIEW依存の主要リスクを解消、機能縮小を最小化

---

### Phase 2: 新機能追加（3〜4週間）— 機能転換による価値創出

| タスク | App | 工数目安 |
|---|:---:|---|
| App 26: 契約者区分フィルタ追加 | 26 | 1日 |
| App 26: ブラックアカウント除外UI明示化 | 26 | 0.5日 |
| App 29: 子供属性を年齢別5区分に分割 | 29 | 2日 |
| App 29: サービス利用プロファイル分析軸追加 | 29 | 2日 |
| App 7: 回線種別分析タブ追加（Phase 1） | 7 | 2日 |
| App 8: 代理店グループ分析タブ追加 | 8 | 2日 |

**期待効果**: 廃止VIEWがなくなった後も、新しい分析軸で価値提供を継続

---

### Phase 3: 長期的なアーキテクチャ刷新（1ヶ月以上）

| タスク | App | 内容 |
|---|:---:|---|
| App 7: イエナカサービス分析タブ追加 | 7 | L_MR_000系VIEWを軸にした新機能 |
| App 7: dMC廃止後の全体VIEWリファクタリング | 7 | Redshift依存からSnowflake完全移行 |
| App 8: 住所コード変換の代替確認・実装 | 8 | 要個別調査（ADDRESS_MASTERの後継次第） |
| 全アプリ: UX改善（フォーム統一・プログレス表示） | 全 | ux-review評価に基づく操作効率向上 |

---

## 代替VIEW 利用サマリー（アプリ横断）

| 代替VIEW | スキーマ | 利用アプリ | 提供機能 |
|---|---|:---:|---|
| `VW_PGN_MECL_USER_VISUALIZE` | L_MR_000 | 26, 29, 7 | 婚姻状態・子供属性・性別・年代・回線ISP種別・サービス契約状態 |
| `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE` | L_MR_000 | 26, 1 | 回線契約状態・契約者属性コード（個人/法人） |
| `VW_DMC_HNCL_CUSTOMER_ATTRIBUTE_INFORMATION` | L_MR_000 | 26 | ブラックアカウントフラグ・ahamo契約状態・請求金額 |
| `VW_ADW_DNCL_SALESOUTLET_AGGREGATION_MASTER` | L_MR_000 | 8 | 代理店グループ別集計 |
| `VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER` | L_MR_000 | 8 | 祝日カレンダー分析 |
| `VW_ADM_MECL_SERVICE_USE_PROFILE` | L_MR_000 | 29 | サービス利用プロファイル（37ヶ月分） |

---

## 次のアクション

1. **即座**: App 26の青少年フィルタ削除（`query_helper.py:651`）をPRとして提出
2. **今週中**: App 29の婚姻状態VIEW切り替えの実装計画書作成
3. **来週以降**: `VW_ADM_DNCL_COMMON_CUSTOMER_ATTRIBUTE`のカラム詳細をApp 26実装チームと共有
4. **別途確認**: `VW_ADW_DNCD_ADDRESS_MASTER`後継VIEW（App 8・17・24）の調査継続

---

*本ドキュメントは snowflake-explorer（Alationカタログ調査）および ux-review（コードリバースモデリング）スキルの実行結果に基づいて生成されました。*
