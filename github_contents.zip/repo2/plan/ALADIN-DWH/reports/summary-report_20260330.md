# DB変更対応 サマリーレポート

**作成日**: 2026-03-30
**元レポート**: decision-report_20260306.md（D_MR_000.csv 最新版反映: 2026-03-27）（dMC/D_MR_000.csv・dMC/L_MR_000.csv 更新反映: 2026-03-30）
**判断基準**: Snowflakeクエリヒストリー（直近30日/1年）× 対応方針 × 削除期限

---

## 1. 全体概要

| 項目 | 件数 |
|:---|---:|
| 全アプリ数 | 46 |
| 対応不要 | 17 |
| **対応あり** | **29** |

---

## 2. 対応不要アプリ一覧（17件）

以下のアプリは廃止VIEWへの本番参照なし、またはアプリ自体が終了するため対応不要です。

| No | アプリ名 | リポジトリ | 理由 |
|:---:|:--------|:------|:------|
| 1 | SQLリファクタリングGPT | pochi-llm-code-refactor-repository | テストデータのみ参照（本番影響なし） |
| 2 | アイデア投票箱 | pochi-app-request-hub-repository | 廃止VIEW参照なし（例示VIEWのみ） |
| 3 | デザインガイドライン | pochi-design-guideline-repository | 廃止VIEW参照なし（例示VIEWのみ） |
| 4 | データ加工ツールボックス | pochi-data-processing-toolbox-repository | 廃止VIEW参照なし |
| 5 | セルアセ支援アプリ | pochi-cs-docomoselfassessment-repository | 廃止VIEW参照なし |
| 6 | かんたん回線施策ユーザー抽出アプリ | pochi-customer-list-quick-extract-repository | 廃止VIEW参照なし |
| 7 | 事業OP関西アプリ | pochi-ds-sales-event-planner-repository | 廃止VIEW参照なし |
| 8 | ギャラリー | pochi-gallery-repository | 廃止VIEW参照なし |
| 9 | データ抽出GPT | pochi-llm-sql-generator-repository | 廃止VIEW参照なし |
| 10 | N1分析 | pochi-n1-timeline-tool-repository | 廃止VIEW参照なし |
| 11 | 開封率予測 | pochi-open-predictor-repository | 廃止VIEW参照なし |
| 12 | メッセージクリエイティブアプリ | pochi-personalized-email-generator-repository | 廃止VIEW参照なし |
| 13 | ResearchBuddy | pochi-research-body-repository | 廃止VIEW参照なし |
| 14 | 滞在エリア受付 | pochi-stay-area-registrator-repository | 廃止VIEW参照なし |
| 15 | TTSアプリ | pochi-text-to-speech-repository | 廃止VIEW参照なし |
| 16 | ワードチェックツール | pochi-word-check-and-correct-repository | 廃止VIEW参照なし |
| 17 | 各種イベント予兆者抽出 | pochi-tetsuduki-yocho-list-repository | 2026年3月末アプリ廃止のため対応不要 |

---

## 3. 対応アプリ一覧（30件）

対象アプリの廃止対象VIEWの全一覧です。判断（🔴緊急/🟠要対応/🔵機能縮小候補/🟢コード削除のみ）ごとに対応方針を確認してください。

| App | アプリ名 | リポジトリ | 判断 | VIEW名 | 実行回数 | アクセス率 | 対応方針 | 削除期限 | 移行先VIEW | 備考 | アプリ対応方針 |
|:---:|:--------|:------|:---:|:------|-------:|-----:|:------:|:------:|:------|:------|:------|
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🟠 | `VW_ADM_DNCD_BASIC_CONTRACT_MB` | 98 (1年:467) | 12.1% (1年:4.3%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_携帯-契約基本 | 高利用（1年467回）。アプリ主要機能の契約データ取得に使用されており、代替VIEWへの移行が必要 | 廃止でアプリ主要機能契約データ取得ができなくなる |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🟢 | `VW_DIC_DNCD_DCARD_INTEGRATION_DCARD_MEMBER` | 83 (1年:1,176) | 10.3% (1年:10.8%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | 高利用（1年1,176回）。アプリ主要機能に関わる重要VIEWのため代替が必要 | ★継続提供のため対応不要（2026-03-27確認） |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_ADM_DNCL_COMNID_INTEGRATION` | 21 (1年:507) | 2.6% (1年:4.7%) | 断捨離(ADM) | ー（別管理） | ー（別管理） | 電話案内許諾・配信許諾・CF系の全許諾フィルタで共通使用するID変換基盤。廃止で許諾フィルタ全種が停止するため代替が必要 | 廃止で許諾フィルタ全種が停止 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_ADW_MECD_BASIC_CONTRACT_CV` | 16 (1年:173) | 2.0% (1年:1.6%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_MECD_光-契約基本-月末 | ドコモ光ユーザー抽出専用VIEW。廃止でドコモ光抽出が完全停止 | ドコモ光の検索ができなくなる機能縮小とするか要検討 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_ADW_MECD_BASIC_CONTRACT_MB` | 32 (1年:539) | 4.0% (1年:5.0%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_MECD_携帯-契約基本-月末 | ahamo・ギガホ系サービス選択時の月次契約データ取得。廃止でahamo系・ポートアウト抽出が停止するため代替が必要 | 廃止でahamo系・ポートアウト抽出が停止 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_ADW_MECD_SERVICE_BASIC_CF` | 5 (1年:110) | 0.6% (1年:1.0%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_MECD_CF-契約サービス-月末 | CF（キャリアフリー）系サービス選択時のユーザー抽出。廃止でCF系全サービスが完全停止 | 廃止でCF系全サービスが完全停止 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_ADW_MECL_BASIC_CONTRACT` | 58 (1年:1,511) | 7.2% (1年:14.0%) | リファクタ(ALADIN) | ー（別管理） | ー（別管理） | 全抽出処理の共通基盤（JOIN軸）で全操作に必須。廃止でアプリ全機能が停止する最重要VIEWのため代替が必要 | 廃止でアプリ全機能が停止 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_DIC_DNCD_MEMBER_PROFILE_BASIC_INFORMATION` | 1 (1年:17) | 0.1% (1年:0.2%) | 残留(リファクタ有り) | 2027年3月 | D_MR_000_CK（新設）/VW_DIC_DNCD_会員プロファイル | いちおしパック選択時の契約状態日次データ取得。廃止でいちおしパック抽出が完全停止 | 廃止でいちおしパック抽出が完全停止 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_DIC_DNHL_CUSTOMER_CHANGE_MB` | 13 (1年:183) | 1.6% (1年:1.7%) | 断捨離(DWH層代替) | ー（別管理） | ー（別管理） | eximo・ギガホ系の契約変更履歴取得。廃止でeximo・ギガホ系抽出が停止するため代替が必要 | 廃止でeximo・ギガホ系抽出が停止 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` | 13 (1年:394) | 1.6% (1年:3.7%) | 残留(リファクタ有り) | ー | ー | ahamo大盛・3Gマイグレーション・回線新規の判定。廃止でahamo大盛・3G移行抽出が停止 | 廃止でahamo大盛・3G移行抽出が停止 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | 1 (1年:77) | 0.1% (1年:0.7%) | 残留(リファクタ有り) | 2027年3月 | D_MR_000_CK（新設）/VW_DIC_MECD_会員プロファイル | 電話案内・第三者提供許諾フラグの月次取得。廃止で電話案内・第三者許諾フィルタが完全停止 | 廃止で電話案内・第三者許諾フィルタが完全停止 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🟢 | `VW_DIC_MECD_MEMBER_PROFILE_DELIVERY_PERMISSION` | 1 (1年:45) | 0.1% (1年:0.4%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | プッシュ通知・メール配信許諾フラグの取得。廃止で配信許諾フィルタが完全停止 | ★継続提供のため対応不要（2026-03-27確認） |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_PGN_DNHD_DANIMESTORE_MEMBER_CONTRACT` | 6 (1年:35) | 0.7% (1年:0.3%) | 残留(リファクタ有り) | 2027年3月 | L_MR_000/VW_PGN_DNHL_アニメストア入退会履歴 | dアニメストア選択時の会員契約履歴取得。廃止でdアニメストア抽出が完全停止 | サービス一覧のdアニメストアの検索ができなくなるため要検討 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_ADM_DNCL_HUMAN_BASIC` | 0 (1年:46) | - (1年:0.4%) | 断捨離(ADM) | ー（別管理） | ー（別管理） | 爆アゲセレクション選択時の個人/法人区分判定。廃止で爆アゲセレクション全件がエラー | 施策一覧の爆アゲセレクションの検索ができなくなるため要検討 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_ADW_DNCD_SERVICE_BASIC_2_MB` | 0 (1年:27) | - (1年:0.3%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_携帯-契約サービス | 爆アゲセレクションのDAZN選択時ユーザー抽出。廃止でDAZN選択時のみ停止 | 施策一覧の爆アゲセレクションのDAZNの検索ができなくなるため要検討 |
| 1 | 契約状態抽出 | pochi-extract-user-by-contract-repository | 🔵 | `VW_ADW_DNCD_SERVICE_BASIC_3_MB` | 0 (1年:58) | - (1年:0.5%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_携帯-契約サービス | 爆アゲセレクションのDAZN以外選択時ユーザー抽出。廃止でDAZN以外の爆アゲが停止 | 施策一覧の爆アゲセレクションのDAZNの検索ができなくなるため要検討 |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🟠 | `VW_ADW_DNCL_SALESOUTLET_DETAILS_MASTER` | 162 (1年:1,923) | 11.2% (1年:11.5%) | 個別マスタ別途 | ー（別管理） | ー（別管理） | 高利用（1年1,923回）。販売店詳細マスタとして重要機能に使用されており、代替が必要 | 代替VIEWへの移行対応 |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🟠 | `VW_ADW_DNCL_SALESOUTLET_MASTER` | 162 (1年:1,926) | 11.2% (1年:11.5%) | 個別マスタ別途 | ー（別管理） | ー（別管理） | 高利用（1年1,926回）。販売店マスタとして重要機能に使用されており、代替が必要 | 代替VIEWへの移行対応 |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🟠 | `VW_ADW_MECD_BASIC_CONTRACT_MB` | 162 (1年:2,036) | 11.2% (1年:12.1%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_MECD_携帯-契約基本-月末 | 高利用（1年2,036回）。アプリ主要機能の契約データ取得に使用する重要VIEWのため代替が必要 | 廃止でアプリ主要機能契約データ取得ができなくなる |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🟠 | `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` | 243 (1年:2,918) | 16.8% (1年:17.4%) | 残留(リファクタ有り) | ー | ー | 高利用（1年2,918回）。アプリ主要機能に関わる重要VIEWのため代替が必要 | 代替VIEWへの移行対応 |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🟠 | `VW_ADW_DNCL_PRODUCT_ATTRIBUTE_MASTER` | 148 (1年:1,652) | 10.2% (1年:9.9%) | 個別マスタ別途 | ー（別管理） | ー（別管理） | 高利用（1年1,652回）。商品属性マスタとして重要機能に使用されており、代替が必要 | 代替VIEWへの移行対応 |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🟠 | `VW_DIC_DNHD_CUSTOMER_CHANGE_MB` | 162 (1年:1,761) | 11.2% (1年:10.5%) | 残留(リファクタ有り) | ー | ー | 高利用（1年1,761回）。アプリ主要機能に関わる重要VIEWのため代替が必要 | 代替VIEWへの移行対応 |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🔵 | `VW_ADM_MECD_GROUP_BASIC` | 81 (1年:1,161) | 5.6% (1年:6.9%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_MECD_共通-グループサービス-月末 | ドコモ光商材のファミ割グループ連動成約判定。廃止でドコモ光の家族回線経由成約追跡が不可 | VIEW削除対応でドコモ光商材の機能縮小のため要検討 |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🔵 | `VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER` | 14 (1年:108) | 1.0% (1年:0.6%) | 個別マスタ別途 | ー（別管理） | ー（別管理） | プラン変更商材のプランコード→プラン名変換マスタ。廃止でプラン名が表示不可（コードのみ表示） | 代替VIEWへの移行対応 |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🔵 | `VW_ADW_DNHL_HOPE_ORDER_BASIC_KI` | 87 (1年:965) | 6.0% (1年:5.7%) | 検討中(内容吟味) | ー（別管理） | ー（別管理） | 全商材共通の施策対象者特定の起点VIEW。廃止でアプリの効果測定機能が全停止する重要VIEWのため代替が必要 | 代替VIEWへの移行対応 |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🔵 | `VW_ADW_DNHL_HOPE_ORDER_SUBJECT_KI` | 87 (1年:965) | 6.0% (1年:5.7%) | 検討中(内容吟味) | ー（別管理） | ー（別管理） | 施策対象者の架電ステータス判定（成約/架電待ち区別）。廃止で成約判定ロジックが破綻するため代替が必要 | 代替VIEWへの移行対応 |
| 2 | テレマ施策効果確認アプリ | pochi-telema-measure-visualization-repository | 🔵 | `VW_ADW_DNHD_BASIC_CONTRACT_CV` | 0 (1年:166) | - (1年:1.0%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNHD_光-契約基本-履歴 | ドコモ光商材の成約フラグ取得。廃止でドコモ光商材が完全停止 | VIEW削除対応でドコモ光商材の機能縮小のため要検討 |
| 3 | DSフムフム | pochi-docomo-shop-analyzer-repository | 🟠 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 12,766 (1年:52,863) | 48.4% (1年:27.0%) | 残留(方針検討中) | ー | ー | 最高利用（1年52,863回）。店舗管理マスタとしてアプリの常時使用基盤となる重要VIEWのため代替が必要 | 代替VIEWへの移行対応 |
| 3 | DSフムフム | pochi-docomo-shop-analyzer-repository | 🔵 | `VW_ADW_DNCL_CATALOG_LIST` | 122 (1年:210) | 0.5% (1年:0.1%) | リファクタ(ALADIN) | ー（別管理） | ー（別管理） | ドコモMAX/ポイ活MAX商材の料金プランコード→プラン名変換マスタ。廃止で「前プラン別」分析軸が判読不能 | 代替VIEWへの移行対応 |
| 3 | DSフムフム | pochi-docomo-shop-analyzer-repository | 🔵 | `VW_ADW_DNHL_GROUP_BASIC_HISTORY` | 183 (1年:1,730) | 0.7% (1年:0.9%) | リファクタ(ALADIN) | ー（別管理） | ー（別管理） | ポートイン商材のファミ割グループ加入履歴取得（ねじれPI判定）。廃止でPI分析の拠点別分類が不可 | 代替VIEWへの移行対応 |
| 3 | DSフムフム | pochi-docomo-shop-analyzer-repository | 🔵 | `VW_DIC_DNHD_CUSTOMER_CHANGE_MB` | 305 (1年:6,798) | 1.2% (1年:3.6%) | 残留(リファクタ有り) | ー | ー | ポートイン・ドコモMAX・ドコモポイ活MAXの3商材で共通使用。廃止で3商材の分析が全停止するため代替が必要 | 代替VIEWへの移行対応 |
| 3 | DSフムフム | pochi-docomo-shop-analyzer-repository | 🔵 | `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` | 0 (1年:4,024) | - (1年:2.1%) | 残留(リファクタ有り) | ー | ー | 開発者向けツールSQLのみ参照（tools/配下）。Streamlitアプリ本体への影響なし | 現在利用していない開発ツールのため対応対象外 |
| 3 | DSフムフム | pochi-docomo-shop-analyzer-repository | 🔵 | `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | 0 (1年:4,242) | - (1年:2.2%) | 残留(リファクタ有り) | 2027年3月 | D_MR_000_CK（新設）/VW_DIC_MECD_会員プロファイル | 開発者向けツールSQLのみ参照（tools/配下）。Streamlitアプリ本体への影響なし | 現在利用していない開発ツールのため対応対象外 |
| 3 | DSフムフム | pochi-docomo-shop-analyzer-repository | 🔵 | `VW_DIC_MECL_CLASSIFIEDBYACTION_CUSTOMER_MB` | 0 (1年:5,005) | - (1年:2.6%) | 断捨離(DWH層代替) | ー（別管理） | ー（別管理） | 開発者向けツールSQLのみ参照（tools/配下）。Streamlitアプリ本体への影響なし | 現在利用していない開発ツールのため対応対象外 |
| 3 | DSフムフム | pochi-docomo-shop-analyzer-repository | 🔵 | `VW_HMD_DNCD_SALES_MANAGEMENT_PRODUCT_MASTER` | 0 (1年:4,787) | - (1年:2.5%) | 残留(方針検討中) | ー | ー | 開発者向けツールSQLのみ参照（tools/配下）。Streamlitアプリ本体への影響なし | 現在利用していない開発ツールのため対応対象外 |
| 4 | 加盟店送客 | pochi-kameiten-riyo-yocho-repository | 🟠 | `VW_ADM_DNCL_COMNID_INTEGRATION` | 33 (1年:1,274) | 26.6% (1年:26.8%) | 断捨離(ADM) | ー（別管理） | ー（別管理） | 高利用（1年1,274回）。ID変換基盤として常時使用する重要VIEWのため代替が必要 | 代替VIEWへの移行対応 |
| 4 | 加盟店送客 | pochi-kameiten-riyo-yocho-repository | 🔵 | `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | 8 (1年:330) | 6.5% (1年:7.0%) | 残留(リファクタ有り) | 2027年3月 | D_MR_000_CK（新設）/VW_DIC_MECD_会員プロファイル | STEP3の「dポお得情報」許諾フィルタでユーザーをCOMNID絞り込みに使用。廃止でコンプライアンスリスクあり | 代替VIEWへの移行対応 |
| 5 | 時系列分析アプリ | pochi-timeseries-data-analyzer-repository | 🔴 | `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` | 206 | 11.3% | 削除(代替無し) | **2026年3月末** | ー |  | 機能縮小修正対応実施中 |
| 5 | 時系列分析アプリ | pochi-timeseries-data-analyzer-repository | 🟠 | `VW_ALL_ARPU` | 未取得 | - | 廃止 | ー（別管理） | ー（別管理） | ARPU/収益グラフの表示ができなくなる |  |
| 5 | 時系列分析アプリ | pochi-timeseries-data-analyzer-repository | 🟠 | `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | 418 | 22.9% | 残留(リファクタ有り) | 2027年3月 | D_MR_000_CK（新設）/VW_DIC_MECD_会員プロファイル | 全機能で利用しているコア部分 | 代替VIEWへの移行対応 |
| 5 | 時系列分析アプリ | pochi-timeseries-data-analyzer-repository | 🟢 | `VUSER_CUST_INFO` | 0 | - | dMC廃止 | ー（別管理） | ー（別管理） |  | テストコードで利用。今回は対応不要だがテスト実施時にアカ識取得可能なVIEWへ代替の必要あり。 |
| 6 | Pochi版StartDash | pochi-startdash-repository | 🟢 | `VW_DIC_DNHD_SETTLEMENT_INTEGRATION` | 39 | 0.7% | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） |  | ★継続提供のため対応不要（2026-03-27確認） |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔴 | `VW_DIC_MECD_MEMBER_PROFILE_USE_INFORMATION` | 0 (1年:256) | - (1年:0.5%) | 削除(代替無し) | **2026年3月末** | ー | コード参照あり（2026年3月末期限・代替なし）。ユーザーフィルタリング実行時に即時エラーが発生するため緊急対応が必要 | 機能縮小修正対応実施中 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_ADM_DNCD_DEALER_DETAILS_MASTER` | 11 (1年:268) | 0.3% (1年:-) | 残留(方針検討中) | 2026年9月 | ー（確認中） | 属性出力の「最終接点日」「最終接点チャネル」「最終接点オーダ種別」「最終接点受付オーダ分類」が欠落 | 最終接点チャネルでの検索、ユーザーリストへのデータ追加が不可のため要検討 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_ADM_MECL_CLASSIFIEDBYACTION_FEE_MASTER` | 32 (1年:868) | 0.8% (1年:-) | 個別マスタ別途 | ー（別管理） | ー（別管理） | 「##### 📶 回線契約」内の「**1. 回線契約種別もしくはプランを選択してください**」 | 料金プランの検索ができなくなるため要検討 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER` | 20 (1年:171) | 0.5% (1年:-) | 個別マスタ別途 | ー（別管理） | ー（別管理） | 祝日データ取得機能で使用 | 平日、土日、祝日を指定した検索方法が実行できなくなるため要検討 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER` | 5 (1年:179) | 0.1% (1年:-) | 個別マスタ別途 | ー（別管理） | ー（別管理） | 店舗リスト取得機能（フィルタサイドバー）で使用。サイドバー「店舗」フィルタ読み込み時に呼び出し | 廃止で店舗リスト取得機能ができなくなるため要検討 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_DIC_DNHD_CUSTOMER_CHANGE_MB` | 11 (1年:268) | 0.3% (1年:-) | 残留(リファクタ有り) | ー | ー | 属性出力の「最終接点日」「最終接点チャネル」「最終接点オーダ種別」「最終接点受付オーダ分類」が欠落 | 最終接点チャネルでの検索、ユーザーリストへのデータ追加が不可のため要検討 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🟢 | `VW_DIC_DNHD_SETTLEMENT_INTEGRATION` | 197 (1年:2,432) | 4.7% (1年:-) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | ユーザーリスト・属性データ取得機能（メイン分析）で使用。分析実行時に呼び出し（30日197回） | ★継続提供のため対応不要（2026-03-27確認） |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` | 30 (1年:747) | 0.7% (1年:-) | 残留(リファクタ有り) | ー | ー | 端末タイプ選択機能（フィルタサイドバー）で使用。サイドバー「端末タイプ」フィルタ読み込み時に呼び出し | 利用端末の検索ができなくなるため要検討 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_ADM_DNCD_BASIC_CONTRACT_MB` | 7 (1年:365) | 0.2% (1年:-) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_携帯-契約基本 | 回線契約・サービス契約系の条件指定（爆アゲ系含む）・遅延監視機能（DogHarness）で使用。分析実行時・DogHarness監視画面表示時に呼び出し | 廃止で回線契約・サービス契約系の条件指定（爆アゲ系含む）・遅延監視機能（DogHarness）ができなくなる |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_ADM_DNCL_COMNID_INTEGRATION` | 130 (1年:2,736) | 3.1% (1年:-) | 断捨離(ADM) | ー（別管理） | ー（別管理） | ユーザーフィルタリング機能・遅延監視機能（DogHarness）のID変換基盤として使用。分析実行時・DogHarness監視画面表示時に呼び出し | 代替VIEWへの移行対応 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_ADW_DNCD_SERVICE_BASIC_2_MB` | 6 (1年:243) | 0.1% (1年:-) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_携帯-契約サービス | ユーザーフィルタリング機能（サービス種別フィルタ適用時）・遅延監視機能（DogHarness）で使用 | 代替VIEWへの移行対応 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_ADW_DNCD_SERVICE_BASIC_3_MB` | 6 (1年:243) | 0.1% (1年:-) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_携帯-契約サービス | ユーザーフィルタリング機能（サービス種別フィルタ適用時）・遅延監視機能（DogHarness）で使用 | 代替VIEWへの移行対応 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔵 | `VW_DIC_MECL_TRAFFIC_INTEGRATION_MB` | 10 (1年:388) | 0.2% (1年:-) | 断捨離(DWH層代替) | ー（別管理） | ー（別管理） | 期間設定ができなくなる・遅延監視機能（DogHarness）で使用。アプリ起動時またはフィルタリング実行時に呼び出し | 代替VIEWへの移行対応 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔴 | `VUSER_CUST_INFO` | 0 (1年:9,060) | - (1年:17.1%) | dMC廃止 | ー（別管理） | ー（別管理） | このVIEWがなくなると、性別・年代・法人除外・住所・同意設定・アウトバウンド許諾・マイショップ条件での抽出が成立しない | 代替VIEWへの移行対応 |
| 7 | ドコモユーザー滞在施設みえる化アプリ | pochi-user-behavior-map-repository | 🔴 | `VUSER_SO_CONTRACT_CURRENT` | 0 (1年:895) | - (1年:1.7%) | dMC廃止 | ー（別管理） | ー（別管理） | ドコモ光・home5G・homeでんわ等の契約有無フィルタが停止 | 代替VIEWへの移行対応 |
| 8 | 事業OP九州アプリ | pochi-store-area-analysis-repository | 🟠 | `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` | 346 (1年:1,123) | 10.1% (1年:12.1%) | 残留(リファクタ有り) | ー | ー | 高利用（30日346回）。契約者数分析での住所コード変換結合に使用する重要VIEW。代替が必要 | 代替VIEWへの移行対応 |
| 8 | 事業OP九州アプリ | pochi-store-area-analysis-repository | 🟠 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 516 (1年:1,413) | 15.0% (1年:15.2%) | 残留(方針検討中) | ー | ー | 高利用（30日516回）。店舗マスタとして主要機能に使用する重要VIEW。代替が必要 | 代替VIEWへの移行対応 |
| 8 | 事業OP九州アプリ | pochi-store-area-analysis-repository | 🔵 | `VW_ADW_DNCD_ADDRESS_AGGREGATION_MASTER` | 171 (1年:523) | 5.0% (1年:5.6%) | 残留(方針検討中) | 2026年9月 | ー（確認中） | MNP分析機能（MNP純増・PI/PO分析）の住所コード→都道府県名変換で使用。MNP分析セクション選択時に呼び出し | 代替VIEWへの移行対応 |
| 8 | 事業OP九州アプリ | pochi-store-area-analysis-repository | 🔵 | `VW_ADW_DNCD_ADDRESS_MASTER` | 26 (1年:269) | 0.7% (1年:2.9%) | 残留(方針検討中) | 2026年9月 | ー（確認中） | 契約者数・住所分析機能で使用。「分析開始」ボタンクリック時に呼び出し | 主要機能のため代替VIEWへの対応 |
| 8 | 事業OP九州アプリ | pochi-store-area-analysis-repository | 🔵 | `VW_ADW_DNCL_PUBLIC_HOLIDAY_MASTER` | 81 (1年:161) | 2.3% (1年:1.7%) | 個別マスタ別途 | ー（別管理） | ー（別管理） | ランドマーク起点人流分析機能の祝日判定で使用。ランドマーク起点マップで地図クリック時に呼び出し | 廃止でランドマーク起点人流分析機能の祝日判定ができなくなるため要検討 |
| 8 | 事業OP九州アプリ | pochi-store-area-analysis-repository | 🔵 | `VW_ADW_DNCL_STAFF_DETAILS` | 90 (1年:331) | 2.6% (1年:3.6%) | 検討中(内容吟味) | ー（別管理） | ー（別管理） | スタッフ数分析機能で使用。「分析開始」ボタンクリック時に呼び出し | 廃止でスタッフ数分析機能ができなくなるため要検討 |
| 8 | 事業OP九州アプリ | pochi-store-area-analysis-repository | 🔵 | `VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER` | 226 (1年:767) | 6.6% (1年:8.3%) | 個別マスタ別途 | ー（別管理） | ー（別管理） | 店舗情報・来客数・スタッフ管理機能で使用。九州エリア来客数計算・店舗位置情報表示時に呼び出し | 廃止で店舗情報・来客数・スタッフ管理機能ができなくなるため要検討 |
| 8 | 事業OP九州アプリ | pochi-store-area-analysis-repository | 🔵 | `VW_DIC_DNHD_CUSTOMER_CHANGE_MB` | 229 (1年:779) | 6.7% (1年:8.4%) | 残留(リファクタ有り) | ー | ー | MNP分析機能（MNP純増・PI/PO分析）で使用。MNP分析セクション選択時・都道府県フィルタ適用時に呼び出し | 主要機能のため代替VIEWで対応 |
| 9 | d払いNW見える化 | pochi-d-pay-nw-quality-visualizer-repository | 🟢 | `VW_HMD_MJCD_INTEGRATION_GENRE_MASTER` | 690 (1年:6,570) | 2.2% (1年:2.5%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | NW品質マップ可視化ページのジャンル選択ドロップダウンで使用。アプリ起動時にGenreMaster ORM経由で大ジャンルリスト（食事・生活・娯楽等）を取得し、フィルタ選択肢に表示 | ★継続提供のため対応不要（2026-03-27確認） |
| 9 | d払いNW見える化 | pochi-d-pay-nw-quality-visualizer-repository | 🟢 | `VW_ADM_DNHD_MERCHANT_SETTLEMENT` | 0 | - | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | 参考SQL（static/バーコード表示時間取得クエリ.sql）およびdata_sources.pyのデータソース説明ページで参照。本番SQLAlchemyクエリでは未使用（VW_MBL_DNHL_MERCHANT_SETTLEMENTに移行済み） | ★継続提供のため対応不要（2026-03-27確認） |
| 9 | d払いNW見える化 | pochi-d-pay-nw-quality-visualizer-repository | 🟢 | `VW_DMC_DNHL_FIREBASEANALYTICS_EVENT_PARAMETERS_CURTDAY` | 0 | - | dMC廃止 | ー（別管理） | ー（別管理） | dMC廃止対象。参考SQL（static/バーコード表示時間取得クエリ.sql）およびdata_sources.pyのデータソース説明ページで参照。またDogHarnessデータ鮮度監視（nw_improvement_dashboard_v2/nw_improvement_store_extractor）でVIEW名を文字列参照。本番クエリでは未使用 | DogHarnessのVIEW名文字列削除 + 参考SQL・ドキュメントからの参照削除 |
| 9 | d払いNW見える化 | pochi-d-pay-nw-quality-visualizer-repository | 🟢 | `VUSER_CUST_INFO` | 0 | - | - | ー（別管理） | ー（別管理） | ❗レポート誤り: 本番コードで使用されている。NW品質マップ可視化ページの「📊集計結果」セクションで性別・年代別集計に使用。_graph_data.pyのget_si_agg_by_gender()/get_si_agg_by_nendai()がcreate_gender_and_age_info_cte()経由でCTEとしてクエリに組み込み。クエリ履歴が0件なのはCTEのためトラッキングされていない可能性が高い | dMC廃止済みのため、user_demographics.pyのCTE関数 + graph_data.pyの性別・年代別集計機能の代替対応が必要 |
| 9 | d払いNW見える化 | pochi-d-pay-nw-quality-visualizer-repository | 🟢 | `VW_ADM_DNCL_COMNID_INTEGRATION` | 0 (1年:183) | - (1年:0.1%) | - | ー（別管理） | ー（別管理） | cte_definitions/id_convert.pyでCTE関数（create_comnid_to_acctid_convert_cte / create_acctid_to_comnid_convert_cte）として定義。アプリの本番コード（app_pages/配下）からの呼び出しなし。コード削除のみ | cte_definitions/id_convert.pyのCTE関数 + sa_modelsのComnidIntegrationクラス削除 |
| 9 | d払いNW見える化 | pochi-d-pay-nw-quality-visualizer-repository | 🟢 | `VW_ADW_DNCL_PRODUCT_ATTRIBUTE_MASTER` | 0 (1年:183) | - (1年:0.1%) | - | ー（別管理） | ー（別管理） | sa_models/vw_adw_dncl_product_attribute_master.pyでProductAttributeMaster ORMクラスとして定義のみ。アプリの本番コードからのimport・クエリ構築なし。コード削除のみ | sa_models/vw_adw_dncl_product_attribute_master.pyのファイル削除 |
| 10 | 施策リフトツール | pochi-promotion-lift-calculator-repository | 🟠 | `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | 18 | 11.9% | 残留(リファクタ有り) | 2027年3月 | D_MR_000_CK（新設）/VW_DIC_MECD_会員プロファイル | dポクラブランク分析・ARPU分析（dカードグレード・回線契約者フィルタ）の3機能で共通使用。廃止で複数分析機能が停止するため代替が必要 | 代替VIEWへの移行対応 |
| 11 | KGI/KPI課題分析・顧客像深掘りアプリ(スマホ総販のみ) | pochi-kpi-analyzer-repository | 🟠 | `VW_DIC_DNHD_CUSTOMER_CHANGE_MB` | 68 (1年:1,062) | 20.3% (1年:20.9%) | 残留(リファクタ有り) | ー | ー | 高利用（30日68回、1年1,062回）。スマホ総販の契約変更履歴取得に使用する重要VIEW。代替が必要 | 代替VIEWへの移行対応 |
| 11 | KGI/KPI課題分析・顧客像深掘りアプリ(スマホ総販のみ) | pochi-kpi-analyzer-repository | 🟠 | `VW_HMD_DNCD_SALES_MANAGEMENT_PRODUCT_MASTER` | 68 (1年:1,049) | 20.3% (1年:20.7%) | 残留(方針検討中) | ー | ー | 高利用（30日68回、1年1,049回）。商品マスタとして主要機能に使用する重要VIEW。代替が必要 | 代替VIEWへの移行対応 |
| 11 | KGI/KPI課題分析・顧客像深掘りアプリ(スマホ総販のみ) | pochi-kpi-analyzer-repository | 🟠 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 68 (1年:1,049) | 20.3% (1年:20.7%) | 残留(方針検討中) | ー | ー | 高利用（30日68回、1年1,049回）。店舗マスタとして主要機能に使用する重要VIEW。代替が必要 | 代替VIEWへの移行対応 |
| 11 | KGI/KPI課題分析・顧客像深掘りアプリ(スマホ総販のみ) | pochi-kpi-analyzer-repository | 🔵 | `VW_ADM_DNCD_BASIC_CONTRACT_CV` | 9 (1年:114) | 2.7% (1年:2.1%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_光-契約基本 | 相関分析機能（corr_llm.py）でドコモ光契約有無判定に使用。「分析内容を出力する」ボタン押下時に呼び出し | 廃止で相関分析の「ドコモ光」列が取得不可、となるため要検討 |
| 11 | KGI/KPI課題分析・顧客像深掘りアプリ(スマホ総販のみ) | pochi-kpi-analyzer-repository | 🔵 | `VW_ADW_DNCD_SERVICE_BASIC_3_MB` | 9 (1年:114) | 2.7% (1年:2.1%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_携帯-契約サービス | 相関分析機能（corr_llm.py）でdカード契約状況（PLATINUM/通常/GOLD）取得に使用。「分析内容を出力する」ボタン押下時に呼び出し | 廃止で相関分析の「dカードPLATINUM」「dカード」「dカードGOLD」列が取得不可となるため要検討 |
| 11 | KGI/KPI課題分析・顧客像深掘りアプリ(スマホ総販のみ) | pochi-kpi-analyzer-repository | 🔵 | `VW_ADW_DNCD_SERVICE_BASIC_MB` | 17 (1年:331) | 5.1% (1年:6.2%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_携帯-契約サービス | ユーザーグループ情報取得（カエドキプログラム加入判定）で使用。「購入者情報を取得する」ボタンクリック時に呼び出し | 廃止でユーザーグループ情報取得（カエドキプログラム加入判定）ができなくなるため要検討 |
| 11 | KGI/KPI課題分析・顧客像深掘りアプリ(スマホ総販のみ) | pochi-kpi-analyzer-repository | 🔵 | `VW_ADW_DNHD_BASIC_CONTRACT_MB` | 5 (1年:65) | 1.5% (1年:1.2%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNHD_携帯-契約基本-履歴 | 相関分析機能（corr_llm.py）でMNPポートイン判定に使用。「分析内容を出力する」ボタン押下時に呼び出し | 廃止で相関分析の「MNP-ポートイン」列が取得不可、となるため要検討 |
| 11 | KGI/KPI課題分析・顧客像深掘りアプリ(スマホ総販のみ) | pochi-kpi-analyzer-repository | 🟢 | `VDICE_MEMBER_PROFILE_BASIC_INFORMATION` | 0 | - | dMC廃止 | ー（別管理） | ー（別管理） | dMC廃止対象。購入者ペルソナ分析（user_group_info.py）で推定年収・dカード種別・dサービス契約状況の取得に使用。dMC廃止によりクエリ0件 | 購入者ペルソナ分析（user_group_info.py）で推定年収・dカード種別・dサービス契約状況の分析ができなくなるため要検討 |
| 12 | データ活用広告配信向け広告ID変換 | pochi-advertisingid-extraction-app-repository | 🟠 | `VW_DIC_DNCD_MEMBER_BUSINESS_INTEGRATION` | 66 (1年:716) | 91.7% (1年:22.9%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_会員-契約基本 | 高利用（30日66回・91.7%、1年716回）。CSVアップロードモードのコアVIEW。廃止でCSVアップロード機能が停止するため代替が必要 | 代替VIEWへの移行対応 |
| 12 | データ活用広告配信向け広告ID変換 | pochi-advertisingid-extraction-app-repository | 🟠 | `VW_ADM_DNCD_BASE_NUMBER_ACCTID_CONVERSION_MASTER` | 0 (1年:407) | - (1年:11.3%) | 残留(方針検討中) | ー | ー | 広告ID変換機能（契約サービス選択／ファイルアップロード両モード）で使用。「見積もり」「データを変換」ボタン押下時（1年407回） | 代替VIEWへの移行対応 |
| 12 | データ活用広告配信向け広告ID変換 | pochi-advertisingid-extraction-app-repository | 🔵 | `VW_ADM_DNCD_SERVICE_BASIC_CF` | 0 (1年:12) | - (1年:0.3%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_CF-契約サービス | dアニメストア(CF)契約者の絞り込みで利用 | dアニメストア(CF)契約者の絞り込みができなくなるため要検討 |
| 12 | データ活用広告配信向け広告ID変換 | pochi-advertisingid-extraction-app-repository | 🔵 | `VW_ADM_DNCL_COMNID_INTEGRATION` | 0 (1年:14) | - (1年:0.4%) | 断捨離(ADM) | ー（別管理） | ー（別管理） | dアニメストア抽出で利用 | dアニメストア抽出ができなくなるため要検討 |
| 12 | データ活用広告配信向け広告ID変換 | pochi-advertisingid-extraction-app-repository | 🔵 | `VW_ADW_DNCD_SERVICE_BASIC_MB` | 0 (1年:14) | - (1年:0.4%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_携帯-契約サービス | dアニメストア抽出で利用 | dアニメストア抽出ができなくなるため要検討 |
| 12 | データ活用広告配信向け広告ID変換 | pochi-advertisingid-extraction-app-repository | 🟠 | `VW_ADW_MECL_SERVICE_BASIC` | 0 (1年:407) | - (1年:11.3%) | リファクタ(ALADIN) | ー（別管理） | ー（別管理） | 汎用サービス契約者抽出（dアニメ・dスポーツくじ以外）。ID変換実行時に主要JOIN軸として呼び出し（1年407回） | 代替VIWEで対応する |
| 12 | データ活用広告配信向け広告ID変換 | pochi-advertisingid-extraction-app-repository | 🟠 | `VW_ADW_MECL_SERVICE_BASIC_2` | 0 (1年:202) | - (1年:5.6%) | VIEW統合 | ー（別管理） | ー（別管理） | 汎用サービス契約者抽出（dアニメ・dスポーツくじ以外）。VW_ADW_MECL_SERVICE_BASICと統合予定 | 代替VIWEで対応する |
| 12 | データ活用広告配信向け広告ID変換 | pochi-advertisingid-extraction-app-repository | 🟠 | `VW_ADW_MECL_SERVICE_BASIC_3` | 0 (1年:145) | - (1年:4.0%) | VIEW統合 | ー（別管理） | ー（別管理） | 汎用サービス契約者抽出（dアニメ・dスポーツくじ以外）。VW_ADW_MECL_SERVICE_BASICと統合予定 | 代替VIWEで対応する |
| 12 | データ活用広告配信向け広告ID変換 | pochi-advertisingid-extraction-app-repository | 🔵 | `VW_DTT_DNHD_DOCOMO_SPORTSKUJI_SERVICE_USE` | 0 (1年:6) | - (1年:0.2%) | 残留(リファクタ有り) | 2026年9月 | L_MR_000/VW_DTT_DNHL_サービス会員 | 広告ID変換機能（契約サービス選択モード）でドコモスポーツくじ選択時に使用。サービス選択後の変換実行時に呼び出し | ドコモスポーツくじで利用ができなくなるため要検討 |
| 13 | ＜社内向け＞加盟店別d払い明細抽出 | pochi-dpay-dpoint-detail-extractor-repository | 🟠 | `VW_ADW_DNCL_ADDRESS_AGGREGATION_MASTER` | 30 | 10.6% | 個別マスタ別途 | ー（別管理） | ー（別管理） |  | 代替VIEWへの移行対応 |
| 13 | ＜社内向け＞加盟店別d払い明細抽出 | pochi-dpay-dpoint-detail-extractor-repository | 🟠 | `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` | 30 | 10.6% | 残留(リファクタ有り) | ー | ー |  | 代替VIEWへの移行対応 |
| 13 | ＜社内向け＞加盟店別d払い明細抽出 | pochi-dpay-dpoint-detail-extractor-repository | 🟢 | `VW_HMD_MJCD_DBARAI_CITY_STORE_MASTER` | 30 | 10.6% | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） |  | ★継続提供のため対応不要（2026-03-27確認） |
| 13 | ＜社内向け＞加盟店別d払い明細抽出 | pochi-dpay-dpoint-detail-extractor-repository | 🟢 | `VW_HMD_MJCD_DBARAI_NET_SITE_MASTER` | 30 | 10.6% | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） |  | ★継続提供のため対応不要（2026-03-27確認） |
| 13 | ＜社内向け＞加盟店別d払い明細抽出 | pochi-dpay-dpoint-detail-extractor-repository | 🟢 | `VW_MBL_DNCD_DBARAI_CPID_MASTER` | 81 | 28.5% | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） |  | ★継続提供のため対応不要（2026-03-27確認） |
| 14 | ロイヤルカスタマー分析 | pochi-loyal-customer-analysis-repository | 🟢 | `VW_ADM_DNHD_SETTLEMENT_ANALYSIS` | 102 (1年:494) | 12.2% (1年:11.0%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | 高利用（30日102回）。d払い・dポイント精算明細データ取得で使用する重要VIEW。代替が必要 | ★継続提供のため対応不要（2026-03-27確認） |
| 14 | ロイヤルカスタマー分析 | pochi-loyal-customer-analysis-repository | 🟠 | `VW_ADW_MECD_COMNID_CONFIGURATION_INTEGRATION` | 105 (1年:587) | 12.6% (1年:13.1%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_MECD_共通-共通IDグループ-月末 | 高利用（30日105回）。ユーザーID（COMNID）設定統合取得で使用する重要VIEW。代替が必要 | 代替VIWEで対応する |
| 14 | ロイヤルカスタマー分析 | pochi-loyal-customer-analysis-repository | 🟢 | `VW_DIC_DNHD_DCARD_INTEGRATION_DCARD_SALES` | 102 (1年:522) | 12.2% (1年:11.6%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | 高利用（30日102回）。dカード決済履歴データ取得で使用する重要VIEW。代替が必要 | ★継続提供のため対応不要（2026-03-27確認） |
| 14 | ロイヤルカスタマー分析 | pochi-loyal-customer-analysis-repository | 🟠 | `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | 99 (1年:399) | 11.9% (1年:8.9%) | 残留(リファクタ有り) | 2027年3月 | D_MR_000_CK（新設）/VW_DIC_MECD_会員プロファイル | 高利用（30日99回）。dポイントランク・dカード区分等の会員プロフィール取得で使用する重要VIEW。代替が必要 | 代替VIWEで対応する |
| 14 | ロイヤルカスタマー分析 | pochi-loyal-customer-analysis-repository | 🟢 | `VW_DIC_MECD_MEMBER_PROFILE_POINT_GIVE_USE` | 102 (1年:396) | 12.2% (1年:8.8%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | 高利用（30日102回）。dポイント付与・利用履歴データ取得で使用する重要VIEW。代替が必要 | ★継続提供のため対応不要（2026-03-27確認） |
| 14 | ロイヤルカスタマー分析 | pochi-loyal-customer-analysis-repository | 🔵 | `VW_ADW_MECL_CLAIM_ELABORATED` | 12 (1年:254) | 1.4% (1年:5.8%) | リファクタ(MoBills) | ー（別管理） | ー（別管理） | NW請求額・光請求額データ取得で使用。分析実行時に呼び出し | 廃止でNW請求額・光請求額データ取得ができなくなる |
| 15 | d払い決済状況見える化ツール | pochi-d-pay-merchant-visualizer-repository | 🔵 | `VW_ADW_DNCL_STORE_INFORMATION_MANAGEMENT_MASTER` | 58 (1年:614) | 0.1% (1年:0.1%) | 個別マスタ別途 | ー（別管理） | ー（別管理） | ショップ起点の加盟店検索機能で使用。ショップコード入力時に呼び出し | 都道府県検索ができなくなるため要検討 |
| 15 | d払い決済状況見える化ツール | pochi-d-pay-merchant-visualizer-repository | 🟢 | `VW_DIC_DNHD_SETTLEMENT_INTEGRATION` | 4,801 (1年:49,372) | 9.9% (1年:8.5%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | 高利用（30日4,801回、1年49,372回）。加盟店別d払い決済データ取得で使用。加盟店ジャンル別グラフ表示・ユーザーリストダウンロード時に呼び出し | ★継続提供のため対応不要（2026-03-27確認） |
| 15 | d払い決済状況見える化ツール | pochi-d-pay-merchant-visualizer-repository | 🟢 | `VW_HMD_MJCD_INTEGRATION_GENRE_MASTER` | 120 (1年:1,812) | 0.2% (1年:0.3%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | 加盟店ジャンル選択リスト取得で使用。ジャンル絞り込み検索時に呼び出し | ★継続提供のため対応不要（2026-03-27確認） |
| 16 | ＜社内向け＞ID変換器 | pochi-id-converter-repository | 🟠 | `VW_ADM_DNCL_COMNID_INTEGRATION` | 997 (1年:9,756) | 21.8% (1年:22.7%) | 断捨離(ADM) | ー（別管理） | ー（別管理） | 高利用（30日997回・21.8%）。全ID変換機能の共通基盤として使用する最重要VIEW。廃止でアプリ全機能が停止するため代替が必要 | 廃止でアプリ全機能が停止 |
| 16 | ＜社内向け＞ID変換器 | pochi-id-converter-repository | 🟢 | `VW_ADM_DNCD_DCARD_REGULAR_MEMBER` | 3 (1年:50) | 0.1% (1年:0.1%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | dカード会員ID変換（現テーブル）で使用。代表顧客番号↔基本契約番号(クレジット)変換選択時に呼び出し | ★継続提供のため対応不要（2026-03-27確認） |
| 16 | ＜社内向け＞ID変換器 | pochi-id-converter-repository | 🔵 | `VW_DIC_DNCL_THIS_FAMILY_MEMBER_INFORMATION` | 3 (1年:50) | 0.1% (1年:0.1%) | 残す方向 | ー（別管理） | ー（別管理） | dカード本家族会員情報取得で使用。家族会員番号↔代表顧客番号変換選択時に呼び出し | 廃止でdカード本家族会員情報取得ができなくなるため要検討 |
| 16 | ＜社内向け＞ID変換器 | pochi-id-converter-repository | 🟢 | `VW_DIC_MECD_DCARD_INTEGRATION_DCARD_MEMBER` | 23 (1年:223) | 0.5% (1年:0.5%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | dカード会員ID変換（統合テーブル）で使用。基本契約番号(クレジット)入出力選択時に呼び出し | ★継続提供のため対応不要（2026-03-27確認） |
| 16 | ＜社内向け＞ID変換器 | pochi-id-converter-repository | 🟢 | `VW_DMC_DNCL_LINE_FRIEND_LIST` | 0 (1年:519) | - (1年:1.2%) | dMC廃止 | ー（別管理） | ー（別管理） | dMC廃止対象。LINE ユーザーID変換機能のコード削除のみ | LINE ID相互変換ができなくなるため要検討 |
| 16 | ＜社内向け＞ID変換器 | pochi-id-converter-repository | 🟢 | `VW_DMC_DNCL_LINE_USER_ID_COORDINATION_DATA` | 0 (1年:519) | - (1年:1.2%) | dMC廃止 | ー（別管理） | ー（別管理） | dMC廃止対象。LINE ユーザーID変換機能のコード削除のみ | LINE ID相互変換ができなくなるため要検討 |
| 17 | 最寄りドコモショップ検索アプリ | pochi-nearby-store-finder-repository | 🟠 | `VW_ADM_DNCD_DEALER_DETAILS_MASTER` | 13 | 12.5% | 残留(方針検討中) | 2026年9月 | ー（確認中） |  | 代替VIEWへの移行対応 |
| 17 | 最寄りドコモショップ検索アプリ | pochi-nearby-store-finder-repository | 🟠 | `VW_ADW_DNCD_ADDRESS_MASTER` | 13 | 12.5% | 残留(方針検討中) | 2026年9月 | ー（確認中） |  | 代替VIEWへの移行対応 |
| 17 | 最寄りドコモショップ検索アプリ | pochi-nearby-store-finder-repository | 🟠 | `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` | 13 | 12.5% | 残留(リファクタ有り) | ー | ー |  | 代替VIEWへの移行対応 |
| 17 | 最寄りドコモショップ検索アプリ | pochi-nearby-store-finder-repository | 🟠 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 13 | 12.5% | 残留(方針検討中) | ー | ー |  | 代替VIEWへの移行対応 |
| 18 | お客様の声みえる化アプリ | pochi-voc-risk-detector-repository | 🔵 | `VW_ADM_DNCL_COMNID_INTEGRATION` | 241 (1年:4,165) | 7.6% (1年:3.8%) | 断捨離(ADM) | ー（別管理） | ー（別管理） | 3ページで使用。1) csv_detail_register.py: CSV登録時の属性付与処理で基本契約番号→COMNID変換に使用。2) detail.py: 「アカウント識別子のリストを作成する」ボタン押下時に基本契約番号→アカウント識別子変換に使用。3) deep_dive_issue.py: 解約影響分析ページのダウンロード時に同様のID変換に使用 | 廃止で属性付与・ID変換・ダウンロード機能が停止。代替VIEWへの移行対応 |
| 18 | お客様の声みえる化アプリ | pochi-voc-risk-detector-repository | 🔵 | `VW_DIC_DNHD_CUSTOMER_CHANGE_MB` | 6 (1年:889) | 0.2% (1年:0.8%) | 残留(リファクタ有り) | ー | ー | deep_dive_issue.py（解約への影響を見るページ）で使用。日次の契約解除ユーザーリスト取得に使用（解約・ MNPポートアウトの受付オーダー登録日を取得）。「解約データ収集中...」プログレスバー表示時に呼び出し | 廃止で日次解約データ取得が停止。代替VIEWへの移行対応 |
| 18 | お客様の声みえる化アプリ | pochi-voc-risk-detector-repository | 🔵 | `VW_DIC_MECL_CLASSIFIEDBYACTION_CUSTOMER_MB` | 230 (1年:3,243) | 7.3% (1年:2.9%) | 断捨離(DWH層代替) | ー（別管理） | ー（別管理） | 2ページで使用。1) csv_detail_register.py: CSV登録時の属性付与処理で請求先住所コード（支社判定）取得に使用。2) deep_dive_issue.py: 解約影響分析ページで月次解約ユーザーリスト取得（当月純粋解約・MNPポートアウト）に使用。「解約データ収集中...」プログレスバー表示時に呼び出し | 廃止で支社別属性付与 + 月次解約データ取得が停止。代替VIEWへの移行対応 |
| 19 | 開発者ブログ | pochi-developers-blog-repository | 🟢 | `VW_DIC_DNHD_SETTLEMENT_INTEGRATION` | 0 | - | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | 松本さんブログ記事のデモ機能で使われている | ★継続提供のため対応不要（2026-03-27確認） |
| 19 | 開発者ブログ | pochi-developers-blog-repository | 🟢 | `VW_HMD_MJCD_DBARAI_CITY_STORE_MASTER` | 0 | - | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | 松本さんブログ記事のデモ機能で使われている | ★継続提供のため対応不要（2026-03-27確認） |
| 20 | カスタマージャーニー | pochi-customer-journey-visualization-repository | 🔵 | `VW_ADM_DNCD_BASIC_CONTRACT_MB` | 4 (1年:66) | 8.9% (1年:0.7%) | 削除(代替有り) | 2026年9月 | D_CM_000（新設）/VW_DSC_DNCD_携帯-契約基本 | 料金プラン判定・5G/ahamo対象者集計で使用。分析実行時に呼び出し | 廃止で料金プラン判定・5G/ahamo対象者集計ができなくなるため要検討 |
| 20 | カスタマージャーニー | pochi-customer-journey-visualization-repository | 🔵 | `VW_DIC_MECL_CLASSIFIEDBYACTION_CUSTOMER_MB` | 1 (1年:324) | 2.2% (1年:3.2%) | 断捨離(DWH層代替) | ー（別管理） | ー（別管理） | 月別集計期間取得・属性フィルタで使用。日付入力フォーム表示時・分析実行時に呼び出し | 代替VIEWへの移行対応 |
| 21 | dカードロイヤルカスタマー可視化分析 | pochi-loyal-customer-visualizer-repository | 🟢 | `VW_DIC_DNHD_DCARD_INTEGRATION_DCARD_SALES` | 4 | 33.3% | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） |  | ★継続提供のため対応不要（2026-03-27確認） |
| 22 | 事業OPRC戦量販アプリ | pochi-retail-event-kashika-repository | 🟢 | `VW_DIC_DNHD_CUSTOMER_CHANGE_MB` | 0 | - | 残留(リファクタ有り) | ー | ー | イベントKPIページ「直近7日間の日別新規契約者数」 を取得するSQLで利用されているがコメントアウトされている | 今後「直近7日間の日別新規契約者数」 を表示するのか要確認 |
| 23 | 店舗NPSアンケート分析アプリ | pochi-nps-analyzer-repository | 🟠 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 829 | 17.0% | 残留(方針検討中) | ー | ー |  | 代替VIEWへの移行対応 |
| 24 | 総合ARPU分析 | pochi-sogo-arpu-analysis-repository | 🟢 | `VW_ADW_DNCD_ADDRESS_MASTER` | 0 | - | 残留(方針検討中) | 2026年9月 | ー（確認中） | 分析グラフが古いデータのままになる | 代替VIEWへの移行対応 |
| 25 | 来店促進分析 | pochi-dpoint-active-raiten-repository | 🟠 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 168 | 29.3% | 残留(方針検討中) | ー | ー |  | 代替VIEWへの移行対応 |
| 25 | 来店促進分析 | pochi-dpoint-active-raiten-repository | 🟠 | `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | (~168) | (~29.3%) | 残留(リファクタ有り) | 2027年3月 | D_MR_000_CK（新設）/VW_DIC_MECD_会員プロファイル | 収集漏れ、実質~168回 | 代替VIEWへの移行対応 |
| 26 | 配信対象者抽出 | pochi-customer-filtering-repository | 🟠 | `VUSER_CUST_INFO` | 0 | 0.0% | dMC廃止 | **2027/3末** | ー（別管理） | query_helper.pyのgenerate_query_conditions_for_user()で配信対象者フィルタリングの中核VIEWとして使用。ブロックリスト除外(BLK_ACNT_FLG)、dアカウント保有判定(DACNT_PSN_FLG)、回線契約状態(LINE_CTR_STT)、青少年除外(CTRR_AGE/RGRD_UTLR_AGE)、メール不達除外(MAIL_NON_DELI_LTST_YM)の5種フィルタ条件をINNER JOINで適用。01_startdash.pyのカウント実行・ダウンロード実行の両方で呼び出し | 代替VIEWへの移行対応 |
| 26 | 配信対象者抽出 | pochi-customer-filtering-repository | 🟠 | `VW_ADM_DNCD_PUSH_DELIVERY_PERMISSION` | 757 | 17.2% | 残留(リファクタ有り) | ー | ー |  | 代替VIEWへの移行対応 |
| 27 | DS代理店/店舗販売状況可視化＆資料化アプリ | pochi-branch-sales-visualizer-repository | 🔵 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | 62 | 5.2% | 代替VIEW対応 | ー | ー | 主要VIEWのため必須 | 代替VIEWへの移行対応 |
| 28 | 手数料シミュレータアプリ | pochi-commission-simulator-repository | 🟠 | `VW_HMD_DNCD_SALES_MANAGEMENT_SALESOUTLET_MASTER` | - | - | 残留(方針検討中) | ー | ー |  | 代替VIEWへの移行対応 |
| 29 | Snowcampゼロ次分析（MI部） | pochi-docomo-zero-order-analysis-repository | 🔴 | `VW_PGN_MECD_STARTDASH_BASIC_ATTRIBUTE_AREA_OTHER` | - (1年:191) | - (1年:9.2%) | 削除(代替無し) | **2026年3月末** | U_DPME_MR/VW_StartDash_基本属性 | sql.pyのsummary_sqlで使用。1) all_startdashサブクエリ: 全体の婚姻状態(MARRIAGE_STATUS_CODE)・子供有無(CHILDREN_CODE)をACCTID別に集計。2) targetサブクエリ: 購入者のTARGET_USERテーブルとLEFT JOINし、購入者の婚姻・子供属性を集計。display_result()→「🗾デモグラフィック情報」タブの婚姻有無・子供有無グラフ表示に使用 | 廃止で「婚姻有無」「子供有無」のデモグラ分析が全停止。機能縮小で対応予定 |
| 29 | Snowcampゼロ次分析（MI部） | pochi-docomo-zero-order-analysis-repository | 🟢 | `VW_DIC_DNHD_SETTLEMENT_INTEGRATION` | - (1年:208) | - (1年:10.1%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | sql.pyで3つのSQLに使用。1) settlement_target_sql: 「決済統合のジャンル検索」モードでジャンル指定のターゲットユーザー抽出(CREATE TEMP TABLE)。2) settlement_store_target_sql: 「決済統合の利用店舗検索」モードで店舗キーワード検索のターゲットユーザー抽出。3) store_detail_sql: 店舗一覧取得ボタン押下時に店舗別購入者数を集計表示。「実行」ボタンで呼び出し | ★継続提供のため対応不要（2026-03-27確認） |
| 29 | Snowcampゼロ次分析（MI部） | pochi-docomo-zero-order-analysis-repository | 🔵 | `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | - (1年:191) | - (1年:9.2%) | 残留(リファクタ有り) | 2027年3月 | D_MR_000_CK（新設）/VW_DIC_MECD_会員プロファイル | sql.pyのsummary_sqlで使用。1) all_profileサブクエリ: 全体の性別・年代・dポイントランク・都道府県・推定年収・世帯主フラグをACCTID別に集計。2) targetサブクエリ: 購入者のTARGET_USERテーブルとLEFT JOINし同属性を集計。display_result()→「🗾デモグラフィック情報」タブの性別・年代・ランク・年収・都道府県・世帯主グラフ表示に使用 | 廃止で「性別」「年代」「dポイントランク」「推定年収」「都道府県」「世帯主」のデモグラ分析が全停止。代替VIEWへの移行対応 |
| 29 | Snowcampゼロ次分析（MI部） | pochi-docomo-zero-order-analysis-repository | 🔵 | `VW_DSH_DNHD_DSHOPPING_PURCHASE` | - (1年:152) | - (1年:7.3%) | 残留(リファクタ有り) | 2026年9月 | L_MR_000/VW_DSH_DNCL_購入履歴 | sql.pyのdshopping_target_sqlで使用。「dショッピングキーワード検索」モードのターゲットユーザー抽出に使用（CREATE TEMP TABLE TARGET_USER）。商品キーワード検索結果から期間内の購入者COMNID/ACCTIDと購入金額・回数・平均を集計。「実行」ボタン押下時に呼び出し | 廃止で「dショッピングキーワード検索」モードが全停止。代替VIEWへの移行対応 |
| 29 | Snowcampゼロ次分析（MI部） | pochi-docomo-zero-order-analysis-repository | 🔵 | `VW_DSH_DNCD_DSHOPPING_PRODUCT_MASTER` | - (1年:32) | - (1年:1.5%) | 残留(リファクタ無し) | 2026年9月 | L_MR_000/VW_DSH_DNCL_dショッピング-商品マスター | sql.pyのitem_sqlで使用。「dショッピングキーワード検索」モードで「該当商品を確認する」ボタン押下時に商品名(PRODUCT)をキーワード検索し、該当商品一覧を表示・CSVダウンロード可能にする。期間・販売期間でフィルタ | 廃止でdショッピング商品名の候補確認機能が停止。代替VIEWへの移行対応 |
| 29 | Snowcampゼロ次分析（MI部） | pochi-docomo-zero-order-analysis-repository | 🟢 | `VW_HMD_MJCD_INTEGRATION_GENRE_MASTER` | - (1年:201) | - (1年:9.7%) | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | sql.pyのgenre_sqlで使用。「決済統合のジャンル検索」モード選択時にジャンルマスタから大分類・中分類・小分類の選択肢リストを取得し、3つのselectboxに表示。最新世代月のデータを使用 | ★継続提供のため対応不要（2026-03-27確認） |
| 29 | Snowcampゼロ次分析（MI部） | pochi-docomo-zero-order-analysis-repository | 🟢 | `VW_HMD_MJCD_DCARD_MERCHANT_STORE_MASTER` | - (1年:0) | - | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | sql.pyのstore_sqlで使用。「決済統合の利用店舗検索」モードの店舗一覧表示で、dカード加盟店(MERCHANT)・企業名(COMPANY)・屋号(STORENAME_SITE)・店子(STORE_TENANT)をキーワード検索。d払い・dポイント店舗マスタとUNIONして統合表示。1年0件のためコード削除のみ | ★継続提供のため対応不要（2026-03-27確認） |
| 29 | Snowcampゼロ次分析（MI部） | pochi-docomo-zero-order-analysis-repository | 🟢 | `VW_HMD_MJCD_DBARAI_CITY_STORE_MASTER` | - (1年:0) | - | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | sql.pyのstore_sqlで使用。「決済統合の利用店舗検索」モードの店舗一覧表示で、d払い店舗名(STORE)・企業名(COMPANY)・屋号(DCARD_STORENAME_SITE)をキーワード検索。dカード・dポイント店舗マスタとUNIONして統合表示。1年0件のためコード削除のみ | ★継続提供のため対応不要（2026-03-27確認） |
| 29 | Snowcampゼロ次分析（MI部） | pochi-docomo-zero-order-analysis-repository | 🟢 | `VW_HMD_MJCD_DPOINT_STORE_MASTER` | - (1年:0) | - | 継続提供（2026-03-27 CSV更新） | ー | ー（継続提供） | sql.pyのstore_sqlで使用。「決済統合の利用店舗検索」モードの店舗一覧表示で、dポイント加盟店(DPOINT_MERCHANT)・屋号(STORENAME)・店舗名(STORE)をキーワード検索。dカード・d払い店舗マスタとUNIONして統合表示。 | ★継続提供のため対応不要（2026-03-27確認） |

---

## 4. 対応アプリの利用状況一覧（29件）

> **更新日**: 2026-03-27（90日データ追加）

| No | アプリ名 | リポジトリ | アクセス数(1年) | UU数(1年) | アクセス数(90日) | UU数(90日) | アクセス数(30日) | UU数(30日) | 備考 |
|:---:|:--------|:------|-------:|----:|-------:|----:|-------:|----:|:---|
| 1 | 契約状態抽出 | extract-user-by-contract | 6,409 | 558 | 1,615 | 145 | 576 | 68 | |
| 2 | テレマ施策効果確認アプリ | telema-measure-visualization | 3,733 | 91 | 825 | 26 | 263 | 10 | |
| 3 | DSフムフム | docomo-shop-analyzer | 71,528 | 1,312 | 39,827 | 853 | 19,307 | 578 | |
| 4 | 加盟店送客 | kameiten-riyo-yocho | 2,013 | 96 | 444 | 30 | 218 | 13 | |
| 5 | 時系列分析アプリ | timeseries-data-analyzer | 14,468 | 379 | 3,236 | 135 | 1,079 | 60 | |
| 6 | Pochi版StartDash | startdash | 28,212 | 1,568 | 11,079 | 770 | 5,478 | 395 | |
| 7 | ドコモユーザー滞在施設みえる化アプリ | user-behavior-map | 30,348 | 934 | 9,624 | 274 | 2,817 | 98 | |
| 8 | 事業OP九州アプリ | store-area-analysis | 5,805 | 18 | 5,470 | 18 | 1,830 | 10 | |
| 9 | d払いNW見える化 | d-pay-nw-quality-visualizer | 244,958 | 1,402 | 94,998 | 557 | 33,339 | 262 | |
| 10 | 施策リフトツール | promotion-lift-calculator | 14,500 | 55 | 679 | 8 | 341 | 5 | ★意向確認対象候補 |
| 11 | KGI/KPI課題分析・顧客像深掘りアプリ(スマホ総販のみ) | kpi-analyzer | 2,270 | 154 | 482 | 25 | 148 | 11 | |
| 12 | データ活用広告配信向け広告ID変換 | advertisingid-extraction-app | 2,232 | 65 | 861 | 28 | 452 | 18 | |
| 13 | ＜社内向け＞加盟店別d払い明細抽出 | dpay-dpoint-detail-extractor | 3,318 | 120 | 538 | 38 | 143 | 13 | |
| 14 | ロイヤルカスタマー分析 | loyal-customer-analysis | 2,727 | 67 | 838 | 19 | 66 | 8 | |
| 15 | d払い決済状況見える化ツール | d-pay-merchant-visualizer | 721,178 | 1,758 | 195,810 | 582 | 63,603 | 339 | |
| 16 | ＜社内向け＞ID変換器 | id-converter | 52,828 | 709 | 16,648 | 258 | 6,945 | 123 | |
| 17 | 最寄りドコモショップ検索アプリ | nearby-store-finder | 691 | 24 | 135 | 9 | 25 | 3 | ★意向確認対象候補 |
| 18 | お客様の声みえる化アプリ | voc-risk-detector | 83,186 | 3,909 | 8,855 | 591 | 2,436 | 204 | |
| 19 | 開発者ブログ | developers-blog | 4,668 | 327 | 569 | 89 | 164 | 29 | |
| 20 | カスタマージャーニー | customer-journey-visualization | 8,436 | 131 | 441 | 21 | 22 | 2 | |
| 21 | dカードロイヤルカスタマー可視化分析 | loyal-customer-visualizer | 528 | 98 | 87 | 21 | 47 | 16 | |
| 22 | 事業OPRC戦量販アプリ | retail-event-kashika | 716 | 24 | 716 | 24 | 613 | 22 | |
| 23 | 店舗NPSアンケート分析アプリ | nps-analyzer | 21,482 | 601 | 9,954 | 306 | 2,959 | 158 | |
| 24 | 総合ARPU分析 | sogo-arpu-analysis | 2,323 | 241 | 485 | 53 | 233 | 32 | |
| 25 | 来店促進分析 | dpoint-active-raiten | 7,440 | 163 | 1,461 | 31 | 621 | 14 | |
| 26 | 配信対象者抽出 | customer-filtering | 24,766 | 971 | 6,559 | 319 | 2,699 | 173 | |
| 27 | DS代理店/店舗販売状況可視化＆資料化アプリ | branch-sales-visualizer | 12,296 | 447 | 4,233 | 106 | 2,750 | 59 | |
| 28 | 手数料シミュレータアプリ | commission-simulator | 61,963 | 853 | 16,536 | 276 | 6,114 | 93 | |
| 29 | Snowcampゼロ次分析（MI部） | docomo-zero-order-analysis | 1,259 | 68 | 225 | 19 | 145 | 11 | |