# skill-improvement-plan-02: column-query-generator 改修計画

## 概要

MS指摘.md に記録された Skill② column-query-generator の検証フィードバック2件（FB①・FB②）について、
根本原因を分析し、SKILL.md の改修計画をまとめる。

対象スキル: `.claude/skills/column-query-generator/SKILL.md`

---

## ✅ FB① 絞込条件なし時にSkillがユーザーに質問しない

### 症状

絞込条件を渡さずSkillを起動したところ、Q4/Q5/Q6-2がスキップされた（禁止メッセージのみ出力）。
Skillがユーザーに絞込条件を問い返す動作が発生しなかった。

### 根本原因

**「再ヒアリング指示の配置タイミング」と「禁止制約の優先度」の競合**

SKILL.md 87〜103行目には絞込条件未入力時の再ヒアリングテンプレートが記述されているが、
その位置が STEP 2（入力解釈フェーズ）であり、STEP 1（入力収集フェーズ）ではない。

実際の起動フローは以下のとおり：

1. ユーザーが Skill① の引き継ぎMD（column-mapping-result_*.md）のパスを渡す
2. STEP 1: I-1〜I-6 を引き継ぎMDから自動抽出。I-7（絞込条件）は引き継ぎMDに含まれないため省略扱い
3. STEP 2: 「省略時は再ヒアリング」の記述があるが、**実際には実行されず**
4. 113〜135行目の `<constraint id="no-q4-q5-without-filter" severity="high">` が優先され、
   Q4/Q5 禁止メッセージがそのまま出力される

LLMは「高重要度の禁止制約（絞込条件なし時の Q4/Q5 生成禁止）」を、
「省略時は再ヒアリングせよ」という通常の指示よりも優先してしまっている。
再ヒアリングの指示が STEP 2 という後段に置かれているため、禁止制約が先に発火する。

### 修正方針

STEP 1 の完了直後（クエリ生成を開始する前）に絞込条件確認ステップを独立して追加する。

**変更前の構造**:
```
STEP 1: 必須項目（I-1〜I-6）を収集
        推奨項目（I-7〜I-8）は省略可とだけ記述
↓
STEP 2: 「省略された場合 → 再ヒアリング」と記述 ← 実際には発火しない
```

**変更後の構造**:
```
STEP 1: 必須項目（I-1〜I-6）を収集
↓
STEP 1 末尾（新規追加）: 絞込条件確認ステップ
  → 絞込条件あり: そのまま STEP 2 へ進む
  → 絞込条件なし: クエリ生成を開始する前にユーザーへ質問する
      → 条件を入力: 全クエリに適用して STEP 2 へ進む
      → 「不要」: Q1〜Q3・Q6 のみ生成する旨を宣言して STEP 2 へ進む
      → 無回答: プレースホルダーコメントを付与して STEP 2 へ進む
↓
STEP 2: 禁止制約はそのまま維持（安全装置として残す）
```

**SKILL.md への追記箇所**: 73行目（推奨項目ヒアリングテンプレートの `</example>` タグ）の直後

```markdown
**【STEP 1 完了後の絞込条件確認（必須）】**

I-1〜I-6 の情報を受け取ったら、**クエリ生成を開始する前に**、絞込条件（I-7）が
提供されているかを確認する。

- **絞込条件あり**: そのまま STEP 2 へ進む
- **絞込条件なし（省略・未入力）**: 以下の質問をユーザーに出し、回答を待ってから STEP 2 へ進む

```
Q4・Q5（JOIN突合クエリ）を生成するには絞り込み条件が必要です。

対象の絞り込み条件を教えてください（例: SEDAI_MONTH = '2025-12-01'）。

▶ Q4・Q5 が不要な場合は「不要」と入力してください（Q1〜Q3・Q6 のみ生成します）。
```

- 条件を入力された場合: 全クエリ（Q1〜Q6）に適用してから STEP 2 へ進む
- 「不要」と回答された場合: Q4・Q5 を生成しない旨を宣言して STEP 2 へ進む
- 再ヒアリング後も無回答の場合: `-- ← 対象月を入力してください` のプレースホルダーを付与して進む
```

---

## ✅ FB② Q3の複合主キーが先頭列のみのCOUNT DISTINCTになる

### 症状

対象ビューの主キーが `BASCID, CONTRACT_SHISHA_CODE`（複合キー）であるにもかかわらず、
生成されたQ3クエリの `unique_pk_cnt` が `COUNT(DISTINCT BASCID)` 単体になっていた。

```sql
-- 実際に生成されたクエリ（誤）
COUNT(DISTINCT BASCID) AS unique_pk_cnt

-- 正しくあるべきクエリ
COUNT(DISTINCT BASCID || '-' || CONTRACT_SHISHA_CODE) AS unique_pk_cnt
```

### 根本原因

**Q3テンプレートのプレースホルダーが `<主キー先頭列>` のみを指示している**

SKILL.md 342行目のテンプレート:
```sql
COUNT(DISTINCT <主キー先頭列>) AS unique_pk_cnt
```

このプレースホルダー `<主キー先頭列>` という命名が「主キーの先頭列のみを使え」という意図を
LLMに伝えてしまっており、複合主キーが渡された場合でも先頭列だけを使って生成してしまう。

STEP 2（79〜82行目）には「複合主キーの場合は全列で JOIN する」というルールがあり、
Q4/Q5 の JOIN ON 句では複合主キー全列が正しく使われている。しかし Q3 のテンプレートには
同等のルールが存在せず、プレースホルダー名から誤った生成が行われる。

### 影響

複合主キーの場合、`BASCID` 単体の COUNT DISTINCT は「BASCID が同じで CONTRACT_SHISHA_CODE が
異なる行」を重複としてカウントできない。
「主キー重複の有無」を確認するためにQ3に追加された機能が、複合キーで正確に機能しない。

### 修正方針

STEP 2 の「主キーの解釈」セクションに複合主キーの COUNT DISTINCT ルールを追加し、
Q3 テンプレートのプレースホルダーをそのルールを参照する形に修正する。

**変更① STEP 2 への追記箇所**: 82行目（主キーの解釈セクション）の末尾

```markdown
#### 複合主キーの COUNT DISTINCT ルール（Q3 向け）

主キーが複数列の場合、Q3 の `unique_pk_cnt` は **全列を `||` で連結した値** で COUNT DISTINCT する。

| 主キー構成 | COUNT DISTINCT の記述 |
|---|---|
| 単一列（例: BASCID） | `COUNT(DISTINCT BASCID)` |
| 2列複合（例: BASCID, CONTRACT_SHISHA_CODE） | `COUNT(DISTINCT BASCID || '-' || CONTRACT_SHISHA_CODE)` |
| 3列以上 | 同様に `||` で全列を連結する |

連結文字 `'-'` はセパレータ。Snowflake で動作し、全列の組み合わせを一意に識別できる。
```

**変更② Q3テンプレートのプレースホルダー修正箇所**: 342行目

```sql
-- 変更前
COUNT(DISTINCT <主キー先頭列>) AS unique_pk_cnt

-- 変更後
COUNT(DISTINCT <主キーCOUNT DISTINCT式（単一列はその列名、複合は全列を || で連結）>) AS unique_pk_cnt
```

なお 345行目の `AND <主キー先頭列> IS NOT NULL`（NULLフィルタ）は変更しない。
NULL除外フィルタとしての先頭列利用は許容される。

---

## 変更対象ファイルと変更箇所まとめ

| 変更 | 対象ファイル | 対象行 | 内容 |
|---|---|---|---|
| FB①-① | `SKILL.md` | 73行目の後に追記 | STEP 1 完了後の絞込条件確認ステップを新設 |
| FB②-① | `SKILL.md` | 82行目の後に追記 | 複合主キーの COUNT DISTINCT ルールを追加 |
| FB②-② | `SKILL.md` | 342行目を修正 | Q3 テンプレートのプレースホルダー名を変更 |

---

## 変更しない箇所

| 箇所 | 理由 |
|---|---|
| STEP 2 の再ヒアリング記述（87〜103行目） | フォールバックとして残す（削除しない） |
| 禁止制約 `<constraint id="no-q4-q5-without-filter">` | 安全装置として維持 |
| Q1/Q2/Q3-T の `AND <主キー先頭列> IS NOT NULL` | NULLフィルタとして先頭列利用は問題なし |
| Q4/Q5 の JOIN ON 句 | すでに複合主キー全列対応済み（STEP 2 81行目） |

---

## 視覚的な解説

### FB② の問題：なぜ複合主キーで COUNT DISTINCT が壊れるのか

#### 1. データモデルで見る「複合主キー」の構造

```
旧ビュー（VW_DIC_MECD_MEMBER_PROFILE）
┌─────────────────────────────────────────────────────┐
│  BASCID  │ CONTRACT_SHISHA_CODE │  LINE_CONTRACT_FLAG  │
│──────────│──────────────────────│──────────────────────│
│   A001   │        001           │          1           │ ← 主キー① (A001, 001)
│   A001   │        002           │          0           │ ← 主キー② (A001, 002) ※BASCIDは同じ
│   A002   │        001           │          1           │ ← 主キー③ (A002, 001)
└─────────────────────────────────────────────────────┘
主キー = (BASCID, CONTRACT_SHISHA_CODE) の複合キー
→ 3行すべて異なる主キーを持つ「重複なし」の正常データ
```

#### 2. 改修前の Q3：先頭列 BASCID だけで COUNT DISTINCT

```sql
-- 改修前（誤）
COUNT(DISTINCT BASCID) AS unique_pk_cnt
```

```
処理イメージ:
┌─────────┬──────────────────────┬──────────────────────┐
│ BASCID  │ CONTRACT_SHISHA_CODE │    COUNT DISTINCT     │
│  A001   │        001           │                       │
│  A001   │        002           │  → A001 を1件とカウント  │ ← 2行が1件に圧縮される！
│  A002   │        001           │  → A002 を1件とカウント  │
└─────────┴──────────────────────┴──────────────────────┘

結果: unique_pk_cnt = 2  ← 実際は3件なのに2件と誤カウント
      total_cnt     = 3

total_cnt(3) ≠ unique_pk_cnt(2) → 「主キーに重複がある！」と誤判定 ❌
```

#### 3. 改修後の Q3：全列を || 連結して COUNT DISTINCT

```sql
-- 改修後（正）
COUNT(DISTINCT BASCID || '-' || CONTRACT_SHISHA_CODE) AS unique_pk_cnt
```

```
処理イメージ:
┌─────────┬──────────────────────┬─────────────────────────────────┐
│ BASCID  │ CONTRACT_SHISHA_CODE │  連結キー（識別値）               │
│  A001   │        001           │  "A001-001"  → 1件としてカウント  │
│  A001   │        002           │  "A001-002"  → 1件としてカウント  │ ← 別レコードとして識別 ✅
│  A002   │        001           │  "A002-001"  → 1件としてカウント  │
└─────────┴──────────────────────┴─────────────────────────────────┘

結果: unique_pk_cnt = 3  ← 正しく3件とカウント
      total_cnt     = 3

total_cnt(3) = unique_pk_cnt(3) → 「主キー重複なし」と正しく判定 ✅
```

#### 4. 問題の連鎖：なぜ Q3 だけが壊れていたのか

```mermaid
flowchart TD
    A[ユーザーが主キーを入力\n'BASCID, CONTRACT_SHISHA_CODE'] --> B{SKILL.md の指示を\nLLM が解釈}

    B --> C[Q4/Q5 JOIN ON 句]
    B --> D[Q3 COUNT DISTINCT]

    C --> E["STEP 2 に明示ルールあり\n「主キー全列で JOIN する」\n→ ON old.BASCID = new.BASCID\n   AND old.CONTRACT_SHISHA_CODE\n       = new.CONTRACT_SHISHA_CODE"]
    D --> F["テンプレートに '<主キー先頭列>' と記述\n→ LLM が「先頭列だけ使え」と解釈\n→ COUNT(DISTINCT BASCID) を生成"]

    E --> G[Q4/Q5: 複合キー全列 ✅]
    F --> H[Q3: 先頭列のみ ❌]

    style H fill:#ffcccc
    style G fill:#ccffcc
```

#### 5. 改修による修正の波及

```mermaid
flowchart LR
    subgraph 改修前
        P1["テンプレート\nCOUNT(DISTINCT &lt;主キー先頭列&gt;)"]
        P2["ルール\n（Q3向けルールなし）"]
        P1 -->|LLMが解釈| R1["COUNT(DISTINCT BASCID)\n❌ 先頭列のみ"]
    end

    subgraph 改修後
        P3["テンプレート\nCOUNT(DISTINCT &lt;主キーCOUNT DISTINCT式&gt;)"]
        P4["ルール（STEP2に追加）\n単一列 → その列名\n複合列 → 全列を || で連結"]
        P4 -->|参照| P3
        P3 -->|LLMが解釈| R2["単一主キー時:\nCOUNT(DISTINCT BASCID) ✅\n\n複合主キー時:\nCOUNT(DISTINCT BASCID || '-' ||\nCONTRACT_SHISHA_CODE) ✅"]
    end

    style R1 fill:#ffcccc
    style R2 fill:#ccffcc
```

#### 6. 業務上のリスク（改修しなかった場合）

```
カラム置換の判定フロー:

Q3 の結果
  ↓
total_cnt ≠ unique_pk_cnt ？
  ↓ YES（改修前は複合キーで必ず誤ってYESになる）
  ↓
「主キーに重複がある」と誤判定
  ↓
件数差の原因として記録
  ↓
Skill③（column-matching-verifier）が誤った根拠でカラム置換を判定
  ↓
「⚠️ 要確認」または「❌ 不一致」に誤降格 ← 実際は正常なのに！
```

---

## 確認方法

### FB① の確認シナリオ

1. 絞込条件を渡さず Skill② を起動する（Skill① 引き継ぎMDのみ渡す）
2. → Skillが「絞り込み条件を教えてください」と質問することを確認
3. 絞込条件を入力する → Q4/Q5 が生成されることを確認
4. 「不要」と入力する → Q1〜Q3・Q6 のみ生成されることを確認

### FB② の確認シナリオ

1. 複合主キー（例: `BASCID, CONTRACT_SHISHA_CODE`）を指定してSkill②を起動する
2. → Q3クエリの `unique_pk_cnt` が `COUNT(DISTINCT BASCID || '-' || CONTRACT_SHISHA_CODE)` になることを確認
3. 単一主キー（例: `ACCTID`）を指定した場合は `COUNT(DISTINCT ACCTID)` のままであることを確認
