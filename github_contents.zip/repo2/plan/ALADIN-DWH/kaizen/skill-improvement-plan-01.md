# カラムマッピングスキル 改修計画

**作成日**: 2026-04-30  
**更新日**: 2026-05-11（AI-040/AI-041 フェーズ4追加）  
**対象スキル**: column-query-generator / column-mapping-initializer / column-matching-verifier  
**ステータス**: フェーズ4実施中（2026-05-11）

---

## 目次

1. [改修全体マップ](#1-改修全体マップ)
2. [Skill② column-query-generator の改修](#2-skill-column-query-generator-の改修)
3. [Skill① column-mapping-initializer の改修](#3-skill-column-mapping-initializer-の改修)
4. [実施順序・依存関係](#4-実施順序依存関係)
5. [タスクリスト](#5-タスクリスト)
6. [改修前後の成果物 差分チェック・検証・評価観点](#6-改修前後の成果物-差分チェック検証評価観点)

---

## 1. 改修全体マップ

| ID | スキル | 課題 | 深刻度 | 改修区分 | 対象ファイル |
|----|--------|------|:------:|----------|------------|
| C3 | column-query-generator | 2ペア目以降の絞り込み条件バグ | 🔴 | バグ修正 | SKILL.md |
| C1 | column-query-generator | Q1/Q2 一律GROUP BY（連続値・IDで大量結果） | 🔴 | 機能改善 | SKILL.md |
| C2 | column-query-generator | Q4/Q5 の LIMIT が統計的根拠なし | 🔴 | 機能改善 | SKILL.md |
| C5 | column-query-generator | Q4 にJOIN脱落件数が含まれない | 🔴 | 機能改善 | SKILL.md |
| C6 | column-query-generator | Q5 が不一致サンプルのみで全体像不明 | 🔴 | 機能改善 | SKILL.md |
| C4 | column-query-generator | Q3 が総件数差のみでユニーク件数なし | 🟡 | 機能改善 | SKILL.md |
| C7 | column-query-generator | Q6 がJOIN後の情報欠落を検出できない | 🟡 | 機能改善 | SKILL.md |
| C8 | column-query-generator | 単一断面のみ・複数断面の安定性未確認 | 🟡 | ガイド追加 | SKILL.md |
| M1 | column-mapping-initializer | 意味なし候補が同列提案（L4/L5なし） | 🔴 | 機能改善 | SKILL.md |
| M2 | column-mapping-initializer | 同一候補群が複数カラムに繰り返し提案 | 🔴 | 機能改善 | SKILL.md |
| M3 | column-mapping-initializer | CODE_VALUE意味比較が未実装 | 🟡 | 機能改善 | SKILL.md |
| M4 | column-mapping-initializer | 縦横持ち変換がスコープ外で検出不可 | 🔴 | スコープ明示 | SKILL.md |
| C9 | column-query-generator | 絞込条件なしでQ4/Q5の生成を許可（大規模テーブル暴走リスク） | 🔴 | バグ修正 | SKILL.md |
| S1 | column-query-generator | Q4-pre+Q4が2重INNER JOIN（C5+C2統合でLEFT JOIN 1-passに変更） | 🔴 | 設計改善 | SKILL.md |
| S2 | column-matching-verifier | C1〜C7のQ1〜Q6スキーマ変更全体に伴うPattern A自動判定未同期 | 🔴 | 同期必須 | SKILL.md（Skill③） |
| C10 | column-query-generator | Q3が表記ゆれ（末尾スペース等）を考慮しない件数比較 | 🔴 | 機能改善 | SKILL.md |
| S3 | column-matching-verifier | 判定出力が三値のみでスコア数値なし（段階的判断ができない） | 🟡 | 機能改善 | SKILL.md（Skill③） |

---

## 2. Skill② column-query-generator の改修

### 実装形式の確認

column-query-generator は **SKILL.md型**（skill_entry.py なし）。  
LLMがSKILL.mdの指示に従ってクエリを生成する。改修はすべてSKILL.mdの指示変更で対応する。

---

### 改修後の Q1〜Q6 クエリ・実行結果 As-Is / To-Be

#### Q1（旧VIEW分布確認）

**As-Is** — コード値型・ID型・連続値型・日付型すべてに一律GROUP BY集計を適用。

| code_value | cnt | pct |
|---|---:|---:|
| 10000001 | 1 | 0.00 |
| 10000002 | 1 | 0.00 |
| … | … | … |
| （ID型に適用すると数千万行） | | |

**To-Be** — カラム種別を判定し、SQLを切り替える。

コード値型・その他:

| code_value | cnt | pct |
|---|---:|---:|
| 1 | 4,200,000 | 42.00 |
| 2 | 3,800,000 | 38.00 |
| NULL | 2,000,000 | 20.00 |

ID型:

| total_cnt | unique_cnt | unique_pct | null_cnt | null_pct |
|---:|---:|---:|---:|---:|
| 10,000,000 | 9,980,000 | 99.80 | 5,000 | 0.05 |

日付型:

| min_date | max_date | null_cnt | null_pct |
|---|---|---:|---:|
| 2020-01-01 | 2025-12-01 | 1,000 | 0.01 |

連続値型:

| min_val | max_val | avg_val | median_val | p25 | p75 | null_cnt | null_pct |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 9,999,999 | 52,300 | 48,000 | 12,000 | 85,000 | 200 | 0.00 |

---

#### Q2（新VIEW分布確認）

Q1と同一の種別判定・SQLテンプレートを新VIEWに適用。As-Is / To-Beの構造はQ1と同じ。

---

#### Q3（件数比較）

**As-Is** — 総件数のみ。件数差の原因（重複起因か新規追加起因か）が不明。

| view_source | total_cnt |
|---|---:|
| 旧VIEW | 10,000,000 |
| 新VIEW | 10,050,000 |

**To-Be** — 総件数 + 主キーユニーク件数を追加。

| view_source | total_cnt | unique_pk_cnt |
|---|---:|---:|
| 旧VIEW | 10,000,000 | 10,000,000 |
| 新VIEW | 10,050,000 | 9,980,000 |

→ 新VIEWは `total_cnt（10,050,000） ≠ unique_pk_cnt（9,980,000）` → **主キー重複が70,000件存在**と判断できる。

---

#### Q4（一致率確認）

**As-Is** — INNER JOIN でサンプル100件を抽出。JOIN脱落が見えない・旧テーブルを最大3回スキャン。

| old_value | new_value |
|---|---|
| 1 | 1 |
| 2 | 2 |
| … | … |
| （100行） | |

**To-Be** — 絞込条件なしはQ4自体を生成しない（C9）。絞込条件ありはLEFT JOIN 1-pass全件集計で1行返す（S1）。

絞込条件なし → 生成禁止メッセージ:
```
-- ⛔ Q4/Q5 は絞込条件なしでの実行禁止（1億件規模のFULL JOINが発生する危険があります）。
-- 絞込条件（例: WHERE SEDAI_MONTH = '2025-12-01'）を指定した上で再度入力してください。
```

絞込条件あり → 1行の集計結果:

| old_cnt | joined_cnt | dropped_cnt | dropped_pct | matched_cnt | match_pct |
|---:|---:|---:|---:|---:|---:|
| 10,000,000 | 9,850,000 | 150,000 | 1.50 | 9,700,000 | 98.48 |

→ `dropped_pct 1.5% > 1%` → **代替不可の可能性大**。`match_pct`より先に確認する。

---

#### Q5（不一致確認）

**As-Is** — INNER JOIN でサンプル100件を抽出。パターンの規則性・全体割合が不明。

| old_value | new_value |
|---|---|
| 1 | 01 |
| 2 | 02 |
| … | … |
| （100行） | |

**To-Be** — 絞込条件なしはQ5も生成しない（C9）。絞込条件ありはカラム種別で出力を切り替える。

コード値型・文字列型 → 不一致パターン分布:

| old_value | new_value | cnt | pct |
|---|---|---:|---:|
| 1 | 01 | 1,200,000 | 80.00 |
| 2 | 02 | 280,000 | 18.67 |
| 3 | NULL | 20,000 | 1.33 |

→ `旧'1'→新'01'` に規則性あり → **アプリ側変換ルールで対応可能**と判断できる。

連続値型 → 差分統計:

| mismatch_cnt | diff_min | diff_max | diff_avg | diff_median |
|---:|---:|---:|---:|---:|
| 50,000 | -100 | 100 | 0.3 | 0 |

→ 差分がほぼ0に集中 → **丸め誤差の可能性**と判断できる。

---

#### Q6（NULL率確認）

**As-Is** — 旧VIEW・新VIEWの単体NULL率のみ。JOIN後に旧=値あり・新=NULLになるケースが見えない。

| view_source | total_cnt | null_cnt | null_pct |
|---|---:|---:|---:|
| 旧VIEW | 10,000,000 | 50,000 | 0.50 |
| 新VIEW | 10,050,000 | 48,000 | 0.48 |

**To-Be** — Q6-1（単体NULL率・従来通り）+ Q6-2（JOIN後の情報欠落・新規追加）の2クエリ構成。

Q6-1（従来通り）:

| view_source | total_cnt | null_cnt | null_pct |
|---|---:|---:|---:|
| 旧VIEW | 10,000,000 | 50,000 | 0.50 |
| 新VIEW | 10,050,000 | 48,000 | 0.48 |

Q6-2（新規追加）:

| joined_cnt | info_loss_cnt | info_loss_pct |
|---:|---:|---:|
| 9,850,000 | 120,000 | 1.22 |

→ `info_loss_pct 1.22% > 1%` → **移行後にNULLエラー・集計誤差の要注意案件**と判断できる。

---

#### クエリ数の変化まとめ

| クエリ | As-Is | To-Be | 変化 |
|---|---|---|---|
| Q1 | 1クエリ（一律GROUP BY） | 1クエリ（種別で内容切替） | SQL切替 |
| Q2 | 1クエリ（一律GROUP BY） | 1クエリ（種別で内容切替） | SQL切替 |
| Q3 | 1クエリ（総件数のみ） | 1クエリ（総件数+PK重複） | 列追加 |
| Q4 | 1クエリ（INNER JOIN LIMIT 100） | 0または1クエリ（LEFT JOIN全件集計） | SQL置換+生成禁止条件 |
| Q5 | 1クエリ（サンプル抽出 LIMIT 100） | 0または1クエリ（パターン分布・種別切替） | SQL置換+生成禁止条件 |
| Q6 | 1クエリ（単体NULL率） | 2クエリ（Q6-1単体+Q6-2情報欠落） | クエリ追加 |

---

### C3【バグ修正】2ペア目以降の絞り込み条件バグ

#### 原因

SKILL.md の STEP 2「絞り込み条件の解釈」では全クエリへの付与を指示しているが、  
複数ペアを一括生成する際にLLMが1ペア目のみに条件を適用し、2ペア目以降にプレースホルダーが残る。

#### 現状の SKILL.md 記述（問題箇所）

```
- 入力あり: すべてのクエリ（Q1〜Q6）の WHERE 句に付与する
- 省略された場合: WHERE 句に `-- ← 対象月を入力してください` のプレースホルダーコメントを付与する
```

指示が抽象的で「全ペアに」という明示がなく、LLMが1ペア目で処理を完結させてしまう。

#### 修正内容（SKILL.md）

STEP 2「絞り込み条件の解釈」に以下を追記する：

```markdown
#### 【重要】複数ペアの一括生成時の絞り込み条件

複数のカラムペアを一括生成する場合、**すべてのペアのQ1〜Q6に同一の絞り込み条件を適用すること。**

- 1ペア目だけに絞り込み条件を入れ、2ペア目以降にプレースホルダーを残すことは禁止。
- 絞り込み条件は生成開始前に確定し、全ペア・全クエリに機械的に埋め込む。
- 絞り込み条件が省略された場合も同様に、全ペア・全クエリにプレースホルダーを均一に付与する。
```

---

### C1【機能改善】Q1/Q2 カラム種別ごとの出力切り替え

#### 現状の問題

全カラムに対して一律 GROUP BY 集計を適用している。  
連続値・IDカラムでは数千万行の無意味な結果が返り、Claudeに渡せない実害が発生済み。

#### 修正内容（SKILL.md）

STEP 3 の「Q1: 旧ビュー コード値分布」「Q2: 新ビュー コード値分布」を以下に置き換える。

```markdown
#### Q1 / Q2 生成前の種別判定（必須）

クエリ生成前に、旧カラム名と型から以下の4種別を判定し、種別に応じてQ1/Q2のSQLを切り替える。
Q1（旧ビュー）・Q2（新ビュー）は同じ種別ルールを適用する。

| 種別 | 判定条件 | 優先順位 |
|------|----------|:---:|
| **ID型** | カラム名に ID/BASCID/ACCTID/COMNID を含む | 1（最優先） |
| **日付型** | DATE型、またはカラム名に DAY/DATE を含む | 2 |
| **連続値型** | NUMBER(6桁以上)、またはカラム名に AMOUNT/FEE/COUNT/QUANTITY/GB を含む | 3 |
| **コード値型** | VARCHAR(1〜5)、またはカラム名に CODE/FLAG/STATUS/RANK を含む | 4 |
| **その他** | 上記に該当しない場合 | 5（コード値型と同じSQLを使用）|

**【ID型】** Q1/Q2 テンプレート

\`\`\`sql
-- Q1: 旧ビュー ID型カラム 件数・ユニーク率確認
SELECT
    COUNT(*) AS total_cnt,
    COUNT(DISTINCT <旧カラム名>) AS unique_cnt,
    ROUND(COUNT(DISTINCT <旧カラム名>) * 100.0 / COUNT(*), 2) AS unique_pct,
    COUNT(CASE WHEN <旧カラム名> IS NULL THEN 1 END) AS null_cnt,
    ROUND(COUNT(CASE WHEN <旧カラム名> IS NULL THEN 1 END) * 100.0 / COUNT(*), 2) AS null_pct
FROM <旧ビュー名>
WHERE <絞り込み条件>
    AND <主キー先頭列> IS NOT NULL;
\`\`\`

**【日付型】** Q1/Q2 テンプレート

\`\`\`sql
-- Q1: 旧ビュー 日付型カラム 分布確認
SELECT
    MIN(<旧カラム名>) AS min_date,
    MAX(<旧カラム名>) AS max_date,
    COUNT(CASE WHEN <旧カラム名> IS NULL THEN 1 END) AS null_cnt,
    ROUND(COUNT(CASE WHEN <旧カラム名> IS NULL THEN 1 END) * 100.0 / COUNT(*), 2) AS null_pct
FROM <旧ビュー名>
WHERE <絞り込み条件>
    AND <主キー先頭列> IS NOT NULL;
\`\`\`

**【連続値型】** Q1/Q2 テンプレート

\`\`\`sql
-- Q1: 旧ビュー 連続値型カラム 統計量確認
SELECT
    MIN(<旧カラム名>) AS min_val,
    MAX(<旧カラム名>) AS max_val,
    AVG(<旧カラム名>) AS avg_val,
    MEDIAN(<旧カラム名>) AS median_val,
    PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY <旧カラム名>) AS p25,
    PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY <旧カラム名>) AS p75,
    COUNT(CASE WHEN <旧カラム名> IS NULL THEN 1 END) AS null_cnt,
    ROUND(COUNT(CASE WHEN <旧カラム名> IS NULL THEN 1 END) * 100.0 / COUNT(*), 2) AS null_pct
FROM <旧ビュー名>
WHERE <絞り込み条件>
    AND <主キー先頭列> IS NOT NULL;
\`\`\`

**【コード値型・その他】** Q1/Q2 テンプレート（従来通り）

\`\`\`sql
-- Q1: 旧ビュー コード値分布
SELECT
    <旧カラム名> AS code_value,
    COUNT(*) AS cnt,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct
FROM <旧ビュー名>
WHERE <絞り込み条件>
    AND <主キー先頭列> IS NOT NULL
GROUP BY <旧カラム名>
ORDER BY <旧カラム名>;
\`\`\`
```

---

### C2【機能改善】Q4 を全件集計に変更（LIMIT 廃止）

#### 現状の問題

`LIMIT 1000`（現行の SKILL.md では `LIMIT 100`）は1億件規模では統計的根拠がない。  
一致率の全体像が把握できず、代替可否の判断根拠にならない。

#### 修正内容（SKILL.md）—— C5 と統合（S1 対応）

Q4 を「サンプル突合（INNER JOIN）」から「**LEFT JOIN 1-pass 全件集計**」に変更する。  
JOIN 脱落件数（旧 C5 の Q4-pre 相当）と一致率を **1クエリ** で同時に取得する。

```markdown
#### Q4: JOIN脱落件数 + 全件一致率（LEFT JOIN 1-pass）

\`\`\`sql
-- Q4: JOIN脱落件数 + 全件一致率（LEFT JOIN 1-pass）
-- ※ 絞込条件なしでの実行禁止（C9 参照）。1億件超のVIEWでは単一断面に絞ること。
SELECT
    COUNT(*)                                                                          AS old_cnt,
    COUNT(new_v.<主キー先頭列>)                                                        AS joined_cnt,
    COUNT(*) - COUNT(new_v.<主キー先頭列>)                                             AS dropped_cnt,
    ROUND((COUNT(*) - COUNT(new_v.<主キー先頭列>)) * 100.0
          / NULLIF(COUNT(*), 0), 2)                                                   AS dropped_pct,
    COUNT(CASE WHEN new_v.<主キー先頭列> IS NOT NULL
                    AND <一致条件> THEN 1 END)                                         AS matched_cnt,
    ROUND(COUNT(CASE WHEN new_v.<主キー先頭列> IS NOT NULL
                          AND <一致条件> THEN 1 END) * 100.0
          / NULLIF(COUNT(new_v.<主キー先頭列>), 0), 2)                                 AS match_pct
FROM <旧ビュー名> old_v
LEFT JOIN <新ビュー名> new_v
    ON  <主キー全列の等値結合条件>
    AND new_v.<絞り込み条件>
WHERE old_v.<絞り込み条件>
  AND old_v.<主キー先頭列> IS NOT NULL;
\`\`\`

- **`dropped_pct` 1%超 → 代替不可の可能性大**（JOIN 脱落が先決問題）
- `match_pct` は JOIN 成功レコードのみを分母とする点に注意
- 型不一致がある場合は `<一致条件>` を `CAST(new_v.<新候補カラム名> AS VARCHAR) = old_v.<旧カラム名>` とすること
```

---

### C5【機能改善】Q4 に JOIN 脱落件数を追加

#### 現状の問題

Q4 は JOIN できたレコードの一致率しか見ていない。  
JOIN で脱落した件数が多い場合、「一致率99%」が実態を誤魔化す。

#### 修正内容（SKILL.md）—— C2 と統合（S1 対応）

**Q4-pre を独立クエリとして追加する案は廃止。**  
INNER JOIN + サブクエリ方式では旧テーブルを最大3回スキャンする。  
代わりに C2（Q4）を LEFT JOIN に変更し、脱落件数と一致率を **1クエリで同時取得** する（詳細は C2 セクション参照）。

> **判断基準**: `dropped_pct` が 1% 超の場合は代替不可の可能性が高い。Q4 の一致率よりこちらを優先して確認すること。

---

### C6【機能改善】Q5 を不一致パターン分布に変更

#### 現状の問題

`LIMIT 100` で不一致レコードを抽出しても全体像が不明。  
判断に必要なのは「不一致がどのパターンで何件発生しているか」。

#### 修正内容（SKILL.md）

Q5 を「不一致レコード抽出」から「不一致パターン分布集計」に変更する。  
種別に応じて出力形式を切り替える。

```markdown
#### Q5: 不一致パターン分布（カラム種別で切り替え）

**【コード値型・文字列型】** — 旧値→新値の組み合わせ別件数

\`\`\`sql
-- Q5: 不一致パターン分布（コード値型）
SELECT
    old_v.<旧カラム名> AS old_value,
    <新カラム参照> AS new_value,
    COUNT(*) AS cnt,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct
FROM <旧ビュー名> old_v
INNER JOIN <新ビュー名> new_v
    ON <主キー全列の等値結合条件>
WHERE old_v.<絞り込み条件>
    AND new_v.<絞り込み条件>
    AND old_v.<主キー先頭列> IS NOT NULL
    AND (<不一致条件>)
GROUP BY old_v.<旧カラム名>, <新カラム参照>
ORDER BY cnt DESC;
\`\`\`

**【連続値型】** — 差分の統計量

\`\`\`sql
-- Q5: 不一致差分統計（連続値型）
SELECT
    COUNT(*) AS mismatch_cnt,
    MIN(old_v.<旧カラム名> - new_v.<新候補カラム名>) AS diff_min,
    MAX(old_v.<旧カラム名> - new_v.<新候補カラム名>) AS diff_max,
    AVG(old_v.<旧カラム名> - new_v.<新候補カラム名>) AS diff_avg,
    MEDIAN(old_v.<旧カラム名> - new_v.<新候補カラム名>) AS diff_median
FROM <旧ビュー名> old_v
INNER JOIN <新ビュー名> new_v
    ON <主キー全列の等値結合条件>
WHERE old_v.<絞り込み条件>
    AND new_v.<絞り込み条件>
    AND old_v.<主キー先頭列> IS NOT NULL
    AND (<不一致条件>);
\`\`\`

> **判断指針**: パターンに規則性がある（例: 旧=`'1'` → 新=`1` に統一）場合はアプリ側の変換ルールで対応可能。ランダムな場合は代替困難と判断する。
```

---

### C4【機能改善】Q3 にユニーク件数を追加

#### 修正内容（SKILL.md）

```markdown
#### Q3: 件数比較（総件数 + 主キーユニーク件数）

\`\`\`sql
-- Q3: 件数比較（同条件）
SELECT
    '旧VIEW' AS view_source,
    COUNT(*) AS total_cnt,
    COUNT(DISTINCT <主キー先頭列>) AS unique_pk_cnt
FROM <旧ビュー名>
WHERE <絞り込み条件>
    AND <主キー先頭列> IS NOT NULL
UNION ALL
SELECT
    '新VIEW',
    COUNT(*),
    COUNT(DISTINCT <主キー先頭列>)
FROM <新ビュー名>
WHERE <絞り込み条件>
    AND <主キー先頭列> IS NOT NULL;
\`\`\`

> `total_cnt ≠ unique_pk_cnt` の場合、主キーに重複が存在する。旧新で重複件数が異なる場合は件数差の原因として記録すること。
```

---

### C7【機能改善】Q6 に JOIN 後の情報欠落検出を追加

#### 修正内容（SKILL.md）

```markdown
#### Q6: NULL件数確認（単体 + JOIN後の情報欠落）

\`\`\`sql
-- Q6-1: 単体NULL率（従来通り）
SELECT
    '旧VIEW' AS view_source,
    COUNT(*) AS total_cnt,
    COUNT(CASE WHEN <旧カラム名> IS NULL THEN 1 END) AS null_cnt,
    ROUND(COUNT(CASE WHEN <旧カラム名> IS NULL THEN 1 END) * 100.0 / COUNT(*), 2) AS null_pct
FROM <旧ビュー名>
WHERE <絞り込み条件> AND <主キー先頭列> IS NOT NULL
UNION ALL
SELECT '新VIEW', COUNT(*),
    COUNT(CASE WHEN <新候補カラム名> IS NULL THEN 1 END),
    ROUND(COUNT(CASE WHEN <新候補カラム名> IS NULL THEN 1 END) * 100.0 / COUNT(*), 2)
FROM <新ビュー名>
WHERE <絞り込み条件> AND <主キー先頭列> IS NOT NULL;

-- Q6-2: JOIN後の情報欠落確認（移行後に旧=値あり・新=NULLになるレコード）
SELECT
    COUNT(*) AS joined_cnt,
    COUNT(CASE WHEN old_v.<旧カラム名> IS NOT NULL AND new_v.<新候補カラム名> IS NULL THEN 1 END) AS info_loss_cnt,
    ROUND(
        COUNT(CASE WHEN old_v.<旧カラム名> IS NOT NULL AND new_v.<新候補カラム名> IS NULL THEN 1 END) * 100.0
        / NULLIF(COUNT(*), 0),
        2
    ) AS info_loss_pct
FROM <旧ビュー名> old_v
INNER JOIN <新ビュー名> new_v
    ON <主キー全列の等値結合条件>
WHERE old_v.<絞り込み条件> AND new_v.<絞り込み条件>
    AND old_v.<主キー先頭列> IS NOT NULL;
\`\`\`

> **判断基準**: `info_loss_pct` が 0% より大きい場合、移行後にアプリのNULLエラー・集計誤差の原因になる可能性がある。1%超は要注意。
```

---

### C8【ガイド追加】複数断面の安定性確認

SKILL.md の「次のアクション案内（STEP 5）」に以下を追記する。

```markdown
**【複数断面での安定性確認】**  
Q1/Q2 の分布確認は単一断面（1ヶ月分）のみでは不十分な場合があります。  
月によって分布が変動するVIEWでは、直近3〜6ヶ月の複数断面で繰り返し実行し、  
全断面で分布が安定していることを確認してください。
```

---

### C9【バグ修正】絞込条件なしでの Q4/Q5 生成を禁止

#### 現状の問題

SKILL.md は絞込条件省略時にプレースホルダーコメントを付与するだけで、Q4/Q5 の生成自体は許可している。  
絞込条件なしで Q4/Q5 を実行すると **1億件 × 1億件の FULL JOIN** が発生し、コスト暴走または Snowflake タイムアウトになる。  
現状のコメント `-- ※ 絞り込み条件を必ず設定してください` は実害を防げていない。

#### 修正内容（SKILL.md の STEP 2「絞り込み条件の解釈」に追記）

```markdown
#### 【重要】絞込条件なし時の Q4/Q5 生成禁止

絞込条件（例: `SEDAI_MONTH = '2025-12-01'`）が **一切提供されていない場合**、  
Q4・Q5 は **生成してはならない**。代わりに以下のメッセージをその場所に出力すること。

```
-- ⛔ Q4/Q5 は絞込条件なしでの実行禁止（1億件規模のFULL JOINが発生する危険があります）。
-- 絞込条件（例: WHERE SEDAI_MONTH = '2025-12-01'）を指定した上で再度入力してください。
```

Q1・Q2・Q3・Q6 は絞込条件なしでも生成して良い（集計クエリのため相対的にコストが低い）。  
Q4・Q5 のみが禁止対象。
```

---

## 3. Skill① column-mapping-initializer の改修

### 実装形式の確認

column-mapping-initializer は **SKILL.md型**（skill_entry.py は残存するが、スキル実行は SKILL.md の LLM 指示で行う）。  
M1〜M4 の改修はすべて **SKILL.md への指示追加** で対応する。

---

### M1/M2【機能改善】LLM による L4 意味類似判定の追加

#### 現状の問題

SKILL.md の実行後フロー（STEP 3）で LLM が L1〜L3 候補を受け取り、  
ビジネス意味を一切考慮しないため意味的に無関係な候補が同列提案される。

#### 修正方針

SKILL.md の STEP 3 に以下のフィルタリング指示を追加する。

**① L2 候補の事前フィルタリング強化**

現状は `l2_score >= 1`（共通トークン1個以上）で候補を生成しているため、  
`CODE` や `FLAG` など汎用トークンのみの一致を実質的な候補として出してしまう。

```python
# 修正前（現状）
if l2 == 0:
    continue

# 修正後
if l2 == 0:
    continue

# 旧カラムのトークン数に対して共通トークン比率が低すぎる候補を除外
total_old = len(old_tokens)
ratio = l2 / total_old if total_old > 0 else 0

# 共通トークンが汎用語のみの場合は ratio に関わらず除外
# （例: PRESUMPTION_GENDER_CODE→NENDAI_CODE は共通={CODE} のみ、ratio=0.33 でも除外すべき）
GENERIC_TOKENS = {"CODE", "FLAG", "STATUS", "RANK", "DATE", "DAY", "ID", "FLG", "TYPE"}
common = old_tokens & new_tokens
if common and common.issubset(GENERIC_TOKENS):
    continue  # 汎用語のみの一致は ratio に関わらず候補に含めない
```

**② 候補なしの場合の明示的出力**

フィルタリング強化により候補が0件になるケースが増えるため、  
`missing` リストに入れる前に「候補なし（意味的一致なし）」を明示する。

```python
# build_markdown() の非存在カラムセクションで分類を追加
# 「新ビューに類似なし」と「候補はあるが意味的に判断不可」を分ける
```

**③ SKILL.md への追記（LLM補完ステップの明示）**

SKILL.md の STEP 3 に以下を追加する。

```markdown
#### STEP 3-b: 確信度「低」候補の LLM 補完判定（任意）

`skill_entry.py` の出力で確信度「低」の候補が多い場合、以下の情報を参照して  
LLM（Claude）がビジネス意味の類似を補完判定する。

**参照情報（あれば）**:
- Alation CSV の `DESCRIPTION` 列（カラムの説明文）
- Alation CSV の `CODE_VALUE` 列（コード値の意味定義）

**補完判定の出力形式**:

| 旧カラム名 | 旧カラムの意味 | 候補カラム名 | 候補の意味 | 意味類似判定 | 判定根拠 |
|-----------|--------------|------------|----------|:---:|---------|
| PRESUMPTION_GENDER_CODE | 推定性別コード | GENDER_CODE | 性別コード | ✅ 一致 | ビジネス意味が同一 |
| PRESUMPTION_GENDER_CODE | 推定性別コード | NENDAI_CODE | 年代コード | ❌ 不一致 | 年代と性別は別概念 |

**注意**: この補完判定は skill_entry.py が出力した L2 スコア順の候補を「絞り込む」ためのものであり、  
新たな候補を生成するものではない。
```

---

### M3【機能改善】CODE_VALUE 意味比較の追加

#### 現状の問題

`load_columns()` で `code_value` フィールドを読み込んでいるが、`map_columns()` では一切使用されていない。  
AlationCSV の `CODE_VALUE` 列には `0:同意しない<br>1:同意する` 形式で意味定義が存在する。

#### 修正内容（SKILL.md への指示追加）

`build_markdown()` の警告セクションに CODE_VALUE 突合結果を出力する処理を追加する。

```python
def compare_code_values(old_col: dict, new_col: dict) -> str:
    """
    旧新カラムの CODE_VALUE を比較し、警告メッセージを返す。
    CODE_VALUE 形式: "0:ラベル0<br>1:ラベル1" を想定。
    """
    old_cv = old_col.get("code_value", "").strip()
    new_cv = new_col.get("code_value", "").strip()

    if not old_cv and not new_cv:
        return ""  # 両方未登録：スキップ

    if not old_cv or not new_cv:
        return "⚠️ CODE_VALUE: 片方のみ登録あり（要目視確認）"

    # "<br>" で分割してコード値辞書を構築
    def parse_cv(cv_str: str) -> dict:
        result = {}
        for item in cv_str.replace("<br>", "\n").split("\n"):
            item = item.strip()
            if ":" in item:
                k, v = item.split(":", 1)
                result[k.strip()] = v.strip()
        return result

    old_dict = parse_cv(old_cv)
    new_dict = parse_cv(new_cv)

    if old_dict == new_dict:
        return ""  # 完全一致：警告不要

    # 差分を検出
    old_keys = set(old_dict.keys())
    new_keys = set(new_dict.keys())
    added = new_keys - old_keys
    removed = old_keys - new_keys
    changed = {k for k in old_keys & new_keys if old_dict[k] != new_dict[k]}

    warnings = []
    if removed:
        warnings.append(f"⚠️ CODE_VALUE: 旧にあって新にないコード={removed}")
    if added:
        warnings.append(f"⚠️ CODE_VALUE: 新に追加されたコード={added}")
    if changed:
        warnings.append(f"⚠️ CODE_VALUE: 意味が変わったコード={changed}")

    return " / ".join(warnings) if warnings else ""
```

SKILL.md の出力フォーマット指示に CODE_VALUE 突合ロジックの説明を追加し、LLM が旧新カラムの CODE_VALUE を比較して警告を付与するよう指示する。  
（以下のロジックは参考例。実装は SKILL.md の指示として記述する。）

---

### M4【スコープ明示】縦横持ち変換の検出と案内

#### 修正内容（SKILL.md の Don't セクションに追記）

```markdown
#### 縦横持ち変換（横持ち→縦持ち）が発生するケース

旧VIEWが横持ち（例: 595サービスを横列で保持）から新VIEWが縦持ちに変わっているケースは、  
本スキルのスコープ外です。単純なカラム置き換えでは対応できません。

このケースが疑われる場合（カラム名に連番が含まれる場合など）は、  
担当者への確認および Snowflake の PIVOT/UNPIVOT を使ったSQL変換を検討してください。

本スキルの出力では、横持ち構造を示唆するカラム名（例: `SERVICE_001`, `SERVICE_002` ...）を  
検出した場合に「⚠️ 縦横持ち変換の可能性あり（スコープ外）」を警告として付与します。
```

SKILL.md の入力チェック指示として連番カラム検出ロジックを追加する。

```python
import re

def detect_numbered_columns(old_cols: list[dict]) -> list[str]:
    """連番パターンを持つカラム名を検出する（縦横持ち変換の可能性を示唆）。"""
    pattern = re.compile(r'_\d{2,}$')  # 末尾に2桁以上の数字
    return [c["name"] for c in old_cols if pattern.search(c["name"])]
```

`build_markdown()` でこれらのカラムに警告行を追加する。

---

## 4. 実施順序・依存関係

### フェーズ定義

```
フェーズ1（即時対応）: 実害が出ているバグ・最優先機能改善
フェーズ2（近期対応）: 精度向上・判断根拠強化
フェーズ3（中長期）  : 設計改善・LLM補完の整備
```

### 実施順序

```
フェーズ1（実施者: RS）
  ├─ C3:   column-query-generator SKILL.md → 絞り込み条件バグ修正
  ├─ C9:   column-query-generator SKILL.md → Q4/Q5 絞込条件なし時の生成禁止 ★新規
  └─ C1:   column-query-generator SKILL.md → Q1/Q2 種別判定切り替え

フェーズ2（実施者: RS or チーム）
  ├─ S1:   column-query-generator SKILL.md → C5+C2 統合: Q4 を LEFT JOIN 1-pass に変更 ★新規
  │         └ C5 (Q4-pre) と C2 (Q4 INNER JOIN) を同時に置き換える
  ├─ S2:   column-matching-verifier SKILL.md → Q1〜Q6 全体の出力スキーマ変更に伴う Pattern A 同期 ★更新
  │         └ S1 完了後に必ず実施（S1 と同一スプリントで対応必須）
  ├─ C6:   column-query-generator SKILL.md → Q5 パターン分布化
  ├─ C7:   column-query-generator SKILL.md → Q6-2 情報欠落クエリ追加
  ├─ C4:   column-query-generator SKILL.md → Q3 ユニーク件数追加
  └─ C8:   column-query-generator SKILL.md → 複数断面ガイド追記

フェーズ3（実施者: チーム・要設計合意）
  ├─ M1/M2: column-mapping-initializer SKILL.md → 汎用語フィルタ指示 + LLM補完ステップ追加
  ├─ M3:   column-mapping-initializer SKILL.md → CODE_VALUE突合指示追加
  └─ M4:   column-mapping-initializer SKILL.md → 縦横変換検出指示追加
```

### 依存関係

```
C3（バグ修正）  ←── 独立。最初に実施
C9（Q4/Q5禁止）←── 独立。C3 と並行実施可 ★新規
C1（種別判定）  ←── 独立。C3 と並行実施可
S1（LEFT JOIN） ←── C3 + C9 完了後に実施（C5 と C2 を同時に置き換える） ★新規
S2（Skill③同期）←── S1 完了と同一スプリント必須。S1 のスキーマ変更後は Skill③ が壊れる ★新規
C6 / C7 / C4 / C8 ←── C3 完了後に実施（S1 完了後が望ましい）
M1/M2（SKILL.md）←── 独立。フェーズ2 と並行実施可
M3（SKILL.md）   ←── M1/M2 の後（L2フィルタ指示が整ってから CODE_VALUE 判定を追加する方が自然）
M4（SKILL.md）   ←── 独立。M1/M2 と並行実施可
```

### 工数見積もり（SKILL.md 編集基準）

| フェーズ | 課題 | 工数目安 |
|---------|------|---------|
| フェーズ1 | C3 バグ修正 | 0.5h |
| フェーズ1 | C9 Q4/Q5 生成禁止 ★新規 | 0.5h |
| フェーズ1 | C1 Q1/Q2 切り替え | 1.5h |
| フェーズ2 | S1 C5+C2 LEFT JOIN統合 ★新規 | 1h |
| フェーズ2 | S2 Skill③ Pattern A 同期（Q1〜Q6全体） ★更新 | 2h |
| フェーズ2 | C4/C6/C7 クエリ改善 | 各 0.5〜1h |
| フェーズ2 | C8 ガイド追記 | 0.25h |
| フェーズ3 | M1/M2 SKILL.md（汎用語フィルタ + LLM補完指示） | 2h |
| フェーズ3 | M3 CODE_VALUE突合 | 1.5h |
| フェーズ3 | M4 縦横変換検出 | 1h |

---

## 付録：判断スコープ外の課題（現行3スキルでは対処不可）

以下は現行スキルの改修範囲外であり、別途対応方針を決定する必要がある。

| 課題 | 内容 | 必要な対応 |
|------|------|-----------|
| ビュー定義差異 | CREATE VIEW文のSQL定義差分は Q1〜Q6 で検出不可 | 別途 DBA または Alation での CREATE VIEW 差分確認 |
| アプリ参照方法 | WHERE/GROUP BY での用途によって許容誤差が異なる | アプリコードレビューのプロセスを別途設ける |
| Skill③ CODE_VALUE 自動連携 | 現状は手動入力。自動連携の仕組みが未整備 | Skill①の出力を Skill③ に自動渡しするパイプライン設計 |
| **【S2・Skill③出力スキーマ同期】** | C1〜C7 による Q1〜Q6 全体の出力スキーマ変更に伴い、Skill③ Pattern A のヘッダー自動判定が旧スキーマにハードコードされており全クエリが壊れる（Q4/Q5は判定ロジック全体の書き換えが必要。Q1/Q2/Q3/Q6はヘッダー文字列の修正＋Q6-2の判定基準追加が必要） | **フェーズ2 S2 として本計画の対応範囲に昇格**。S1 と同一スプリントで Skill③ SKILL.md の Q1〜Q6 ヘッダー定義・判定ロジックをすべて更新すること |
| 全件 INNER JOIN のコスト | 1億件超ビューの全件 JOIN は実行コスト大 | SEDAI_MONTH 単一断面への絞り込みを強制する設計 |

---

## 5. タスクリスト

実施順序・依存関係に基づくタスク一覧。完了したら `[x]` にチェックを入れる。

---

### フェーズ1（即時対応）— 実施者: RS

- [x] **T1-1** `C3` column-query-generator SKILL.md の「絞り込み条件の解釈」セクションに複数ペア均一適用の指示を追記する
  - 検証: 2ペア以上を一括生成し、全ペアのQ1〜Q6に同一条件が入っていることを確認
- [x] **T1-2** `C9` column-query-generator SKILL.md の STEP 2 に絞込条件なし時のQ4/Q5生成禁止ルールを追記する
  - 検証: 絞込条件なしで依頼し、Q4/Q5に禁止メッセージが出力され、Q1〜Q3/Q6は通常生成されることを確認
- [x] **T1-3** `C1` column-query-generator SKILL.md のSTEP 3 を Q1/Q2 種別判定（ID型・日付型・連続値型・コード値型）切り替えに書き換える
  - 検証: 各種別のカラムでQ1を生成し、対応するテンプレート（列構成）が使われることを確認

> フェーズ1の3タスクは互いに独立しており並行実施可。合計工数目安: **2.5h**

---

### フェーズ2（近期対応）— 実施者: RS or チーム

- [x] **T2-1** `S1` column-query-generator SKILL.md のQ4をINNER JOIN + LIMIT構成からLEFT JOIN 1-pass全件集計に書き換える（C2・C5を同時に置き換え）
  - 依存: T1-1（C3）・T1-2（C9）完了後
  - 検証: 生成されたQ4がLEFT JOIN構成で `dropped_cnt/dropped_pct/matched_cnt/match_pct` を含む1クエリになっていることを確認
- [x] **T2-2** `S2` column-matching-verifier SKILL.md のPattern AのCSVヘッダー自動判定をQ1〜Q6全体の新スキーマに同期させる
  - 依存: T2-1（S1）完了後・**T2-1と同一スプリントで必須**
  - 検証: 各QのCSV（新ヘッダー）をPattern Aで渡し、Q番号が正しく認識され判定処理が走ることを確認
- [x] **T2-3** `C6` column-query-generator SKILL.md のQ5をサンプル抽出（LIMIT 100）から不一致パターン分布集計（コード値型・連続値型で切り替え）に書き換える
  - 依存: T1-1（C3）完了後（T2-1完了後が望ましい）
  - 検証: コード値型で `cnt/pct` 付き分布、連続値型で差分統計量が返るQ5が生成されることを確認
- [x] **T2-4** `C7` column-query-generator SKILL.md のQ6にQ6-2（JOIN後の情報欠落検出クエリ）を追加する
  - 依存: T1-1（C3）完了後（T2-1完了後が望ましい）
  - 検証: 生成されたQ6が `-- Q6-1` / `-- Q6-2` の2クエリ構成で、Q6-2に `info_loss_cnt/info_loss_pct` が含まれることを確認
- [x] **T2-5** `C4` column-query-generator SKILL.md のQ3に `COUNT(DISTINCT 主キー)` を追加する
  - 依存: T1-1（C3）完了後
  - 検証: 生成されたQ3のUNION ALL両方に `unique_pk_cnt` が含まれることを確認
- [x] **T2-6** `C8` column-query-generator SKILL.md のSTEP 5「次のアクション案内」に複数断面での安定性確認ガイドを追記する
  - 依存: なし（独立）
  - 検証: STEP 5の出力に複数断面確認の案内が含まれることを確認

> T2-1とT2-2は同一スプリントで必ず実施。合計工数目安: **6.25h**

---

### フェーズ3（中長期）— 実施者: チーム・要設計合意

- [x] **T3-1** `M1/M2` column-mapping-initializer SKILL.md のSTEP 3 に汎用語フィルタ（GENERIC_TOKENS除外）指示とSTEP 3-b（LLM補完判定）を追加する
  - 依存: なし（独立。フェーズ2と並行実施可）
  - 検証: 汎用語のみ一致する候補（例: `NENDAI_CODE → PRESUMPTION_GENDER_CODE`）が除外され、Alation DESCRIPTIONを参照した補完判定テーブルが出力されることを確認
- [x] **T3-2** `M3` column-mapping-initializer SKILL.md の出力フォーマット指示にCODE_VALUE突合ロジックを追加する
  - 依存: T3-1（M1/M2）完了後
  - 検証: 旧新カラムのCODE_VALUEに差分がある場合に `⚠️ CODE_VALUE:` 警告が付与されることを確認
- [x] **T3-3** `M4` column-mapping-initializer SKILL.md の入力チェック指示に連番カラム検出ロジックを追加し、Dontセクションに縦横持ち変換スコープ外の警告を追記する
  - 依存: なし（T3-1と並行実施可）
  - 検証: 末尾に2桁以上の連番を持つカラム（例: `SERVICE_001`）を含む入力に対し `⚠️ 縦横持ち変換の可能性あり（スコープ外）` が出力されることを確認

> 合計工数目安: **4.5h**

---

### フェーズ4（実運用フィードバック）— 発生元: 2026-04-22 スキル確認ミーティング（さとみつ氏）

- [x] **T4-1** `C10` column-query-generator SKILL.md のQ3の直後に Q3-T（TRIM適用版件数比較）テンプレートを追加する
  - 発生背景: 都道府県コードの検証で約2000件の件数差が発生。原因は末尾の全角スペース混入によるNULL判定のカウント不一致（AI-040）
  - 依存: なし（独立）
  - 検証: コード値型カラムペアを指定した場合にQ3直後にQ3-Tが生成され、ID型・日付型では生成されないことを確認
- [x] **T4-2** `S3` column-matching-verifier SKILL.md の「総合判定の決定」セクションにスコア計算ロジック（5指標・100点満点）を追加し、出力フォーマットを「三値 + スコア数値併記」に変更する
  - 発生背景: さとみつ氏より「❌だと別カラム探しに移ってしまう。スコア数値なら段階的判断ができる」との提案（AI-041）
  - 依存: なし（独立）
  - 検証: Q3〜Q6の結果を貼り付けた際にスコア数値が総合判定に併記され、各Q根拠詳細にも指標ごとの点数が表示されることを確認

> 合計工数目安: **2.5h**

---

### タスク全体サマリー

| タスクID | 課題 | フェーズ | 依存 | 工数目安 | ステータス |
|---|---|:---:|---|---:|---|
| T1-1 | C3 絞り込み条件バグ修正 | 1 | なし | 0.5h | ✅ 完了（2026-05-01） |
| T1-2 | C9 Q4/Q5 生成禁止 | 1 | なし | 0.5h | ✅ 完了（2026-05-01） |
| T1-3 | C1 Q1/Q2 種別判定切り替え | 1 | なし | 1.5h | ✅ 完了（2026-05-01） |
| T2-1 | S1 Q4 LEFT JOIN 1-pass化 | 2 | T1-1・T1-2 | 1h | ✅ 完了（2026-05-01） |
| T2-2 | S2 Skill③ Pattern A 全体同期 | 2 | T2-1（同スプリント必須） | 2h | ✅ 完了（2026-05-01） |
| T2-3 | C6 Q5 パターン分布化 | 2 | T1-1 | 1h | ✅ 完了（2026-05-01） |
| T2-4 | C7 Q6-2 情報欠落クエリ追加 | 2 | T1-1 | 0.5h | ✅ 完了（2026-05-01） |
| T2-5 | C4 Q3 ユニーク件数追加 | 2 | T1-1 | 0.5h | ✅ 完了（2026-05-01） |
| T2-6 | C8 複数断面ガイド追記 | 2 | なし | 0.25h | ✅ 完了（2026-05-01） |
| T3-1 | M1/M2 汎用語フィルタ + LLM補完指示 | 3 | なし | 2h | ✅ 完了（2026-05-01） |
| T3-2 | M3 CODE_VALUE突合指示 | 3 | T3-1 | 1.5h | ✅ 完了（2026-05-01） |
| T3-3 | M4 縦横変換検出指示 | 3 | なし | 1h | ✅ 完了（2026-05-01） |
| T4-1 | C10 Q3-T（TRIM版）テンプレート追加 | 4 | なし | 1h | ✅ 完了（2026-05-11） |
| T4-2 | S3 スコア計算ロジック・出力フォーマット変更 | 4 | なし | 1.5h | ✅ 完了（2026-05-11） |

**合計工数目安: 16.25h**

---

## 6. 改修前後の成果物 差分チェック・検証・評価観点

改修後のSkill②（column-query-generator）・Skill③（column-matching-verifier）が正しく動作しているかを確認するための観点。
改修ごとに対応するチェック項目を実施すること。

---

### Skill②（column-query-generator）の検証

#### C3 バグ修正検証（2ペア目以降の絞り込み条件）

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | 2ペア以上を一括生成し、全ペアのQ1〜Q6に同一の絞り込み条件が入っているか | 2ペア目以降にプレースホルダー（`-- ← 対象月を入力してください`）が残っていない |
| 2 | 絞り込み条件を省略して2ペア以上を一括生成し、全ペアに均一にプレースホルダーが付与されるか | 1ペア目のみプレースホルダー・2ペア目以降が空白になっていない |

#### C1 機能改善検証（Q1/Q2 種別判定切り替え）

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | カラム名に `ID` を含むカラムでQ1を生成し、ID型テンプレートが使われるか | `total_cnt / unique_cnt / unique_pct / null_cnt / null_pct` の5列SELECT文が生成される |
| 2 | DATE型カラムでQ1を生成し、日付型テンプレートが使われるか | `min_date / max_date / null_cnt / null_pct` の4列SELECT文が生成される |
| 3 | カラム名に `AMOUNT` を含むカラムでQ1を生成し、連続値型テンプレートが使われるか | `min_val / max_val / avg_val / median_val / p25 / p75 / null_cnt / null_pct` の8列SELECT文が生成される |
| 4 | VARCHAR(3)のコード値カラムでQ1を生成し、コード値型テンプレートが使われるか | `GROUP BY` を含むSELECT文が生成される |
| 5 | Q1とQ2が同じ種別ルールで生成されるか | Q1が連続値型ならQ2も連続値型テンプレートが使われる |

#### C9 バグ修正検証（絞込条件なしのQ4/Q5生成禁止）

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | 絞込条件なしでQ4を含むクエリ生成を依頼した場合、Q4が生成されないか | `⛔ Q4/Q5 は絞込条件なしでの実行禁止` メッセージが出力される |
| 2 | 絞込条件なしでQ5を含むクエリ生成を依頼した場合、Q5が生成されないか | 同上 |
| 3 | 絞込条件なしでもQ1/Q2/Q3/Q6は生成されるか | Q4/Q5のみ禁止。Q1〜Q3・Q6は通常生成される |

#### S1 設計改善検証（Q4 LEFT JOIN 1-pass化）

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | 生成されたQ4に `LEFT JOIN` が使われているか | `INNER JOIN` が使われていない |
| 2 | Q4の出力列に `dropped_cnt / dropped_pct` が含まれるか | JOIN脱落件数が1クエリで取得できる構造になっている |
| 3 | Q4の出力列に `matched_cnt / match_pct` が含まれるか | 一致率が1クエリで取得できる構造になっている |
| 4 | Q4が1クエリで完結しているか（旧Q4-preが独立クエリとして残っていないか） | `-- Q4-pre` のようなサブクエリが独立して生成されていない |

#### C6 機能改善検証（Q5 不一致パターン分布化）

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | コード値型カラムのQ5に `GROUP BY` と `cnt / pct` が含まれるか | 件数・割合の集計結果が返る構造になっている |
| 2 | 連続値型カラムのQ5に `diff_min / diff_max / diff_avg / diff_median` が含まれるか | 差分統計量が返る構造になっている |
| 3 | `LIMIT` が含まれていないか | Q5にLIMITが残存していない |

#### C4 機能改善検証（Q3 ユニーク件数追加）

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | 生成されたQ3に `unique_pk_cnt` が含まれるか | `COUNT(DISTINCT <主キー>)` が UNION ALL の両方に含まれている |

#### C7 機能改善検証（Q6-2 情報欠落検出追加）

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | Q6が2クエリ構成（Q6-1 + Q6-2）で生成されるか | `-- Q6-1` と `-- Q6-2` の両コメントが含まれる |
| 2 | Q6-2に `info_loss_cnt / info_loss_pct` が含まれるか | JOIN後の情報欠落を集計する構造になっている |

---

### Skill③（column-matching-verifier）の検証（S2対応後）

#### Q1/Q2 ヘッダー判定検証

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | ID型Q1のCSV（`total_cnt,unique_cnt,...`）をPattern Aで渡した場合にQ1として認識されるか | 「Q1（旧ビュー ID型）」として判定処理が走る |
| 2 | 日付型Q1のCSV（`min_date,max_date,...`）をPattern Aで渡した場合にQ1として認識されるか | 「Q1（旧ビュー 日付型）」として判定処理が走る |
| 3 | 連続値型Q1のCSV（`min_val,max_val,...`）をPattern Aで渡した場合にQ1として認識されるか | 「Q1（旧ビュー 連続値型）」として判定処理が走る |
| 4 | コード値型Q1のCSV（`code_value,cnt,pct`）は引き続き認識されるか | 旧来のヘッダー形式も引き続き動作する（後方互換） |

#### Q3 ヘッダー判定・判定ロジック検証

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | `view_source,total_cnt,unique_pk_cnt` のCSVをPattern Aで渡した場合にQ3として認識されるか | Q3の件数比較処理が走る |
| 2 | `total_cnt ≠ unique_pk_cnt` の場合に「主キー重複あり」として記録されるか | 判定レポートに主キー重複の旨が明記される |

#### Q4 判定ロジック検証

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | `old_cnt,joined_cnt,dropped_cnt,dropped_pct,matched_cnt,match_pct` のCSVをPattern Aで渡した場合にQ4として認識されるか | Q4の一致率判定処理が走る |
| 2 | `dropped_pct` が1%超の場合に「代替不可の可能性大」として記録されるか | 判定レポートに `dropped_pct` を根拠とした ❌ または ⚠️ が付与される |
| 3 | `dropped_pct` が0%でも `match_pct` が低い場合に不一致として記録されるか | 二段階判定が正しく機能している |

#### Q5 判定ロジック検証

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | `old_value,new_value,cnt,pct` のCSVをPattern Aで渡した場合にQ5として認識されるか | Q5の不一致パターン分析処理が走る |
| 2 | 不一致パターンに規則性がある場合（例: 旧`'1'`→新`'01'`が80%）に「⚠️ 要確認（変換ルール提案）」と判定されるか | 規則性ありの判定ロジックが機能している |
| 3 | 連続値型の差分統計（`mismatch_cnt,diff_min,...`）をQ5として渡した場合に正しく判定されるか | diff_avg・diff_medianが0に近い場合に「丸め誤差の可能性」が記録される |

#### Q6 ヘッダー判定・Q6-2判定ロジック検証

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | Q6-1の`view_source,total_cnt,null_cnt,null_pct`のCSVがQ6として認識されるか | Q6のNULL率比較処理が走る |
| 2 | Q6-2の`joined_cnt,info_loss_cnt,info_loss_pct`のCSVがQ6-2として認識されるか | 情報欠落の判定処理が走る |
| 3 | `info_loss_pct` が1%超の場合に「⚠️ 要注意」として記録されるか | 判定レポートにinfo_loss_pctを根拠とした ⚠️ が付与される |

---

### 総合評価観点（改修前後の比較）

改修前後で同一のカラムペアをSkill②→Skill③の順で実行し、以下の観点で比較する。

| 評価観点 | 改修前の状態 | 改修後の期待状態 |
|---|---|---|
| Q1/Q2の行数 | ID型・連続値型で数千万行 | 種別に応じた集計値1〜数十行 |
| Q4のJOIN脱落検出 | 不可（INNER JOINのため脱落レコードが見えない） | `dropped_pct` で即時把握可能 |
| Q4の一致率の信頼度 | LIMIT 100のサンプルベース（統計的根拠なし） | 全件集計ベース（断面全体を反映） |
| Q5の不一致パターン把握 | LIMIT 100のサンプル（全体割合不明） | `pct`付きの全パターン分布で規則性を即判断 |
| Q6の情報欠落検出 | 不可（単体NULL率のみ） | `info_loss_pct` で移行後のNULL増加を事前検出 |
| Skill③の自動判定精度 | CSVヘッダーが変わると認識失敗 | Q1〜Q6全種別のヘッダーに対応 |
| 2ペア目以降の絞り込み | プレースホルダーが残存するバグあり | 全ペアに均一適用 |
| 絞込条件なしのJOINコスト暴走リスク | あり（Q4/Q5が生成される） | なし（生成禁止メッセージに置換） |

---

---

### フェーズ4（C10 / S3）の検証

#### C10 検証（Q3-T 表記ゆれ除外版）

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | コード値型カラムペアを指定してQ1〜Q6を生成した場合にQ3-Tが生成されるか | Q3テンプレートの直後に `-- Q3-T: 件数比較（表記ゆれ除外・TRIM適用版）` が出力される |
| 2 | ID型・日付型・連続値型カラムを指定した場合にQ3-Tが生成されないか | Q3-Tが出力されず、Q3のみ出力される |
| 3 | Q3-Tに `NULLIF(TRIM(<カラム名>), '')` が含まれるか | TRIM処理でスペースのみの値をNULLとして扱う構造になっている |

#### S3 検証（スコア数値出力）

| # | 検証内容 | 合格条件 |
|---|---|---|
| 1 | Q3結果（件数差0.33%）・Q4結果（dropped_pct=0.5%・match_pct=95%）・Q5なし・Q6なしの場合のスコア | Q3スコア: 18.7点・Q4スコア: 47.5点・Q5スコア: 20点・Q6スコア: 10点 → 合計: 96.2点 → ✅ 概ね一致 |
| 2 | 総合判定にスコアが併記されるか | `### 総合判定: ✅ 概ね一致（スコア: XX / 100点）[基準未合意・参考値]` の形式で出力される |
| 3 | Q4未実施（絞込条件なし）の場合にスコアが70点満点換算になるか | 「Q4未実施（絞込条件なし）・XX点/70点満点」と付記される |
| 4 | サマリーテーブルにスコア列が追加されるか | 複数カラム一括判定時に「スコア」列が含まれるサマリーテーブルが出力される |
| 5 | [基準未合意・参考値] フラグが引き続き付与されるか | スコア付記後も全出力にフラグが存在する |

---

*最終更新: 2026-05-11（フェーズ4: AI-040/AI-041 追加）*
