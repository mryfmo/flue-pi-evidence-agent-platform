# Skill設計書：検証クエリ生成Skill（Skill②）

**作成日**: 2026年4月21日  
**作成者**: RS  
**参照元**: `column-mapping-skill-investigation_20260416.md` §5 Skill②

---

## 1. 概要

### 1.1 Skill名

`column-query-generator`

### 1.2 目的

Skill①（初期マッピング判定）が出力した「要検証」候補カラムに対して、**人間がSnowflakeで実行するための検証クエリ（Q1〜Q6）を一括生成**する。

従来はClaudeへ毎回個別指示していたためオーダーメイドになりがちで、クエリの品質・網羅性が担当者依存だった。本Skillにより標準化された6種のクエリを自動生成し、実行〜判定（Skill③）へのつなぎを効率化する。

### 1.3 対象ユーザー

- MSさん（ALADIN-DWH 収束対応担当）
- Pochiアプリ改修担当者全般

### 1.4 前後関係

```
[Skill①] 初期マッピング判定（候補一覧）
    ↓
[人間] 候補確認・検証対象の絞り込み
    ↓
[Skill②] 本Skill: 検証クエリ生成（Q1〜Q6）
    ↓
[人間] Snowflakeでクエリを実行し、結果をコピー
    ↓
[Skill③] 突合結果判定・アプリ影響分析
```

---

## 2. 入力定義

### 2.1 必須入力

Skill②の起動時点では、Skill①の出力によってビュー名・カラム名は確定済みのはずであり、ユーザーは以下を手元に持っている。

| # | 入力名 | 形式 | 提供方法 | 説明 |
|:---:|:---|:---:|:---|:---|
| I-1 | 旧カラム名 | テキスト | 人間が入力 | 例: `LINE_CONTRACT_FLAG` |
| I-2 | 新候補カラム名 | テキスト | 人間が入力 | 例: `LINE_CONTRACT_CODE` |
| I-3 | 旧ビュー名 | テキスト | 人間が入力 | Snowflakeのフルパス（DB.SCHEMA.VIEW）。例: `PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` |
| I-4 | 新ビュー名 | テキスト | 人間が入力 | Snowflakeのフルパス。例: `USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY` |
| I-5 | 旧ビューの主キー | テキスト | 人間が入力 | カンマ区切りで列挙。例: `ACCTID, SEDAI_MONTH` |
| I-6 | 新ビューの主キー | テキスト | 人間が入力 | 旧ビューと同じ場合は「同じ」と入力可。変更がある場合は具体的なカラム名を記載 |

### 2.2 推奨入力（クエリ品質向上）

| # | 入力名 | 形式 | 提供方法 | 説明 |
|:---:|:---|:---:|:---|:---|
| I-7 | 絞り込み条件（月次条件） | テキスト | 人間が入力 | 例: `SEDAI_MONTH = '2025-12-01'`。1億件超テーブルへのLIMIT制御用。省略時は最新月のデータを自動的に対象とする旨を注記 |
| I-8 | アプリでの使用箇所コード | テキスト | 人間がアプリコードからコピペ | 例: `CASE WHEN LINE_CONTRACT_FLAG='1' THEN '回線契約あり'`。Q4/Q5の突合観点とSkill③へのアプリ影響分析精度を高める |

### 2.3 複数候補を一括生成する場合

同一ビューペアに対して複数のカラムペアを検証する場合（例: `LINE_CONTRACT_FLAG`・`RANK_CODE`・`CARD_GRADE_CODE` を一括で検証する場合）は、カラムペアをまとめて入力することで各ペアのQ1〜Q6を連続生成できる。

---

## 3. 出力定義（Q1〜Q6クエリ）

### 3.1 クエリ一覧

| # | クエリ種別 | 目的 | 設計上の注意点 |
|:---:|:---|:---|:---|
| Q1 | 旧ビュー コード値分布 | 旧カラムにどのコード値が何件入っているか確認する | `GROUP BY + ORDER BY` 集計のみ。全件スキャンだが結果は集約されるため実行コスト低 |
| Q2 | 新ビュー コード値分布 | 新カラムにどのコード値が何件入っているか確認する | Q1と同形式。Skill③での比較を容易にするため列名・形式を揃える |
| Q3 | 件数比較（同条件） | 同じ絞り込み条件で旧新の総件数が一致するか確認する | 母体件数が旧新で異なる場合は WHERE 条件で揃える。UNION ALL で1クエリにまとめる |
| Q4 | サンプル突合 | 同一主キーのレコードで旧新の値を並べて比較する | `LIMIT 1000` 必須。主キーが異なる場合は共通キーでの近似突合を生成し制約事項を注記 |
| Q5 | 不一致レコード抽出 | 同一主キーで旧新の値が異なるレコードのみを抽出する | `WHERE old_col <> new_col OR (old_col IS NULL AND new_col IS NOT NULL) OR ...` + `LIMIT 1000` |
| Q6 | NULL件数確認 | 旧新それぞれのNULL件数・比率を確認する | 全件集計可。UNION ALL で1クエリにまとめる |

### 3.2 全件取得の回避方針

| クエリ | 方針 |
|:---|:---|
| Q1, Q2（コード値分布） | `GROUP BY` 集計のみ。絞り込み条件（月次）を付与 |
| Q3（件数比較） | `COUNT(*)` のみ。絞り込み条件を付与 |
| Q4（サンプル突合） | `LIMIT 1000` 必須 |
| Q5（不一致抽出） | `WHERE 不一致条件 + LIMIT 1000` |
| Q6（NULL件数） | `COUNT(*) FILTER(WHERE col IS NULL)` のみ。絞り込み条件を付与 |

月次テーブル（1億件/月超）に対しては `WHERE SEDAI_MONTH = '<最新月>'` の絞り込み条件を原則付与する。I-7が省略された場合はクエリコメントに「最新月の日付を入力してください」と注記を加える。

### 3.3 出力形式

```sql
-- =========================================================
-- 検証クエリ：LINE_CONTRACT_FLAG（旧） vs LINE_CONTRACT_CODE（新）
-- 旧ビュー: PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
-- 新ビュー: USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
-- 主キー: ACCTID, SEDAI_MONTH（旧新共通）
-- 絞り込み: SEDAI_MONTH = '2025-12-01'
-- 生成日: YYYY-MM-DD
-- =========================================================

-- Q1: 旧ビュー コード値分布
SELECT
    LINE_CONTRACT_FLAG AS code_value,
    COUNT(*) AS cnt,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct
FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
WHERE SEDAI_MONTH = '2025-12-01'
    AND ACCTID IS NOT NULL
GROUP BY LINE_CONTRACT_FLAG
ORDER BY LINE_CONTRACT_FLAG;

-- Q2: 新ビュー コード値分布
SELECT
    LINE_CONTRACT_CODE AS code_value,
    COUNT(*) AS cnt,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct
FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
WHERE SEDAI_MONTH = '2025-12-01'
    AND ACCTID IS NOT NULL
GROUP BY LINE_CONTRACT_CODE
ORDER BY LINE_CONTRACT_CODE;

-- Q3: 件数比較（同条件）
SELECT '旧VIEW' AS view_source, COUNT(*) AS row_count
FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
WHERE SEDAI_MONTH = '2025-12-01'
    AND ACCTID IS NOT NULL
UNION ALL
SELECT '新VIEW', COUNT(*)
FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
WHERE SEDAI_MONTH = '2025-12-01'
    AND ACCTID IS NOT NULL;

-- Q4: サンプル突合（同一主キー・LIMIT 1000）
SELECT
    old_v.ACCTID,
    old_v.SEDAI_MONTH,
    old_v.LINE_CONTRACT_FLAG AS old_value,
    new_v.LINE_CONTRACT_CODE AS new_value,
    CASE WHEN old_v.LINE_CONTRACT_FLAG = new_v.LINE_CONTRACT_CODE THEN '一致' ELSE '不一致' END AS match_result
FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION old_v
INNER JOIN USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY new_v
    ON old_v.ACCTID = new_v.ACCTID
    AND old_v.SEDAI_MONTH = new_v.SEDAI_MONTH
WHERE old_v.SEDAI_MONTH = '2025-12-01'
    AND old_v.ACCTID IS NOT NULL
LIMIT 1000;

-- Q5: 不一致レコード抽出（LIMIT 1000）
SELECT
    old_v.ACCTID,
    old_v.SEDAI_MONTH,
    old_v.LINE_CONTRACT_FLAG AS old_value,
    new_v.LINE_CONTRACT_CODE AS new_value
FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION old_v
INNER JOIN USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY new_v
    ON old_v.ACCTID = new_v.ACCTID
    AND old_v.SEDAI_MONTH = new_v.SEDAI_MONTH
WHERE old_v.SEDAI_MONTH = '2025-12-01'
    AND old_v.ACCTID IS NOT NULL
    AND (old_v.LINE_CONTRACT_FLAG <> new_v.LINE_CONTRACT_CODE
         OR (old_v.LINE_CONTRACT_FLAG IS NULL AND new_v.LINE_CONTRACT_CODE IS NOT NULL)
         OR (old_v.LINE_CONTRACT_FLAG IS NOT NULL AND new_v.LINE_CONTRACT_CODE IS NULL))
LIMIT 1000;

-- Q6: NULL件数確認
SELECT
    '旧VIEW' AS view_source,
    COUNT(*) AS total_count,
    COUNT(CASE WHEN LINE_CONTRACT_FLAG IS NULL THEN 1 END) AS null_count,
    ROUND(COUNT(CASE WHEN LINE_CONTRACT_FLAG IS NULL THEN 1 END) * 100.0 / COUNT(*), 2) AS null_pct
FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
WHERE SEDAI_MONTH = '2025-12-01'
    AND ACCTID IS NOT NULL
UNION ALL
SELECT
    '新VIEW',
    COUNT(*),
    COUNT(CASE WHEN LINE_CONTRACT_CODE IS NULL THEN 1 END),
    ROUND(COUNT(CASE WHEN LINE_CONTRACT_CODE IS NULL THEN 1 END) * 100.0 / COUNT(*), 2)
FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
WHERE SEDAI_MONTH = '2025-12-01'
    AND ACCTID IS NOT NULL;
```

### 3.4 主キー差異がある場合の Q4/Q5 の代替生成

旧新で主キー構造が異なる場合（例: 旧は `ACCTID + SEDAI_MONTH`、新は `MEMBER_ID + YEAR_MONTH`）は、直接JOINが不可能なため以下の近似突合クエリを生成し、制約事項として注記する。

```sql
-- Q4（近似）: 共通キーでの近似突合（主キー差異あり・参考値）
-- ⚠️ 注意: 旧新で主キー構造が異なるため直接JOINが不可能です。
-- ACCTID のみで突合した近似突合結果です。同一月の同一ACCTIDが複数存在する場合
-- 先頭1件のみが取得されます。結果は参考値として扱ってください。
SELECT
    old_v.ACCTID,
    old_v.LINE_CONTRACT_FLAG AS old_value,
    new_v.LINE_CONTRACT_CODE AS new_value
FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION old_v
INNER JOIN USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY new_v
    ON old_v.ACCTID = new_v.ACCTID
WHERE old_v.SEDAI_MONTH = '2025-12-01'
    AND new_v.SEDAI_MONTH = '2025-12-01'
LIMIT 1000;
```

---

## 4. 実装方針

### 4.1 スコープの明確化

| 本Skillのスコープ | スコープ外 |
|:---|:---|
| Q1〜Q6クエリの一括生成 | Snowflakeでのクエリ実行（人間が手動実行） |
| 主キー差異に応じた近似突合クエリの生成 | 実行結果の解析・判定（Skill③が担当） |
| 複数カラムペアの連続生成 | Alationメタデータの取得・参照 |
| 絞り込み条件・NULL条件の適切な付与 | 初期マッピング候補の生成（Skill①が担当） |

### 4.2 LLM活用箇所

| 処理 | LLM利用 | 理由 |
|:---:|:---:|:---|
| Q1〜Q6 SQL文の生成 | ✅ | ビュー名・カラム名・主キーを組み合わせた動的生成 |
| 主キー差異の解釈 | ✅ | 「同じ」「異なる」の自然言語入力を構造化 |
| NULL条件の組み立て | ✅ | IS NULL / IS NOT NULL の組み合わせを正しく組み立てる |
| クエリ実行 | ❌ | Snowflake MCPが未対応のため人間が手動実行 |

### 4.3 クエリ品質の担保

- 全クエリにヘッダコメント（カラム名・ビュー名・主キー・絞り込み条件・生成日）を付与する
- Q4/Q5は必ず `LIMIT 1000` を付与する（全件取得禁止）
- Q1/Q2は `pct`（比率）列を含め、Skill③でのコード値分布比較を容易にする
- Q5のNULL不一致は `IS NULL / IS NOT NULL` の組み合わせを網羅する（`<>` 演算子だけでは NULL を検出できないため）

---

## 5. エラーハンドリング

| エラーケース | 対応方針 |
|:---|:---|
| 旧新ビューで主キー構造が異なる | Q4/Q5を近似突合クエリに切り替え、「主キー差異あり・参考値」旨をコメントとして注記する |
| 絞り込み条件（月次）が未入力 | クエリ内の WHERE 条件に `-- ← 対象月を入力してください（例: '2025-12-01'）` とプレースホルダーコメントを付与する |
| カラム名にスペース・特殊文字が含まれる | ダブルクォートでカラム名を囲む（例: `"LINE CONTRACT FLAG"`） |
| 複数カラムペアを一括生成する場合 | 各ペアのQ1〜Q6を `-- ========` の区切り線で分離して出力する |

---

## 6. 未解決事項・前提条件

| # | 項目 | 状態 | 確認先 |
|:---:|:---|:---:|:---|
| U-1 | 絞り込み条件が省略された場合の最新月の自動判定方法（Snowflakeへのアクセスが必要か） | 未定 | RS |
| U-2 | 型が異なる（例: `NUMBER(1,0)` vs `VARCHAR(1)`）場合の比較演算子の選択（キャスト要否） | 未定 | RS・MS |
| U-3 | 複数候補を一括生成する場合の入力インターフェース（リスト入力 vs 対話的に1ペアずつ） | 未定 | RS |

---

## 7. 参考情報

- 調査元ドキュメント: `column-mapping-skill-investigation_20260416.md` §5 Skill②
- Before/After 対応表: 同 §4.1（⑥ 検証クエリ生成ステップ）
- 対象アプリ実例（クエリ設計の参考）: `VIEW変更対応_施策リフト計算アプリ_カラムマッピングと検証クエリ.md`
  - 検証1: `LINE_CONTRACT_FLAG` vs `LINE_INUSE_FLAG`（主キー一致・全件不一致ケース）
  - 検証1-B: コード値分布の GROUP BY 確認パターン
  - 検証1-C: 件数比較（UNION ALL）パターン
  - 検証2: `RANK_CODE` vs `DPOINTCLUB_RANK_CODE`（旧新コード値分布比較）
  - 検証3: `CARD_GRADE_CODE` vs `DCARD_GRADE_CODE`（絞り込み条件付きの比較）
  - 検証4: 件数突合（`DCARD_MEMBER_TYPE_CODE` + `DCARD_SERVICE_CODE` → 代替条件）
- 前後Skill: Skill①（`column-mapping-initializer`）・Skill③（`column-matching-verifier`）
