# VIEW変更対応レポート - 施策リフト計算アプリ

作成日: 2026-04-13  
対象アプリ: pochi-promotion-lift-calculator  
担当: SMさん（さとみつさん）  

---

## 概要

DWH収束に伴い、以下の旧VIEWが廃止予定。このアプリが使用しているカラムと、新VIEWへのマッピング・検証クエリをまとめる。

| 旧VIEW（廃止予定） | 新VIEW（代替先） |
|---|---|
| `PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | `USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY` |

---

## このアプリが使用しているVIEW一覧

### 要対応（DWH収束の対象）

| VIEW名 | DB.スキーマ | 使用ファイル |
|---|---|---|
| `VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` | `PROCDB_B_P01_LAK.D_MR_000` | `_03_dpoclubrank.py`, `_04_arpu.py` |

### 変更なし（参考）

| VIEW名 | DB.スキーマ | 使用ファイル |
|---|---|---|
| `VW_ADM_DNHD_DPOINTKOZA_GIVE_USE` | `PROCDB_B_P01_LAK.D_MR_000` | `_01_dpoint.py` |
| `VW_HMD_MECD_SERVICECATEGORY_CODE_CONVERSION_MASTER` | `PROCDB_B_P01_LAK.D_MR_000` | `_01_dpoint.py` |
| `VW_会員別サービス収益` | `USPCDB_N_P01_LAK.U_CMCM_MR` | `_04_arpu.py` |
| `VW_DIC_MECD_CLASSIFIEDBYACTION_CUSTOMER_MB` | `PROCDB_B_P01_LAK.D_MR_000` | `_04_arpu.py` |
| `VW_ADM_DNCD_BASE_NUMBER_ACCTID_CONVERSION_MASTER` | `PROCDB_B_P01_LAK.D_MR_000` | `_04_arpu.py` |

---

## カラムマッピング詳細（旧 → 新）

### このアプリで使用する旧VIEWのカラム（全7件）

| 旧カラム名 | 旧型 | 用途 | 新カラム名（候補） | 新型 | 判定 |
|---|---|---|---|---|---|
| `ACCTID` | VARCHAR(24) | アカウント識別子 | `ACCTID` | VARCHAR(24) | ✅ **完全一致・変更不要** |
| `SEDAI_MONTH` | DATE | 世代指定月（月初日） | `SEDAI_MONTH` | DATE | ✅ **完全一致・変更不要** |
| `LINE_CONTRACT_FLAG` | NUMBER(1,0) | 回線契約フラグ | `LINE_INUSE_FLAG` | NUMBER(1,0) | ⚠️ **要検証（後述のクエリ参照）** |
| `RANK_CODE` | VARCHAR(3) | ランクコード | `DPOINTCLUB_RANK_CODE` | VARCHAR(3) | ⚠️ **要検証（後述のクエリ参照）** |
| `CARD_GRADE_CODE` | VARCHAR(1) | dカード種別コード | `DCARD_GRADE_CODE` | VARCHAR(2) | ⚠️ **要検証（型拡張あり）** |
| `DCARD_MEMBER_TYPE_CODE` | VARCHAR(1) | dカード契約種別コード | **該当なし** | - | ❌ **新VIEWに存在しない** |
| `DCARD_SERVICE_CODE` | VARCHAR(5) | dカードサービスコード | **該当なし** | - | ❌ **新VIEWに存在しない** |

---

## コード上の使用箇所

### `_03_dpoclubrank.py:153` - dポイントクラブランク分析

```python
# 使用カラム: ACCTID, LINE_CONTRACT_FLAG, RANK_CODE, SEDAI_MONTH
rank_query = f"""
    SELECT distinct rank_vw.ACCTID
        , case when LINE_CONTRACT_FLAG='1' then '回線契約あり' else '回線契約なし' end as subset
        , case when RANK_CODE in ('102','001') then '1つ星'
               when RANK_CODE in ('103','002') then '2つ星'
               when RANK_CODE in ('104','003') then '3つ星'
               when RANK_CODE in ('105','004') then '4つ星'
               when RANK_CODE in ('106','005') then '5つ星'
               when RANK_CODE = '801' then 'ドコモビジネスメンバーズ1st'
               when RANK_CODE = '802' then 'ドコモビジネスメンバーズ2nd'
               when RANK_CODE = '803' then 'ドコモビジネスメンバーズ3rd'
               when RANK_CODE = '804' then 'ドコモビジネスメンバーズ4th'
               when RANK_CODE = '805' then 'ドコモビジネスメンバーズトップ'
               when RANK_CODE in ('101','000','ZZZ') or RANK_CODE is NULL then 'なし'
               else '例外'
           end as RANK
        , to_date(dateadd(month,-1,dateadd(day,1,SEDAI_MONTH))) as NENGETSU
        , SEDAI_MONTH
    FROM "PROCDB_B_P01_LAK"."D_MR_000"."VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION" rank_vw
    WHERE SEDAI_MONTH in ({nengappi_list})
        and ACCTID is not null
        and exists (select * from ... csv_user where rank_vw.ACCTID = csv_user.ACCTID)
"""
```

### `_04_arpu.py:359` - SLC-ARPU（dカードグレード）

```python
# 使用カラム: ACCTID, CARD_GRADE_CODE, SEDAI_MONTH, DCARD_MEMBER_TYPE_CODE, DCARD_SERVICE_CODE
"""
    select
        bsc_info.ACCTID,
        max(bsc_info.CARD_GRADE_CODE) as CARD_GRADE
    from "PROCDB_B_P01_LAK"."D_MR_000"."VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION" bsc_info
    where SEDAI_MONTH = '{base_month}'
    and DCARD_MEMBER_TYPE_CODE in (1,2)
    and DCARD_SERVICE_CODE is not null
    group by bsc_info.ACCTID
"""
```

### `_04_arpu.py:544` - CorporatePlanningARPU（回線契約フラグ）

```python
# 使用カラム: ACCTID, LINE_CONTRACT_FLAG, SEDAI_MONTH
"""
    select
        distinct ACCTID,
        to_char(SEDAI_MONTH, 'YYYYMM') as MONTH_DATE,
        case when LINE_CONTRACT_FLAG=1 then 1 else 0 end as line_flg
    from PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
    where MONTH_DATE in ({nengetsu_list})
"""
```

### `_04_arpu.py:1099` と `1114` - MobileFiberSlarpu（dカード・回線契約フラグ）

同上のパターンを2箇所で使用。

---

## 検証クエリ（Snowflake WebUIで実行）

### 【検証1】 `LINE_CONTRACT_FLAG` vs `LINE_INUSE_FLAG` の同等性確認

目的：同じ `ACCTID` に対して、旧の `LINE_CONTRACT_FLAG` と新の `LINE_INUSE_FLAG` が同じ値（1/0）を返すか確認する。

```sql
-- 同じSEDAI_MONTHで、旧旧VIEWと新VIEWのフラグ値を突合して比較
WITH old_flag AS (
    SELECT
        ACCTID,
        LINE_CONTRACT_FLAG AS old_flag,
        SEDAI_MONTH
    FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
    WHERE SEDAI_MONTH = '2025-12-01'  -- ← 検証したい月を入れる（月初日のDATE型）
        AND ACCTID IS NOT NULL
),
new_flag AS (
    SELECT
        ACCTID,
        LINE_INUSE_FLAG AS new_flag,
        SEDAI_MONTH
    FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
    WHERE SEDAI_MONTH = '2025-12-01'  -- ← 同じ月を入れる
        AND ACCTID IS NOT NULL
)
-- 差分確認：値が異なるレコードのみ抽出（0件なら完全一致）
SELECT
    old_flag.ACCTID,
    old_flag.old_flag,
    new_flag.new_flag,
    CASE
        WHEN old_flag.old_flag = new_flag.new_flag THEN '一致'
        ELSE '不一致'
    END AS check_result
FROM old_flag
INNER JOIN new_flag ON old_flag.ACCTID = new_flag.ACCTID
WHERE old_flag.old_flag != new_flag.new_flag  -- 不一致のみ表示
LIMIT 1000;
```

**判定基準：**
- 0件返ってきた → `LINE_INUSE_FLAG` で完全代替可能
- 不一致が多い → 意味が違うため代替不可。別の対応方法を検討


## snowflakeの実行結果（2025-12-01で実施）
全件違った。
OLD　→　2 or 3
NEW →　全て 0 

**考察：** `LINE_INUSE_FLAG` は 0/1 フラグだが、旧VIEWの `LINE_CONTRACT_FLAG` は 2/3 といったコード値を持つ別体系のカラム。候補の選定が外れていた。新VIEWには `LINE_CONTRACT_CODE`（VARCHAR(1)・回線契約中コード）と `LINE_CONTRACT_STATUS`（VARCHAR(2)・回線契約状態）が存在しており、特に `LINE_CONTRACT_STATUS` が複数桁のコード値を持つため、旧VIEWの値体系により近い可能性がある。

### 【追加検証1-B】`LINE_CONTRACT_FLAG` の正しい代替カラム探索

**背景：** 検証1の結果（`docs/検証１の結果.csv`）を確認したところ、INNER JOINは成立（ACCTIDは両VIEWに存在）しているが、旧VIEWの `LINE_CONTRACT_FLAG` の値は **2か3のみ**、新VIEWの `LINE_INUSE_FLAG` は**全て0**だった。値の体系が完全に別物であり、`LINE_INUSE_FLAG` の選定が外れていた。新VIEWには `LINE_CONTRACT_CODE`（VARCHAR(1)）・`LINE_CONTRACT_STATUS`（VARCHAR(2)）という別の候補があるため、以下で調査する。

**ステップ1：旧VIEWのコード値分布を確認する**

```sql
-- 旧VIEWの LINE_CONTRACT_FLAG のコード値分布を確認
SELECT
    LINE_CONTRACT_FLAG,
    COUNT(*) AS cnt
FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
WHERE SEDAI_MONTH = '2025-12-01'
    AND ACCTID IS NOT NULL
GROUP BY LINE_CONTRACT_FLAG
ORDER BY LINE_CONTRACT_FLAG;
```
## snowflakeの検証結果
LINE_CONTRACT_FLAG	CNT
1	44631702
2	32048809
3	39372135

**ステップ2：新VIEWの回線契約系カラム3種の分布を確認する**

```sql
-- 新VIEWの回線契約系カラムのコード値分布を確認（候補3種を比較）
SELECT
    LINE_CONTRACT_CODE,
    LINE_CONTRACT_STATUS,
    LINE_INUSE_FLAG,
    COUNT(*) AS cnt
FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
WHERE SEDAI_MONTH = '2025-12-01'
    AND ACCTID IS NOT NULL
GROUP BY LINE_CONTRACT_CODE, LINE_CONTRACT_STATUS, LINE_INUSE_FLAG
ORDER BY cnt DESC
LIMIT 1000;
```
## snowflakeの実行結果
LINE_CONTRACT_CODE	LINE_CONTRACT_STATUS	LINE_INUSE_FLAG	CNT
1	回線	1	42318997
0	CF	0	39035003
2	CF	0	24495717
0	CF	1	2270228
2	CF	1	26705
1	回線	0	13

アプリでは `LINE_CONTRACT_FLAG = '1'` を「回線契約あり」として使っているため、新VIEWで値が `'1'` または同等の意味を持つコードを返すカラムを特定し、同一ACCTIDで件数が一致するか突合する。

**ステップ3：同様に、dカード系の新VIEWのコード値分布も確認する**

`DCARD_CONTRACT_STATUS_FLAG = 1` が0件だった原因を調べるため、まず新VIEWのdカード系カラムの実際の値を確認する。

```sql
-- 新VIEWのdカード系カラムの値分布を確認
SELECT
    DCARD_CONTRACT_STATUS_FLAG,
    DCARD_GRADE_CODE,
    DCARD_FAMILY_MEMBER_FLAG,
    COUNT(*) AS cnt
FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
WHERE SEDAI_MONTH = '2025-12-01'
GROUP BY DCARD_CONTRACT_STATUS_FLAG, DCARD_GRADE_CODE, DCARD_FAMILY_MEMBER_FLAG
ORDER BY cnt DESC
LIMIT 1000;
```
## snowflakeの実行結果
DCARD_CONTRACT_STATUS_FLAG	DCARD_GRADE_CODE	DCARD_FAMILY_MEMBER_FLAG	CNT
0			90669354
1		0	14331754
1		1	3332528

### 追加検証1-B 考察・暫定結論

**回線契約フラグについて：**

旧VIEWのコード定義：
- `1` → 回線契約あり（44,631,702件）
- `2` → 解約後CF（32,048,809件）
- `3` → 純粋CF（39,372,135件）

新VIEWの対応関係（ステップ2の結果から）：
- 旧 `1`（回線契約あり）≒ 新 `LINE_CONTRACT_CODE = '1'` かつ `LINE_CONTRACT_STATUS = '回線'`（42,318,997件）
- 旧 `2` / `3`（CF系）≒ 新 `LINE_CONTRACT_STATUS = 'CF'`（計約65,827,653件）

アプリは `LINE_CONTRACT_FLAG = '1'`（回線契約あり）のみを「回線契約あり」として使っているため、**代替条件の最有力候補は `LINE_CONTRACT_CODE = '1'`**。旧1 = 44,631,702件 vs 新 = 42,318,997件で約230万件の差があるため、次の検証で同一ACCTIDの件数一致を確認する必要がある。

**dカードグレードコードについて：**

- `DCARD_CONTRACT_STATUS_FLAG = 1` は合計 17,664,282件（旧VIEWの17,113,926件に近い）→ **`DCARD_CONTRACT_STATUS_FLAG = 1` は正しい代替条件だった可能性が高い**
- ただし `DCARD_GRADE_CODE` が全てNULL → 検証3でNEWのレコードが0件だったのは、`DCARD_CONTRACT_STATUS_FLAG = 1` で絞っても `DCARD_GRADE_CODE` がNULLのため結果に出なかったのが原因
- `DCARD_GRADE_CODE` は新VIEWでは別カラムまたは別VIEWに移っている可能性が高い。引き続き調査が必要

### 【追加検証1-C】代替条件の件数突合と、DCARD_GRADE_CODEの代替探索

**回線契約：件数突合**

```sql
SELECT
    '旧VIEW (LINE_CONTRACT_FLAG=1)' AS condition,
    COUNT(DISTINCT ACCTID) AS cnt
FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
WHERE SEDAI_MONTH = '2025-12-01'
    AND LINE_CONTRACT_FLAG = '1'

UNION ALL

SELECT
    '新VIEW (LINE_CONTRACT_CODE=1)',
    COUNT(DISTINCT ACCTID)
FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
WHERE SEDAI_MONTH = '2025-12-01'
    AND LINE_CONTRACT_CODE = '1';
```
## snowflakeの実行結果
CONDITION	CNT
旧VIEW (LINE_CONTRACT_FLAG=1)	44631702
新VIEW (LINE_CONTRACT_CODE=1)	42319010


**dカードグレード：新VIEWで DCARD_GRADE_CODE が入っているレコードを探す**

```sql
-- DCARD_GRADE_CODE が NULL でないレコードがそもそも存在するか確認
SELECT
    DCARD_GRADE_CODE,
    COUNT(*) AS cnt
FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
WHERE SEDAI_MONTH = '2025-12-01'
    AND DCARD_GRADE_CODE IS NOT NULL
GROUP BY DCARD_GRADE_CODE;
```
## snowflakeの実行結果
クエリ結果なし。

### 追加検証1-C 考察・暫定結論

**回線契約フラグについて：**
- 旧VIEW `LINE_CONTRACT_FLAG = '1'`：44,631,702件
- 新VIEW `LINE_CONTRACT_CODE = '1'`：42,319,010件
- 差分：約231万件（旧 > 新）
- 件数が完全一致していないため、`LINE_CONTRACT_CODE = '1'` は代替候補として有力だが確定ではない。差分の原因追加調査が必要（新VIEWの母集団定義が旧VIEWと異なる可能性）。

**dカードグレードコードについて：**
- 新VIEWの `DCARD_GRADE_CODE` は全件NULL（データなし）が確定
- 旧VIEWの `CARD_GRADE_CODE`（1=レギュラー、2=ゴールド、3=プラチナ、4=GOLD U）に相当するカラムが `VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY` には存在しない
- dカードグレード情報は別VIEWに分離されているか、完全に廃止された可能性が高い
- **アプリのSLC-ARPU・MobileFiberSlarpuのdカードグレード別集計機能は、このVIEWだけでは代替不可能**

<!-- ### 【追加検証1-D】dカードグレード情報の代替VIEW探索

新VIEWとは別に、dカードグレード情報を保有するVIEWが存在するか確認する。

```sql
-- USPCDB_N_P01_LAK配下でdカードグレード関連のVIEWを探す
SELECT TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME
FROM USPCDB_N_P01_LAK.INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'VIEW'
    AND (TABLE_NAME ILIKE '%DCARD%' OR TABLE_NAME ILIKE '%CREDIT%' OR TABLE_NAME ILIKE '%CARD%')
ORDER BY TABLE_NAME;
``` -->

## snowflakeの実行結果
/home/user/pochi-promotion-lift-calculator-repository/docs/### 【追加検証1-D】dカードグレード情報の代替VIEW探索.csv
---

### 【検証2】 `RANK_CODE` vs `DPOINTCLUB_RANK_CODE` の同等性確認

目的：コード値体系が同じか（'102','001'等が同じ意味か）を確認する。

```sql
-- コード値の分布を旧新で比較する
WITH old_rank AS (
    SELECT
        RANK_CODE,
        COUNT(*) AS cnt
    FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
    WHERE SEDAI_MONTH = '2025-03-01'  -- ← 検証したい月
        AND ACCTID IS NOT NULL
    GROUP BY RANK_CODE
),
new_rank AS (
    SELECT
        DPOINTCLUB_RANK_CODE,
        COUNT(*) AS cnt
    FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
    WHERE SEDAI_MONTH = '2025-03-01'  -- ← 同じ月
        AND ACCTID IS NOT NULL
    GROUP BY DPOINTCLUB_RANK_CODE
)
-- 旧VIEWのコード分布
SELECT 'OLD' AS view, RANK_CODE AS code, cnt FROM old_rank
UNION ALL
-- 新VIEWのコード分布
SELECT 'NEW', DPOINTCLUB_RANK_CODE, cnt FROM new_rank
ORDER BY view, code;
```

**判定基準：**
- 旧'102' と 新'102' の件数がほぼ一致 → コード値体系が同じ（代替可能）
- 分布が大きく異なる → コード値体系が変わっている可能性あり（ドキュメント確認）

**アプリで使用しているコード値（確認対象）：**
```
'102','001' → '1つ星'
'103','002' → '2つ星'
'104','003' → '3つ星'
'105','004' → '4つ星'
'106','005' → '5つ星'
'801' → 'ドコモビジネスメンバーズ1st'
'802' → 'ドコモビジネスメンバーズ2nd'
'803' → 'ドコモビジネスメンバーズ3rd'
'804' → 'ドコモビジネスメンバーズ4th'
'805' → 'ドコモビジネスメンバーズトップ'
'101','000','ZZZ' または NULL → 'なし'
```
## snowflakeの実行結果
VIEW	CODE	CNT
NEW	102	60844580
NEW	103	29404960
NEW	104	5134647
NEW	105	6366308
NEW	106	2911015
OLD	000	72602
OLD	102	61469785
OLD	103	29451243
OLD	104	5142107
OLD	105	6368235
OLD	106	2911529
OLD	801	8252
OLD	802	434
OLD	803	415
OLD	804	387
OLD	805	172
OLD		6678478

- まぁまぁ合っていそうか？800番台のレコードがないね。
---

### 【検証3】 `CARD_GRADE_CODE` vs `DCARD_GRADE_CODE` の同等性確認

目的：型が VARCHAR(1)→VARCHAR(2) に拡張されているが、アプリで使用するコード値が引き続き使えるか確認。

```sql
-- コード値の分布を比較
WITH old_card AS (
    SELECT
        CARD_GRADE_CODE,
        COUNT(*) AS cnt
    FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
    WHERE SEDAI_MONTH = '2025-03-01'
        AND DCARD_MEMBER_TYPE_CODE IN (1,2)
        AND DCARD_SERVICE_CODE IS NOT NULL
    GROUP BY CARD_GRADE_CODE
),
new_card AS (
    SELECT
        DCARD_GRADE_CODE,
        COUNT(*) AS cnt
    FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
    WHERE SEDAI_MONTH = '2025-03-01'
        AND DCARD_CONTRACT_STATUS_FLAG = 1  -- ← 後述の検証3-Bで確認
    GROUP BY DCARD_GRADE_CODE
)
SELECT 'OLD' AS view, CARD_GRADE_CODE AS code, cnt FROM old_card
UNION ALL
SELECT 'NEW', DCARD_GRADE_CODE, cnt FROM new_card
ORDER BY view, code;
```

**アプリで使用しているコード値：**
```
1 → レギュラー
2 → ゴールド
3 → プラチナ
4 → GOLD U
```
## snowflakeの実行結果
VIEW	CODE	CNT
OLD	1	6527318
OLD	2	10063370
OLD	3	498904
OLD	4	24334

- newのレコードがないけれど、クエリの問題？
---

### 【検証4】 `DCARD_MEMBER_TYPE_CODE` / `DCARD_SERVICE_CODE` の代替条件確認（最重要）

旧VIEWの絞り込み条件：
```sql
WHERE DCARD_MEMBER_TYPE_CODE in (1,2)
AND DCARD_SERVICE_CODE is not null
```
→ この意図は「dカード本会員（個人契約）かつ有効なサービス利用者」を絞ること。

新VIEWには上記カラムが存在しないため、`DCARD_CONTRACT_STATUS_FLAG`（dカード契約状態フラグ）での代替を検証する。

```sql
-- 旧VIEWの対象件数
SELECT COUNT(DISTINCT ACCTID) AS old_count
FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
WHERE SEDAI_MONTH = '2025-03-01'
    AND DCARD_MEMBER_TYPE_CODE IN (1,2)
    AND DCARD_SERVICE_CODE IS NOT NULL;
```
## snowflakeの実行結果
OLD_COUNT
17113926

```sql
-- 新VIEWでの代替候補条件（DCARD_CONTRACT_STATUS_FLAG = 1）
SELECT COUNT(DISTINCT ACCTID) AS new_count
FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
WHERE SEDAI_MONTH = '2025-03-01'
    AND DCARD_CONTRACT_STATUS_FLAG = 1;  -- dカード契約状態フラグ
```
## snowflakeの実行結果
NEW_COUNT
0

```sql
-- 件数比較（上記2つをまとめて確認）
SELECT 'OLD (DCARD_MEMBER_TYPE_CODE IN (1,2) AND DCARD_SERVICE_CODE IS NOT NULL)' AS condition,
       COUNT(DISTINCT ACCTID) AS acctid_count
FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
WHERE SEDAI_MONTH = '2025-03-01'
    AND DCARD_MEMBER_TYPE_CODE IN (1,2)
    AND DCARD_SERVICE_CODE IS NOT NULL

UNION ALL

SELECT 'NEW (DCARD_CONTRACT_STATUS_FLAG = 1)' AS condition,
       COUNT(DISTINCT ACCTID) AS acctid_count
FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
WHERE SEDAI_MONTH = '2025-03-01'
    AND DCARD_CONTRACT_STATUS_FLAG = 1;
```

## snowflakeの実行結果
CONDITION	ACCTID_COUNT
OLD (DCARD_MEMBER_TYPE_CODE IN (1,2) AND DCARD_SERVICE_CODE IS NOT NULL)	17113926
NEW (DCARD_CONTRACT_STATUS_FLAG = 1)	0

**判定基準：**
- 件数がほぼ一致（±1%以内）→ `DCARD_CONTRACT_STATUS_FLAG = 1` で代替可能
- 大きな乖離がある場合 → 他の条件の組み合わせも試す（例：`DCARD_FAMILY_MEMBER_FLAG = 0` を追加してみる等）

---

### 【検証5】 総合的なデータ整合性確認（最終確認用）

`VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION` を使う全アプリクエリに対して、新旧VIEWで結果セットが一致するか確認する。

```sql
-- ランク分析（_03_dpoclubrank.py相当）の新旧比較
WITH old_result AS (
    SELECT
        ACCTID,
        LINE_CONTRACT_FLAG,
        RANK_CODE,
        SEDAI_MONTH
    FROM PROCDB_B_P01_LAK.D_MR_000.VW_DIC_MECD_MEMBER_PROFILE_BASIC_INFORMATION
    WHERE SEDAI_MONTH = '2025-03-01'
        AND ACCTID IS NOT NULL
),
new_result AS (
    SELECT
        ACCTID,
        LINE_INUSE_FLAG       AS LINE_CONTRACT_FLAG,   -- 代替候補
        DPOINTCLUB_RANK_CODE  AS RANK_CODE,            -- 代替候補
        SEDAI_MONTH
    FROM USPCDB_N_P01_LAK.U_MP001_MR.VW_DPOINTCLUB_MEMBER_PROFILE_MONTHLY
    WHERE SEDAI_MONTH = '2025-03-01'
        AND ACCTID IS NOT NULL
)
-- 件数・ハッシュ値比較（これが一致すれば代替OK）
SELECT
    '旧VIEW' AS view_source,
    COUNT(*) AS row_count,
    HASH_AGG(*) AS data_hash
FROM old_result

UNION ALL

SELECT
    '新VIEW',
    COUNT(*),
    HASH_AGG(*)
FROM new_result;
```

## snowflakeの実行結果
VIEW_SOURCE	ROW_COUNT	DATA_HASH
旧VIEW	112103639	9202837077100171072
新VIEW	104661510	-4826179194150792396

**判定基準：**
- `row_count` と `data_hash` の両方が一致 → 完全代替可能、アプリへの影響ゼロと判断

---

## 結論（現時点の判断）

| カラム | 代替候補 | 状況 |
|---|---|---|
| `ACCTID` | `ACCTID` | ✅ 変更不要 |
| `SEDAI_MONTH` | `SEDAI_MONTH` | ✅ 変更不要 |
| `LINE_CONTRACT_FLAG` | `LINE_INUSE_FLAG` | ⚠️ 検証1で確認（おそらく代替可） |
| `RANK_CODE` | `DPOINTCLUB_RANK_CODE` | ⚠️ 検証2でコード値確認 |
| `CARD_GRADE_CODE` | `DCARD_GRADE_CODE` | ⚠️ 検証3で確認（型拡張は許容範囲） |
| `DCARD_MEMBER_TYPE_CODE` | `DCARD_CONTRACT_STATUS_FLAG = 1` | ⚠️ 検証4で件数比較 |
| `DCARD_SERVICE_CODE` | 同上（`DCARD_CONTRACT_STATUS_FLAG = 1` に統合） | ⚠️ 検証4で件数比較 |

---

## 検証完了後のアプリ修正箇所

検証が完了し、代替カラムが確定したら以下のファイルを修正する：

| ファイル | 行番号 | 修正内容 |
|---|---|---|
| `app/_01_app_modules/calculation/_03_dpoclubrank.py` | 153 | VIEW名・カラム名の変更 |
| `app/_01_app_modules/calculation/_04_arpu.py` | 359, 544, 1099, 1114 | VIEW名・カラム名・WHERE条件の変更 |
