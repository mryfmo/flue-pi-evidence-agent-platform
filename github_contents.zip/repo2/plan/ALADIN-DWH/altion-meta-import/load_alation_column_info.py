"""
Snowflake からダウンロードした VW_ALATION_COLUMN_INFO CSV を pandas で読み込むスクリプト

使い方:
    # 全件表示（カラム名一覧 + 先頭5行）
    python load_alation_column_info.py

    # VIEW名で絞り込み（部分一致）
    python load_alation_column_info.py --view MY_VIEW_NAME

    # VIEW名で絞り込み（完全一致）
    python load_alation_column_info.py --view MY_VIEW_NAME --exact
"""

import argparse
import sys

import pandas as pd
from pathlib import Path

CSV_PATH = Path(__file__).parent.parent / "alation-meta" / "VW_ALATION_COLUMN_INFO 1_2026-04-17.csv"

# VIEW名が格納されているカラム名（実行後のカラム名一覧を確認して変更してください）
VIEW_NAME_COLUMN = "VIEW_NAME"


def load_alation_column_info(csv_path: Path = CSV_PATH) -> pd.DataFrame:
    """
    Snowflake からダウンロードした CSV を DataFrame として返す。

    Parameters
    ----------
    csv_path : Path
        読み込む CSV ファイルのパス

    Returns
    -------
    pd.DataFrame
        読み込んだデータ
    """
    df = pd.read_csv(
        csv_path,
        encoding="utf-8",      # Snowflake エクスポートのデフォルト文字コード
        low_memory=False,       # 混在型カラムの誤検知を防ぐ
    )
    return df


def search_by_view_name(df: pd.DataFrame, view_name: str, exact: bool = False) -> pd.DataFrame:
    """
    VIEW名でデータフレームを絞り込む。

    Parameters
    ----------
    df : pd.DataFrame
        全件データフレーム
    view_name : str
        検索するVIEW名
    exact : bool
        True の場合は完全一致、False の場合は部分一致（大文字小文字を無視）

    Returns
    -------
    pd.DataFrame
        絞り込み結果
    """
    if VIEW_NAME_COLUMN not in df.columns:
        raise KeyError(
            f"カラム '{VIEW_NAME_COLUMN}' が見つかりません。"
            f"実際のカラム: {df.columns.tolist()}\n"
            f"スクリプト内の VIEW_NAME_COLUMN を正しいカラム名に変更してください。"
        )

    if exact:
        return df[df[VIEW_NAME_COLUMN].str.upper() == view_name.upper()].reset_index(drop=True)
    else:
        return df[df[VIEW_NAME_COLUMN].str.contains(view_name, case=False, na=False)].reset_index(drop=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="VW_ALATION_COLUMN_INFO CSV を検索する")
    parser.add_argument("--view", type=str, default=None, help="検索するVIEW名（部分一致）")
    parser.add_argument("--exact", action="store_true", help="完全一致で検索する")
    args = parser.parse_args()

    df_all = load_alation_column_info()

    # カラム名一覧を取得
    columns = df_all.columns.tolist()

    print(f"全件 shape : {df_all.shape}")
    print(f"カラム数   : {len(columns)}")
    print("カラム名一覧:")
    for i, col in enumerate(columns):
        print(f"  [{i:>2}] {col}")

    if args.view:
        try:
            df_result = search_by_view_name(df_all, args.view, exact=args.exact)
        except KeyError as e:
            print(f"\n[ERROR] {e}", file=sys.stderr)
            sys.exit(1)

        match_type = "完全一致" if args.exact else "部分一致"
        print(f"\n--- '{args.view}' で検索（{match_type}）: {len(df_result)} 件 ---")
        print(df_result)
    else:
        print("\n--- head(5) ---")
        print(df_all.head())
