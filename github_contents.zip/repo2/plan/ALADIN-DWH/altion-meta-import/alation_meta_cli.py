#!/usr/bin/env python3
# /// script
# requires-python = "==3.13.*"
# dependencies = [
#   "duckdb>=1.0.0",
#   "pandas>=2.0.0",
#   "tabulate>=0.9.0",
# ]
# ///
"""
alation_meta_cli.py

Alation メタ情報 CSV を参照・絞り込みする統合CLIスクリプト（DuckDB版）

実行方法:
    # uv run（推奨）— 依存ライブラリを自動インストールして実行
    uv run alation_meta_cli.py <subcommand> [options]

    # python（依存ライブラリを別途インストール済みの場合）
    python alation_meta_cli.py <subcommand> [options]

使い方:
    # VIEW情報のカラム統計を確認（SUMMARIZE）
    uv run alation_meta_cli.py view-meta

    # VIEW名で絞り込み（部分一致）
    uv run alation_meta_cli.py view-meta --view MY_VIEW

    # VIEW名で絞り込み（完全一致）
    uv run alation_meta_cli.py view-meta --view MY_VIEW --exact

    # カラム情報を参照（VIEW名で絞り込み）
    uv run alation_meta_cli.py column-meta --view MY_VIEW

    # カラム名で絞り込み
    uv run alation_meta_cli.py column-meta --column AMOUNT

    # VIEW_INFO + COLUMN_INFO を VIEW_NAME で JOIN
    uv run alation_meta_cli.py join --view MY_VIEW

    # 結果をCSVに保存
    uv run alation_meta_cli.py view-meta --view MY_VIEW --out ./output.csv

    # 任意のCSVファイルのカラム統計を確認
    uv run alation_meta_cli.py csv-meta --file ./some.csv ./other.csv

    # 任意のSQLを実行
    uv run alation_meta_cli.py query --sql "SELECT * FROM './some.csv' LIMIT 10"
    uv run alation_meta_cli.py query --sql "SELECT * FROM './some.csv'" --out ./output.csv

------------------------------------------------------------------------
セキュリティ対応履歴 (2026-04-17)
------------------------------------------------------------------------

[Critical] #1 SQLインジェクション対策 (CWE-89 / OWASP A03:2021)
  - _escape() を廃止。DuckDBの文字列エスケープ仕様に合わず無効だった
  - view-meta / column-meta / join / csv-meta の全サブコマンドで
    DuckDB パラメータバインディング（? プレースホルダー）に移行
  - --view / --column 引数の値が SQL に直接埋め込まれなくなった

[Critical] #2 任意SQL実行によるファイル読み書き防止 (CWE-94 / OWASP A03:2021)
  - Claude Code Skill 実行時（POCHI_SKILL_MODE=1）は query サブコマンドを拒否
  - プロンプトインジェクション経由で任意SQL（SELECT * FROM '/etc/passwd' 等）が
    実行されることを防止

[High] #3 パストラバーサル対策 (CWE-22 / OWASP A01:2021)
  - _validate_path() を実装し --file / --out に指定されたパスを検証
  - Path.resolve() で絶対パスへ変換後、スクリプトディレクトリまたは
    カレントディレクトリ配下のみ許可（_ALLOWED_DIRS）
  - /etc/shadow 等の機密ファイル読み取りや ~/.bashrc 上書きを防止

[High] #4 csv-meta ファイルパスインジェクション対策 (CWE-73)
  - cmd_csv_meta() の SUMMARIZE / COUNT クエリを f-string 埋め込みから
    read_csv_auto(?) パラメータバインディングに変更
  - ファイルパス自体が SQL インジェクションのベクターになる問題を解消

[Medium] #5 エラー情報過剰開示の抑制 (CWE-209 / OWASP A04:2021)
  - Skill 実行モード（POCHI_SKILL_MODE=1）では traceback.print_exc() を抑制
  - スタックトレースに含まれるファイルパス・内部構造の漏洩を防止
  - CLI 実行時はこれまで通りフルスタックトレースを出力
"""

import argparse
import os
import sys
import traceback
from pathlib import Path

import duckdb
import pandas as pd
from tabulate import tabulate

_DIR = Path(__file__).parent.parent / "alation-meta"
VIEW_INFO_CSV   = str(_DIR / "VW_ALATION_VIEW_INFO_2026-04-17.csv")
COLUMN_INFO_CSV = str(_DIR / "VW_ALATION_COLUMN_INFO 1_2026-04-17.csv")


# ─── ユーティリティ ───────────────────────────────────────────────────────────

# 許可されたディレクトリ（スクリプトディレクトリおよびカレントディレクトリ）
_ALLOWED_DIRS = [
    Path(__file__).parent.resolve(),
    Path.cwd().resolve(),
]


def _is_skill_mode() -> bool:
    """Claude Code Skill として実行されているか判定"""
    return os.environ.get("POCHI_SKILL_MODE", "").lower() in ("1", "true", "yes")


def _validate_path(path_str: str, label: str) -> str:
    """ファイルパスがプロジェクトディレクトリ配下であることを検証（パストラバーサル対策）"""
    resolved = Path(path_str).resolve()
    if not any(resolved.is_relative_to(d) for d in _ALLOWED_DIRS):
        raise ValueError(
            f"{label}はスクリプトディレクトリまたはカレントディレクトリ配下に限定されています: {resolved}\n"
            f"許可ディレクトリ: {', '.join(str(d) for d in _ALLOWED_DIRS)}"
        )
    return str(resolved)


def _output(df: pd.DataFrame, out_path: str | None) -> None:
    if out_path:
        if len(df) == 0:
            print(f"[WARN] 結果が0件のため、ファイルへの出力をスキップしました: {out_path}", file=sys.stderr)
            return
        validated = _validate_path(out_path, "--out")
        out_dir = os.path.dirname(validated)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        df.to_csv(validated, index=False)
        print(f"[OK] {len(df)}行 × {len(df.columns)}列 を {Path(validated).resolve()} に保存しました")
    else:
        print(tabulate(df.head(50), headers="keys", tablefmt="grid", showindex=False))
        if len(df) > 50:
            print(f"\n（先頭50行を表示。全{len(df)}行）")


def _summarize(con: duckdb.DuckDBPyConnection, csv_path: str) -> None:
    summary_df = con.execute(f"SUMMARIZE SELECT * FROM '{csv_path}'").fetchdf()
    count_df   = con.execute(f"SELECT COUNT(*) AS row_count FROM '{csv_path}'").fetchdf()
    row_count  = count_df["row_count"].iloc[0]

    print(f"行数: {row_count:,}")
    print(f"カラム数: {len(summary_df)}")
    print()

    display_cols = ["column_name", "column_type", "min", "max", "approx_unique", "avg", "null_percentage"]
    available   = [c for c in display_cols if c in summary_df.columns]
    print(tabulate(summary_df[available], headers="keys", tablefmt="grid", showindex=False))


# ─── サブコマンド実装（汎用） ─────────────────────────────────────────────────

def cmd_csv_meta(args: argparse.Namespace) -> None:
    con = duckdb.connect()
    try:
        for filepath in args.file:
            validated = _validate_path(filepath, "--file")
            if not os.path.exists(validated):
                print(f"[ERROR] ファイルが見つかりません: {validated}", file=sys.stderr)
                continue

            print("=" * 60)
            print(f"ファイル: {validated}")
            print("=" * 60)

            summary_df = con.execute("SUMMARIZE SELECT * FROM read_csv_auto(?)", [validated]).fetchdf()
            count_df   = con.execute("SELECT COUNT(*) AS row_count FROM read_csv_auto(?)", [validated]).fetchdf()
            row_count  = count_df["row_count"].iloc[0]

            print(f"行数: {row_count:,}")
            print(f"カラム数: {len(summary_df)}")
            print()

            display_cols = ["column_name", "column_type", "min", "max", "approx_unique", "avg", "null_percentage"]
            available = [c for c in display_cols if c in summary_df.columns]
            print(tabulate(summary_df[available], headers="keys", tablefmt="grid", showindex=False))
            print()
    finally:
        con.close()


def cmd_query(args: argparse.Namespace) -> None:
    if _is_skill_mode():
        print("[ERROR] Skill実行モードでは query サブコマンドは使用できません", file=sys.stderr)
        sys.exit(1)
    con = duckdb.connect()
    try:
        df = con.execute(args.sql).fetchdf()
        _output(df, args.out)
    finally:
        con.close()


# ─── サブコマンド実装（Alation特化） ─────────────────────────────────────────

def cmd_view_meta(args: argparse.Namespace) -> None:
    con = duckdb.connect()
    try:
        if not args.view:
            _summarize(con, VIEW_INFO_CSV)
            return

        if args.exact:
            sql = f"SELECT * FROM '{VIEW_INFO_CSV}' WHERE UPPER(VIEW_NAME) = UPPER(?)"
        else:
            sql = f"SELECT * FROM '{VIEW_INFO_CSV}' WHERE CONTAINS(UPPER(VIEW_NAME), UPPER(?))"

        df = con.execute(sql, [args.view]).fetchdf()
        match_type = "完全一致" if args.exact else "部分一致"
        print(f"\n--- VIEW='{args.view}'（{match_type}）: {len(df)} 件 ---\n")
        _output(df, args.out)
    finally:
        con.close()


def cmd_column_meta(args: argparse.Namespace) -> None:
    con = duckdb.connect()
    try:
        if not args.view and not args.column:
            _summarize(con, COLUMN_INFO_CSV)
            return

        conditions = []
        params = []
        if args.view:
            if args.exact:
                conditions.append("UPPER(VIEW_NAME) = UPPER(?)")
            else:
                conditions.append("CONTAINS(UPPER(VIEW_NAME), UPPER(?))")
            params.append(args.view)
        if args.column:
            conditions.append("CONTAINS(UPPER(COLUMN_NAME), UPPER(?))")
            params.append(args.column)

        where = " AND ".join(conditions)
        sql = f"SELECT * FROM '{COLUMN_INFO_CSV}' WHERE {where}"

        df = con.execute(sql, params).fetchdf()
        label_parts = []
        if args.view:
            label_parts.append(f"VIEW='{args.view}'")
        if args.column:
            label_parts.append(f"COLUMN='{args.column}'")
        print(f"\n--- {' & '.join(label_parts)}: {len(df)} 件 ---\n")
        _output(df, args.out)
    finally:
        con.close()


def cmd_join(args: argparse.Namespace) -> None:
    con = duckdb.connect()
    try:
        base_sql = f"""
            SELECT v.*, c.* EXCLUDE (c.VIEW_NAME)
            FROM '{VIEW_INFO_CSV}' v
            LEFT JOIN '{COLUMN_INFO_CSV}' c USING (VIEW_NAME)
        """
        params = []
        if args.view:
            if args.exact:
                where = "WHERE UPPER(v.VIEW_NAME) = UPPER(?)"
            else:
                where = "WHERE CONTAINS(UPPER(v.VIEW_NAME), UPPER(?))"
            sql = base_sql + where
            params.append(args.view)
            match_type = "完全一致" if args.exact else "部分一致"
            label = f"JOIN結果 VIEW='{args.view}'（{match_type}）"
        else:
            sql = base_sql
            label = "VIEW_INFO JOIN COLUMN_INFO（全件）"

        df = con.execute(sql, params).fetchdf()
        print(f"\n--- {label}: {len(df)} 件 ---\n")
        _output(df, args.out)
    finally:
        con.close()


# ─── CLI エントリポイント ─────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Alation メタ情報 CSV（VIEW_INFO / COLUMN_INFO）を DuckDB で参照・絞り込みするCLIツール"
    )
    sub = parser.add_subparsers(dest="subcommand", metavar="<subcommand>")
    sub.required = True

    p_view = sub.add_parser("view-meta", help="VW_ALATION_VIEW_INFO を参照・絞り込み（引数なし時はSUMMARIZE）")
    p_view.add_argument("--view",  type=str, help="VIEW名（部分一致）")
    p_view.add_argument("--exact", action="store_true", help="VIEW名を完全一致で検索")
    p_view.add_argument("--out",   type=str, help="結果をCSVファイルに保存するパス")

    p_col = sub.add_parser("column-meta", help="VW_ALATION_COLUMN_INFO を参照・絞り込み（引数なし時はSUMMARIZE）")
    p_col.add_argument("--view",   type=str, help="VIEW名（部分一致）")
    p_col.add_argument("--column", type=str, help="カラム名（部分一致）")
    p_col.add_argument("--exact",  action="store_true", help="VIEW名を完全一致で検索")
    p_col.add_argument("--out",    type=str, help="結果をCSVファイルに保存するパス")

    p_join = sub.add_parser("join", help="VIEW_INFO + COLUMN_INFO を VIEW_NAME で LEFT JOIN")
    p_join.add_argument("--view",  type=str, help="VIEW名（部分一致）")
    p_join.add_argument("--exact", action="store_true", help="VIEW名を完全一致で検索")
    p_join.add_argument("--out",   type=str, help="結果をCSVファイルに保存するパス")

    p_csv_meta = sub.add_parser("csv-meta", help="任意のCSVファイルのカラム統計を表示（SUMMARIZE）")
    p_csv_meta.add_argument("--file", required=True, nargs="+", help="CSVファイルパス（複数指定可）")

    p_query = sub.add_parser("query", help="任意のSQLを実行してCSVを加工")
    p_query.add_argument("--sql", required=True, help="実行するSQL（CSVパスをテーブル名として使用）")
    p_query.add_argument("--out", type=str, help="結果をCSVファイルに保存するパス（省略時は先頭50行を表示）")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    dispatch = {
        "view-meta":   cmd_view_meta,
        "column-meta": cmd_column_meta,
        "join":        cmd_join,
        "csv-meta":    cmd_csv_meta,
        "query":       cmd_query,
    }

    try:
        dispatch[args.subcommand](args)
    except Exception as e:
        if not _is_skill_mode():
            traceback.print_exc()
        print(f"\n[ERROR] {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
