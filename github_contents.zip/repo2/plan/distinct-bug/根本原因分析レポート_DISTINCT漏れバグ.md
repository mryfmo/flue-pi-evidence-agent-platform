# 根本原因分析レポート：DISTINCT漏れバグ

| 項目 | 内容 |
|---|---|
| 対象アプリ | 配信対象者リスト抽出アプリ（pochi-customer-filtering-repository） |
| 関連Issue | #461, #462（振り返り会議 2026-05-14） |
| 調査日 | 2026-05-14 |
| 調査者 | Claude Code |
| 調査方法 | コードリポジトリの実コード・gitログ・テストファイルを直接精査 |

---

## 1. バグの概要

メディア接触状況フィルタを使用して配信対象者リストを抽出すると、選択件数が異常に膨れ上がる。

**影響範囲：** メディア接触状況タブでいずれかのメディアを選択した全ての検索実行

---

## 2. 直接原因：コードによる特定

### 問題箇所

`app/lib/clazz/query_helper.py:1771–1783`

```python
# バグのあるコード（現HEADでも未修正）
INNER JOIN (
    SELECT ACCTID           # ← DISTINCT が抜けている
    FROM "USPCDB_N_P01_LAK"."U_DPME_MR"."VW_STARTDASH_MEDIA_CONTACT"
    WHERE
        SEDAI_MONTH = %(media_contact_sedai_month)s
        AND MEDIA_ID_CODE in (%(target_media)s)
) AS startdash_media_contact
ON startdash_basic.ACCTID = startdash_media_contact.ACCTID
```

### なぜ重複が発生するか

`VW_STARTDASH_MEDIA_CONTACT` は `ACCTID × SEDAI_MONTH × MEDIA_ID_CODE` の縦持ち構造（アプリ利用ログ型）。  
ユーザーが複数のメディア（例：「dポイントクラブ_サイト」コード51・「dポイントクラブ_アプリ」コード52）を選択すると、`MEDIA_ID_CODE IN (51, 52)` の条件に対して同一 `ACCTID` が複数行マッチする。  
`DISTINCT` のない `SELECT ACCTID` をそのままベーステーブルに `INNER JOIN` すると、マッチしたメディア数の分だけ行が膨張する。

**例：**

| ACCTID | SEDAI_MONTH | MEDIA_ID_CODE |
|---|---|---|
| A001 | 202504 | 51 |
| A001 | 202504 | 52 |

→ `IN (51, 52)` でフィルタすると A001 が2行ヒット → JOIN後にA001が2件になる

### 正しい実装

```sql
SELECT DISTINCT ACCTID
FROM "USPCDB_N_P01_LAK"."U_DPME_MR"."VW_STARTDASH_MEDIA_CONTACT"
WHERE ...
```

---

## 3. 導入経緯：gitログによる特定

| コミット | 日時 | 内容 |
|---|---|---|
| `834fd27` | 2025-10月 | `VW_STARTDASH_MEDIA_CONTACT` を新規追加（世代日実装）。この時点でDISTINCTなしで実装 |
| `a9d887d` | 2025-10-21 | 世代月取得処理を修正。サブクエリのDISTINCT欠落はそのまま |
| `741bc3d` | 以降 | テーブルを本番環境DBに差し替え（スキーマ名変更のみ、SQLロジック変更なし） |
| `86d5e5b`（現HEAD） | 2026-03-06 | DISTINCTは未修正のまま |

バグは **2025年10月のStartDash統合作業** で混入し、**現在も未修正**。

---

## 4. 議事録の記述との照合

振り返り会議（2026-05-14）の議事録で確定された根本原因と、実コード調査による検証結果を照合する。

### 4-1. 「縦持ち構造かどうかを実データで検証しなかった」（HTによる確定）

**判定：部分的に正しいが、表現が不正確**

縦持ち構造であること自体は、ビュー名（MEDIA_CONTACT）とフィルタ条件（`MEDIA_ID_CODE IN (...)`）から実装時点で推察できるはず。  
より正確に言えば、「縦持ちビューをJOINする際にはDISTINCTが必要」という実装知識が適用されなかったことが直接の原因。

### 4-2. 「Alationカタログにメタ情報の記載なし」

**判定：状況証拠と一致**

リポジトリには `VW_STARTDASH_BASIC_ATTRIBUTE` 向けのAlationメタデータCSV（`tests/lib/alation_VW_STARTDASH_BASIC_ATTRIBUT.csv`）が存在するが、`VW_STARTDASH_MEDIA_CONTACT` に対応するファイルは存在しない。議事録の記述と整合する。

### 4-3. 「1行の修正（DISTINCT追加）で対応済み」

**判定：誤り。現HEADでも未修正**

調査時点（2026-05-14）のHEAD（コミット `86d5e5b`）において、`query_helper.py:1773` は `SELECT ACCTID`（DISTINCTなし）のまま。修正が別ブランチ・別環境に存在する可能性はあるが、このリポジトリのmain相当ブランチでは確認できなかった。

### 4-4. 「DISTINCT要否の判断基準は自明（判断基準不明は削除）」（HTによる評価）

**判定：疑問あり**

同一ファイル `query_helper.py` 内で、他のサブクエリには `DISTINCT` が明示されている：

| 行 | 対象ビュー | 記述 |
|---|---|---|
| 1792 | `VW_ADM_DNCD_PUSH_DELIVERY_PERMISSION` | `SELECT DISTINCT ACCTID` |
| 1810 | `VW_KESSAI_DCARD_FEATURES` | `SELECT DISTINCT "共通IDグループ番号"` |
| 1866 | （別サブクエリ） | `DISTINCT "共通IDグループ番号"` |

`VW_STARTDASH_MEDIA_CONTACT` だけが `SELECT ACCTID`（DISTINCTなし）。  
「自明だから削除」ではなく、むしろ同一ファイル内の他の実装パターンとの**不整合**が混入した可能性が高い。

---

## 5. 根本原因の再整理

議事録の「縦持ち検証不足」は真因の一部だが、より構造的に整理すると以下の2層になる。

```
Layer A（実装層）：query_helper.py の同一ファイル内で
                   他のビューへのサブクエリには DISTINCT が書かれているのに、
                   新規追加した VW_STARTDASH_MEDIA_CONTACT だけ抜けた
                   → StartDash統合作業（2025年10月）で混入

Layer B（設計・検証層）：縦持ちビューをJOINする際の DISTINCT 要否が
                         設計・レビュー時に確認されなかった
                         → Alationにメタ情報がなく、ビューの粒度情報が不明だった
```

Layer A が直接の混入経路であり、Layer B がそれを見逃した要因。  
議事録は Layer B に焦点を当てているが、Layer A（同ファイル内の実装パターンとの不整合）の分析が欠けている。

---

## 6. テストで検出できなかった理由

- `VW_STARTDASH_MEDIA_CONTACT` に対するAlation CSVがなく、ビュー粒度（縦持ち）がドキュメント化されていなかった
- リポジトリ内のテスト（`tests/design/`）は SQL構造の設計検討用ファイルであり、Snowflakeへの実行・件数検証は行っていない
- メディア接触状況フィルタを**複数選択した場合**にのみ重複が顕在化するため、単一メディア選択・未選択のテストでは検出されない
- 100万〜数千万件規模の出力では件数の異常をExcel等で手動確認できない

---

## 7. 再発防止への示唆（調査ベース）

### 即効性が高い対策

1. **`VW_STARTDASH_MEDIA_CONTACT` のDISTINCT修正**（未修正であれば早急に対応）
2. **同ファイル内の他サブクエリとの整合確認**をコードレビューのチェック項目に追加

### 設計・プロセス面の対策

3. **縦持ちビューをJOINする際の実装パターンを標準化**：`SELECT DISTINCT <id_col> FROM <縦持ちビュー> WHERE ...` を定型パターンとしてドキュメント化
4. **Alationメタデータ未登録ビューの実装時アラート**：メタ情報がないビューを新規実装に使う際はAlation確認またはSELECT COUNT比較を必須とする

### スキル②（HTタスク）との関係

会議で合意された「アプリSQLのDISTINCT有無で件数が変わるかチェックするスキル」は、今回の `query_helper.py:1773` の問題を事後的に検出する手段として有効。  
ただし、今回のバグは「複数メディア選択時のみ」発現するため、検証クエリはメディア1件選択・複数選択の両パターンを実行して比較する必要がある。

---

## 8. 調査で確認したファイル

| ファイル | 用途 |
|---|---|
| `app/lib/clazz/query_helper.py` | SQLクエリ生成のコア。バグ箇所（1771–1783行） |
| `app/lib/startdash_components_ver2/media_app_usage.py` | メディア選択UIとSQL値への変換ロジック |
| `app/tests/lib/alation_VW_STARTDASH_BASIC_ATTRIBUT.csv` | BASIC_ATTRIBUTEのAlation情報（MEDIA_CONTACT版は存在しない） |
| `app/tests/lib/【View定義書】VW_StartDash_基本属性.md` | BASIC_ATTRIBUTEのビュー定義（MEDIA_CONTACT版は存在しない） |
| `app/tests/design/test_sql*.sql` | SQL設計検討用ファイル（実行・件数検証は行っていない） |
