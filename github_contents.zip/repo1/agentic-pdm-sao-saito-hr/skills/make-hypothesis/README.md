# make-hypothesis

## 概要

実現したい機能や改善テーマをインプットに、ユーザーニーズ・定量データ・ベストプラクティス・ユーザー観点を4エージェントが並列調査し、「なぜその機能が必要か」「ユーザーにどう喜ばれるか」の根拠に基づく仮説を自動生成するDiscoveryスキルです。

## メリット

- 4つの専門エージェントが並列で調査・評価し、多角的な仮説を生成
- 背景・世の中事例・ユーザー視点を統合した説得力のある仮説ドキュメントを自動作成
- 既存仮説との重複チェックも自動で実施

## 対象者

- 実現したい機能はあるが、ユーザーに喜ばれるか根拠を整理したい方
- 仮説立てをどこから始めればいいか迷っている方

## 前提環境・依存コンポーネント

| 依存コンポーネント | 説明 |
|---|---|
| `ux-researcher` エージェント | ユーザーニーズ・定性インサイト分析を担当 |
| `data-analyst` エージェント | 定量データ分析・KPI評価を担当 |
| `desktop-researcher` エージェント | ベストプラクティス・技術動向調査を担当 |
| `user-persona` エージェント | ユーザー視点での仮説評価を担当 |
| `Agent` ツール | サブエージェントの並列呼び出しに必要。Claude Codeのデフォルト環境で利用可能 |
| `hypotheses/` ディレクトリ | 仮説ドキュメントの保存先。存在しない場合は自動作成されます |

> 上記4エージェントはすべて `discovery-agents-sao-saito-hr` に同梱されています。合わせて導入してください。

## ディレクトリ構成

```bash
make-hypothesis-sao-saito-hr/
├── skills/
│   └── make-hypothesis/
│       └── SKILL.md   # スキル本体
└── README.md          # 本ファイル
```

## 使い方

### 導入手順

#### 特定のリポジトリだけで使いたい場合 → `.claude/skills/` に配置

```bash
cd path/to/your-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/make-hypothesis-sao-saito-hr"

mkdir -p .claude/skills/make-hypothesis
cp -r ${KNOWLEDGE_DIR}/skills/make-hypothesis/ .claude/skills/make-hypothesis/
```

#### すべてのプロジェクトで使いたい場合 → `~/.claude/skills/` に配置

```bash
KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/make-hypothesis-sao-saito-hr"

mkdir -p ~/.claude/skills/make-hypothesis
cp -r ${KNOWLEDGE_DIR}/skills/make-hypothesis/ ~/.claude/skills/make-hypothesis/
```

> **注意**: `ux-researcher`・`data-analyst`・`desktop-researcher`・`user-persona` の4エージェントも合わせて導入してください。導入方法は `discovery-agents-sao-saito-hr/README.md` を参照してください。

### 起動方法

Claude Codeのチャット欄に以下のいずれかを入力してください。

- `/make-hypothesis`
- 「仮説を作って」
- 「〇〇についての仮説を立てて」

### 成果物

| 成果物 | 説明 |
|---|---|
| 仮説ドキュメント（Markdown） | `hypotheses/` 配下に保存される仮説ファイル。背景・根拠・検証方法を含む |

---

詳しい導入手順は[リポジトリのREADME](../../README.md)もご参照ください。
