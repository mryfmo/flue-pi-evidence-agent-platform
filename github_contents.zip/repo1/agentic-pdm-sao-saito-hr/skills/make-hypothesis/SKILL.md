---
name: make-hypothesis
description: |
  4エージェント並列調査から仮説ドキュメント原稿を生成してhypotheses/に保存するSkill。
  「仮説を作って」「/make-hypothesis」で呼び出し可能。
---

# /make-hypothesis

**概要**: ユーザーニーズ・定量データ・ベストプラクティス・ユーザー観点を統合し、仮説ドキュメント原稿を生成して `hypotheses/` に自動保存します。

**処理フロー**:

0. **テーマと参照先の確認**（Lead PdM 自身）

   まず仮説のテーマをユーザーに確認する：
   ```
   仮説のテーマを教えてください。
   ```

   `{THEME}` が確定したら、参照先パスを確認する：
   ```
   参照先パスを確認します（変更不要なら「OK」と返信してください）：

   | 対象       | デフォルトパス              |
   |------------|----------------------------|
   | needs-lake | research/needs-lake.md     |
   | insights   | research/insights/         |

   変更する場合は「needs-lake: <パス>, insights: <パス>」の形式で入力してください。
   ※ 片方のみ変更する場合は変更する対象のみ記入してください（例: 「needs-lake: workspace/test/needs-lake.md」）。
   ```

   ユーザーの入力に基づき `{NEEDS_LAKE_PATH}`・`{INSIGHTS_DIR}` を確定する。
   `{INSIGHTS_DIR}` は末尾スラッシュを持つこと（例: `research/insights/`）。末尾スラッシュがない場合は自動で付与する。
   参照先ディレクトリが存在しない場合は `mkdir -p` で作成する。

   `hypotheses/` が存在する場合、配下を glob して `{THEME}` をファイル名に**完全一致で含む**既存仮説ファイルを検索する。
   - 一致するファイルが**ある場合**: ユーザーに提示し「続行」の返答があった場合のみ次のSTEPへ進む:
     ```
     既存仮説の確認: 以下のファイルが存在します。
     - hypotheses/1.Discovery/〇〇_仮説_YYYYMMDD.md
     重複している場合は中断します。続行する場合は「続行」と返信してください。
     ```
   - 一致するファイルが**ない場合**: そのまま次のSTEPへ進む。

1. **ux-researcher**（@.claude/agents/ux-researcher.md）をAgentツールで呼び出し: `{NEEDS_LAKE_PATH}` の未検証要望・セグメントパターンを調査
2. **data-analyst**（@.claude/agents/data-analyst.md）をAgentツールで呼び出し: `data/usage_logs/` の最新データを分析
3. **desktop-researcher**（@.claude/agents/desktop-researcher.md）をAgentツールで呼び出し: 仮説テーマのベストプラクティス・実装参考を調査
4. **user-persona**（@.claude/agents/user-persona.md）をAgentツールで呼び出し: 仮説案のユーザー適合度を一人称視点で評価
5. Lead PdM が4つの調査結果を統合し、`.claude/rules/hypothesis-rules.md` の必須セクション構成に準拠した仮説ドキュメント原稿を生成する
   - 統合サマリー（各エージェントの調査要点をまとめたもの）も併せて作成する
   - 保存先フォルダ（フェーズ）をテーマから推定し、ユーザーに提示する
   - `{NEEDS_LAKE_PATH}` または `{INSIGHTS_DIR}` が空または存在しない場合、引用が必要な箇所に「（ユーザーインタビュー引用予定）」のプレースホルダーを明示する

   **統合マトリクス**（各エージェントの出力を仮説ドキュメントのどのセクションに反映するか）:

   | エージェント | 主な出力 | 反映先セクション |
   |-------------|---------|----------------|
   | `ux-researcher` | 未検証要望・セグメント別パターン | **なぜ「XXX」なのか（ユーザーの Why）**・**課題仮説** |
   | `data-analyst` | KPI達成状況・定量トレンド | **検証テーブル**（定量目標値・期限）・**まとめ表** |
   | `desktop-researcher` | ベストプラクティス・実装事例 | **ソリューション仮説**・**なぜ（技術の Why）**・**どのように検証するか** |
   | `user-persona` | ユーザー適合度評価・優先度差 | **価値仮説**・**課題仮説**（セグメント別優先度）・**Go/No-Go 判定基準** |

   **矛盾解決ルール**（エージェント間で判断が相反する場合）:
   - 定性情報（`user-persona`・`ux-researcher`）を優先し、定量情報（`data-analyst`）で根拠を補う
   - 例: `ux-researcher` と `user-persona` でセグメント優先度が相反する場合は、`user-persona` の一人称評価を採用し、`data-analyst` の数値で妥当性を検証する
6. ユーザーに統合サマリー + 仮説ドキュメント原稿（全文）を提示して承認を得る:
   ```
   【統合サマリー】
   - ux-researcher: （調査要点）
   - data-analyst: （調査要点）
   - desktop-researcher: （調査要点）
   - user-persona: （調査要点）

   【仮説ドキュメント原稿】
   （hypothesis-rules.md 準拠の全文）

   保存予定パス: hypotheses/1.Discovery/〇〇_仮説_YYYYMMDD.md

   この内容で保存してよいですか？修正があればコメントしてください。
   ```
7. 承認後、Lead PdM が仮説ファイルを自動保存する
   - 保存先: `hypotheses/[フェーズ]/[テーマ]_仮説_[YYYYMMDD].md`
   - フェーズフォルダは `hypothesis-rules.md` に従う
   - 完了報告:
     ```
     ✅ hypotheses/1.Discovery/〇〇_仮説_YYYYMMDD.md を保存しました
     次のステップ: 検証を開始するには仮説ドキュメントの「検証テーブル」を埋めてください
     ```
   - 修正コメントがあった場合は原稿を再生成し、再度承認フローを実行する
