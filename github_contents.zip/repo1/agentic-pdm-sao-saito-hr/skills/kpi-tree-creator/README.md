# KGI・KPIツリー設計 ナレッジ

## 概要

価値マップ・課題分析・ToBeコンセプトから、KGI（重要目標達成指標）とKPIツリーを設計し、ブラウザで確認できる垂直SVGグラフのHTMLビューワーとして自動生成する Claude Code Skill です。

「実行 → 提供 → 行動変容 → アウトカム → 事業成果」という因果連鎖でKPIを設計し、各KPIのベースライン・ターゲット値・測定方法・レビュー頻度まで定義します。

本スキルは `operation-map-creator` → `issue-map-creator` → `product-concept-creator` → **`kpi-tree-creator`** という一連のPlan作業フローの第4ステップです。

## メリット

- 「KPIは何を測ればいいか」を因果連鎖（kai→product→behavior→outcome→business）で体系的に設計できる
- KGIから末端KPIまでの貢献メカニズムを `contribution_reason` で明示するため、チームの共通認識を作りやすい
- ベースライン・ターゲット値・測定方法・データソースまで定義するため、すぐに計測を開始できる状態になる
- 成果物（data.json）を次のステップ（`usm-creator` 等）への入力としてそのまま使えるため、分析の流れが途切れない

## 対象者

- 「ビジョンや価値はまとまったが、何をKPIにすればいいかわからない」方
- KPIとKGIの因果関係を整理して、チームに説明したい方
- VibeCodingで実装するにあたり、「アプリが成功しているかどうかを何で測るか」を明確にしたい方

## ディレクトリ構成

```bash
kpi-tree-creator-sao-saito-hr/
├── skills/
│   └── kpi-tree-creator/
│       ├── SKILL.md                    # スキル定義（メイン）
│       ├── scripts/
│       │   └── generate.sh             # HTML生成スクリプト
│       ├── assets/
│       │   └── template.html           # HTMLビューワーテンプレート
│       └── references/
│           └── kpi.schema.json         # KGI/KPI定義スキーマ
└── README.md                           # 本ファイル
```

## 使い方

### 1. 導入手順

`skills/kpi-tree-creator/` フォルダを、自分のプロジェクトの `.claude/skills/` または `~/.claude/skills/` にコピーしてください。

#### 特定のリポジトリだけで使いたい場合 → `.claude/skills/` に配置

```bash
# 使いたいリポジトリのルートに移動
cd path/to/pochi-xxx-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/kpi-tree-creator-sao-saito-hr"

mkdir -p .claude/skills
cp -r ${KNOWLEDGE_DIR}/skills/kpi-tree-creator .claude/skills/
```

#### すべてのプロジェクトで使いたい場合 → `~/.claude/skills/` に配置

```bash
cd path/to/pochi-developing-knowledge-for-vibecoding-repository
KNOWLEDGE_DIR="001-requirements/kpi-tree-creator-sao-saito-hr"

mkdir -p ~/.claude/skills
cp -r ${KNOWLEDGE_DIR}/skills/kpi-tree-creator ~/.claude/skills/
```

### 2. 起動方法

導入後、Claude Code のチャット欄に以下を入力するだけで起動します。

```
/kpi-tree-creator
```

または以下のように話しかけても起動します。

- 「KPIツリーを作って」
- 「KGIを設計して」
- 「Step4を進めて」

### 3. 成果物

スキル実行後、プロジェクト内の指定ディレクトリに以下のファイルが生成されます。

| ファイル | 内容 | 利用用途 |
|---------|------|---------|
| `viewer.html` | KGI・KPIツリー（垂直SVGグラフ）＋総合判定レビューUIを含む完全自己完結HTML | ブラウザで開いてKPIツリーをチームでレビューする |
| `data.json` | KGI/KPI全定義のSSoT（Single Source of Truth） | 別セッションでの再開、または次スキル（usm-creator等）への入力として使用する |
| `next_actions.md` | 不明点・追加調査リスト | 計測基盤の整備・データソース確認などの次アクション把握に使用する |

### 4. 利用フロー

このスキルの典型的な利用フローは以下の通りです。

1. `product-concept-creator` の成果物（`data.json`）を用意する（なくても対話形式で進められる）
2. スキルを実行し、KGI・KPIツリーを設計する（因果連鎖の5レイヤーで体系的に設計）
3. `viewer.html` が生成されたらブラウザで開き、KPIツリーをレビューする
4. 修正したい点があれば Claude Code にフィードバックして再生成を依頼する。満足いくまで繰り返す
5. 「OK」と伝えると、最終成果物（`viewer.html` / `data.json` / `next_actions.md`）が出力される

### 5. KPIレイヤーの構造

本スキルは以下の5レイヤーでKPIを設計します。

| レイヤー | 定義 | 例 |
|---------|------|----|
| `business`（事業成果） | ビジネス上の最終結果。KGIと直結する遅行指標 | 売上成長率・NPS・チャーン率 |
| `outcome`（ユーザーアウトカム） | ユーザーが実際に得た価値・状態変化 | タスク達成率・工数削減率・満足度 |
| `behavior`（行動変容） | ユーザーが実際に取る行動の変化 | 機能利用率・継続率・定着率 |
| `product`（提供品質） | プロダクトが提供する機能・品質 | レスポンス速度・出力品質スコア |
| `kai`（実行指標） | チームの日次・週次の実行指標 | 入力件数/日・対応リードタイム |

---

詳しい導入手順は[リポジトリのREADME](../../README.md)もご参照ください。
