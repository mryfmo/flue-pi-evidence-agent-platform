# interview-prep

## 概要

明らかにしたい問い・リサーチ目的をインプットに、インタビュー実行の準備（リサーチ計画・インタビューガイド・実施注意事項）を生成するDiscoveryスキルです。

「何を検証すべきか」の問い選定は他スキル（`/make-hypothesis` 等）に委ねており、このスキルは「インタビュー実行の準備」にフォーカスします。

## メリット

- リサーチ目的を伝えるだけでインタビューガイドを自動生成
- 当日そのまま使えるHTMLガイドも出力
- 「何を聞けばいいか」の整理にかかる時間を大幅に短縮

## 対象者

- ユーザーインタビューを初めて設計する方
- インタビュー前の準備を効率化したい方

## 前提環境・依存コンポーネント

| 依存コンポーネント | 説明 |
|---|---|
| `ux-researcher` エージェント | UXリサーチ専門知見を持つサブエージェント。`discovery-agents-sao-saito-hr` と合わせて導入してください |
| `Agent` ツール | サブエージェント呼び出しに必要。Claude Codeのデフォルト環境で利用可能 |
| `interview-guide-template.html` | インタビューガイドのHTMLテンプレート。スキルと同梱 |

## ディレクトリ構成

```bash
interview-prep-sao-saito-hr/
├── skills/
│   └── interview-prep/
│       ├── SKILL.md                      # スキル本体
│       └── interview-guide-template.html # インタビューガイドHTMLテンプレート
└── README.md                             # 本ファイル
```

## 使い方

### 導入手順

#### 特定のリポジトリだけで使いたい場合 → `.claude/skills/` に配置

```bash
cd path/to/your-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/interview-prep-sao-saito-hr"

mkdir -p .claude/skills/interview-prep
cp -r ${KNOWLEDGE_DIR}/skills/interview-prep/ .claude/skills/interview-prep/
```

#### すべてのプロジェクトで使いたい場合 → `~/.claude/skills/` に配置

```bash
KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/interview-prep-sao-saito-hr"

mkdir -p ~/.claude/skills/interview-prep
cp -r ${KNOWLEDGE_DIR}/skills/interview-prep/ ~/.claude/skills/interview-prep/
```

> **注意**: `ux-researcher` エージェントも合わせて導入してください。導入方法は `discovery-agents-sao-saito-hr/README.md` を参照してください。

### 起動方法

Claude Codeのチャット欄に以下のいずれかを入力してください。

- `/interview-prep`
- 「リサーチ設計して」
- 「インタビューガイドを作って」
- 「インタビュー計画を立てて」

### 成果物

| 成果物 | 説明 |
|---|---|
| リサーチ計画（Markdown） | 検証目的・問い・対象者・スケジュールをまとめた計画書 |
| インタビューガイド（HTML） | 当日使えるインタビュー質問リスト |

---

詳しい導入手順は[リポジトリのREADME](../../README.md)もご参照ください。
