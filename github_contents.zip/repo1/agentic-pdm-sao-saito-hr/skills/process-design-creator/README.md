# process-design-creator

## 概要

業務課題・ペインを起点にTo-Be業務プロセスを設計し、As-Isからの変化・業務課題→価値の実現・ビジョン達成をインタラクティブHTMLビューワーとして出力するスキルです。

Planningフェーズ④「To-Be業務プロセス設計」に対応します。

## メリット

- 業務課題IDとビジョンを起点に、AI対話でTo-Beプロセスを整理・壁打ちできる
- As-Is/To-Be比較・課題対応状況を1画面で確認・共有できるHTMLビューワーを生成
- 後続スキル（`usm-creator`）に渡すdata.jsonを自動生成し、ストーリー設計をスムーズに引き継げる
- 評価エージェントによる品質チェックで成果物の精度を担保

## 対象者

- 業務課題の構造化が終わり、次にTo-Be業務プロセスを設計したい方
- As-Is/To-Be比較をHTMLで可視化してチームに共有したい方

## 前提環境・依存コンポーネント

| 依存コンポーネント | 説明 |
|---|---|
| `ux-researcher` エージェント | ペイン情報の整理・構造化を担うサブエージェント。`discovery-agents-sao-saito-hr` と合わせて導入してください |
| `Agent` ツール・`Bash` ツール | サブエージェント呼び出し・スクリプト実行に必要。Claude Codeのデフォルト環境で利用可能 |
| `CLAUDE_SKILL_DIR` 環境変数 | スキルのディレクトリパスを指す環境変数。Claude Codeが自動で設定します |
| 前段スキルの成果物（任意） | `operation-map-creator`・`issue-map-creator`・`product-concept-creator` の出力があるとより精度が高まります。なくても対話で補完して実行可能です |

## ディレクトリ構成

```bash
process-design-creator-sao-saito-hr/
├── skills/
│   └── process-design-creator/
│       ├── SKILL.md                        # スキル本体
│       ├── assets/
│       │   └── template.html               # HTMLビューワーテンプレート
│       ├── scripts/
│       │   └── generate.sh                 # data.json埋め込みスクリプト
│       └── references/
│           └── process-design.schema.json  # To-Beプロセス JSONスキーマ
└── README.md                               # 本ファイル
```

## 使い方

### 導入手順

#### 特定のリポジトリだけで使いたい場合 → `.claude/skills/` に配置

```bash
cd path/to/your-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/process-design-creator-sao-saito-hr"

mkdir -p .claude/skills/process-design-creator
cp -r ${KNOWLEDGE_DIR}/skills/process-design-creator/ .claude/skills/process-design-creator/
```

#### すべてのプロジェクトで使いたい場合 → `~/.claude/skills/` に配置

```bash
KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/process-design-creator-sao-saito-hr"

mkdir -p ~/.claude/skills/process-design-creator
cp -r ${KNOWLEDGE_DIR}/skills/process-design-creator/ ~/.claude/skills/process-design-creator/
```

> **注意**: `ux-researcher` エージェントも合わせて導入してください。導入方法は `discovery-agents-sao-saito-hr/README.md` を参照してください。

### 起動方法

Claude Codeのチャット欄に以下のいずれかを入力してください。

- `/process-design-creator`
- 「To-Be業務プロセスを設計して」
- 「業務プロセス設計して」

### 成果物

| 成果物 | 説明 |
|---|---|
| To-Be業務プロセスビューワー（HTML） | ビジョンサマリー・全ステップのAs-Is/To-Be比較・FBダウンロード機能を含むインタラクティブビューワー |
| data.json | To-Beプロセス全定義を含むSSoT。`usm-creator` が参照して後続のストーリー設計に使用 |

---

詳しい導入手順は[リポジトリのREADME](../../README.md)もご参照ください。
