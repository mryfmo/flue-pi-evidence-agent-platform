# プロダクトコンセプト設計 ナレッジ

## 概要

課題分析結果から「誰が・どんな状況で困っているか → 提供する価値 → 価値の実現順序 → その先のビジョン」という一貫したナラティブを設計し、プロダクトコンセプトをブラウザで確認できるHTMLビューワーとして自動生成する Claude Code Skill です。

ナラティブ構造（読み順）：

```
PROBLEM × WHO  — こんな課題がある。こういう人が困っている。
    ↓ 「だから」
VALUE          — この価値を届ける。
    ↓ 「こう実現する」
HOW (STAGES)   — この順序で積み上げる。
    ↓ 「その先に」
VISION         — こういう世界を実現したい。
```

本スキルは `operation-map-creator` → `issue-map-creator` → **`product-concept-creator`** → `kpi-tree-creator` という一連のPlan作業フローの第3ステップです。

## メリット

- WHO×SITUATIONから出発することで、「誰のための価値か」が明確なプロダクトコンセプトを設計できる
- 価値の実現順序（HOW STAGES）を定義するため、何を先に作るべきかの優先順位が明確になる
- 成果物（`product-concept.json`）をそのまま `kpi-tree-creator` / `tobe-operation-creator` / `usm-creator` への入力として使えるため、分析の流れが途切れない

## 対象者

- 「課題はわかったが、何を作ればいいか・誰のために作るか」を整理したい方
- プロダクトのビジョンや提供価値をチームで言語化・共有したい方
- VibeCodingで実装するにあたり、「どんな価値を提供するアプリか」を明確にしたい方

## ディレクトリ構成

```bash
product-concept-creator-sao-saito-hr/
├── skills/
│   └── product-concept-creator/
│       ├── SKILL.md                         # スキル定義（メイン）
│       ├── scripts/
│       │   └── generate.sh                  # HTML生成スクリプト
│       ├── assets/
│       │   └── template.html                # HTMLビューワーテンプレート
│       └── references/
│           └── product-concept.schema.json  # プロダクトコンセプト定義スキーマ
└── README.md                                # 本ファイル
```

## 使い方

### 1. 導入手順

`skills/product-concept-creator/` フォルダを、自分のプロジェクトの `.claude/skills/` または `~/.claude/skills/` にコピーしてください。

#### 特定のリポジトリだけで使いたい場合 → `.claude/skills/` に配置

```bash
# 使いたいリポジトリのルートに移動
cd path/to/pochi-xxx-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/product-concept-creator-sao-saito-hr"

mkdir -p .claude/skills
cp -r ${KNOWLEDGE_DIR}/skills/product-concept-creator .claude/skills/
```

#### すべてのプロジェクトで使いたい場合 → `~/.claude/skills/` に配置

```bash
cd path/to/pochi-developing-knowledge-for-vibecoding-repository
KNOWLEDGE_DIR="001-requirements/product-concept-creator-sao-saito-hr"

mkdir -p ~/.claude/skills
cp -r ${KNOWLEDGE_DIR}/skills/product-concept-creator ~/.claude/skills/
```

### 2. 起動方法

導入後、Claude Code のチャット欄に以下を入力するだけで起動します。

```
/product-concept-creator
```

または以下のように話しかけても起動します。

- 「プロダクトコンセプトを作って」
- 「価値マップを作りたい」
- 「ビジョンを策定して」

### 3. 成果物

スキル実行後、プロジェクト内の指定ディレクトリに以下のファイルが生成されます。

| ファイル | 内容 | 利用用途 |
|---------|------|---------|
| `viewer.html` | ナラティブ構造に沿った縦スクロール型インタラクティブビューワー（コメント機能付き） | ブラウザで開いてプロダクトコンセプトをチームでレビューする |
| `product-concept.json` | 全定義のSSoT（Single Source of Truth） | 別セッションでの再開、または `kpi-tree-creator` / `tobe-operation-creator` / `usm-creator` への入力として使用する |

### 4. 利用フロー

このスキルの典型的な利用フローは以下の通りです。

1. `issue-map-creator` の成果物（`issue-map.json`）を用意する（なくても対話形式で進められる）
2. スキルを実行し、WHO×SITUATION / PROBLEM / VALUE / HOW / VISION のたたき台をClaudeが自動生成する
3. セクションごとにClaudeと対話して磨き込む
4. `viewer.html` が生成されたらブラウザで開き、プロダクトコンセプトを確認する
5. 修正したい点があれば Claude Code にフィードバックして再生成を依頼する。満足いくまで繰り返す
6. 「OK」と伝えると、最終成果物（`viewer.html` / `product-concept.json`）が出力される
7. 出力された `product-concept.json` を `kpi-tree-creator` に渡して次のステップへ進む

---

詳しい導入手順は[リポジトリのREADME](../../README.md)もご参照ください。
