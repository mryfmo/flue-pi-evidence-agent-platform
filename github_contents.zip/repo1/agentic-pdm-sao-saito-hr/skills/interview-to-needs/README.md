# interview-to-needs

## 概要

ユーザーインタビューのVTT書き起こし・Markdownメモ・テキストフィードバックを受け取り、議事録への変換・needs-lake（要望蓄積ファイル）への追記・インサイトメモの作成までを一括で行うDiscoveryスキルです。

## メリット

- インタビュー後の議事録作成・要望メモ転記を自動化
- needs-lake への追記形式に自動整形するため、転記ミスや漏れを防止
- VTTファイルを渡すだけで議事録変換〜インサイト抽出まで一気通貫で完了

## 対象者

- インタビュー後の議事録作成・要望メモ転記を効率化したい方
- needs-lake を継続的に蓄積・管理したい方

## 前提環境・依存コンポーネント

| 依存コンポーネント | 説明 |
|---|---|
| `ux-researcher` エージェント | インサイト抽出・needs-lake分類を担当。`discovery-agents-sao-saito-hr` と合わせて導入してください |
| `vtt-to-minutes` スキル（任意） | VTTファイルをMarkdown議事録に変換するスキル。存在する場合は自動で委譲します。ない場合はこのスキル内で直接変換します |
| `needs-lake.md` | 要望を蓄積するファイル。存在しない場合は新規作成されます |
| `research/insights/` ディレクトリ | インサイトメモの保存先。存在しない場合は自動作成されます |
| VTTファイル形式 | WebVTT標準形式（タイムスタンプ: `00:00:00.000 --> 00:00:00.000`）を想定 |

## ディレクトリ構成

```bash
interview-to-needs-sao-saito-hr/
├── skills/
│   └── interview-to-needs/
│       └── SKILL.md   # スキル本体
└── README.md          # 本ファイル
```

## 使い方

### 導入手順

#### 特定のリポジトリだけで使いたい場合 → `.claude/skills/` に配置

```bash
cd path/to/your-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/interview-to-needs-sao-saito-hr"

mkdir -p .claude/skills/interview-to-needs
cp -r ${KNOWLEDGE_DIR}/skills/interview-to-needs/ .claude/skills/interview-to-needs/
```

#### すべてのプロジェクトで使いたい場合 → `~/.claude/skills/` に配置

```bash
KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/interview-to-needs-sao-saito-hr"

mkdir -p ~/.claude/skills/interview-to-needs
cp -r ${KNOWLEDGE_DIR}/skills/interview-to-needs/ ~/.claude/skills/interview-to-needs/
```

> **注意**: `ux-researcher` エージェントも合わせて導入してください。導入方法は `discovery-agents-sao-saito-hr/README.md` を参照してください。

### 起動方法

Claude Codeのチャット欄に以下のいずれかを入力してください。

- `/interview-to-needs`
- 「インタビューをMarkdownにして」
- 「needs-lakeに追記して」
- 「フィードバックを取り込んで」

VTTファイルやMarkdownメモを添付して起動するとスムーズです。

### 成果物

| 成果物 | 説明 |
|---|---|
| Markdown議事録 | VTTから変換したインタビュー議事録 |
| needs-lake追記 | 抽出した要望をneeds-lake.mdに追記 |
| インサイトメモ | `research/insights/` 配下に保存されるインサイトメモ |

---

詳しい導入手順は[リポジトリのREADME](../../README.md)もご参照ください。
