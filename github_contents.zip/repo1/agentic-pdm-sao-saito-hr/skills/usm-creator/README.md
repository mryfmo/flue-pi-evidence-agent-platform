# usm-creator

## 概要

KPIツリー・価値マップ・To-Beプロセスの成果物をもとに、ユーザーストーリーマッピング（USM）とリリースラインを導出し、ブラウザでレビュー・編集できるインタラクティブHTMLビューワーとして出力するスキルです。

「次に何を作るか」の意思決定に必要な、実現すべきユースケースと機能のマッピングを可視化します。

## メリット

- 目指す業務フローをもとに、実現すべきユースケースと機能を自動で洗い出し
- リリース優先順位をHTMLビューワーで可視化し、チームでのレビューが容易
- 評価エージェントによる品質チェックで成果物の精度を担保

## 対象者

- To-Be業務フローが決まり、次に実装する機能を整理したい方
- ユーザーストーリーマッピングをAIの力で効率化したい方

## 前提環境・依存コンポーネント

| 依存コンポーネント | 説明 |
|---|---|
| `ux-researcher` エージェント | ユーザーストーリー設計の専門知見を持つサブエージェント。`discovery-agents-sao-saito-hr` と合わせて導入してください |
| `user-persona` エージェント | ユーザー視点の評価を担うサブエージェント。同上 |
| `Agent` ツール・`Bash` ツール | サブエージェント呼び出し・スクリプト実行に必要。Claude Codeのデフォルト環境で利用可能 |
| `CLAUDE_SKILL_DIR` 環境変数 | スキルのディレクトリパスを指す環境変数。Claude Codeが自動で設定します |
| 前段スキルの成果物（任意） | `kpi-tree-creator`・`product-concept-creator`・`process-design-creator` の出力があるとより精度が高まります。なくても対話で補完して実行可能です |

## ディレクトリ構成

```bash
usm-creator-sao-saito-hr/
├── skills/
│   └── usm-creator/
│       ├── SKILL.md                    # スキル本体
│       ├── assets/
│       │   └── template.html           # HTMLビューワーテンプレート
│       ├── scripts/
│       │   └── generate.sh             # data.json埋め込みスクリプト
│       └── references/
│           └── usm.schema.json         # USM JSONスキーマ
└── README.md                           # 本ファイル
```

## 使い方

### 導入手順

#### 特定のリポジトリだけで使いたい場合 → `.claude/skills/` に配置

```bash
cd path/to/your-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/usm-creator-sao-saito-hr"

mkdir -p .claude/skills/usm-creator
cp -r ${KNOWLEDGE_DIR}/skills/usm-creator/ .claude/skills/usm-creator/
```

#### すべてのプロジェクトで使いたい場合 → `~/.claude/skills/` に配置

```bash
KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/usm-creator-sao-saito-hr"

mkdir -p ~/.claude/skills/usm-creator
cp -r ${KNOWLEDGE_DIR}/skills/usm-creator/ ~/.claude/skills/usm-creator/
```

> **注意**: `ux-researcher`・`user-persona` エージェントも合わせて導入してください。導入方法は `discovery-agents-sao-saito-hr/README.md` を参照してください。

### 起動方法

Claude Codeのチャット欄に以下のいずれかを入力してください。

- `/usm-creator`
- 「ストーリーマッピングを作って」
- 「USMを作って」

### 成果物

| 成果物 | 説明 |
|---|---|
| ユーザーストーリーマップ（HTML） | アクティビティ・ユーザータスク・機能をマッピングしたインタラクティブビューワー |

---

詳しい導入手順は[リポジトリのREADME](../../README.md)もご参照ください。
