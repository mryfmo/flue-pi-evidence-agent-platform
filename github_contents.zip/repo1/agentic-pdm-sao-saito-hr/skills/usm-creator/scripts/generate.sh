#!/usr/bin/env bash
# usm-creator: embeddedData を差し替えてHTMLを生成する
set -euo pipefail

TEMPLATE=""
OUTPUT=""
DATA_FILE=""

while [[ $# -gt 0 ]]; do
  case $1 in
    --template) TEMPLATE="$2"; shift 2 ;;
    --output)   OUTPUT="$2"; shift 2 ;;
    --data)     DATA_FILE="$2"; shift 2 ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac
done

if [[ -z "$OUTPUT" ]]; then
  echo "Usage: $0 --template <template_file> --output <html_file> [--data <json_file>]" >&2
  exit 1
fi

if [[ -z "$TEMPLATE" ]]; then
  echo "ERROR: --template is required" >&2
  exit 1
fi

# --data 未指定の場合は出力ディレクトリの data.json を使う
if [[ -z "$DATA_FILE" ]]; then
  DATA_FILE="$(dirname "$OUTPUT")/data.json"
fi

if [[ ! -f "$DATA_FILE" ]]; then
  echo "ERROR: Data file not found: $DATA_FILE" >&2
  exit 1
fi

cp "$TEMPLATE" "$OUTPUT"

python3 - "$OUTPUT" "$DATA_FILE" <<'PYEOF'
import sys, re, json

html_path = sys.argv[1]
json_path = sys.argv[2]

with open(html_path, 'r', encoding='utf-8') as f:
    content = f.read()

with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

pattern = r'(const embeddedData\s*=\s*)\{[\s\S]*?\};'
m = re.search(pattern, content)
if not m:
    print("ERROR: embeddedData block not found in template", file=sys.stderr)
    sys.exit(1)
new_content = content[:m.start()] + 'const embeddedData = ' + json.dumps(data, ensure_ascii=False, indent=2) + ';' + content[m.end():]

with open(html_path, 'w', encoding='utf-8') as f:
    f.write(new_content)

print(f"Generated: {html_path}")
PYEOF
