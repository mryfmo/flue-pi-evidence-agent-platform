# 課題構造化・優先度付け ナレッジ

## 概要

インタビュー書き起こし・業務フロー分析結果・課題リストから、業務課題をPdM視点で構造化・優先度付けし、ブラウザで確認できる課題因果関係ツリーを自動生成する Claude Code Skill です。

`operation-map-creator` で整理した業務フローを入力として受け取り、各課題の根本原因（5Why分析）・KPI影響・推奨施策をインタラクティブHTMLビューワーとして出力します。

本スキルは `operation-map-creator` → **`issue-map-creator`** → `product-concept-creator` → `kpi-tree-creator` という一連のPlan作業フローの第2ステップです。

## メリット

- 「課題が多くてどこから手をつければいいかわからない」を解消し、PdM視点での優先度付けができる
- 5Why分析と因果関係ツリーで根本原因を可視化できるため、表面的な対症療法ではなく本質的な施策を立案できる
- 各課題のKPI影響・推奨施策がHTMLビューワーで一覧確認できるため、チームへの説明・合意形成がしやすい
- 成果物（data.json）をそのまま次の `product-concept-creator` への入力として使えるため、分析の流れが途切れない

## 対象者

- 業務課題を整理したいが、どこが本質的な問題かわからない方
- PdM視点で課題を構造化し、施策の優先度を議論したい方
- VibeCodingで実装するにあたり、「どの課題を解決するアプリか」を明確にしたい方

## ディレクトリ構成

```bash
issue-map-creator-sao-saito-hr/
├── skills/
│   └── issue-map-creator/
│       ├── SKILL.md                    # スキル定義（メイン）
│       ├── scripts/
│       │   └── generate.sh             # HTML生成スクリプト
│       ├── assets/
│       │   └── template.html           # HTMLビューワーテンプレート
│       └── references/
│           └── issue.schema.json       # 課題定義スキーマ
└── README.md                           # 本ファイル
```

## 使い方

### 1. 導入手順

`skills/issue-map-creator/` フォルダを、自分のプロジェクトの `.claude/skills/` または `~/.claude/skills/` にコピーしてください。

#### 特定のリポジトリだけで使いたい場合 → `.claude/skills/` に配置

```bash
# 使いたいリポジトリのルートに移動
cd path/to/pochi-xxx-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/issue-map-creator-sao-saito-hr"

mkdir -p .claude/skills
cp -r ${KNOWLEDGE_DIR}/skills/issue-map-creator .claude/skills/
```

#### すべてのプロジェクトで使いたい場合 → `~/.claude/skills/` に配置

```bash
cd path/to/pochi-developing-knowledge-for-vibecoding-repository
KNOWLEDGE_DIR="001-requirements/issue-map-creator-sao-saito-hr"

mkdir -p ~/.claude/skills
cp -r ${KNOWLEDGE_DIR}/skills/issue-map-creator ~/.claude/skills/
```

### 2. 起動方法

導入後、Claude Code のチャット欄に以下を入力するだけで起動します。

```
/issue-map-creator
```

または以下のように話しかけても起動します。

- 「課題分析して」
- 「PDMで課題を整理して」

### 3. 成果物

スキル実行後、プロジェクト内の指定ディレクトリに以下のファイルが生成されます。

| ファイル | 内容 | 利用用途 |
|---------|------|---------|
| `viewer.html` | 課題因果関係ツリー・KPI影響・推奨施策を含むインタラクティブビューワー | ブラウザで開いて課題構造を確認し、チームでレビューする |
| `data.json` | 全課題定義のSSoT（Single Source of Truth） | 別セッションでの再開、または `product-concept-creator` への入力として使用する |
| `next_actions.md` | 施策ロードマップ・追加調査リスト | 今後の施策実行計画の把握に使用する |

### 4. 利用フロー

このスキルの典型的な利用フローは以下の通りです。

1. `operation-map-creator` の成果物（`data.json`）を用意する（なくても対話形式で進められる）
2. スキルを実行し、`viewer.html` が生成されたらブラウザで開く
3. 課題因果関係ツリーと推奨施策の内容を確認する
4. 修正したい点があれば Claude Code にフィードバックして再生成を依頼する。満足いくまで繰り返す
5. 「OK」と伝えると、最終成果物（`viewer.html` / `data.json` / `next_actions.md`）が出力される
6. 出力された `data.json` を `product-concept-creator` に渡して次のステップへ進む

---

詳しい導入手順は[リポジトリのREADME](../../README.md)もご参照ください。
