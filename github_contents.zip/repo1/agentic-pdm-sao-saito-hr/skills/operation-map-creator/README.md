# 業務フロー自動生成 ナレッジ

## 概要

インタビューやヒアリングの文字起こし・議事録・業務マニュアルなど、手元にある資料を渡すだけで、ブラウザ上で確認・編集できる業務フロー図（スイムレーン図）を自動生成する Claude Code Skill です。

VTT・Markdown・テキストなど形式は問いません。資料がなくても対話形式でヒアリングしながら生成できます。

生成した業務フローはそのままAIへのコンテキストとして活用可能です。VibeCodingの実装フェーズで「この業務フローに沿って実装して」と渡せば、業務の流れを正確に理解したうえでの実装が期待できます。

## メリット

- 業務フロー図を作るのが面倒・後回しになりがちな方でも、資料を渡すだけで自動生成できる
- 「業務フローをコンテキストとしてAIに渡したいけど、どう伝えればいいかわからない」を解消できる
- 生成した業務フロー図をそのままVibeCodingのコンテキストとして使えるので、業務を正確に反映したアプリ開発ができる
- ブラウザ上で業務フロー図を確認・編集できるので、関係者へのレビューや共有がしやすい
- 業務内容からステークホルダー候補を自動提示するため、ヒアリング漏れを防ぎやすい
- セッションを中断しても data.json から再開できるため、長い業務でも分割して進められる

## 対象者

- 自分たちの業務をPochiアプリ化したいが、業務フローの整理が面倒で後回しになっている方
- VibeCodingで実装を進める際に、業務情報をAIにどう伝えればいいかわからない方

## ディレクトリ構成

```bash
operation-map-creator-sao-saito-hr/
├── skills/
│   └── operation-map-creator/
│       ├── SKILL.md                    # スキル定義（メイン）
│       ├── scripts/
│       │   └── generate.sh             # HTML生成スクリプト
│       ├── assets/
│       │   └── template.html           # HTMLビューワーテンプレート
│       └── references/
│           └── operation.schema.json   # 業務定義スキーマ
└── README.md                           # 本ファイル
```

## 使い方

### 1. 導入手順

`skills/operation-map-creator/` フォルダを、自分のプロジェクトの `.claude/skills/` または `~/.claude/skills/` にコピーしてください。

#### 特定のリポジトリだけで使いたい場合 → `.claude/skills/` に配置

```bash
# 使いたいリポジトリのルートに移動
cd path/to/pochi-xxx-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/operation-map-creator-sao-saito-hr"

mkdir -p .claude/skills
cp -r ${KNOWLEDGE_DIR}/skills/operation-map-creator .claude/skills/
```

#### すべてのプロジェクトで使いたい場合 → `~/.claude/skills/` に配置

```bash
cd path/to/pochi-developing-knowledge-for-vibecoding-repository
KNOWLEDGE_DIR="001-requirements/operation-map-creator-sao-saito-hr"

mkdir -p ~/.claude/skills
cp -r ${KNOWLEDGE_DIR}/skills/operation-map-creator ~/.claude/skills/
```

### 2. 起動方法

導入後、Claude Code のチャット欄に以下を入力するだけで起動します。

```
/operation-map-creator
```

または以下のように話しかけても起動します。

- 「業務フローをHTMLで出力して」
- 「業務ビューワーを作りたい」

### 3. 成果物

スキル実行後、`workspace/operation-map/` に以下のファイルが生成されます。

| ファイル | 内容 | 利用用途 |
|---------|------|---------|
| `viewer.html` | ブラウザで確認・編集できる業務フロー図（スイムレーン図） | ブラウザで開いて業務フロー内容を確認し、修正箇所を検討する |
| `data.json` | 業務フロー定義のSSoT（Single Source of Truth） | 別セッションでClaudeに渡すことで、業務フローの文脈をまるごと引き継いでブラッシュアップを続けられる |
| `next_actions.md` | 不明点・追加調査リスト（優先度付き） | 今後確認が必要な事項や改善ポイントの把握に使用する |
| `feedback.json` | HTMLの「📋 FB出力」ボタンで生成されるフィードバックファイル | Claude Code に渡して修正内容を伝え、viewer.html を再生成させる |

### 4. 利用フロー

このスキルの典型的な利用フローは以下の通りです。

1. スキルを実行し、`viewer.html` が生成されたらブラウザで開く
2. 業務フローの内容を確認する
3. 修正したい点があれば、該当の要素をクリックしてコメントを記載する
4. Viewer上の「📋 FB出力」ボタンで `feedback.json` を出力し、Claude Code に渡して再生成を依頼する。満足いくまで繰り返す
5. 「OK」と伝えると、最終成果物（`viewer.html` / `data.json` / `next_actions.md`）が出力される

> **セッション中断時の再開**: `data.json` を Claude Code に渡すと、前回の続きから再開できます。

#### viewer.html の開き方

スキル実行後、Claude Code のチャットに案内されたパスのファイルをダウンロードしてブラウザで開いてください。

またはファイルをブラウザウィンドウにドラッグ＆ドロップしても開けます。

---

詳しい導入手順は[リポジトリのREADME](../../README.md)もご参照ください。
