# AgenticPdM — スキル・エージェント集

Claude Code（Anthropic公式CLI）向けのスキル・エージェント群です。PdM（プロダクト開発管理）業務をAI駆動化するための、業務分析・仮説検証・ユーザーリサーチ支援ツールを提供します。

---

## 全コンポーネント一覧

| フェーズ | 種別 | 名前 | 概要 | エージェント依存 |
|---------|------|------|------|----------------|
| Planning | スキル | `operation-map-creator` | As-Is業務フロー自動生成（スイムレーン図） | なし（単体動作可） |
| Planning | スキル | `issue-map-creator` | 課題構造化・優先度付け（因果関係ツリー） | なし（単体動作可） |
| Planning | スキル | `product-concept-creator` | プロダクトコンセプト設計（WHO×価値×ビジョン） | なし（単体動作可） |
| Planning | スキル | `kpi-tree-creator` | KGI/KPIツリー設計（因果連鎖で設計） | なし（単体動作可） |
| Planning | スキル | `process-design-creator` | To-Be業務プロセス設計（スイムレーン図） | なし（単体動作可） |
| Planning | スキル | `usm-creator` | ユーザーストーリーマッピング自動生成 | なし（単体動作可） |
| Discovery | スキル | `interview-prep` | インタビュー設計・ガイド生成 | **ux-researcher** |
| Discovery | スキル | `interview-to-needs` | インタビュー→ニーズ・インサイト取り込み | **ux-researcher** |
| Discovery | スキル | `make-hypothesis` | 仮説自動生成（4エージェント並列調査） | **ux-researcher + data-analyst + desktop-researcher + user-persona（全4体）** |
| Discovery | エージェント | `ux-researcher` | ユーザーニーズ・定性インサイト分析専門家 | — |
| Discovery | エージェント | `data-analyst` | 定量データ分析・KPI評価専門家 | — |
| Discovery | エージェント | `desktop-researcher` | ベストプラクティス・技術動向リサーチ専門家 | — |
| Discovery | エージェント | `user-persona` | ターゲットユーザー視点評価専門家 | — |

---

## 一括ダウンロード（すべてまとめて導入）

AgenticPdMのスキル・エージェントをすべて導入する場合は、以下のコマンドを実行してください。

### 特定リポジトリだけで使いたい場合 → `.claude/` に配置

```bash
# 使いたいリポジトリのルートに移動
cd path/to/your-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/agentic-pdm-sao-saito-hr"

mkdir -p .claude/skills .claude/agents
cp -r ${KNOWLEDGE_DIR}/skills/* .claude/skills/
cp -r ${KNOWLEDGE_DIR}/agents/* .claude/agents/
```

### すべてのプロジェクトで使いたい場合 → `~/.claude/` に配置

```bash
KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/agentic-pdm-sao-saito-hr"

mkdir -p ~/.claude/skills ~/.claude/agents
cp -r ${KNOWLEDGE_DIR}/skills/* ~/.claude/skills/
cp -r ${KNOWLEDGE_DIR}/agents/* ~/.claude/agents/
```

---

## スキル個別ダウンロード

特定のスキルだけを導入する場合は、以下を参照してください。

### Planning スキル（単体で動作）

エージェントのインストールは不要です。

```bash
KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/agentic-pdm-sao-saito-hr"

# 例: operation-map-creator のみ導入
cp -r ${KNOWLEDGE_DIR}/skills/operation-map-creator .claude/skills/

# 他のスキルも同様（スキル名を変えるだけ）
# cp -r ${KNOWLEDGE_DIR}/skills/issue-map-creator .claude/skills/
# cp -r ${KNOWLEDGE_DIR}/skills/product-concept-creator .claude/skills/
# cp -r ${KNOWLEDGE_DIR}/skills/kpi-tree-creator .claude/skills/
# cp -r ${KNOWLEDGE_DIR}/skills/process-design-creator .claude/skills/
# cp -r ${KNOWLEDGE_DIR}/skills/usm-creator .claude/skills/
```

### Discovery スキル（エージェントが必要）

> **推奨**: Discovery スキルはエージェントとセットで動作するため、個別ではなくまとめてインストールすることを推奨します。→ [Discovery スキルをまとめて導入](#discovery-スキルをまとめて導入推奨)

個別にインストールする場合は以下を参照してください。

#### `interview-prep` / `interview-to-needs`（ux-researcher が必要）

```bash
KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/agentic-pdm-sao-saito-hr"

mkdir -p .claude/skills .claude/agents

cp -r ${KNOWLEDGE_DIR}/skills/interview-prep .claude/skills/
# または
cp -r ${KNOWLEDGE_DIR}/skills/interview-to-needs .claude/skills/

# 必須エージェントをインストール
cp ${KNOWLEDGE_DIR}/agents/ux-researcher.md .claude/agents/
```

#### `make-hypothesis`（全4エージェントが必要）

```bash
KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/agentic-pdm-sao-saito-hr"

mkdir -p .claude/skills .claude/agents

cp -r ${KNOWLEDGE_DIR}/skills/make-hypothesis .claude/skills/

# 必須エージェントをすべてインストール（4体すべて必要）
cp -r ${KNOWLEDGE_DIR}/agents/* .claude/agents/
```

---

## Discovery スキルをまとめて導入（推奨）

Discovery スキル（`interview-prep` / `interview-to-needs` / `make-hypothesis`）はエージェントとセットで動作します。3つのスキルと必要なエージェント4体をまとめてインストールすることを推奨します。

### 特定リポジトリだけで使いたい場合

```bash
cd path/to/your-repository

KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/agentic-pdm-sao-saito-hr"

mkdir -p .claude/skills .claude/agents

# Discovery スキル3つをまとめてインストール
cp -r ${KNOWLEDGE_DIR}/skills/interview-prep .claude/skills/
cp -r ${KNOWLEDGE_DIR}/skills/interview-to-needs .claude/skills/
cp -r ${KNOWLEDGE_DIR}/skills/make-hypothesis .claude/skills/

# 必須エージェントをすべてインストール
cp -r ${KNOWLEDGE_DIR}/agents/* .claude/agents/
```

### すべてのプロジェクトで使いたい場合

```bash
KNOWLEDGE_DIR="path/to/pochi-developing-knowledge-for-vibecoding-repository/001-requirements/agentic-pdm-sao-saito-hr"

mkdir -p ~/.claude/skills ~/.claude/agents

cp -r ${KNOWLEDGE_DIR}/skills/interview-prep ~/.claude/skills/
cp -r ${KNOWLEDGE_DIR}/skills/interview-to-needs ~/.claude/skills/
cp -r ${KNOWLEDGE_DIR}/skills/make-hypothesis ~/.claude/skills/
cp -r ${KNOWLEDGE_DIR}/agents/* ~/.claude/agents/
```

---

## ディレクトリ構成

```
agentic-pdm-sao-saito-hr/
├── README.md               # 本ファイル
├── agents/
│   ├── ux-researcher.md        # ユーザーニーズ・定性インサイト分析
│   ├── data-analyst.md         # 定量データ分析・KPI評価
│   ├── desktop-researcher.md   # ベストプラクティスリサーチ
│   └── user-persona.md         # ターゲットユーザー視点評価
└── skills/
    ├── operation-map-creator/   # [Planning] As-Is業務フロー生成
    ├── issue-map-creator/       # [Planning] 課題構造化・優先度付け
    ├── product-concept-creator/ # [Planning] プロダクトコンセプト設計
    ├── kpi-tree-creator/        # [Planning] KGI/KPIツリー設計
    ├── process-design-creator/  # [Planning] To-Be業務プロセス設計
    ├── usm-creator/             # [Planning] ユーザーストーリーマッピング
    ├── interview-prep/          # [Discovery] インタビュー設計・ガイド生成
    ├── interview-to-needs/      # [Discovery] インタビュー→ニーズ取り込み
    └── make-hypothesis/         # [Discovery] 仮説自動生成
```
