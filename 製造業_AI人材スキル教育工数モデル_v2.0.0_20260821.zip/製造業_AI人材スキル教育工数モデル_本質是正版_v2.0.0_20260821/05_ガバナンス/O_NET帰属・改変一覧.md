# O*NET帰属・改変一覧

## 固定版

- O*NET Database 30.3
- 取得・確認日: 2026-08-21
- Database: https://www.onetcenter.org/database.html
- Content Model: https://www.onetcenter.org/content.html
- License: https://www.onetcenter.org/license.html

## 帰属

This product uses the O*NET® database by the U.S. Department of Labor, Employment and Training Administration (USDOL/ETA).

O*NET data are used under the Creative Commons Attribution 4.0 International License.

## 改変

- 日本語訳・表記統一
- 同名要素の重複除外
- 複数O*NET職種と社内FDE/DS/ドメイン/その他職種の多対多対応
- 暫定等分重み
- 社内段位・要求水準
- 社内AI、ガバナンス、事業、ツール能力の追加
- Technology Skillsのツール群化
- Abilitiesを認定得点から除外
- Work Stylesを行動観察へ変更

These modifications have not been approved or endorsed by USDOL/ETA.

## 未取込

O*NET公式Element ID、Scale ID、Importance、Level、Not Relevant等は旧版に保持されていなかったため、推測せず空欄にしています。公式固定版から取込み、職務分析・人事承認を完了するまでHR利用ゲートを閉鎖します。
