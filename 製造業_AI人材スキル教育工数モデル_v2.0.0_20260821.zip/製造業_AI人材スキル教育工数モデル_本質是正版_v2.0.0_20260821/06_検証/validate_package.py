#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, json, math, re, sys, zipfile
from collections import defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET
import posixpath

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "03_正規データ"
VERIFY = ROOT / "06_検証"

def read_csv(name: str):
    with open(DATA / name, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def xlsx_formula_hash(path: Path):
    ns = {
        "m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
        "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    }
    formulas = []
    tables = validations = 0
    bad_refs = []
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None:
            raise ValueError("CRC error")
        names = z.namelist()
        if any(n.lower().endswith("vbaproject.bin") for n in names):
            raise ValueError("VBA detected")
        if any(n.startswith("xl/externalLinks/") for n in names):
            raise ValueError("external link detected")
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        relmap = {r.attrib["Id"]: r.attrib["Target"] for r in rels}
        for s in wb.find("m:sheets", ns):
            name = s.attrib["name"]
            rid = s.attrib["{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"]
            target = relmap[rid]
            sheet_path = target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join("xl", target))
            root = ET.fromstring(z.read(sheet_path))
            dvs = root.find("m:dataValidations", ns)
            if dvs is not None:
                validations += int(dvs.attrib.get("count", len(dvs)))
            tp = root.find("m:tableParts", ns)
            if tp is not None:
                tables += int(tp.attrib.get("count", len(tp)))
            for c in root.findall(".//m:c", ns):
                f = c.find("m:f", ns)
                if f is not None and f.text is not None:
                    formula = f.text
                    cell = c.attrib.get("r", "")
                    formulas.append((name, cell, formula))
                    if re.search(r"(?<!['])\b\d[^!']*!", formula):
                        bad_refs.append(f"{name}!{cell}")
    text = "\n".join(f"{name}!{cell}={formula}" for name, cell, formula in sorted(formulas, key=lambda x: (x[0], x[1])))
    return hashlib.sha256(text.encode("utf-8")).hexdigest(), len(formulas), tables, validations, bad_refs

def main() -> int:
    results = []
    def check(test_id, ok, detail):
        results.append({"test_id": test_id, "status": "PASS" if ok else "FAIL", "detail": detail})

    # File hashes
    hash_file = ROOT / "SHA256SUMS.txt"
    if not hash_file.exists():
        check("PKG-001", False, "SHA256SUMS.txt missing")
    else:
        for line in hash_file.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            expected, rel = line.split("  ", 1)
            p = ROOT / rel
            check(f"HASH:{rel}", p.exists() and sha256(p) == expected, rel)

    # Canonical data invariants
    comps = read_csv("competencies.csv")
    sources = read_csv("competency_sources.csv")
    modules = read_csv("modules.csv")
    mappings = read_csv("module_competencies.csv")
    rubrics = read_csv("rubrics.csv")
    reqs = read_csv("role_competency_requirements.csv")
    trace = list(csv.DictReader(open(VERIFY / "remediation_traceability.csv", encoding="utf-8-sig")))

    ids = [r["competency_id"] for r in comps]
    check("DATA-001", len(ids) == len(set(ids)), "competency_id unique")
    check("DATA-002", len(sources) == 488, f"source rows={len(sources)}")

    weights = defaultdict(float)
    for r in sources:
        weights[(r["role_group_id"], r["competency_id"])] += float(r["mapping_weight"])
    dev = max((abs(v - 1.0) for v in weights.values()), default=0)
    check("DATA-003", dev < 1e-5, f"max weight deviation={dev}")

    check("DATA-004", all(v.strip() != "―" for row in comps + sources + modules + mappings + rubrics + reqs for v in row.values()), "no exact dash-null sentinel")

    mapped_modules = {r["module_id"] for r in mappings}
    check("EDU-001", len(modules) == 64 and len(mapped_modules) == 64, f"modules={len(modules)}, mapped={len(mapped_modules)}")
    ojt = [r for r in modules if r["hours_status"] == "PROVISIONAL_OJT_ASSUMPTION"]
    check("EDU-002", len(ojt) == 23 and all(float(r["learner_hours"]) > 0 for r in ojt), f"OJT={len(ojt)}")

    weights_by_module = defaultdict(int)
    critical = defaultdict(int)
    for r in rubrics:
        weights_by_module[r["module_id"]] += int(float(r["weight_pct"]))
        if r["critical_gate"] == "Yes":
            critical[r["module_id"]] += 1
    check("EDU-003", len(weights_by_module) == 64 and all(v == 100 for v in weights_by_module.values()), "rubric weights")
    check("EDU-004", all(critical[m] >= 1 for m in weights_by_module), "critical gate")

    comp_types = {r["competency_id"]: r["source_type"] for r in comps}
    check("SKL-001", all(r["certification_scoring"] == "No" for r in reqs if comp_types.get(r["competency_id"]) in ("ONET_ABILITY", "ONET_WORK_STYLE")), "non-scoring types")
    check("GOV-001", len(trace) == 91, f"traceability={len(trace)}")

    # Workbook structure and formula hashes
    expected_hashes = json.loads((VERIFY / "formula_hashes.json").read_text(encoding="utf-8"))
    workbook_files = list((ROOT / "01_統合マスター").glob("*.xlsx")) + list((ROOT / "02_利用者向けビュー").glob("*.xlsx"))
    check("XLS-000", len(workbook_files) == 4, f"workbooks={len(workbook_files)}")
    for p in workbook_files:
        try:
            fh, count, tables, dvs, bad = xlsx_formula_hash(p)
            exp = expected_hashes[p.name]
            ok = fh == exp["formula_sha256"] and count == exp["formula_count"] and tables > 0 and not bad
            check(f"XLS:{p.name}", ok, f"formulas={count}, tables={tables}, validations={dvs}, badRefs={bad}")
        except Exception as exc:
            check(f"XLS:{p.name}", False, str(exc))

    failed = [r for r in results if r["status"] == "FAIL"]
    summary = {"status": "PASS" if not failed else "FAIL", "tests": len(results), "failed": len(failed), "results": results}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if not failed else 1

if __name__ == "__main__":
    raise SystemExit(main())
